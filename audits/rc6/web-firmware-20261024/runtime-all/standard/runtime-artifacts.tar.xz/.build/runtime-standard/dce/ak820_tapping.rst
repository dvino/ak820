                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _layer_hold_off
                                     12 	.globl _layer_hold_on
                                     13 	.globl _unregister_mods
                                     14 	.globl _register_mods
                                     15 	.globl _process_record
                                     16 	.globl _ADC_START
                                     17 	.globl _S0_R_FIFO
                                     18 	.globl _S0_T_FIFO
                                     19 	.globl _S0_FREE
                                     20 	.globl _S0_IF_BYTE
                                     21 	.globl _S0_IF_FIRST
                                     22 	.globl _S0_IF_OV
                                     23 	.globl _S0_FST_ACT
                                     24 	.globl _CP_RL2
                                     25 	.globl _C_T2
                                     26 	.globl _TR2
                                     27 	.globl _EXEN2
                                     28 	.globl _TCLK
                                     29 	.globl _RCLK
                                     30 	.globl _EXF2
                                     31 	.globl _CAP1F
                                     32 	.globl _TF2
                                     33 	.globl _RI
                                     34 	.globl _TI
                                     35 	.globl _RB8
                                     36 	.globl _TB8
                                     37 	.globl _REN
                                     38 	.globl _SM2
                                     39 	.globl _SM1
                                     40 	.globl _SM0
                                     41 	.globl _IT0
                                     42 	.globl _IE0
                                     43 	.globl _IT1
                                     44 	.globl _IE1
                                     45 	.globl _TR0
                                     46 	.globl _TF0
                                     47 	.globl _TR1
                                     48 	.globl _TF1
                                     49 	.globl _P4_0
                                     50 	.globl _P4_1
                                     51 	.globl _P4_2
                                     52 	.globl _P4_3
                                     53 	.globl _P4_4
                                     54 	.globl _P4_5
                                     55 	.globl _P4_6
                                     56 	.globl _RXD
                                     57 	.globl _TXD
                                     58 	.globl _INT0
                                     59 	.globl _INT1
                                     60 	.globl _T0
                                     61 	.globl _T1
                                     62 	.globl _MOSI1
                                     63 	.globl _MISO1
                                     64 	.globl _SCK1
                                     65 	.globl _P3_0
                                     66 	.globl _P3_1
                                     67 	.globl _P3_2
                                     68 	.globl _P3_3
                                     69 	.globl _P3_4
                                     70 	.globl _P3_5
                                     71 	.globl _P3_6
                                     72 	.globl _P3_7
                                     73 	.globl _CAP1_
                                     74 	.globl _T2_
                                     75 	.globl _CAP2_
                                     76 	.globl _T2EX_
                                     77 	.globl _RXD1
                                     78 	.globl _TXD1
                                     79 	.globl _P2_0
                                     80 	.globl _P2_1
                                     81 	.globl _P2_2
                                     82 	.globl _P2_3
                                     83 	.globl _P2_4
                                     84 	.globl _P2_5
                                     85 	.globl _P2_6
                                     86 	.globl _P2_7
                                     87 	.globl _AIN0
                                     88 	.globl _AIN1
                                     89 	.globl _AIN2
                                     90 	.globl _AIN3
                                     91 	.globl _AIN4
                                     92 	.globl _AIN5
                                     93 	.globl _AIN6
                                     94 	.globl _AIN7
                                     95 	.globl _CAP1
                                     96 	.globl _T2
                                     97 	.globl _CAP2
                                     98 	.globl _T2EX
                                     99 	.globl _INT0_
                                    100 	.globl _SCS
                                    101 	.globl _MOSI
                                    102 	.globl _MISO
                                    103 	.globl _SCK
                                    104 	.globl _RXD1_
                                    105 	.globl _TXD1_
                                    106 	.globl _P1_0
                                    107 	.globl _P1_1
                                    108 	.globl _P1_2
                                    109 	.globl _P1_3
                                    110 	.globl _P1_4
                                    111 	.globl _P1_5
                                    112 	.globl _P1_6
                                    113 	.globl _P1_7
                                    114 	.globl _AIN8
                                    115 	.globl _AIN9
                                    116 	.globl _AIN10
                                    117 	.globl _AIN11
                                    118 	.globl _AIN12
                                    119 	.globl _AIN13
                                    120 	.globl _RXD_
                                    121 	.globl _TXD_
                                    122 	.globl _SCL0
                                    123 	.globl _SDA0
                                    124 	.globl _P0_0
                                    125 	.globl _P0_1
                                    126 	.globl _P0_2
                                    127 	.globl _P0_3
                                    128 	.globl _P0_4
                                    129 	.globl _P0_5
                                    130 	.globl _P0_6
                                    131 	.globl _P0_7
                                    132 	.globl _IE_SPI0
                                    133 	.globl _IE_USB
                                    134 	.globl _IE_ADC
                                    135 	.globl _IE_UART1
                                    136 	.globl _IE_PWM_I2C
                                    137 	.globl _IE_GPIO
                                    138 	.globl _IE_WDOG
                                    139 	.globl _PX0
                                    140 	.globl _PT0
                                    141 	.globl _PX1
                                    142 	.globl _PT1
                                    143 	.globl _PS
                                    144 	.globl _PT2
                                    145 	.globl _PL_FLAG
                                    146 	.globl _PH_FLAG
                                    147 	.globl _EX0
                                    148 	.globl _ET0
                                    149 	.globl _EX1
                                    150 	.globl _ET1
                                    151 	.globl _ES
                                    152 	.globl _ET2
                                    153 	.globl _E_DIS
                                    154 	.globl _EA
                                    155 	.globl _P
                                    156 	.globl _F1
                                    157 	.globl _OV
                                    158 	.globl _RS0
                                    159 	.globl _RS1
                                    160 	.globl _F0
                                    161 	.globl _AC
                                    162 	.globl _CY
                                    163 	.globl _I2CS_INT_ST
                                    164 	.globl _I2CX_INT
                                    165 	.globl _LED_STATUS
                                    166 	.globl _LED_DMA_H
                                    167 	.globl _LED_DMA_L
                                    168 	.globl _LED_DMA
                                    169 	.globl _LED_PWM_OE
                                    170 	.globl _LED_COMMON
                                    171 	.globl _ADC_CHAN
                                    172 	.globl _ADC_DAT_H
                                    173 	.globl _ADC_DAT_L
                                    174 	.globl _ADC_DAT
                                    175 	.globl _ADC_CTRL
                                    176 	.globl _SPI1_CK_SE
                                    177 	.globl _SPI1_CTRL
                                    178 	.globl _SPI1_DATA
                                    179 	.globl _SPI1_STAT
                                    180 	.globl _SIF1
                                    181 	.globl _SBAUD1
                                    182 	.globl _SBUF1
                                    183 	.globl _SCON1
                                    184 	.globl _SPI0_SETUP
                                    185 	.globl _SPI0_CK_SE
                                    186 	.globl _SPI0_CTRL
                                    187 	.globl _SPI0_DATA
                                    188 	.globl _SPI0_STAT
                                    189 	.globl _T2CAP1H
                                    190 	.globl _T2CAP1L
                                    191 	.globl _T2CAP1
                                    192 	.globl _TH2
                                    193 	.globl _TL2
                                    194 	.globl _T2COUNT
                                    195 	.globl _RCAP2H
                                    196 	.globl _RCAP2L
                                    197 	.globl _RCAP2
                                    198 	.globl _T2MOD
                                    199 	.globl _T2CON
                                    200 	.globl _SBUF
                                    201 	.globl _SCON
                                    202 	.globl _TH1
                                    203 	.globl _TH0
                                    204 	.globl _TL1
                                    205 	.globl _TL0
                                    206 	.globl _TMOD
                                    207 	.globl _TCON
                                    208 	.globl _XBUS_AUX
                                    209 	.globl _P7
                                    210 	.globl _P6_DIR
                                    211 	.globl _P6_OUT_PU
                                    212 	.globl _P6_IN
                                    213 	.globl _P5_DIR
                                    214 	.globl _P5_OUT_PU
                                    215 	.globl _P5_IN
                                    216 	.globl _P4_LED_KEY
                                    217 	.globl _P4_DIR_PU
                                    218 	.globl _P4_MOD_OC
                                    219 	.globl _P4
                                    220 	.globl _P3_DIR_PU
                                    221 	.globl _P3_MOD_OC
                                    222 	.globl _P3
                                    223 	.globl _P2_DIR_PU
                                    224 	.globl _P2_MOD_OC
                                    225 	.globl _P2
                                    226 	.globl _P1_DIR_PU
                                    227 	.globl _P1_MOD_OC
                                    228 	.globl _P1
                                    229 	.globl _P0_DIR_PU
                                    230 	.globl _P0_MOD_OC
                                    231 	.globl _P0
                                    232 	.globl _ROM_CTRL
                                    233 	.globl _ROM_DATA_HH
                                    234 	.globl _ROM_DATA_HL
                                    235 	.globl _ROM_DATA_HI
                                    236 	.globl _ROM_ADDR_H
                                    237 	.globl _ROM_ADDR_L
                                    238 	.globl _ROM_ADDR
                                    239 	.globl _GPIO_IE
                                    240 	.globl _IP_EX
                                    241 	.globl _IE_EX
                                    242 	.globl _IP
                                    243 	.globl _IE
                                    244 	.globl _WDOG_COUNT
                                    245 	.globl _RESET_KEEP
                                    246 	.globl _WAKE_CTRL
                                    247 	.globl _CLOCK_CFG
                                    248 	.globl _POWER_CFG
                                    249 	.globl _PCON
                                    250 	.globl _GLOBAL_CFG
                                    251 	.globl _SAFE_MOD
                                    252 	.globl _DPH
                                    253 	.globl _DPL
                                    254 	.globl _SP
                                    255 	.globl _A_INV
                                    256 	.globl _B
                                    257 	.globl _ACC
                                    258 	.globl _PSW
                                    259 	.globl _ak820_tapping_before
                                    260 	.globl _ak820_tapping_process
                                    261 	.globl _ak820_tapping_cancel
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
      000015                        524 _ak820_tapping_process_sloc0_1_0:
      000015                        525 	.ds 2
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable items in internal ram
                                    528 ;--------------------------------------------------------
                                    529 ;--------------------------------------------------------
                                    530 ; indirectly addressable internal ram data
                                    531 ;--------------------------------------------------------
                                    532 	.area ISEG    (DATA)
                                    533 ;--------------------------------------------------------
                                    534 ; absolute internal ram data
                                    535 ;--------------------------------------------------------
                                    536 	.area IABS    (ABS,DATA)
                                    537 	.area IABS    (ABS,DATA)
                                    538 ;--------------------------------------------------------
                                    539 ; bit data
                                    540 ;--------------------------------------------------------
                                    541 	.area BSEG    (BIT)
      00000E                        542 _ak820_tapping_before_sloc0_1_0:
      00000E                        543 	.ds 1
                                    544 ;--------------------------------------------------------
                                    545 ; paged external ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area PSEG    (PAG,XDATA)
                                    548 ;--------------------------------------------------------
                                    549 ; uninitialized external ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area XSEG    (XDATA)
      00059C                        552 _source_state:
      00059C                        553 	.ds 130
      00061E                        554 _pending_time:
      00061E                        555 	.ds 2
      000620                        556 _pending_code:
      000620                        557 	.ds 2
      000622                        558 _source_PARM_1:
      000622                        559 	.ds 2
      000624                        560 _hold_PARM_2:
      000624                        561 	.ds 1
      000625                        562 _hold_code_10000_597:
      000625                        563 	.ds 2
      000627                        564 _hold_mods_30000_600:
      000627                        565 	.ds 1
      000628                        566 _commit_pending_id_10000_606:
      000628                        567 	.ds 1
      000629                        568 _ak820_tapping_before_event_10000_607:
      000629                        569 	.ds 2
      00062B                        570 _ak820_tapping_process_record_10000_618:
      00062B                        571 	.ds 2
                                    572 ;--------------------------------------------------------
                                    573 ; absolute external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area XABS    (ABS,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; initialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XISEG   (XDATA)
      000D9C                        580 _pending:
      000D9C                        581 	.ds 1
                                    582 	.area HOME    (CODE)
                                    583 	.area GSINIT0 (CODE)
                                    584 	.area GSINIT1 (CODE)
                                    585 	.area GSINIT2 (CODE)
                                    586 	.area GSINIT3 (CODE)
                                    587 	.area GSINIT4 (CODE)
                                    588 	.area GSINIT5 (CODE)
                                    589 	.area GSINIT  (CODE)
                                    590 	.area GSFINAL (CODE)
                                    591 	.area CSEG    (CODE)
                                    592 ;--------------------------------------------------------
                                    593 ; global & static initialisations
                                    594 ;--------------------------------------------------------
                                    595 	.area HOME    (CODE)
                                    596 	.area GSINIT  (CODE)
                                    597 	.area GSFINAL (CODE)
                                    598 	.area GSINIT  (CODE)
                                    599 ;--------------------------------------------------------
                                    600 ; Home
                                    601 ;--------------------------------------------------------
                                    602 	.area HOME    (CODE)
                                    603 	.area HOME    (CODE)
                                    604 ;--------------------------------------------------------
                                    605 ; code
                                    606 ;--------------------------------------------------------
                                    607 	.area CSEG    (CODE)
                                    608 ;------------------------------------------------------------
                                    609 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    610 ;------------------------------------------------------------
                                    611 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    612 ;------------------------------------------------------------
                                    613 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    614 ;	-----------------------------------------
                           000007   615 	ar7 = 0x07
                           000006   616 	ar6 = 0x06
                           000005   617 	ar5 = 0x05
                           000004   618 	ar4 = 0x04
                           000003   619 	ar3 = 0x03
                           000002   620 	ar2 = 0x02
                           000001   621 	ar1 = 0x01
                           000000   622 	ar0 = 0x00
                                    623 ;	 function source
                                    624 ;	-----------------------------------------
      004387                        625 _source:
                                    626 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004387 90 06 23         [24]  627 	mov	dptr,#(_source_PARM_1 + 0x0001)
      00438A E0               [24]  628 	movx	a,@dptr
      00438B FF               [12]  629 	mov	r7,a
      00438C BF 10 00         [24]  630 	cjne	r7,#0x10,00147$
      00438F                        631 00147$:
      00438F 50 14            [24]  632 	jnc	00102$
      004391 90 06 22         [24]  633 	mov	dptr,#_source_PARM_1
      004394 E0               [24]  634 	movx	a,@dptr
      004395 FE               [12]  635 	mov	r6,a
      004396 BE 08 00         [24]  636 	cjne	r6,#0x08,00149$
      004399                        637 00149$:
      004399 50 0A            [24]  638 	jnc	00102$
      00439B 8F 05            [24]  639 	mov	ar5,r7
      00439D ED               [12]  640 	mov	a,r5
      00439E 12 38 C1         [24]  641 	lcall	_ak820_outline_0184
      0043A1 2E               [12]  642 	add	a,r6
      0043A2 F5 82            [12]  643 	mov	dpl,a
      0043A4 22               [24]  644 	ret
      0043A5                        645 00102$:
                                    646 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      0043A5 90 06 22         [24]  647 	mov	dptr,#_source_PARM_1
      0043A8 E0               [24]  648 	movx	a,@dptr
      0043A9 FE               [12]  649 	mov	r6,a
      0043AA BE 01 00         [24]  650 	cjne	r6,#0x01,00151$
      0043AD                        651 00151$:
      0043AD 50 0E            [24]  652 	jnc	00109$
                                    653 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0043AF BF FD 04         [24]  654 	cjne	r7,#0xfd,00105$
      0043B2 75 82 80         [24]  655 	mov	dpl, #0x80
      0043B5 22               [24]  656 	ret
      0043B6                        657 00105$:
                                    658 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0043B6 BF FC 04         [24]  659 	cjne	r7,#0xfc,00109$
      0043B9 75 82 81         [24]  660 	mov	dpl, #0x81
      0043BC 22               [24]  661 	ret
      0043BD                        662 00109$:
                                    663 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      0043BD 75 82 FF         [24]  664 	mov	dpl, #0xff
                                    665 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      0043C0 22               [24]  666 	ret
                                    667 ;------------------------------------------------------------
                                    668 ;Allocation info for local variables in function 'hold'
                                    669 ;------------------------------------------------------------
                                    670 ;pressed       Allocated with name '_hold_PARM_2'
                                    671 ;code          Allocated with name '_hold_code_10000_597'
                                    672 ;mods          Allocated with name '_hold_mods_30000_600'
                                    673 ;layer         Allocated with name '_hold_layer_30000_603'
                                    674 ;------------------------------------------------------------
                                    675 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    676 ;	-----------------------------------------
                                    677 ;	 function hold
                                    678 ;	-----------------------------------------
      0043C1                        679 _hold:
      0043C1 12 38 88         [24]  680 	lcall	_ak820_outline_0104
      0043C4 90 06 25         [24]  681 	mov	dptr,#_hold_code_10000_597
      0043C7 12 38 83         [24]  682 	lcall	_ak820_outline_0103
                                    683 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      0043CA 90 06 25         [24]  684 	mov	dptr,#_hold_code_10000_597
      0043CD 12 46 89         [24]  685 	lcall	_ak820_outline_0008
      0043D0 74 C0            [12]  686 	mov	a,#0x100 - 0x40
      0043D2 2D               [12]  687 	add	a,r5
      0043D3 40 2E            [24]  688 	jc	00110$
                                    689 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      0043D5 8F 05            [24]  690 	mov	ar5,r7
      0043D7 53 05 1F         [24]  691 	anl	ar5,#0x1f
      0043DA 90 06 27         [24]  692 	mov	dptr,#_hold_mods_30000_600
      0043DD ED               [12]  693 	mov	a,r5
      0043DE F0               [24]  694 	movx	@dptr,a
                                    695 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      0043DF ED               [12]  696 	mov	a,r5
      0043E0 30 E4 08         [24]  697 	jnb	acc.4,00102$
      0043E3 ED               [12]  698 	mov	a,r5
      0043E4 C4               [12]  699 	swap	a
      0043E5 54 F0            [12]  700 	anl	a,#0xf0
      0043E7 90 06 27         [24]  701 	mov	dptr,#_hold_mods_30000_600
      0043EA F0               [24]  702 	movx	@dptr,a
      0043EB                        703 00102$:
                                    704 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      0043EB 90 06 24         [24]  705 	mov	dptr,#_hold_PARM_2
      0043EE E0               [24]  706 	movx	a,@dptr
      0043EF 60 09            [24]  707 	jz	00104$
      0043F1 90 06 27         [24]  708 	mov	dptr,#_hold_mods_30000_600
      0043F4 E0               [24]  709 	movx	a,@dptr
      0043F5 F5 82            [12]  710 	mov	dpl,a
      0043F7 02 73 6F         [24]  711 	ljmp	_register_mods
      0043FA                        712 00104$:
                                    713 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      0043FA 90 06 27         [24]  714 	mov	dptr,#_hold_mods_30000_600
      0043FD E0               [24]  715 	movx	a,@dptr
      0043FE F5 82            [12]  716 	mov	dpl,a
      004400 02 73 83         [24]  717 	ljmp	_unregister_mods
      004403                        718 00110$:
                                    719 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004403 8F 06            [24]  720 	mov	ar6,r7
      004405 74 0F            [12]  721 	mov	a,#0x0f
      004407 5E               [12]  722 	anl	a,r6
      004408 FF               [12]  723 	mov	r7,a
                                    724 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      004409 90 06 24         [24]  725 	mov	dptr,#_hold_PARM_2
      00440C E0               [24]  726 	movx	a,@dptr
      00440D 60 05            [24]  727 	jz	00107$
      00440F 8F 82            [24]  728 	mov	dpl, r7
      004411 02 75 38         [24]  729 	ljmp	_layer_hold_on
      004414                        730 00107$:
                                    731 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      004414 8F 82            [24]  732 	mov	dpl, r7
                                    733 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      004416 02 75 70         [24]  734 	ljmp	_layer_hold_off
                                    735 ;------------------------------------------------------------
                                    736 ;Allocation info for local variables in function 'commit_pending'
                                    737 ;------------------------------------------------------------
                                    738 ;id            Allocated with name '_commit_pending_id_10000_606'
                                    739 ;------------------------------------------------------------
                                    740 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    741 ;	-----------------------------------------
                                    742 ;	 function commit_pending
                                    743 ;	-----------------------------------------
      004419                        744 _commit_pending:
                                    745 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      004419 90 0D 9C         [24]  746 	mov	dptr,#_pending
      00441C E0               [24]  747 	movx	a,@dptr
      00441D 90 06 28         [24]  748 	mov	dptr,#_commit_pending_id_10000_606
      004420 F0               [24]  749 	movx	@dptr,a
                                    750 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      004421 12 46 F2         [24]  751 	lcall	_ak820_outline_0148
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      004424 90 06 28         [24]  753 	mov	dptr,#_commit_pending_id_10000_606
      004427 E0               [24]  754 	movx	a,@dptr
      004428 24 9C            [12]  755 	add	a,#_source_state
      00442A FF               [12]  756 	mov	r7,a
      00442B E4               [12]  757 	clr	a
      00442C 34 05            [12]  758 	addc	a, #(_source_state >> 8)
      00442E FE               [12]  759 	mov	r6,a
      00442F 12 43 71         [24]  760 	lcall	_ak820_outline_0152
      004432 E0               [24]  761 	movx	a,@dptr
      004433 FD               [12]  762 	mov	r5,a
      004434 43 05 04         [24]  763 	orl	ar5,#0x04
      004437 12 43 71         [24]  764 	lcall	_ak820_outline_0152
      00443A ED               [12]  765 	mov	a,r5
      00443B F0               [24]  766 	movx	@dptr,a
                                    767 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      00443C 90 06 20         [24]  768 	mov	dptr,#_pending_code
      00443F 12 38 42         [24]  769 	lcall	_ak820_outline_0051
      004442 90 06 24         [24]  770 	mov	dptr,#_hold_PARM_2
      004445 74 01            [12]  771 	mov	a,#0x01
      004447 12 43 32         [24]  772 	lcall	_ak820_outline_0071
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      00444A 02 43 C1         [24]  774 	ljmp	_hold
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    777 ;------------------------------------------------------------
                                    778 ;event         Allocated with name '_ak820_tapping_before_event_10000_607'
                                    779 ;id            Allocated with name '_ak820_tapping_before_id_10000_608'
                                    780 ;------------------------------------------------------------
                                    781 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    782 ;	-----------------------------------------
                                    783 ;	 function ak820_tapping_before
                                    784 ;	-----------------------------------------
      00444D                        785 _ak820_tapping_before:
      00444D 12 38 88         [24]  786 	lcall	_ak820_outline_0104
      004450 90 06 29         [24]  787 	mov	dptr,#_ak820_tapping_before_event_10000_607
      004453 12 38 83         [24]  788 	lcall	_ak820_outline_0103
                                    789 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      004456 90 06 29         [24]  790 	mov	dptr,#_ak820_tapping_before_event_10000_607
      004459 12 46 89         [24]  791 	lcall	_ak820_outline_0008
      00445C 12 46 9E         [24]  792 	lcall	_ak820_outline_0022
      00445F C0 07            [24]  793 	push	ar7
      004461 C0 06            [24]  794 	push	ar6
      004463 12 B4 82         [24]  795 	lcall	___memcpy
      004466 12 43 87         [24]  796 	lcall	_source
      004469 AD 82            [24]  797 	mov	r5, dpl
      00446B D0 06            [24]  798 	pop	ar6
      00446D D0 07            [24]  799 	pop	ar7
                                    800 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      00446F 90 0E 0C         [24]  801 	mov	dptr,#_vial_unlock_in_progress
      004472 E0               [24]  802 	movx	a,@dptr
      004473 60 29            [24]  803 	jz	00106$
                                    804 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004475 74 04            [12]  805 	mov	a,#0x04
      004477 12 46 93         [24]  806 	lcall	_ak820_outline_0017
      00447A 60 1E            [24]  807 	jz	00102$
      00447C BD FF 02         [24]  808 	cjne	r5,#0xff,00218$
      00447F 80 19            [24]  809 	sjmp	00102$
      004481                        810 00218$:
      004481 74 05            [12]  811 	mov	a,#0x05
      004483 12 46 93         [24]  812 	lcall	_ak820_outline_0017
      004486 70 12            [24]  813 	jnz	00102$
      004488 ED               [12]  814 	mov	a,r5
      004489 24 9C            [12]  815 	add	a, #_source_state
      00448B FB               [12]  816 	mov	r3,a
      00448C E4               [12]  817 	clr	a
      00448D 34 05            [12]  818 	addc	a, #(_source_state >> 8)
      00448F 12 46 CE         [24]  819 	lcall	_ak820_outline_0055
      004492 53 02 FD         [24]  820 	anl	ar2,#0xfd
      004495 12 33 FC         [24]  821 	lcall	_ak820_outline_0119
      004498 EA               [12]  822 	mov	a,r2
      004499 F0               [24]  823 	movx	@dptr,a
      00449A                        824 00102$:
                                    825 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      00449A 75 82 00         [24]  826 	mov	dpl, #0x00
      00449D 22               [24]  827 	ret
      00449E                        828 00106$:
                                    829 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      00449E 90 0D 9C         [24]  830 	mov	dptr,#_pending
      0044A1 E0               [24]  831 	movx	a,@dptr
      0044A2 FC               [12]  832 	mov	r4,a
      0044A3 BC FF 02         [24]  833 	cjne	r4,#0xff,00220$
      0044A6 80 3B            [24]  834 	sjmp	00108$
      0044A8                        835 00220$:
      0044A8 12 38 3A         [24]  836 	lcall	_ak820_outline_0035
      0044AB FA               [12]  837 	mov	r2,a
      0044AC A3               [24]  838 	inc	dptr
      0044AD E0               [24]  839 	movx	a,@dptr
      0044AE FB               [12]  840 	mov	r3,a
      0044AF 90 06 1E         [24]  841 	mov	dptr,#_pending_time
      0044B2 12 38 77         [24]  842 	lcall	_ak820_outline_0097
      0044B5 EA               [12]  843 	mov	a,r2
      0044B6 C3               [12]  844 	clr	c
      0044B7 98               [12]  845 	subb	a,r0
      0044B8 FA               [12]  846 	mov	r2,a
      0044B9 EB               [12]  847 	mov	a,r3
      0044BA 99               [12]  848 	subb	a,r1
      0044BB FB               [12]  849 	mov	r3,a
      0044BC C3               [12]  850 	clr	c
      0044BD EA               [12]  851 	mov	a,r2
      0044BE 94 C8            [12]  852 	subb	a,#0xc8
      0044C0 EB               [12]  853 	mov	a,r3
      0044C1 94 00            [12]  854 	subb	a,#0x00
      0044C3 50 17            [24]  855 	jnc	00107$
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0044C5 74 04            [12]  857 	mov	a,#0x04
      0044C7 12 46 B8         [24]  858 	lcall	_ak820_outline_0030
      0044CA 60 17            [24]  859 	jz	00108$
      0044CC 12 38 13         [24]  860 	lcall	_ak820_outline_0013
      0044CF 60 12            [24]  861 	jz	00108$
      0044D1 BD FF 02         [24]  862 	cjne	r5,#0xff,00224$
      0044D4 80 06            [24]  863 	sjmp	00107$
      0044D6                        864 00224$:
      0044D6 ED               [12]  865 	mov	a,r5
      0044D7 B5 04 02         [24]  866 	cjne	a,ar4,00225$
      0044DA 80 07            [24]  867 	sjmp	00108$
      0044DC                        868 00225$:
      0044DC                        869 00107$:
      0044DC C0 05            [24]  870 	push	ar5
      0044DE 12 44 19         [24]  871 	lcall	_commit_pending
      0044E1 D0 05            [24]  872 	pop	ar5
      0044E3                        873 00108$:
                                    874 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      0044E3 90 06 29         [24]  875 	mov	dptr,#_ak820_tapping_before_event_10000_607
      0044E6 12 38 42         [24]  876 	lcall	_ak820_outline_0051
      0044E9 74 04            [12]  877 	mov	a,#0x04
      0044EB 12 46 93         [24]  878 	lcall	_ak820_outline_0017
      0044EE 60 03            [24]  879 	jz	00114$
      0044F0 BD FF 04         [24]  880 	cjne	r5,#0xff,00115$
      0044F3                        881 00114$:
      0044F3 75 82 01         [24]  882 	mov	dpl, #0x01
      0044F6 22               [24]  883 	ret
      0044F7                        884 00115$:
                                    885 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      0044F7 ED               [12]  886 	mov	a,r5
      0044F8 24 9C            [12]  887 	add	a, #_source_state
      0044FA FC               [12]  888 	mov	r4,a
      0044FB E4               [12]  889 	clr	a
      0044FC 34 05            [12]  890 	addc	a, #(_source_state >> 8)
      0044FE FD               [12]  891 	mov	r5,a
      0044FF 12 43 38         [24]  892 	lcall	_ak820_outline_0089
      004502 FB               [12]  893 	mov	r3,a
      004503 30 E1 12         [24]  894 	jnb	acc.1,00120$
                                    895 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004506 74 05            [12]  896 	mov	a,#0x05
      004508 2E               [12]  897 	add	a, r6
      004509 12 38 20         [24]  898 	lcall	_ak820_outline_0014
      00450C 70 06            [24]  899 	jnz	00118$
      00450E 74 FD            [12]  900 	mov	a,#0xfd
      004510 5B               [12]  901 	anl	a,r3
      004511 12 43 50         [24]  902 	lcall	_ak820_outline_0116
      004514                        903 00118$:
                                    904 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      004514 75 82 00         [24]  905 	mov	dpl, #0x00
      004517 22               [24]  906 	ret
      004518                        907 00120$:
                                    908 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004518 12 42 FC         [24]  909 	lcall	_ak820_outline_0010
      00451B E0               [24]  910 	movx	a,@dptr
      00451C FF               [12]  911 	mov	r7,a
      00451D 8B 06            [24]  912 	mov	ar6,r3
      00451F 53 06 01         [24]  913 	anl	ar6,#0x01
      004522 EE               [12]  914 	mov	a,r6
      004523 B4 01 00         [24]  915 	cjne	a,#0x01,00231$
      004526                        916 00231$:
      004526 B3               [12]  917 	cpl	c
      004527 92 0E            [24]  918 	mov	_ak820_tapping_before_sloc0_1_0,c
      004529 8F F0            [24]  919 	mov	b,r7
      00452B E4               [12]  920 	clr	a
      00452C 33               [12]  921 	rlc	a
      00452D B5 F0 04         [24]  922 	cjne	a,b,00122$
      004530 75 82 00         [24]  923 	mov	dpl, #0x00
      004533 22               [24]  924 	ret
      004534                        925 00122$:
                                    926 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      004534 63 03 01         [24]  927 	xrl	ar3,#0x01
      004537 12 38 92         [24]  928 	lcall	_ak820_outline_0120
      00453A EB               [12]  929 	mov	a,r3
      00453B F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      00453C 75 82 01         [24]  932 	mov	dpl, #0x01
                                    933 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      00453F 22               [24]  934 	ret
                                    935 ;------------------------------------------------------------
                                    936 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    937 ;------------------------------------------------------------
                                    938 ;sloc0         Allocated with name '_ak820_tapping_process_sloc0_1_0'
                                    939 ;record        Allocated with name '_ak820_tapping_process_record_10000_618'
                                    940 ;id            Allocated with name '_ak820_tapping_process_id_10000_619'
                                    941 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_619'
                                    942 ;code          Allocated with name '_ak820_tapping_process_code_10000_619'
                                    943 ;------------------------------------------------------------
                                    944 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    945 ;	-----------------------------------------
                                    946 ;	 function ak820_tapping_process
                                    947 ;	-----------------------------------------
      004540                        948 _ak820_tapping_process:
      004540 12 38 88         [24]  949 	lcall	_ak820_outline_0104
      004543 90 06 2B         [24]  950 	mov	dptr,#_ak820_tapping_process_record_10000_618
      004546 12 38 83         [24]  951 	lcall	_ak820_outline_0103
                                    952 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      004549 90 06 2B         [24]  953 	mov	dptr,#_ak820_tapping_process_record_10000_618
      00454C 12 38 42         [24]  954 	lcall	_ak820_outline_0051
      00454F 74 04            [12]  955 	mov	a,#0x04
      004551 12 46 C3         [24]  956 	lcall	_ak820_outline_0031
      004554 70 04            [24]  957 	jnz	00102$
      004556 75 82 01         [24]  958 	mov	dpl, #0x01
      004559 22               [24]  959 	ret
      00455A                        960 00102$:
                                    961 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      00455A 8E 04            [24]  962 	mov	ar4,r6
      00455C 8F 05            [24]  963 	mov	ar5,r7
      00455E 12 46 9E         [24]  964 	lcall	_ak820_outline_0022
      004561 C0 07            [24]  965 	push	ar7
      004563 C0 06            [24]  966 	push	ar6
      004565 12 B4 82         [24]  967 	lcall	___memcpy
      004568 12 43 87         [24]  968 	lcall	_source
      00456B AD 82            [24]  969 	mov	r5, dpl
      00456D D0 06            [24]  970 	pop	ar6
      00456F D0 07            [24]  971 	pop	ar7
                                    972 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      004571 BD FF 04         [24]  973 	cjne	r5,#0xff,00104$
      004574 75 82 01         [24]  974 	mov	dpl, #0x01
      004577 22               [24]  975 	ret
      004578                        976 00104$:
                                    977 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      004578 74 07            [12]  978 	mov	a,#0x07
      00457A 12 38 32         [24]  979 	lcall	_ak820_outline_0021
      00457D E0               [24]  980 	movx	a,@dptr
      00457E F5 15            [12]  981 	mov	_ak820_tapping_process_sloc0_1_0,a
      004580 A3               [24]  982 	inc	dptr
      004581 E0               [24]  983 	movx	a,@dptr
      004582 F5 16            [12]  984 	mov	(_ak820_tapping_process_sloc0_1_0 + 1),a
                                    985 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      004584 AC 16            [24]  986 	mov	r4,(_ak820_tapping_process_sloc0_1_0 + 1)
                                    987 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      004586 BC 20 00         [24]  988 	cjne	r4,#0x20,00189$
      004589                        989 00189$:
      004589 40 05            [24]  990 	jc	00105$
      00458B BC 50 00         [24]  991 	cjne	r4,#0x50,00191$
      00458E                        992 00191$:
      00458E 40 04            [24]  993 	jc	00106$
      004590                        994 00105$:
      004590 75 82 01         [24]  995 	mov	dpl, #0x01
      004593 22               [24]  996 	ret
      004594                        997 00106$:
                                    998 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004594 BC 40 00         [24]  999 	cjne	r4,#0x40,00193$
      004597                       1000 00193$:
      004597 40 0C            [24] 1001 	jc	00109$
      004599 53 04 0F         [24] 1002 	anl	ar4,#0x0f
      00459C BC 06 00         [24] 1003 	cjne	r4,#0x06,00195$
      00459F                       1004 00195$:
      00459F 40 04            [24] 1005 	jc	00109$
      0045A1 75 82 00         [24] 1006 	mov	dpl, #0x00
      0045A4 22               [24] 1007 	ret
      0045A5                       1008 00109$:
                                   1009 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      0045A5 90 06 2B         [24] 1010 	mov	dptr,#_ak820_tapping_process_record_10000_618
      0045A8 12 38 7D         [24] 1011 	lcall	_ak820_outline_0099
      0045AB 74 05            [12] 1012 	mov	a,#0x05
      0045AD 2B               [12] 1013 	add	a, r3
      0045AE F9               [12] 1014 	mov	r1,a
      0045AF E4               [12] 1015 	clr	a
      0045B0 3C               [12] 1016 	addc	a, r4
      0045B1 FA               [12] 1017 	mov	r2,a
      0045B2 12 43 67         [24] 1018 	lcall	_ak820_outline_0142
      0045B5 E0               [24] 1019 	movx	a,@dptr
      0045B6 60 22            [24] 1020 	jz	00119$
                                   1021 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      0045B8 90 0D 9C         [24] 1022 	mov	dptr,#_pending
      0045BB ED               [12] 1023 	mov	a,r5
      0045BC 12 46 EC         [24] 1024 	lcall	_ak820_outline_0118
                                   1025 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      0045BF A3               [24] 1026 	inc	dptr
      0045C0 A3               [24] 1027 	inc	dptr
      0045C1 E0               [24] 1028 	movx	a,@dptr
      0045C2 F8               [12] 1029 	mov	r0,a
      0045C3 A3               [24] 1030 	inc	dptr
      0045C4 E0               [24] 1031 	movx	a,@dptr
      0045C5 FF               [12] 1032 	mov	r7,a
      0045C6 90 06 1E         [24] 1033 	mov	dptr,#_pending_time
      0045C9 E8               [12] 1034 	mov	a,r0
      0045CA 12 38 83         [24] 1035 	lcall	_ak820_outline_0103
                                   1036 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      0045CD 90 06 20         [24] 1037 	mov	dptr,#_pending_code
      0045D0 E5 15            [12] 1038 	mov	a,_ak820_tapping_process_sloc0_1_0
      0045D2 F0               [24] 1039 	movx	@dptr,a
      0045D3 E5 16            [12] 1040 	mov	a,(_ak820_tapping_process_sloc0_1_0 + 1)
      0045D5 A3               [24] 1041 	inc	dptr
      0045D6 F0               [24] 1042 	movx	@dptr,a
      0045D7 02 46 5D         [24] 1043 	ljmp	00120$
      0045DA                       1044 00119$:
                                   1045 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      0045DA 90 0D 9C         [24] 1046 	mov	dptr,#_pending
      0045DD E0               [24] 1047 	movx	a,@dptr
      0045DE FF               [12] 1048 	mov	r7,a
      0045DF ED               [12] 1049 	mov	a,r5
      0045E0 B5 07 54         [24] 1050 	cjne	a,ar7,00116$
                                   1051 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      0045E3 12 46 F2         [24] 1052 	lcall	_ak820_outline_0148
                                   1053 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      0045E6 74 07            [12] 1054 	mov	a,#0x07
      0045E8 12 46 E4         [24] 1055 	lcall	_ak820_outline_0113
      0045EB AE 15            [24] 1056 	mov	r6,_ak820_tapping_process_sloc0_1_0
      0045ED 7F 00            [12] 1057 	mov	r7,#0x00
      0045EF 12 46 DE         [24] 1058 	lcall	_ak820_outline_0058
                                   1059 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      0045F2 C3               [12] 1060 	clr	c
      0045F3 04               [12] 1061 	inc	a
      0045F4 9E               [12] 1062 	subb	a,r6
      0045F5 50 66            [24] 1063 	jnc	00120$
                                   1064 ;	free result
                                   1065 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      0045F7 74 06            [12] 1066 	mov	a,#0x06
      0045F9 12 46 E4         [24] 1067 	lcall	_ak820_outline_0113
      0045FC E0               [24] 1068 	movx	a,@dptr
      0045FD 54 0F            [12] 1069 	anl	a,#0x0f
      0045FF 44 10            [12] 1070 	orl	a,#0x10
      004601 F0               [24] 1071 	movx	@dptr,a
                                   1072 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      004602 12 43 67         [24] 1073 	lcall	_ak820_outline_0142
      004605 74 01            [12] 1074 	mov	a,#0x01
      004607 F0               [24] 1075 	movx	@dptr,a
                                   1076 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      004608 8B 00            [24] 1077 	mov	ar0,r3
      00460A 8C 06            [24] 1078 	mov	ar6,r4
      00460C 7F 00            [12] 1079 	mov	r7,#0x00
      00460E 88 82            [24] 1080 	mov	dpl, r0
      004610 8E 83            [24] 1081 	mov	dph, r6
      004612 8F F0            [24] 1082 	mov	b, r7
      004614 C0 04            [24] 1083 	push	ar4
      004616 C0 03            [24] 1084 	push	ar3
      004618 C0 02            [24] 1085 	push	ar2
      00461A C0 01            [24] 1086 	push	ar1
      00461C 12 6E CF         [24] 1087 	lcall	_process_record
      00461F D0 01            [24] 1088 	pop	ar1
      004621 D0 02            [24] 1089 	pop	ar2
      004623 D0 03            [24] 1090 	pop	ar3
      004625 D0 04            [24] 1091 	pop	ar4
                                   1092 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      004627 12 43 67         [24] 1093 	lcall	_ak820_outline_0142
      00462A E4               [12] 1094 	clr	a
      00462B F0               [24] 1095 	movx	@dptr,a
                                   1096 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      00462C FF               [12] 1097 	mov	r7,a
      00462D 12 33 FC         [24] 1098 	lcall	_ak820_outline_0119
      004630 8F F0            [24] 1099 	mov	b, r7
      004632 12 6E CF         [24] 1100 	lcall	_process_record
      004635 80 26            [24] 1101 	sjmp	00120$
      004637                       1102 00116$:
                                   1103 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      004637 ED               [12] 1104 	mov	a,r5
      004638 24 9C            [12] 1105 	add	a, #_source_state
      00463A FE               [12] 1106 	mov	r6,a
      00463B E4               [12] 1107 	clr	a
      00463C 34 05            [12] 1108 	addc	a, #(_source_state >> 8)
      00463E FF               [12] 1109 	mov	r7,a
      00463F 12 38 8D         [24] 1110 	lcall	_ak820_outline_0112
      004642 E0               [24] 1111 	movx	a,@dptr
      004643 FD               [12] 1112 	mov	r5,a
      004644 30 E2 16         [24] 1113 	jnb	acc.2,00120$
                                   1114 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      004647 53 05 FB         [24] 1115 	anl	ar5,#0xfb
      00464A 12 38 8D         [24] 1116 	lcall	_ak820_outline_0112
      00464D ED               [12] 1117 	mov	a,r5
      00464E F0               [24] 1118 	movx	@dptr,a
                                   1119 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      00464F 90 06 24         [24] 1120 	mov	dptr,#_hold_PARM_2
      004652 E4               [12] 1121 	clr	a
      004653 F0               [24] 1122 	movx	@dptr,a
      004654 85 15 82         [24] 1123 	mov	dpl, _ak820_tapping_process_sloc0_1_0
      004657 85 16 83         [24] 1124 	mov	dph, (_ak820_tapping_process_sloc0_1_0 + 1)
      00465A 12 43 C1         [24] 1125 	lcall	_hold
      00465D                       1126 00120$:
                                   1127 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      00465D 75 82 00         [24] 1128 	mov	dpl, #0x00
                                   1129 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      004660 22               [24] 1130 	ret
                                   1131 ;------------------------------------------------------------
                                   1132 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1133 ;------------------------------------------------------------
                                   1134 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_634'
                                   1135 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_635'
                                   1136 ;------------------------------------------------------------
                                   1137 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1138 ;	-----------------------------------------
                                   1139 ;	 function ak820_tapping_cancel
                                   1140 ;	-----------------------------------------
      004661                       1141 _ak820_tapping_cancel:
                                   1142 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      004661 12 46 F2         [24] 1143 	lcall	_ak820_outline_0148
                                   1144 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004664 7F 00            [12] 1145 	mov	r7,#0x00
      004666                       1146 00103$:
      004666 BF 82 00         [24] 1147 	cjne	r7,#0x82,00122$
      004669                       1148 00122$:
      004669 50 1D            [24] 1149 	jnc	00105$
                                   1150 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      00466B EF               [12] 1151 	mov	a,r7
      00466C 24 9C            [12] 1152 	add	a, #_source_state
      00466E FD               [12] 1153 	mov	r5,a
      00466F E4               [12] 1154 	clr	a
      004670 34 05            [12] 1155 	addc	a, #(_source_state >> 8)
      004672 12 46 D6         [24] 1156 	lcall	_ak820_outline_0057
                                   1157 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004675 74 02            [12] 1158 	mov	a,#0x02
      004677 5C               [12] 1159 	anl	a,r4
      004678 FB               [12] 1160 	mov	r3,a
      004679 53 04 01         [24] 1161 	anl	ar4,#0x01
      00467C EC               [12] 1162 	mov	a,r4
      00467D 2C               [12] 1163 	add	a,r4
      00467E 42 03            [12] 1164 	orl	ar3,a
      004680 12 38 9C         [24] 1165 	lcall	_ak820_outline_0129
      004683 EB               [12] 1166 	mov	a,r3
      004684 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004685 0F               [12] 1169 	inc	r7
      004686 80 DE            [24] 1170 	sjmp	00103$
      004688                       1171 00105$:
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      004688 22               [24] 1173 	ret
                                   1174 	.area CSEG    (CODE)
                                   1175 	.area CONST   (CODE)
                                   1176 	.area XINIT   (CODE)
      00BD42                       1177 __xinit__pending:
      00BD42 FF                    1178 	.db #0xff	; 255
                                   1179 	.area CABS    (ABS,CODE)
                                   1180 
                                   1181 ; Experimental exact instruction outlining.
                                   1182 	.globl _ak820_outline_0008
                                   1183 	.globl _ak820_outline_0010
                                   1184 	.globl _ak820_outline_0013
                                   1185 	.globl _ak820_outline_0014
                                   1186 	.globl _ak820_outline_0017
                                   1187 	.globl _ak820_outline_0021
                                   1188 	.globl _ak820_outline_0022
                                   1189 	.globl _ak820_outline_0030
                                   1190 	.globl _ak820_outline_0031
                                   1191 	.globl _ak820_outline_0035
                                   1192 	.globl _ak820_outline_0051
                                   1193 	.globl _ak820_outline_0055
                                   1194 	.globl _ak820_outline_0057
                                   1195 	.globl _ak820_outline_0058
                                   1196 	.globl _ak820_outline_0071
                                   1197 	.globl _ak820_outline_0089
                                   1198 	.globl _ak820_outline_0097
                                   1199 	.globl _ak820_outline_0099
                                   1200 	.globl _ak820_outline_0103
                                   1201 	.globl _ak820_outline_0104
                                   1202 	.globl _ak820_outline_0112
                                   1203 	.globl _ak820_outline_0113
                                   1204 	.globl _ak820_outline_0116
                                   1205 	.globl _ak820_outline_0118
                                   1206 	.globl _ak820_outline_0119
                                   1207 	.globl _ak820_outline_0120
                                   1208 	.globl _ak820_outline_0129
                                   1209 	.globl _ak820_outline_0142
                                   1210 	.globl _ak820_outline_0148
                                   1211 	.globl _ak820_outline_0152
                                   1212 	.globl _ak820_outline_0184
                                   1213 
                                   1214 	.area CSEG (CODE)
                                   1215 ; function ak820_outline_0008
      004689                       1216 _ak820_outline_0008:
      004689 E0               [24] 1217 	movx	a,@dptr
      00468A FE               [12] 1218 	mov	r6,a
      00468B A3               [24] 1219 	inc	dptr
      00468C E0               [24] 1220 	movx	a,@dptr
      00468D FF               [12] 1221 	mov	r7,a
      00468E 8E 04            [24] 1222 	mov	ar4,r6
      004690 8F 05            [24] 1223 	mov	ar5,r7
      004692 22               [24] 1224 	ret
                                   1225 
                                   1226 	.area CSEG (CODE)
                                   1227 ; function ak820_outline_0017
      004693                       1228 _ak820_outline_0017:
      004693 2E               [12] 1229 	add	a,r6
      004694 FB               [12] 1230 	mov	r3,a
      004695 E4               [12] 1231 	clr	a
      004696 3F               [12] 1232 	addc	a,r7
      004697 FC               [12] 1233 	mov	r4,a
      004698 8B 82            [24] 1234 	mov	dpl,r3
      00469A 8C 83            [24] 1235 	mov	dph,r4
      00469C E0               [24] 1236 	movx	a,@dptr
      00469D 22               [24] 1237 	ret
                                   1238 
                                   1239 	.area CSEG (CODE)
                                   1240 ; function ak820_outline_0022
      00469E                       1241 _ak820_outline_0022:
      00469E 90 0D 8C         [24] 1242 	mov	dptr,#___memcpy_PARM_2
      0046A1 EC               [12] 1243 	mov	a,r4
      0046A2 F0               [24] 1244 	movx	@dptr,a
      0046A3 ED               [12] 1245 	mov	a,r5
      0046A4 A3               [24] 1246 	inc	dptr
      0046A5 F0               [24] 1247 	movx	@dptr,a
      0046A6 E4               [12] 1248 	clr	a
      0046A7 A3               [24] 1249 	inc	dptr
      0046A8 F0               [24] 1250 	movx	@dptr,a
      0046A9 90 0D 8F         [24] 1251 	mov	dptr,#___memcpy_PARM_3
      0046AC 74 02            [12] 1252 	mov	a,#0x02
      0046AE F0               [24] 1253 	movx	@dptr,a
      0046AF E4               [12] 1254 	clr	a
      0046B0 A3               [24] 1255 	inc	dptr
      0046B1 F0               [24] 1256 	movx	@dptr,a
      0046B2 90 06 22         [24] 1257 	mov	dptr,#_source_PARM_1
      0046B5 F5 F0            [12] 1258 	mov	b,a
      0046B7 22               [24] 1259 	ret
                                   1260 
                                   1261 	.area CSEG (CODE)
                                   1262 ; function ak820_outline_0030
      0046B8                       1263 _ak820_outline_0030:
      0046B8 2E               [12] 1264 	add	a,r6
      0046B9 FA               [12] 1265 	mov	r2,a
      0046BA E4               [12] 1266 	clr	a
      0046BB 3F               [12] 1267 	addc	a,r7
      0046BC FB               [12] 1268 	mov	r3,a
      0046BD 8A 82            [24] 1269 	mov	dpl,r2
      0046BF 8B 83            [24] 1270 	mov	dph,r3
      0046C1 E0               [24] 1271 	movx	a,@dptr
      0046C2 22               [24] 1272 	ret
                                   1273 
                                   1274 	.area CSEG (CODE)
                                   1275 ; function ak820_outline_0031
      0046C3                       1276 _ak820_outline_0031:
      0046C3 2E               [12] 1277 	add	a,r6
      0046C4 FC               [12] 1278 	mov	r4,a
      0046C5 E4               [12] 1279 	clr	a
      0046C6 3F               [12] 1280 	addc	a,r7
      0046C7 FD               [12] 1281 	mov	r5,a
      0046C8 8C 82            [24] 1282 	mov	dpl,r4
      0046CA 8D 83            [24] 1283 	mov	dph,r5
      0046CC E0               [24] 1284 	movx	a,@dptr
      0046CD 22               [24] 1285 	ret
                                   1286 
                                   1287 	.area CSEG (CODE)
                                   1288 ; function ak820_outline_0055
      0046CE                       1289 _ak820_outline_0055:
      0046CE FC               [12] 1290 	mov	r4,a
      0046CF 8B 82            [24] 1291 	mov	dpl,r3
      0046D1 8C 83            [24] 1292 	mov	dph,r4
      0046D3 E0               [24] 1293 	movx	a,@dptr
      0046D4 FA               [12] 1294 	mov	r2,a
      0046D5 22               [24] 1295 	ret
                                   1296 
                                   1297 	.area CSEG (CODE)
                                   1298 ; function ak820_outline_0057
      0046D6                       1299 _ak820_outline_0057:
      0046D6 FE               [12] 1300 	mov	r6,a
      0046D7 8D 82            [24] 1301 	mov	dpl,r5
      0046D9 8E 83            [24] 1302 	mov	dph,r6
      0046DB E0               [24] 1303 	movx	a,@dptr
      0046DC FC               [12] 1304 	mov	r4,a
      0046DD 22               [24] 1305 	ret
                                   1306 
                                   1307 	.area CSEG (CODE)
                                   1308 ; function ak820_outline_0058
      0046DE                       1309 _ak820_outline_0058:
      0046DE EE               [12] 1310 	mov	a,r6
      0046DF F0               [24] 1311 	movx	@dptr,a
      0046E0 EF               [12] 1312 	mov	a,r7
      0046E1 A3               [24] 1313 	inc	dptr
      0046E2 F0               [24] 1314 	movx	@dptr,a
      0046E3 22               [24] 1315 	ret
                                   1316 
                                   1317 	.area CSEG (CODE)
                                   1318 ; function ak820_outline_0113
      0046E4                       1319 _ak820_outline_0113:
      0046E4 2B               [12] 1320 	add	a,r3
      0046E5 F5 82            [12] 1321 	mov	dpl,a
      0046E7 E4               [12] 1322 	clr	a
      0046E8 3C               [12] 1323 	addc	a,r4
      0046E9 F5 83            [12] 1324 	mov	dph,a
      0046EB 22               [24] 1325 	ret
                                   1326 
                                   1327 	.area CSEG (CODE)
                                   1328 ; function ak820_outline_0118
      0046EC                       1329 _ak820_outline_0118:
      0046EC F0               [24] 1330 	movx	@dptr,a
      0046ED 8B 82            [24] 1331 	mov	dpl,r3
      0046EF 8C 83            [24] 1332 	mov	dph,r4
      0046F1 22               [24] 1333 	ret
                                   1334 
                                   1335 	.area CSEG (CODE)
                                   1336 ; function ak820_outline_0148
      0046F2                       1337 _ak820_outline_0148:
      0046F2 90 0D 9C         [24] 1338 	mov	dptr,#_pending
      0046F5 74 FF            [12] 1339 	mov	a,#0xff
      0046F7 F0               [24] 1340 	movx	@dptr,a
      0046F8 22               [24] 1341 	ret
