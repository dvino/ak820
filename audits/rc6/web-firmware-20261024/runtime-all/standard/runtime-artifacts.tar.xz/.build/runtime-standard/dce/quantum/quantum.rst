                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _post_process_record_user_PARM_2
                                    282 	.globl _post_process_record_kb_PARM_2
                                    283 	.globl _process_record_user_PARM_2
                                    284 	.globl _process_record_kb_PARM_2
                                    285 	.globl _pre_process_record_user_PARM_2
                                    286 	.globl _pre_process_record_kb_PARM_2
                                    287 	.globl _register_code16
                                    288 	.globl _unregister_code16
                                    289 	.globl _pre_process_record_kb
                                    290 	.globl _pre_process_record_user
                                    291 	.globl _process_action_kb
                                    292 	.globl _process_record_kb
                                    293 	.globl _process_record_user
                                    294 	.globl _post_process_record_kb
                                    295 	.globl _post_process_record_user
                                    296 	.globl _reset_keyboard
                                    297 	.globl _soft_reset_keyboard
                                    298 	.globl _get_record_keycode
                                    299 	.globl _pre_process_record_quantum
                                    300 	.globl _post_process_record_quantum
                                    301 	.globl _process_record_quantum
                                    302 	.globl _process_record_quantum_helper
                                    303 	.globl _shutdown_user
                                    304 ;--------------------------------------------------------
                                    305 ; special function registers
                                    306 ;--------------------------------------------------------
                                    307 	.area RSEG    (ABS,DATA)
      000000                        308 	.org 0x0000
                           0000D0   309 _PSW	=	0x00d0
                           0000E0   310 _ACC	=	0x00e0
                           0000F0   311 _B	=	0x00f0
                           0000FD   312 _A_INV	=	0x00fd
                           000081   313 _SP	=	0x0081
                           000082   314 _DPL	=	0x0082
                           000083   315 _DPH	=	0x0083
                           0000A1   316 _SAFE_MOD	=	0x00a1
                           0000B1   317 _GLOBAL_CFG	=	0x00b1
                           000087   318 _PCON	=	0x0087
                           0000BA   319 _POWER_CFG	=	0x00ba
                           0000B9   320 _CLOCK_CFG	=	0x00b9
                           0000A9   321 _WAKE_CTRL	=	0x00a9
                           0000FE   322 _RESET_KEEP	=	0x00fe
                           0000FF   323 _WDOG_COUNT	=	0x00ff
                           0000A8   324 _IE	=	0x00a8
                           0000B8   325 _IP	=	0x00b8
                           0000E8   326 _IE_EX	=	0x00e8
                           0000E9   327 _IP_EX	=	0x00e9
                           0000B2   328 _GPIO_IE	=	0x00b2
                           008584   329 _ROM_ADDR	=	0x8584
                           000084   330 _ROM_ADDR_L	=	0x0084
                           000085   331 _ROM_ADDR_H	=	0x0085
                           008F8E   332 _ROM_DATA_HI	=	0x8f8e
                           00008E   333 _ROM_DATA_HL	=	0x008e
                           00008F   334 _ROM_DATA_HH	=	0x008f
                           000086   335 _ROM_CTRL	=	0x0086
                           000080   336 _P0	=	0x0080
                           0000C4   337 _P0_MOD_OC	=	0x00c4
                           0000C5   338 _P0_DIR_PU	=	0x00c5
                           000090   339 _P1	=	0x0090
                           000092   340 _P1_MOD_OC	=	0x0092
                           000093   341 _P1_DIR_PU	=	0x0093
                           0000A0   342 _P2	=	0x00a0
                           000094   343 _P2_MOD_OC	=	0x0094
                           000095   344 _P2_DIR_PU	=	0x0095
                           0000B0   345 _P3	=	0x00b0
                           000096   346 _P3_MOD_OC	=	0x0096
                           000097   347 _P3_DIR_PU	=	0x0097
                           0000C0   348 _P4	=	0x00c0
                           0000C2   349 _P4_MOD_OC	=	0x00c2
                           0000C3   350 _P4_DIR_PU	=	0x00c3
                           0000C1   351 _P4_LED_KEY	=	0x00c1
                           0000AA   352 _P5_IN	=	0x00aa
                           0000AB   353 _P5_OUT_PU	=	0x00ab
                           0000AC   354 _P5_DIR	=	0x00ac
                           0000AD   355 _P6_IN	=	0x00ad
                           0000AE   356 _P6_OUT_PU	=	0x00ae
                           0000AF   357 _P6_DIR	=	0x00af
                           0000F1   358 _P7	=	0x00f1
                           0000A2   359 _XBUS_AUX	=	0x00a2
                           000088   360 _TCON	=	0x0088
                           000089   361 _TMOD	=	0x0089
                           00008A   362 _TL0	=	0x008a
                           00008B   363 _TL1	=	0x008b
                           00008C   364 _TH0	=	0x008c
                           00008D   365 _TH1	=	0x008d
                           000098   366 _SCON	=	0x0098
                           000099   367 _SBUF	=	0x0099
                           0000C8   368 _T2CON	=	0x00c8
                           0000C9   369 _T2MOD	=	0x00c9
                           00CBCA   370 _RCAP2	=	0xcbca
                           0000CA   371 _RCAP2L	=	0x00ca
                           0000CB   372 _RCAP2H	=	0x00cb
                           00CDCC   373 _T2COUNT	=	0xcdcc
                           0000CC   374 _TL2	=	0x00cc
                           0000CD   375 _TH2	=	0x00cd
                           00CFCE   376 _T2CAP1	=	0xcfce
                           0000CE   377 _T2CAP1L	=	0x00ce
                           0000CF   378 _T2CAP1H	=	0x00cf
                           0000F8   379 _SPI0_STAT	=	0x00f8
                           0000F9   380 _SPI0_DATA	=	0x00f9
                           0000FA   381 _SPI0_CTRL	=	0x00fa
                           0000FB   382 _SPI0_CK_SE	=	0x00fb
                           0000FC   383 _SPI0_SETUP	=	0x00fc
                           0000BC   384 _SCON1	=	0x00bc
                           0000BD   385 _SBUF1	=	0x00bd
                           0000BE   386 _SBAUD1	=	0x00be
                           0000BF   387 _SIF1	=	0x00bf
                           0000B4   388 _SPI1_STAT	=	0x00b4
                           0000B5   389 _SPI1_DATA	=	0x00b5
                           0000B6   390 _SPI1_CTRL	=	0x00b6
                           0000B7   391 _SPI1_CK_SE	=	0x00b7
                           0000F3   392 _ADC_CTRL	=	0x00f3
                           00F5F4   393 _ADC_DAT	=	0xf5f4
                           0000F4   394 _ADC_DAT_L	=	0x00f4
                           0000F5   395 _ADC_DAT_H	=	0x00f5
                           0000F6   396 _ADC_CHAN	=	0x00f6
                           0000A6   397 _LED_COMMON	=	0x00a6
                           0000A7   398 _LED_PWM_OE	=	0x00a7
                           00C7C6   399 _LED_DMA	=	0xc7c6
                           0000C6   400 _LED_DMA_L	=	0x00c6
                           0000C7   401 _LED_DMA_H	=	0x00c7
                           0000F7   402 _LED_STATUS	=	0x00f7
                           0000B3   403 _I2CX_INT	=	0x00b3
                           0000BB   404 _I2CS_INT_ST	=	0x00bb
                                    405 ;--------------------------------------------------------
                                    406 ; special function bits
                                    407 ;--------------------------------------------------------
                                    408 	.area RSEG    (ABS,DATA)
      000000                        409 	.org 0x0000
                           0000D7   410 _CY	=	0x00d7
                           0000D6   411 _AC	=	0x00d6
                           0000D5   412 _F0	=	0x00d5
                           0000D4   413 _RS1	=	0x00d4
                           0000D3   414 _RS0	=	0x00d3
                           0000D2   415 _OV	=	0x00d2
                           0000D1   416 _F1	=	0x00d1
                           0000D0   417 _P	=	0x00d0
                           0000AF   418 _EA	=	0x00af
                           0000AE   419 _E_DIS	=	0x00ae
                           0000AD   420 _ET2	=	0x00ad
                           0000AC   421 _ES	=	0x00ac
                           0000AB   422 _ET1	=	0x00ab
                           0000AA   423 _EX1	=	0x00aa
                           0000A9   424 _ET0	=	0x00a9
                           0000A8   425 _EX0	=	0x00a8
                           0000BF   426 _PH_FLAG	=	0x00bf
                           0000BE   427 _PL_FLAG	=	0x00be
                           0000BD   428 _PT2	=	0x00bd
                           0000BC   429 _PS	=	0x00bc
                           0000BB   430 _PT1	=	0x00bb
                           0000BA   431 _PX1	=	0x00ba
                           0000B9   432 _PT0	=	0x00b9
                           0000B8   433 _PX0	=	0x00b8
                           0000EF   434 _IE_WDOG	=	0x00ef
                           0000EE   435 _IE_GPIO	=	0x00ee
                           0000ED   436 _IE_PWM_I2C	=	0x00ed
                           0000EC   437 _IE_UART1	=	0x00ec
                           0000EB   438 _IE_ADC	=	0x00eb
                           0000E9   439 _IE_USB	=	0x00e9
                           0000E8   440 _IE_SPI0	=	0x00e8
                           000087   441 _P0_7	=	0x0087
                           000086   442 _P0_6	=	0x0086
                           000085   443 _P0_5	=	0x0085
                           000084   444 _P0_4	=	0x0084
                           000083   445 _P0_3	=	0x0083
                           000082   446 _P0_2	=	0x0082
                           000081   447 _P0_1	=	0x0081
                           000080   448 _P0_0	=	0x0080
                           000081   449 _SDA0	=	0x0081
                           000080   450 _SCL0	=	0x0080
                           000083   451 _TXD_	=	0x0083
                           000082   452 _RXD_	=	0x0082
                           000085   453 _AIN13	=	0x0085
                           000084   454 _AIN12	=	0x0084
                           000083   455 _AIN11	=	0x0083
                           000082   456 _AIN10	=	0x0082
                           000081   457 _AIN9	=	0x0081
                           000080   458 _AIN8	=	0x0080
                           000097   459 _P1_7	=	0x0097
                           000096   460 _P1_6	=	0x0096
                           000095   461 _P1_5	=	0x0095
                           000094   462 _P1_4	=	0x0094
                           000093   463 _P1_3	=	0x0093
                           000092   464 _P1_2	=	0x0092
                           000091   465 _P1_1	=	0x0091
                           000090   466 _P1_0	=	0x0090
                           000097   467 _TXD1_	=	0x0097
                           000096   468 _RXD1_	=	0x0096
                           000097   469 _SCK	=	0x0097
                           000096   470 _MISO	=	0x0096
                           000095   471 _MOSI	=	0x0095
                           000094   472 _SCS	=	0x0094
                           000092   473 _INT0_	=	0x0092
                           000091   474 _T2EX	=	0x0091
                           000091   475 _CAP2	=	0x0091
                           000090   476 _T2	=	0x0090
                           000090   477 _CAP1	=	0x0090
                           000097   478 _AIN7	=	0x0097
                           000096   479 _AIN6	=	0x0096
                           000095   480 _AIN5	=	0x0095
                           000094   481 _AIN4	=	0x0094
                           000093   482 _AIN3	=	0x0093
                           000092   483 _AIN2	=	0x0092
                           000091   484 _AIN1	=	0x0091
                           000090   485 _AIN0	=	0x0090
                           0000A7   486 _P2_7	=	0x00a7
                           0000A6   487 _P2_6	=	0x00a6
                           0000A5   488 _P2_5	=	0x00a5
                           0000A4   489 _P2_4	=	0x00a4
                           0000A3   490 _P2_3	=	0x00a3
                           0000A2   491 _P2_2	=	0x00a2
                           0000A1   492 _P2_1	=	0x00a1
                           0000A0   493 _P2_0	=	0x00a0
                           0000A7   494 _TXD1	=	0x00a7
                           0000A6   495 _RXD1	=	0x00a6
                           0000A5   496 _T2EX_	=	0x00a5
                           0000A5   497 _CAP2_	=	0x00a5
                           0000A4   498 _T2_	=	0x00a4
                           0000A4   499 _CAP1_	=	0x00a4
                           0000B7   500 _P3_7	=	0x00b7
                           0000B6   501 _P3_6	=	0x00b6
                           0000B5   502 _P3_5	=	0x00b5
                           0000B4   503 _P3_4	=	0x00b4
                           0000B3   504 _P3_3	=	0x00b3
                           0000B2   505 _P3_2	=	0x00b2
                           0000B1   506 _P3_1	=	0x00b1
                           0000B0   507 _P3_0	=	0x00b0
                           0000B7   508 _SCK1	=	0x00b7
                           0000B6   509 _MISO1	=	0x00b6
                           0000B5   510 _MOSI1	=	0x00b5
                           0000B5   511 _T1	=	0x00b5
                           0000B4   512 _T0	=	0x00b4
                           0000B3   513 _INT1	=	0x00b3
                           0000B2   514 _INT0	=	0x00b2
                           0000B1   515 _TXD	=	0x00b1
                           0000B0   516 _RXD	=	0x00b0
                           0000C6   517 _P4_6	=	0x00c6
                           0000C5   518 _P4_5	=	0x00c5
                           0000C4   519 _P4_4	=	0x00c4
                           0000C3   520 _P4_3	=	0x00c3
                           0000C2   521 _P4_2	=	0x00c2
                           0000C1   522 _P4_1	=	0x00c1
                           0000C0   523 _P4_0	=	0x00c0
                           00008F   524 _TF1	=	0x008f
                           00008E   525 _TR1	=	0x008e
                           00008D   526 _TF0	=	0x008d
                           00008C   527 _TR0	=	0x008c
                           00008B   528 _IE1	=	0x008b
                           00008A   529 _IT1	=	0x008a
                           000089   530 _IE0	=	0x0089
                           000088   531 _IT0	=	0x0088
                           00009F   532 _SM0	=	0x009f
                           00009E   533 _SM1	=	0x009e
                           00009D   534 _SM2	=	0x009d
                           00009C   535 _REN	=	0x009c
                           00009B   536 _TB8	=	0x009b
                           00009A   537 _RB8	=	0x009a
                           000099   538 _TI	=	0x0099
                           000098   539 _RI	=	0x0098
                           0000CF   540 _TF2	=	0x00cf
                           0000CF   541 _CAP1F	=	0x00cf
                           0000CE   542 _EXF2	=	0x00ce
                           0000CD   543 _RCLK	=	0x00cd
                           0000CC   544 _TCLK	=	0x00cc
                           0000CB   545 _EXEN2	=	0x00cb
                           0000CA   546 _TR2	=	0x00ca
                           0000C9   547 _C_T2	=	0x00c9
                           0000C8   548 _CP_RL2	=	0x00c8
                           0000FF   549 _S0_FST_ACT	=	0x00ff
                           0000FE   550 _S0_IF_OV	=	0x00fe
                           0000FD   551 _S0_IF_FIRST	=	0x00fd
                           0000FC   552 _S0_IF_BYTE	=	0x00fc
                           0000FB   553 _S0_FREE	=	0x00fb
                           0000FA   554 _S0_T_FIFO	=	0x00fa
                           0000F8   555 _S0_R_FIFO	=	0x00f8
                           0000F7   556 _ADC_START	=	0x00f7
                                    557 ;--------------------------------------------------------
                                    558 ; overlayable register banks
                                    559 ;--------------------------------------------------------
                                    560 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        561 	.ds 8
                                    562 ;--------------------------------------------------------
                                    563 ; internal ram data
                                    564 ;--------------------------------------------------------
                                    565 	.area DSEG    (DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; overlayable items in internal ram
                                    568 ;--------------------------------------------------------
                                    569 ;--------------------------------------------------------
                                    570 ; indirectly addressable internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area ISEG    (DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; absolute internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area IABS    (ABS,DATA)
                                    577 	.area IABS    (ABS,DATA)
                                    578 ;--------------------------------------------------------
                                    579 ; bit data
                                    580 ;--------------------------------------------------------
                                    581 	.area BSEG    (BIT)
      000025                        582 _get_record_keycode_sloc0_1_0:
      000025                        583 	.ds 1
      000026                        584 _pre_process_record_quantum_sloc0_1_0:
      000026                        585 	.ds 1
                                    586 ;--------------------------------------------------------
                                    587 ; paged external ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area PSEG    (PAG,XDATA)
                                    590 ;--------------------------------------------------------
                                    591 ; uninitialized external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area XSEG    (XDATA)
      000BCA                        594 _extract_mod_bits_code_10000_599:
      000BCA                        595 	.ds 2
      000BCC                        596 _register_code16_code_10000_605:
      000BCC                        597 	.ds 2
      000BCE                        598 _unregister_code16_code_10000_610:
      000BCE                        599 	.ds 2
      000BD0                        600 _pre_process_record_kb_PARM_2:
      000BD0                        601 	.ds 3
      000BD3                        602 _pre_process_record_kb_keycode_10000_624:
      000BD3                        603 	.ds 2
      000BD5                        604 _pre_process_record_user_PARM_2:
      000BD5                        605 	.ds 3
      000BD8                        606 _process_record_kb_PARM_2:
      000BD8                        607 	.ds 3
      000BDB                        608 _process_record_kb_keycode_10000_630:
      000BDB                        609 	.ds 2
      000BDD                        610 _process_record_user_PARM_2:
      000BDD                        611 	.ds 3
      000BE0                        612 _post_process_record_kb_PARM_2:
      000BE0                        613 	.ds 3
      000BE3                        614 _post_process_record_kb_keycode_10000_634:
      000BE3                        615 	.ds 2
      000BE5                        616 _post_process_record_user_PARM_2:
      000BE5                        617 	.ds 3
      000BE8                        618 _get_record_keycode_PARM_2:
      000BE8                        619 	.ds 1
      000BE9                        620 _get_record_keycode_record_argument_10000_648:
      000BE9                        621 	.ds 3
      000BEC                        622 _pre_process_record_quantum_record_argument_10000_654:
      000BEC                        623 	.ds 3
      000BEF                        624 _post_process_record_quantum_record_10000_656:
      000BEF                        625 	.ds 3
      000BF2                        626 _process_record_quantum_record_10000_658:
      000BF2                        627 	.ds 3
      000BF5                        628 _process_record_quantum_helper_PARM_2:
      000BF5                        629 	.ds 3
      000BF8                        630 _process_record_quantum_helper_keycode_10000_660:
      000BF8                        631 	.ds 2
      000BFA                        632 _get_u8_str_last_num_10000_686:
      000BFA                        633 	.ds 1
      000BFB                        634 _get_u16_str_last_num_10000_690:
      000BFB                        635 	.ds 2
                                    636 ;--------------------------------------------------------
                                    637 ; absolute external ram data
                                    638 ;--------------------------------------------------------
                                    639 	.area XABS    (ABS,XDATA)
                                    640 ;--------------------------------------------------------
                                    641 ; initialized external ram data
                                    642 ;--------------------------------------------------------
                                    643 	.area XISEG   (XDATA)
                                    644 	.area HOME    (CODE)
                                    645 	.area GSINIT0 (CODE)
                                    646 	.area GSINIT1 (CODE)
                                    647 	.area GSINIT2 (CODE)
                                    648 	.area GSINIT3 (CODE)
                                    649 	.area GSINIT4 (CODE)
                                    650 	.area GSINIT5 (CODE)
                                    651 	.area GSINIT  (CODE)
                                    652 	.area GSFINAL (CODE)
                                    653 	.area CSEG    (CODE)
                                    654 ;--------------------------------------------------------
                                    655 ; global & static initialisations
                                    656 ;--------------------------------------------------------
                                    657 	.area HOME    (CODE)
                                    658 	.area GSINIT  (CODE)
                                    659 	.area GSFINAL (CODE)
                                    660 	.area GSINIT  (CODE)
                                    661 ;------------------------------------------------------------
                                    662 ;Allocation info for local variables in function 'get_u8_str'
                                    663 ;------------------------------------------------------------
                                    664 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    665 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_685'
                                    666 ;buf           Allocated with name '_get_u8_str_buf_10000_686'
                                    667 ;last_num      Allocated with name '_get_u8_str_last_num_10000_686'
                                    668 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_686'
                                    669 ;------------------------------------------------------------
                                    670 ;	quantum/quantum.c:750: static uint8_t last_num = 0xFF;
      0030F3 90 0B FA         [24]  671 	mov	dptr,#_get_u8_str_last_num_10000_686
      0030F6 74 FF            [12]  672 	mov	a,#0xff
      0030F8 F0               [24]  673 	movx	@dptr,a
                                    674 ;------------------------------------------------------------
                                    675 ;Allocation info for local variables in function 'get_u16_str'
                                    676 ;------------------------------------------------------------
                                    677 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    678 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_689'
                                    679 ;buf           Allocated with name '_get_u16_str_buf_10000_690'
                                    680 ;last_num      Allocated with name '_get_u16_str_last_num_10000_690'
                                    681 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_690'
                                    682 ;------------------------------------------------------------
                                    683 ;	quantum/quantum.c:770: static uint16_t last_num = 0xFF;
      0030F9 90 0B FB         [24]  684 	mov	dptr,#_get_u16_str_last_num_10000_690
      0030FC 74 FF            [12]  685 	mov	a,#0xff
      0030FE F0               [24]  686 	movx	@dptr,a
      0030FF E4               [12]  687 	clr	a
      003100 A3               [24]  688 	inc	dptr
      003101 F0               [24]  689 	movx	@dptr,a
                                    690 ;--------------------------------------------------------
                                    691 ; Home
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area HOME    (CODE)
                                    695 ;--------------------------------------------------------
                                    696 ; code
                                    697 ;--------------------------------------------------------
                                    698 	.area CSEG    (CODE)
                                    699 ;------------------------------------------------------------
                                    700 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    701 ;------------------------------------------------------------
                                    702 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    703 ;------------------------------------------------------------
                                    704 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    705 ;	-----------------------------------------
                           000007   706 	ar7 = 0x07
                           000006   707 	ar6 = 0x06
                           000005   708 	ar5 = 0x05
                           000004   709 	ar4 = 0x04
                           000003   710 	ar3 = 0x03
                           000002   711 	ar2 = 0x02
                           000001   712 	ar1 = 0x01
                           000000   713 	ar0 = 0x00
                                    714 ;	 function extract_mod_bits
                                    715 ;	-----------------------------------------
      009A2F                        716 _extract_mod_bits:
      009A2F 12 38 88         [24]  717 	lcall	_ak820_outline_0104
      009A32 90 0B CA         [24]  718 	mov	dptr,#_extract_mod_bits_code_10000_599
      009A35 12 38 83         [24]  719 	lcall	_ak820_outline_0103
                                    720 ;	quantum/quantum.c:107: uint8_t mods = (uint8_t)(code >> 8);
      009A38 90 0B CA         [24]  721 	mov	dptr,#_extract_mod_bits_code_10000_599
      009A3B E0               [24]  722 	movx	a,@dptr
      009A3C A3               [24]  723 	inc	dptr
      009A3D E0               [24]  724 	movx	a,@dptr
                                    725 ;	quantum/quantum.c:108: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009A3E FF               [12]  726 	mov	r7,a
      009A3F 60 05            [24]  727 	jz	00101$
      009A41 EF               [12]  728 	mov	a,r7
      009A42 24 E0            [12]  729 	add	a,#0xff - 0x1f
      009A44 50 04            [24]  730 	jnc	00102$
                                    731 ;	free result
      009A46                        732 00101$:
      009A46 75 82 00         [24]  733 	mov	dpl, #0x00
      009A49 22               [24]  734 	ret
      009A4A                        735 00102$:
                                    736 ;	quantum/quantum.c:109: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009A4A EF               [12]  737 	mov	a,r7
      009A4B 30 E4 07         [24]  738 	jnb	acc.4,00106$
      009A4E EF               [12]  739 	mov	a,r7
      009A4F C4               [12]  740 	swap	a
      009A50 54 F0            [12]  741 	anl	a,#0xf0
      009A52 FE               [12]  742 	mov	r6,a
      009A53 80 02            [24]  743 	sjmp	00107$
      009A55                        744 00106$:
      009A55 8F 06            [24]  745 	mov	ar6,r7
      009A57                        746 00107$:
      009A57 8E 82            [24]  747 	mov	dpl, r6
                                    748 ;	quantum/quantum.c:137: }
      009A59 22               [24]  749 	ret
                                    750 ;------------------------------------------------------------
                                    751 ;Allocation info for local variables in function 'do_code16'
                                    752 ;------------------------------------------------------------
                                    753 ;f             Allocated with name '_do_code16_PARM_2'
                                    754 ;code          Allocated with name '_do_code16_code_10000_602'
                                    755 ;------------------------------------------------------------
                                    756 ;	quantum/quantum.c:139: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    757 ;	-----------------------------------------
                                    758 ;	 function register_code16
                                    759 ;	-----------------------------------------
      009A5A                        760 _register_code16:
      009A5A 12 38 88         [24]  761 	lcall	_ak820_outline_0104
      009A5D 90 0B CC         [24]  762 	mov	dptr,#_register_code16_code_10000_605
      009A60 12 38 83         [24]  763 	lcall	_ak820_outline_0103
                                    764 ;	quantum/quantum.c:145: uint8_t mods = extract_mod_bits(code);
      009A63 90 0B CC         [24]  765 	mov	dptr,#_register_code16_code_10000_605
      009A66 12 37 F5         [24]  766 	lcall	_ak820_outline_0005
      009A69 C0 07            [24]  767 	push	ar7
      009A6B C0 06            [24]  768 	push	ar6
      009A6D 12 9A 2F         [24]  769 	lcall	_extract_mod_bits
      009A70 AD 82            [24]  770 	mov	r5, dpl
      009A72 D0 06            [24]  771 	pop	ar6
      009A74 D0 07            [24]  772 	pop	ar7
                                    773 ;	quantum/quantum.c:146: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009A76 12 98 68         [24]  774 	lcall	_ak820_outline_0114
      009A79 40 07            [24]  775 	jc	00105$
      009A7B 74 E7            [12]  776 	mov	a,#0xe7
      009A7D 9E               [12]  777 	subb	a,r6
      009A7E E4               [12]  778 	clr	a
      009A7F 9F               [12]  779 	subb	a,r7
      009A80 50 08            [24]  780 	jnc	00101$
                                    781 ;	free result
      009A82                        782 00105$:
      009A82 90 0B CC         [24]  783 	mov	dptr,#_register_code16_code_10000_605
      009A85 12 6B 89         [24]  784 	lcall	_ak820_outline_0039
      009A88 70 07            [24]  785 	jnz	00102$
      009A8A                        786 00101$:
                                    787 ;	quantum/quantum.c:147: register_mods(mods);
      009A8A 8D 82            [24]  788 	mov	dpl, r5
      009A8C 12 73 6F         [24]  789 	lcall	_register_mods
      009A8F 80 05            [24]  790 	sjmp	00103$
      009A91                        791 00102$:
                                    792 ;	quantum/quantum.c:149: register_weak_mods(mods);
      009A91 8D 82            [24]  793 	mov	dpl, r5
      009A93 12 73 97         [24]  794 	lcall	_register_weak_mods
      009A96                        795 00103$:
                                    796 ;	quantum/quantum.c:151: register_code(code);
      009A96 90 0B CC         [24]  797 	mov	dptr,#_register_code16_code_10000_605
      009A99 E0               [24]  798 	movx	a,@dptr
      009A9A F5 82            [12]  799 	mov	dpl,a
                                    800 ;	quantum/quantum.c:161: }
      009A9C 02 72 4C         [24]  801 	ljmp	_register_code
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'unregister_code16'
                                    804 ;------------------------------------------------------------
                                    805 ;code          Allocated with name '_unregister_code16_code_10000_610'
                                    806 ;mods          Allocated with name '_unregister_code16_mods_10000_611'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/quantum.c:163: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    809 ;	-----------------------------------------
                                    810 ;	 function unregister_code16
                                    811 ;	-----------------------------------------
      009A9F                        812 _unregister_code16:
      009A9F 12 38 88         [24]  813 	lcall	_ak820_outline_0104
      009AA2 90 0B CE         [24]  814 	mov	dptr,#_unregister_code16_code_10000_610
      009AA5 12 38 83         [24]  815 	lcall	_ak820_outline_0103
                                    816 ;	quantum/quantum.c:165: uint8_t mods = extract_mod_bits(code);
      009AA8 90 0B CE         [24]  817 	mov	dptr,#_unregister_code16_code_10000_610
      009AAB 12 37 F5         [24]  818 	lcall	_ak820_outline_0005
      009AAE C0 07            [24]  819 	push	ar7
      009AB0 C0 06            [24]  820 	push	ar6
      009AB2 12 9A 2F         [24]  821 	lcall	_extract_mod_bits
      009AB5 AD 82            [24]  822 	mov	r5, dpl
      009AB7 D0 06            [24]  823 	pop	ar6
                                    824 ;	quantum/quantum.c:166: unregister_code(code);
      009AB9 8E 04            [24]  825 	mov	ar4,r6
      009ABB 8C 82            [24]  826 	mov	dpl, r4
      009ABD C0 06            [24]  827 	push	ar6
      009ABF C0 05            [24]  828 	push	ar5
      009AC1 12 72 B9         [24]  829 	lcall	_unregister_code
      009AC4 D0 05            [24]  830 	pop	ar5
      009AC6 D0 06            [24]  831 	pop	ar6
      009AC8 D0 07            [24]  832 	pop	ar7
                                    833 ;	quantum/quantum.c:167: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009ACA 12 98 68         [24]  834 	lcall	_ak820_outline_0114
      009ACD 40 07            [24]  835 	jc	00105$
      009ACF 74 E7            [12]  836 	mov	a,#0xe7
      009AD1 9E               [12]  837 	subb	a,r6
      009AD2 E4               [12]  838 	clr	a
      009AD3 9F               [12]  839 	subb	a,r7
      009AD4 50 08            [24]  840 	jnc	00101$
                                    841 ;	free result
      009AD6                        842 00105$:
      009AD6 90 0B CE         [24]  843 	mov	dptr,#_unregister_code16_code_10000_610
      009AD9 12 6B 89         [24]  844 	lcall	_ak820_outline_0039
      009ADC 70 05            [24]  845 	jnz	00102$
      009ADE                        846 00101$:
                                    847 ;	quantum/quantum.c:168: unregister_mods(mods);
      009ADE 8D 82            [24]  848 	mov	dpl, r5
      009AE0 02 73 83         [24]  849 	ljmp	_unregister_mods
      009AE3                        850 00102$:
                                    851 ;	quantum/quantum.c:170: unregister_weak_mods(mods);
      009AE3 8D 82            [24]  852 	mov	dpl, r5
                                    853 ;	quantum/quantum.c:181: }
      009AE5 02 73 AB         [24]  854 	ljmp	_unregister_weak_mods
                                    855 ;------------------------------------------------------------
                                    856 ;Allocation info for local variables in function 'tap_code16_delay'
                                    857 ;------------------------------------------------------------
                                    858 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    859 ;code          Allocated with name '_tap_code16_delay_code_10000_615'
                                    860 ;i             Allocated with name '_tap_code16_delay_i_20000_617'
                                    861 ;i             Allocated with name '_tap_code16_delay_i_50000_620'
                                    862 ;------------------------------------------------------------
                                    863 ;	quantum/quantum.c:188: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    864 ;	-----------------------------------------
                                    865 ;	 function pre_process_record_kb
                                    866 ;	-----------------------------------------
      009AE8                        867 _pre_process_record_kb:
      009AE8 12 38 88         [24]  868 	lcall	_ak820_outline_0104
      009AEB 90 0B D3         [24]  869 	mov	dptr,#_pre_process_record_kb_keycode_10000_624
      009AEE 12 38 83         [24]  870 	lcall	_ak820_outline_0103
                                    871 ;	quantum/quantum.c:205: return pre_process_record_user(keycode, record);
      009AF1 90 0B D3         [24]  872 	mov	dptr,#_pre_process_record_kb_keycode_10000_624
      009AF4 12 38 42         [24]  873 	lcall	_ak820_outline_0051
      009AF7 90 0B D0         [24]  874 	mov	dptr,#_pre_process_record_kb_PARM_2
      009AFA 12 98 5F         [24]  875 	lcall	_ak820_outline_0024
      009AFD 90 0B D5         [24]  876 	mov	dptr,#_pre_process_record_user_PARM_2
      009B00 12 9D BE         [24]  877 	lcall	_ak820_outline_0009
                                    878 ;	quantum/quantum.c:206: }
      009B03 02 9B 06         [24]  879 	ljmp	_pre_process_record_user
                                    880 ;------------------------------------------------------------
                                    881 ;Allocation info for local variables in function 'pre_process_record_user'
                                    882 ;------------------------------------------------------------
                                    883 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    884 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_626'
                                    885 ;------------------------------------------------------------
                                    886 ;	quantum/quantum.c:208: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    887 ;	-----------------------------------------
                                    888 ;	 function pre_process_record_user
                                    889 ;	-----------------------------------------
      009B06                        890 _pre_process_record_user:
                                    891 ;	quantum/quantum.c:209: return true;
      009B06 75 82 01         [24]  892 	mov	dpl, #0x01
                                    893 ;	quantum/quantum.c:210: }
      009B09 22               [24]  894 	ret
                                    895 ;------------------------------------------------------------
                                    896 ;Allocation info for local variables in function 'process_action_kb'
                                    897 ;------------------------------------------------------------
                                    898 ;record        Allocated with name '_process_action_kb_record_10000_628'
                                    899 ;------------------------------------------------------------
                                    900 ;	quantum/quantum.c:212: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    901 ;	-----------------------------------------
                                    902 ;	 function process_action_kb
                                    903 ;	-----------------------------------------
      009B0A                        904 _process_action_kb:
                                    905 ;	quantum/quantum.c:213: return true;
      009B0A 75 82 01         [24]  906 	mov	dpl, #0x01
                                    907 ;	quantum/quantum.c:214: }
      009B0D 22               [24]  908 	ret
                                    909 ;------------------------------------------------------------
                                    910 ;Allocation info for local variables in function 'process_record_kb'
                                    911 ;------------------------------------------------------------
                                    912 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    913 ;keycode       Allocated with name '_process_record_kb_keycode_10000_630'
                                    914 ;------------------------------------------------------------
                                    915 ;	quantum/quantum.c:216: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    916 ;	-----------------------------------------
                                    917 ;	 function process_record_kb
                                    918 ;	-----------------------------------------
      009B0E                        919 _process_record_kb:
      009B0E 12 38 88         [24]  920 	lcall	_ak820_outline_0104
      009B11 90 0B DB         [24]  921 	mov	dptr,#_process_record_kb_keycode_10000_630
      009B14 12 38 83         [24]  922 	lcall	_ak820_outline_0103
                                    923 ;	quantum/quantum.c:217: return process_record_user(keycode, record);
      009B17 90 0B DB         [24]  924 	mov	dptr,#_process_record_kb_keycode_10000_630
      009B1A 12 38 42         [24]  925 	lcall	_ak820_outline_0051
      009B1D 90 0B D8         [24]  926 	mov	dptr,#_process_record_kb_PARM_2
      009B20 12 98 5F         [24]  927 	lcall	_ak820_outline_0024
      009B23 90 0B DD         [24]  928 	mov	dptr,#_process_record_user_PARM_2
      009B26 12 9D BE         [24]  929 	lcall	_ak820_outline_0009
                                    930 ;	quantum/quantum.c:218: }
      009B29 02 9B 2C         [24]  931 	ljmp	_process_record_user
                                    932 ;------------------------------------------------------------
                                    933 ;Allocation info for local variables in function 'process_record_user'
                                    934 ;------------------------------------------------------------
                                    935 ;record        Allocated with name '_process_record_user_PARM_2'
                                    936 ;keycode       Allocated with name '_process_record_user_keycode_10000_632'
                                    937 ;------------------------------------------------------------
                                    938 ;	quantum/quantum.c:220: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    939 ;	-----------------------------------------
                                    940 ;	 function process_record_user
                                    941 ;	-----------------------------------------
      009B2C                        942 _process_record_user:
                                    943 ;	quantum/quantum.c:221: return true;
      009B2C 75 82 01         [24]  944 	mov	dpl, #0x01
                                    945 ;	quantum/quantum.c:222: }
      009B2F 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'post_process_record_kb'
                                    949 ;------------------------------------------------------------
                                    950 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    951 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_634'
                                    952 ;------------------------------------------------------------
                                    953 ;	quantum/quantum.c:224: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    954 ;	-----------------------------------------
                                    955 ;	 function post_process_record_kb
                                    956 ;	-----------------------------------------
      009B30                        957 _post_process_record_kb:
      009B30 12 38 88         [24]  958 	lcall	_ak820_outline_0104
      009B33 90 0B E3         [24]  959 	mov	dptr,#_post_process_record_kb_keycode_10000_634
      009B36 12 38 83         [24]  960 	lcall	_ak820_outline_0103
                                    961 ;	quantum/quantum.c:225: post_process_record_user(keycode, record);
      009B39 90 0B E3         [24]  962 	mov	dptr,#_post_process_record_kb_keycode_10000_634
      009B3C 12 38 42         [24]  963 	lcall	_ak820_outline_0051
      009B3F 90 0B E0         [24]  964 	mov	dptr,#_post_process_record_kb_PARM_2
      009B42 12 98 5F         [24]  965 	lcall	_ak820_outline_0024
      009B45 90 0B E5         [24]  966 	mov	dptr,#_post_process_record_user_PARM_2
      009B48 12 9D BE         [24]  967 	lcall	_ak820_outline_0009
                                    968 ;	quantum/quantum.c:226: }
      009B4B 02 9B 4E         [24]  969 	ljmp	_post_process_record_user
                                    970 ;------------------------------------------------------------
                                    971 ;Allocation info for local variables in function 'post_process_record_user'
                                    972 ;------------------------------------------------------------
                                    973 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    974 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_636'
                                    975 ;------------------------------------------------------------
                                    976 ;	quantum/quantum.c:228: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    977 ;	-----------------------------------------
                                    978 ;	 function post_process_record_user
                                    979 ;	-----------------------------------------
      009B4E                        980 _post_process_record_user:
      009B4E 22               [24]  981 	ret
                                    982 ;------------------------------------------------------------
                                    983 ;Allocation info for local variables in function 'shutdown_quantum'
                                    984 ;------------------------------------------------------------
                                    985 ;i             Allocated with name '_shutdown_quantum_i_30000_642'
                                    986 ;------------------------------------------------------------
                                    987 ;	quantum/quantum.c:230: void shutdown_quantum(void) {
                                    988 ;	-----------------------------------------
                                    989 ;	 function shutdown_quantum
                                    990 ;	-----------------------------------------
      009B4F                        991 _shutdown_quantum:
                                    992 ;	quantum/quantum.c:231: clear_keyboard();
      009B4F 12 73 BF         [24]  993 	lcall	_clear_keyboard
                                    994 ;	quantum/quantum.c:246: shutdown_user();
      009B52 12 9D B0         [24]  995 	lcall	_shutdown_user
                                    996 ;	quantum/quantum.c:247: wait_ms(250);
      009B55 7F FA            [12]  997 	mov	r7,#0xfa
      009B57                        998 00106$:
      009B57 EF               [12]  999 	mov	a,r7
      009B58 60 09            [24] 1000 	jz	00108$
      009B5A 90 00 01         [24] 1001 	mov	dptr,#0x0001
      009B5D 12 56 F5         [24] 1002 	lcall	_mDelaymS
      009B60 1F               [12] 1003 	dec	r7
      009B61 80 F4            [24] 1004 	sjmp	00106$
      009B63                       1005 00108$:
                                   1006 ;	quantum/quantum.c:252: }
      009B63 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'reset_keyboard'
                                   1010 ;------------------------------------------------------------
                                   1011 ;	quantum/quantum.c:254: void reset_keyboard(void) {
                                   1012 ;	-----------------------------------------
                                   1013 ;	 function reset_keyboard
                                   1014 ;	-----------------------------------------
      009B64                       1015 _reset_keyboard:
                                   1016 ;	quantum/quantum.c:255: shutdown_quantum();
      009B64 12 9B 4F         [24] 1017 	lcall	_shutdown_quantum
                                   1018 ;	quantum/quantum.c:256: bootloader_jump();
                                   1019 ;	quantum/quantum.c:257: }
      009B67 02 34 0E         [24] 1020 	ljmp	_bootloader_jump
                                   1021 ;------------------------------------------------------------
                                   1022 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1023 ;------------------------------------------------------------
                                   1024 ;	quantum/quantum.c:259: void soft_reset_keyboard(void) {
                                   1025 ;	-----------------------------------------
                                   1026 ;	 function soft_reset_keyboard
                                   1027 ;	-----------------------------------------
      009B6A                       1028 _soft_reset_keyboard:
                                   1029 ;	quantum/quantum.c:260: shutdown_quantum();
      009B6A 12 9B 4F         [24] 1030 	lcall	_shutdown_quantum
                                   1031 ;	quantum/quantum.c:261: mcu_reset();
                                   1032 ;	quantum/quantum.c:262: }
      009B6D 02 34 01         [24] 1033 	ljmp	_mcu_reset
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'get_record_keycode'
                                   1036 ;------------------------------------------------------------
                                   1037 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1038 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_648'
                                   1039 ;record        Allocated with name '_get_record_keycode_record_10000_649'
                                   1040 ;------------------------------------------------------------
                                   1041 ;	quantum/quantum.c:265: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1042 ;	-----------------------------------------
                                   1043 ;	 function get_record_keycode
                                   1044 ;	-----------------------------------------
      009B70                       1045 _get_record_keycode:
      009B70 12 43 0E         [24] 1046 	lcall	_ak820_outline_0036
      009B73 90 0B E9         [24] 1047 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009B76 12 38 2A         [24] 1048 	lcall	_ak820_outline_0015
                                   1049 ;	quantum/quantum.c:267: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009B79 90 0B E9         [24] 1050 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009B7C 12 37 FF         [24] 1051 	lcall	_ak820_outline_0007
                                   1052 ;	quantum/quantum.c:272: if (record->keycode) {
      009B7F 4C               [12] 1053 	orl	a,r4
      009B80 60 04            [24] 1054 	jz	00102$
                                   1055 ;	quantum/quantum.c:273: return record->keycode;
      009B82 12 38 92         [24] 1056 	lcall	_ak820_outline_0120
      009B85 22               [24] 1057 	ret
      009B86                       1058 00102$:
                                   1059 ;	quantum/quantum.c:277: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      009B86 12 74 0C         [24] 1060 	lcall	_ak820_outline_0019
      009B89 7A 00            [12] 1061 	mov	r2,#0x00
      009B8B 12 43 61         [24] 1062 	lcall	_ak820_outline_0137
      009B8E 12 38 13         [24] 1063 	lcall	_ak820_outline_0013
      009B91 60 06            [24] 1064 	jz	00105$
      009B93 90 0B E8         [24] 1065 	mov	dptr,#_get_record_keycode_PARM_2
      009B96 E0               [24] 1066 	movx	a,@dptr
      009B97 70 04            [24] 1067 	jnz	00106$
      009B99                       1068 00105$:
                                   1069 ;	assignBit
      009B99 C2 25            [12] 1070 	clr	_get_record_keycode_sloc0_1_0
      009B9B 80 02            [24] 1071 	sjmp	00107$
      009B9D                       1072 00106$:
                                   1073 ;	assignBit
      009B9D D2 25            [12] 1074 	setb	_get_record_keycode_sloc0_1_0
      009B9F                       1075 00107$:
      009B9F 90 09 5D         [24] 1076 	mov	dptr,#_ak820_resolve_key_PARM_2
      009BA2 A2 25            [12] 1077 	mov	c,_get_record_keycode_sloc0_1_0
      009BA4 E4               [12] 1078 	clr	a
      009BA5 33               [12] 1079 	rlc	a
      009BA6 F0               [24] 1080 	movx	@dptr,a
      009BA7 8D 82            [24] 1081 	mov	dpl, r5
      009BA9 8C 83            [24] 1082 	mov	dph, r4
                                   1083 ;	quantum/quantum.c:281: }
      009BAB 02 77 A4         [24] 1084 	ljmp	_ak820_resolve_key
                                   1085 ;------------------------------------------------------------
                                   1086 ;Allocation info for local variables in function 'get_event_keycode'
                                   1087 ;------------------------------------------------------------
                                   1088 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1089 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_652'
                                   1090 ;------------------------------------------------------------
                                   1091 ;	quantum/quantum.c:289: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1092 ;	-----------------------------------------
                                   1093 ;	 function pre_process_record_quantum
                                   1094 ;	-----------------------------------------
      009BAE                       1095 _pre_process_record_quantum:
      009BAE 12 43 0E         [24] 1096 	lcall	_ak820_outline_0036
      009BB1 90 0B EC         [24] 1097 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009BB4 12 38 2A         [24] 1098 	lcall	_ak820_outline_0015
                                   1099 ;	quantum/quantum.c:322: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009BB7 90 0B EC         [24] 1100 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009BBA 12 38 42         [24] 1101 	lcall	_ak820_outline_0051
                                   1102 ;	quantum/quantum.c:326: uint16_t keycode = get_record_keycode(record, true);
      009BBD 8E 03            [24] 1103 	mov	ar3,r6
      009BBF 8F 04            [24] 1104 	mov	ar4,r7
      009BC1 7D 00            [12] 1105 	mov	r5,#0x00
      009BC3 90 0B E8         [24] 1106 	mov	dptr,#_get_record_keycode_PARM_2
      009BC6 74 01            [12] 1107 	mov	a,#0x01
      009BC8 12 46 EC         [24] 1108 	lcall	_ak820_outline_0118
      009BCB 8D F0            [24] 1109 	mov	b, r5
      009BCD C0 07            [24] 1110 	push	ar7
      009BCF C0 06            [24] 1111 	push	ar6
      009BD1 12 9B 70         [24] 1112 	lcall	_get_record_keycode
      009BD4 12 43 6C         [24] 1113 	lcall	_ak820_outline_0143
      009BD7 D0 06            [24] 1114 	pop	ar6
      009BD9 D0 07            [24] 1115 	pop	ar7
                                   1116 ;	quantum/quantum.c:328: record->keycode = keycode;
      009BDB 74 07            [12] 1117 	mov	a,#0x07
      009BDD 12 38 32         [24] 1118 	lcall	_ak820_outline_0021
      009BE0 12 38 5F         [24] 1119 	lcall	_ak820_outline_0070
                                   1120 ;	quantum/quantum.c:338: return pre_process_record_kb(keycode, record) &&
      009BE3 90 0B D0         [24] 1121 	mov	dptr,#_pre_process_record_kb_PARM_2
      009BE6 12 9D B1         [24] 1122 	lcall	_ak820_outline_0002
      009BE9 C0 07            [24] 1123 	push	ar7
      009BEB C0 06            [24] 1124 	push	ar6
      009BED 12 9A E8         [24] 1125 	lcall	_pre_process_record_kb
      009BF0 E5 82            [12] 1126 	mov	a, dpl
      009BF2 D0 06            [24] 1127 	pop	ar6
      009BF4 D0 07            [24] 1128 	pop	ar7
      009BF6 60 0A            [24] 1129 	jz	00103$
                                   1130 ;	quantum/quantum.c:341: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      009BF8 12 38 8D         [24] 1131 	lcall	_ak820_outline_0112
      009BFB 12 36 3B         [24] 1132 	lcall	_ak820_combo_process
      009BFE E5 82            [12] 1133 	mov	a, dpl
      009C00 70 04            [24] 1134 	jnz	00104$
                                   1135 ;	quantum/quantum.c:346: true;
      009C02                       1136 00103$:
                                   1137 ;	assignBit
      009C02 C2 26            [12] 1138 	clr	_pre_process_record_quantum_sloc0_1_0
      009C04 80 02            [24] 1139 	sjmp	00105$
      009C06                       1140 00104$:
                                   1141 ;	assignBit
      009C06 D2 26            [12] 1142 	setb	_pre_process_record_quantum_sloc0_1_0
      009C08                       1143 00105$:
      009C08 A2 26            [12] 1144 	mov	c,_pre_process_record_quantum_sloc0_1_0
      009C0A 12 38 AC         [24] 1145 	lcall	_ak820_outline_0150
                                   1146 ;	quantum/quantum.c:347: }
      009C0D 22               [24] 1147 	ret
                                   1148 ;------------------------------------------------------------
                                   1149 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1150 ;------------------------------------------------------------
                                   1151 ;record        Allocated with name '_post_process_record_quantum_record_10000_656'
                                   1152 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_657'
                                   1153 ;------------------------------------------------------------
                                   1154 ;	quantum/quantum.c:350: void post_process_record_quantum(keyrecord_t *record) {
                                   1155 ;	-----------------------------------------
                                   1156 ;	 function post_process_record_quantum
                                   1157 ;	-----------------------------------------
      009C0E                       1158 _post_process_record_quantum:
      009C0E 12 43 0E         [24] 1159 	lcall	_ak820_outline_0036
      009C11 90 0B EF         [24] 1160 	mov	dptr,#_post_process_record_quantum_record_10000_656
      009C14 12 38 2A         [24] 1161 	lcall	_ak820_outline_0015
                                   1162 ;	quantum/quantum.c:351: uint16_t keycode = get_record_keycode(record, false);
      009C17 90 0B EF         [24] 1163 	mov	dptr,#_post_process_record_quantum_record_10000_656
      009C1A 12 4D 27         [24] 1164 	lcall	_ak820_outline_0012
      009C1D 90 0B E8         [24] 1165 	mov	dptr,#_get_record_keycode_PARM_2
      009C20 E4               [12] 1166 	clr	a
      009C21 12 4D 30         [24] 1167 	lcall	_ak820_outline_0038
      009C24 12 9B 70         [24] 1168 	lcall	_get_record_keycode
      009C27 12 43 56         [24] 1169 	lcall	_ak820_outline_0130
                                   1170 ;	quantum/quantum.c:352: post_process_record_kb(keycode, record);
      009C2A 90 0B EF         [24] 1171 	mov	dptr,#_post_process_record_quantum_record_10000_656
      009C2D 12 98 5F         [24] 1172 	lcall	_ak820_outline_0024
      009C30 90 0B E0         [24] 1173 	mov	dptr,#_post_process_record_kb_PARM_2
      009C33 12 9D BE         [24] 1174 	lcall	_ak820_outline_0009
                                   1175 ;	quantum/quantum.c:353: }
      009C36 02 9B 30         [24] 1176 	ljmp	_post_process_record_kb
                                   1177 ;------------------------------------------------------------
                                   1178 ;Allocation info for local variables in function 'process_record_quantum'
                                   1179 ;------------------------------------------------------------
                                   1180 ;record        Allocated with name '_process_record_quantum_record_10000_658'
                                   1181 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_659'
                                   1182 ;------------------------------------------------------------
                                   1183 ;	quantum/quantum.c:355: bool process_record_quantum(keyrecord_t *record) {
                                   1184 ;	-----------------------------------------
                                   1185 ;	 function process_record_quantum
                                   1186 ;	-----------------------------------------
      009C39                       1187 _process_record_quantum:
      009C39 12 43 0E         [24] 1188 	lcall	_ak820_outline_0036
      009C3C 90 0B F2         [24] 1189 	mov	dptr,#_process_record_quantum_record_10000_658
      009C3F 12 38 2A         [24] 1190 	lcall	_ak820_outline_0015
                                   1191 ;	quantum/quantum.c:357: uint16_t keycode = get_record_keycode(record, false);
      009C42 90 0B F2         [24] 1192 	mov	dptr,#_process_record_quantum_record_10000_658
      009C45 12 4D 27         [24] 1193 	lcall	_ak820_outline_0012
      009C48 90 0B E8         [24] 1194 	mov	dptr,#_get_record_keycode_PARM_2
      009C4B E4               [12] 1195 	clr	a
      009C4C 12 4D 30         [24] 1196 	lcall	_ak820_outline_0038
      009C4F 12 9B 70         [24] 1197 	lcall	_get_record_keycode
      009C52 12 43 56         [24] 1198 	lcall	_ak820_outline_0130
                                   1199 ;	quantum/quantum.c:361: return process_record_quantum_helper(keycode, record);
      009C55 90 0B F2         [24] 1200 	mov	dptr,#_process_record_quantum_record_10000_658
      009C58 12 98 5F         [24] 1201 	lcall	_ak820_outline_0024
      009C5B 90 0B F5         [24] 1202 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009C5E 12 9D BE         [24] 1203 	lcall	_ak820_outline_0009
                                   1204 ;	quantum/quantum.c:362: }
      009C61 02 9C 64         [24] 1205 	ljmp	_process_record_quantum_helper
                                   1206 ;------------------------------------------------------------
                                   1207 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1208 ;------------------------------------------------------------
                                   1209 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1210 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_660'
                                   1211 ;record        Allocated with name '_process_record_quantum_helper_record_10000_661'
                                   1212 ;------------------------------------------------------------
                                   1213 ;	quantum/quantum.c:384: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1214 ;	-----------------------------------------
                                   1215 ;	 function process_record_quantum_helper
                                   1216 ;	-----------------------------------------
      009C64                       1217 _process_record_quantum_helper:
      009C64 12 38 88         [24] 1218 	lcall	_ak820_outline_0104
      009C67 90 0B F8         [24] 1219 	mov	dptr,#_process_record_quantum_helper_keycode_10000_660
      009C6A 12 38 83         [24] 1220 	lcall	_ak820_outline_0103
                                   1221 ;	quantum/quantum.c:386: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009C6D 90 0B F5         [24] 1222 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009C70 12 38 42         [24] 1223 	lcall	_ak820_outline_0051
                                   1224 ;	quantum/quantum.c:440: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      009C73 90 0B F8         [24] 1225 	mov	dptr,#_process_record_quantum_helper_keycode_10000_660
      009C76 12 38 59         [24] 1226 	lcall	_ak820_outline_0059
      009C79 90 0B B3         [24] 1227 	mov	dptr,#_process_last_key_PARM_2
      009C7C 12 9D B1         [24] 1228 	lcall	_ak820_outline_0002
      009C7F C0 07            [24] 1229 	push	ar7
      009C81 C0 06            [24] 1230 	push	ar6
      009C83 C0 05            [24] 1231 	push	ar5
      009C85 C0 04            [24] 1232 	push	ar4
      009C87 12 97 98         [24] 1233 	lcall	_process_last_key
      009C8A E5 82            [12] 1234 	mov	a, dpl
      009C8C D0 04            [24] 1235 	pop	ar4
      009C8E D0 05            [24] 1236 	pop	ar5
      009C90 D0 06            [24] 1237 	pop	ar6
      009C92 D0 07            [24] 1238 	pop	ar7
      009C94 70 03            [24] 1239 	jnz	00196$
      009C96 02 9D 6D         [24] 1240 	ljmp	00101$
      009C99                       1241 00196$:
      009C99 90 0B B9         [24] 1242 	mov	dptr,#_process_repeat_key_PARM_2
      009C9C 12 9D B1         [24] 1243 	lcall	_ak820_outline_0002
      009C9F C0 07            [24] 1244 	push	ar7
      009CA1 C0 06            [24] 1245 	push	ar6
      009CA3 C0 05            [24] 1246 	push	ar5
      009CA5 C0 04            [24] 1247 	push	ar4
      009CA7 12 98 16         [24] 1248 	lcall	_process_repeat_key
      009CAA E5 82            [12] 1249 	mov	a, dpl
      009CAC D0 04            [24] 1250 	pop	ar4
      009CAE D0 05            [24] 1251 	pop	ar5
      009CB0 D0 06            [24] 1252 	pop	ar6
      009CB2 D0 07            [24] 1253 	pop	ar7
      009CB4 70 03            [24] 1254 	jnz	00197$
      009CB6 02 9D 6D         [24] 1255 	ljmp	00101$
      009CB9                       1256 00197$:
                                   1257 ;	quantum/quantum.c:449: process_record_via(keycode, record) &&
      009CB9 90 0C 35         [24] 1258 	mov	dptr,#_process_record_via_PARM_2
      009CBC 12 9D B1         [24] 1259 	lcall	_ak820_outline_0002
      009CBF C0 07            [24] 1260 	push	ar7
      009CC1 C0 06            [24] 1261 	push	ar6
      009CC3 C0 05            [24] 1262 	push	ar5
      009CC5 C0 04            [24] 1263 	push	ar4
      009CC7 12 A2 C3         [24] 1264 	lcall	_process_record_via
      009CCA E5 82            [12] 1265 	mov	a, dpl
      009CCC D0 04            [24] 1266 	pop	ar4
      009CCE D0 05            [24] 1267 	pop	ar5
      009CD0 D0 06            [24] 1268 	pop	ar6
      009CD2 D0 07            [24] 1269 	pop	ar7
      009CD4 70 03            [24] 1270 	jnz	00198$
      009CD6 02 9D 6D         [24] 1271 	ljmp	00101$
      009CD9                       1272 00198$:
                                   1273 ;	quantum/quantum.c:459: process_record_kb(keycode, record) &&
      009CD9 90 0B D8         [24] 1274 	mov	dptr,#_process_record_kb_PARM_2
      009CDC 12 9D B1         [24] 1275 	lcall	_ak820_outline_0002
      009CDF C0 07            [24] 1276 	push	ar7
      009CE1 C0 06            [24] 1277 	push	ar6
      009CE3 C0 05            [24] 1278 	push	ar5
      009CE5 C0 04            [24] 1279 	push	ar4
      009CE7 12 9B 0E         [24] 1280 	lcall	_process_record_kb
      009CEA E5 82            [12] 1281 	mov	a, dpl
      009CEC D0 04            [24] 1282 	pop	ar4
      009CEE D0 05            [24] 1283 	pop	ar5
      009CF0 D0 06            [24] 1284 	pop	ar6
      009CF2 D0 07            [24] 1285 	pop	ar7
      009CF4 70 03            [24] 1286 	jnz	00199$
      009CF6 02 9D 6D         [24] 1287 	ljmp	00101$
      009CF9                       1288 00199$:
                                   1289 ;	quantum/quantum.c:482: process_caps_word(keycode, record) &&
      009CF9 90 0B 9B         [24] 1290 	mov	dptr,#_process_caps_word_PARM_2
      009CFC 12 9D B1         [24] 1291 	lcall	_ak820_outline_0002
      009CFF C0 07            [24] 1292 	push	ar7
      009D01 C0 06            [24] 1293 	push	ar6
      009D03 C0 05            [24] 1294 	push	ar5
      009D05 C0 04            [24] 1295 	push	ar4
      009D07 12 95 0E         [24] 1296 	lcall	_process_caps_word
      009D0A E5 82            [12] 1297 	mov	a, dpl
      009D0C D0 04            [24] 1298 	pop	ar4
      009D0E D0 05            [24] 1299 	pop	ar5
      009D10 D0 06            [24] 1300 	pop	ar6
      009D12 D0 07            [24] 1301 	pop	ar7
      009D14 60 57            [24] 1302 	jz	00101$
                                   1303 ;	quantum/quantum.c:509: process_grave_esc(keycode, record) &&
      009D16 90 0B A0         [24] 1304 	mov	dptr,#_process_grave_esc_PARM_2
      009D19 12 9D B1         [24] 1305 	lcall	_ak820_outline_0002
      009D1C C0 07            [24] 1306 	push	ar7
      009D1E C0 06            [24] 1307 	push	ar6
      009D20 C0 05            [24] 1308 	push	ar5
      009D22 C0 04            [24] 1309 	push	ar4
      009D24 12 96 21         [24] 1310 	lcall	_process_grave_esc
      009D27 E5 82            [12] 1311 	mov	a, dpl
      009D29 D0 04            [24] 1312 	pop	ar4
      009D2B D0 05            [24] 1313 	pop	ar5
      009D2D D0 06            [24] 1314 	pop	ar6
      009D2F D0 07            [24] 1315 	pop	ar7
      009D31 60 3A            [24] 1316 	jz	00101$
                                   1317 ;	quantum/quantum.c:512: process_rgb(keycode, record) &&
      009D33 90 0B BE         [24] 1318 	mov	dptr,#_process_rgb_PARM_2
      009D36 12 9D B1         [24] 1319 	lcall	_ak820_outline_0002
      009D39 C0 07            [24] 1320 	push	ar7
      009D3B C0 06            [24] 1321 	push	ar6
      009D3D C0 05            [24] 1322 	push	ar5
      009D3F C0 04            [24] 1323 	push	ar4
      009D41 12 98 70         [24] 1324 	lcall	_process_rgb
      009D44 E5 82            [12] 1325 	mov	a, dpl
      009D46 D0 04            [24] 1326 	pop	ar4
      009D48 D0 05            [24] 1327 	pop	ar5
      009D4A D0 06            [24] 1328 	pop	ar6
      009D4C D0 07            [24] 1329 	pop	ar7
      009D4E 60 1D            [24] 1330 	jz	00101$
                                   1331 ;	quantum/quantum.c:524: process_tri_layer(keycode, record) &&
      009D50 90 0B C4         [24] 1332 	mov	dptr,#_process_tri_layer_PARM_2
      009D53 12 9D B1         [24] 1333 	lcall	_ak820_outline_0002
      009D56 C0 07            [24] 1334 	push	ar7
      009D58 C0 06            [24] 1335 	push	ar6
      009D5A C0 05            [24] 1336 	push	ar5
      009D5C C0 04            [24] 1337 	push	ar4
      009D5E 12 99 21         [24] 1338 	lcall	_process_tri_layer
      009D61 E5 82            [12] 1339 	mov	a, dpl
      009D63 D0 04            [24] 1340 	pop	ar4
      009D65 D0 05            [24] 1341 	pop	ar5
      009D67 D0 06            [24] 1342 	pop	ar6
      009D69 D0 07            [24] 1343 	pop	ar7
      009D6B 70 04            [24] 1344 	jnz	00102$
                                   1345 ;	quantum/quantum.c:526: true)) {
      009D6D                       1346 00101$:
                                   1347 ;	quantum/quantum.c:527: return false;
      009D6D 75 82 00         [24] 1348 	mov	dpl, #0x00
      009D70 22               [24] 1349 	ret
      009D71                       1350 00102$:
                                   1351 ;	quantum/quantum.c:530: if (record->event.pressed) {
      009D71 74 05            [12] 1352 	mov	a,#0x05
      009D73 12 46 B8         [24] 1353 	lcall	_ak820_outline_0030
      009D76 60 30            [24] 1354 	jz	00116$
                                   1355 ;	quantum/quantum.c:531: switch (keycode) {
      009D78 BC 00 05         [24] 1356 	cjne	r4,#0x00,00205$
      009D7B BD 7C 02         [24] 1357 	cjne	r5,#0x7c,00205$
      009D7E 80 10            [24] 1358 	sjmp	00111$
      009D80                       1359 00205$:
      009D80 BC 01 05         [24] 1360 	cjne	r4,#0x01,00206$
      009D83 BD 7C 02         [24] 1361 	cjne	r5,#0x7c,00206$
      009D86 80 0F            [24] 1362 	sjmp	00112$
      009D88                       1363 00206$:
                                   1364 ;	quantum/quantum.c:533: case QK_BOOTLOADER:
      009D88 BC 03 1D         [24] 1365 	cjne	r4,#0x03,00116$
      009D8B BD 7C 1A         [24] 1366 	cjne	r5,#0x7c,00116$
      009D8E 80 0E            [24] 1367 	sjmp	00113$
      009D90                       1368 00111$:
                                   1369 ;	quantum/quantum.c:534: reset_keyboard();
      009D90 12 9B 64         [24] 1370 	lcall	_reset_keyboard
                                   1371 ;	quantum/quantum.c:535: return false;
      009D93 75 82 00         [24] 1372 	mov	dpl, #0x00
                                   1373 ;	quantum/quantum.c:536: case QK_REBOOT:
      009D96 22               [24] 1374 	ret
      009D97                       1375 00112$:
                                   1376 ;	quantum/quantum.c:537: soft_reset_keyboard();
      009D97 12 9B 6A         [24] 1377 	lcall	_soft_reset_keyboard
                                   1378 ;	quantum/quantum.c:538: return false;
      009D9A 75 82 00         [24] 1379 	mov	dpl, #0x00
                                   1380 ;	quantum/quantum.c:550: case QK_CLEAR_EEPROM:
      009D9D 22               [24] 1381 	ret
      009D9E                       1382 00113$:
                                   1383 ;	quantum/quantum.c:557: eeconfig_disable();
      009D9E 12 8C 7A         [24] 1384 	lcall	_eeconfig_disable
                                   1385 ;	quantum/quantum.c:558: soft_reset_keyboard();
      009DA1 12 9B 6A         [24] 1386 	lcall	_soft_reset_keyboard
                                   1387 ;	quantum/quantum.c:560: return false;
      009DA4 75 82 00         [24] 1388 	mov	dpl, #0x00
                                   1389 ;	quantum/quantum.c:615: }
      009DA7 22               [24] 1390 	ret
      009DA8                       1391 00116$:
                                   1392 ;	quantum/quantum.c:618: return process_action_kb(record);
      009DA8 7D 00            [12] 1393 	mov	r5,#0x00
      009DAA 12 6D A4         [24] 1394 	lcall	_ak820_outline_0063
                                   1395 ;	quantum/quantum.c:619: }
      009DAD 02 9B 0A         [24] 1396 	ljmp	_process_action_kb
                                   1397 ;------------------------------------------------------------
                                   1398 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1399 ;------------------------------------------------------------
                                   1400 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_668'
                                   1401 ;------------------------------------------------------------
                                   1402 ;	quantum/quantum.c:621: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1403 ;	-----------------------------------------
                                   1404 ;	 function shutdown_user
                                   1405 ;	-----------------------------------------
      009DB0                       1406 _shutdown_user:
      009DB0 22               [24] 1407 	ret
                                   1408 ;------------------------------------------------------------
                                   1409 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1410 ;------------------------------------------------------------
                                   1411 ;	quantum/quantum.c:637: void suspend_power_down_quantum(void) {
                                   1412 ;	-----------------------------------------
                                   1413 	.area CSEG    (CODE)
                                   1414 	.area CONST   (CODE)
                                   1415 	.area XINIT   (CODE)
                                   1416 	.area CABS    (ABS,CODE)
                                   1417 
                                   1418 ; Experimental exact instruction outlining.
                                   1419 	.globl _ak820_outline_0002
                                   1420 	.globl _ak820_outline_0005
                                   1421 	.globl _ak820_outline_0007
                                   1422 	.globl _ak820_outline_0009
                                   1423 	.globl _ak820_outline_0012
                                   1424 	.globl _ak820_outline_0013
                                   1425 	.globl _ak820_outline_0015
                                   1426 	.globl _ak820_outline_0019
                                   1427 	.globl _ak820_outline_0021
                                   1428 	.globl _ak820_outline_0024
                                   1429 	.globl _ak820_outline_0030
                                   1430 	.globl _ak820_outline_0036
                                   1431 	.globl _ak820_outline_0038
                                   1432 	.globl _ak820_outline_0039
                                   1433 	.globl _ak820_outline_0051
                                   1434 	.globl _ak820_outline_0059
                                   1435 	.globl _ak820_outline_0063
                                   1436 	.globl _ak820_outline_0070
                                   1437 	.globl _ak820_outline_0103
                                   1438 	.globl _ak820_outline_0104
                                   1439 	.globl _ak820_outline_0112
                                   1440 	.globl _ak820_outline_0114
                                   1441 	.globl _ak820_outline_0118
                                   1442 	.globl _ak820_outline_0120
                                   1443 	.globl _ak820_outline_0130
                                   1444 	.globl _ak820_outline_0137
                                   1445 	.globl _ak820_outline_0143
                                   1446 	.globl _ak820_outline_0150
                                   1447 
                                   1448 	.area CSEG (CODE)
                                   1449 ; function ak820_outline_0002
      009DB1                       1450 _ak820_outline_0002:
      009DB1 EE               [12] 1451 	mov	a,r6
      009DB2 F0               [24] 1452 	movx	@dptr,a
      009DB3 EF               [12] 1453 	mov	a,r7
      009DB4 A3               [24] 1454 	inc	dptr
      009DB5 F0               [24] 1455 	movx	@dptr,a
      009DB6 E4               [12] 1456 	clr	a
      009DB7 A3               [24] 1457 	inc	dptr
      009DB8 F0               [24] 1458 	movx	@dptr,a
      009DB9 8C 82            [24] 1459 	mov	dpl,r4
      009DBB 8D 83            [24] 1460 	mov	dph,r5
      009DBD 22               [24] 1461 	ret
                                   1462 
                                   1463 	.area CSEG (CODE)
                                   1464 ; function ak820_outline_0009
      009DBE                       1465 _ak820_outline_0009:
      009DBE EB               [12] 1466 	mov	a,r3
      009DBF F0               [24] 1467 	movx	@dptr,a
      009DC0 EC               [12] 1468 	mov	a,r4
      009DC1 A3               [24] 1469 	inc	dptr
      009DC2 F0               [24] 1470 	movx	@dptr,a
      009DC3 ED               [12] 1471 	mov	a,r5
      009DC4 A3               [24] 1472 	inc	dptr
      009DC5 F0               [24] 1473 	movx	@dptr,a
      009DC6 8E 82            [24] 1474 	mov	dpl,r6
      009DC8 8F 83            [24] 1475 	mov	dph,r7
      009DCA 22               [24] 1476 	ret
