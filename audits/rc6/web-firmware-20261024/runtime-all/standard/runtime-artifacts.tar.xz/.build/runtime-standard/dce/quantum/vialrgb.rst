                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004E                        535 _fast_set_leds_sloc0_1_0:
      00004E                        536 	.ds 2
      000050                        537 _fast_set_leds_sloc1_1_0:
      000050                        538 	.ds 2
      000052                        539 _vialrgb_get_value_sloc0_1_0:
      000052                        540 	.ds 2
      000054                        541 _vialrgb_get_value_sloc1_1_0:
      000054                        542 	.ds 2
      000056                        543 _vialrgb_set_value_sloc0_1_0:
      000056                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C78                        569 _g_direct_mode_colors::
      000C78                        570 	.ds 246
      000D6E                        571 _get_supported_PARM_2:
      000D6E                        572 	.ds 1
      000D6F                        573 _get_supported_args_10000_255:
      000D6F                        574 	.ds 2
      000D71                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D71                        576 	.ds 2
      000D73                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D73                        578 	.ds 2
      000D75                        579 _set_mode_mode_10000_275:
      000D75                        580 	.ds 2
      000D77                        581 _get_matrix_pos_for_led_PARM_2:
      000D77                        582 	.ds 2
      000D79                        583 _get_matrix_pos_for_led_led_10000_280:
      000D79                        584 	.ds 2
      000D7B                        585 _fast_set_leds_PARM_2:
      000D7B                        586 	.ds 1
      000D7C                        587 _fast_set_leds_args_10000_282:
      000D7C                        588 	.ds 2
      000D7E                        589 _fast_set_leds_first_index_10001_285:
      000D7E                        590 	.ds 2
      000D80                        591 _fast_set_leds_num_leds_10001_285:
      000D80                        592 	.ds 1
      000D81                        593 _vialrgb_get_value_PARM_2:
      000D81                        594 	.ds 1
      000D82                        595 _vialrgb_get_value_data_10000_291:
      000D82                        596 	.ds 3
      000D85                        597 _vialrgb_set_value_PARM_2:
      000D85                        598 	.ds 1
      000D86                        599 _vialrgb_set_value_data_10000_302:
      000D86                        600 	.ds 3
      000D89                        601 _vialrgb_save_PARM_2:
      000D89                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00AEDB                        654 _get_supported:
      00AEDB 12 38 88         [24]  655 	lcall	_ak820_outline_0104
      00AEDE 90 0D 6F         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00AEE1 12 38 83         [24]  657 	lcall	_ak820_outline_0103
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00AEE4 90 0D 6F         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00AEE7 12 37 F5         [24]  660 	lcall	_ak820_outline_0005
      00AEEA E0               [24]  661 	movx	a,@dptr
      00AEEB FD               [12]  662 	mov	r5,a
      00AEEC 7C 00            [12]  663 	mov	r4,#0x00
      00AEEE 12 38 8D         [24]  664 	lcall	_ak820_outline_0112
      00AEF1 A3               [24]  665 	inc	dptr
      00AEF2 E0               [24]  666 	movx	a,@dptr
      00AEF3 FA               [12]  667 	mov	r2,a
      00AEF4 E4               [12]  668 	clr	a
      00AEF5 12 43 61         [24]  669 	lcall	_ak820_outline_0137
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00AEF8 90 0D 6E         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00AEFB E0               [24]  672 	movx	a,@dptr
      00AEFC FB               [12]  673 	mov	r3,a
      00AEFD 7A 00            [12]  674 	mov	r2,#0x00
      00AEFF                        675 00107$:
      00AEFF C3               [12]  676 	clr	c
      00AF00 EA               [12]  677 	mov	a,r2
      00AF01 9B               [12]  678 	subb	a,r3
      00AF02 50 0A            [24]  679 	jnc	00101$
      00AF04 EA               [12]  680 	mov	a,r2
      00AF05 12 38 32         [24]  681 	lcall	_ak820_outline_0021
      00AF08 74 FF            [12]  682 	mov	a,#0xff
      00AF0A F0               [24]  683 	movx	@dptr,a
      00AF0B 0A               [12]  684 	inc	r2
      00AF0C 80 F1            [24]  685 	sjmp	00107$
      00AF0E                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AF0E 8D 06            [24]  688 	mov	ar6,r5
      00AF10 8C 07            [24]  689 	mov	ar7,r4
      00AF12 8B 05            [24]  690 	mov	ar5,r3
      00AF14 90 0D 6F         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00AF17 12 38 7D         [24]  692 	lcall	_ak820_outline_0099
      00AF1A 7A 00            [12]  693 	mov	r2,#0x00
      00AF1C                        694 00110$:
      00AF1C BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00AF1F                        696 00159$:
      00AF1F 50 45            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00AF21 EA               [12]  699 	mov	a,r2
      00AF22 75 F0 02         [24]  700 	mov	b,#0x02
      00AF25 A4               [48]  701 	mul	ab
      00AF26 24 84            [12]  702 	add	a, #_supported_modes
      00AF28 F5 82            [12]  703 	mov	dpl,a
      00AF2A 74 BB            [12]  704 	mov	a,#(_supported_modes >> 8)
      00AF2C 12 55 38         [24]  705 	lcall	_ak820_outline_0105
      00AF2F F8               [12]  706 	mov	r0,a
      00AF30 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00AF32 C3               [12]  709 	clr	c
      00AF33 EE               [12]  710 	mov	a,r6
      00AF34 98               [12]  711 	subb	a,r0
      00AF35 EF               [12]  712 	mov	a,r7
      00AF36 99               [12]  713 	subb	a,r1
      00AF37 50 2A            [24]  714 	jnc	00111$
                                    715 ;	free result
      00AF39 BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00AF3C                        717 00162$:
      00AF3C 40 25            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00AF3E C0 06            [24]  720 	push	ar6
      00AF40 C0 07            [24]  721 	push	ar7
      00AF42 88 07            [24]  722 	mov	ar7,r0
      00AF44 12 33 FC         [24]  723 	lcall	_ak820_outline_0119
      00AF47 EF               [12]  724 	mov	a,r7
      00AF48 12 46 EC         [24]  725 	lcall	_ak820_outline_0118
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00AF4B A3               [24]  727 	inc	dptr
      00AF4C 89 00            [24]  728 	mov	ar0,r1
      00AF4E E8               [12]  729 	mov	a,r0
      00AF4F F0               [24]  730 	movx	@dptr,a
                                    731 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00AF50 1D               [12]  732 	dec	r5
      00AF51 1D               [12]  733 	dec	r5
                                    734 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00AF52 74 02            [12]  735 	mov	a,#0x02
      00AF54 2B               [12]  736 	add	a, r3
      00AF55 FB               [12]  737 	mov	r3,a
      00AF56 E4               [12]  738 	clr	a
      00AF57 3C               [12]  739 	addc	a, r4
      00AF58 FC               [12]  740 	mov	r4,a
      00AF59 90 0D 6F         [24]  741 	mov	dptr,#_get_supported_args_10000_255
      00AF5C 12 38 65         [24]  742 	lcall	_ak820_outline_0080
                                    743 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AF5F D0 07            [24]  744 	pop	ar7
      00AF61 D0 06            [24]  745 	pop	ar6
                                    746 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00AF63                        747 00111$:
                                    748 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AF63 0A               [12]  749 	inc	r2
      00AF64 80 B6            [24]  750 	sjmp	00110$
      00AF66                        751 00127$:
      00AF66 90 0D 6F         [24]  752 	mov	dptr,#_get_supported_args_10000_255
      00AF69 12 38 65         [24]  753 	lcall	_ak820_outline_0080
                                    754 ;	quantum/vialrgb.c:55: }
      00AF6C 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    758 ;------------------------------------------------------------
                                    759 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    760 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    761 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function qmk_id_to_vialrgb_id
                                    766 ;	-----------------------------------------
      00AF6D                        767 _qmk_id_to_vialrgb_id:
      00AF6D 12 38 88         [24]  768 	lcall	_ak820_outline_0104
      00AF70 90 0D 71         [24]  769 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00AF73 12 38 83         [24]  770 	lcall	_ak820_outline_0103
                                    771 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AF76 90 0D 71         [24]  772 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00AF79 12 38 42         [24]  773 	lcall	_ak820_outline_0051
      00AF7C 7D 00            [12]  774 	mov	r5,#0x00
      00AF7E                        775 00105$:
      00AF7E BD 07 00         [24]  776 	cjne	r5,#0x07,00130$
      00AF81                        777 00130$:
      00AF81 50 19            [24]  778 	jnc	00103$
                                    779 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00AF83 12 B3 A3         [24]  780 	lcall	_ak820_outline_0047
      00AF86 A3               [24]  781 	inc	dptr
      00AF87 E4               [12]  782 	clr	a
      00AF88 93               [24]  783 	movc	a,@a+dptr
                                    784 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00AF89 7A 00            [12]  785 	mov	r2,#0x00
      00AF8B B5 06 0B         [24]  786 	cjne	a,ar6,00106$
      00AF8E EA               [12]  787 	mov	a,r2
      00AF8F B5 07 07         [24]  788 	cjne	a,ar7,00106$
                                    789 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00AF92 12 33 FC         [24]  790 	lcall	_ak820_outline_0119
      00AF95 12 B3 CF         [24]  791 	lcall	_ak820_outline_0139
      00AF98 22               [24]  792 	ret
      00AF99                        793 00106$:
                                    794 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AF99 0D               [12]  795 	inc	r5
      00AF9A 80 E2            [24]  796 	sjmp	00105$
      00AF9C                        797 00103$:
                                    798 ;	quantum/vialrgb.c:63: return 0;
      00AF9C 90 00 00         [24]  799 	mov	dptr,#0x0000
                                    800 ;	quantum/vialrgb.c:64: }
      00AF9F 22               [24]  801 	ret
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    804 ;------------------------------------------------------------
                                    805 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    806 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    807 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    808 ;------------------------------------------------------------
                                    809 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function vialrgb_id_to_qmk_id
                                    812 ;	-----------------------------------------
      00AFA0                        813 _vialrgb_id_to_qmk_id:
      00AFA0 12 38 88         [24]  814 	lcall	_ak820_outline_0104
      00AFA3 90 0D 73         [24]  815 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00AFA6 12 38 83         [24]  816 	lcall	_ak820_outline_0103
                                    817 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AFA9 90 0D 73         [24]  818 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00AFAC 12 38 42         [24]  819 	lcall	_ak820_outline_0051
      00AFAF 7D 00            [12]  820 	mov	r5,#0x00
      00AFB1                        821 00105$:
      00AFB1 BD 07 00         [24]  822 	cjne	r5,#0x07,00130$
      00AFB4                        823 00130$:
      00AFB4 50 19            [24]  824 	jnc	00103$
                                    825 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00AFB6 12 B3 A3         [24]  826 	lcall	_ak820_outline_0047
      00AFB9 E4               [12]  827 	clr	a
      00AFBA 93               [24]  828 	movc	a,@a+dptr
                                    829 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00AFBB 7A 00            [12]  830 	mov	r2,#0x00
      00AFBD B5 06 0C         [24]  831 	cjne	a,ar6,00106$
      00AFC0 EA               [12]  832 	mov	a,r2
      00AFC1 B5 07 08         [24]  833 	cjne	a,ar7,00106$
                                    834 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00AFC4 12 33 FC         [24]  835 	lcall	_ak820_outline_0119
      00AFC7 A3               [24]  836 	inc	dptr
      00AFC8 12 B3 CF         [24]  837 	lcall	_ak820_outline_0139
      00AFCB 22               [24]  838 	ret
      00AFCC                        839 00106$:
                                    840 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00AFCC 0D               [12]  841 	inc	r5
      00AFCD 80 E2            [24]  842 	sjmp	00105$
      00AFCF                        843 00103$:
                                    844 ;	quantum/vialrgb.c:72: return 0;
      00AFCF 90 00 00         [24]  845 	mov	dptr,#0x0000
                                    846 ;	quantum/vialrgb.c:73: }
      00AFD2 22               [24]  847 	ret
                                    848 ;------------------------------------------------------------
                                    849 ;Allocation info for local variables in function 'get_mode'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function get_mode
                                    854 ;	-----------------------------------------
      00AFD3                        855 _get_mode:
                                    856 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00AFD3 12 53 1E         [24]  857 	lcall	_rgb_matrix_is_enabled
      00AFD6 E5 82            [12]  858 	mov	a, dpl
      00AFD8 70 04            [24]  859 	jnz	00102$
                                    860 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00AFDA 90 00 00         [24]  861 	mov	dptr,#0x0000
      00AFDD 22               [24]  862 	ret
      00AFDE                        863 00102$:
                                    864 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00AFDE 12 53 24         [24]  865 	lcall	_rgb_matrix_get_mode
      00AFE1 7E 00            [12]  866 	mov	r6,#0x00
      00AFE3 8E 83            [24]  867 	mov	dph, r6
                                    868 ;	quantum/vialrgb.c:80: }
      00AFE5 02 AF 6D         [24]  869 	ljmp	_qmk_id_to_vialrgb_id
                                    870 ;------------------------------------------------------------
                                    871 ;Allocation info for local variables in function 'set_mode'
                                    872 ;------------------------------------------------------------
                                    873 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    874 ;------------------------------------------------------------
                                    875 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    876 ;	-----------------------------------------
                                    877 ;	 function set_mode
                                    878 ;	-----------------------------------------
      00AFE8                        879 _set_mode:
      00AFE8 12 38 88         [24]  880 	lcall	_ak820_outline_0104
      00AFEB 90 0D 75         [24]  881 	mov	dptr,#_set_mode_mode_10000_275
      00AFEE 12 38 83         [24]  882 	lcall	_ak820_outline_0103
                                    883 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00AFF1 90 0D 75         [24]  884 	mov	dptr,#_set_mode_mode_10000_275
      00AFF4 12 38 42         [24]  885 	lcall	_ak820_outline_0051
      00AFF7 90 0D 75         [24]  886 	mov	dptr,#_set_mode_mode_10000_275
      00AFFA 12 6B 89         [24]  887 	lcall	_ak820_outline_0039
      00AFFD 70 03            [24]  888 	jnz	00102$
                                    889 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00AFFF 02 53 71         [24]  890 	ljmp	_rgb_matrix_disable_noeeprom
      00B002                        891 00102$:
                                    892 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B002 C0 07            [24]  893 	push	ar7
      00B004 C0 06            [24]  894 	push	ar6
      00B006 12 53 60         [24]  895 	lcall	_rgb_matrix_enable_noeeprom
      00B009 D0 06            [24]  896 	pop	ar6
      00B00B D0 07            [24]  897 	pop	ar7
                                    898 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B00D 12 38 8D         [24]  899 	lcall	_ak820_outline_0112
      00B010 12 AF A0         [24]  900 	lcall	_vialrgb_id_to_qmk_id
                                    901 ;	quantum/vialrgb.c:90: }
      00B013 02 53 7A         [24]  902 	ljmp	_rgb_matrix_mode_noeeprom
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    905 ;------------------------------------------------------------
                                    906 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    907 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    908 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    909 ;------------------------------------------------------------
                                    910 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    911 ;	-----------------------------------------
                                    912 ;	 function get_matrix_pos_for_led
                                    913 ;	-----------------------------------------
      00B016                        914 _get_matrix_pos_for_led:
      00B016 12 38 88         [24]  915 	lcall	_ak820_outline_0104
      00B019 90 0D 79         [24]  916 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B01C 12 38 83         [24]  917 	lcall	_ak820_outline_0103
                                    918 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B01F 90 0D 79         [24]  919 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B022 12 38 42         [24]  920 	lcall	_ak820_outline_0051
      00B025 EE               [12]  921 	mov	a,r6
      00B026 24 8B            [12]  922 	add	a, #_ak820_rgb_slots
      00B028 F5 82            [12]  923 	mov	dpl,a
      00B02A EF               [12]  924 	mov	a,r7
      00B02B 34 B5            [12]  925 	addc	a, #(_ak820_rgb_slots >> 8)
      00B02D F5 83            [12]  926 	mov	dph,a
      00B02F E4               [12]  927 	clr	a
      00B030 93               [24]  928 	movc	a,@a+dptr
      00B031 FF               [12]  929 	mov	r7,a
                                    930 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B032 90 0D 77         [24]  931 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B035 12 38 71         [24]  932 	lcall	_ak820_outline_0091
      00B038 EF               [12]  933 	mov	a,r7
      00B039 12 55 6E         [24]  934 	lcall	_ak820_outline_0181
      00B03C 12 7D E4         [24]  935 	lcall	_ak820_outline_0117
                                    936 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B03F 12 38 9C         [24]  937 	lcall	_ak820_outline_0129
      00B042 A3               [24]  938 	inc	dptr
      00B043 53 07 07         [24]  939 	anl	ar7,#0x07
      00B046 EF               [12]  940 	mov	a,r7
      00B047 F0               [24]  941 	movx	@dptr,a
                                    942 ;	quantum/vialrgb.c:110: }
      00B048 22               [24]  943 	ret
                                    944 ;------------------------------------------------------------
                                    945 ;Allocation info for local variables in function 'fast_set_leds'
                                    946 ;------------------------------------------------------------
                                    947 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    948 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    949 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    950 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    951 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    952 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    953 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    954 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    955 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    956 ;------------------------------------------------------------
                                    957 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    958 ;	-----------------------------------------
                                    959 ;	 function fast_set_leds
                                    960 ;	-----------------------------------------
      00B049                        961 _fast_set_leds:
      00B049 12 38 88         [24]  962 	lcall	_ak820_outline_0104
      00B04C 90 0D 7C         [24]  963 	mov	dptr,#_fast_set_leds_args_10000_282
      00B04F 12 38 83         [24]  964 	lcall	_ak820_outline_0103
                                    965 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B052 90 0D 7B         [24]  966 	mov	dptr,#_fast_set_leds_PARM_2
      00B055 E0               [24]  967 	movx	a,@dptr
      00B056 FF               [12]  968 	mov	r7,a
      00B057 BF 03 00         [24]  969 	cjne	r7,#0x03,00159$
      00B05A                        970 00159$:
      00B05A 50 01            [24]  971 	jnc	00102$
      00B05C 22               [24]  972 	ret
      00B05D                        973 00102$:
                                    974 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B05D 90 0D 7C         [24]  975 	mov	dptr,#_fast_set_leds_args_10000_282
      00B060 E0               [24]  976 	movx	a,@dptr
      00B061 FD               [12]  977 	mov	r5,a
      00B062 A3               [24]  978 	inc	dptr
      00B063 E0               [24]  979 	movx	a,@dptr
      00B064 12 46 D6         [24]  980 	lcall	_ak820_outline_0057
      00B067 7B 00            [12]  981 	mov	r3,#0x00
      00B069 12 38 9C         [24]  982 	lcall	_ak820_outline_0129
      00B06C A3               [24]  983 	inc	dptr
      00B06D E0               [24]  984 	movx	a,@dptr
      00B06E FA               [12]  985 	mov	r2,a
      00B06F 79 00            [12]  986 	mov	r1,#0x00
      00B071 90 0D 7E         [24]  987 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B074 E9               [12]  988 	mov	a,r1
      00B075 4C               [12]  989 	orl	a,r4
      00B076 F0               [24]  990 	movx	@dptr,a
      00B077 EA               [12]  991 	mov	a,r2
      00B078 4B               [12]  992 	orl	a,r3
      00B079 A3               [24]  993 	inc	dptr
      00B07A F0               [24]  994 	movx	@dptr,a
                                    995 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B07B 12 38 9C         [24]  996 	lcall	_ak820_outline_0129
      00B07E A3               [24]  997 	inc	dptr
      00B07F A3               [24]  998 	inc	dptr
      00B080 E0               [24]  999 	movx	a,@dptr
      00B081 90 0D 80         [24] 1000 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B084 F0               [24] 1001 	movx	@dptr,a
                                   1002 ;	quantum/vialrgb.c:119: length -= 3;
      00B085 EF               [12] 1003 	mov	a,r7
      00B086 24 FD            [12] 1004 	add	a,#0xfd
      00B088 90 0D 7B         [24] 1005 	mov	dptr,#_fast_set_leds_PARM_2
      00B08B F0               [24] 1006 	movx	@dptr,a
                                   1007 ;	quantum/vialrgb.c:120: args += 3;
      00B08C 90 0D 7C         [24] 1008 	mov	dptr,#_fast_set_leds_args_10000_282
      00B08F 74 03            [12] 1009 	mov	a,#0x03
      00B091 2D               [12] 1010 	add	a, r5
      00B092 F0               [24] 1011 	movx	@dptr,a
      00B093 E4               [12] 1012 	clr	a
      00B094 3E               [12] 1013 	addc	a, r6
      00B095 A3               [24] 1014 	inc	dptr
      00B096 F0               [24] 1015 	movx	@dptr,a
                                   1016 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B097 90 0D 80         [24] 1017 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B09A E0               [24] 1018 	movx	a,@dptr
      00B09B FF               [12] 1019 	mov	r7,a
      00B09C 75 F0 03         [24] 1020 	mov	b,#0x03
      00B09F A4               [48] 1021 	mul	ab
      00B0A0 FE               [12] 1022 	mov	r6,a
      00B0A1 AD F0            [24] 1023 	mov	r5,b
      00B0A3 90 0D 7B         [24] 1024 	mov	dptr,#_fast_set_leds_PARM_2
      00B0A6 E0               [24] 1025 	movx	a,@dptr
      00B0A7 FB               [12] 1026 	mov	r3,a
      00B0A8 7C 00            [12] 1027 	mov	r4,#0x00
      00B0AA C3               [12] 1028 	clr	c
      00B0AB EB               [12] 1029 	mov	a,r3
      00B0AC 9E               [12] 1030 	subb	a,r6
      00B0AD EC               [12] 1031 	mov	a,r4
      00B0AE 9D               [12] 1032 	subb	a,r5
      00B0AF 40 13            [24] 1033 	jc	00103$
                                   1034 ;	free result
      00B0B1 90 0D 7E         [24] 1035 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B0B4 12 38 71         [24] 1036 	lcall	_ak820_outline_0091
      00B0B7 8D 03            [24] 1037 	mov	ar3,r5
      00B0B9 8E 04            [24] 1038 	mov	ar4,r6
      00B0BB C3               [12] 1039 	clr	c
      00B0BC EB               [12] 1040 	mov	a,r3
      00B0BD 94 52            [12] 1041 	subb	a,#0x52
      00B0BF EC               [12] 1042 	mov	a,r4
      00B0C0 94 00            [12] 1043 	subb	a,#0x00
      00B0C2 40 01            [24] 1044 	jc	00104$
      00B0C4                       1045 00103$:
      00B0C4 22               [24] 1046 	ret
      00B0C5                       1047 00104$:
                                   1048 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B0C5 74 52            [12] 1049 	mov	a,#0x52
      00B0C7 C3               [12] 1050 	clr	c
      00B0C8 9D               [12] 1051 	subb	a,r5
      00B0C9 FB               [12] 1052 	mov	r3,a
      00B0CA E4               [12] 1053 	clr	a
      00B0CB 9E               [12] 1054 	subb	a,r6
      00B0CC FC               [12] 1055 	mov	r4,a
      00B0CD 7A 00            [12] 1056 	mov	r2,#0x00
      00B0CF C3               [12] 1057 	clr	c
      00B0D0 EB               [12] 1058 	mov	a,r3
      00B0D1 9F               [12] 1059 	subb	a,r7
      00B0D2 EC               [12] 1060 	mov	a,r4
      00B0D3 9A               [12] 1061 	subb	a,r2
      00B0D4 50 08            [24] 1062 	jnc	00127$
                                   1063 ;	free result
      00B0D6 90 0D 80         [24] 1064 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B0D9 74 52            [12] 1065 	mov	a,#0x52
      00B0DB C3               [12] 1066 	clr	c
      00B0DC 9D               [12] 1067 	subb	a,r5
      00B0DD F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B0DE                       1070 00127$:
      00B0DE 90 0D 80         [24] 1071 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B0E1 E0               [24] 1072 	movx	a,@dptr
      00B0E2 FF               [12] 1073 	mov	r7,a
      00B0E3 90 0D 7E         [24] 1074 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B0E6 12 38 71         [24] 1075 	lcall	_ak820_outline_0091
      00B0E9 7C 00            [12] 1076 	mov	r4,#0x00
      00B0EB                       1077 00110$:
      00B0EB C3               [12] 1078 	clr	c
      00B0EC EC               [12] 1079 	mov	a,r4
      00B0ED 9F               [12] 1080 	subb	a,r7
      00B0EE 40 01            [24] 1081 	jc	00164$
      00B0F0 22               [24] 1082 	ret
      00B0F1                       1083 00164$:
                                   1084 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B0F1 C0 07            [24] 1085 	push	ar7
      00B0F3 90 0D 98         [24] 1086 	mov	dptr,#__mulint_PARM_2
      00B0F6 12 43 7C         [24] 1087 	lcall	_ak820_outline_0156
      00B0F9 90 00 03         [24] 1088 	mov	dptr,#0x0003
      00B0FC C0 07            [24] 1089 	push	ar7
      00B0FE C0 06            [24] 1090 	push	ar6
      00B100 C0 05            [24] 1091 	push	ar5
      00B102 C0 04            [24] 1092 	push	ar4
      00B104 12 B5 3B         [24] 1093 	lcall	__mulint
      00B107 AA 82            [24] 1094 	mov	r2, dpl
      00B109 AB 83            [24] 1095 	mov	r3, dph
      00B10B D0 04            [24] 1096 	pop	ar4
      00B10D D0 05            [24] 1097 	pop	ar5
      00B10F D0 06            [24] 1098 	pop	ar6
      00B111 D0 07            [24] 1099 	pop	ar7
      00B113 0D               [12] 1100 	inc	r5
      00B114 BD 00 01         [24] 1101 	cjne	r5,#0x00,00165$
      00B117 0E               [12] 1102 	inc	r6
      00B118                       1103 00165$:
      00B118 EA               [12] 1104 	mov	a,r2
      00B119 24 78            [12] 1105 	add	a, #_g_direct_mode_colors
      00B11B FA               [12] 1106 	mov	r2,a
      00B11C EB               [12] 1107 	mov	a,r3
      00B11D 34 0C            [12] 1108 	addc	a, #(_g_direct_mode_colors >> 8)
      00B11F FB               [12] 1109 	mov	r3,a
                                   1110 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B120 8A 4E            [24] 1111 	mov	_fast_set_leds_sloc0_1_0,r2
      00B122 8B 4F            [24] 1112 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B124 12 B3 B5         [24] 1113 	lcall	_ak820_outline_0079
      00B127 F8               [12] 1114 	mov	r0,a
      00B128 12 B3 C3         [24] 1115 	lcall	_ak820_outline_0102
      00B12B 85 4E 82         [24] 1116 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B12E 85 4F 83         [24] 1117 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B131 E8               [12] 1118 	mov	a,r0
      00B132 F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B133 74 01            [12] 1121 	mov	a,#0x01
      00B135 2A               [12] 1122 	add	a, r2
      00B136 F5 4E            [12] 1123 	mov	_fast_set_leds_sloc0_1_0,a
      00B138 E4               [12] 1124 	clr	a
      00B139 3B               [12] 1125 	addc	a, r3
      00B13A F5 4F            [12] 1126 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B13C 90 0D 7C         [24] 1127 	mov	dptr,#_fast_set_leds_args_10000_282
      00B13F E0               [24] 1128 	movx	a,@dptr
      00B140 F8               [12] 1129 	mov	r0,a
      00B141 A3               [24] 1130 	inc	dptr
      00B142 E0               [24] 1131 	movx	a,@dptr
      00B143 FF               [12] 1132 	mov	r7,a
      00B144 88 82            [24] 1133 	mov	dpl,r0
      00B146 8F 83            [24] 1134 	mov	dph,r7
      00B148 E0               [24] 1135 	movx	a,@dptr
      00B149 F9               [12] 1136 	mov	r1,a
      00B14A 90 0D 7C         [24] 1137 	mov	dptr,#_fast_set_leds_args_10000_282
      00B14D 74 01            [12] 1138 	mov	a,#0x01
      00B14F 28               [12] 1139 	add	a, r0
      00B150 F0               [24] 1140 	movx	@dptr,a
      00B151 E4               [12] 1141 	clr	a
      00B152 3F               [12] 1142 	addc	a, r7
      00B153 A3               [24] 1143 	inc	dptr
      00B154 F0               [24] 1144 	movx	@dptr,a
      00B155 85 4E 82         [24] 1145 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B158 85 4F 83         [24] 1146 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B15B E9               [12] 1147 	mov	a,r1
      00B15C F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B15D 12 B3 B5         [24] 1150 	lcall	_ak820_outline_0079
      00B160 F5 4E            [12] 1151 	mov	_fast_set_leds_sloc0_1_0,a
      00B162 12 B3 C3         [24] 1152 	lcall	_ak820_outline_0102
                                   1153 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B165 74 02            [12] 1154 	mov	a,#0x02
      00B167 2A               [12] 1155 	add	a, r2
      00B168 F5 50            [12] 1156 	mov	_fast_set_leds_sloc1_1_0,a
      00B16A E4               [12] 1157 	clr	a
      00B16B 3B               [12] 1158 	addc	a, r3
      00B16C F5 51            [12] 1159 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B16E C3               [12] 1160 	clr	c
      00B16F 74 A0            [12] 1161 	mov	a,#0xa0
      00B171 95 4E            [12] 1162 	subb	a,_fast_set_leds_sloc0_1_0
      00B173 D0 07            [24] 1163 	pop	ar7
      00B175 50 04            [24] 1164 	jnc	00114$
                                   1165 ;	free result
      00B177 7B A0            [12] 1166 	mov	r3,#0xa0
      00B179 80 04            [24] 1167 	sjmp	00115$
      00B17B                       1168 00114$:
      00B17B AA 4E            [24] 1169 	mov	r2,_fast_set_leds_sloc0_1_0
      00B17D 8A 03            [24] 1170 	mov	ar3,r2
      00B17F                       1171 00115$:
      00B17F 85 50 82         [24] 1172 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B182 85 51 83         [24] 1173 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B185 EB               [12] 1174 	mov	a,r3
      00B186 F0               [24] 1175 	movx	@dptr,a
                                   1176 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B187 0C               [12] 1177 	inc	r4
                                   1178 ;	quantum/vialrgb.c:133: }
      00B188 02 B0 EB         [24] 1179 	ljmp	00110$
                                   1180 ;------------------------------------------------------------
                                   1181 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1182 ;------------------------------------------------------------
                                   1183 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1184 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1185 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1186 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1187 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1188 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1189 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1190 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function vialrgb_get_value
                                   1195 ;	-----------------------------------------
      00B18B                       1196 _vialrgb_get_value:
      00B18B 12 43 0E         [24] 1197 	lcall	_ak820_outline_0036
      00B18E 90 0D 82         [24] 1198 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B191 12 38 2A         [24] 1199 	lcall	_ak820_outline_0015
                                   1200 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B194 90 0D 81         [24] 1201 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B197 E0               [24] 1202 	movx	a,@dptr
      00B198 FF               [12] 1203 	mov	r7,a
      00B199 BF 20 02         [24] 1204 	cjne	r7,#0x20,00162$
      00B19C 80 01            [24] 1205 	sjmp	00102$
      00B19E                       1206 00162$:
      00B19E 22               [24] 1207 	ret
      00B19F                       1208 00102$:
                                   1209 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B19F 90 0D 82         [24] 1210 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B1A2 12 B3 8F         [24] 1211 	lcall	_ak820_outline_0045
                                   1212 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1213 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B1A5 BA 40 02         [24] 1214 	cjne	r2,#0x40,00163$
      00B1A8 80 18            [24] 1215 	sjmp	00103$
      00B1AA                       1216 00163$:
      00B1AA BA 41 02         [24] 1217 	cjne	r2,#0x41,00164$
      00B1AD 80 26            [24] 1218 	sjmp	00104$
      00B1AF                       1219 00164$:
      00B1AF BA 42 03         [24] 1220 	cjne	r2,#0x42,00165$
      00B1B2 02 B2 67         [24] 1221 	ljmp	00105$
      00B1B5                       1222 00165$:
      00B1B5 BA 43 03         [24] 1223 	cjne	r2,#0x43,00166$
      00B1B8 02 B2 73         [24] 1224 	ljmp	00106$
      00B1BB                       1225 00166$:
      00B1BB BA 44 03         [24] 1226 	cjne	r2,#0x44,00167$
      00B1BE 02 B2 7F         [24] 1227 	ljmp	00107$
      00B1C1                       1228 00167$:
      00B1C1 22               [24] 1229 	ret
                                   1230 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B1C2                       1231 00103$:
                                   1232 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B1C2 12 33 FC         [24] 1233 	lcall	_ak820_outline_0119
      00B1C5 74 01            [12] 1234 	mov	a,#0x01
      00B1C7 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B1C8 12 B3 87         [24] 1237 	lcall	_ak820_outline_0037
      00B1CB E4               [12] 1238 	clr	a
      00B1CC F0               [24] 1239 	movx	@dptr,a
                                   1240 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B1CD 12 B3 87         [24] 1241 	lcall	_ak820_outline_0037
      00B1D0 A3               [24] 1242 	inc	dptr
      00B1D1 74 A0            [12] 1243 	mov	a,#0xa0
      00B1D3 F0               [24] 1244 	movx	@dptr,a
                                   1245 ;	quantum/vialrgb.c:147: break;
      00B1D4 22               [24] 1246 	ret
                                   1247 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B1D5                       1248 00104$:
                                   1249 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B1D5 C0 06            [24] 1250 	push	ar6
      00B1D7 C0 05            [24] 1251 	push	ar5
      00B1D9 C0 04            [24] 1252 	push	ar4
      00B1DB C0 03            [24] 1253 	push	ar3
      00B1DD 12 AF D3         [24] 1254 	lcall	_get_mode
      00B1E0 A9 82            [24] 1255 	mov	r1, dpl
      00B1E2 AA 83            [24] 1256 	mov	r2, dph
      00B1E4 D0 03            [24] 1257 	pop	ar3
      00B1E6 D0 04            [24] 1258 	pop	ar4
      00B1E8 D0 05            [24] 1259 	pop	ar5
      00B1EA D0 06            [24] 1260 	pop	ar6
                                   1261 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B1EC 89 00            [24] 1262 	mov	ar0,r1
      00B1EE 12 33 FC         [24] 1263 	lcall	_ak820_outline_0119
      00B1F1 E8               [12] 1264 	mov	a,r0
      00B1F2 F0               [24] 1265 	movx	@dptr,a
                                   1266 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B1F3 12 B3 87         [24] 1267 	lcall	_ak820_outline_0037
      00B1F6 8A 01            [24] 1268 	mov	ar1,r2
      00B1F8 E9               [12] 1269 	mov	a,r1
      00B1F9 F0               [24] 1270 	movx	@dptr,a
                                   1271 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B1FA 74 04            [12] 1272 	mov	a,#0x04
      00B1FC 12 8B 66         [24] 1273 	lcall	_ak820_outline_0131
      00B1FF C0 06            [24] 1274 	push	ar6
      00B201 C0 05            [24] 1275 	push	ar5
      00B203 C0 02            [24] 1276 	push	ar2
      00B205 C0 01            [24] 1277 	push	ar1
      00B207 12 53 3F         [24] 1278 	lcall	_rgb_matrix_get_speed
      00B20A A8 82            [24] 1279 	mov	r0, dpl
      00B20C D0 01            [24] 1280 	pop	ar1
      00B20E D0 02            [24] 1281 	pop	ar2
      00B210 D0 05            [24] 1282 	pop	ar5
      00B212 D0 06            [24] 1283 	pop	ar6
      00B214 12 7D BD         [24] 1284 	lcall	_ak820_outline_0062
                                   1285 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B217 74 05            [12] 1286 	mov	a,#0x05
      00B219 12 8B 66         [24] 1287 	lcall	_ak820_outline_0131
      00B21C C0 06            [24] 1288 	push	ar6
      00B21E C0 05            [24] 1289 	push	ar5
      00B220 C0 02            [24] 1290 	push	ar2
      00B222 C0 01            [24] 1291 	push	ar1
      00B224 12 53 2A         [24] 1292 	lcall	_rgb_matrix_get_hue
      00B227 A8 82            [24] 1293 	mov	r0, dpl
      00B229 D0 01            [24] 1294 	pop	ar1
      00B22B D0 02            [24] 1295 	pop	ar2
      00B22D D0 05            [24] 1296 	pop	ar5
      00B22F D0 06            [24] 1297 	pop	ar6
      00B231 12 7D BD         [24] 1298 	lcall	_ak820_outline_0062
                                   1299 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B234 74 06            [12] 1300 	mov	a,#0x06
      00B236 12 8B 66         [24] 1301 	lcall	_ak820_outline_0131
      00B239 C0 06            [24] 1302 	push	ar6
      00B23B C0 05            [24] 1303 	push	ar5
      00B23D C0 02            [24] 1304 	push	ar2
      00B23F C0 01            [24] 1305 	push	ar1
      00B241 12 53 31         [24] 1306 	lcall	_rgb_matrix_get_sat
      00B244 A8 82            [24] 1307 	mov	r0, dpl
      00B246 D0 01            [24] 1308 	pop	ar1
      00B248 D0 02            [24] 1309 	pop	ar2
      00B24A D0 05            [24] 1310 	pop	ar5
      00B24C D0 06            [24] 1311 	pop	ar6
      00B24E 12 7D BD         [24] 1312 	lcall	_ak820_outline_0062
                                   1313 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B251 74 07            [12] 1314 	mov	a,#0x07
      00B253 12 8B 66         [24] 1315 	lcall	_ak820_outline_0131
      00B256 C0 02            [24] 1316 	push	ar2
      00B258 C0 01            [24] 1317 	push	ar1
      00B25A 12 53 38         [24] 1318 	lcall	_rgb_matrix_get_val
      00B25D A8 82            [24] 1319 	mov	r0, dpl
      00B25F D0 01            [24] 1320 	pop	ar1
      00B261 D0 02            [24] 1321 	pop	ar2
      00B263 12 7D BD         [24] 1322 	lcall	_ak820_outline_0062
                                   1323 ;	quantum/vialrgb.c:156: break;
      00B266 22               [24] 1324 	ret
                                   1325 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B267                       1326 00105$:
                                   1327 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B267 EF               [12] 1328 	mov	a,r7
      00B268 24 FE            [12] 1329 	add	a,#0xfe
      00B26A 90 0D 6E         [24] 1330 	mov	dptr,#_get_supported_PARM_2
      00B26D 12 46 EC         [24] 1331 	lcall	_ak820_outline_0118
                                   1332 ;	quantum/vialrgb.c:160: break;
      00B270 02 AE DB         [24] 1333 	ljmp	_get_supported
                                   1334 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B273                       1335 00106$:
                                   1336 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B273 12 33 FC         [24] 1337 	lcall	_ak820_outline_0119
      00B276 74 52            [12] 1338 	mov	a,#0x52
      00B278 F0               [24] 1339 	movx	@dptr,a
                                   1340 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B279 12 B3 87         [24] 1341 	lcall	_ak820_outline_0037
      00B27C E4               [12] 1342 	clr	a
      00B27D F0               [24] 1343 	movx	@dptr,a
                                   1344 ;	quantum/vialrgb.c:166: break;
      00B27E 22               [24] 1345 	ret
                                   1346 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B27F                       1347 00107$:
                                   1348 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B27F 12 33 FC         [24] 1349 	lcall	_ak820_outline_0119
      00B282 E0               [24] 1350 	movx	a,@dptr
      00B283 FF               [12] 1351 	mov	r7,a
      00B284 7A 00            [12] 1352 	mov	r2,#0x00
      00B286 74 03            [12] 1353 	mov	a,#0x03
      00B288 2D               [12] 1354 	add	a, r5
      00B289 F8               [12] 1355 	mov	r0,a
      00B28A E4               [12] 1356 	clr	a
      00B28B 3E               [12] 1357 	addc	a, r6
      00B28C F9               [12] 1358 	mov	r1,a
      00B28D C0 03            [24] 1359 	push	ar3
      00B28F C0 04            [24] 1360 	push	ar4
      00B291 12 38 B1         [24] 1361 	lcall	_ak820_outline_0151
      00B294 E0               [24] 1362 	movx	a,@dptr
      00B295 FB               [12] 1363 	mov	r3,a
      00B296 E4               [12] 1364 	clr	a
      00B297 4F               [12] 1365 	orl	a,r7
      00B298 F5 52            [12] 1366 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B29A EB               [12] 1367 	mov	a,r3
      00B29B 4A               [12] 1368 	orl	a,r2
      00B29C F5 53            [12] 1369 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1370 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B29E AC 52            [24] 1371 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B2A0 AF 53            [24] 1372 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B2A2 C3               [12] 1373 	clr	c
      00B2A3 EC               [12] 1374 	mov	a,r4
      00B2A4 94 52            [12] 1375 	subb	a,#0x52
      00B2A6 EF               [12] 1376 	mov	a,r7
      00B2A7 94 00            [12] 1377 	subb	a,#0x00
      00B2A9 D0 04            [24] 1378 	pop	ar4
      00B2AB D0 03            [24] 1379 	pop	ar3
      00B2AD 40 01            [24] 1380 	jc	00109$
      00B2AF 22               [24] 1381 	ret
      00B2B0                       1382 00109$:
                                   1383 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B2B0 E5 52            [12] 1384 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B2B2 25 52            [12] 1385 	add	a,_vialrgb_get_value_sloc0_1_0
      00B2B4 FA               [12] 1386 	mov	r2,a
      00B2B5 E5 53            [12] 1387 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B2B7 33               [12] 1388 	rlc	a
      00B2B8 FF               [12] 1389 	mov	r7,a
      00B2B9 EA               [12] 1390 	mov	a,r2
      00B2BA 24 45            [12] 1391 	add	a, #_ak820_led_points
      00B2BC F5 54            [12] 1392 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B2BE EF               [12] 1393 	mov	a,r7
      00B2BF 34 B8            [12] 1394 	addc	a, #(_ak820_led_points >> 8)
      00B2C1 F5 55            [12] 1395 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B2C3 85 54 82         [24] 1396 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B2C6 85 55 83         [24] 1397 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B2C9 E4               [12] 1398 	clr	a
      00B2CA 93               [24] 1399 	movc	a,@a+dptr
      00B2CB 12 33 FC         [24] 1400 	lcall	_ak820_outline_0119
      00B2CE F0               [24] 1401 	movx	@dptr,a
                                   1402 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B2CF 85 54 82         [24] 1403 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B2D2 85 55 83         [24] 1404 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B2D5 A3               [24] 1405 	inc	dptr
      00B2D6 E4               [12] 1406 	clr	a
      00B2D7 93               [24] 1407 	movc	a,@a+dptr
      00B2D8 12 38 B1         [24] 1408 	lcall	_ak820_outline_0151
      00B2DB F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B2DC 12 B3 87         [24] 1411 	lcall	_ak820_outline_0037
      00B2DF A3               [24] 1412 	inc	dptr
      00B2E0 74 04            [12] 1413 	mov	a,#0x04
      00B2E2 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B2E3 90 0D 77         [24] 1416 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B2E6 04               [12] 1417 	inc	a
      00B2E7 2D               [12] 1418 	add	a, r5
      00B2E8 F0               [24] 1419 	movx	@dptr,a
      00B2E9 E4               [12] 1420 	clr	a
      00B2EA 3E               [12] 1421 	addc	a, r6
      00B2EB A3               [24] 1422 	inc	dptr
      00B2EC F0               [24] 1423 	movx	@dptr,a
      00B2ED 85 52 82         [24] 1424 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B2F0 85 53 83         [24] 1425 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1426 ;	quantum/vialrgb.c:187: }
                                   1427 ;	quantum/vialrgb.c:188: }
      00B2F3 02 B0 16         [24] 1428 	ljmp	_get_matrix_pos_for_led
                                   1429 ;------------------------------------------------------------
                                   1430 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1431 ;------------------------------------------------------------
                                   1432 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1433 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1434 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1435 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1436 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1437 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1438 ;------------------------------------------------------------
                                   1439 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1440 ;	-----------------------------------------
                                   1441 ;	 function vialrgb_set_value
                                   1442 ;	-----------------------------------------
      00B2F6                       1443 _vialrgb_set_value:
      00B2F6 12 43 0E         [24] 1444 	lcall	_ak820_outline_0036
      00B2F9 90 0D 86         [24] 1445 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B2FC 12 38 2A         [24] 1446 	lcall	_ak820_outline_0015
                                   1447 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B2FF 90 0D 85         [24] 1448 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B302 E0               [24] 1449 	movx	a,@dptr
      00B303 FF               [12] 1450 	mov	r7,a
      00B304 BF 20 02         [24] 1451 	cjne	r7,#0x20,00129$
      00B307 80 01            [24] 1452 	sjmp	00102$
      00B309                       1453 00129$:
      00B309 22               [24] 1454 	ret
      00B30A                       1455 00102$:
                                   1456 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B30A 90 0D 86         [24] 1457 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B30D 12 B3 8F         [24] 1458 	lcall	_ak820_outline_0045
                                   1459 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1460 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B310 BA 41 02         [24] 1461 	cjne	r2,#0x41,00130$
      00B313 80 06            [24] 1462 	sjmp	00103$
      00B315                       1463 00130$:
      00B315 BA 42 02         [24] 1464 	cjne	r2,#0x42,00131$
      00B318 80 5E            [24] 1465 	sjmp	00104$
      00B31A                       1466 00131$:
      00B31A 22               [24] 1467 	ret
                                   1468 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B31B                       1469 00103$:
                                   1470 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B31B 12 33 FC         [24] 1471 	lcall	_ak820_outline_0119
      00B31E E0               [24] 1472 	movx	a,@dptr
      00B31F FA               [12] 1473 	mov	r2,a
      00B320 12 B3 87         [24] 1474 	lcall	_ak820_outline_0037
      00B323 E0               [24] 1475 	movx	a,@dptr
      00B324 F8               [12] 1476 	mov	r0,a
      00B325 79 00            [12] 1477 	mov	r1,#0x00
      00B327 88 57            [24] 1478 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B329 89 56            [24] 1479 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B32B 8A 01            [24] 1480 	mov	ar1,r2
      00B32D 7A 00            [12] 1481 	mov	r2,#0x00
      00B32F E5 57            [12] 1482 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B331 42 02            [12] 1483 	orl	ar2,a
                                   1484 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B333 12 43 67         [24] 1485 	lcall	_ak820_outline_0142
      00B336 C0 06            [24] 1486 	push	ar6
      00B338 C0 05            [24] 1487 	push	ar5
      00B33A 12 AF E8         [24] 1488 	lcall	_set_mode
      00B33D D0 05            [24] 1489 	pop	ar5
      00B33F D0 06            [24] 1490 	pop	ar6
                                   1491 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B341 12 B3 87         [24] 1492 	lcall	_ak820_outline_0037
      00B344 A3               [24] 1493 	inc	dptr
      00B345 E0               [24] 1494 	movx	a,@dptr
      00B346 F5 82            [12] 1495 	mov	dpl,a
      00B348 C0 06            [24] 1496 	push	ar6
      00B34A C0 05            [24] 1497 	push	ar5
      00B34C 12 54 0D         [24] 1498 	lcall	_rgb_matrix_set_speed_noeeprom
      00B34F D0 05            [24] 1499 	pop	ar5
      00B351 D0 06            [24] 1500 	pop	ar6
                                   1501 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B353 12 B3 87         [24] 1502 	lcall	_ak820_outline_0037
      00B356 A3               [24] 1503 	inc	dptr
      00B357 A3               [24] 1504 	inc	dptr
      00B358 E0               [24] 1505 	movx	a,@dptr
      00B359 F9               [12] 1506 	mov	r1,a
      00B35A 7A 00            [12] 1507 	mov	r2,#0x00
      00B35C 74 06            [12] 1508 	mov	a,#0x06
      00B35E 12 B3 D9         [24] 1509 	lcall	_ak820_outline_0166
      00B361 F8               [12] 1510 	mov	r0,a
      00B362 74 07            [12] 1511 	mov	a,#0x07
      00B364 12 B3 D9         [24] 1512 	lcall	_ak820_outline_0166
      00B367 FE               [12] 1513 	mov	r6,a
      00B368 90 07 24         [24] 1514 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B36B E8               [12] 1515 	mov	a,r0
      00B36C F0               [24] 1516 	movx	@dptr,a
      00B36D 90 07 25         [24] 1517 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B370 EE               [12] 1518 	mov	a,r6
      00B371 F0               [24] 1519 	movx	@dptr,a
      00B372 12 43 67         [24] 1520 	lcall	_ak820_outline_0142
                                   1521 ;	quantum/vialrgb.c:202: break;
                                   1522 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B375 02 53 DE         [24] 1523 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B378                       1524 00104$:
                                   1525 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B378 EF               [12] 1526 	mov	a,r7
      00B379 24 FE            [12] 1527 	add	a,#0xfe
      00B37B 90 0D 7B         [24] 1528 	mov	dptr,#_fast_set_leds_PARM_2
      00B37E 12 46 EC         [24] 1529 	lcall	_ak820_outline_0118
                                   1530 ;	quantum/vialrgb.c:210: }
                                   1531 ;	quantum/vialrgb.c:211: }
      00B381 02 B0 49         [24] 1532 	ljmp	_fast_set_leds
                                   1533 ;------------------------------------------------------------
                                   1534 ;Allocation info for local variables in function 'vialrgb_save'
                                   1535 ;------------------------------------------------------------
                                   1536 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1537 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1538 ;------------------------------------------------------------
                                   1539 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1540 ;	-----------------------------------------
                                   1541 ;	 function vialrgb_save
                                   1542 ;	-----------------------------------------
      00B384                       1543 _vialrgb_save:
                                   1544 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1545 ;	quantum/vialrgb.c:218: }
      00B384 02 4E 64         [24] 1546 	ljmp	_eeconfig_update_rgb_matrix
                                   1547 	.area CSEG    (CODE)
                                   1548 	.area CONST   (CODE)
                                   1549 	.area CONST   (CODE)
      00BB84                       1550 _supported_modes:
      00BB84 00                    1551 	.db #0x00	; 0
      00BB85 00                    1552 	.db #0x00	; 0
      00BB86 01                    1553 	.db #0x01	; 1
      00BB87 05                    1554 	.db #0x05	; 5
      00BB88 02                    1555 	.db #0x02	; 2
      00BB89 01                    1556 	.db #0x01	; 1
      00BB8A 06                    1557 	.db #0x06	; 6
      00BB8B 02                    1558 	.db #0x02	; 2
      00BB8C 0D                    1559 	.db #0x0d	; 13
      00BB8D 03                    1560 	.db #0x03	; 3
      00BB8E 0E                    1561 	.db #0x0e	; 14
      00BB8F 04                    1562 	.db #0x04	; 4
      00BB90 1F                    1563 	.db #0x1f	; 31
      00BB91 06                    1564 	.db #0x06	; 6
                                   1565 	.area CSEG    (CODE)
                                   1566 	.area XINIT   (CODE)
                                   1567 	.area CABS    (ABS,CODE)
                                   1568 
                                   1569 ; Experimental exact instruction outlining.
                                   1570 	.globl _ak820_outline_0005
                                   1571 	.globl _ak820_outline_0015
                                   1572 	.globl _ak820_outline_0021
                                   1573 	.globl _ak820_outline_0036
                                   1574 	.globl _ak820_outline_0037
                                   1575 	.globl _ak820_outline_0039
                                   1576 	.globl _ak820_outline_0045
                                   1577 	.globl _ak820_outline_0047
                                   1578 	.globl _ak820_outline_0051
                                   1579 	.globl _ak820_outline_0057
                                   1580 	.globl _ak820_outline_0062
                                   1581 	.globl _ak820_outline_0079
                                   1582 	.globl _ak820_outline_0080
                                   1583 	.globl _ak820_outline_0091
                                   1584 	.globl _ak820_outline_0099
                                   1585 	.globl _ak820_outline_0102
                                   1586 	.globl _ak820_outline_0103
                                   1587 	.globl _ak820_outline_0104
                                   1588 	.globl _ak820_outline_0105
                                   1589 	.globl _ak820_outline_0112
                                   1590 	.globl _ak820_outline_0117
                                   1591 	.globl _ak820_outline_0118
                                   1592 	.globl _ak820_outline_0119
                                   1593 	.globl _ak820_outline_0129
                                   1594 	.globl _ak820_outline_0131
                                   1595 	.globl _ak820_outline_0137
                                   1596 	.globl _ak820_outline_0139
                                   1597 	.globl _ak820_outline_0142
                                   1598 	.globl _ak820_outline_0151
                                   1599 	.globl _ak820_outline_0156
                                   1600 	.globl _ak820_outline_0166
                                   1601 	.globl _ak820_outline_0181
                                   1602 
                                   1603 	.area CSEG (CODE)
                                   1604 ; function ak820_outline_0037
      00B387                       1605 _ak820_outline_0037:
      00B387 8D 82            [24] 1606 	mov	dpl,r5
      00B389 8E 83            [24] 1607 	mov	dph,r6
      00B38B A3               [24] 1608 	inc	dptr
      00B38C A3               [24] 1609 	inc	dptr
      00B38D A3               [24] 1610 	inc	dptr
      00B38E 22               [24] 1611 	ret
                                   1612 
                                   1613 	.area CSEG (CODE)
                                   1614 ; function ak820_outline_0045
      00B38F                       1615 _ak820_outline_0045:
      00B38F E0               [24] 1616 	movx	a,@dptr
      00B390 FD               [12] 1617 	mov	r5,a
      00B391 A3               [24] 1618 	inc	dptr
      00B392 E0               [24] 1619 	movx	a,@dptr
      00B393 FE               [12] 1620 	mov	r6,a
      00B394 74 02            [12] 1621 	mov	a,#0x02
      00B396 2D               [12] 1622 	add	a,r5
      00B397 FB               [12] 1623 	mov	r3,a
      00B398 E4               [12] 1624 	clr	a
      00B399 3E               [12] 1625 	addc	a,r6
      00B39A FC               [12] 1626 	mov	r4,a
      00B39B 8D 82            [24] 1627 	mov	dpl,r5
      00B39D 8E 83            [24] 1628 	mov	dph,r6
      00B39F A3               [24] 1629 	inc	dptr
      00B3A0 E0               [24] 1630 	movx	a,@dptr
      00B3A1 FA               [12] 1631 	mov	r2,a
      00B3A2 22               [24] 1632 	ret
                                   1633 
                                   1634 	.area CSEG (CODE)
                                   1635 ; function ak820_outline_0047
      00B3A3                       1636 _ak820_outline_0047:
      00B3A3 ED               [12] 1637 	mov	a,r5
      00B3A4 75 F0 02         [24] 1638 	mov	b,#0x02
      00B3A7 A4               [48] 1639 	mul	ab
      00B3A8 24 84            [12] 1640 	add	a,#_supported_modes
      00B3AA FB               [12] 1641 	mov	r3,a
      00B3AB 74 BB            [12] 1642 	mov	a,#(_supported_modes>>8)
      00B3AD 35 F0            [12] 1643 	addc	a,b
      00B3AF FC               [12] 1644 	mov	r4,a
      00B3B0 8B 82            [24] 1645 	mov	dpl,r3
      00B3B2 8C 83            [24] 1646 	mov	dph,r4
      00B3B4 22               [24] 1647 	ret
                                   1648 
                                   1649 	.area CSEG (CODE)
                                   1650 ; function ak820_outline_0079
      00B3B5                       1651 _ak820_outline_0079:
      00B3B5 90 0D 7C         [24] 1652 	mov	dptr,#_fast_set_leds_args_10000_282
      00B3B8 E0               [24] 1653 	movx	a,@dptr
      00B3B9 F9               [12] 1654 	mov	r1,a
      00B3BA A3               [24] 1655 	inc	dptr
      00B3BB E0               [24] 1656 	movx	a,@dptr
      00B3BC FF               [12] 1657 	mov	r7,a
      00B3BD 89 82            [24] 1658 	mov	dpl,r1
      00B3BF 8F 83            [24] 1659 	mov	dph,r7
      00B3C1 E0               [24] 1660 	movx	a,@dptr
      00B3C2 22               [24] 1661 	ret
                                   1662 
                                   1663 	.area CSEG (CODE)
                                   1664 ; function ak820_outline_0102
      00B3C3                       1665 _ak820_outline_0102:
      00B3C3 90 0D 7C         [24] 1666 	mov	dptr,#_fast_set_leds_args_10000_282
      00B3C6 74 01            [12] 1667 	mov	a,#0x01
      00B3C8 29               [12] 1668 	add	a,r1
      00B3C9 F0               [24] 1669 	movx	@dptr,a
      00B3CA E4               [12] 1670 	clr	a
      00B3CB 3F               [12] 1671 	addc	a,r7
      00B3CC A3               [24] 1672 	inc	dptr
      00B3CD F0               [24] 1673 	movx	@dptr,a
      00B3CE 22               [24] 1674 	ret
                                   1675 
                                   1676 	.area CSEG (CODE)
                                   1677 ; function ak820_outline_0139
      00B3CF                       1678 _ak820_outline_0139:
      00B3CF E4               [12] 1679 	clr	a
      00B3D0 93               [24] 1680 	movc	a,@a+dptr
      00B3D1 FC               [12] 1681 	mov	r4,a
      00B3D2 7B 00            [12] 1682 	mov	r3,#0x00
      00B3D4 8C 82            [24] 1683 	mov	dpl,r4
      00B3D6 8B 83            [24] 1684 	mov	dph,r3
      00B3D8 22               [24] 1685 	ret
                                   1686 
                                   1687 	.area CSEG (CODE)
                                   1688 ; function ak820_outline_0166
      00B3D9                       1689 _ak820_outline_0166:
      00B3D9 2D               [12] 1690 	add	a,r5
      00B3DA F5 82            [12] 1691 	mov	dpl,a
      00B3DC E4               [12] 1692 	clr	a
      00B3DD 3E               [12] 1693 	addc	a,r6
      00B3DE F5 83            [12] 1694 	mov	dph,a
      00B3E0 E0               [24] 1695 	movx	a,@dptr
      00B3E1 22               [24] 1696 	ret
