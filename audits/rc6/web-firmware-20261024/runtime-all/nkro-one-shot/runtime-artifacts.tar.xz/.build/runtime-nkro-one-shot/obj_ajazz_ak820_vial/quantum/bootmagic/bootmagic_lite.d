bootmagic_lite.o: quantum/bootmagic/bootmagic_lite.c \
 keyboards/ajazz/ak820/config.h \
 .build/runtime-nkro-one-shot/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h quantum/bootmagic/bootmagic.h \
 quantum/bootmagic/bootmagic_lite.h quantum/matrix.h \
 platforms/sdcc_dummy_macros.h tmk_core/protocol/ch555/usb_device.h \
 lib/ch555/ch555.h tmk_core/protocol/ch555/usb.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdint.h \
 tmk_core/protocol/usb_descriptor.h \
 tmk_core/protocol/ch555/lufa_utils/LUFA/Drivers/USB/USB.h \
 platforms/progmem.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/string.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stddef.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/inttypes.h \
 lib/lufa/LUFA/Common/Architectures.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/StdDescriptors.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/../../../Common/Common.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/USBMode.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/Events.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDParser.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDReportData.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/CDCClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/AudioClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/MIDIClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/AudioClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Core/USBController.h \
 lib/lufa/LUFA/Drivers/USB/Core/../../../Common/Common.h \
 lib/lufa/LUFA/Drivers/USB/Core/USBMode.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdbool.h \
 platforms/gpio.h platforms/pin_defs.h platforms/mcs51/_pin_defs.h \
 platforms/mcs51/gpio.h quantum/keyboard.h platforms/timer.h \
 platforms/mcs51/_timer.h platforms/mcs51/atomic_util.h lib/ch555/hal.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdio.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdarg.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/sdcc-lib.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/asm/mcs51/features.h \
 lib/ch555/ch555.h platforms/wait.h platforms/mcs51/_wait.h \
 quantum/eeconfig.h platforms/bootloader.h
