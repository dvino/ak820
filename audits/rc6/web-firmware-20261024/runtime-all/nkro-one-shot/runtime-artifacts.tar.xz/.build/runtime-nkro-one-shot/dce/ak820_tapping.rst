                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _add_owned_mods
                                     13 	.globl _layer_hold_off
                                     14 	.globl _layer_hold_on
                                     15 	.globl _unregister_mods
                                     16 	.globl _register_mods
                                     17 	.globl _process_record
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _ak820_oneshot_target
                                    262 	.globl _ak820_oneshot_process_PARM_3
                                    263 	.globl _ak820_oneshot_process_PARM_2
                                    264 	.globl _ak820_oneshot_consumed
                                    265 	.globl _ak820_oneshot_mods
                                    266 	.globl _ak820_tapping_source_PARM_1
                                    267 	.globl _ak820_tapping_source
                                    268 	.globl _ak820_tapping_before
                                    269 	.globl _ak820_tapping_process
                                    270 	.globl _ak820_tapping_cancel
                                    271 	.globl _ak820_oneshot_process
                                    272 ;--------------------------------------------------------
                                    273 ; special function registers
                                    274 ;--------------------------------------------------------
                                    275 	.area RSEG    (ABS,DATA)
      000000                        276 	.org 0x0000
                           0000D0   277 _PSW	=	0x00d0
                           0000E0   278 _ACC	=	0x00e0
                           0000F0   279 _B	=	0x00f0
                           0000FD   280 _A_INV	=	0x00fd
                           000081   281 _SP	=	0x0081
                           000082   282 _DPL	=	0x0082
                           000083   283 _DPH	=	0x0083
                           0000A1   284 _SAFE_MOD	=	0x00a1
                           0000B1   285 _GLOBAL_CFG	=	0x00b1
                           000087   286 _PCON	=	0x0087
                           0000BA   287 _POWER_CFG	=	0x00ba
                           0000B9   288 _CLOCK_CFG	=	0x00b9
                           0000A9   289 _WAKE_CTRL	=	0x00a9
                           0000FE   290 _RESET_KEEP	=	0x00fe
                           0000FF   291 _WDOG_COUNT	=	0x00ff
                           0000A8   292 _IE	=	0x00a8
                           0000B8   293 _IP	=	0x00b8
                           0000E8   294 _IE_EX	=	0x00e8
                           0000E9   295 _IP_EX	=	0x00e9
                           0000B2   296 _GPIO_IE	=	0x00b2
                           008584   297 _ROM_ADDR	=	0x8584
                           000084   298 _ROM_ADDR_L	=	0x0084
                           000085   299 _ROM_ADDR_H	=	0x0085
                           008F8E   300 _ROM_DATA_HI	=	0x8f8e
                           00008E   301 _ROM_DATA_HL	=	0x008e
                           00008F   302 _ROM_DATA_HH	=	0x008f
                           000086   303 _ROM_CTRL	=	0x0086
                           000080   304 _P0	=	0x0080
                           0000C4   305 _P0_MOD_OC	=	0x00c4
                           0000C5   306 _P0_DIR_PU	=	0x00c5
                           000090   307 _P1	=	0x0090
                           000092   308 _P1_MOD_OC	=	0x0092
                           000093   309 _P1_DIR_PU	=	0x0093
                           0000A0   310 _P2	=	0x00a0
                           000094   311 _P2_MOD_OC	=	0x0094
                           000095   312 _P2_DIR_PU	=	0x0095
                           0000B0   313 _P3	=	0x00b0
                           000096   314 _P3_MOD_OC	=	0x0096
                           000097   315 _P3_DIR_PU	=	0x0097
                           0000C0   316 _P4	=	0x00c0
                           0000C2   317 _P4_MOD_OC	=	0x00c2
                           0000C3   318 _P4_DIR_PU	=	0x00c3
                           0000C1   319 _P4_LED_KEY	=	0x00c1
                           0000AA   320 _P5_IN	=	0x00aa
                           0000AB   321 _P5_OUT_PU	=	0x00ab
                           0000AC   322 _P5_DIR	=	0x00ac
                           0000AD   323 _P6_IN	=	0x00ad
                           0000AE   324 _P6_OUT_PU	=	0x00ae
                           0000AF   325 _P6_DIR	=	0x00af
                           0000F1   326 _P7	=	0x00f1
                           0000A2   327 _XBUS_AUX	=	0x00a2
                           000088   328 _TCON	=	0x0088
                           000089   329 _TMOD	=	0x0089
                           00008A   330 _TL0	=	0x008a
                           00008B   331 _TL1	=	0x008b
                           00008C   332 _TH0	=	0x008c
                           00008D   333 _TH1	=	0x008d
                           000098   334 _SCON	=	0x0098
                           000099   335 _SBUF	=	0x0099
                           0000C8   336 _T2CON	=	0x00c8
                           0000C9   337 _T2MOD	=	0x00c9
                           00CBCA   338 _RCAP2	=	0xcbca
                           0000CA   339 _RCAP2L	=	0x00ca
                           0000CB   340 _RCAP2H	=	0x00cb
                           00CDCC   341 _T2COUNT	=	0xcdcc
                           0000CC   342 _TL2	=	0x00cc
                           0000CD   343 _TH2	=	0x00cd
                           00CFCE   344 _T2CAP1	=	0xcfce
                           0000CE   345 _T2CAP1L	=	0x00ce
                           0000CF   346 _T2CAP1H	=	0x00cf
                           0000F8   347 _SPI0_STAT	=	0x00f8
                           0000F9   348 _SPI0_DATA	=	0x00f9
                           0000FA   349 _SPI0_CTRL	=	0x00fa
                           0000FB   350 _SPI0_CK_SE	=	0x00fb
                           0000FC   351 _SPI0_SETUP	=	0x00fc
                           0000BC   352 _SCON1	=	0x00bc
                           0000BD   353 _SBUF1	=	0x00bd
                           0000BE   354 _SBAUD1	=	0x00be
                           0000BF   355 _SIF1	=	0x00bf
                           0000B4   356 _SPI1_STAT	=	0x00b4
                           0000B5   357 _SPI1_DATA	=	0x00b5
                           0000B6   358 _SPI1_CTRL	=	0x00b6
                           0000B7   359 _SPI1_CK_SE	=	0x00b7
                           0000F3   360 _ADC_CTRL	=	0x00f3
                           00F5F4   361 _ADC_DAT	=	0xf5f4
                           0000F4   362 _ADC_DAT_L	=	0x00f4
                           0000F5   363 _ADC_DAT_H	=	0x00f5
                           0000F6   364 _ADC_CHAN	=	0x00f6
                           0000A6   365 _LED_COMMON	=	0x00a6
                           0000A7   366 _LED_PWM_OE	=	0x00a7
                           00C7C6   367 _LED_DMA	=	0xc7c6
                           0000C6   368 _LED_DMA_L	=	0x00c6
                           0000C7   369 _LED_DMA_H	=	0x00c7
                           0000F7   370 _LED_STATUS	=	0x00f7
                           0000B3   371 _I2CX_INT	=	0x00b3
                           0000BB   372 _I2CS_INT_ST	=	0x00bb
                                    373 ;--------------------------------------------------------
                                    374 ; special function bits
                                    375 ;--------------------------------------------------------
                                    376 	.area RSEG    (ABS,DATA)
      000000                        377 	.org 0x0000
                           0000D7   378 _CY	=	0x00d7
                           0000D6   379 _AC	=	0x00d6
                           0000D5   380 _F0	=	0x00d5
                           0000D4   381 _RS1	=	0x00d4
                           0000D3   382 _RS0	=	0x00d3
                           0000D2   383 _OV	=	0x00d2
                           0000D1   384 _F1	=	0x00d1
                           0000D0   385 _P	=	0x00d0
                           0000AF   386 _EA	=	0x00af
                           0000AE   387 _E_DIS	=	0x00ae
                           0000AD   388 _ET2	=	0x00ad
                           0000AC   389 _ES	=	0x00ac
                           0000AB   390 _ET1	=	0x00ab
                           0000AA   391 _EX1	=	0x00aa
                           0000A9   392 _ET0	=	0x00a9
                           0000A8   393 _EX0	=	0x00a8
                           0000BF   394 _PH_FLAG	=	0x00bf
                           0000BE   395 _PL_FLAG	=	0x00be
                           0000BD   396 _PT2	=	0x00bd
                           0000BC   397 _PS	=	0x00bc
                           0000BB   398 _PT1	=	0x00bb
                           0000BA   399 _PX1	=	0x00ba
                           0000B9   400 _PT0	=	0x00b9
                           0000B8   401 _PX0	=	0x00b8
                           0000EF   402 _IE_WDOG	=	0x00ef
                           0000EE   403 _IE_GPIO	=	0x00ee
                           0000ED   404 _IE_PWM_I2C	=	0x00ed
                           0000EC   405 _IE_UART1	=	0x00ec
                           0000EB   406 _IE_ADC	=	0x00eb
                           0000E9   407 _IE_USB	=	0x00e9
                           0000E8   408 _IE_SPI0	=	0x00e8
                           000087   409 _P0_7	=	0x0087
                           000086   410 _P0_6	=	0x0086
                           000085   411 _P0_5	=	0x0085
                           000084   412 _P0_4	=	0x0084
                           000083   413 _P0_3	=	0x0083
                           000082   414 _P0_2	=	0x0082
                           000081   415 _P0_1	=	0x0081
                           000080   416 _P0_0	=	0x0080
                           000081   417 _SDA0	=	0x0081
                           000080   418 _SCL0	=	0x0080
                           000083   419 _TXD_	=	0x0083
                           000082   420 _RXD_	=	0x0082
                           000085   421 _AIN13	=	0x0085
                           000084   422 _AIN12	=	0x0084
                           000083   423 _AIN11	=	0x0083
                           000082   424 _AIN10	=	0x0082
                           000081   425 _AIN9	=	0x0081
                           000080   426 _AIN8	=	0x0080
                           000097   427 _P1_7	=	0x0097
                           000096   428 _P1_6	=	0x0096
                           000095   429 _P1_5	=	0x0095
                           000094   430 _P1_4	=	0x0094
                           000093   431 _P1_3	=	0x0093
                           000092   432 _P1_2	=	0x0092
                           000091   433 _P1_1	=	0x0091
                           000090   434 _P1_0	=	0x0090
                           000097   435 _TXD1_	=	0x0097
                           000096   436 _RXD1_	=	0x0096
                           000097   437 _SCK	=	0x0097
                           000096   438 _MISO	=	0x0096
                           000095   439 _MOSI	=	0x0095
                           000094   440 _SCS	=	0x0094
                           000092   441 _INT0_	=	0x0092
                           000091   442 _T2EX	=	0x0091
                           000091   443 _CAP2	=	0x0091
                           000090   444 _T2	=	0x0090
                           000090   445 _CAP1	=	0x0090
                           000097   446 _AIN7	=	0x0097
                           000096   447 _AIN6	=	0x0096
                           000095   448 _AIN5	=	0x0095
                           000094   449 _AIN4	=	0x0094
                           000093   450 _AIN3	=	0x0093
                           000092   451 _AIN2	=	0x0092
                           000091   452 _AIN1	=	0x0091
                           000090   453 _AIN0	=	0x0090
                           0000A7   454 _P2_7	=	0x00a7
                           0000A6   455 _P2_6	=	0x00a6
                           0000A5   456 _P2_5	=	0x00a5
                           0000A4   457 _P2_4	=	0x00a4
                           0000A3   458 _P2_3	=	0x00a3
                           0000A2   459 _P2_2	=	0x00a2
                           0000A1   460 _P2_1	=	0x00a1
                           0000A0   461 _P2_0	=	0x00a0
                           0000A7   462 _TXD1	=	0x00a7
                           0000A6   463 _RXD1	=	0x00a6
                           0000A5   464 _T2EX_	=	0x00a5
                           0000A5   465 _CAP2_	=	0x00a5
                           0000A4   466 _T2_	=	0x00a4
                           0000A4   467 _CAP1_	=	0x00a4
                           0000B7   468 _P3_7	=	0x00b7
                           0000B6   469 _P3_6	=	0x00b6
                           0000B5   470 _P3_5	=	0x00b5
                           0000B4   471 _P3_4	=	0x00b4
                           0000B3   472 _P3_3	=	0x00b3
                           0000B2   473 _P3_2	=	0x00b2
                           0000B1   474 _P3_1	=	0x00b1
                           0000B0   475 _P3_0	=	0x00b0
                           0000B7   476 _SCK1	=	0x00b7
                           0000B6   477 _MISO1	=	0x00b6
                           0000B5   478 _MOSI1	=	0x00b5
                           0000B5   479 _T1	=	0x00b5
                           0000B4   480 _T0	=	0x00b4
                           0000B3   481 _INT1	=	0x00b3
                           0000B2   482 _INT0	=	0x00b2
                           0000B1   483 _TXD	=	0x00b1
                           0000B0   484 _RXD	=	0x00b0
                           0000C6   485 _P4_6	=	0x00c6
                           0000C5   486 _P4_5	=	0x00c5
                           0000C4   487 _P4_4	=	0x00c4
                           0000C3   488 _P4_3	=	0x00c3
                           0000C2   489 _P4_2	=	0x00c2
                           0000C1   490 _P4_1	=	0x00c1
                           0000C0   491 _P4_0	=	0x00c0
                           00008F   492 _TF1	=	0x008f
                           00008E   493 _TR1	=	0x008e
                           00008D   494 _TF0	=	0x008d
                           00008C   495 _TR0	=	0x008c
                           00008B   496 _IE1	=	0x008b
                           00008A   497 _IT1	=	0x008a
                           000089   498 _IE0	=	0x0089
                           000088   499 _IT0	=	0x0088
                           00009F   500 _SM0	=	0x009f
                           00009E   501 _SM1	=	0x009e
                           00009D   502 _SM2	=	0x009d
                           00009C   503 _REN	=	0x009c
                           00009B   504 _TB8	=	0x009b
                           00009A   505 _RB8	=	0x009a
                           000099   506 _TI	=	0x0099
                           000098   507 _RI	=	0x0098
                           0000CF   508 _TF2	=	0x00cf
                           0000CF   509 _CAP1F	=	0x00cf
                           0000CE   510 _EXF2	=	0x00ce
                           0000CD   511 _RCLK	=	0x00cd
                           0000CC   512 _TCLK	=	0x00cc
                           0000CB   513 _EXEN2	=	0x00cb
                           0000CA   514 _TR2	=	0x00ca
                           0000C9   515 _C_T2	=	0x00c9
                           0000C8   516 _CP_RL2	=	0x00c8
                           0000FF   517 _S0_FST_ACT	=	0x00ff
                           0000FE   518 _S0_IF_OV	=	0x00fe
                           0000FD   519 _S0_IF_FIRST	=	0x00fd
                           0000FC   520 _S0_IF_BYTE	=	0x00fc
                           0000FB   521 _S0_FREE	=	0x00fb
                           0000FA   522 _S0_T_FIFO	=	0x00fa
                           0000F8   523 _S0_R_FIFO	=	0x00f8
                           0000F7   524 _ADC_START	=	0x00f7
                                    525 ;--------------------------------------------------------
                                    526 ; overlayable register banks
                                    527 ;--------------------------------------------------------
                                    528 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        529 	.ds 8
                                    530 ;--------------------------------------------------------
                                    531 ; internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area DSEG    (DATA)
      000015                        534 _ak820_tapping_process_sloc0_1_0:
      000015                        535 	.ds 2
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000E                        552 _ak820_tapping_before_sloc0_1_0:
      00000E                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      00059E                        562 _source_state:
      00059E                        563 	.ds 130
      000620                        564 _pending_time:
      000620                        565 	.ds 2
      000622                        566 _pending_code:
      000622                        567 	.ds 2
      000624                        568 _ak820_tapping_source_PARM_1:
      000624                        569 	.ds 2
      000626                        570 _hold_PARM_2:
      000626                        571 	.ds 1
      000627                        572 _hold_code_10000_601:
      000627                        573 	.ds 2
      000629                        574 _hold_mods_30000_604:
      000629                        575 	.ds 1
      00062A                        576 _commit_pending_id_10000_610:
      00062A                        577 	.ds 1
      00062B                        578 _ak820_tapping_before_event_10000_611:
      00062B                        579 	.ds 2
      00062D                        580 _ak820_tapping_process_record_10000_622:
      00062D                        581 	.ds 2
      00062F                        582 _ak820_oneshot_mods::
      00062F                        583 	.ds 1
      000630                        584 _ak820_oneshot_consumed::
      000630                        585 	.ds 1
      000631                        586 _ak820_oneshot_process_PARM_2:
      000631                        587 	.ds 1
      000632                        588 _ak820_oneshot_process_PARM_3:
      000632                        589 	.ds 1
      000633                        590 _ak820_oneshot_process_code_10000_640:
      000633                        591 	.ds 2
      000635                        592 _ak820_oneshot_process_mods_10000_641:
      000635                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; absolute external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XABS    (ABS,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; initialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XISEG   (XDATA)
      000DAA                        602 _pending:
      000DAA                        603 	.ds 1
      000DAB                        604 _ak820_oneshot_target::
      000DAB                        605 	.ds 1
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT0 (CODE)
                                    608 	.area GSINIT1 (CODE)
                                    609 	.area GSINIT2 (CODE)
                                    610 	.area GSINIT3 (CODE)
                                    611 	.area GSINIT4 (CODE)
                                    612 	.area GSINIT5 (CODE)
                                    613 	.area GSINIT  (CODE)
                                    614 	.area GSFINAL (CODE)
                                    615 	.area CSEG    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; global & static initialisations
                                    618 ;--------------------------------------------------------
                                    619 	.area HOME    (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; Home
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area HOME    (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; code
                                    630 ;--------------------------------------------------------
                                    631 	.area CSEG    (CODE)
                                    632 ;------------------------------------------------------------
                                    633 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    634 ;------------------------------------------------------------
                                    635 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    638 ;	-----------------------------------------
                           000007   639 	ar7 = 0x07
                           000006   640 	ar6 = 0x06
                           000005   641 	ar5 = 0x05
                           000004   642 	ar4 = 0x04
                           000003   643 	ar3 = 0x03
                           000002   644 	ar2 = 0x02
                           000001   645 	ar1 = 0x01
                           000000   646 	ar0 = 0x00
                                    647 ;	 function ak820_tapping_source
                                    648 ;	-----------------------------------------
      00438D                        649 _ak820_tapping_source:
                                    650 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      00438D 90 06 25         [24]  651 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      004390 E0               [24]  652 	movx	a,@dptr
      004391 FF               [12]  653 	mov	r7,a
      004392 BF 10 00         [24]  654 	cjne	r7,#0x10,00147$
      004395                        655 00147$:
      004395 50 14            [24]  656 	jnc	00102$
      004397 90 06 24         [24]  657 	mov	dptr,#_ak820_tapping_source_PARM_1
      00439A E0               [24]  658 	movx	a,@dptr
      00439B FE               [12]  659 	mov	r6,a
      00439C BE 08 00         [24]  660 	cjne	r6,#0x08,00149$
      00439F                        661 00149$:
      00439F 50 0A            [24]  662 	jnc	00102$
      0043A1 8F 05            [24]  663 	mov	ar5,r7
      0043A3 ED               [12]  664 	mov	a,r5
      0043A4 12 38 C6         [24]  665 	lcall	_ak820_outline_0190
      0043A7 2E               [12]  666 	add	a,r6
      0043A8 F5 82            [12]  667 	mov	dpl,a
      0043AA 22               [24]  668 	ret
      0043AB                        669 00102$:
                                    670 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      0043AB 90 06 24         [24]  671 	mov	dptr,#_ak820_tapping_source_PARM_1
      0043AE E0               [24]  672 	movx	a,@dptr
      0043AF FE               [12]  673 	mov	r6,a
      0043B0 BE 01 00         [24]  674 	cjne	r6,#0x01,00151$
      0043B3                        675 00151$:
      0043B3 50 0E            [24]  676 	jnc	00109$
                                    677 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0043B5 BF FD 04         [24]  678 	cjne	r7,#0xfd,00105$
      0043B8 75 82 80         [24]  679 	mov	dpl, #0x80
      0043BB 22               [24]  680 	ret
      0043BC                        681 00105$:
                                    682 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0043BC BF FC 04         [24]  683 	cjne	r7,#0xfc,00109$
      0043BF 75 82 81         [24]  684 	mov	dpl, #0x81
      0043C2 22               [24]  685 	ret
      0043C3                        686 00109$:
                                    687 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      0043C3 75 82 FF         [24]  688 	mov	dpl, #0xff
                                    689 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      0043C6 22               [24]  690 	ret
                                    691 ;------------------------------------------------------------
                                    692 ;Allocation info for local variables in function 'hold'
                                    693 ;------------------------------------------------------------
                                    694 ;pressed       Allocated with name '_hold_PARM_2'
                                    695 ;code          Allocated with name '_hold_code_10000_601'
                                    696 ;mods          Allocated with name '_hold_mods_30000_604'
                                    697 ;layer         Allocated with name '_hold_layer_30000_607'
                                    698 ;------------------------------------------------------------
                                    699 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    700 ;	-----------------------------------------
                                    701 ;	 function hold
                                    702 ;	-----------------------------------------
      0043C7                        703 _hold:
      0043C7 12 38 8D         [24]  704 	lcall	_ak820_outline_0108
      0043CA 90 06 27         [24]  705 	mov	dptr,#_hold_code_10000_601
      0043CD 12 38 88         [24]  706 	lcall	_ak820_outline_0107
                                    707 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      0043D0 90 06 27         [24]  708 	mov	dptr,#_hold_code_10000_601
      0043D3 12 47 BB         [24]  709 	lcall	_ak820_outline_0008
      0043D6 74 C0            [12]  710 	mov	a,#0x100 - 0x40
      0043D8 2D               [12]  711 	add	a,r5
      0043D9 40 2E            [24]  712 	jc	00110$
                                    713 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      0043DB 8F 05            [24]  714 	mov	ar5,r7
      0043DD 53 05 1F         [24]  715 	anl	ar5,#0x1f
      0043E0 90 06 29         [24]  716 	mov	dptr,#_hold_mods_30000_604
      0043E3 ED               [12]  717 	mov	a,r5
      0043E4 F0               [24]  718 	movx	@dptr,a
                                    719 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      0043E5 ED               [12]  720 	mov	a,r5
      0043E6 30 E4 08         [24]  721 	jnb	acc.4,00102$
      0043E9 ED               [12]  722 	mov	a,r5
      0043EA C4               [12]  723 	swap	a
      0043EB 54 F0            [12]  724 	anl	a,#0xf0
      0043ED 90 06 29         [24]  725 	mov	dptr,#_hold_mods_30000_604
      0043F0 F0               [24]  726 	movx	@dptr,a
      0043F1                        727 00102$:
                                    728 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      0043F1 90 06 26         [24]  729 	mov	dptr,#_hold_PARM_2
      0043F4 E0               [24]  730 	movx	a,@dptr
      0043F5 60 09            [24]  731 	jz	00104$
      0043F7 90 06 29         [24]  732 	mov	dptr,#_hold_mods_30000_604
      0043FA E0               [24]  733 	movx	a,@dptr
      0043FB F5 82            [12]  734 	mov	dpl,a
      0043FD 02 75 81         [24]  735 	ljmp	_register_mods
      004400                        736 00104$:
                                    737 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      004400 90 06 29         [24]  738 	mov	dptr,#_hold_mods_30000_604
      004403 E0               [24]  739 	movx	a,@dptr
      004404 F5 82            [12]  740 	mov	dpl,a
      004406 02 75 95         [24]  741 	ljmp	_unregister_mods
      004409                        742 00110$:
                                    743 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004409 8F 06            [24]  744 	mov	ar6,r7
      00440B 74 0F            [12]  745 	mov	a,#0x0f
      00440D 5E               [12]  746 	anl	a,r6
      00440E FF               [12]  747 	mov	r7,a
                                    748 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      00440F 90 06 26         [24]  749 	mov	dptr,#_hold_PARM_2
      004412 E0               [24]  750 	movx	a,@dptr
      004413 60 05            [24]  751 	jz	00107$
      004415 8F 82            [24]  752 	mov	dpl, r7
      004417 02 77 6A         [24]  753 	ljmp	_layer_hold_on
      00441A                        754 00107$:
                                    755 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      00441A 8F 82            [24]  756 	mov	dpl, r7
                                    757 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      00441C 02 77 A2         [24]  758 	ljmp	_layer_hold_off
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'commit_pending'
                                    761 ;------------------------------------------------------------
                                    762 ;id            Allocated with name '_commit_pending_id_10000_610'
                                    763 ;------------------------------------------------------------
                                    764 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function commit_pending
                                    767 ;	-----------------------------------------
      00441F                        768 _commit_pending:
                                    769 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      00441F 90 0D AA         [24]  770 	mov	dptr,#_pending
      004422 E0               [24]  771 	movx	a,@dptr
      004423 90 06 2A         [24]  772 	mov	dptr,#_commit_pending_id_10000_610
      004426 F0               [24]  773 	movx	@dptr,a
                                    774 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      004427 12 48 40         [24]  775 	lcall	_ak820_outline_0155
                                    776 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      00442A 90 06 2A         [24]  777 	mov	dptr,#_commit_pending_id_10000_610
      00442D E0               [24]  778 	movx	a,@dptr
      00442E 24 9E            [12]  779 	add	a,#_source_state
      004430 FF               [12]  780 	mov	r7,a
      004431 E4               [12]  781 	clr	a
      004432 34 05            [12]  782 	addc	a, #(_source_state >> 8)
      004434 FE               [12]  783 	mov	r6,a
      004435 12 43 77         [24]  784 	lcall	_ak820_outline_0158
      004438 E0               [24]  785 	movx	a,@dptr
      004439 FD               [12]  786 	mov	r5,a
      00443A 43 05 04         [24]  787 	orl	ar5,#0x04
      00443D 12 43 77         [24]  788 	lcall	_ak820_outline_0158
      004440 ED               [12]  789 	mov	a,r5
      004441 F0               [24]  790 	movx	@dptr,a
                                    791 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      004442 90 06 22         [24]  792 	mov	dptr,#_pending_code
      004445 12 38 41         [24]  793 	lcall	_ak820_outline_0051
      004448 90 06 26         [24]  794 	mov	dptr,#_hold_PARM_2
      00444B 74 01            [12]  795 	mov	a,#0x01
      00444D 12 43 3E         [24]  796 	lcall	_ak820_outline_0072
                                    797 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      004450 02 43 C7         [24]  798 	ljmp	_hold
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    801 ;------------------------------------------------------------
                                    802 ;event         Allocated with name '_ak820_tapping_before_event_10000_611'
                                    803 ;id            Allocated with name '_ak820_tapping_before_id_10000_612'
                                    804 ;------------------------------------------------------------
                                    805 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    806 ;	-----------------------------------------
                                    807 ;	 function ak820_tapping_before
                                    808 ;	-----------------------------------------
      004453                        809 _ak820_tapping_before:
      004453 12 38 8D         [24]  810 	lcall	_ak820_outline_0108
      004456 90 06 2B         [24]  811 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004459 12 38 88         [24]  812 	lcall	_ak820_outline_0107
                                    813 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      00445C 90 06 2B         [24]  814 	mov	dptr,#_ak820_tapping_before_event_10000_611
      00445F 12 47 BB         [24]  815 	lcall	_ak820_outline_0008
      004462 12 47 DF         [24]  816 	lcall	_ak820_outline_0024
      004465 C0 07            [24]  817 	push	ar7
      004467 C0 06            [24]  818 	push	ar6
      004469 12 B7 19         [24]  819 	lcall	___memcpy
      00446C 12 43 8D         [24]  820 	lcall	_ak820_tapping_source
      00446F AD 82            [24]  821 	mov	r5, dpl
      004471 D0 06            [24]  822 	pop	ar6
      004473 D0 07            [24]  823 	pop	ar7
                                    824 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      004475 90 0E 1B         [24]  825 	mov	dptr,#_vial_unlock_in_progress
      004478 E0               [24]  826 	movx	a,@dptr
      004479 60 29            [24]  827 	jz	00106$
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00447B 74 04            [12]  829 	mov	a,#0x04
      00447D 12 47 C5         [24]  830 	lcall	_ak820_outline_0018
      004480 60 1E            [24]  831 	jz	00102$
      004482 BD FF 02         [24]  832 	cjne	r5,#0xff,00218$
      004485 80 19            [24]  833 	sjmp	00102$
      004487                        834 00218$:
      004487 74 05            [12]  835 	mov	a,#0x05
      004489 12 47 C5         [24]  836 	lcall	_ak820_outline_0018
      00448C 70 12            [24]  837 	jnz	00102$
      00448E ED               [12]  838 	mov	a,r5
      00448F 24 9E            [12]  839 	add	a, #_source_state
      004491 FB               [12]  840 	mov	r3,a
      004492 E4               [12]  841 	clr	a
      004493 34 05            [12]  842 	addc	a, #(_source_state >> 8)
      004495 12 48 0F         [24]  843 	lcall	_ak820_outline_0055
      004498 53 02 FD         [24]  844 	anl	ar2,#0xfd
      00449B 12 33 FC         [24]  845 	lcall	_ak820_outline_0123
      00449E EA               [12]  846 	mov	a,r2
      00449F F0               [24]  847 	movx	@dptr,a
      0044A0                        848 00102$:
                                    849 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      0044A0 75 82 00         [24]  850 	mov	dpl, #0x00
      0044A3 22               [24]  851 	ret
      0044A4                        852 00106$:
                                    853 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      0044A4 90 0D AA         [24]  854 	mov	dptr,#_pending
      0044A7 E0               [24]  855 	movx	a,@dptr
      0044A8 FC               [12]  856 	mov	r4,a
      0044A9 BC FF 02         [24]  857 	cjne	r4,#0xff,00220$
      0044AC 80 3B            [24]  858 	sjmp	00108$
      0044AE                        859 00220$:
      0044AE 12 38 39         [24]  860 	lcall	_ak820_outline_0036
      0044B1 FA               [12]  861 	mov	r2,a
      0044B2 A3               [24]  862 	inc	dptr
      0044B3 E0               [24]  863 	movx	a,@dptr
      0044B4 FB               [12]  864 	mov	r3,a
      0044B5 90 06 20         [24]  865 	mov	dptr,#_pending_time
      0044B8 12 38 7C         [24]  866 	lcall	_ak820_outline_0101
      0044BB EA               [12]  867 	mov	a,r2
      0044BC C3               [12]  868 	clr	c
      0044BD 98               [12]  869 	subb	a,r0
      0044BE FA               [12]  870 	mov	r2,a
      0044BF EB               [12]  871 	mov	a,r3
      0044C0 99               [12]  872 	subb	a,r1
      0044C1 FB               [12]  873 	mov	r3,a
      0044C2 C3               [12]  874 	clr	c
      0044C3 EA               [12]  875 	mov	a,r2
      0044C4 94 C8            [12]  876 	subb	a,#0xc8
      0044C6 EB               [12]  877 	mov	a,r3
      0044C7 94 00            [12]  878 	subb	a,#0x00
      0044C9 50 17            [24]  879 	jnc	00107$
                                    880 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0044CB 74 04            [12]  881 	mov	a,#0x04
      0044CD 12 47 F9         [24]  882 	lcall	_ak820_outline_0031
      0044D0 60 17            [24]  883 	jz	00108$
      0044D2 12 38 12         [24]  884 	lcall	_ak820_outline_0009
      0044D5 60 12            [24]  885 	jz	00108$
      0044D7 BD FF 02         [24]  886 	cjne	r5,#0xff,00224$
      0044DA 80 06            [24]  887 	sjmp	00107$
      0044DC                        888 00224$:
      0044DC ED               [12]  889 	mov	a,r5
      0044DD B5 04 02         [24]  890 	cjne	a,ar4,00225$
      0044E0 80 07            [24]  891 	sjmp	00108$
      0044E2                        892 00225$:
      0044E2                        893 00107$:
      0044E2 C0 05            [24]  894 	push	ar5
      0044E4 12 44 1F         [24]  895 	lcall	_commit_pending
      0044E7 D0 05            [24]  896 	pop	ar5
      0044E9                        897 00108$:
                                    898 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      0044E9 90 06 2B         [24]  899 	mov	dptr,#_ak820_tapping_before_event_10000_611
      0044EC 12 38 41         [24]  900 	lcall	_ak820_outline_0051
      0044EF 74 04            [12]  901 	mov	a,#0x04
      0044F1 12 47 C5         [24]  902 	lcall	_ak820_outline_0018
      0044F4 60 03            [24]  903 	jz	00114$
      0044F6 BD FF 04         [24]  904 	cjne	r5,#0xff,00115$
      0044F9                        905 00114$:
      0044F9 75 82 01         [24]  906 	mov	dpl, #0x01
      0044FC 22               [24]  907 	ret
      0044FD                        908 00115$:
                                    909 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      0044FD ED               [12]  910 	mov	a,r5
      0044FE 12 48 24         [24]  911 	lcall	_ak820_outline_0079
      004501 30 E1 13         [24]  912 	jnb	acc.1,00120$
                                    913 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004504 74 05            [12]  914 	mov	a,#0x05
      004506 2E               [12]  915 	add	a, r6
      004507 12 38 1F         [24]  916 	lcall	_ak820_outline_0015
      00450A 70 07            [24]  917 	jnz	00118$
      00450C 74 FD            [12]  918 	mov	a,#0xfd
      00450E 5B               [12]  919 	anl	a,r3
      00450F 12 38 97         [24]  920 	lcall	_ak820_outline_0124
      004512 F0               [24]  921 	movx	@dptr,a
      004513                        922 00118$:
                                    923 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      004513 75 82 00         [24]  924 	mov	dpl, #0x00
      004516 22               [24]  925 	ret
      004517                        926 00120$:
                                    927 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004517 12 43 01         [24]  928 	lcall	_ak820_outline_0011
      00451A E0               [24]  929 	movx	a,@dptr
      00451B FF               [12]  930 	mov	r7,a
      00451C 8B 06            [24]  931 	mov	ar6,r3
      00451E 53 06 01         [24]  932 	anl	ar6,#0x01
      004521 EE               [12]  933 	mov	a,r6
      004522 B4 01 00         [24]  934 	cjne	a,#0x01,00231$
      004525                        935 00231$:
      004525 B3               [12]  936 	cpl	c
      004526 92 0E            [24]  937 	mov	_ak820_tapping_before_sloc0_1_0,c
      004528 8F F0            [24]  938 	mov	b,r7
      00452A E4               [12]  939 	clr	a
      00452B 33               [12]  940 	rlc	a
      00452C B5 F0 04         [24]  941 	cjne	a,b,00122$
      00452F 75 82 00         [24]  942 	mov	dpl, #0x00
      004532 22               [24]  943 	ret
      004533                        944 00122$:
                                    945 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      004533 63 03 01         [24]  946 	xrl	ar3,#0x01
      004536 12 38 97         [24]  947 	lcall	_ak820_outline_0124
      004539 EB               [12]  948 	mov	a,r3
      00453A F0               [24]  949 	movx	@dptr,a
                                    950 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      00453B 75 82 01         [24]  951 	mov	dpl, #0x01
                                    952 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      00453E 22               [24]  953 	ret
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    956 ;------------------------------------------------------------
                                    957 ;sloc0         Allocated with name '_ak820_tapping_process_sloc0_1_0'
                                    958 ;record        Allocated with name '_ak820_tapping_process_record_10000_622'
                                    959 ;id            Allocated with name '_ak820_tapping_process_id_10000_623'
                                    960 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_623'
                                    961 ;code          Allocated with name '_ak820_tapping_process_code_10000_623'
                                    962 ;------------------------------------------------------------
                                    963 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    964 ;	-----------------------------------------
                                    965 ;	 function ak820_tapping_process
                                    966 ;	-----------------------------------------
      00453F                        967 _ak820_tapping_process:
      00453F 12 38 8D         [24]  968 	lcall	_ak820_outline_0108
      004542 90 06 2D         [24]  969 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004545 12 38 88         [24]  970 	lcall	_ak820_outline_0107
                                    971 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      004548 90 06 2D         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00454B 12 38 41         [24]  973 	lcall	_ak820_outline_0051
      00454E 74 04            [12]  974 	mov	a,#0x04
      004550 12 48 04         [24]  975 	lcall	_ak820_outline_0032
      004553 70 04            [24]  976 	jnz	00102$
      004555 75 82 01         [24]  977 	mov	dpl, #0x01
      004558 22               [24]  978 	ret
      004559                        979 00102$:
                                    980 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      004559 8E 04            [24]  981 	mov	ar4,r6
      00455B 8F 05            [24]  982 	mov	ar5,r7
      00455D 12 47 DF         [24]  983 	lcall	_ak820_outline_0024
      004560 C0 07            [24]  984 	push	ar7
      004562 C0 06            [24]  985 	push	ar6
      004564 12 B7 19         [24]  986 	lcall	___memcpy
      004567 12 43 8D         [24]  987 	lcall	_ak820_tapping_source
      00456A AD 82            [24]  988 	mov	r5, dpl
      00456C D0 06            [24]  989 	pop	ar6
      00456E D0 07            [24]  990 	pop	ar7
                                    991 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      004570 BD FF 04         [24]  992 	cjne	r5,#0xff,00104$
      004573 75 82 01         [24]  993 	mov	dpl, #0x01
      004576 22               [24]  994 	ret
      004577                        995 00104$:
                                    996 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      004577 74 07            [12]  997 	mov	a,#0x07
      004579 12 38 31         [24]  998 	lcall	_ak820_outline_0023
      00457C E0               [24]  999 	movx	a,@dptr
      00457D F5 15            [12] 1000 	mov	_ak820_tapping_process_sloc0_1_0,a
      00457F A3               [24] 1001 	inc	dptr
      004580 E0               [24] 1002 	movx	a,@dptr
      004581 F5 16            [12] 1003 	mov	(_ak820_tapping_process_sloc0_1_0 + 1),a
                                   1004 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      004583 AC 16            [24] 1005 	mov	r4,(_ak820_tapping_process_sloc0_1_0 + 1)
                                   1006 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      004585 BC 20 00         [24] 1007 	cjne	r4,#0x20,00189$
      004588                       1008 00189$:
      004588 40 05            [24] 1009 	jc	00105$
      00458A BC 50 00         [24] 1010 	cjne	r4,#0x50,00191$
      00458D                       1011 00191$:
      00458D 40 04            [24] 1012 	jc	00106$
      00458F                       1013 00105$:
      00458F 75 82 01         [24] 1014 	mov	dpl, #0x01
      004592 22               [24] 1015 	ret
      004593                       1016 00106$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004593 BC 40 00         [24] 1018 	cjne	r4,#0x40,00193$
      004596                       1019 00193$:
      004596 40 0C            [24] 1020 	jc	00109$
      004598 53 04 0F         [24] 1021 	anl	ar4,#0x0f
      00459B BC 06 00         [24] 1022 	cjne	r4,#0x06,00195$
      00459E                       1023 00195$:
      00459E 40 04            [24] 1024 	jc	00109$
      0045A0 75 82 00         [24] 1025 	mov	dpl, #0x00
      0045A3 22               [24] 1026 	ret
      0045A4                       1027 00109$:
                                   1028 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      0045A4 90 06 2D         [24] 1029 	mov	dptr,#_ak820_tapping_process_record_10000_622
      0045A7 12 38 82         [24] 1030 	lcall	_ak820_outline_0103
      0045AA 74 05            [12] 1031 	mov	a,#0x05
      0045AC 2B               [12] 1032 	add	a, r3
      0045AD F9               [12] 1033 	mov	r1,a
      0045AE E4               [12] 1034 	clr	a
      0045AF 3C               [12] 1035 	addc	a, r4
      0045B0 FA               [12] 1036 	mov	r2,a
      0045B1 12 43 6D         [24] 1037 	lcall	_ak820_outline_0149
      0045B4 E0               [24] 1038 	movx	a,@dptr
      0045B5 60 22            [24] 1039 	jz	00119$
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      0045B7 90 0D AA         [24] 1041 	mov	dptr,#_pending
      0045BA ED               [12] 1042 	mov	a,r5
      0045BB 12 48 3A         [24] 1043 	lcall	_ak820_outline_0122
                                   1044 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      0045BE A3               [24] 1045 	inc	dptr
      0045BF A3               [24] 1046 	inc	dptr
      0045C0 E0               [24] 1047 	movx	a,@dptr
      0045C1 F8               [12] 1048 	mov	r0,a
      0045C2 A3               [24] 1049 	inc	dptr
      0045C3 E0               [24] 1050 	movx	a,@dptr
      0045C4 FF               [12] 1051 	mov	r7,a
      0045C5 90 06 20         [24] 1052 	mov	dptr,#_pending_time
      0045C8 E8               [12] 1053 	mov	a,r0
      0045C9 12 38 88         [24] 1054 	lcall	_ak820_outline_0107
                                   1055 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      0045CC 90 06 22         [24] 1056 	mov	dptr,#_pending_code
      0045CF E5 15            [12] 1057 	mov	a,_ak820_tapping_process_sloc0_1_0
      0045D1 F0               [24] 1058 	movx	@dptr,a
      0045D2 E5 16            [12] 1059 	mov	a,(_ak820_tapping_process_sloc0_1_0 + 1)
      0045D4 A3               [24] 1060 	inc	dptr
      0045D5 F0               [24] 1061 	movx	@dptr,a
      0045D6 02 46 5C         [24] 1062 	ljmp	00120$
      0045D9                       1063 00119$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      0045D9 90 0D AA         [24] 1065 	mov	dptr,#_pending
      0045DC E0               [24] 1066 	movx	a,@dptr
      0045DD FF               [12] 1067 	mov	r7,a
      0045DE ED               [12] 1068 	mov	a,r5
      0045DF B5 07 54         [24] 1069 	cjne	a,ar7,00116$
                                   1070 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      0045E2 12 48 40         [24] 1071 	lcall	_ak820_outline_0155
                                   1072 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      0045E5 74 07            [12] 1073 	mov	a,#0x07
      0045E7 12 48 32         [24] 1074 	lcall	_ak820_outline_0118
      0045EA AE 15            [24] 1075 	mov	r6,_ak820_tapping_process_sloc0_1_0
      0045EC 7F 00            [12] 1076 	mov	r7,#0x00
      0045EE 12 48 17         [24] 1077 	lcall	_ak820_outline_0059
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      0045F1 C3               [12] 1079 	clr	c
      0045F2 04               [12] 1080 	inc	a
      0045F3 9E               [12] 1081 	subb	a,r6
      0045F4 50 66            [24] 1082 	jnc	00120$
                                   1083 ;	free result
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      0045F6 74 06            [12] 1085 	mov	a,#0x06
      0045F8 12 48 32         [24] 1086 	lcall	_ak820_outline_0118
      0045FB E0               [24] 1087 	movx	a,@dptr
      0045FC 54 0F            [12] 1088 	anl	a,#0x0f
      0045FE 44 10            [12] 1089 	orl	a,#0x10
      004600 F0               [24] 1090 	movx	@dptr,a
                                   1091 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      004601 12 43 6D         [24] 1092 	lcall	_ak820_outline_0149
      004604 74 01            [12] 1093 	mov	a,#0x01
      004606 F0               [24] 1094 	movx	@dptr,a
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      004607 8B 00            [24] 1096 	mov	ar0,r3
      004609 8C 06            [24] 1097 	mov	ar6,r4
      00460B 7F 00            [12] 1098 	mov	r7,#0x00
      00460D 88 82            [24] 1099 	mov	dpl, r0
      00460F 8E 83            [24] 1100 	mov	dph, r6
      004611 8F F0            [24] 1101 	mov	b, r7
      004613 C0 04            [24] 1102 	push	ar4
      004615 C0 03            [24] 1103 	push	ar3
      004617 C0 02            [24] 1104 	push	ar2
      004619 C0 01            [24] 1105 	push	ar1
      00461B 12 70 1E         [24] 1106 	lcall	_process_record
      00461E D0 01            [24] 1107 	pop	ar1
      004620 D0 02            [24] 1108 	pop	ar2
      004622 D0 03            [24] 1109 	pop	ar3
      004624 D0 04            [24] 1110 	pop	ar4
                                   1111 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      004626 12 43 6D         [24] 1112 	lcall	_ak820_outline_0149
      004629 E4               [12] 1113 	clr	a
      00462A F0               [24] 1114 	movx	@dptr,a
                                   1115 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      00462B FF               [12] 1116 	mov	r7,a
      00462C 12 33 FC         [24] 1117 	lcall	_ak820_outline_0123
      00462F 8F F0            [24] 1118 	mov	b, r7
      004631 12 70 1E         [24] 1119 	lcall	_process_record
      004634 80 26            [24] 1120 	sjmp	00120$
      004636                       1121 00116$:
                                   1122 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      004636 ED               [12] 1123 	mov	a,r5
      004637 24 9E            [12] 1124 	add	a, #_source_state
      004639 FE               [12] 1125 	mov	r6,a
      00463A E4               [12] 1126 	clr	a
      00463B 34 05            [12] 1127 	addc	a, #(_source_state >> 8)
      00463D FF               [12] 1128 	mov	r7,a
      00463E 12 38 92         [24] 1129 	lcall	_ak820_outline_0117
      004641 E0               [24] 1130 	movx	a,@dptr
      004642 FD               [12] 1131 	mov	r5,a
      004643 30 E2 16         [24] 1132 	jnb	acc.2,00120$
                                   1133 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      004646 53 05 FB         [24] 1134 	anl	ar5,#0xfb
      004649 12 38 92         [24] 1135 	lcall	_ak820_outline_0117
      00464C ED               [12] 1136 	mov	a,r5
      00464D F0               [24] 1137 	movx	@dptr,a
                                   1138 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      00464E 90 06 26         [24] 1139 	mov	dptr,#_hold_PARM_2
      004651 E4               [12] 1140 	clr	a
      004652 F0               [24] 1141 	movx	@dptr,a
      004653 85 15 82         [24] 1142 	mov	dpl, _ak820_tapping_process_sloc0_1_0
      004656 85 16 83         [24] 1143 	mov	dph, (_ak820_tapping_process_sloc0_1_0 + 1)
      004659 12 43 C7         [24] 1144 	lcall	_hold
      00465C                       1145 00120$:
                                   1146 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      00465C 75 82 00         [24] 1147 	mov	dpl, #0x00
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      00465F 22               [24] 1149 	ret
                                   1150 ;------------------------------------------------------------
                                   1151 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1152 ;------------------------------------------------------------
                                   1153 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_638'
                                   1154 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_639'
                                   1155 ;------------------------------------------------------------
                                   1156 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1157 ;	-----------------------------------------
                                   1158 ;	 function ak820_tapping_cancel
                                   1159 ;	-----------------------------------------
      004660                       1160 _ak820_tapping_cancel:
                                   1161 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      004660 12 48 40         [24] 1162 	lcall	_ak820_outline_0155
                                   1163 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004663 7F 00            [12] 1164 	mov	r7,#0x00
      004665                       1165 00103$:
      004665 BF 82 00         [24] 1166 	cjne	r7,#0x82,00122$
      004668                       1167 00122$:
      004668 50 16            [24] 1168 	jnc	00105$
                                   1169 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      00466A 12 47 D0         [24] 1170 	lcall	_ak820_outline_0020
                                   1171 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      00466D 74 02            [12] 1172 	mov	a,#0x02
      00466F 5C               [12] 1173 	anl	a,r4
      004670 FB               [12] 1174 	mov	r3,a
      004671 53 04 01         [24] 1175 	anl	ar4,#0x01
      004674 EC               [12] 1176 	mov	a,r4
      004675 2C               [12] 1177 	add	a,r4
      004676 42 03            [12] 1178 	orl	ar3,a
      004678 12 38 A1         [24] 1179 	lcall	_ak820_outline_0135
      00467B EB               [12] 1180 	mov	a,r3
      00467C F0               [24] 1181 	movx	@dptr,a
                                   1182 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      00467D 0F               [12] 1183 	inc	r7
      00467E 80 E5            [24] 1184 	sjmp	00103$
      004680                       1185 00105$:
                                   1186 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      004680 22               [24] 1187 	ret
                                   1188 ;------------------------------------------------------------
                                   1189 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1190 ;------------------------------------------------------------
                                   1191 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1192 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1193 ;code          Allocated with name '_ak820_oneshot_process_code_10000_640'
                                   1194 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_641'
                                   1195 ;i             Allocated with name '_ak820_oneshot_process_i_40000_655'
                                   1196 ;------------------------------------------------------------
                                   1197 ;	keyboards/ajazz/ak820/ak820_tapping.c:143: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1198 ;	-----------------------------------------
                                   1199 ;	 function ak820_oneshot_process
                                   1200 ;	-----------------------------------------
      004681                       1201 _ak820_oneshot_process:
      004681 12 38 8D         [24] 1202 	lcall	_ak820_outline_0108
      004684 90 06 33         [24] 1203 	mov	dptr,#_ak820_oneshot_process_code_10000_640
      004687 12 38 88         [24] 1204 	lcall	_ak820_outline_0107
                                   1205 ;	keyboards/ajazz/ak820/ak820_tapping.c:145: if (id == NONE || get_repeat_key_count()) return true;
      00468A 90 06 31         [24] 1206 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00468D E0               [24] 1207 	movx	a,@dptr
      00468E FF               [12] 1208 	mov	r7,a
      00468F BF FF 02         [24] 1209 	cjne	r7,#0xff,00248$
      004692 80 0B            [24] 1210 	sjmp	00101$
      004694                       1211 00248$:
      004694 C0 07            [24] 1212 	push	ar7
      004696 12 A0 F8         [24] 1213 	lcall	_get_repeat_key_count
      004699 E5 82            [12] 1214 	mov	a, dpl
      00469B D0 07            [24] 1215 	pop	ar7
      00469D 60 04            [24] 1216 	jz	00102$
      00469F                       1217 00101$:
      00469F 75 82 01         [24] 1218 	mov	dpl, #0x01
      0046A2 22               [24] 1219 	ret
      0046A3                       1220 00102$:
                                   1221 ;	keyboards/ajazz/ak820/ak820_tapping.c:158: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      0046A3 90 06 33         [24] 1222 	mov	dptr,#_ak820_oneshot_process_code_10000_640
      0046A6 E0               [24] 1223 	movx	a,@dptr
      0046A7 FD               [12] 1224 	mov	r5,a
      0046A8 A3               [24] 1225 	inc	dptr
      0046A9 E0               [24] 1226 	movx	a,@dptr
      0046AA FB               [12] 1227 	mov	r3,a
      0046AB BB 52 02         [24] 1228 	cjne	r3,#0x52,00250$
      0046AE 80 03            [24] 1229 	sjmp	00251$
      0046B0                       1230 00250$:
      0046B0 02 47 55         [24] 1231 	ljmp	00116$
      0046B3                       1232 00251$:
      0046B3 8D 04            [24] 1233 	mov	ar4,r5
      0046B5 53 04 E0         [24] 1234 	anl	ar4,#0xe0
      0046B8 BC A0 02         [24] 1235 	cjne	r4,#0xa0,00252$
      0046BB 80 03            [24] 1236 	sjmp	00253$
      0046BD                       1237 00252$:
      0046BD 02 47 55         [24] 1238 	ljmp	00116$
      0046C0                       1239 00253$:
                                   1240 ;	keyboards/ajazz/ak820/ak820_tapping.c:159: mods = code & 15;
      0046C0 8D 04            [24] 1241 	mov	ar4,r5
      0046C2 53 04 0F         [24] 1242 	anl	ar4,#0x0f
      0046C5 90 06 35         [24] 1243 	mov	dptr,#_ak820_oneshot_process_mods_10000_641
      0046C8 EC               [12] 1244 	mov	a,r4
      0046C9 F0               [24] 1245 	movx	@dptr,a
                                   1246 ;	keyboards/ajazz/ak820/ak820_tapping.c:160: if (code & 16) mods <<= 4;
      0046CA ED               [12] 1247 	mov	a,r5
      0046CB 30 E4 08         [24] 1248 	jnb	acc.4,00105$
      0046CE EC               [12] 1249 	mov	a,r4
      0046CF C4               [12] 1250 	swap	a
      0046D0 54 F0            [12] 1251 	anl	a,#0xf0
      0046D2 90 06 35         [24] 1252 	mov	dptr,#_ak820_oneshot_process_mods_10000_641
      0046D5 F0               [24] 1253 	movx	@dptr,a
      0046D6                       1254 00105$:
                                   1255 ;	keyboards/ajazz/ak820/ak820_tapping.c:161: if (pressed) {
      0046D6 90 06 32         [24] 1256 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0046D9 E0               [24] 1257 	movx	a,@dptr
      0046DA 60 2D            [24] 1258 	jz	00113$
                                   1259 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: source_state[id] |= SOURCE_ONESHOT;
      0046DC 12 47 D0         [24] 1260 	lcall	_ak820_outline_0020
      0046DF 43 04 08         [24] 1261 	orl	ar4,#0x08
      0046E2 12 43 37         [24] 1262 	lcall	_ak820_outline_0063
                                   1263 ;	keyboards/ajazz/ak820/ak820_tapping.c:163: source_state[id] &= ~SOURCE_ONESHOT_USED;
      0046E5 53 04 EF         [24] 1264 	anl	ar4,#0xef
      0046E8 12 43 37         [24] 1265 	lcall	_ak820_outline_0063
                                   1266 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      0046EB 90 0D AB         [24] 1267 	mov	dptr,#_ak820_oneshot_target
      0046EE E0               [24] 1268 	movx	a,@dptr
      0046EF FC               [12] 1269 	mov	r4,a
      0046F0 BC FF 02         [24] 1270 	cjne	r4,#0xff,00256$
      0046F3 80 09            [24] 1271 	sjmp	00107$
      0046F5                       1272 00256$:
      0046F5 12 48 1D         [24] 1273 	lcall	_ak820_outline_0076
      0046F8 43 04 10         [24] 1274 	orl	ar4,#0x10
      0046FB 12 43 37         [24] 1275 	lcall	_ak820_outline_0063
      0046FE                       1276 00107$:
                                   1277 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: register_mods(mods);
      0046FE 90 06 35         [24] 1278 	mov	dptr,#_ak820_oneshot_process_mods_10000_641
      004701 E0               [24] 1279 	movx	a,@dptr
      004702 F5 82            [12] 1280 	mov	dpl,a
      004704 12 75 81         [24] 1281 	lcall	_register_mods
      004707 80 48            [24] 1282 	sjmp	00114$
      004709                       1283 00113$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: } else if (source_state[id] & SOURCE_ONESHOT) {
      004709 12 47 D0         [24] 1285 	lcall	_ak820_outline_0020
      00470C 30 E3 42         [24] 1286 	jnb	acc.3,00114$
                                   1287 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      00470F EC               [12] 1288 	mov	a,r4
      004710 20 E4 24         [24] 1289 	jb	acc.4,00109$
                                   1290 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: add_owned_mods(mods & ~ak820_oneshot_mods);
      004713 90 06 2F         [24] 1291 	mov	dptr,#_ak820_oneshot_mods
      004716 E0               [24] 1292 	movx	a,@dptr
      004717 F4               [12] 1293 	cpl	a
      004718 FC               [12] 1294 	mov	r4,a
      004719 90 06 35         [24] 1295 	mov	dptr,#_ak820_oneshot_process_mods_10000_641
      00471C E0               [24] 1296 	movx	a,@dptr
      00471D FB               [12] 1297 	mov	r3,a
      00471E 52 04            [12] 1298 	anl	ar4,a
      004720 8C 82            [24] 1299 	mov	dpl, r4
      004722 C0 06            [24] 1300 	push	ar6
      004724 C0 05            [24] 1301 	push	ar5
      004726 C0 03            [24] 1302 	push	ar3
      004728 12 7B F0         [24] 1303 	lcall	_add_owned_mods
      00472B D0 03            [24] 1304 	pop	ar3
      00472D D0 05            [24] 1305 	pop	ar5
      00472F D0 06            [24] 1306 	pop	ar6
                                   1307 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: ak820_oneshot_mods |= mods;
      004731 90 06 2F         [24] 1308 	mov	dptr,#_ak820_oneshot_mods
      004734 E0               [24] 1309 	movx	a,@dptr
      004735 4B               [12] 1310 	orl	a,r3
      004736 F0               [24] 1311 	movx	@dptr,a
      004737                       1312 00109$:
                                   1313 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: unregister_mods(mods);
      004737 90 06 35         [24] 1314 	mov	dptr,#_ak820_oneshot_process_mods_10000_641
      00473A E0               [24] 1315 	movx	a,@dptr
      00473B F5 82            [12] 1316 	mov	dpl,a
      00473D C0 06            [24] 1317 	push	ar6
      00473F C0 05            [24] 1318 	push	ar5
      004741 12 75 95         [24] 1319 	lcall	_unregister_mods
      004744 D0 05            [24] 1320 	pop	ar5
      004746 D0 06            [24] 1321 	pop	ar6
                                   1322 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004748 12 48 1D         [24] 1323 	lcall	_ak820_outline_0076
      00474B 53 04 E7         [24] 1324 	anl	ar4,#0xe7
      00474E 12 43 37         [24] 1325 	lcall	_ak820_outline_0063
      004751                       1326 00114$:
                                   1327 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: return false;
      004751 75 82 00         [24] 1328 	mov	dpl, #0x00
      004754 22               [24] 1329 	ret
      004755                       1330 00116$:
                                   1331 ;	keyboards/ajazz/ak820/ak820_tapping.c:176: if (pressed && code > KC_TRANSPARENT &&
      004755 90 06 32         [24] 1332 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004758 E0               [24] 1333 	movx	a,@dptr
      004759 60 5C            [24] 1334 	jz	00124$
      00475B 90 06 33         [24] 1335 	mov	dptr,#_ak820_oneshot_process_code_10000_640
      00475E 12 38 64         [24] 1336 	lcall	_ak820_outline_0078
      004761 C3               [12] 1337 	clr	c
      004762 74 01            [12] 1338 	mov	a,#0x01
      004764 9D               [12] 1339 	subb	a,r5
      004765 E4               [12] 1340 	clr	a
      004766 9E               [12] 1341 	subb	a,r6
      004767 50 4E            [24] 1342 	jnc	00124$
                                   1343 ;	free result
                                   1344 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004769 C3               [12] 1345 	clr	c
      00476A ED               [12] 1346 	mov	a,r5
      00476B 94 E0            [12] 1347 	subb	a,#0xe0
      00476D EE               [12] 1348 	mov	a,r6
      00476E 94 00            [12] 1349 	subb	a,#0x00
      004770 40 07            [24] 1350 	jc	00129$
      004772 74 E7            [12] 1351 	mov	a,#0xe7
      004774 9D               [12] 1352 	subb	a,r5
      004775 E4               [12] 1353 	clr	a
      004776 9E               [12] 1354 	subb	a,r6
      004777 50 3E            [24] 1355 	jnc	00124$
                                   1356 ;	free result
      004779                       1357 00129$:
                                   1358 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004779 74 AE            [12] 1359 	mov	a,#0x100 - 0x52
      00477B 2E               [12] 1360 	add	a,r6
      00477C 50 09            [24] 1361 	jnc	00165$
      00477E C3               [12] 1362 	clr	c
      00477F 74 DF            [12] 1363 	mov	a,#0xdf
      004781 9D               [12] 1364 	subb	a,r5
      004782 74 52            [12] 1365 	mov	a,#0x52
      004784 9E               [12] 1366 	subb	a,r6
      004785 50 30            [24] 1367 	jnc	00124$
                                   1368 ;	free result
                                   1369 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: for (uint8_t i = 0; i < SOURCES; ++i)
      004787                       1370 00165$:
      004787 7E 00            [12] 1371 	mov	r6,#0x00
      004789                       1372 00131$:
      004789 BE 82 00         [24] 1373 	cjne	r6,#0x82,00265$
      00478C                       1374 00265$:
      00478C 50 12            [24] 1375 	jnc	00120$
                                   1376 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      00478E EE               [12] 1377 	mov	a,r6
      00478F 12 48 24         [24] 1378 	lcall	_ak820_outline_0079
      004792 30 E3 08         [24] 1379 	jnb	acc.3,00132$
      004795 43 03 10         [24] 1380 	orl	ar3,#0x10
      004798 12 38 97         [24] 1381 	lcall	_ak820_outline_0124
      00479B EB               [12] 1382 	mov	a,r3
      00479C F0               [24] 1383 	movx	@dptr,a
      00479D                       1384 00132$:
                                   1385 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: for (uint8_t i = 0; i < SOURCES; ++i)
      00479D 0E               [12] 1386 	inc	r6
      00479E 80 E9            [24] 1387 	sjmp	00131$
      0047A0                       1388 00120$:
                                   1389 ;	keyboards/ajazz/ak820/ak820_tapping.c:181: if (ak820_oneshot_mods) {
      0047A0 90 06 2F         [24] 1390 	mov	dptr,#_ak820_oneshot_mods
      0047A3 E0               [24] 1391 	movx	a,@dptr
      0047A4 FE               [12] 1392 	mov	r6,a
      0047A5 E0               [24] 1393 	movx	a,@dptr
      0047A6 60 0F            [24] 1394 	jz	00124$
                                   1395 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: ak820_oneshot_consumed = ak820_oneshot_mods;
      0047A8 90 06 30         [24] 1396 	mov	dptr,#_ak820_oneshot_consumed
      0047AB EE               [12] 1397 	mov	a,r6
      0047AC F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: ak820_oneshot_target = id;
      0047AD 90 0D AB         [24] 1400 	mov	dptr,#_ak820_oneshot_target
      0047B0 EF               [12] 1401 	mov	a,r7
      0047B1 F0               [24] 1402 	movx	@dptr,a
                                   1403 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: ak820_oneshot_mods = 0;
      0047B2 90 06 2F         [24] 1404 	mov	dptr,#_ak820_oneshot_mods
      0047B5 E4               [12] 1405 	clr	a
      0047B6 F0               [24] 1406 	movx	@dptr,a
      0047B7                       1407 00124$:
                                   1408 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: return true;
      0047B7 75 82 01         [24] 1409 	mov	dpl, #0x01
                                   1410 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: }
      0047BA 22               [24] 1411 	ret
                                   1412 	.area CSEG    (CODE)
                                   1413 	.area CONST   (CODE)
                                   1414 	.area XINIT   (CODE)
      00BFD9                       1415 __xinit__pending:
      00BFD9 FF                    1416 	.db #0xff	; 255
      00BFDA                       1417 __xinit__ak820_oneshot_target:
      00BFDA FF                    1418 	.db #0xff	; 255
                                   1419 	.area CABS    (ABS,CODE)
                                   1420 
                                   1421 ; Experimental exact instruction outlining.
                                   1422 	.globl _ak820_outline_0008
                                   1423 	.globl _ak820_outline_0009
                                   1424 	.globl _ak820_outline_0011
                                   1425 	.globl _ak820_outline_0015
                                   1426 	.globl _ak820_outline_0018
                                   1427 	.globl _ak820_outline_0020
                                   1428 	.globl _ak820_outline_0023
                                   1429 	.globl _ak820_outline_0024
                                   1430 	.globl _ak820_outline_0031
                                   1431 	.globl _ak820_outline_0032
                                   1432 	.globl _ak820_outline_0036
                                   1433 	.globl _ak820_outline_0051
                                   1434 	.globl _ak820_outline_0055
                                   1435 	.globl _ak820_outline_0059
                                   1436 	.globl _ak820_outline_0063
                                   1437 	.globl _ak820_outline_0072
                                   1438 	.globl _ak820_outline_0076
                                   1439 	.globl _ak820_outline_0078
                                   1440 	.globl _ak820_outline_0079
                                   1441 	.globl _ak820_outline_0101
                                   1442 	.globl _ak820_outline_0103
                                   1443 	.globl _ak820_outline_0107
                                   1444 	.globl _ak820_outline_0108
                                   1445 	.globl _ak820_outline_0117
                                   1446 	.globl _ak820_outline_0118
                                   1447 	.globl _ak820_outline_0122
                                   1448 	.globl _ak820_outline_0123
                                   1449 	.globl _ak820_outline_0124
                                   1450 	.globl _ak820_outline_0135
                                   1451 	.globl _ak820_outline_0149
                                   1452 	.globl _ak820_outline_0155
                                   1453 	.globl _ak820_outline_0158
                                   1454 	.globl _ak820_outline_0190
                                   1455 
                                   1456 	.area CSEG (CODE)
                                   1457 ; function ak820_outline_0008
      0047BB                       1458 _ak820_outline_0008:
      0047BB E0               [24] 1459 	movx	a,@dptr
      0047BC FE               [12] 1460 	mov	r6,a
      0047BD A3               [24] 1461 	inc	dptr
      0047BE E0               [24] 1462 	movx	a,@dptr
      0047BF FF               [12] 1463 	mov	r7,a
      0047C0 8E 04            [24] 1464 	mov	ar4,r6
      0047C2 8F 05            [24] 1465 	mov	ar5,r7
      0047C4 22               [24] 1466 	ret
                                   1467 
                                   1468 	.area CSEG (CODE)
                                   1469 ; function ak820_outline_0018
      0047C5                       1470 _ak820_outline_0018:
      0047C5 2E               [12] 1471 	add	a,r6
      0047C6 FB               [12] 1472 	mov	r3,a
      0047C7 E4               [12] 1473 	clr	a
      0047C8 3F               [12] 1474 	addc	a,r7
      0047C9 FC               [12] 1475 	mov	r4,a
      0047CA 8B 82            [24] 1476 	mov	dpl,r3
      0047CC 8C 83            [24] 1477 	mov	dph,r4
      0047CE E0               [24] 1478 	movx	a,@dptr
      0047CF 22               [24] 1479 	ret
                                   1480 
                                   1481 	.area CSEG (CODE)
                                   1482 ; function ak820_outline_0020
      0047D0                       1483 _ak820_outline_0020:
      0047D0 EF               [12] 1484 	mov	a,r7
      0047D1 24 9E            [12] 1485 	add	a,#_source_state
      0047D3 FD               [12] 1486 	mov	r5,a
      0047D4 E4               [12] 1487 	clr	a
      0047D5 34 05            [12] 1488 	addc	a,#(_source_state>>8)
      0047D7 FE               [12] 1489 	mov	r6,a
      0047D8 8D 82            [24] 1490 	mov	dpl,r5
      0047DA 8E 83            [24] 1491 	mov	dph,r6
      0047DC E0               [24] 1492 	movx	a,@dptr
      0047DD FC               [12] 1493 	mov	r4,a
      0047DE 22               [24] 1494 	ret
                                   1495 
                                   1496 	.area CSEG (CODE)
                                   1497 ; function ak820_outline_0024
      0047DF                       1498 _ak820_outline_0024:
      0047DF 90 0D 9A         [24] 1499 	mov	dptr,#___memcpy_PARM_2
      0047E2 EC               [12] 1500 	mov	a,r4
      0047E3 F0               [24] 1501 	movx	@dptr,a
      0047E4 ED               [12] 1502 	mov	a,r5
      0047E5 A3               [24] 1503 	inc	dptr
      0047E6 F0               [24] 1504 	movx	@dptr,a
      0047E7 E4               [12] 1505 	clr	a
      0047E8 A3               [24] 1506 	inc	dptr
      0047E9 F0               [24] 1507 	movx	@dptr,a
      0047EA 90 0D 9D         [24] 1508 	mov	dptr,#___memcpy_PARM_3
      0047ED 74 02            [12] 1509 	mov	a,#0x02
      0047EF F0               [24] 1510 	movx	@dptr,a
      0047F0 E4               [12] 1511 	clr	a
      0047F1 A3               [24] 1512 	inc	dptr
      0047F2 F0               [24] 1513 	movx	@dptr,a
      0047F3 90 06 24         [24] 1514 	mov	dptr,#_ak820_tapping_source_PARM_1
      0047F6 F5 F0            [12] 1515 	mov	b,a
      0047F8 22               [24] 1516 	ret
                                   1517 
                                   1518 	.area CSEG (CODE)
                                   1519 ; function ak820_outline_0031
      0047F9                       1520 _ak820_outline_0031:
      0047F9 2E               [12] 1521 	add	a,r6
      0047FA FA               [12] 1522 	mov	r2,a
      0047FB E4               [12] 1523 	clr	a
      0047FC 3F               [12] 1524 	addc	a,r7
      0047FD FB               [12] 1525 	mov	r3,a
      0047FE 8A 82            [24] 1526 	mov	dpl,r2
      004800 8B 83            [24] 1527 	mov	dph,r3
      004802 E0               [24] 1528 	movx	a,@dptr
      004803 22               [24] 1529 	ret
                                   1530 
                                   1531 	.area CSEG (CODE)
                                   1532 ; function ak820_outline_0032
      004804                       1533 _ak820_outline_0032:
      004804 2E               [12] 1534 	add	a,r6
      004805 FC               [12] 1535 	mov	r4,a
      004806 E4               [12] 1536 	clr	a
      004807 3F               [12] 1537 	addc	a,r7
      004808 FD               [12] 1538 	mov	r5,a
      004809 8C 82            [24] 1539 	mov	dpl,r4
      00480B 8D 83            [24] 1540 	mov	dph,r5
      00480D E0               [24] 1541 	movx	a,@dptr
      00480E 22               [24] 1542 	ret
                                   1543 
                                   1544 	.area CSEG (CODE)
                                   1545 ; function ak820_outline_0055
      00480F                       1546 _ak820_outline_0055:
      00480F FC               [12] 1547 	mov	r4,a
      004810 8B 82            [24] 1548 	mov	dpl,r3
      004812 8C 83            [24] 1549 	mov	dph,r4
      004814 E0               [24] 1550 	movx	a,@dptr
      004815 FA               [12] 1551 	mov	r2,a
      004816 22               [24] 1552 	ret
                                   1553 
                                   1554 	.area CSEG (CODE)
                                   1555 ; function ak820_outline_0059
      004817                       1556 _ak820_outline_0059:
      004817 EE               [12] 1557 	mov	a,r6
      004818 F0               [24] 1558 	movx	@dptr,a
      004819 EF               [12] 1559 	mov	a,r7
      00481A A3               [24] 1560 	inc	dptr
      00481B F0               [24] 1561 	movx	@dptr,a
      00481C 22               [24] 1562 	ret
                                   1563 
                                   1564 	.area CSEG (CODE)
                                   1565 ; function ak820_outline_0076
      00481D                       1566 _ak820_outline_0076:
      00481D 8D 82            [24] 1567 	mov	dpl,r5
      00481F 8E 83            [24] 1568 	mov	dph,r6
      004821 E0               [24] 1569 	movx	a,@dptr
      004822 FC               [12] 1570 	mov	r4,a
      004823 22               [24] 1571 	ret
                                   1572 
                                   1573 	.area CSEG (CODE)
                                   1574 ; function ak820_outline_0079
      004824                       1575 _ak820_outline_0079:
      004824 24 9E            [12] 1576 	add	a,#_source_state
      004826 FC               [12] 1577 	mov	r4,a
      004827 E4               [12] 1578 	clr	a
      004828 34 05            [12] 1579 	addc	a,#(_source_state>>8)
      00482A FD               [12] 1580 	mov	r5,a
      00482B 8C 82            [24] 1581 	mov	dpl,r4
      00482D 8D 83            [24] 1582 	mov	dph,r5
      00482F E0               [24] 1583 	movx	a,@dptr
      004830 FB               [12] 1584 	mov	r3,a
      004831 22               [24] 1585 	ret
                                   1586 
                                   1587 	.area CSEG (CODE)
                                   1588 ; function ak820_outline_0118
      004832                       1589 _ak820_outline_0118:
      004832 2B               [12] 1590 	add	a,r3
      004833 F5 82            [12] 1591 	mov	dpl,a
      004835 E4               [12] 1592 	clr	a
      004836 3C               [12] 1593 	addc	a,r4
      004837 F5 83            [12] 1594 	mov	dph,a
      004839 22               [24] 1595 	ret
                                   1596 
                                   1597 	.area CSEG (CODE)
                                   1598 ; function ak820_outline_0122
      00483A                       1599 _ak820_outline_0122:
      00483A F0               [24] 1600 	movx	@dptr,a
      00483B 8B 82            [24] 1601 	mov	dpl,r3
      00483D 8C 83            [24] 1602 	mov	dph,r4
      00483F 22               [24] 1603 	ret
                                   1604 
                                   1605 	.area CSEG (CODE)
                                   1606 ; function ak820_outline_0155
      004840                       1607 _ak820_outline_0155:
      004840 90 0D AA         [24] 1608 	mov	dptr,#_pending
      004843 74 FF            [12] 1609 	mov	a,#0xff
      004845 F0               [24] 1610 	movx	@dptr,a
      004846 22               [24] 1611 	ret
