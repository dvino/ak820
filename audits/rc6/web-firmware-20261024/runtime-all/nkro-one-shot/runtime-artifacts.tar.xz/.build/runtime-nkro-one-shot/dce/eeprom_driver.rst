                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00067C                         85 _eeprom_read_word_addr_10000_91:
      00067C                         86 	.ds 3
      00067F                         87 _eeprom_read_word_ret_10000_92:
      00067F                         88 	.ds 2
      000681                         89 _eeprom_read_dword_addr_10000_93:
      000681                         90 	.ds 3
      000684                         91 _eeprom_read_dword_ret_10000_94:
      000684                         92 	.ds 4
      000688                         93 _eeprom_write_byte_PARM_2:
      000688                         94 	.ds 1
      000689                         95 _eeprom_write_byte_addr_10000_95:
      000689                         96 	.ds 3
      00068C                         97 _eeprom_write_word_PARM_2:
      00068C                         98 	.ds 2
      00068E                         99 _eeprom_write_word_addr_10000_97:
      00068E                        100 	.ds 3
      000691                        101 _eeprom_write_dword_PARM_2:
      000691                        102 	.ds 4
      000695                        103 _eeprom_write_dword_addr_10000_99:
      000695                        104 	.ds 3
      000698                        105 _eeprom_update_byte_PARM_2:
      000698                        106 	.ds 1
      000699                        107 _eeprom_update_byte_addr_10000_107:
      000699                        108 	.ds 3
      00069C                        109 _eeprom_update_word_PARM_2:
      00069C                        110 	.ds 2
      00069E                        111 _eeprom_update_word_addr_10000_111:
      00069E                        112 	.ds 3
      0006A1                        113 _eeprom_update_dword_PARM_2:
      0006A1                        114 	.ds 4
      0006A5                        115 _eeprom_update_dword_addr_10000_115:
      0006A5                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004CB8                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004CB8 12 43 13         [24]  170 	lcall	_ak820_outline_0037
      004CBB 90 06 7C         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004CBE 12 38 29         [24]  172 	lcall	_ak820_outline_0016
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004CC1 90 06 7F         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004CC4 12 4E C3         [24]  175 	lcall	_ak820_outline_0183
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004CC7 90 06 7C         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004CCA 12 4E 70         [24]  178 	lcall	_ak820_outline_0012
      004CCD 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004CD0 ED               [12]  180 	mov	a,r5
      004CD1 12 38 29         [24]  181 	lcall	_ak820_outline_0016
      004CD4 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004CD7 12 4E B5         [24]  183 	lcall	_ak820_outline_0110
      004CDA 90 06 7F         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004CDD 12 40 AF         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004CE0 90 06 7F         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004CE3 12 4E AC         [24]  188 	lcall	_ak820_outline_0091
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004CE6 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004CE7                        201 _eeprom_read_dword:
      004CE7 12 43 13         [24]  202 	lcall	_ak820_outline_0037
      004CEA 90 06 81         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004CED 12 38 29         [24]  204 	lcall	_ak820_outline_0016
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004CF0 90 06 84         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004CF3 12 4E 81         [24]  207 	lcall	_ak820_outline_0050
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004CF6 90 06 81         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004CF9 12 4E 70         [24]  210 	lcall	_ak820_outline_0012
      004CFC 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004CFF ED               [12]  212 	mov	a,r5
      004D00 12 38 29         [24]  213 	lcall	_ak820_outline_0016
      004D03 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004D06 74 04            [12]  215 	mov	a,#0x04
      004D08 12 38 9C         [24]  216 	lcall	_ak820_outline_0134
      004D0B 90 06 84         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D0E 12 40 AF         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004D11 90 06 84         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004D14 12 4E 8A         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004D17 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004D18                        234 _eeprom_write_byte:
      004D18 12 43 13         [24]  235 	lcall	_ak820_outline_0037
      004D1B 90 06 89         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004D1E 12 38 29         [24]  237 	lcall	_ak820_outline_0016
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004D21 90 06 89         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004D24 12 4E 59         [24]  240 	lcall	_ak820_outline_0004
      004D27 74 01            [12]  241 	mov	a,#0x01
      004D29 12 38 9C         [24]  242 	lcall	_ak820_outline_0134
      004D2C 90 06 88         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004D2F 02 41 3B         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004D32                        256 _eeprom_write_word:
      004D32 12 43 13         [24]  257 	lcall	_ak820_outline_0037
      004D35 90 06 8E         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004D38 12 38 29         [24]  259 	lcall	_ak820_outline_0016
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004D3B 90 06 8E         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004D3E 12 4E 59         [24]  262 	lcall	_ak820_outline_0004
      004D41 12 4E B5         [24]  263 	lcall	_ak820_outline_0110
      004D44 90 06 8C         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004D47 02 41 3B         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004D4A                        277 _eeprom_write_dword:
      004D4A 12 43 13         [24]  278 	lcall	_ak820_outline_0037
      004D4D 90 06 95         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004D50 12 38 29         [24]  280 	lcall	_ak820_outline_0016
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004D53 90 06 95         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004D56 12 4E 59         [24]  283 	lcall	_ak820_outline_0004
      004D59 74 04            [12]  284 	mov	a,#0x04
      004D5B 12 38 9C         [24]  285 	lcall	_ak820_outline_0134
      004D5E 90 06 91         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004D61 02 41 3B         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004D64                        307 _eeprom_update_byte:
      004D64 C0 07            [24]  308 	push	ar7
      004D66 C0 06            [24]  309 	push	ar6
      004D68 C0 05            [24]  310 	push	ar5
      004D6A C0 04            [24]  311 	push	ar4
      004D6C 12 43 13         [24]  312 	lcall	_ak820_outline_0037
      004D6F 90 06 99         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D72 12 38 29         [24]  314 	lcall	_ak820_outline_0016
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004D75 90 06 99         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D78 12 4E 4A         [24]  317 	lcall	_ak820_outline_0001
      004D7B 12 40 74         [24]  318 	lcall	_eeprom_read_byte
      004D7E AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004D80 90 06 98         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004D83 E0               [24]  322 	movx	a,@dptr
      004D84 FE               [12]  323 	mov	r6,a
      004D85 EF               [12]  324 	mov	a,r7
      004D86 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004D89 80 35            [24]  326 	sjmp	00103$
      004D8B                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004D8B 90 06 99         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004D8E 12 38 58         [24]  330 	lcall	_ak820_outline_0058
      004D91 A3               [24]  331 	inc	dptr
      004D92 E0               [24]  332 	movx	a,@dptr
      004D93 FF               [12]  333 	mov	r7,a
      004D94 90 06 88         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004D97 EE               [12]  335 	mov	a,r6
      004D98 12 38 76         [24]  336 	lcall	_ak820_outline_0100
      004D9B 8F F0            [24]  337 	mov	b, r7
      004D9D C0 07            [24]  338 	push	ar7
      004D9F C0 06            [24]  339 	push	ar6
      004DA1 C0 05            [24]  340 	push	ar5
      004DA3 C0 04            [24]  341 	push	ar4
      004DA5 C0 03            [24]  342 	push	ar3
      004DA7 C0 02            [24]  343 	push	ar2
      004DA9 C0 01            [24]  344 	push	ar1
      004DAB C0 00            [24]  345 	push	ar0
      004DAD 12 4D 18         [24]  346 	lcall	_eeprom_write_byte
      004DB0 D0 00            [24]  347 	pop	ar0
      004DB2 D0 01            [24]  348 	pop	ar1
      004DB4 D0 02            [24]  349 	pop	ar2
      004DB6 D0 03            [24]  350 	pop	ar3
      004DB8 D0 04            [24]  351 	pop	ar4
      004DBA D0 05            [24]  352 	pop	ar5
      004DBC D0 06            [24]  353 	pop	ar6
      004DBE D0 07            [24]  354 	pop	ar7
      004DC0                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      004DC0 D0 04            [24]  357 	pop	ar4
      004DC2 D0 05            [24]  358 	pop	ar5
      004DC4 D0 06            [24]  359 	pop	ar6
      004DC6 D0 07            [24]  360 	pop	ar7
      004DC8 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      004DC9                        373 _eeprom_update_word:
      004DC9 12 43 13         [24]  374 	lcall	_ak820_outline_0037
      004DCC 90 06 9E         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004DCF 12 38 29         [24]  376 	lcall	_ak820_outline_0016
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004DD2 90 06 9E         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004DD5 12 4E 4A         [24]  379 	lcall	_ak820_outline_0001
      004DD8 12 4C B8         [24]  380 	lcall	_eeprom_read_word
      004DDB 12 43 5C         [24]  381 	lcall	_ak820_outline_0133
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004DDE 90 06 9C         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      004DE1 12 38 58         [24]  384 	lcall	_ak820_outline_0058
      004DE4 EE               [12]  385 	mov	a,r6
      004DE5 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      004DE8 EF               [12]  387 	mov	a,r7
      004DE9 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      004DEC 22               [24]  389 	ret
      004DED                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004DED 90 06 9E         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004DF0 E0               [24]  393 	movx	a,@dptr
      004DF1 FB               [12]  394 	mov	r3,a
      004DF2 A3               [24]  395 	inc	dptr
      004DF3 12 38 41         [24]  396 	lcall	_ak820_outline_0051
      004DF6 90 06 8C         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      004DF9 12 38 5E         [24]  398 	lcall	_ak820_outline_0071
      004DFC 8B 82            [24]  399 	mov	dpl, r3
      004DFE 8E 83            [24]  400 	mov	dph, r6
      004E00 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      004E02 02 4D 32         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      004E05                        415 _eeprom_update_dword:
      004E05 12 43 13         [24]  416 	lcall	_ak820_outline_0037
      004E08 90 06 A5         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E0B 12 38 29         [24]  418 	lcall	_ak820_outline_0016
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004E0E 90 06 A5         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E11 12 4E 4A         [24]  421 	lcall	_ak820_outline_0001
      004E14 12 4C E7         [24]  422 	lcall	_eeprom_read_dword
      004E17 12 4E 9B         [24]  423 	lcall	_ak820_outline_0056
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004E1A 90 06 A1         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      004E1D E0               [24]  426 	movx	a,@dptr
      004E1E F8               [12]  427 	mov	r0,a
      004E1F A3               [24]  428 	inc	dptr
      004E20 12 4E A3         [24]  429 	lcall	_ak820_outline_0090
      004E23 EC               [12]  430 	mov	a,r4
      004E24 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      004E27 ED               [12]  432 	mov	a,r5
      004E28 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      004E2B EE               [12]  434 	mov	a,r6
      004E2C B5 02 05         [24]  435 	cjne	a,ar2,00112$
      004E2F EF               [12]  436 	mov	a,r7
      004E30 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      004E33 22               [24]  438 	ret
      004E34                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004E34 90 06 A5         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004E37 12 4E 70         [24]  442 	lcall	_ak820_outline_0012
      004E3A 90 06 91         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      004E3D E8               [12]  444 	mov	a,r0
      004E3E F0               [24]  445 	movx	@dptr,a
      004E3F E9               [12]  446 	mov	a,r1
      004E40 A3               [24]  447 	inc	dptr
      004E41 12 4E BC         [24]  448 	lcall	_ak820_outline_0156
      004E44 12 4E 79         [24]  449 	lcall	_ak820_outline_0033
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      004E47 02 4D 4A         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0012
                                    461 	.globl _ak820_outline_0016
                                    462 	.globl _ak820_outline_0033
                                    463 	.globl _ak820_outline_0037
                                    464 	.globl _ak820_outline_0050
                                    465 	.globl _ak820_outline_0051
                                    466 	.globl _ak820_outline_0054
                                    467 	.globl _ak820_outline_0056
                                    468 	.globl _ak820_outline_0058
                                    469 	.globl _ak820_outline_0071
                                    470 	.globl _ak820_outline_0090
                                    471 	.globl _ak820_outline_0091
                                    472 	.globl _ak820_outline_0100
                                    473 	.globl _ak820_outline_0110
                                    474 	.globl _ak820_outline_0133
                                    475 	.globl _ak820_outline_0134
                                    476 	.globl _ak820_outline_0156
                                    477 	.globl _ak820_outline_0183
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      004E4A                        481 _ak820_outline_0001:
      004E4A E0               [24]  482 	movx	a,@dptr
      004E4B FD               [12]  483 	mov	r5,a
      004E4C A3               [24]  484 	inc	dptr
      004E4D E0               [24]  485 	movx	a,@dptr
      004E4E FE               [12]  486 	mov	r6,a
      004E4F A3               [24]  487 	inc	dptr
      004E50 E0               [24]  488 	movx	a,@dptr
      004E51 FF               [12]  489 	mov	r7,a
      004E52 8D 82            [24]  490 	mov	dpl,r5
      004E54 8E 83            [24]  491 	mov	dph,r6
      004E56 8F F0            [24]  492 	mov	b,r7
      004E58 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      004E59                        497 _ak820_outline_0004:
      004E59 E0               [24]  498 	movx	a,@dptr
      004E5A FD               [12]  499 	mov	r5,a
      004E5B A3               [24]  500 	inc	dptr
      004E5C E0               [24]  501 	movx	a,@dptr
      004E5D FE               [12]  502 	mov	r6,a
      004E5E A3               [24]  503 	inc	dptr
      004E5F E0               [24]  504 	movx	a,@dptr
      004E60 FF               [12]  505 	mov	r7,a
      004E61 90 05 8E         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004E64 ED               [12]  507 	mov	a,r5
      004E65 F0               [24]  508 	movx	@dptr,a
      004E66 EE               [12]  509 	mov	a,r6
      004E67 A3               [24]  510 	inc	dptr
      004E68 F0               [24]  511 	movx	@dptr,a
      004E69 EF               [12]  512 	mov	a,r7
      004E6A A3               [24]  513 	inc	dptr
      004E6B F0               [24]  514 	movx	@dptr,a
      004E6C 90 05 91         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004E6F 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0012
      004E70                        520 _ak820_outline_0012:
      004E70 E0               [24]  521 	movx	a,@dptr
      004E71 FD               [12]  522 	mov	r5,a
      004E72 A3               [24]  523 	inc	dptr
      004E73 E0               [24]  524 	movx	a,@dptr
      004E74 FE               [12]  525 	mov	r6,a
      004E75 A3               [24]  526 	inc	dptr
      004E76 E0               [24]  527 	movx	a,@dptr
      004E77 FF               [12]  528 	mov	r7,a
      004E78 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0033
      004E79                        533 _ak820_outline_0033:
      004E79 F0               [24]  534 	movx	@dptr,a
      004E7A 8D 82            [24]  535 	mov	dpl,r5
      004E7C 8E 83            [24]  536 	mov	dph,r6
      004E7E 8F F0            [24]  537 	mov	b,r7
      004E80 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0050
      004E81                        542 _ak820_outline_0050:
      004E81 E4               [12]  543 	clr	a
      004E82 F0               [24]  544 	movx	@dptr,a
      004E83 A3               [24]  545 	inc	dptr
      004E84 F0               [24]  546 	movx	@dptr,a
      004E85 A3               [24]  547 	inc	dptr
      004E86 F0               [24]  548 	movx	@dptr,a
      004E87 A3               [24]  549 	inc	dptr
      004E88 F0               [24]  550 	movx	@dptr,a
      004E89 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0054
      004E8A                        555 _ak820_outline_0054:
      004E8A E0               [24]  556 	movx	a,@dptr
      004E8B FC               [12]  557 	mov	r4,a
      004E8C A3               [24]  558 	inc	dptr
      004E8D E0               [24]  559 	movx	a,@dptr
      004E8E FD               [12]  560 	mov	r5,a
      004E8F A3               [24]  561 	inc	dptr
      004E90 E0               [24]  562 	movx	a,@dptr
      004E91 FE               [12]  563 	mov	r6,a
      004E92 A3               [24]  564 	inc	dptr
      004E93 E0               [24]  565 	movx	a,@dptr
      004E94 8C 82            [24]  566 	mov	dpl,r4
      004E96 8D 83            [24]  567 	mov	dph,r5
      004E98 8E F0            [24]  568 	mov	b,r6
      004E9A 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0056
      004E9B                        573 _ak820_outline_0056:
      004E9B AC 82            [24]  574 	mov	r4,dpl
      004E9D AD 83            [24]  575 	mov	r5,dph
      004E9F AE F0            [24]  576 	mov	r6,b
      004EA1 FF               [12]  577 	mov	r7,a
      004EA2 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0090
      004EA3                        582 _ak820_outline_0090:
      004EA3 E0               [24]  583 	movx	a,@dptr
      004EA4 F9               [12]  584 	mov	r1,a
      004EA5 A3               [24]  585 	inc	dptr
      004EA6 E0               [24]  586 	movx	a,@dptr
      004EA7 FA               [12]  587 	mov	r2,a
      004EA8 A3               [24]  588 	inc	dptr
      004EA9 E0               [24]  589 	movx	a,@dptr
      004EAA FB               [12]  590 	mov	r3,a
      004EAB 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0091
      004EAC                        595 _ak820_outline_0091:
      004EAC E0               [24]  596 	movx	a,@dptr
      004EAD FE               [12]  597 	mov	r6,a
      004EAE A3               [24]  598 	inc	dptr
      004EAF E0               [24]  599 	movx	a,@dptr
      004EB0 8E 82            [24]  600 	mov	dpl,r6
      004EB2 F5 83            [12]  601 	mov	dph,a
      004EB4 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0110
      004EB5                        606 _ak820_outline_0110:
      004EB5 74 02            [12]  607 	mov	a,#0x02
      004EB7 F0               [24]  608 	movx	@dptr,a
      004EB8 E4               [12]  609 	clr	a
      004EB9 A3               [24]  610 	inc	dptr
      004EBA F0               [24]  611 	movx	@dptr,a
      004EBB 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0156
      004EBC                        616 _ak820_outline_0156:
      004EBC F0               [24]  617 	movx	@dptr,a
      004EBD EA               [12]  618 	mov	a,r2
      004EBE A3               [24]  619 	inc	dptr
      004EBF F0               [24]  620 	movx	@dptr,a
      004EC0 EB               [12]  621 	mov	a,r3
      004EC1 A3               [24]  622 	inc	dptr
      004EC2 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0183
      004EC3                        627 _ak820_outline_0183:
      004EC3 E4               [12]  628 	clr	a
      004EC4 F0               [24]  629 	movx	@dptr,a
      004EC5 A3               [24]  630 	inc	dptr
      004EC6 F0               [24]  631 	movx	@dptr,a
      004EC7 22               [24]  632 	ret
