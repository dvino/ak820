send_string.o: quantum/send_string/send_string.c \
 keyboards/ajazz/ak820/config.h \
 .build/runtime-nkro/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h platforms/sdcc_dummy_macros.h \
 tmk_core/protocol/ch555/usb_device.h lib/ch555/ch555.h \
 tmk_core/protocol/ch555/usb.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdint.h \
 tmk_core/protocol/usb_descriptor.h \
 tmk_core/protocol/ch555/lufa_utils/LUFA/Drivers/USB/USB.h \
 platforms/progmem.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/string.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stddef.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/inttypes.h \
 lib/lufa/LUFA/Common/Architectures.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/StdDescriptors.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/../../../Common/Common.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/USBMode.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/../../Core/Events.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDParser.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/HIDReportData.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/CDCClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/AudioClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/MIDIClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Class/Common/AudioClassCommon.h \
 lib/lufa/LUFA/Drivers/USB/Core/USBController.h \
 lib/lufa/LUFA/Drivers/USB/Core/../../../Common/Common.h \
 lib/lufa/LUFA/Drivers/USB/Core/USBMode.h \
 quantum/send_string/send_string.h \
 quantum/send_string/send_string_keycodes.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/ctype.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdlib.h \
 quantum/quantum_keycodes.h quantum/keycodes.h \
 quantum/keymap_extras/keymap_us.h quantum/sequencer/sequencer.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdbool.h \
 quantum/quantum_keycodes_legacy.h quantum/keycode.h quantum/modifiers.h \
 quantum/action.h quantum/keyboard.h platforms/timer.h \
 platforms/mcs51/_timer.h platforms/mcs51/atomic_util.h lib/ch555/hal.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdio.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdarg.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/sdcc-lib.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/asm/mcs51/features.h \
 lib/ch555/ch555.h quantum/action_code.h platforms/wait.h \
 platforms/mcs51/_wait.h
