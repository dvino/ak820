                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_nvm_diagnostic
                                     16 	.globl _mDelaymS
                                     17 	.globl _mDelayuS
                                     18 	.globl _raw_hid_receive
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _ak820_usb_raw_send_PARM_2
                                    263 	.globl _ak820_usb_try_send_PARM_3
                                    264 	.globl _ak820_usb_try_send_PARM_2
                                    265 	.globl _ak820_usb_send_PARM_3
                                    266 	.globl _ak820_usb_send_PARM_2
                                    267 	.globl _ak820_main_heartbeat
                                    268 	.globl _ak820_boot_stage
                                    269 	.globl _KB_USB_SetReport
                                    270 	.globl _KB_USB_UpStatus
                                    271 	.globl _MCU_Sleep_Operate
                                    272 	.globl _USB_SleepStatus
                                    273 	.globl _USB_EnumStatus
                                    274 	.globl _D0UsbConfig
                                    275 	.globl _pD0Descr
                                    276 	.globl _D0SetupLen
                                    277 	.globl _D0SetupReqCode
                                    278 	.globl _USB_DeviceInterrupt
                                    279 	.globl _USB_Device_Init
                                    280 	.globl _USB_WakeUp_PC
                                    281 	.globl _ak820_usb_send
                                    282 	.globl _ak820_usb_try_send
                                    283 	.globl _ak820_usb_raw_send
                                    284 	.globl _ak820_usb_raw_task
                                    285 	.globl _ak820_usb_take_keyboard_reset
                                    286 ;--------------------------------------------------------
                                    287 ; special function registers
                                    288 ;--------------------------------------------------------
                                    289 	.area RSEG    (ABS,DATA)
      000000                        290 	.org 0x0000
                           0000D0   291 _PSW	=	0x00d0
                           0000E0   292 _ACC	=	0x00e0
                           0000F0   293 _B	=	0x00f0
                           0000FD   294 _A_INV	=	0x00fd
                           000081   295 _SP	=	0x0081
                           000082   296 _DPL	=	0x0082
                           000083   297 _DPH	=	0x0083
                           0000A1   298 _SAFE_MOD	=	0x00a1
                           0000B1   299 _GLOBAL_CFG	=	0x00b1
                           000087   300 _PCON	=	0x0087
                           0000BA   301 _POWER_CFG	=	0x00ba
                           0000B9   302 _CLOCK_CFG	=	0x00b9
                           0000A9   303 _WAKE_CTRL	=	0x00a9
                           0000FE   304 _RESET_KEEP	=	0x00fe
                           0000FF   305 _WDOG_COUNT	=	0x00ff
                           0000A8   306 _IE	=	0x00a8
                           0000B8   307 _IP	=	0x00b8
                           0000E8   308 _IE_EX	=	0x00e8
                           0000E9   309 _IP_EX	=	0x00e9
                           0000B2   310 _GPIO_IE	=	0x00b2
                           008584   311 _ROM_ADDR	=	0x8584
                           000084   312 _ROM_ADDR_L	=	0x0084
                           000085   313 _ROM_ADDR_H	=	0x0085
                           008F8E   314 _ROM_DATA_HI	=	0x8f8e
                           00008E   315 _ROM_DATA_HL	=	0x008e
                           00008F   316 _ROM_DATA_HH	=	0x008f
                           000086   317 _ROM_CTRL	=	0x0086
                           000080   318 _P0	=	0x0080
                           0000C4   319 _P0_MOD_OC	=	0x00c4
                           0000C5   320 _P0_DIR_PU	=	0x00c5
                           000090   321 _P1	=	0x0090
                           000092   322 _P1_MOD_OC	=	0x0092
                           000093   323 _P1_DIR_PU	=	0x0093
                           0000A0   324 _P2	=	0x00a0
                           000094   325 _P2_MOD_OC	=	0x0094
                           000095   326 _P2_DIR_PU	=	0x0095
                           0000B0   327 _P3	=	0x00b0
                           000096   328 _P3_MOD_OC	=	0x0096
                           000097   329 _P3_DIR_PU	=	0x0097
                           0000C0   330 _P4	=	0x00c0
                           0000C2   331 _P4_MOD_OC	=	0x00c2
                           0000C3   332 _P4_DIR_PU	=	0x00c3
                           0000C1   333 _P4_LED_KEY	=	0x00c1
                           0000AA   334 _P5_IN	=	0x00aa
                           0000AB   335 _P5_OUT_PU	=	0x00ab
                           0000AC   336 _P5_DIR	=	0x00ac
                           0000AD   337 _P6_IN	=	0x00ad
                           0000AE   338 _P6_OUT_PU	=	0x00ae
                           0000AF   339 _P6_DIR	=	0x00af
                           0000F1   340 _P7	=	0x00f1
                           0000A2   341 _XBUS_AUX	=	0x00a2
                           000088   342 _TCON	=	0x0088
                           000089   343 _TMOD	=	0x0089
                           00008A   344 _TL0	=	0x008a
                           00008B   345 _TL1	=	0x008b
                           00008C   346 _TH0	=	0x008c
                           00008D   347 _TH1	=	0x008d
                           000098   348 _SCON	=	0x0098
                           000099   349 _SBUF	=	0x0099
                           0000C8   350 _T2CON	=	0x00c8
                           0000C9   351 _T2MOD	=	0x00c9
                           00CBCA   352 _RCAP2	=	0xcbca
                           0000CA   353 _RCAP2L	=	0x00ca
                           0000CB   354 _RCAP2H	=	0x00cb
                           00CDCC   355 _T2COUNT	=	0xcdcc
                           0000CC   356 _TL2	=	0x00cc
                           0000CD   357 _TH2	=	0x00cd
                           00CFCE   358 _T2CAP1	=	0xcfce
                           0000CE   359 _T2CAP1L	=	0x00ce
                           0000CF   360 _T2CAP1H	=	0x00cf
                           0000F8   361 _SPI0_STAT	=	0x00f8
                           0000F9   362 _SPI0_DATA	=	0x00f9
                           0000FA   363 _SPI0_CTRL	=	0x00fa
                           0000FB   364 _SPI0_CK_SE	=	0x00fb
                           0000FC   365 _SPI0_SETUP	=	0x00fc
                           0000BC   366 _SCON1	=	0x00bc
                           0000BD   367 _SBUF1	=	0x00bd
                           0000BE   368 _SBAUD1	=	0x00be
                           0000BF   369 _SIF1	=	0x00bf
                           0000B4   370 _SPI1_STAT	=	0x00b4
                           0000B5   371 _SPI1_DATA	=	0x00b5
                           0000B6   372 _SPI1_CTRL	=	0x00b6
                           0000B7   373 _SPI1_CK_SE	=	0x00b7
                           0000F3   374 _ADC_CTRL	=	0x00f3
                           00F5F4   375 _ADC_DAT	=	0xf5f4
                           0000F4   376 _ADC_DAT_L	=	0x00f4
                           0000F5   377 _ADC_DAT_H	=	0x00f5
                           0000F6   378 _ADC_CHAN	=	0x00f6
                           0000A6   379 _LED_COMMON	=	0x00a6
                           0000A7   380 _LED_PWM_OE	=	0x00a7
                           00C7C6   381 _LED_DMA	=	0xc7c6
                           0000C6   382 _LED_DMA_L	=	0x00c6
                           0000C7   383 _LED_DMA_H	=	0x00c7
                           0000F7   384 _LED_STATUS	=	0x00f7
                           0000B3   385 _I2CX_INT	=	0x00b3
                           0000BB   386 _I2CS_INT_ST	=	0x00bb
                                    387 ;--------------------------------------------------------
                                    388 ; special function bits
                                    389 ;--------------------------------------------------------
                                    390 	.area RSEG    (ABS,DATA)
      000000                        391 	.org 0x0000
                           0000D7   392 _CY	=	0x00d7
                           0000D6   393 _AC	=	0x00d6
                           0000D5   394 _F0	=	0x00d5
                           0000D4   395 _RS1	=	0x00d4
                           0000D3   396 _RS0	=	0x00d3
                           0000D2   397 _OV	=	0x00d2
                           0000D1   398 _F1	=	0x00d1
                           0000D0   399 _P	=	0x00d0
                           0000AF   400 _EA	=	0x00af
                           0000AE   401 _E_DIS	=	0x00ae
                           0000AD   402 _ET2	=	0x00ad
                           0000AC   403 _ES	=	0x00ac
                           0000AB   404 _ET1	=	0x00ab
                           0000AA   405 _EX1	=	0x00aa
                           0000A9   406 _ET0	=	0x00a9
                           0000A8   407 _EX0	=	0x00a8
                           0000BF   408 _PH_FLAG	=	0x00bf
                           0000BE   409 _PL_FLAG	=	0x00be
                           0000BD   410 _PT2	=	0x00bd
                           0000BC   411 _PS	=	0x00bc
                           0000BB   412 _PT1	=	0x00bb
                           0000BA   413 _PX1	=	0x00ba
                           0000B9   414 _PT0	=	0x00b9
                           0000B8   415 _PX0	=	0x00b8
                           0000EF   416 _IE_WDOG	=	0x00ef
                           0000EE   417 _IE_GPIO	=	0x00ee
                           0000ED   418 _IE_PWM_I2C	=	0x00ed
                           0000EC   419 _IE_UART1	=	0x00ec
                           0000EB   420 _IE_ADC	=	0x00eb
                           0000E9   421 _IE_USB	=	0x00e9
                           0000E8   422 _IE_SPI0	=	0x00e8
                           000087   423 _P0_7	=	0x0087
                           000086   424 _P0_6	=	0x0086
                           000085   425 _P0_5	=	0x0085
                           000084   426 _P0_4	=	0x0084
                           000083   427 _P0_3	=	0x0083
                           000082   428 _P0_2	=	0x0082
                           000081   429 _P0_1	=	0x0081
                           000080   430 _P0_0	=	0x0080
                           000081   431 _SDA0	=	0x0081
                           000080   432 _SCL0	=	0x0080
                           000083   433 _TXD_	=	0x0083
                           000082   434 _RXD_	=	0x0082
                           000085   435 _AIN13	=	0x0085
                           000084   436 _AIN12	=	0x0084
                           000083   437 _AIN11	=	0x0083
                           000082   438 _AIN10	=	0x0082
                           000081   439 _AIN9	=	0x0081
                           000080   440 _AIN8	=	0x0080
                           000097   441 _P1_7	=	0x0097
                           000096   442 _P1_6	=	0x0096
                           000095   443 _P1_5	=	0x0095
                           000094   444 _P1_4	=	0x0094
                           000093   445 _P1_3	=	0x0093
                           000092   446 _P1_2	=	0x0092
                           000091   447 _P1_1	=	0x0091
                           000090   448 _P1_0	=	0x0090
                           000097   449 _TXD1_	=	0x0097
                           000096   450 _RXD1_	=	0x0096
                           000097   451 _SCK	=	0x0097
                           000096   452 _MISO	=	0x0096
                           000095   453 _MOSI	=	0x0095
                           000094   454 _SCS	=	0x0094
                           000092   455 _INT0_	=	0x0092
                           000091   456 _T2EX	=	0x0091
                           000091   457 _CAP2	=	0x0091
                           000090   458 _T2	=	0x0090
                           000090   459 _CAP1	=	0x0090
                           000097   460 _AIN7	=	0x0097
                           000096   461 _AIN6	=	0x0096
                           000095   462 _AIN5	=	0x0095
                           000094   463 _AIN4	=	0x0094
                           000093   464 _AIN3	=	0x0093
                           000092   465 _AIN2	=	0x0092
                           000091   466 _AIN1	=	0x0091
                           000090   467 _AIN0	=	0x0090
                           0000A7   468 _P2_7	=	0x00a7
                           0000A6   469 _P2_6	=	0x00a6
                           0000A5   470 _P2_5	=	0x00a5
                           0000A4   471 _P2_4	=	0x00a4
                           0000A3   472 _P2_3	=	0x00a3
                           0000A2   473 _P2_2	=	0x00a2
                           0000A1   474 _P2_1	=	0x00a1
                           0000A0   475 _P2_0	=	0x00a0
                           0000A7   476 _TXD1	=	0x00a7
                           0000A6   477 _RXD1	=	0x00a6
                           0000A5   478 _T2EX_	=	0x00a5
                           0000A5   479 _CAP2_	=	0x00a5
                           0000A4   480 _T2_	=	0x00a4
                           0000A4   481 _CAP1_	=	0x00a4
                           0000B7   482 _P3_7	=	0x00b7
                           0000B6   483 _P3_6	=	0x00b6
                           0000B5   484 _P3_5	=	0x00b5
                           0000B4   485 _P3_4	=	0x00b4
                           0000B3   486 _P3_3	=	0x00b3
                           0000B2   487 _P3_2	=	0x00b2
                           0000B1   488 _P3_1	=	0x00b1
                           0000B0   489 _P3_0	=	0x00b0
                           0000B7   490 _SCK1	=	0x00b7
                           0000B6   491 _MISO1	=	0x00b6
                           0000B5   492 _MOSI1	=	0x00b5
                           0000B5   493 _T1	=	0x00b5
                           0000B4   494 _T0	=	0x00b4
                           0000B3   495 _INT1	=	0x00b3
                           0000B2   496 _INT0	=	0x00b2
                           0000B1   497 _TXD	=	0x00b1
                           0000B0   498 _RXD	=	0x00b0
                           0000C6   499 _P4_6	=	0x00c6
                           0000C5   500 _P4_5	=	0x00c5
                           0000C4   501 _P4_4	=	0x00c4
                           0000C3   502 _P4_3	=	0x00c3
                           0000C2   503 _P4_2	=	0x00c2
                           0000C1   504 _P4_1	=	0x00c1
                           0000C0   505 _P4_0	=	0x00c0
                           00008F   506 _TF1	=	0x008f
                           00008E   507 _TR1	=	0x008e
                           00008D   508 _TF0	=	0x008d
                           00008C   509 _TR0	=	0x008c
                           00008B   510 _IE1	=	0x008b
                           00008A   511 _IT1	=	0x008a
                           000089   512 _IE0	=	0x0089
                           000088   513 _IT0	=	0x0088
                           00009F   514 _SM0	=	0x009f
                           00009E   515 _SM1	=	0x009e
                           00009D   516 _SM2	=	0x009d
                           00009C   517 _REN	=	0x009c
                           00009B   518 _TB8	=	0x009b
                           00009A   519 _RB8	=	0x009a
                           000099   520 _TI	=	0x0099
                           000098   521 _RI	=	0x0098
                           0000CF   522 _TF2	=	0x00cf
                           0000CF   523 _CAP1F	=	0x00cf
                           0000CE   524 _EXF2	=	0x00ce
                           0000CD   525 _RCLK	=	0x00cd
                           0000CC   526 _TCLK	=	0x00cc
                           0000CB   527 _EXEN2	=	0x00cb
                           0000CA   528 _TR2	=	0x00ca
                           0000C9   529 _C_T2	=	0x00c9
                           0000C8   530 _CP_RL2	=	0x00c8
                           0000FF   531 _S0_FST_ACT	=	0x00ff
                           0000FE   532 _S0_IF_OV	=	0x00fe
                           0000FD   533 _S0_IF_FIRST	=	0x00fd
                           0000FC   534 _S0_IF_BYTE	=	0x00fc
                           0000FB   535 _S0_FREE	=	0x00fb
                           0000FA   536 _S0_T_FIFO	=	0x00fa
                           0000F8   537 _S0_R_FIFO	=	0x00f8
                           0000F7   538 _ADC_START	=	0x00f7
                                    539 ;--------------------------------------------------------
                                    540 ; overlayable register banks
                                    541 ;--------------------------------------------------------
                                    542 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        543 	.ds 8
                                    544 ;--------------------------------------------------------
                                    545 ; internal ram data
                                    546 ;--------------------------------------------------------
                                    547 	.area DSEG    (DATA)
      000016                        548 _control_setup_sloc1_1_0:
      000016                        549 	.ds 1
      000017                        550 _control_setup_sloc3_1_0:
      000017                        551 	.ds 2
      000019                        552 _control_setup_sloc4_1_0:
      000019                        553 	.ds 2
      00001B                        554 _ak820_usb_send_sloc0_1_0:
      00001B                        555 	.ds 2
      00001D                        556 _ak820_usb_send_sloc1_1_0:
      00001D                        557 	.ds 1
      00001E                        558 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        559 	.ds 2
                                    560 ;--------------------------------------------------------
                                    561 ; overlayable items in internal ram
                                    562 ;--------------------------------------------------------
                                    563 ;--------------------------------------------------------
                                    564 ; indirectly addressable internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area ISEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; absolute internal ram data
                                    569 ;--------------------------------------------------------
                                    570 	.area IABS    (ABS,DATA)
                                    571 	.area IABS    (ABS,DATA)
                                    572 ;--------------------------------------------------------
                                    573 ; bit data
                                    574 ;--------------------------------------------------------
                                    575 	.area BSEG    (BIT)
      000017                        576 _control_setup_valid_interface_10000_287:
      000017                        577 	.ds 1
      000018                        578 _control_setup_zero_index_10000_287:
      000018                        579 	.ds 1
      000019                        580 _control_setup_zero_value_10000_287:
      000019                        581 	.ds 1
      00001A                        582 _control_setup_zero_length_10000_287:
      00001A                        583 	.ds 1
      00001B                        584 _control_setup_sloc0_1_0:
      00001B                        585 	.ds 1
      00001C                        586 _control_setup_sloc2_1_0:
      00001C                        587 	.ds 1
      00001D                        588 _ak820_usb_try_send_sloc0_1_0:
      00001D                        589 	.ds 1
      00001E                        590 _ak820_usb_raw_task_sloc1_1_0:
      00001E                        591 	.ds 1
      00001F                        592 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001F                        593 	.ds 1
                                    594 ;--------------------------------------------------------
                                    595 ; paged external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area PSEG    (PAG,XDATA)
                                    598 ;--------------------------------------------------------
                                    599 ; uninitialized external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XSEG    (XDATA)
      00078B                        602 _D0SetupReqCode::
      00078B                        603 	.ds 1
      00078C                        604 _D0SetupLen::
      00078C                        605 	.ds 2
      00078E                        606 _pD0Descr::
      00078E                        607 	.ds 3
      000791                        608 _D0UsbConfig::
      000791                        609 	.ds 1
      000792                        610 _USB_EnumStatus::
      000792                        611 	.ds 1
      000793                        612 _USB_SleepStatus::
      000793                        613 	.ds 1
      000794                        614 _MCU_Sleep_Operate::
      000794                        615 	.ds 1
      000795                        616 _KB_USB_UpStatus::
      000795                        617 	.ds 1
      000796                        618 _KB_USB_SetReport::
      000796                        619 	.ds 1
      000797                        620 _ak820_boot_stage::
      000797                        621 	.ds 1
      000798                        622 _ak820_main_heartbeat::
      000798                        623 	.ds 1
      000799                        624 _raw_state:
      000799                        625 	.ds 1
      00079A                        626 _raw_buffer:
      00079A                        627 	.ds 32
      0007BA                        628 _raw_reply_without_nvm:
      0007BA                        629 	.ds 1
      0007BB                        630 _keyboard_reset:
      0007BB                        631 	.ds 1
      0007BC                        632 _input_snapshot:
      0007BC                        633 	.ds 52
      0007F0                        634 _control_phase:
      0007F0                        635 	.ds 1
      0007F1                        636 _output_kind:
      0007F1                        637 	.ds 1
      0007F2                        638 _output_report_id:
      0007F2                        639 	.ds 1
      0007F3                        640 _control_zlp:
      0007F3                        641 	.ds 1
      0007F4                        642 _control_pointer:
      0007F4                        643 	.ds 2
      0007F6                        644 _descriptor_select_PARM_2:
      0007F6                        645 	.ds 1
      0007F7                        646 _descriptor_select_PARM_3:
      0007F7                        647 	.ds 2
      0007F9                        648 _descriptor_select_type_10000_269:
      0007F9                        649 	.ds 1
      0007FA                        650 _control_setup_length_10000_287:
      0007FA                        651 	.ds 2
      0007FC                        652 _control_setup_offset_10000_287:
      0007FC                        653 	.ds 1
      0007FD                        654 _ak820_usb_send_PARM_2:
      0007FD                        655 	.ds 2
      0007FF                        656 _ak820_usb_send_PARM_3:
      0007FF                        657 	.ds 1
      000800                        658 _ak820_usb_send_endpoint_10000_423:
      000800                        659 	.ds 1
      000801                        660 _ak820_usb_send_offset_10000_424:
      000801                        661 	.ds 1
      000802                        662 _ak820_usb_try_send_PARM_2:
      000802                        663 	.ds 2
      000804                        664 _ak820_usb_try_send_PARM_3:
      000804                        665 	.ds 1
      000805                        666 _ak820_usb_try_send_endpoint_10000_444:
      000805                        667 	.ds 1
      000806                        668 _ak820_usb_try_send_sent_10000_445:
      000806                        669 	.ds 1
      000807                        670 _ak820_usb_raw_send_PARM_2:
      000807                        671 	.ds 1
      000808                        672 _ak820_usb_raw_send_report_10000_460:
      000808                        673 	.ds 3
                                    674 ;--------------------------------------------------------
                                    675 ; absolute external ram data
                                    676 ;--------------------------------------------------------
                                    677 	.area XABS    (ABS,XDATA)
                                    678 ;--------------------------------------------------------
                                    679 ; initialized external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XISEG   (XDATA)
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT0 (CODE)
                                    684 	.area GSINIT1 (CODE)
                                    685 	.area GSINIT2 (CODE)
                                    686 	.area GSINIT3 (CODE)
                                    687 	.area GSINIT4 (CODE)
                                    688 	.area GSINIT5 (CODE)
                                    689 	.area GSINIT  (CODE)
                                    690 	.area GSFINAL (CODE)
                                    691 	.area CSEG    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; global & static initialisations
                                    694 ;--------------------------------------------------------
                                    695 	.area HOME    (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 	.area GSFINAL (CODE)
                                    698 	.area GSINIT  (CODE)
                                    699 ;--------------------------------------------------------
                                    700 ; Home
                                    701 ;--------------------------------------------------------
                                    702 	.area HOME    (CODE)
                                    703 	.area HOME    (CODE)
                                    704 ;--------------------------------------------------------
                                    705 ; code
                                    706 ;--------------------------------------------------------
                                    707 	.area CSEG    (CODE)
                                    708 ;------------------------------------------------------------
                                    709 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    710 ;------------------------------------------------------------
                                    711 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    712 ;------------------------------------------------------------
                                    713 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    714 ;	-----------------------------------------
                           000007   715 	ar7 = 0x07
                           000006   716 	ar6 = 0x06
                           000005   717 	ar5 = 0x05
                           000004   718 	ar4 = 0x04
                           000003   719 	ar3 = 0x03
                           000002   720 	ar2 = 0x02
                           000001   721 	ar1 = 0x01
                           000000   722 	ar0 = 0x00
                                    723 ;	 function raw_abort
                                    724 ;	-----------------------------------------
      005EE6                        725 _raw_abort:
                                    726 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005EE6 90 07 99         [24]  727 	mov	dptr,#_raw_state
      005EE9 E0               [24]  728 	movx	a,@dptr
      005EEA FF               [12]  729 	mov	r7,a
      005EEB BF 03 02         [24]  730 	cjne	r7,#0x03,00130$
      005EEE 80 1C            [24]  731 	sjmp	00101$
      005EF0                        732 00130$:
      005EF0 90 07 99         [24]  733 	mov	dptr,#_raw_state
      005EF3 E0               [24]  734 	movx	a,@dptr
      005EF4 FF               [12]  735 	mov	r7,a
      005EF5 BF 04 02         [24]  736 	cjne	r7,#0x04,00131$
      005EF8 80 12            [24]  737 	sjmp	00101$
      005EFA                        738 00131$:
                                    739 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005EFA 90 07 99         [24]  740 	mov	dptr,#_raw_state
      005EFD E0               [24]  741 	movx	a,@dptr
      005EFE FF               [12]  742 	mov	r7,a
      005EFF BF 06 02         [24]  743 	cjne	r7,#0x06,00132$
      005F02 80 08            [24]  744 	sjmp	00101$
      005F04                        745 00132$:
      005F04 90 07 99         [24]  746 	mov	dptr,#_raw_state
      005F07 E0               [24]  747 	movx	a,@dptr
      005F08 FF               [12]  748 	mov	r7,a
      005F09 BF 07 08         [24]  749 	cjne	r7,#0x07,00102$
      005F0C                        750 00101$:
                                    751 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005F0C 90 07 99         [24]  752 	mov	dptr,#_raw_state
      005F0F 74 07            [12]  753 	mov	a,#0x07
      005F11 F0               [24]  754 	movx	@dptr,a
      005F12 80 05            [24]  755 	sjmp	00103$
      005F14                        756 00102$:
                                    757 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005F14 90 07 99         [24]  758 	mov	dptr,#_raw_state
      005F17 E4               [12]  759 	clr	a
      005F18 F0               [24]  760 	movx	@dptr,a
      005F19                        761 00103$:
                                    762 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005F19 90 07 F1         [24]  763 	mov	dptr,#_output_kind
      005F1C E4               [12]  764 	clr	a
      005F1D F0               [24]  765 	movx	@dptr,a
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005F1E 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'raw_complete'
                                    770 ;------------------------------------------------------------
                                    771 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function raw_complete
                                    774 ;	-----------------------------------------
      005F1F                        775 _raw_complete:
                                    776 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005F1F 90 07 99         [24]  777 	mov	dptr,#_raw_state
      005F22 E0               [24]  778 	movx	a,@dptr
      005F23 FF               [12]  779 	mov	r7,a
      005F24 BF 04 07         [24]  780 	cjne	r7,#0x04,00104$
      005F27 90 07 99         [24]  781 	mov	dptr,#_raw_state
      005F2A 74 06            [12]  782 	mov	a,#0x06
      005F2C F0               [24]  783 	movx	@dptr,a
      005F2D 22               [24]  784 	ret
      005F2E                        785 00104$:
                                    786 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005F2E 90 07 99         [24]  787 	mov	dptr,#_raw_state
      005F31 E0               [24]  788 	movx	a,@dptr
      005F32 FF               [12]  789 	mov	r7,a
      005F33 BF 05 05         [24]  790 	cjne	r7,#0x05,00106$
      005F36 90 07 99         [24]  791 	mov	dptr,#_raw_state
      005F39 E4               [12]  792 	clr	a
      005F3A F0               [24]  793 	movx	@dptr,a
      005F3B                        794 00106$:
                                    795 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005F3B 22               [24]  796 	ret
                                    797 ;------------------------------------------------------------
                                    798 ;Allocation info for local variables in function 'endpoints_reset'
                                    799 ;------------------------------------------------------------
                                    800 ;i             Allocated with name '_endpoints_reset_i_10000_259'
                                    801 ;------------------------------------------------------------
                                    802 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    803 ;	-----------------------------------------
                                    804 ;	 function endpoints_reset
                                    805 ;	-----------------------------------------
      005F3C                        806 _endpoints_reset:
                                    807 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005F3C 90 22 0C         [24]  808 	mov	dptr,#0x220c
      005F3F 74 01            [12]  809 	mov	a,#0x01
      005F41 F0               [24]  810 	movx	@dptr,a
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F42 F5 82            [12]  812 	mov	dpl,a
      005F44 74 12            [12]  813 	mov	a,#0x12
      005F46 F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F47 A3               [24]  816 	inc	dptr
      005F48 F0               [24]  817 	movx	@dptr,a
                                    818 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005F49 A3               [24]  819 	inc	dptr
      005F4A F0               [24]  820 	movx	@dptr,a
                                    821 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005F4B 90 22 0B         [24]  822 	mov	dptr,#0x220b
      005F4E E4               [12]  823 	clr	a
      005F4F F0               [24]  824 	movx	@dptr,a
      005F50 15 82            [12]  825 	dec	dpl
      005F52 F0               [24]  826 	movx	@dptr,a
      005F53 15 82            [12]  827 	dec	dpl
      005F55 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005F56 FF               [12]  830 	mov	r7,a
      005F57                        831 00103$:
      005F57 EF               [12]  832 	mov	a,r7
      005F58 24 BC            [12]  833 	add	a, #_input_snapshot
      005F5A F5 82            [12]  834 	mov	dpl,a
      005F5C E4               [12]  835 	clr	a
      005F5D 34 07            [12]  836 	addc	a, #(_input_snapshot >> 8)
      005F5F F5 83            [12]  837 	mov	dph,a
      005F61 E4               [12]  838 	clr	a
      005F62 F0               [24]  839 	movx	@dptr,a
      005F63 0F               [12]  840 	inc	r7
      005F64 BF 34 00         [24]  841 	cjne	r7,#0x34,00139$
      005F67                        842 00139$:
      005F67 40 EE            [24]  843 	jc	00103$
                                    844 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005F69 90 07 C4         [24]  845 	mov	dptr,#(_input_snapshot + 0x0008)
      005F6C 74 06            [12]  846 	mov	a,#0x06
      005F6E F0               [24]  847 	movx	@dptr,a
                                    848 ;	tmk_core/protocol/ch555/usb_ak820.c:124: input_snapshot[SNAPSHOT_MOUSE] = REPORT_ID_MOUSE;
      005F6F 90 07 E4         [24]  849 	mov	dptr,#(_input_snapshot + 0x0028)
      005F72 74 02            [12]  850 	mov	a,#0x02
      005F74 F0               [24]  851 	movx	@dptr,a
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005F75 90 07 EA         [24]  853 	mov	dptr,#(_input_snapshot + 0x002e)
      005F78 04               [12]  854 	inc	a
      005F79 F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005F7A 90 07 ED         [24]  857 	mov	dptr,#(_input_snapshot + 0x0031)
      005F7D 04               [12]  858 	inc	a
      005F7E F0               [24]  859 	movx	@dptr,a
                                    860 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005F7F 7F 00            [12]  861 	mov	r7,#0x00
      005F81                        862 00105$:
      005F81 8F 06            [24]  863 	mov	ar6,r7
      005F83 74 C0            [12]  864 	mov	a,#0xc0
      005F85 2E               [12]  865 	add	a, r6
      005F86 F5 82            [12]  866 	mov	dpl,a
      005F88 74 10            [12]  867 	mov	a,#0x10
      005F8A 24 00            [12]  868 	add	a, #0x00
      005F8C F5 83            [12]  869 	mov	dph,a
      005F8E E4               [12]  870 	clr	a
      005F8F F0               [24]  871 	movx	@dptr,a
      005F90 0F               [12]  872 	inc	r7
      005F91 BF 20 00         [24]  873 	cjne	r7,#0x20,00141$
      005F94                        874 00141$:
      005F94 40 EB            [24]  875 	jc	00105$
                                    876 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    877 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005F96 02 5E E6         [24]  878 	ljmp	_raw_abort
                                    879 ;------------------------------------------------------------
                                    880 ;Allocation info for local variables in function 'control_stall'
                                    881 ;------------------------------------------------------------
                                    882 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    883 ;	-----------------------------------------
                                    884 ;	 function control_stall
                                    885 ;	-----------------------------------------
      005F99                        886 _control_stall:
                                    887 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005F99 90 07 99         [24]  888 	mov	dptr,#_raw_state
      005F9C E0               [24]  889 	movx	a,@dptr
      005F9D FF               [12]  890 	mov	r7,a
      005F9E BF 01 05         [24]  891 	cjne	r7,#0x01,00102$
      005FA1 90 07 99         [24]  892 	mov	dptr,#_raw_state
      005FA4 E4               [12]  893 	clr	a
      005FA5 F0               [24]  894 	movx	@dptr,a
      005FA6                        895 00102$:
                                    896 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005FA6 90 07 F1         [24]  897 	mov	dptr,#_output_kind
      005FA9 E4               [12]  898 	clr	a
      005FAA F0               [24]  899 	movx	@dptr,a
                                    900 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005FAB 90 07 F0         [24]  901 	mov	dptr,#_control_phase
      005FAE F0               [24]  902 	movx	@dptr,a
                                    903 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      005FAF 90 07 8B         [24]  904 	mov	dptr,#_D0SetupReqCode
      005FB2 14               [12]  905 	dec	a
      005FB3 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005FB4 90 22 00         [24]  908 	mov	dptr,#0x2200
      005FB7 74 CF            [12]  909 	mov	a,#0xcf
      005FB9 F0               [24]  910 	movx	@dptr,a
                                    911 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      005FBA 22               [24]  912 	ret
                                    913 ;------------------------------------------------------------
                                    914 ;Allocation info for local variables in function 'control_next'
                                    915 ;------------------------------------------------------------
                                    916 ;i             Allocated with name '_control_next_i_10000_266'
                                    917 ;length        Allocated with name '_control_next_length_10000_266'
                                    918 ;------------------------------------------------------------
                                    919 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    920 ;	-----------------------------------------
                                    921 ;	 function control_next
                                    922 ;	-----------------------------------------
      005FBB                        923 _control_next:
                                    924 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005FBB 90 07 8C         [24]  925 	mov	dptr,#_D0SetupLen
      005FBE E0               [24]  926 	movx	a,@dptr
      005FBF FE               [12]  927 	mov	r6,a
      005FC0 A3               [24]  928 	inc	dptr
      005FC1 E0               [24]  929 	movx	a,@dptr
      005FC2 FF               [12]  930 	mov	r7,a
      005FC3 C3               [12]  931 	clr	c
      005FC4 74 40            [12]  932 	mov	a,#0x40
      005FC6 9E               [12]  933 	subb	a,r6
      005FC7 E4               [12]  934 	clr	a
      005FC8 9F               [12]  935 	subb	a,r7
      005FC9 50 04            [24]  936 	jnc	00109$
                                    937 ;	free result
      005FCB 7E 40            [12]  938 	mov	r6,#0x40
      005FCD 80 07            [24]  939 	sjmp	00110$
      005FCF                        940 00109$:
      005FCF 90 07 8C         [24]  941 	mov	dptr,#_D0SetupLen
      005FD2 E0               [24]  942 	movx	a,@dptr
      005FD3 FE               [12]  943 	mov	r6,a
      005FD4 A3               [24]  944 	inc	dptr
      005FD5 E0               [24]  945 	movx	a,@dptr
      005FD6                        946 00110$:
                                    947 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005FD6 7F 00            [12]  948 	mov	r7,#0x00
      005FD8                        949 00105$:
      005FD8 C3               [12]  950 	clr	c
      005FD9 EF               [12]  951 	mov	a,r7
      005FDA 9E               [12]  952 	subb	a,r6
      005FDB 50 2A            [24]  953 	jnc	00101$
      005FDD 8F 04            [24]  954 	mov	ar4,r7
      005FDF 74 10            [12]  955 	mov	a,#0x10
      005FE1 24 00            [12]  956 	add	a, #0x00
      005FE3 FD               [12]  957 	mov	r5,a
      005FE4 90 07 F4         [24]  958 	mov	dptr,#_control_pointer
      005FE7 E0               [24]  959 	movx	a,@dptr
      005FE8 FA               [12]  960 	mov	r2,a
      005FE9 A3               [24]  961 	inc	dptr
      005FEA E0               [24]  962 	movx	a,@dptr
      005FEB FB               [12]  963 	mov	r3,a
      005FEC 8A 82            [24]  964 	mov	dpl,r2
      005FEE 8B 83            [24]  965 	mov	dph,r3
      005FF0 E4               [12]  966 	clr	a
      005FF1 93               [24]  967 	movc	a,@a+dptr
      005FF2 F9               [12]  968 	mov	r1,a
      005FF3 90 07 F4         [24]  969 	mov	dptr,#_control_pointer
      005FF6 74 01            [12]  970 	mov	a,#0x01
      005FF8 2A               [12]  971 	add	a, r2
      005FF9 F0               [24]  972 	movx	@dptr,a
      005FFA E4               [12]  973 	clr	a
      005FFB 3B               [12]  974 	addc	a, r3
      005FFC A3               [24]  975 	inc	dptr
      005FFD F0               [24]  976 	movx	@dptr,a
      005FFE 8C 82            [24]  977 	mov	dpl,r4
      006000 8D 83            [24]  978 	mov	dph,r5
      006002 E9               [12]  979 	mov	a,r1
      006003 F0               [24]  980 	movx	@dptr,a
      006004 0F               [12]  981 	inc	r7
      006005 80 D1            [24]  982 	sjmp	00105$
      006007                        983 00101$:
                                    984 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      006007 8E 05            [24]  985 	mov	ar5,r6
      006009 7F 00            [12]  986 	mov	r7,#0x00
      00600B 90 07 8C         [24]  987 	mov	dptr,#_D0SetupLen
      00600E E0               [24]  988 	movx	a,@dptr
      00600F FB               [12]  989 	mov	r3,a
      006010 A3               [24]  990 	inc	dptr
      006011 E0               [24]  991 	movx	a,@dptr
      006012 FC               [12]  992 	mov	r4,a
      006013 EB               [12]  993 	mov	a,r3
      006014 C3               [12]  994 	clr	c
      006015 9D               [12]  995 	subb	a,r5
      006016 FB               [12]  996 	mov	r3,a
      006017 EC               [12]  997 	mov	a,r4
      006018 9F               [12]  998 	subb	a,r7
      006019 FC               [12]  999 	mov	r4,a
      00601A 90 07 8C         [24] 1000 	mov	dptr,#_D0SetupLen
      00601D EB               [12] 1001 	mov	a,r3
      00601E F0               [24] 1002 	movx	@dptr,a
      00601F EC               [12] 1003 	mov	a,r4
      006020 A3               [24] 1004 	inc	dptr
      006021 F0               [24] 1005 	movx	@dptr,a
                                   1006 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      006022 EE               [12] 1007 	mov	a,r6
      006023 70 05            [24] 1008 	jnz	00103$
      006025 90 07 F3         [24] 1009 	mov	dptr,#_control_zlp
      006028 E4               [12] 1010 	clr	a
      006029 F0               [24] 1011 	movx	@dptr,a
      00602A                       1012 00103$:
                                   1013 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      00602A 90 22 08         [24] 1014 	mov	dptr,#0x2208
      00602D EE               [12] 1015 	mov	a,r6
      00602E F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      00602F 90 22 00         [24] 1018 	mov	dptr,#0x2200
      006032 E0               [24] 1019 	movx	a,@dptr
      006033 54 C0            [12] 1020 	anl	a,#0xc0
      006035 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      006036 22               [24] 1023 	ret
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'descriptor_select'
                                   1026 ;------------------------------------------------------------
                                   1027 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1028 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1029 ;type          Allocated with name '_descriptor_select_type_10000_269'
                                   1030 ;hid           Allocated with name '_descriptor_select_hid_30000_282'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function descriptor_select
                                   1035 ;	-----------------------------------------
      006037                       1036 _descriptor_select:
      006037 E5 82            [12] 1037 	mov	a,dpl
      006039 90 07 F9         [24] 1038 	mov	dptr,#_descriptor_select_type_10000_269
      00603C F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      00603D E0               [24] 1041 	movx	a,@dptr
      00603E FF               [12] 1042 	mov	r7,a
      00603F BF 01 20         [24] 1043 	cjne	r7,#0x01,00102$
      006042 90 07 F6         [24] 1044 	mov	dptr,#_descriptor_select_PARM_2
      006045 E0               [24] 1045 	movx	a,@dptr
      006046 70 1A            [24] 1046 	jnz	00102$
      006048 90 07 F7         [24] 1047 	mov	dptr,#_descriptor_select_PARM_3
      00604B E0               [24] 1048 	movx	a,@dptr
      00604C F5 F0            [12] 1049 	mov	b,a
      00604E A3               [24] 1050 	inc	dptr
      00604F E0               [24] 1051 	movx	a,@dptr
      006050 45 F0            [12] 1052 	orl	a,b
      006052 70 0E            [24] 1053 	jnz	00102$
                                   1054 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      006054 90 07 F4         [24] 1055 	mov	dptr,#_control_pointer
      006057 74 37            [12] 1056 	mov	a,#_DeviceDescriptor
      006059 F0               [24] 1057 	movx	@dptr,a
      00605A 74 C5            [12] 1058 	mov	a,#(_DeviceDescriptor >> 8)
      00605C A3               [24] 1059 	inc	dptr
      00605D F0               [24] 1060 	movx	@dptr,a
                                   1061 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      00605E 90 00 12         [24] 1062 	mov	dptr,#0x0012
      006061 22               [24] 1063 	ret
      006062                       1064 00102$:
                                   1065 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      006062 90 07 F9         [24] 1066 	mov	dptr,#_descriptor_select_type_10000_269
      006065 E0               [24] 1067 	movx	a,@dptr
      006066 FF               [12] 1068 	mov	r7,a
      006067 BF 02 20         [24] 1069 	cjne	r7,#0x02,00106$
      00606A 90 07 F6         [24] 1070 	mov	dptr,#_descriptor_select_PARM_2
      00606D E0               [24] 1071 	movx	a,@dptr
      00606E 70 1A            [24] 1072 	jnz	00106$
      006070 90 07 F7         [24] 1073 	mov	dptr,#_descriptor_select_PARM_3
      006073 E0               [24] 1074 	movx	a,@dptr
      006074 F5 F0            [12] 1075 	mov	b,a
      006076 A3               [24] 1076 	inc	dptr
      006077 E0               [24] 1077 	movx	a,@dptr
      006078 45 F0            [12] 1078 	orl	a,b
      00607A 70 0E            [24] 1079 	jnz	00106$
                                   1080 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      00607C 90 07 F4         [24] 1081 	mov	dptr,#_control_pointer
      00607F 74 49            [12] 1082 	mov	a,#_ConfigurationDescriptor
      006081 F0               [24] 1083 	movx	@dptr,a
      006082 74 C5            [12] 1084 	mov	a,#(_ConfigurationDescriptor >> 8)
      006084 A3               [24] 1085 	inc	dptr
      006085 F0               [24] 1086 	movx	@dptr,a
                                   1087 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      006086 90 00 54         [24] 1088 	mov	dptr,#0x0054
      006089 22               [24] 1089 	ret
      00608A                       1090 00106$:
                                   1091 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      00608A 90 07 F9         [24] 1092 	mov	dptr,#_descriptor_select_type_10000_269
      00608D E0               [24] 1093 	movx	a,@dptr
      00608E FF               [12] 1094 	mov	r7,a
      00608F BF 03 02         [24] 1095 	cjne	r7,#0x03,00238$
      006092 80 03            [24] 1096 	sjmp	00239$
      006094                       1097 00238$:
      006094 02 61 2E         [24] 1098 	ljmp	00119$
      006097                       1099 00239$:
                                   1100 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      006097 90 07 F7         [24] 1101 	mov	dptr,#_descriptor_select_PARM_3
      00609A E0               [24] 1102 	movx	a,@dptr
      00609B FD               [12] 1103 	mov	r5,a
      00609C A3               [24] 1104 	inc	dptr
      00609D E0               [24] 1105 	movx	a,@dptr
      00609E FE               [12] 1106 	mov	r6,a
      00609F 90 07 F7         [24] 1107 	mov	dptr,#_descriptor_select_PARM_3
      0060A2 E0               [24] 1108 	movx	a,@dptr
      0060A3 F5 F0            [12] 1109 	mov	b,a
      0060A5 A3               [24] 1110 	inc	dptr
      0060A6 E0               [24] 1111 	movx	a,@dptr
      0060A7 45 F0            [12] 1112 	orl	a,b
      0060A9 60 0C            [24] 1113 	jz	00110$
      0060AB BD 09 05         [24] 1114 	cjne	r5,#0x09,00241$
      0060AE BE 04 02         [24] 1115 	cjne	r6,#0x04,00241$
      0060B1 80 04            [24] 1116 	sjmp	00110$
      0060B3                       1117 00241$:
      0060B3 90 00 00         [24] 1118 	mov	dptr,#0x0000
      0060B6 22               [24] 1119 	ret
      0060B7                       1120 00110$:
                                   1121 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      0060B7 90 07 F6         [24] 1122 	mov	dptr,#_descriptor_select_PARM_2
      0060BA E0               [24] 1123 	movx	a,@dptr
      0060BB FE               [12] 1124 	mov  r6,a
      0060BC 24 FC            [12] 1125 	add	a,#0xff - 0x03
      0060BE 40 6A            [24] 1126 	jc	00116$
                                   1127 ;	free result
      0060C0 EE               [12] 1128 	mov	a,r6
      0060C1 2E               [12] 1129 	add	a,r6
                                   1130 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      0060C2 90 60 C6         [24] 1131 	mov	dptr,#00243$
      0060C5 73               [24] 1132 	jmp	@a+dptr
      0060C6                       1133 00243$:
      0060C6 80 06            [24] 1134 	sjmp	00112$
      0060C8 80 1B            [24] 1135 	sjmp	00113$
      0060CA 80 30            [24] 1136 	sjmp	00114$
      0060CC 80 45            [24] 1137 	sjmp	00115$
      0060CE                       1138 00112$:
      0060CE 90 07 F4         [24] 1139 	mov	dptr,#_control_pointer
      0060D1 74 9D            [12] 1140 	mov	a,#_LanguageString
      0060D3 F0               [24] 1141 	movx	@dptr,a
      0060D4 74 C5            [12] 1142 	mov	a,#(_LanguageString >> 8)
      0060D6 A3               [24] 1143 	inc	dptr
      0060D7 F0               [24] 1144 	movx	@dptr,a
      0060D8 90 C5 9D         [24] 1145 	mov	dptr,#_LanguageString
      0060DB E4               [12] 1146 	clr	a
      0060DC 93               [24] 1147 	movc	a,@a+dptr
      0060DD FE               [12] 1148 	mov	r6,a
      0060DE 7D 00            [12] 1149 	mov	r5,#0x00
      0060E0 8E 82            [24] 1150 	mov	dpl, r6
      0060E2 8D 83            [24] 1151 	mov	dph, r5
      0060E4 22               [24] 1152 	ret
                                   1153 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      0060E5                       1154 00113$:
      0060E5 90 07 F4         [24] 1155 	mov	dptr,#_control_pointer
      0060E8 74 A1            [12] 1156 	mov	a,#_ManufacturerString
      0060EA F0               [24] 1157 	movx	@dptr,a
      0060EB 74 C5            [12] 1158 	mov	a,#(_ManufacturerString >> 8)
      0060ED A3               [24] 1159 	inc	dptr
      0060EE F0               [24] 1160 	movx	@dptr,a
      0060EF 90 C5 A1         [24] 1161 	mov	dptr,#_ManufacturerString
      0060F2 E4               [12] 1162 	clr	a
      0060F3 93               [24] 1163 	movc	a,@a+dptr
      0060F4 FE               [12] 1164 	mov	r6,a
      0060F5 7D 00            [12] 1165 	mov	r5,#0x00
      0060F7 8E 82            [24] 1166 	mov	dpl, r6
      0060F9 8D 83            [24] 1167 	mov	dph, r5
      0060FB 22               [24] 1168 	ret
                                   1169 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      0060FC                       1170 00114$:
      0060FC 90 07 F4         [24] 1171 	mov	dptr,#_control_pointer
      0060FF 74 AF            [12] 1172 	mov	a,#_ProductString
      006101 F0               [24] 1173 	movx	@dptr,a
      006102 74 C5            [12] 1174 	mov	a,#(_ProductString >> 8)
      006104 A3               [24] 1175 	inc	dptr
      006105 F0               [24] 1176 	movx	@dptr,a
      006106 90 C5 AF         [24] 1177 	mov	dptr,#_ProductString
      006109 E4               [12] 1178 	clr	a
      00610A 93               [24] 1179 	movc	a,@a+dptr
      00610B FE               [12] 1180 	mov	r6,a
      00610C 7D 00            [12] 1181 	mov	r5,#0x00
      00610E 8E 82            [24] 1182 	mov	dpl, r6
      006110 8D 83            [24] 1183 	mov	dph, r5
      006112 22               [24] 1184 	ret
                                   1185 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      006113                       1186 00115$:
      006113 90 07 F4         [24] 1187 	mov	dptr,#_control_pointer
      006116 74 E7            [12] 1188 	mov	a,#_SerialNumberString
      006118 F0               [24] 1189 	movx	@dptr,a
      006119 74 C5            [12] 1190 	mov	a,#(_SerialNumberString >> 8)
      00611B A3               [24] 1191 	inc	dptr
      00611C F0               [24] 1192 	movx	@dptr,a
      00611D 90 C5 E7         [24] 1193 	mov	dptr,#_SerialNumberString
      006120 E4               [12] 1194 	clr	a
      006121 93               [24] 1195 	movc	a,@a+dptr
      006122 FE               [12] 1196 	mov	r6,a
      006123 7D 00            [12] 1197 	mov	r5,#0x00
      006125 8E 82            [24] 1198 	mov	dpl, r6
      006127 8D 83            [24] 1199 	mov	dph, r5
      006129 22               [24] 1200 	ret
                                   1201 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      00612A                       1202 00116$:
      00612A 90 00 00         [24] 1203 	mov	dptr,#0x0000
      00612D 22               [24] 1204 	ret
                                   1205 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      00612E                       1206 00119$:
                                   1207 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      00612E 90 07 F6         [24] 1208 	mov	dptr,#_descriptor_select_PARM_2
      006131 E0               [24] 1209 	movx	a,@dptr
      006132 70 11            [24] 1210 	jnz	00120$
      006134 90 07 F7         [24] 1211 	mov	dptr,#_descriptor_select_PARM_3
      006137 E0               [24] 1212 	movx	a,@dptr
      006138 FD               [12] 1213 	mov	r5,a
      006139 A3               [24] 1214 	inc	dptr
      00613A E0               [24] 1215 	movx	a,@dptr
      00613B FE               [12] 1216 	mov	r6,a
      00613C C3               [12] 1217 	clr	c
      00613D ED               [12] 1218 	mov	a,r5
      00613E 94 03            [12] 1219 	subb	a,#0x03
      006140 EE               [12] 1220 	mov	a,r6
      006141 94 00            [12] 1221 	subb	a,#0x00
      006143 40 04            [24] 1222 	jc	00121$
      006145                       1223 00120$:
      006145 90 00 00         [24] 1224 	mov	dptr,#0x0000
      006148 22               [24] 1225 	ret
      006149                       1226 00121$:
                                   1227 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      006149 BF 22 02         [24] 1228 	cjne	r7,#0x22,00246$
      00614C 80 03            [24] 1229 	sjmp	00127$
      00614E                       1230 00246$:
      00614E BF 21 5D         [24] 1231 	cjne	r7,#0x21,00128$
      006151                       1232 00127$:
                                   1233 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      006151 ED               [12] 1234 	mov	a,r5
      006152 75 F0 04         [24] 1235 	mov	b,#0x04
      006155 A4               [48] 1236 	mul	ab
      006156 24 6F            [12] 1237 	add	a, #_interface_descriptors
      006158 FE               [12] 1238 	mov	r6,a
      006159 74 BE            [12] 1239 	mov	a,#(_interface_descriptors >> 8)
      00615B 35 F0            [12] 1240 	addc	a, b
      00615D FF               [12] 1241 	mov	r7,a
      00615E 8E 82            [24] 1242 	mov	dpl,r6
      006160 8F 83            [24] 1243 	mov	dph,r7
      006162 A3               [24] 1244 	inc	dptr
      006163 A3               [24] 1245 	inc	dptr
      006164 E4               [12] 1246 	clr	a
      006165 93               [24] 1247 	movc	a,@a+dptr
      006166 FC               [12] 1248 	mov	r4,a
      006167 A3               [24] 1249 	inc	dptr
      006168 E4               [12] 1250 	clr	a
      006169 93               [24] 1251 	movc	a,@a+dptr
                                   1252 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      00616A FD               [12] 1253 	mov	r5,a
      00616B 4C               [12] 1254 	orl	a,r4
      00616C 70 04            [24] 1255 	jnz	00124$
      00616E 90 00 00         [24] 1256 	mov	dptr,#0x0000
      006171 22               [24] 1257 	ret
      006172                       1258 00124$:
                                   1259 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      006172 90 07 F9         [24] 1260 	mov	dptr,#_descriptor_select_type_10000_269
      006175 E0               [24] 1261 	movx	a,@dptr
      006176 FB               [12] 1262 	mov	r3,a
      006177 BB 22 28         [24] 1263 	cjne	r3,#0x22,00126$
                                   1264 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      00617A 8E 82            [24] 1265 	mov	dpl,r6
      00617C 8F 83            [24] 1266 	mov	dph,r7
      00617E E4               [12] 1267 	clr	a
      00617F 93               [24] 1268 	movc	a,@a+dptr
      006180 FE               [12] 1269 	mov	r6,a
      006181 A3               [24] 1270 	inc	dptr
      006182 E4               [12] 1271 	clr	a
      006183 93               [24] 1272 	movc	a,@a+dptr
      006184 FF               [12] 1273 	mov	r7,a
      006185 90 07 F4         [24] 1274 	mov	dptr,#_control_pointer
      006188 EE               [12] 1275 	mov	a,r6
      006189 F0               [24] 1276 	movx	@dptr,a
      00618A EF               [12] 1277 	mov	a,r7
      00618B A3               [24] 1278 	inc	dptr
      00618C F0               [24] 1279 	movx	@dptr,a
                                   1280 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      00618D 74 07            [12] 1281 	mov	a,#0x07
      00618F 2C               [12] 1282 	add	a, r4
      006190 F5 82            [12] 1283 	mov	dpl,a
      006192 E4               [12] 1284 	clr	a
      006193 3D               [12] 1285 	addc	a, r5
      006194 F5 83            [12] 1286 	mov	dph,a
      006196 E4               [12] 1287 	clr	a
      006197 93               [24] 1288 	movc	a,@a+dptr
      006198 FE               [12] 1289 	mov	r6,a
      006199 A3               [24] 1290 	inc	dptr
      00619A E4               [12] 1291 	clr	a
      00619B 93               [24] 1292 	movc	a,@a+dptr
      00619C FF               [12] 1293 	mov	r7,a
      00619D 8E 82            [24] 1294 	mov	dpl, r6
      00619F 8F 83            [24] 1295 	mov	dph, r7
      0061A1 22               [24] 1296 	ret
      0061A2                       1297 00126$:
                                   1298 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      0061A2 90 07 F4         [24] 1299 	mov	dptr,#_control_pointer
      0061A5 EC               [12] 1300 	mov	a,r4
      0061A6 F0               [24] 1301 	movx	@dptr,a
      0061A7 ED               [12] 1302 	mov	a,r5
      0061A8 A3               [24] 1303 	inc	dptr
      0061A9 F0               [24] 1304 	movx	@dptr,a
                                   1305 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      0061AA 90 00 09         [24] 1306 	mov	dptr,#0x0009
      0061AD 22               [24] 1307 	ret
      0061AE                       1308 00128$:
                                   1309 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      0061AE 90 00 00         [24] 1310 	mov	dptr,#0x0000
                                   1311 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      0061B1 22               [24] 1312 	ret
                                   1313 ;------------------------------------------------------------
                                   1314 ;Allocation info for local variables in function 'control_setup'
                                   1315 ;------------------------------------------------------------
                                   1316 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1317 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1318 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1319 ;type          Allocated with name '_control_setup_type_10000_287'
                                   1320 ;value         Allocated with name '_control_setup_value_10000_287'
                                   1321 ;index         Allocated with name '_control_setup_index_10000_287'
                                   1322 ;length        Allocated with name '_control_setup_length_10000_287'
                                   1323 ;endpoint      Allocated with name '_control_setup_endpoint_10000_287'
                                   1324 ;i             Allocated with name '_control_setup_i_10000_287'
                                   1325 ;offset        Allocated with name '_control_setup_offset_10000_287'
                                   1326 ;report_id     Allocated with name '_control_setup_report_id_10000_287'
                                   1327 ;------------------------------------------------------------
                                   1328 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1329 ;	-----------------------------------------
                                   1330 ;	 function control_setup
                                   1331 ;	-----------------------------------------
      0061B2                       1332 _control_setup:
                                   1333 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      0061B2 90 10 00         [24] 1334 	mov	dptr,#0x1000
      0061B5 E0               [24] 1335 	movx	a,@dptr
      0061B6 FF               [12] 1336 	mov	r7,a
                                   1337 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      0061B7 A3               [24] 1338 	inc	dptr
      0061B8 A3               [24] 1339 	inc	dptr
      0061B9 E0               [24] 1340 	movx	a,@dptr
      0061BA FE               [12] 1341 	mov	r6,a
      0061BB A3               [24] 1342 	inc	dptr
      0061BC E0               [24] 1343 	movx	a,@dptr
      0061BD FC               [12] 1344 	mov	r4,a
      0061BE 7D 00            [12] 1345 	mov	r5,#0x00
      0061C0 8E 03            [24] 1346 	mov	ar3,r6
      0061C2 7E 00            [12] 1347 	mov	r6,#0x00
      0061C4 ED               [12] 1348 	mov	a,r5
      0061C5 4B               [12] 1349 	orl	a,r3
      0061C6 FD               [12] 1350 	mov	r5,a
      0061C7 EC               [12] 1351 	mov	a,r4
      0061C8 4E               [12] 1352 	orl	a,r6
      0061C9 FE               [12] 1353 	mov	r6,a
                                   1354 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      0061CA A3               [24] 1355 	inc	dptr
      0061CB E0               [24] 1356 	movx	a,@dptr
      0061CC FC               [12] 1357 	mov	r4,a
      0061CD A3               [24] 1358 	inc	dptr
      0061CE E0               [24] 1359 	movx	a,@dptr
      0061CF FA               [12] 1360 	mov	r2,a
      0061D0 7B 00            [12] 1361 	mov	r3,#0x00
      0061D2 8C 01            [24] 1362 	mov	ar1,r4
      0061D4 7C 00            [12] 1363 	mov	r4,#0x00
      0061D6 EB               [12] 1364 	mov	a,r3
      0061D7 49               [12] 1365 	orl	a,r1
      0061D8 FB               [12] 1366 	mov	r3,a
      0061D9 EA               [12] 1367 	mov	a,r2
      0061DA 4C               [12] 1368 	orl	a,r4
      0061DB FC               [12] 1369 	mov	r4,a
                                   1370 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      0061DC C3               [12] 1371 	clr	c
      0061DD EB               [12] 1372 	mov	a,r3
      0061DE 94 03            [12] 1373 	subb	a,#0x03
      0061E0 EC               [12] 1374 	mov	a,r4
      0061E1 94 00            [12] 1375 	subb	a,#0x00
      0061E3 92 17            [24] 1376 	mov	_control_setup_valid_interface_10000_287,c
                                   1377 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      0061E5 EB               [12] 1378 	mov	a,r3
      0061E6 4C               [12] 1379 	orl	a,r4
      0061E7 B4 01 00         [24] 1380 	cjne	a,#0x01,01201$
      0061EA                       1381 01201$:
      0061EA 92 18            [24] 1382 	mov	_control_setup_zero_index_10000_287,c
                                   1383 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      0061EC ED               [12] 1384 	mov	a,r5
      0061ED 4E               [12] 1385 	orl	a,r6
      0061EE B4 01 00         [24] 1386 	cjne	a,#0x01,01202$
      0061F1                       1387 01202$:
                                   1388 ;	assignBit
      0061F1 92 1B            [24] 1389 	mov  _control_setup_sloc0_1_0,c
      0061F3 92 19            [24] 1390 	mov	_control_setup_zero_value_10000_287,c
                                   1391 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      0061F5 90 07 FC         [24] 1392 	mov	dptr,#_control_setup_offset_10000_287
      0061F8 E4               [12] 1393 	clr	a
      0061F9 F0               [24] 1394 	movx	@dptr,a
                                   1395 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      0061FA 90 07 99         [24] 1396 	mov	dptr,#_raw_state
      0061FD E0               [24] 1397 	movx	a,@dptr
      0061FE FA               [12] 1398 	mov	r2,a
      0061FF BA 01 05         [24] 1399 	cjne	r2,#0x01,00102$
      006202 90 07 99         [24] 1400 	mov	dptr,#_raw_state
      006205 E4               [12] 1401 	clr	a
      006206 F0               [24] 1402 	movx	@dptr,a
      006207                       1403 00102$:
                                   1404 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      006207 C0 07            [24] 1405 	push	ar7
      006209 90 07 F1         [24] 1406 	mov	dptr,#_output_kind
      00620C E4               [12] 1407 	clr	a
      00620D F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      00620E 90 07 F0         [24] 1410 	mov	dptr,#_control_phase
      006211 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      006212 90 07 F3         [24] 1413 	mov	dptr,#_control_zlp
      006215 F0               [24] 1414 	movx	@dptr,a
                                   1415 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      006216 90 10 01         [24] 1416 	mov	dptr,#0x1001
      006219 E0               [24] 1417 	movx	a,@dptr
      00621A 90 07 8B         [24] 1418 	mov	dptr,#_D0SetupReqCode
      00621D F0               [24] 1419 	movx	@dptr,a
                                   1420 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      00621E 90 10 06         [24] 1421 	mov	dptr,#0x1006
      006221 E0               [24] 1422 	movx	a,@dptr
      006222 FA               [12] 1423 	mov	r2,a
      006223 A3               [24] 1424 	inc	dptr
      006224 E0               [24] 1425 	movx	a,@dptr
      006225 F9               [12] 1426 	mov	r1,a
      006226 78 00            [12] 1427 	mov	r0,#0x00
      006228 7F 00            [12] 1428 	mov	r7,#0x00
      00622A 90 07 8C         [24] 1429 	mov	dptr,#_D0SetupLen
      00622D E8               [12] 1430 	mov	a,r0
      00622E 4A               [12] 1431 	orl	a,r2
      00622F F0               [24] 1432 	movx	@dptr,a
      006230 E9               [12] 1433 	mov	a,r1
      006231 4F               [12] 1434 	orl	a,r7
      006232 A3               [24] 1435 	inc	dptr
      006233 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      006234 90 07 8C         [24] 1438 	mov	dptr,#_D0SetupLen
      006237 E0               [24] 1439 	movx	a,@dptr
      006238 FA               [12] 1440 	mov	r2,a
      006239 A3               [24] 1441 	inc	dptr
      00623A E0               [24] 1442 	movx	a,@dptr
      00623B 4A               [12] 1443 	orl	a,r2
      00623C B4 01 00         [24] 1444 	cjne	a,#0x01,01205$
      00623F                       1445 01205$:
      00623F 92 1A            [24] 1446 	mov	_control_setup_zero_length_10000_287,c
                                   1447 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006241 90 22 00         [24] 1448 	mov	dptr,#0x2200
      006244 74 C2            [12] 1449 	mov	a,#0xc2
      006246 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      006247 90 22 08         [24] 1452 	mov	dptr,#0x2208
      00624A E4               [12] 1453 	clr	a
      00624B F0               [24] 1454 	movx	@dptr,a
                                   1455 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      00624C 90 07 8B         [24] 1456 	mov	dptr,#_D0SetupReqCode
      00624F E0               [24] 1457 	movx	a,@dptr
      006250 F5 16            [12] 1458 	mov	_control_setup_sloc1_1_0,a
      006252 C3               [12] 1459 	clr	c
      006253 74 0B            [12] 1460 	mov	a,#0x0b
      006255 95 16            [12] 1461 	subb	a,_control_setup_sloc1_1_0
      006257 D0 07            [24] 1462 	pop	ar7
      006259 50 03            [24] 1463 	jnc	01206$
      00625B 02 5F 99         [24] 1464 	ljmp	_control_stall
      00625E                       1465 01206$:
                                   1466 ;	free result
      00625E E5 16            [12] 1467 	mov	a,_control_setup_sloc1_1_0
      006260 F5 F0            [12] 1468 	mov	b,a
      006262 24 0B            [12] 1469 	add	a,#(01207$-3-.)
      006264 83               [24] 1470 	movc	a,@a+pc
      006265 F5 82            [12] 1471 	mov	dpl,a
      006267 E5 F0            [12] 1472 	mov	a,b
      006269 24 10            [12] 1473 	add	a,#(01208$-3-.)
      00626B 83               [24] 1474 	movc	a,@a+pc
      00626C F5 83            [12] 1475 	mov	dph,a
      00626E E4               [12] 1476 	clr	a
      00626F 73               [24] 1477 	jmp	@a+dptr
      006270                       1478 01207$:
      006270 18                    1479 	.db	00188$
      006271 BE                    1480 	.db	00205$
      006272 01                    1481 	.db	00282$
      006273 BE                    1482 	.db	00205$
      006274 45                    1483 	.db	00290$
      006275 42                    1484 	.db	00116$
      006276 88                    1485 	.db	00103$
      006277 45                    1486 	.db	00290$
      006278 47                    1487 	.db	00150$
      006279 6B                    1488 	.db	00123$
      00627A 77                    1489 	.db	00157$
      00627B CA                    1490 	.db	00173$
      00627C                       1491 01208$:
      00627C 65                    1492 	.db	00188$>>8
      00627D 65                    1493 	.db	00205$>>8
      00627E 69                    1494 	.db	00282$>>8
      00627F 65                    1495 	.db	00205$>>8
      006280 69                    1496 	.db	00290$>>8
      006281 63                    1497 	.db	00116$>>8
      006282 62                    1498 	.db	00103$>>8
      006283 69                    1499 	.db	00290$>>8
      006284 64                    1500 	.db	00150$>>8
      006285 63                    1501 	.db	00123$>>8
      006286 64                    1502 	.db	00157$>>8
      006287 64                    1503 	.db	00173$>>8
                                   1504 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      006288                       1505 00103$:
                                   1506 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      006288 BF 80 02         [24] 1507 	cjne	r7,#0x80,01209$
      00628B 80 08            [24] 1508 	sjmp	00112$
      00628D                       1509 01209$:
      00628D BF 81 02         [24] 1510 	cjne	r7,#0x81,01210$
      006290 80 03            [24] 1511 	sjmp	01211$
      006292                       1512 01210$:
      006292 02 5F 99         [24] 1513 	ljmp	_control_stall
      006295                       1514 01211$:
      006295                       1515 00112$:
                                   1516 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      006295 8E 01            [24] 1517 	mov	ar1,r6
      006297 B9 21 02         [24] 1518 	cjne	r1,#0x21,01212$
      00629A 80 09            [24] 1519 	sjmp	00301$
      00629C                       1520 01212$:
      00629C B9 22 02         [24] 1521 	cjne	r1,#0x22,01213$
      00629F 80 04            [24] 1522 	sjmp	00301$
      0062A1                       1523 01213$:
                                   1524 ;	assignBit
      0062A1 C2 1C            [12] 1525 	clr	_control_setup_sloc2_1_0
      0062A3 80 02            [24] 1526 	sjmp	00302$
      0062A5                       1527 00301$:
                                   1528 ;	assignBit
      0062A5 D2 1C            [12] 1529 	setb	_control_setup_sloc2_1_0
      0062A7                       1530 00302$:
      0062A7 E4               [12] 1531 	clr	a
      0062A8 BF 81 01         [24] 1532 	cjne	r7,#0x81,01214$
      0062AB 04               [12] 1533 	inc	a
      0062AC                       1534 01214$:
      0062AC FA               [12] 1535 	mov	r2,a
      0062AD A2 1C            [12] 1536 	mov	c,_control_setup_sloc2_1_0
      0062AF E4               [12] 1537 	clr	a
      0062B0 33               [12] 1538 	rlc	a
      0062B1 B5 02 02         [24] 1539 	cjne	a,ar2,01216$
      0062B4 80 03            [24] 1540 	sjmp	00105$
      0062B6                       1541 01216$:
                                   1542 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      0062B6 02 5F 99         [24] 1543 	ljmp	_control_stall
      0062B9                       1544 00105$:
                                   1545 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      0062B9 8E 02            [24] 1546 	mov	ar2,r6
      0062BB 90 07 F6         [24] 1547 	mov	dptr,#_descriptor_select_PARM_2
      0062BE ED               [12] 1548 	mov	a,r5
      0062BF F0               [24] 1549 	movx	@dptr,a
      0062C0 90 07 F7         [24] 1550 	mov	dptr,#_descriptor_select_PARM_3
      0062C3 EB               [12] 1551 	mov	a,r3
      0062C4 F0               [24] 1552 	movx	@dptr,a
      0062C5 EC               [12] 1553 	mov	a,r4
      0062C6 A3               [24] 1554 	inc	dptr
      0062C7 F0               [24] 1555 	movx	@dptr,a
      0062C8 8A 82            [24] 1556 	mov	dpl, r2
      0062CA 12 60 37         [24] 1557 	lcall	_descriptor_select
      0062CD 85 82 17         [24] 1558 	mov	_control_setup_sloc3_1_0,dpl
      0062D0 85 83 18         [24] 1559 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1560 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      0062D3 E5 17            [12] 1561 	mov	a,_control_setup_sloc3_1_0
      0062D5 45 18            [12] 1562 	orl	a,(_control_setup_sloc3_1_0 + 1)
      0062D7 70 03            [24] 1563 	jnz	00107$
      0062D9 02 5F 99         [24] 1564 	ljmp	_control_stall
      0062DC                       1565 00107$:
                                   1566 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      0062DC 90 07 8C         [24] 1567 	mov	dptr,#_D0SetupLen
      0062DF E0               [24] 1568 	movx	a,@dptr
      0062E0 F8               [12] 1569 	mov	r0,a
      0062E1 A3               [24] 1570 	inc	dptr
      0062E2 E0               [24] 1571 	movx	a,@dptr
      0062E3 FA               [12] 1572 	mov	r2,a
      0062E4 C3               [12] 1573 	clr	c
      0062E5 E5 17            [12] 1574 	mov	a,_control_setup_sloc3_1_0
      0062E7 98               [12] 1575 	subb	a,r0
      0062E8 E5 18            [12] 1576 	mov	a,(_control_setup_sloc3_1_0 + 1)
      0062EA 9A               [12] 1577 	subb	a,r2
      0062EB 50 06            [24] 1578 	jnc	00303$
      0062ED E5 17            [12] 1579 	mov	a,_control_setup_sloc3_1_0
      0062EF 54 3F            [12] 1580 	anl	a,#0x3f
      0062F1 60 04            [24] 1581 	jz	00304$
      0062F3                       1582 00303$:
                                   1583 ;	assignBit
      0062F3 C2 1C            [12] 1584 	clr	_control_setup_sloc2_1_0
      0062F5 80 02            [24] 1585 	sjmp	00305$
      0062F7                       1586 00304$:
                                   1587 ;	assignBit
      0062F7 D2 1C            [12] 1588 	setb	_control_setup_sloc2_1_0
      0062F9                       1589 00305$:
      0062F9 90 07 F3         [24] 1590 	mov	dptr,#_control_zlp
      0062FC A2 1C            [12] 1591 	mov	c,_control_setup_sloc2_1_0
      0062FE E4               [12] 1592 	clr	a
      0062FF 33               [12] 1593 	rlc	a
      006300 F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      006301 90 07 8C         [24] 1596 	mov	dptr,#_D0SetupLen
      006304 E0               [24] 1597 	movx	a,@dptr
      006305 F9               [12] 1598 	mov	r1,a
      006306 A3               [24] 1599 	inc	dptr
      006307 E0               [24] 1600 	movx	a,@dptr
      006308 FA               [12] 1601 	mov	r2,a
      006309 C3               [12] 1602 	clr	c
      00630A E5 17            [12] 1603 	mov	a,_control_setup_sloc3_1_0
      00630C 99               [12] 1604 	subb	a,r1
      00630D E5 18            [12] 1605 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00630F 9A               [12] 1606 	subb	a,r2
      006310 50 0A            [24] 1607 	jnc	00109$
                                   1608 ;	free result
      006312 90 07 8C         [24] 1609 	mov	dptr,#_D0SetupLen
      006315 E5 17            [12] 1610 	mov	a,_control_setup_sloc3_1_0
      006317 F0               [24] 1611 	movx	@dptr,a
      006318 E5 18            [12] 1612 	mov	a,(_control_setup_sloc3_1_0 + 1)
      00631A A3               [24] 1613 	inc	dptr
      00631B F0               [24] 1614 	movx	@dptr,a
      00631C                       1615 00109$:
                                   1616 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      00631C 90 07 8C         [24] 1617 	mov	dptr,#_D0SetupLen
      00631F E0               [24] 1618 	movx	a,@dptr
      006320 F9               [12] 1619 	mov	r1,a
      006321 A3               [24] 1620 	inc	dptr
      006322 E0               [24] 1621 	movx	a,@dptr
      006323 49               [12] 1622 	orl	a,r1
      006324 60 04            [24] 1623 	jz	00306$
      006326 7A 01            [12] 1624 	mov	r2,#0x01
      006328 80 02            [24] 1625 	sjmp	00307$
      00632A                       1626 00306$:
      00632A 7A 02            [12] 1627 	mov	r2,#0x02
      00632C                       1628 00307$:
      00632C 90 07 F0         [24] 1629 	mov	dptr,#_control_phase
      00632F EA               [12] 1630 	mov	a,r2
      006330 F0               [24] 1631 	movx	@dptr,a
                                   1632 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      006331 90 07 8C         [24] 1633 	mov	dptr,#_D0SetupLen
      006334 E0               [24] 1634 	movx	a,@dptr
      006335 F9               [12] 1635 	mov	r1,a
      006336 A3               [24] 1636 	inc	dptr
      006337 E0               [24] 1637 	movx	a,@dptr
      006338 49               [12] 1638 	orl	a,r1
      006339 60 03            [24] 1639 	jz	00111$
                                   1640 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      00633B 02 5F BB         [24] 1641 	ljmp	_control_next
      00633E                       1642 00111$:
      00633E 22               [24] 1643 	ret
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      00633F 02 5F 99         [24] 1645 	ljmp	_control_stall
                                   1646 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      006342                       1647 00116$:
                                   1648 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      006342 EF               [12] 1649 	mov	a,r7
      006343 70 23            [24] 1650 	jnz	00118$
      006345 30 18 20         [24] 1651 	jnb	_control_setup_zero_index_10000_287,00118$
      006348 30 1A 1D         [24] 1652 	jnb	_control_setup_zero_length_10000_287,00118$
      00634B 8D 01            [24] 1653 	mov	ar1,r5
      00634D 8E 02            [24] 1654 	mov	ar2,r6
      00634F C3               [12] 1655 	clr	c
      006350 74 7F            [12] 1656 	mov	a,#0x7f
      006352 99               [12] 1657 	subb	a,r1
      006353 E4               [12] 1658 	clr	a
      006354 9A               [12] 1659 	subb	a,r2
      006355 40 11            [24] 1660 	jc	00118$
                                   1661 ;	free result
                                   1662 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      006357 90 07 8C         [24] 1663 	mov	dptr,#_D0SetupLen
      00635A ED               [12] 1664 	mov	a,r5
      00635B F0               [24] 1665 	movx	@dptr,a
      00635C EE               [12] 1666 	mov	a,r6
      00635D A3               [24] 1667 	inc	dptr
      00635E F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      00635F 90 07 F0         [24] 1670 	mov	dptr,#_control_phase
      006362 74 03            [12] 1671 	mov	a,#0x03
      006364 F0               [24] 1672 	movx	@dptr,a
      006365 02 69 48         [24] 1673 	ljmp	00291$
      006368                       1674 00118$:
                                   1675 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      006368 02 5F 99         [24] 1676 	ljmp	_control_stall
                                   1677 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      00636B                       1678 00123$:
                                   1679 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      00636B EF               [12] 1680 	mov	a,r7
      00636C 70 3C            [24] 1681 	jnz	00145$
      00636E 30 18 39         [24] 1682 	jnb	_control_setup_zero_index_10000_287,00145$
      006371 30 1A 36         [24] 1683 	jnb	_control_setup_zero_length_10000_287,00145$
      006374 8D 01            [24] 1684 	mov	ar1,r5
      006376 8E 02            [24] 1685 	mov	ar2,r6
      006378 C3               [12] 1686 	clr	c
      006379 74 01            [12] 1687 	mov	a,#0x01
      00637B 99               [12] 1688 	subb	a,r1
      00637C E4               [12] 1689 	clr	a
      00637D 9A               [12] 1690 	subb	a,r2
      00637E 40 2A            [24] 1691 	jc	00145$
                                   1692 ;	free result
                                   1693 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      006380 C0 06            [24] 1694 	push	ar6
      006382 C0 05            [24] 1695 	push	ar5
      006384 12 5F 3C         [24] 1696 	lcall	_endpoints_reset
      006387 D0 05            [24] 1697 	pop	ar5
      006389 D0 06            [24] 1698 	pop	ar6
                                   1699 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      00638B 90 07 91         [24] 1700 	mov	dptr,#_D0UsbConfig
      00638E ED               [12] 1701 	mov	a,r5
      00638F F0               [24] 1702 	movx	@dptr,a
                                   1703 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      006390 A2 1B            [12] 1704 	mov	c,_control_setup_sloc0_1_0
      006392 B3               [12] 1705 	cpl	c
      006393 92 1C            [24] 1706 	mov	_control_setup_sloc2_1_0,c
      006395 90 07 92         [24] 1707 	mov	dptr,#_USB_EnumStatus
      006398 E4               [12] 1708 	clr	a
      006399 33               [12] 1709 	rlc	a
      00639A F0               [24] 1710 	movx	@dptr,a
                                   1711 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      00639B 90 07 BB         [24] 1712 	mov	dptr,#_keyboard_reset
      00639E 74 01            [12] 1713 	mov	a,#0x01
      0063A0 F0               [24] 1714 	movx	@dptr,a
                                   1715 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      0063A1 90 07 F0         [24] 1716 	mov	dptr,#_control_phase
      0063A4 74 03            [12] 1717 	mov	a,#0x03
      0063A6 F0               [24] 1718 	movx	@dptr,a
      0063A7 02 69 48         [24] 1719 	ljmp	00291$
      0063AA                       1720 00145$:
                                   1721 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      0063AA BF 21 02         [24] 1722 	cjne	r7,#0x21,01231$
      0063AD 80 03            [24] 1723 	sjmp	01232$
      0063AF                       1724 01231$:
      0063AF 02 5F 99         [24] 1725 	ljmp	_control_stall
      0063B2                       1726 01232$:
      0063B2 90 07 91         [24] 1727 	mov	dptr,#_D0UsbConfig
      0063B5 E0               [24] 1728 	movx	a,@dptr
      0063B6 70 03            [24] 1729 	jnz	01233$
      0063B8 02 5F 99         [24] 1730 	ljmp	_control_stall
      0063BB                       1731 01233$:
                                   1732 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      0063BB BB 01 2D         [24] 1733 	cjne	r3,#0x01,00135$
      0063BE BC 00 2A         [24] 1734 	cjne	r4,#0x00,00135$
      0063C1 8D 01            [24] 1735 	mov	ar1,r5
      0063C3 8E 02            [24] 1736 	mov	ar2,r6
      0063C5 B9 00 23         [24] 1737 	cjne	r1,#0x00,00135$
      0063C8 BA 02 20         [24] 1738 	cjne	r2,#0x02,00135$
      0063CB 90 07 8C         [24] 1739 	mov	dptr,#_D0SetupLen
      0063CE E0               [24] 1740 	movx	a,@dptr
      0063CF F9               [12] 1741 	mov	r1,a
      0063D0 A3               [24] 1742 	inc	dptr
      0063D1 E0               [24] 1743 	movx	a,@dptr
      0063D2 FA               [12] 1744 	mov	r2,a
      0063D3 B9 20 15         [24] 1745 	cjne	r1,#0x20,00135$
      0063D6 BA 00 12         [24] 1746 	cjne	r2,#0x00,00135$
      0063D9 90 07 99         [24] 1747 	mov	dptr,#_raw_state
      0063DC E0               [24] 1748 	movx	a,@dptr
      0063DD 70 0C            [24] 1749 	jnz	00135$
                                   1750 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      0063DF 90 07 99         [24] 1751 	mov	dptr,#_raw_state
      0063E2 74 01            [12] 1752 	mov	a,#0x01
      0063E4 F0               [24] 1753 	movx	@dptr,a
                                   1754 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      0063E5 90 07 F1         [24] 1755 	mov	dptr,#_output_kind
      0063E8 F0               [24] 1756 	movx	@dptr,a
      0063E9 80 52            [24] 1757 	sjmp	00136$
      0063EB                       1758 00135$:
                                   1759 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      0063EB EB               [12] 1760 	mov	a,r3
      0063EC 4C               [12] 1761 	orl	a,r4
      0063ED 70 20            [24] 1762 	jnz	00130$
      0063EF 8D 01            [24] 1763 	mov	ar1,r5
      0063F1 8E 02            [24] 1764 	mov	ar2,r6
      0063F3 B9 00 19         [24] 1765 	cjne	r1,#0x00,00130$
      0063F6 BA 02 16         [24] 1766 	cjne	r2,#0x02,00130$
      0063F9 90 07 8C         [24] 1767 	mov	dptr,#_D0SetupLen
      0063FC E0               [24] 1768 	movx	a,@dptr
      0063FD F9               [12] 1769 	mov	r1,a
      0063FE A3               [24] 1770 	inc	dptr
      0063FF E0               [24] 1771 	movx	a,@dptr
      006400 FA               [12] 1772 	mov	r2,a
      006401 B9 01 0B         [24] 1773 	cjne	r1,#0x01,00130$
      006404 BA 00 08         [24] 1774 	cjne	r2,#0x00,00130$
                                   1775 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      006407 90 07 F1         [24] 1776 	mov	dptr,#_output_kind
      00640A 74 02            [12] 1777 	mov	a,#0x02
      00640C F0               [24] 1778 	movx	@dptr,a
      00640D 80 2E            [24] 1779 	sjmp	00136$
      00640F                       1780 00130$:
                                   1781 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      00640F BB 02 28         [24] 1782 	cjne	r3,#0x02,00125$
      006412 BC 00 25         [24] 1783 	cjne	r4,#0x00,00125$
      006415 8D 01            [24] 1784 	mov	ar1,r5
      006417 8E 02            [24] 1785 	mov	ar2,r6
      006419 B9 06 1E         [24] 1786 	cjne	r1,#0x06,00125$
      00641C BA 02 1B         [24] 1787 	cjne	r2,#0x02,00125$
      00641F 90 07 8C         [24] 1788 	mov	dptr,#_D0SetupLen
      006422 E0               [24] 1789 	movx	a,@dptr
      006423 F9               [12] 1790 	mov	r1,a
      006424 A3               [24] 1791 	inc	dptr
      006425 E0               [24] 1792 	movx	a,@dptr
      006426 FA               [12] 1793 	mov	r2,a
      006427 B9 02 10         [24] 1794 	cjne	r1,#0x02,00125$
      00642A BA 00 0D         [24] 1795 	cjne	r2,#0x00,00125$
                                   1796 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      00642D 90 07 F1         [24] 1797 	mov	dptr,#_output_kind
      006430 74 03            [12] 1798 	mov	a,#0x03
      006432 F0               [24] 1799 	movx	@dptr,a
                                   1800 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      006433 90 07 F2         [24] 1801 	mov	dptr,#_output_report_id
      006436 23               [12] 1802 	rl	a
      006437 F0               [24] 1803 	movx	@dptr,a
      006438 80 03            [24] 1804 	sjmp	00136$
      00643A                       1805 00125$:
                                   1806 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      00643A 02 5F 99         [24] 1807 	ljmp	_control_stall
      00643D                       1808 00136$:
                                   1809 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      00643D 90 07 F0         [24] 1810 	mov	dptr,#_control_phase
      006440 74 04            [12] 1811 	mov	a,#0x04
      006442 F0               [24] 1812 	movx	@dptr,a
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      006443 22               [24] 1814 	ret
                                   1815 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      006444 02 5F 99         [24] 1816 	ljmp	_control_stall
                                   1817 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      006447                       1818 00150$:
                                   1819 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      006447 BF 80 2A         [24] 1820 	cjne	r7,#0x80,00152$
      00644A 30 18 27         [24] 1821 	jnb	_control_setup_zero_index_10000_287,00152$
      00644D 30 19 24         [24] 1822 	jnb	_control_setup_zero_value_10000_287,00152$
      006450 90 07 8C         [24] 1823 	mov	dptr,#_D0SetupLen
      006453 E0               [24] 1824 	movx	a,@dptr
      006454 F9               [12] 1825 	mov	r1,a
      006455 A3               [24] 1826 	inc	dptr
      006456 E0               [24] 1827 	movx	a,@dptr
      006457 FA               [12] 1828 	mov	r2,a
      006458 B9 01 19         [24] 1829 	cjne	r1,#0x01,00152$
      00645B BA 00 16         [24] 1830 	cjne	r2,#0x00,00152$
                                   1831 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      00645E 90 07 91         [24] 1832 	mov	dptr,#_D0UsbConfig
      006461 E0               [24] 1833 	movx	a,@dptr
      006462 90 10 00         [24] 1834 	mov	dptr,#0x1000
      006465 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      006466 90 22 08         [24] 1837 	mov	dptr,#0x2208
      006469 74 01            [12] 1838 	mov	a,#0x01
      00646B F0               [24] 1839 	movx	@dptr,a
                                   1840 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      00646C 90 07 F0         [24] 1841 	mov	dptr,#_control_phase
      00646F 04               [12] 1842 	inc	a
      006470 F0               [24] 1843 	movx	@dptr,a
      006471 02 69 48         [24] 1844 	ljmp	00291$
      006474                       1845 00152$:
                                   1846 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      006474 02 5F 99         [24] 1847 	ljmp	_control_stall
                                   1848 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      006477                       1849 00157$:
                                   1850 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      006477 BF 81 2C         [24] 1851 	cjne	r7,#0x81,00167$
      00647A 30 17 29         [24] 1852 	jnb	_control_setup_valid_interface_10000_287,00167$
      00647D 30 19 26         [24] 1853 	jnb	_control_setup_zero_value_10000_287,00167$
      006480 90 07 8C         [24] 1854 	mov	dptr,#_D0SetupLen
      006483 E0               [24] 1855 	movx	a,@dptr
      006484 F9               [12] 1856 	mov	r1,a
      006485 A3               [24] 1857 	inc	dptr
      006486 E0               [24] 1858 	movx	a,@dptr
      006487 FA               [12] 1859 	mov	r2,a
      006488 B9 01 1B         [24] 1860 	cjne	r1,#0x01,00167$
      00648B BA 00 18         [24] 1861 	cjne	r2,#0x00,00167$
      00648E 90 07 91         [24] 1862 	mov	dptr,#_D0UsbConfig
      006491 E0               [24] 1863 	movx	a,@dptr
      006492 60 12            [24] 1864 	jz	00167$
                                   1865 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      006494 90 10 00         [24] 1866 	mov	dptr,#0x1000
      006497 E4               [12] 1867 	clr	a
      006498 F0               [24] 1868 	movx	@dptr,a
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      006499 90 22 08         [24] 1870 	mov	dptr,#0x2208
      00649C 04               [12] 1871 	inc	a
      00649D F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      00649E 90 07 F0         [24] 1874 	mov	dptr,#_control_phase
      0064A1 04               [12] 1875 	inc	a
      0064A2 F0               [24] 1876 	movx	@dptr,a
      0064A3 02 69 48         [24] 1877 	ljmp	00291$
      0064A6                       1878 00167$:
                                   1879 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      0064A6 30 17 1E         [24] 1880 	jnb	_control_setup_valid_interface_10000_287,00161$
      0064A9 90 07 91         [24] 1881 	mov	dptr,#_D0UsbConfig
      0064AC E0               [24] 1882 	movx	a,@dptr
      0064AD 60 18            [24] 1883 	jz	00161$
      0064AF BF 21 15         [24] 1884 	cjne	r7,#0x21,00161$
      0064B2 30 1A 12         [24] 1885 	jnb	_control_setup_zero_length_10000_287,00161$
                                   1886 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      0064B5 EB               [12] 1887 	mov	a,r3
      0064B6 4C               [12] 1888 	orl	a,r4
      0064B7 70 05            [24] 1889 	jnz	00159$
      0064B9 90 06 53         [24] 1890 	mov	dptr,#_keyboard_idle
      0064BC EE               [12] 1891 	mov	a,r6
      0064BD F0               [24] 1892 	movx	@dptr,a
      0064BE                       1893 00159$:
                                   1894 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      0064BE 90 07 F0         [24] 1895 	mov	dptr,#_control_phase
      0064C1 74 03            [12] 1896 	mov	a,#0x03
      0064C3 F0               [24] 1897 	movx	@dptr,a
      0064C4 02 69 48         [24] 1898 	ljmp	00291$
      0064C7                       1899 00161$:
                                   1900 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      0064C7 02 5F 99         [24] 1901 	ljmp	_control_stall
                                   1902 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      0064CA                       1903 00173$:
                                   1904 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      0064CA BF 01 18         [24] 1905 	cjne	r7,#0x01,00182$
      0064CD 30 17 15         [24] 1906 	jnb	_control_setup_valid_interface_10000_287,00182$
      0064D0 30 19 12         [24] 1907 	jnb	_control_setup_zero_value_10000_287,00182$
      0064D3 30 1A 0F         [24] 1908 	jnb	_control_setup_zero_length_10000_287,00182$
      0064D6 90 07 91         [24] 1909 	mov	dptr,#_D0UsbConfig
      0064D9 E0               [24] 1910 	movx	a,@dptr
      0064DA 60 09            [24] 1911 	jz	00182$
                                   1912 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      0064DC 90 07 F0         [24] 1913 	mov	dptr,#_control_phase
      0064DF 74 03            [12] 1914 	mov	a,#0x03
      0064E1 F0               [24] 1915 	movx	@dptr,a
      0064E2 02 69 48         [24] 1916 	ljmp	00291$
      0064E5                       1917 00182$:
                                   1918 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      0064E5 EB               [12] 1919 	mov	a,r3
      0064E6 4C               [12] 1920 	orl	a,r4
      0064E7 70 2C            [24] 1921 	jnz	00175$
      0064E9 90 07 91         [24] 1922 	mov	dptr,#_D0UsbConfig
      0064EC E0               [24] 1923 	movx	a,@dptr
      0064ED 60 26            [24] 1924 	jz	00175$
      0064EF BF 21 23         [24] 1925 	cjne	r7,#0x21,00175$
      0064F2 30 1A 20         [24] 1926 	jnb	_control_setup_zero_length_10000_287,00175$
      0064F5 8D 01            [24] 1927 	mov	ar1,r5
      0064F7 8E 02            [24] 1928 	mov	ar2,r6
      0064F9 C3               [12] 1929 	clr	c
      0064FA 74 01            [12] 1930 	mov	a,#0x01
      0064FC 99               [12] 1931 	subb	a,r1
      0064FD E4               [12] 1932 	clr	a
      0064FE 9A               [12] 1933 	subb	a,r2
      0064FF 40 14            [24] 1934 	jc	00175$
                                   1935 ;	free result
                                   1936 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      006501 90 0D E1         [24] 1937 	mov	dptr,#_keyboard_protocol
      006504 ED               [12] 1938 	mov	a,r5
      006505 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      006506 90 07 BB         [24] 1941 	mov	dptr,#_keyboard_reset
      006509 74 01            [12] 1942 	mov	a,#0x01
      00650B F0               [24] 1943 	movx	@dptr,a
                                   1944 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      00650C 90 07 F0         [24] 1945 	mov	dptr,#_control_phase
      00650F 74 03            [12] 1946 	mov	a,#0x03
      006511 F0               [24] 1947 	movx	@dptr,a
      006512 02 69 48         [24] 1948 	ljmp	00291$
      006515                       1949 00175$:
                                   1950 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      006515 02 5F 99         [24] 1951 	ljmp	_control_stall
                                   1952 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      006518                       1953 00188$:
                                   1954 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      006518 20 19 03         [24] 1955 	jb	_control_setup_zero_value_10000_287,01283$
      00651B 02 5F 99         [24] 1956 	ljmp	_control_stall
      00651E                       1957 01283$:
      00651E 90 07 8C         [24] 1958 	mov	dptr,#_D0SetupLen
      006521 E0               [24] 1959 	movx	a,@dptr
      006522 F9               [12] 1960 	mov	r1,a
      006523 A3               [24] 1961 	inc	dptr
      006524 E0               [24] 1962 	movx	a,@dptr
      006525 FA               [12] 1963 	mov	r2,a
      006526 B9 02 05         [24] 1964 	cjne	r1,#0x02,01284$
      006529 BA 00 02         [24] 1965 	cjne	r2,#0x00,01284$
      00652C 80 03            [24] 1966 	sjmp	01285$
      00652E                       1967 01284$:
      00652E 02 5F 99         [24] 1968 	ljmp	_control_stall
      006531                       1969 01285$:
                                   1970 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      006531 E4               [12] 1971 	clr	a
      006532 BF 80 01         [24] 1972 	cjne	r7,#0x80,01286$
      006535 04               [12] 1973 	inc	a
      006536                       1974 01286$:
      006536 FA               [12] 1975 	mov	r2,a
      006537 60 03            [24] 1976 	jz	00196$
      006539 20 18 35         [24] 1977 	jb	_control_setup_zero_index_10000_287,00189$
      00653C                       1978 00196$:
      00653C BF 81 09         [24] 1979 	cjne	r7,#0x81,00202$
      00653F 30 17 06         [24] 1980 	jnb	_control_setup_valid_interface_10000_287,00202$
      006542 90 07 91         [24] 1981 	mov	dptr,#_D0UsbConfig
      006545 E0               [24] 1982 	movx	a,@dptr
      006546 70 29            [24] 1983 	jnz	00189$
      006548                       1984 00202$:
                                   1985 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      006548 BF 82 70         [24] 1986 	cjne	r7,#0x82,00190$
      00654B 90 07 91         [24] 1987 	mov	dptr,#_D0UsbConfig
      00654E E0               [24] 1988 	movx	a,@dptr
      00654F 60 6A            [24] 1989 	jz	00190$
      006551 EB               [12] 1990 	mov	a,r3
      006552 4C               [12] 1991 	orl	a,r4
      006553 60 1C            [24] 1992 	jz	00189$
      006555 8B 00            [24] 1993 	mov	ar0,r3
      006557 8C 01            [24] 1994 	mov	ar1,r4
      006559 B8 80 05         [24] 1995 	cjne	r0,#0x80,01298$
      00655C B9 00 02         [24] 1996 	cjne	r1,#0x00,01298$
      00655F 80 10            [24] 1997 	sjmp	00189$
      006561                       1998 01298$:
      006561 C3               [12] 1999 	clr	c
      006562 E8               [12] 2000 	mov	a,r0
      006563 94 81            [12] 2001 	subb	a,#0x81
      006565 E9               [12] 2002 	mov	a,r1
      006566 94 00            [12] 2003 	subb	a,#0x00
      006568 40 51            [24] 2004 	jc	00190$
      00656A 74 83            [12] 2005 	mov	a,#0x83
      00656C 98               [12] 2006 	subb	a,r0
      00656D E4               [12] 2007 	clr	a
      00656E 99               [12] 2008 	subb	a,r1
      00656F 40 4A            [24] 2009 	jc	00190$
                                   2010 ;	free result
      006571                       2011 00189$:
                                   2012 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      006571 8B 01            [24] 2013 	mov	ar1,r3
      006573 53 01 07         [24] 2014 	anl	ar1,#0x07
                                   2015 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      006576 EA               [12] 2016 	mov	a,r2
      006577 60 0B            [24] 2017 	jz	00308$
      006579 90 07 93         [24] 2018 	mov	dptr,#_USB_SleepStatus
      00657C E0               [24] 2019 	movx	a,@dptr
      00657D 54 01            [12] 2020 	anl	a,#0x01
      00657F 25 E0            [12] 2021 	add	a,acc
      006581 FA               [12] 2022 	mov	r2,a
      006582 80 22            [24] 2023 	sjmp	00309$
      006584                       2024 00308$:
                                   2025 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      006584 BF 82 1B         [24] 2026 	cjne	r7,#0x82,00310$
      006587 E9               [12] 2027 	mov	a,r1
      006588 60 18            [24] 2028 	jz	00310$
      00658A 89 00            [24] 2029 	mov	ar0,r1
      00658C 79 00            [12] 2030 	mov	r1,#0x00
      00658E 74 22            [12] 2031 	mov	a,#0x22
      006590 29               [12] 2032 	add	a, r1
      006591 F9               [12] 2033 	mov	r1,a
      006592 88 82            [24] 2034 	mov	dpl,r0
      006594 89 83            [24] 2035 	mov	dph,r1
      006596 E0               [24] 2036 	movx	a,@dptr
      006597 F9               [12] 2037 	mov	r1,a
      006598 53 01 03         [24] 2038 	anl	ar1,#0x03
      00659B B9 03 04         [24] 2039 	cjne	r1,#0x03,00310$
      00659E 79 01            [12] 2040 	mov	r1,#0x01
      0065A0 80 02            [24] 2041 	sjmp	00311$
      0065A2                       2042 00310$:
      0065A2 79 00            [12] 2043 	mov	r1,#0x00
      0065A4                       2044 00311$:
      0065A4 89 02            [24] 2045 	mov	ar2,r1
      0065A6                       2046 00309$:
      0065A6 90 10 00         [24] 2047 	mov	dptr,#0x1000
      0065A9 EA               [12] 2048 	mov	a,r2
      0065AA F0               [24] 2049 	movx	@dptr,a
                                   2050 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      0065AB A3               [24] 2051 	inc	dptr
      0065AC E4               [12] 2052 	clr	a
      0065AD F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      0065AE 90 22 08         [24] 2055 	mov	dptr,#0x2208
      0065B1 74 02            [12] 2056 	mov	a,#0x02
      0065B3 F0               [24] 2057 	movx	@dptr,a
                                   2058 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      0065B4 90 07 F0         [24] 2059 	mov	dptr,#_control_phase
      0065B7 F0               [24] 2060 	movx	@dptr,a
      0065B8 02 69 48         [24] 2061 	ljmp	00291$
      0065BB                       2062 00190$:
                                   2063 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      0065BB 02 5F 99         [24] 2064 	ljmp	_control_stall
                                   2065 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      0065BE                       2066 00205$:
                                   2067 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      0065BE 20 1A 03         [24] 2068 	jb	_control_setup_zero_length_10000_287,01307$
      0065C1 02 66 51         [24] 2069 	ljmp	00279$
      0065C4                       2070 01307$:
      0065C4 90 07 91         [24] 2071 	mov	dptr,#_D0UsbConfig
      0065C7 E0               [24] 2072 	movx	a,@dptr
      0065C8 70 03            [24] 2073 	jnz	01308$
      0065CA 02 66 51         [24] 2074 	ljmp	00279$
      0065CD                       2075 01308$:
                                   2076 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      0065CD EF               [12] 2077 	mov	a,r7
      0065CE 70 29            [24] 2078 	jnz	00218$
      0065D0 8D 01            [24] 2079 	mov	ar1,r5
      0065D2 8E 02            [24] 2080 	mov	ar2,r6
      0065D4 B9 01 22         [24] 2081 	cjne	r1,#0x01,00218$
      0065D7 BA 00 1F         [24] 2082 	cjne	r2,#0x00,00218$
      0065DA 30 18 1C         [24] 2083 	jnb	_control_setup_zero_index_10000_287,00218$
                                   2084 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      0065DD 90 07 8B         [24] 2085 	mov	dptr,#_D0SetupReqCode
      0065E0 E0               [24] 2086 	movx	a,@dptr
      0065E1 FA               [12] 2087 	mov	r2,a
      0065E2 BA 03 0A         [24] 2088 	cjne	r2,#0x03,00207$
      0065E5 90 07 93         [24] 2089 	mov	dptr,#_USB_SleepStatus
      0065E8 E0               [24] 2090 	movx	a,@dptr
      0065E9 43 E0 01         [24] 2091 	orl	acc,#0x01
      0065EC F0               [24] 2092 	movx	@dptr,a
      0065ED 80 59            [24] 2093 	sjmp	00219$
      0065EF                       2094 00207$:
                                   2095 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      0065EF 90 07 93         [24] 2096 	mov	dptr,#_USB_SleepStatus
      0065F2 E0               [24] 2097 	movx	a,@dptr
      0065F3 53 E0 FE         [24] 2098 	anl	acc,#0xfe
      0065F6 F0               [24] 2099 	movx	@dptr,a
      0065F7 80 4F            [24] 2100 	sjmp	00219$
      0065F9                       2101 00218$:
                                   2102 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      0065F9 BF 02 49         [24] 2103 	cjne	r7,#0x02,00212$
      0065FC 30 19 46         [24] 2104 	jnb	_control_setup_zero_value_10000_287,00212$
      0065FF 8B 01            [24] 2105 	mov	ar1,r3
      006601 8C 02            [24] 2106 	mov	ar2,r4
      006603 C3               [12] 2107 	clr	c
      006604 E9               [12] 2108 	mov	a,r1
      006605 94 81            [12] 2109 	subb	a,#0x81
      006607 EA               [12] 2110 	mov	a,r2
      006608 94 00            [12] 2111 	subb	a,#0x00
      00660A 40 39            [24] 2112 	jc	00212$
      00660C 74 83            [12] 2113 	mov	a,#0x83
      00660E 99               [12] 2114 	subb	a,r1
      00660F E4               [12] 2115 	clr	a
      006610 9A               [12] 2116 	subb	a,r2
      006611 40 32            [24] 2117 	jc	00212$
                                   2118 ;	free result
                                   2119 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      006613 8B 02            [24] 2120 	mov	ar2,r3
      006615 53 02 07         [24] 2121 	anl	ar2,#0x07
                                   2122 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      006618 8A 00            [24] 2123 	mov	ar0,r2
      00661A 79 00            [12] 2124 	mov	r1,#0x00
      00661C 74 22            [12] 2125 	mov	a,#0x22
      00661E 29               [12] 2126 	add	a, r1
      00661F F9               [12] 2127 	mov	r1,a
      006620 88 17            [24] 2128 	mov	_control_setup_sloc3_1_0,r0
      006622 89 18            [24] 2129 	mov	(_control_setup_sloc3_1_0 + 1),r1
      006624 90 07 8B         [24] 2130 	mov	dptr,#_D0SetupReqCode
      006627 E0               [24] 2131 	movx	a,@dptr
      006628 F9               [12] 2132 	mov	r1,a
      006629 B9 03 04         [24] 2133 	cjne	r1,#0x03,00318$
      00662C 79 03            [12] 2134 	mov	r1,#0x03
      00662E 80 02            [24] 2135 	sjmp	00319$
      006630                       2136 00318$:
      006630 79 02            [12] 2137 	mov	r1,#0x02
      006632                       2138 00319$:
      006632 43 01 10         [24] 2139 	orl	ar1,#0x10
      006635 85 17 82         [24] 2140 	mov	dpl,_control_setup_sloc3_1_0
      006638 85 18 83         [24] 2141 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00663B E9               [12] 2142 	mov	a,r1
      00663C F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00663D BA 03 08         [24] 2145 	cjne	r2,#0x03,00219$
      006640 12 5F 1F         [24] 2146 	lcall	_raw_complete
      006643 80 03            [24] 2147 	sjmp	00219$
      006645                       2148 00212$:
                                   2149 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      006645 02 5F 99         [24] 2150 	ljmp	_control_stall
      006648                       2151 00219$:
                                   2152 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      006648 90 07 F0         [24] 2153 	mov	dptr,#_control_phase
      00664B 74 03            [12] 2154 	mov	a,#0x03
      00664D F0               [24] 2155 	movx	@dptr,a
      00664E 02 69 48         [24] 2156 	ljmp	00291$
      006651                       2157 00279$:
                                   2158 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      006651 E4               [12] 2159 	clr	a
      006652 BF A1 01         [24] 2160 	cjne	r7,#0xa1,01324$
      006655 04               [12] 2161 	inc	a
      006656                       2162 01324$:
      006656 FA               [12] 2163 	mov	r2,a
      006657 70 03            [24] 2164 	jnz	01326$
      006659 02 68 C3         [24] 2165 	ljmp	00273$
      00665C                       2166 01326$:
      00665C 90 07 8B         [24] 2167 	mov	dptr,#_D0SetupReqCode
      00665F E0               [24] 2168 	movx	a,@dptr
      006660 F9               [12] 2169 	mov	r1,a
      006661 B9 01 02         [24] 2170 	cjne	r1,#0x01,01327$
      006664 80 03            [24] 2171 	sjmp	01328$
      006666                       2172 01327$:
      006666 02 68 C3         [24] 2173 	ljmp	00273$
      006669                       2174 01328$:
      006669 90 07 91         [24] 2175 	mov	dptr,#_D0UsbConfig
      00666C E0               [24] 2176 	movx	a,@dptr
      00666D 70 03            [24] 2177 	jnz	01329$
      00666F 02 68 C3         [24] 2178 	ljmp	00273$
      006672                       2179 01329$:
      006672 90 07 8C         [24] 2180 	mov	dptr,#_D0SetupLen
      006675 E0               [24] 2181 	movx	a,@dptr
      006676 F8               [12] 2182 	mov	r0,a
      006677 A3               [24] 2183 	inc	dptr
      006678 E0               [24] 2184 	movx	a,@dptr
      006679 48               [12] 2185 	orl	a,r0
      00667A 70 03            [24] 2186 	jnz	01330$
      00667C 02 68 C3         [24] 2187 	ljmp	00273$
      00667F                       2188 01330$:
                                   2189 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      00667F C0 03            [24] 2190 	push	ar3
      006681 C0 04            [24] 2191 	push	ar4
      006683 8D 01            [24] 2192 	mov	ar1,r5
                                   2193 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      006685 8E 00            [24] 2194 	mov	ar0,r6
      006687 B8 01 03         [24] 2195 	cjne	r0,#0x01,01331$
      00668A E8               [12] 2196 	mov	a,r0
      00668B 80 01            [24] 2197 	sjmp	01332$
      00668D                       2198 01331$:
      00668D E4               [12] 2199 	clr	a
      00668E                       2200 01332$:
      00668E F5 17            [12] 2201 	mov	_control_setup_sloc3_1_0,a
      006690 D0 04            [24] 2202 	pop	ar4
      006692 D0 03            [24] 2203 	pop	ar3
      006694 E5 17            [12] 2204 	mov	a,_control_setup_sloc3_1_0
      006696 60 17            [24] 2205 	jz	00251$
      006698 EB               [12] 2206 	mov	a,r3
      006699 4C               [12] 2207 	orl	a,r4
      00669A 70 13            [24] 2208 	jnz	00251$
      00669C E9               [12] 2209 	mov	a,r1
      00669D 70 10            [24] 2210 	jnz	00251$
                                   2211 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      00669F 90 07 FA         [24] 2212 	mov	dptr,#_control_setup_length_10000_287
      0066A2 74 08            [12] 2213 	mov	a,#0x08
      0066A4 F0               [24] 2214 	movx	@dptr,a
      0066A5 E4               [12] 2215 	clr	a
      0066A6 A3               [24] 2216 	inc	dptr
      0066A7 F0               [24] 2217 	movx	@dptr,a
                                   2218 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      0066A8 90 07 FC         [24] 2219 	mov	dptr,#_control_setup_offset_10000_287
      0066AB F0               [24] 2220 	movx	@dptr,a
      0066AC 02 68 33         [24] 2221 	ljmp	00252$
      0066AF                       2222 00251$:
                                   2223 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      0066AF E5 17            [12] 2224 	mov	a,_control_setup_sloc3_1_0
      0066B1 60 27            [24] 2225 	jz	00245$
      0066B3 BB 02 24         [24] 2226 	cjne	r3,#0x02,00245$
      0066B6 BC 00 21         [24] 2227 	cjne	r4,#0x00,00245$
                                   2228 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      0066B9 B9 07 00         [24] 2229 	cjne	r1,#0x07,01339$
      0066BC                       2230 01339$:
      0066BC 50 1C            [24] 2231 	jnc	00245$
      0066BE E9               [12] 2232 	mov	a,r1
      0066BF 90 BE 68         [24] 2233 	mov	dptr,#_shared_lengths
      0066C2 93               [24] 2234 	movc	a,@a+dptr
      0066C3 F8               [12] 2235 	mov	r0,a
      0066C4 60 14            [24] 2236 	jz	00245$
                                   2237 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      0066C6 90 07 FA         [24] 2238 	mov	dptr,#_control_setup_length_10000_287
      0066C9 E8               [12] 2239 	mov	a,r0
      0066CA F0               [24] 2240 	movx	@dptr,a
      0066CB E4               [12] 2241 	clr	a
      0066CC A3               [24] 2242 	inc	dptr
      0066CD F0               [24] 2243 	movx	@dptr,a
                                   2244 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      0066CE E9               [12] 2245 	mov	a,r1
      0066CF 90 BE 61         [24] 2246 	mov	dptr,#_shared_offsets
      0066D2 93               [24] 2247 	movc	a,@a+dptr
      0066D3 90 07 FC         [24] 2248 	mov	dptr,#_control_setup_offset_10000_287
      0066D6 F0               [24] 2249 	movx	@dptr,a
      0066D7 02 68 33         [24] 2250 	ljmp	00252$
      0066DA                       2251 00245$:
                                   2252 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      0066DA E5 17            [12] 2253 	mov	a,_control_setup_sloc3_1_0
      0066DC 60 7A            [24] 2254 	jz	00240$
      0066DE BB 01 77         [24] 2255 	cjne	r3,#0x01,00240$
      0066E1 BC 00 74         [24] 2256 	cjne	r4,#0x00,00240$
      0066E4 E9               [12] 2257 	mov	a,r1
      0066E5 70 71            [24] 2258 	jnz	00240$
                                   2259 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      0066E7 90 07 8C         [24] 2260 	mov	dptr,#_D0SetupLen
      0066EA E0               [24] 2261 	movx	a,@dptr
      0066EB F8               [12] 2262 	mov	r0,a
      0066EC A3               [24] 2263 	inc	dptr
      0066ED E0               [24] 2264 	movx	a,@dptr
      0066EE F9               [12] 2265 	mov	r1,a
      0066EF C3               [12] 2266 	clr	c
      0066F0 E8               [12] 2267 	mov	a,r0
      0066F1 94 20            [12] 2268 	subb	a,#0x20
      0066F3 E9               [12] 2269 	mov	a,r1
      0066F4 94 00            [12] 2270 	subb	a,#0x00
      0066F6 50 0A            [24] 2271 	jnc	00320$
      0066F8 90 07 8C         [24] 2272 	mov	dptr,#_D0SetupLen
      0066FB E0               [24] 2273 	movx	a,@dptr
      0066FC F8               [12] 2274 	mov	r0,a
      0066FD A3               [24] 2275 	inc	dptr
      0066FE E0               [24] 2276 	movx	a,@dptr
      0066FF F9               [12] 2277 	mov	r1,a
      006700 80 04            [24] 2278 	sjmp	00321$
      006702                       2279 00320$:
      006702 78 20            [12] 2280 	mov	r0,#0x20
      006704 79 00            [12] 2281 	mov	r1,#0x00
      006706                       2282 00321$:
                                   2283 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      006706 75 17 00         [24] 2284 	mov	_control_setup_sloc3_1_0,#0x00
      006709                       2285 00293$:
      006709 C0 03            [24] 2286 	push	ar3
      00670B C0 04            [24] 2287 	push	ar4
      00670D AB 17            [24] 2288 	mov	r3,_control_setup_sloc3_1_0
      00670F 7C 00            [12] 2289 	mov	r4,#0x00
      006711 C3               [12] 2290 	clr	c
      006712 EB               [12] 2291 	mov	a,r3
      006713 98               [12] 2292 	subb	a,r0
      006714 EC               [12] 2293 	mov	a,r4
      006715 99               [12] 2294 	subb	a,r1
      006716 D0 04            [24] 2295 	pop	ar4
      006718 D0 03            [24] 2296 	pop	ar3
      00671A 50 32            [24] 2297 	jnc	00222$
      00671C C0 00            [24] 2298 	push	ar0
      00671E C0 01            [24] 2299 	push	ar1
      006720 85 17 19         [24] 2300 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      006723 74 10            [12] 2301 	mov	a,#0x10
      006725 24 00            [12] 2302 	add	a, #0x00
      006727 F5 1A            [12] 2303 	mov	(_control_setup_sloc4_1_0 + 1),a
      006729 A8 17            [24] 2304 	mov	r0,_control_setup_sloc3_1_0
      00672B 79 00            [12] 2305 	mov	r1,#0x00
      00672D 74 C0            [12] 2306 	mov	a,#0xc0
      00672F 28               [12] 2307 	add	a, r0
      006730 F8               [12] 2308 	mov	r0,a
      006731 E4               [12] 2309 	clr	a
      006732 39               [12] 2310 	addc	a, r1
      006733 F9               [12] 2311 	mov	r1,a
      006734 88 82            [24] 2312 	mov	dpl,r0
      006736 74 10            [12] 2313 	mov	a,#0x10
      006738 29               [12] 2314 	add	a, r1
      006739 F5 83            [12] 2315 	mov	dph,a
      00673B E0               [24] 2316 	movx	a,@dptr
      00673C 85 19 82         [24] 2317 	mov	dpl,_control_setup_sloc4_1_0
      00673F 85 1A 83         [24] 2318 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      006742 F0               [24] 2319 	movx	@dptr,a
      006743 E5 17            [12] 2320 	mov	a,_control_setup_sloc3_1_0
      006745 04               [12] 2321 	inc	a
      006746 F5 17            [12] 2322 	mov	_control_setup_sloc3_1_0,a
      006748 D0 01            [24] 2323 	pop	ar1
      00674A D0 00            [24] 2324 	pop	ar0
      00674C 80 BB            [24] 2325 	sjmp	00293$
      00674E                       2326 00222$:
                                   2327 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      00674E 90 07 FA         [24] 2328 	mov	dptr,#_control_setup_length_10000_287
      006751 E4               [12] 2329 	clr	a
      006752 F0               [24] 2330 	movx	@dptr,a
      006753 A3               [24] 2331 	inc	dptr
      006754 F0               [24] 2332 	movx	@dptr,a
      006755 02 68 33         [24] 2333 	ljmp	00252$
      006758                       2334 00240$:
                                   2335 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      006758 8D 00            [24] 2336 	mov	ar0,r5
      00675A 8E 01            [24] 2337 	mov	ar1,r6
      00675C B8 00 21         [24] 2338 	cjne	r0,#0x00,00236$
      00675F B9 02 1E         [24] 2339 	cjne	r1,#0x02,00236$
      006762 EB               [12] 2340 	mov	a,r3
      006763 4C               [12] 2341 	orl	a,r4
      006764 70 1A            [24] 2342 	jnz	00236$
                                   2343 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      006766 90 07 96         [24] 2344 	mov	dptr,#_KB_USB_SetReport
      006769 E0               [24] 2345 	movx	a,@dptr
      00676A 90 10 00         [24] 2346 	mov	dptr,#0x1000
      00676D F0               [24] 2347 	movx	@dptr,a
                                   2348 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      00676E 90 07 FA         [24] 2349 	mov	dptr,#_control_setup_length_10000_287
      006771 E4               [12] 2350 	clr	a
      006772 F0               [24] 2351 	movx	@dptr,a
      006773 A3               [24] 2352 	inc	dptr
      006774 F0               [24] 2353 	movx	@dptr,a
                                   2354 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      006775 90 07 8C         [24] 2355 	mov	dptr,#_D0SetupLen
      006778 04               [12] 2356 	inc	a
      006779 F0               [24] 2357 	movx	@dptr,a
      00677A E4               [12] 2358 	clr	a
      00677B A3               [24] 2359 	inc	dptr
      00677C F0               [24] 2360 	movx	@dptr,a
      00677D 02 68 33         [24] 2361 	ljmp	00252$
      006780                       2362 00236$:
                                   2363 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006780 B8 06 41         [24] 2364 	cjne	r0,#0x06,00232$
      006783 B9 02 3E         [24] 2365 	cjne	r1,#0x02,00232$
      006786 BB 02 3B         [24] 2366 	cjne	r3,#0x02,00232$
      006789 BC 00 38         [24] 2367 	cjne	r4,#0x00,00232$
                                   2368 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      00678C C0 03            [24] 2369 	push	ar3
      00678E C0 04            [24] 2370 	push	ar4
      006790 90 10 00         [24] 2371 	mov	dptr,#0x1000
      006793 74 06            [12] 2372 	mov	a,#0x06
      006795 F0               [24] 2373 	movx	@dptr,a
                                   2374 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      006796 90 07 96         [24] 2375 	mov	dptr,#_KB_USB_SetReport
      006799 E0               [24] 2376 	movx	a,@dptr
      00679A 90 10 01         [24] 2377 	mov	dptr,#0x1001
      00679D F0               [24] 2378 	movx	@dptr,a
                                   2379 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      00679E 90 07 FA         [24] 2380 	mov	dptr,#_control_setup_length_10000_287
      0067A1 E4               [12] 2381 	clr	a
      0067A2 F0               [24] 2382 	movx	@dptr,a
      0067A3 A3               [24] 2383 	inc	dptr
      0067A4 F0               [24] 2384 	movx	@dptr,a
                                   2385 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      0067A5 90 07 8C         [24] 2386 	mov	dptr,#_D0SetupLen
      0067A8 E0               [24] 2387 	movx	a,@dptr
      0067A9 FB               [12] 2388 	mov	r3,a
      0067AA A3               [24] 2389 	inc	dptr
      0067AB E0               [24] 2390 	movx	a,@dptr
      0067AC FC               [12] 2391 	mov	r4,a
      0067AD C3               [12] 2392 	clr	c
      0067AE 74 02            [12] 2393 	mov	a,#0x02
      0067B0 9B               [12] 2394 	subb	a,r3
      0067B1 E4               [12] 2395 	clr	a
      0067B2 9C               [12] 2396 	subb	a,r4
      0067B3 D0 04            [24] 2397 	pop	ar4
      0067B5 D0 03            [24] 2398 	pop	ar3
      0067B7 50 7A            [24] 2399 	jnc	00252$
                                   2400 ;	free result
      0067B9 90 07 8C         [24] 2401 	mov	dptr,#_D0SetupLen
      0067BC 74 02            [12] 2402 	mov	a,#0x02
      0067BE F0               [24] 2403 	movx	@dptr,a
      0067BF E4               [12] 2404 	clr	a
      0067C0 A3               [24] 2405 	inc	dptr
      0067C1 F0               [24] 2406 	movx	@dptr,a
      0067C2 80 6F            [24] 2407 	sjmp	00252$
      0067C4                       2408 00232$:
                                   2409 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      0067C4 B8 00 69         [24] 2410 	cjne	r0,#0x00,00228$
      0067C7 B9 03 66         [24] 2411 	cjne	r1,#0x03,00228$
      0067CA BB 01 63         [24] 2412 	cjne	r3,#0x01,00228$
      0067CD BC 00 60         [24] 2413 	cjne	r4,#0x00,00228$
                                   2414 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      0067D0 90 10 00         [24] 2415 	mov	dptr,#0x1000
      0067D3 74 41            [12] 2416 	mov	a,#0x41
      0067D5 F0               [24] 2417 	movx	@dptr,a
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      0067D6 A3               [24] 2419 	inc	dptr
      0067D7 74 4B            [12] 2420 	mov	a,#0x4b
      0067D9 F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      0067DA A3               [24] 2423 	inc	dptr
      0067DB 74 42            [12] 2424 	mov	a,#0x42
      0067DD F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      0067DE A3               [24] 2427 	inc	dptr
      0067DF 74 54            [12] 2428 	mov	a,#0x54
      0067E1 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      0067E2 A3               [24] 2431 	inc	dptr
      0067E3 74 01            [12] 2432 	mov	a,#0x01
      0067E5 F0               [24] 2433 	movx	@dptr,a
                                   2434 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      0067E6 90 07 97         [24] 2435 	mov	dptr,#_ak820_boot_stage
      0067E9 E0               [24] 2436 	movx	a,@dptr
      0067EA 90 10 05         [24] 2437 	mov	dptr,#0x1005
      0067ED F0               [24] 2438 	movx	@dptr,a
                                   2439 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      0067EE 90 07 98         [24] 2440 	mov	dptr,#_ak820_main_heartbeat
      0067F1 E0               [24] 2441 	movx	a,@dptr
      0067F2 90 10 06         [24] 2442 	mov	dptr,#0x1006
      0067F5 F0               [24] 2443 	movx	@dptr,a
                                   2444 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      0067F6 90 07 92         [24] 2445 	mov	dptr,#_USB_EnumStatus
      0067F9 E0               [24] 2446 	movx	a,@dptr
      0067FA 60 02            [24] 2447 	jz	00322$
      0067FC 74 01            [12] 2448 	mov	a,#0x01
      0067FE                       2449 00322$:
      0067FE F9               [12] 2450 	mov	r1,a
      0067FF 90 07 93         [24] 2451 	mov	dptr,#_USB_SleepStatus
      006802 E0               [24] 2452 	movx	a,@dptr
      006803 54 02            [12] 2453 	anl	a,#0x02
      006805 F8               [12] 2454 	mov	r0,a
      006806 E9               [12] 2455 	mov	a,r1
      006807 42 00            [12] 2456 	orl	ar0,a
      006809 90 10 07         [24] 2457 	mov	dptr,#0x1007
      00680C E8               [12] 2458 	mov	a,r0
      00680D F0               [24] 2459 	movx	@dptr,a
                                   2460 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      00680E 90 07 FA         [24] 2461 	mov	dptr,#_control_setup_length_10000_287
      006811 E4               [12] 2462 	clr	a
      006812 F0               [24] 2463 	movx	@dptr,a
      006813 A3               [24] 2464 	inc	dptr
      006814 F0               [24] 2465 	movx	@dptr,a
                                   2466 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      006815 90 07 8C         [24] 2467 	mov	dptr,#_D0SetupLen
      006818 E0               [24] 2468 	movx	a,@dptr
      006819 F8               [12] 2469 	mov	r0,a
      00681A A3               [24] 2470 	inc	dptr
      00681B E0               [24] 2471 	movx	a,@dptr
      00681C F9               [12] 2472 	mov	r1,a
      00681D C3               [12] 2473 	clr	c
      00681E 74 08            [12] 2474 	mov	a,#0x08
      006820 98               [12] 2475 	subb	a,r0
      006821 E4               [12] 2476 	clr	a
      006822 99               [12] 2477 	subb	a,r1
      006823 50 0E            [24] 2478 	jnc	00252$
                                   2479 ;	free result
      006825 90 07 8C         [24] 2480 	mov	dptr,#_D0SetupLen
      006828 74 08            [12] 2481 	mov	a,#0x08
      00682A F0               [24] 2482 	movx	@dptr,a
      00682B E4               [12] 2483 	clr	a
      00682C A3               [24] 2484 	inc	dptr
      00682D F0               [24] 2485 	movx	@dptr,a
      00682E 80 03            [24] 2486 	sjmp	00252$
      006830                       2487 00228$:
                                   2488 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      006830 02 5F 99         [24] 2489 	ljmp	_control_stall
      006833                       2490 00252$:
                                   2491 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      006833 90 07 FA         [24] 2492 	mov	dptr,#_control_setup_length_10000_287
      006836 E0               [24] 2493 	movx	a,@dptr
      006837 F5 19            [12] 2494 	mov	_control_setup_sloc4_1_0,a
      006839 A3               [24] 2495 	inc	dptr
      00683A E0               [24] 2496 	movx	a,@dptr
      00683B F5 1A            [12] 2497 	mov	(_control_setup_sloc4_1_0 + 1),a
      00683D E5 19            [12] 2498 	mov	a,_control_setup_sloc4_1_0
      00683F 45 1A            [12] 2499 	orl	a,(_control_setup_sloc4_1_0 + 1)
      006841 60 50            [24] 2500 	jz	00262$
                                   2501 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      006843 90 07 8C         [24] 2502 	mov	dptr,#_D0SetupLen
      006846 E0               [24] 2503 	movx	a,@dptr
      006847 F8               [12] 2504 	mov	r0,a
      006848 A3               [24] 2505 	inc	dptr
      006849 E0               [24] 2506 	movx	a,@dptr
      00684A F9               [12] 2507 	mov	r1,a
      00684B C3               [12] 2508 	clr	c
      00684C E5 19            [12] 2509 	mov	a,_control_setup_sloc4_1_0
      00684E 98               [12] 2510 	subb	a,r0
      00684F E5 1A            [12] 2511 	mov	a,(_control_setup_sloc4_1_0 + 1)
      006851 99               [12] 2512 	subb	a,r1
      006852 50 0A            [24] 2513 	jnc	00559$
                                   2514 ;	free result
      006854 90 07 8C         [24] 2515 	mov	dptr,#_D0SetupLen
      006857 E5 19            [12] 2516 	mov	a,_control_setup_sloc4_1_0
      006859 F0               [24] 2517 	movx	@dptr,a
      00685A E5 1A            [12] 2518 	mov	a,(_control_setup_sloc4_1_0 + 1)
      00685C A3               [24] 2519 	inc	dptr
      00685D F0               [24] 2520 	movx	@dptr,a
                                   2521 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      00685E                       2522 00559$:
      00685E 75 19 00         [24] 2523 	mov	_control_setup_sloc4_1_0,#0x00
      006861                       2524 00296$:
      006861 90 07 8C         [24] 2525 	mov	dptr,#_D0SetupLen
      006864 E0               [24] 2526 	movx	a,@dptr
      006865 F8               [12] 2527 	mov	r0,a
      006866 C3               [12] 2528 	clr	c
      006867 E5 19            [12] 2529 	mov	a,_control_setup_sloc4_1_0
      006869 98               [12] 2530 	subb	a,r0
      00686A 50 46            [24] 2531 	jnc	00263$
      00686C 85 19 17         [24] 2532 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      00686F 74 10            [12] 2533 	mov	a,#0x10
      006871 24 00            [12] 2534 	add	a, #0x00
      006873 F5 18            [12] 2535 	mov	(_control_setup_sloc3_1_0 + 1),a
      006875 90 07 FC         [24] 2536 	mov	dptr,#_control_setup_offset_10000_287
      006878 E0               [24] 2537 	movx	a,@dptr
      006879 25 19            [12] 2538 	add	a, _control_setup_sloc4_1_0
      00687B 24 BC            [12] 2539 	add	a, #_input_snapshot
      00687D F5 82            [12] 2540 	mov	dpl,a
      00687F E4               [12] 2541 	clr	a
      006880 34 07            [12] 2542 	addc	a,#(_input_snapshot >> 8)
      006882 F5 83            [12] 2543 	mov	dph,a
      006884 E0               [24] 2544 	movx	a,@dptr
      006885 85 17 82         [24] 2545 	mov	dpl,_control_setup_sloc3_1_0
      006888 85 18 83         [24] 2546 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      00688B F0               [24] 2547 	movx	@dptr,a
      00688C E5 19            [12] 2548 	mov	a,_control_setup_sloc4_1_0
      00688E 04               [12] 2549 	inc	a
      00688F F5 19            [12] 2550 	mov	_control_setup_sloc4_1_0,a
      006891 80 CE            [24] 2551 	sjmp	00296$
      006893                       2552 00262$:
                                   2553 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      006893 BB 01 1C         [24] 2554 	cjne	r3,#0x01,00263$
      006896 BC 00 19         [24] 2555 	cjne	r4,#0x00,00263$
      006899 90 07 8C         [24] 2556 	mov	dptr,#_D0SetupLen
      00689C E0               [24] 2557 	movx	a,@dptr
      00689D F8               [12] 2558 	mov	r0,a
      00689E A3               [24] 2559 	inc	dptr
      00689F E0               [24] 2560 	movx	a,@dptr
      0068A0 F9               [12] 2561 	mov	r1,a
      0068A1 C3               [12] 2562 	clr	c
      0068A2 74 20            [12] 2563 	mov	a,#0x20
      0068A4 98               [12] 2564 	subb	a,r0
      0068A5 E4               [12] 2565 	clr	a
      0068A6 99               [12] 2566 	subb	a,r1
      0068A7 50 09            [24] 2567 	jnc	00263$
                                   2568 ;	free result
      0068A9 90 07 8C         [24] 2569 	mov	dptr,#_D0SetupLen
      0068AC 74 20            [12] 2570 	mov	a,#0x20
      0068AE F0               [24] 2571 	movx	@dptr,a
      0068AF E4               [12] 2572 	clr	a
      0068B0 A3               [24] 2573 	inc	dptr
      0068B1 F0               [24] 2574 	movx	@dptr,a
      0068B2                       2575 00263$:
                                   2576 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      0068B2 90 07 8C         [24] 2577 	mov	dptr,#_D0SetupLen
      0068B5 E0               [24] 2578 	movx	a,@dptr
      0068B6 90 22 08         [24] 2579 	mov	dptr,#0x2208
      0068B9 F0               [24] 2580 	movx	@dptr,a
                                   2581 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      0068BA 90 07 F0         [24] 2582 	mov	dptr,#_control_phase
      0068BD 74 02            [12] 2583 	mov	a,#0x02
      0068BF F0               [24] 2584 	movx	@dptr,a
      0068C0 02 69 48         [24] 2585 	ljmp	00291$
      0068C3                       2586 00273$:
                                   2587 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      0068C3 EB               [12] 2588 	mov	a,r3
      0068C4 4C               [12] 2589 	orl	a,r4
      0068C5 70 37            [24] 2590 	jnz	00265$
      0068C7 90 07 91         [24] 2591 	mov	dptr,#_D0UsbConfig
      0068CA E0               [24] 2592 	movx	a,@dptr
      0068CB 60 31            [24] 2593 	jz	00265$
      0068CD EA               [12] 2594 	mov	a,r2
      0068CE 60 2E            [24] 2595 	jz	00265$
      0068D0 90 07 8B         [24] 2596 	mov	dptr,#_D0SetupReqCode
      0068D3 E0               [24] 2597 	movx	a,@dptr
      0068D4 FA               [12] 2598 	mov	r2,a
      0068D5 BA 03 26         [24] 2599 	cjne	r2,#0x03,00265$
      0068D8 30 19 23         [24] 2600 	jnb	_control_setup_zero_value_10000_287,00265$
      0068DB 90 07 8C         [24] 2601 	mov	dptr,#_D0SetupLen
      0068DE E0               [24] 2602 	movx	a,@dptr
      0068DF F9               [12] 2603 	mov	r1,a
      0068E0 A3               [24] 2604 	inc	dptr
      0068E1 E0               [24] 2605 	movx	a,@dptr
      0068E2 FA               [12] 2606 	mov	r2,a
      0068E3 B9 01 18         [24] 2607 	cjne	r1,#0x01,00265$
      0068E6 BA 00 15         [24] 2608 	cjne	r2,#0x00,00265$
                                   2609 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      0068E9 90 0D E1         [24] 2610 	mov	dptr,#_keyboard_protocol
      0068EC E0               [24] 2611 	movx	a,@dptr
      0068ED 90 10 00         [24] 2612 	mov	dptr,#0x1000
      0068F0 F0               [24] 2613 	movx	@dptr,a
                                   2614 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      0068F1 90 22 08         [24] 2615 	mov	dptr,#0x2208
      0068F4 74 01            [12] 2616 	mov	a,#0x01
      0068F6 F0               [24] 2617 	movx	@dptr,a
                                   2618 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      0068F7 90 07 F0         [24] 2619 	mov	dptr,#_control_phase
      0068FA 04               [12] 2620 	inc	a
      0068FB F0               [24] 2621 	movx	@dptr,a
      0068FC 80 4A            [24] 2622 	sjmp	00291$
      0068FE                       2623 00265$:
                                   2624 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2625 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      0068FE 02 5F 99         [24] 2626 	ljmp	_control_stall
      006901                       2627 00282$:
                                   2628 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006901 30 17 3E         [24] 2629 	jnb	_control_setup_valid_interface_10000_287,00284$
      006904 90 07 91         [24] 2630 	mov	dptr,#_D0UsbConfig
      006907 E0               [24] 2631 	movx	a,@dptr
      006908 60 38            [24] 2632 	jz	00284$
      00690A BF A1 35         [24] 2633 	cjne	r7,#0xa1,00284$
      00690D 8E 05            [24] 2634 	mov	ar5,r6
      00690F 7E 00            [12] 2635 	mov	r6,#0x00
      006911 ED               [12] 2636 	mov	a,r5
      006912 4E               [12] 2637 	orl	a,r6
      006913 70 2D            [24] 2638 	jnz	00284$
      006915 90 07 8C         [24] 2639 	mov	dptr,#_D0SetupLen
      006918 E0               [24] 2640 	movx	a,@dptr
      006919 FE               [12] 2641 	mov	r6,a
      00691A A3               [24] 2642 	inc	dptr
      00691B E0               [24] 2643 	movx	a,@dptr
      00691C FF               [12] 2644 	mov	r7,a
      00691D BE 01 22         [24] 2645 	cjne	r6,#0x01,00284$
      006920 BF 00 1F         [24] 2646 	cjne	r7,#0x00,00284$
                                   2647 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      006923 EB               [12] 2648 	mov	a,r3
      006924 4C               [12] 2649 	orl	a,r4
      006925 70 07            [24] 2650 	jnz	00324$
      006927 90 06 53         [24] 2651 	mov	dptr,#_keyboard_idle
      00692A E0               [24] 2652 	movx	a,@dptr
      00692B FF               [12] 2653 	mov	r7,a
      00692C 80 02            [24] 2654 	sjmp	00325$
      00692E                       2655 00324$:
      00692E 7F 00            [12] 2656 	mov	r7,#0x00
      006930                       2657 00325$:
      006930 90 10 00         [24] 2658 	mov	dptr,#0x1000
      006933 EF               [12] 2659 	mov	a,r7
      006934 F0               [24] 2660 	movx	@dptr,a
                                   2661 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      006935 90 22 08         [24] 2662 	mov	dptr,#0x2208
      006938 74 01            [12] 2663 	mov	a,#0x01
      00693A F0               [24] 2664 	movx	@dptr,a
                                   2665 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      00693B 90 07 F0         [24] 2666 	mov	dptr,#_control_phase
      00693E 04               [12] 2667 	inc	a
      00693F F0               [24] 2668 	movx	@dptr,a
      006940 80 06            [24] 2669 	sjmp	00291$
      006942                       2670 00284$:
                                   2671 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2672 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      006942 02 5F 99         [24] 2673 	ljmp	_control_stall
      006945                       2674 00290$:
                                   2675 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      006945 02 5F 99         [24] 2676 	ljmp	_control_stall
      006948                       2677 00291$:
                                   2678 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      006948 90 22 00         [24] 2679 	mov	dptr,#0x2200
      00694B 74 C0            [12] 2680 	mov	a,#0xc0
      00694D F0               [24] 2681 	movx	@dptr,a
                                   2682 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      00694E 22               [24] 2683 	ret
                                   2684 ;------------------------------------------------------------
                                   2685 ;Allocation info for local variables in function 'control_out'
                                   2686 ;------------------------------------------------------------
                                   2687 ;i             Allocated with name '_control_out_i_10000_371'
                                   2688 ;------------------------------------------------------------
                                   2689 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2690 ;	-----------------------------------------
                                   2691 ;	 function control_out
                                   2692 ;	-----------------------------------------
      00694F                       2693 _control_out:
                                   2694 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      00694F 90 22 0F         [24] 2695 	mov	dptr,#0x220f
      006952 E0               [24] 2696 	movx	a,@dptr
      006953 20 E6 01         [24] 2697 	jb	acc.6,00102$
      006956 22               [24] 2698 	ret
      006957                       2699 00102$:
                                   2700 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      006957 90 07 F0         [24] 2701 	mov	dptr,#_control_phase
      00695A E0               [24] 2702 	movx	a,@dptr
      00695B FF               [12] 2703 	mov	r7,a
      00695C BF 02 12         [24] 2704 	cjne	r7,#0x02,00104$
      00695F 90 22 0E         [24] 2705 	mov	dptr,#0x220e
      006962 E0               [24] 2706 	movx	a,@dptr
      006963 70 0C            [24] 2707 	jnz	00104$
                                   2708 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      006965 90 07 F0         [24] 2709 	mov	dptr,#_control_phase
      006968 E4               [12] 2710 	clr	a
      006969 F0               [24] 2711 	movx	@dptr,a
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00696A 90 22 00         [24] 2713 	mov	dptr,#0x2200
      00696D 74 02            [12] 2714 	mov	a,#0x02
      00696F F0               [24] 2715 	movx	@dptr,a
                                   2716 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      006970 22               [24] 2717 	ret
      006971                       2718 00104$:
                                   2719 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      006971 BF 04 19         [24] 2720 	cjne	r7,#0x04,00106$
      006974 90 22 0E         [24] 2721 	mov	dptr,#0x220e
      006977 E0               [24] 2722 	movx	a,@dptr
      006978 FF               [12] 2723 	mov	r7,a
      006979 90 07 8C         [24] 2724 	mov	dptr,#_D0SetupLen
      00697C E0               [24] 2725 	movx	a,@dptr
      00697D FD               [12] 2726 	mov	r5,a
      00697E A3               [24] 2727 	inc	dptr
      00697F E0               [24] 2728 	movx	a,@dptr
      006980 FE               [12] 2729 	mov	r6,a
      006981 7C 00            [12] 2730 	mov	r4,#0x00
      006983 EF               [12] 2731 	mov	a,r7
      006984 B5 05 06         [24] 2732 	cjne	a,ar5,00209$
      006987 EC               [12] 2733 	mov	a,r4
      006988 B5 06 02         [24] 2734 	cjne	a,ar6,00209$
      00698B 80 03            [24] 2735 	sjmp	00107$
      00698D                       2736 00209$:
      00698D                       2737 00106$:
      00698D 02 5F 99         [24] 2738 	ljmp	_control_stall
      006990                       2739 00107$:
                                   2740 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006990 90 07 F1         [24] 2741 	mov	dptr,#_output_kind
      006993 E0               [24] 2742 	movx	a,@dptr
      006994 FF               [12] 2743 	mov	r7,a
      006995 BF 01 2E         [24] 2744 	cjne	r7,#0x01,00118$
      006998 90 07 99         [24] 2745 	mov	dptr,#_raw_state
      00699B E0               [24] 2746 	movx	a,@dptr
      00699C FE               [12] 2747 	mov	r6,a
      00699D BE 01 26         [24] 2748 	cjne	r6,#0x01,00118$
                                   2749 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      0069A0 7E 00            [12] 2750 	mov	r6,#0x00
      0069A2                       2751 00121$:
      0069A2 EE               [12] 2752 	mov	a,r6
      0069A3 24 9A            [12] 2753 	add	a, #_raw_buffer
      0069A5 FC               [12] 2754 	mov	r4,a
      0069A6 E4               [12] 2755 	clr	a
      0069A7 34 07            [12] 2756 	addc	a, #(_raw_buffer >> 8)
      0069A9 FD               [12] 2757 	mov	r5,a
      0069AA 8E 82            [24] 2758 	mov	dpl,r6
      0069AC 74 10            [12] 2759 	mov	a,#0x10
      0069AE 24 00            [12] 2760 	add	a, #0x00
      0069B0 F5 83            [12] 2761 	mov	dph,a
      0069B2 E0               [24] 2762 	movx	a,@dptr
      0069B3 8C 82            [24] 2763 	mov	dpl,r4
      0069B5 8D 83            [24] 2764 	mov	dph,r5
      0069B7 F0               [24] 2765 	movx	@dptr,a
      0069B8 0E               [12] 2766 	inc	r6
      0069B9 BE 20 00         [24] 2767 	cjne	r6,#0x20,00214$
      0069BC                       2768 00214$:
      0069BC 40 E4            [24] 2769 	jc	00121$
                                   2770 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      0069BE 90 07 99         [24] 2771 	mov	dptr,#_raw_state
      0069C1 74 02            [12] 2772 	mov	a,#0x02
      0069C3 F0               [24] 2773 	movx	@dptr,a
      0069C4 80 2B            [24] 2774 	sjmp	00119$
      0069C6                       2775 00118$:
                                   2776 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      0069C6 BF 02 0A         [24] 2777 	cjne	r7,#0x02,00115$
                                   2778 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      0069C9 90 10 00         [24] 2779 	mov	dptr,#0x1000
      0069CC E0               [24] 2780 	movx	a,@dptr
      0069CD 90 07 96         [24] 2781 	mov	dptr,#_KB_USB_SetReport
      0069D0 F0               [24] 2782 	movx	@dptr,a
      0069D1 80 1E            [24] 2783 	sjmp	00119$
      0069D3                       2784 00115$:
                                   2785 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      0069D3 BF 03 18         [24] 2786 	cjne	r7,#0x03,00111$
      0069D6 90 10 00         [24] 2787 	mov	dptr,#0x1000
      0069D9 E0               [24] 2788 	movx	a,@dptr
      0069DA FF               [12] 2789 	mov	r7,a
      0069DB 90 07 F2         [24] 2790 	mov	dptr,#_output_report_id
      0069DE E0               [24] 2791 	movx	a,@dptr
      0069DF FE               [12] 2792 	mov	r6,a
      0069E0 EF               [12] 2793 	mov	a,r7
      0069E1 B5 06 0A         [24] 2794 	cjne	a,ar6,00111$
                                   2795 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      0069E4 90 10 01         [24] 2796 	mov	dptr,#0x1001
      0069E7 E0               [24] 2797 	movx	a,@dptr
      0069E8 90 07 96         [24] 2798 	mov	dptr,#_KB_USB_SetReport
      0069EB F0               [24] 2799 	movx	@dptr,a
      0069EC 80 03            [24] 2800 	sjmp	00119$
      0069EE                       2801 00111$:
                                   2802 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      0069EE 02 5F 99         [24] 2803 	ljmp	_control_stall
      0069F1                       2804 00119$:
                                   2805 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      0069F1 90 07 F1         [24] 2806 	mov	dptr,#_output_kind
      0069F4 E4               [12] 2807 	clr	a
      0069F5 F0               [24] 2808 	movx	@dptr,a
                                   2809 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      0069F6 90 07 8C         [24] 2810 	mov	dptr,#_D0SetupLen
      0069F9 F0               [24] 2811 	movx	@dptr,a
      0069FA A3               [24] 2812 	inc	dptr
      0069FB F0               [24] 2813 	movx	@dptr,a
                                   2814 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      0069FC 90 07 F0         [24] 2815 	mov	dptr,#_control_phase
      0069FF 74 03            [12] 2816 	mov	a,#0x03
      006A01 F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      006A02 90 22 08         [24] 2819 	mov	dptr,#0x2208
      006A05 E4               [12] 2820 	clr	a
      006A06 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      006A07 F5 82            [12] 2823 	mov	dpl,a
      006A09 74 48            [12] 2824 	mov	a,#0x48
      006A0B F0               [24] 2825 	movx	@dptr,a
                                   2826 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      006A0C 22               [24] 2827 	ret
                                   2828 ;------------------------------------------------------------
                                   2829 ;Allocation info for local variables in function 'control_in'
                                   2830 ;------------------------------------------------------------
                                   2831 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2832 ;	-----------------------------------------
                                   2833 ;	 function control_in
                                   2834 ;	-----------------------------------------
      006A0D                       2835 _control_in:
                                   2836 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      006A0D 90 07 F0         [24] 2837 	mov	dptr,#_control_phase
      006A10 E0               [24] 2838 	movx	a,@dptr
      006A11 FF               [12] 2839 	mov	r7,a
      006A12 BF 01 22         [24] 2840 	cjne	r7,#0x01,00109$
                                   2841 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      006A15 90 07 8C         [24] 2842 	mov	dptr,#_D0SetupLen
      006A18 E0               [24] 2843 	movx	a,@dptr
      006A19 FD               [12] 2844 	mov	r5,a
      006A1A A3               [24] 2845 	inc	dptr
      006A1B E0               [24] 2846 	movx	a,@dptr
      006A1C 4D               [12] 2847 	orl	a,r5
      006A1D 70 06            [24] 2848 	jnz	00101$
      006A1F 90 07 F3         [24] 2849 	mov	dptr,#_control_zlp
      006A22 E0               [24] 2850 	movx	a,@dptr
      006A23 60 0A            [24] 2851 	jz	00102$
      006A25                       2852 00101$:
                                   2853 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      006A25 90 22 00         [24] 2854 	mov	dptr,#0x2200
      006A28 E0               [24] 2855 	movx	a,@dptr
      006A29 64 40            [12] 2856 	xrl	a,#0x40
      006A2B F0               [24] 2857 	movx	@dptr,a
                                   2858 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2859 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      006A2C 02 5F BB         [24] 2860 	ljmp	_control_next
      006A2F                       2861 00102$:
                                   2862 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      006A2F 90 07 F0         [24] 2863 	mov	dptr,#_control_phase
      006A32 74 02            [12] 2864 	mov	a,#0x02
      006A34 F0               [24] 2865 	movx	@dptr,a
      006A35 80 18            [24] 2866 	sjmp	00110$
      006A37                       2867 00109$:
                                   2868 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      006A37 BF 03 15         [24] 2869 	cjne	r7,#0x03,00110$
                                   2870 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      006A3A 90 07 8B         [24] 2871 	mov	dptr,#_D0SetupReqCode
      006A3D E0               [24] 2872 	movx	a,@dptr
      006A3E FF               [12] 2873 	mov	r7,a
      006A3F BF 05 08         [24] 2874 	cjne	r7,#0x05,00105$
      006A42 90 07 8C         [24] 2875 	mov	dptr,#_D0SetupLen
      006A45 E0               [24] 2876 	movx	a,@dptr
      006A46 90 22 07         [24] 2877 	mov	dptr,#0x2207
      006A49 F0               [24] 2878 	movx	@dptr,a
      006A4A                       2879 00105$:
                                   2880 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      006A4A 90 07 F0         [24] 2881 	mov	dptr,#_control_phase
      006A4D E4               [12] 2882 	clr	a
      006A4E F0               [24] 2883 	movx	@dptr,a
      006A4F                       2884 00110$:
                                   2885 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A4F 90 22 00         [24] 2886 	mov	dptr,#0x2200
      006A52 74 82            [12] 2887 	mov	a,#0x82
      006A54 F0               [24] 2888 	movx	@dptr,a
                                   2889 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      006A55 22               [24] 2890 	ret
                                   2891 ;------------------------------------------------------------
                                   2892 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2893 ;------------------------------------------------------------
                                   2894 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_395'
                                   2895 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_395'
                                   2896 ;------------------------------------------------------------
                                   2897 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2898 ;	-----------------------------------------
                                   2899 ;	 function USB_DeviceInterrupt
                                   2900 ;	-----------------------------------------
      006A56                       2901 _USB_DeviceInterrupt:
                                   2902 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      006A56                       2903 00129$:
                                   2904 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      006A56 90 22 3D         [24] 2905 	mov	dptr,#0x223d
      006A59 E0               [24] 2906 	movx	a,@dptr
      006A5A 30 E0 4B         [24] 2907 	jnb	acc.0,00127$
                                   2908 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      006A5D 12 5F 3C         [24] 2909 	lcall	_endpoints_reset
                                   2910 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      006A60 90 22 07         [24] 2911 	mov	dptr,#0x2207
      006A63 E4               [12] 2912 	clr	a
      006A64 F0               [24] 2913 	movx	@dptr,a
                                   2914 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006A65 90 07 93         [24] 2915 	mov	dptr,#_USB_SleepStatus
      006A68 F0               [24] 2916 	movx	@dptr,a
      006A69 90 07 92         [24] 2917 	mov	dptr,#_USB_EnumStatus
      006A6C F0               [24] 2918 	movx	@dptr,a
      006A6D 90 07 91         [24] 2919 	mov	dptr,#_D0UsbConfig
      006A70 F0               [24] 2920 	movx	@dptr,a
                                   2921 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      006A71 90 07 96         [24] 2922 	mov	dptr,#_KB_USB_SetReport
      006A74 F0               [24] 2923 	movx	@dptr,a
                                   2924 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      006A75 90 0D E1         [24] 2925 	mov	dptr,#_keyboard_protocol
      006A78 04               [12] 2926 	inc	a
      006A79 F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006A7A 90 06 53         [24] 2929 	mov	dptr,#_keyboard_idle
      006A7D E4               [12] 2930 	clr	a
      006A7E F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006A7F 90 07 BB         [24] 2933 	mov	dptr,#_keyboard_reset
      006A82 04               [12] 2934 	inc	a
      006A83 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      006A84 90 07 8B         [24] 2937 	mov	dptr,#_D0SetupReqCode
      006A87 74 FF            [12] 2938 	mov	a,#0xff
      006A89 F0               [24] 2939 	movx	@dptr,a
                                   2940 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006A8A 90 07 8C         [24] 2941 	mov	dptr,#_D0SetupLen
      006A8D E4               [12] 2942 	clr	a
      006A8E F0               [24] 2943 	movx	@dptr,a
      006A8F A3               [24] 2944 	inc	dptr
      006A90 F0               [24] 2945 	movx	@dptr,a
                                   2946 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006A91 90 07 F0         [24] 2947 	mov	dptr,#_control_phase
      006A94 F0               [24] 2948 	movx	@dptr,a
                                   2949 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006A95 90 22 00         [24] 2950 	mov	dptr,#0x2200
      006A98 74 02            [12] 2951 	mov	a,#0x02
      006A9A F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006A9B 90 22 0F         [24] 2954 	mov	dptr,#0x220f
      006A9E E4               [12] 2955 	clr	a
      006A9F F0               [24] 2956 	movx	@dptr,a
                                   2957 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006AA0 90 22 3D         [24] 2958 	mov	dptr,#0x223d
      006AA3 04               [12] 2959 	inc	a
      006AA4 F0               [24] 2960 	movx	@dptr,a
      006AA5 02 6B 3B         [24] 2961 	ljmp	00130$
      006AA8                       2962 00127$:
                                   2963 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006AA8 90 22 3D         [24] 2964 	mov	dptr,#0x223d
      006AAB E0               [24] 2965 	movx	a,@dptr
      006AAC 30 E5 60         [24] 2966 	jnb	acc.5,00124$
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006AAF 90 22 0F         [24] 2968 	mov	dptr,#0x220f
      006AB2 E0               [24] 2969 	movx	a,@dptr
      006AB3 FF               [12] 2970 	mov	r7,a
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      006AB4 74 07            [12] 2972 	mov	a,#0x07
      006AB6 5F               [12] 2973 	anl	a,r7
      006AB7 FE               [12] 2974 	mov	r6,a
                                   2975 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006AB8 EF               [12] 2976 	mov	a,r7
      006AB9 54 18            [12] 2977 	anl	a,#0x18
      006ABB 70 08            [24] 2978 	jnz	00115$
      006ABD EE               [12] 2979 	mov	a,r6
      006ABE 70 05            [24] 2980 	jnz	00115$
                                   2981 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006AC0 12 69 4F         [24] 2982 	lcall	_control_out
      006AC3 80 43            [24] 2983 	sjmp	00116$
      006AC5                       2984 00115$:
                                   2985 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      006AC5 8F 05            [24] 2986 	mov	ar5,r7
      006AC7 74 18            [12] 2987 	mov	a,#0x18
      006AC9 5D               [12] 2988 	anl	a,r5
      006ACA FC               [12] 2989 	mov	r4,a
      006ACB BC 10 2D         [24] 2990 	cjne	r4,#0x10,00112$
                                   2991 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006ACE EE               [12] 2992 	mov	a,r6
      006ACF 70 05            [24] 2993 	jnz	00106$
      006AD1 12 6A 0D         [24] 2994 	lcall	_control_in
      006AD4 80 32            [24] 2995 	sjmp	00116$
      006AD6                       2996 00106$:
                                   2997 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      006AD6 EE               [12] 2998 	mov	a,r6
      006AD7 24 FC            [12] 2999 	add	a,#0xff - 0x03
      006AD9 40 2D            [24] 3000 	jc	00116$
                                   3001 ;	free result
                                   3002 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006ADB 8E 04            [24] 3003 	mov	ar4,r6
      006ADD 7B 00            [12] 3004 	mov	r3,#0x00
      006ADF 74 22            [12] 3005 	mov	a,#0x22
      006AE1 2B               [12] 3006 	add	a, r3
      006AE2 FB               [12] 3007 	mov	r3,a
      006AE3 8C 82            [24] 3008 	mov	dpl,r4
      006AE5 8B 83            [24] 3009 	mov	dph,r3
      006AE7 E0               [24] 3010 	movx	a,@dptr
      006AE8 FA               [12] 3011 	mov	r2,a
      006AE9 74 FC            [12] 3012 	mov	a,#0xfc
      006AEB 5A               [12] 3013 	anl	a,r2
      006AEC 44 02            [12] 3014 	orl	a,#0x02
      006AEE 8C 82            [24] 3015 	mov	dpl,r4
      006AF0 8B 83            [24] 3016 	mov	dph,r3
      006AF2 F0               [24] 3017 	movx	@dptr,a
                                   3018 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      006AF3 BE 03 12         [24] 3019 	cjne	r6,#0x03,00116$
      006AF6 12 5F 1F         [24] 3020 	lcall	_raw_complete
      006AF9 80 0D            [24] 3021 	sjmp	00116$
      006AFB                       3022 00112$:
                                   3023 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006AFB 53 05 18         [24] 3024 	anl	ar5,#0x18
      006AFE BD 18 07         [24] 3025 	cjne	r5,#0x18,00116$
      006B01 EF               [12] 3026 	mov	a,r7
      006B02 30 E5 03         [24] 3027 	jnb	acc.5,00116$
                                   3028 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      006B05 12 61 B2         [24] 3029 	lcall	_control_setup
      006B08                       3030 00116$:
                                   3031 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006B08 90 22 0F         [24] 3032 	mov	dptr,#0x220f
      006B0B E4               [12] 3033 	clr	a
      006B0C F0               [24] 3034 	movx	@dptr,a
      006B0D 80 2C            [24] 3035 	sjmp	00130$
      006B0F                       3036 00124$:
                                   3037 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006B0F 90 22 3D         [24] 3038 	mov	dptr,#0x223d
      006B12 E0               [24] 3039 	movx	a,@dptr
      006B13 30 E2 25         [24] 3040 	jnb	acc.2,00130$
                                   3041 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      006B16 90 22 3D         [24] 3042 	mov	dptr,#0x223d
      006B19 E0               [24] 3043 	movx	a,@dptr
      006B1A 30 E3 0A         [24] 3044 	jnb	acc.3,00119$
      006B1D 90 07 93         [24] 3045 	mov	dptr,#_USB_SleepStatus
      006B20 E0               [24] 3046 	movx	a,@dptr
      006B21 43 E0 02         [24] 3047 	orl	acc,#0x02
      006B24 F0               [24] 3048 	movx	@dptr,a
      006B25 80 0E            [24] 3049 	sjmp	00120$
      006B27                       3050 00119$:
                                   3051 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      006B27 90 07 93         [24] 3052 	mov	dptr,#_USB_SleepStatus
      006B2A E0               [24] 3053 	movx	a,@dptr
      006B2B 53 E0 FD         [24] 3054 	anl	acc,#0xfd
      006B2E F0               [24] 3055 	movx	@dptr,a
                                   3056 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      006B2F 90 07 BB         [24] 3057 	mov	dptr,#_keyboard_reset
      006B32 74 01            [12] 3058 	mov	a,#0x01
      006B34 F0               [24] 3059 	movx	@dptr,a
      006B35                       3060 00120$:
                                   3061 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      006B35 90 22 3D         [24] 3062 	mov	dptr,#0x223d
      006B38 74 04            [12] 3063 	mov	a,#0x04
      006B3A F0               [24] 3064 	movx	@dptr,a
      006B3B                       3065 00130$:
                                   3066 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      006B3B 90 22 3D         [24] 3067 	mov	dptr,#0x223d
      006B3E E0               [24] 3068 	movx	a,@dptr
      006B3F 54 25            [12] 3069 	anl	a,#0x25
      006B41 60 03            [24] 3070 	jz	00242$
      006B43 02 6A 56         [24] 3071 	ljmp	00129$
      006B46                       3072 00242$:
                                   3073 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      006B46 22               [24] 3074 	ret
                                   3075 ;------------------------------------------------------------
                                   3076 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3077 ;------------------------------------------------------------
                                   3078 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3079 ;	-----------------------------------------
                                   3080 ;	 function USB_Device_Init
                                   3081 ;	-----------------------------------------
      006B47                       3082 _USB_Device_Init:
                                   3083 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3084 ;	assignBit
      006B47 C2 E9            [12] 3085 	clr	_IE_USB
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      006B49 90 22 3C         [24] 3087 	mov	dptr,#0x223c
      006B4C E4               [12] 3088 	clr	a
      006B4D F0               [24] 3089 	movx	@dptr,a
                                   3090 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      006B4E 90 07 99         [24] 3091 	mov	dptr,#_raw_state
      006B51 F0               [24] 3092 	movx	@dptr,a
                                   3093 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      006B52 12 5F 3C         [24] 3094 	lcall	_endpoints_reset
                                   3095 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      006B55 90 07 93         [24] 3096 	mov	dptr,#_USB_SleepStatus
      006B58 E4               [12] 3097 	clr	a
      006B59 F0               [24] 3098 	movx	@dptr,a
      006B5A 90 07 92         [24] 3099 	mov	dptr,#_USB_EnumStatus
      006B5D F0               [24] 3100 	movx	@dptr,a
      006B5E 90 07 91         [24] 3101 	mov	dptr,#_D0UsbConfig
      006B61 F0               [24] 3102 	movx	@dptr,a
      006B62 90 22 07         [24] 3103 	mov	dptr,#0x2207
      006B65 F0               [24] 3104 	movx	@dptr,a
                                   3105 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      006B66 90 07 94         [24] 3106 	mov	dptr,#_MCU_Sleep_Operate
      006B69 F0               [24] 3107 	movx	@dptr,a
      006B6A 90 07 95         [24] 3108 	mov	dptr,#_KB_USB_UpStatus
      006B6D F0               [24] 3109 	movx	@dptr,a
      006B6E 90 07 96         [24] 3110 	mov	dptr,#_KB_USB_SetReport
      006B71 F0               [24] 3111 	movx	@dptr,a
                                   3112 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      006B72 90 0D E1         [24] 3113 	mov	dptr,#_keyboard_protocol
      006B75 04               [12] 3114 	inc	a
      006B76 F0               [24] 3115 	movx	@dptr,a
                                   3116 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006B77 90 06 53         [24] 3117 	mov	dptr,#_keyboard_idle
      006B7A E4               [12] 3118 	clr	a
      006B7B F0               [24] 3119 	movx	@dptr,a
                                   3120 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006B7C 90 07 BB         [24] 3121 	mov	dptr,#_keyboard_reset
      006B7F F0               [24] 3122 	movx	@dptr,a
                                   3123 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      006B80 90 07 F0         [24] 3124 	mov	dptr,#_control_phase
      006B83 F0               [24] 3125 	movx	@dptr,a
                                   3126 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006B84 90 07 8B         [24] 3127 	mov	dptr,#_D0SetupReqCode
      006B87 14               [12] 3128 	dec	a
      006B88 F0               [24] 3129 	movx	@dptr,a
                                   3130 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006B89 90 07 8C         [24] 3131 	mov	dptr,#_D0SetupLen
      006B8C E4               [12] 3132 	clr	a
      006B8D F0               [24] 3133 	movx	@dptr,a
      006B8E A3               [24] 3134 	inc	dptr
      006B8F F0               [24] 3135 	movx	@dptr,a
                                   3136 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      006B90 90 22 00         [24] 3137 	mov	dptr,#0x2200
      006B93 74 02            [12] 3138 	mov	a,#0x02
      006B95 F0               [24] 3139 	movx	@dptr,a
                                   3140 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006B96 90 22 37         [24] 3141 	mov	dptr,#0x2237
      006B99 74 7F            [12] 3142 	mov	a,#0x7f
      006B9B F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006B9C 90 22 3D         [24] 3145 	mov	dptr,#0x223d
      006B9F 74 FF            [12] 3146 	mov	a,#0xff
      006BA1 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      006BA2 90 22 3B         [24] 3149 	mov	dptr,#0x223b
      006BA5 74 07            [12] 3150 	mov	a,#0x07
      006BA7 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006BA8 A3               [24] 3153 	inc	dptr
      006BA9 74 80            [12] 3154 	mov	a,#0x80
      006BAB F0               [24] 3155 	movx	@dptr,a
                                   3156 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3157 ;	assignBit
      006BAC D2 E9            [12] 3158 	setb	_IE_USB
                                   3159 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      006BAE 22               [24] 3160 	ret
                                   3161 ;------------------------------------------------------------
                                   3162 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3163 ;------------------------------------------------------------
                                   3164 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_418'
                                   3165 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_421'
                                   3166 ;------------------------------------------------------------
                                   3167 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3168 ;	-----------------------------------------
                                   3169 ;	 function USB_WakeUp_PC
                                   3170 ;	-----------------------------------------
      006BAF                       3171 _USB_WakeUp_PC:
                                   3172 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      006BAF 90 07 93         [24] 3173 	mov	dptr,#_USB_SleepStatus
      006BB2 E0               [24] 3174 	movx	a,@dptr
      006BB3 FF               [12] 3175 	mov	r7,a
      006BB4 BF 03 22         [24] 3176 	cjne	r7,#0x03,00110$
                                   3177 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006BB7 90 22 3C         [24] 3178 	mov	dptr,#0x223c
      006BBA E0               [24] 3179 	movx	a,@dptr
      006BBB FF               [12] 3180 	mov	r7,a
                                   3181 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006BBC E0               [24] 3182 	movx	a,@dptr
      006BBD FE               [12] 3183 	mov	r6,a
      006BBE 63 06 C0         [24] 3184 	xrl	ar6,#0xc0
      006BC1 90 22 3C         [24] 3185 	mov	dptr,#0x223c
      006BC4 EE               [12] 3186 	mov	a,r6
      006BC5 F0               [24] 3187 	movx	@dptr,a
                                   3188 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006BC6 7E 0A            [12] 3189 	mov	r6,#0x0a
      006BC8                       3190 00108$:
      006BC8 EE               [12] 3191 	mov	a,r6
      006BC9 60 09            [24] 3192 	jz	00105$
      006BCB 90 00 01         [24] 3193 	mov	dptr,#0x0001
      006BCE 12 5D 83         [24] 3194 	lcall	_mDelaymS
      006BD1 1E               [12] 3195 	dec	r6
      006BD2 80 F4            [24] 3196 	sjmp	00108$
      006BD4                       3197 00105$:
                                   3198 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006BD4 90 22 3C         [24] 3199 	mov	dptr,#0x223c
      006BD7 EF               [12] 3200 	mov	a,r7
      006BD8 F0               [24] 3201 	movx	@dptr,a
      006BD9                       3202 00110$:
                                   3203 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006BD9 22               [24] 3204 	ret
                                   3205 ;------------------------------------------------------------
                                   3206 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3207 ;------------------------------------------------------------
                                   3208 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3209 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3210 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3211 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3212 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_423'
                                   3213 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_424'
                                   3214 ;i             Allocated with name '_ak820_usb_send_i_10000_424'
                                   3215 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_424'
                                   3216 ;offset        Allocated with name '_ak820_usb_send_offset_10000_424'
                                   3217 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_424'
                                   3218 ;i             Allocated with name '_ak820_usb_send_i_30000_436'
                                   3219 ;------------------------------------------------------------
                                   3220 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3221 ;	-----------------------------------------
                                   3222 ;	 function ak820_usb_send
                                   3223 ;	-----------------------------------------
      006BDA                       3224 _ak820_usb_send:
      006BDA E5 82            [12] 3225 	mov	a,dpl
      006BDC 90 08 00         [24] 3226 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006BDF F0               [24] 3227 	movx	@dptr,a
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      006BE0 90 08 01         [24] 3229 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006BE3 74 34            [12] 3230 	mov	a,#0x34
      006BE5 F0               [24] 3231 	movx	@dptr,a
                                   3232 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006BE6 90 08 00         [24] 3233 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006BE9 E0               [24] 3234 	movx	a,@dptr
      006BEA FF               [12] 3235 	mov	r7,a
      006BEB BF 01 00         [24] 3236 	cjne	r7,#0x01,00306$
      006BEE                       3237 00306$:
      006BEE 40 14            [24] 3238 	jc	00101$
      006BF0 EF               [12] 3239 	mov	a,r7
      006BF1 24 FC            [12] 3240 	add	a,#0xff - 0x03
      006BF3 40 0F            [24] 3241 	jc	00101$
                                   3242 ;	free result
      006BF5 90 07 FF         [24] 3243 	mov	dptr,#_ak820_usb_send_PARM_3
      006BF8 E0               [24] 3244 	movx	a,@dptr
      006BF9 FE               [12] 3245 	mov  r6,a
      006BFA 24 BF            [12] 3246 	add	a,#0xff - 0x40
      006BFC 40 06            [24] 3247 	jc	00101$
                                   3248 ;	free result
      006BFE 90 07 92         [24] 3249 	mov	dptr,#_USB_EnumStatus
      006C01 E0               [24] 3250 	movx	a,@dptr
      006C02 70 04            [24] 3251 	jnz	00102$
      006C04                       3252 00101$:
      006C04 75 82 00         [24] 3253 	mov	dpl, #0x00
      006C07 22               [24] 3254 	ret
      006C08                       3255 00102$:
                                   3256 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006C08 BF 01 10         [24] 3257 	cjne	r7,#0x01,00118$
                                   3258 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006C0B BE 08 02         [24] 3259 	cjne	r6,#0x08,00313$
      006C0E 80 04            [24] 3260 	sjmp	00107$
      006C10                       3261 00313$:
      006C10 75 82 00         [24] 3262 	mov	dpl, #0x00
      006C13 22               [24] 3263 	ret
      006C14                       3264 00107$:
                                   3265 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      006C14 90 08 01         [24] 3266 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006C17 E4               [12] 3267 	clr	a
      006C18 F0               [24] 3268 	movx	@dptr,a
      006C19 80 3C            [24] 3269 	sjmp	00119$
      006C1B                       3270 00118$:
                                   3271 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      006C1B BF 02 30         [24] 3272 	cjne	r7,#0x02,00115$
                                   3273 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      006C1E 90 07 FD         [24] 3274 	mov	dptr,#_ak820_usb_send_PARM_2
      006C21 E0               [24] 3275 	movx	a,@dptr
      006C22 FD               [12] 3276 	mov	r5,a
      006C23 A3               [24] 3277 	inc	dptr
      006C24 E0               [24] 3278 	movx	a,@dptr
      006C25 FF               [12] 3279 	mov	r7,a
      006C26 8D 82            [24] 3280 	mov	dpl,r5
      006C28 8F 83            [24] 3281 	mov	dph,r7
      006C2A E0               [24] 3282 	movx	a,@dptr
      006C2B FF               [12] 3283 	mov	r7,a
                                   3284 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      006C2C BF 07 00         [24] 3285 	cjne	r7,#0x07,00316$
      006C2F                       3286 00316$:
      006C2F 50 0E            [24] 3287 	jnc	00108$
      006C31 EF               [12] 3288 	mov	a,r7
      006C32 90 BE 68         [24] 3289 	mov	dptr,#_shared_lengths
      006C35 93               [24] 3290 	movc	a,@a+dptr
      006C36 FD               [12] 3291 	mov	r5,a
      006C37 60 06            [24] 3292 	jz	00108$
      006C39 EE               [12] 3293 	mov	a,r6
      006C3A B5 05 02         [24] 3294 	cjne	a,ar5,00319$
      006C3D 80 04            [24] 3295 	sjmp	00109$
      006C3F                       3296 00319$:
      006C3F                       3297 00108$:
      006C3F 75 82 00         [24] 3298 	mov	dpl, #0x00
      006C42 22               [24] 3299 	ret
      006C43                       3300 00109$:
                                   3301 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      006C43 EF               [12] 3302 	mov	a,r7
      006C44 90 BE 61         [24] 3303 	mov	dptr,#_shared_offsets
      006C47 93               [24] 3304 	movc	a,@a+dptr
      006C48 90 08 01         [24] 3305 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006C4B F0               [24] 3306 	movx	@dptr,a
      006C4C 80 09            [24] 3307 	sjmp	00119$
      006C4E                       3308 00115$:
                                   3309 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      006C4E BE 20 02         [24] 3310 	cjne	r6,#0x20,00320$
      006C51 80 04            [24] 3311 	sjmp	00119$
      006C53                       3312 00320$:
      006C53 75 82 00         [24] 3313 	mov	dpl, #0x00
      006C56 22               [24] 3314 	ret
      006C57                       3315 00119$:
                                   3316 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      006C57 90 07 93         [24] 3317 	mov	dptr,#_USB_SleepStatus
      006C5A E0               [24] 3318 	movx	a,@dptr
      006C5B 30 E1 07         [24] 3319 	jnb	acc.1,00184$
      006C5E 12 6B AF         [24] 3320 	lcall	_USB_WakeUp_PC
      006C61 75 82 00         [24] 3321 	mov	dpl, #0x00
      006C64 22               [24] 3322 	ret
                                   3323 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      006C65                       3324 00184$:
      006C65 7F FA            [12] 3325 	mov	r7,#0xfa
      006C67                       3326 00127$:
      006C67 90 08 00         [24] 3327 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006C6A E0               [24] 3328 	movx	a,@dptr
      006C6B FC               [12] 3329 	mov	r4,a
      006C6C 7D 00            [12] 3330 	mov	r5,#0x00
      006C6E 8C 02            [24] 3331 	mov	ar2,r4
      006C70 74 22            [12] 3332 	mov	a,#0x22
      006C72 2D               [12] 3333 	add	a, r5
      006C73 FB               [12] 3334 	mov	r3,a
      006C74 8A 82            [24] 3335 	mov	dpl,r2
      006C76 8B 83            [24] 3336 	mov	dph,r3
      006C78 E0               [24] 3337 	movx	a,@dptr
      006C79 54 03            [12] 3338 	anl	a,#0x03
      006C7B 70 14            [24] 3339 	jnz	00129$
      006C7D 8F 03            [24] 3340 	mov	ar3,r7
      006C7F 1F               [12] 3341 	dec	r7
      006C80 EB               [12] 3342 	mov	a,r3
      006C81 60 0E            [24] 3343 	jz	00129$
      006C83 7B 28            [12] 3344 	mov	r3,#0x28
      006C85                       3345 00141$:
      006C85 EB               [12] 3346 	mov	a,r3
      006C86 60 DF            [24] 3347 	jz	00127$
      006C88 90 00 01         [24] 3348 	mov	dptr,#0x0001
      006C8B 12 5D 3F         [24] 3349 	lcall	_mDelayuS
      006C8E 1B               [12] 3350 	dec	r3
      006C8F 80 F4            [24] 3351 	sjmp	00141$
      006C91                       3352 00129$:
                                   3353 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      006C91 A2 AF            [12] 3354 	mov	c,_EA
      006C93 E4               [12] 3355 	clr	a
      006C94 33               [12] 3356 	rlc	a
      006C95 FF               [12] 3357 	mov	r7,a
                                   3358 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3359 ;	assignBit
      006C96 C2 AF            [12] 3360 	clr	_EA
                                   3361 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006C98 90 07 92         [24] 3362 	mov	dptr,#_USB_EnumStatus
      006C9B E0               [24] 3363 	movx	a,@dptr
      006C9C 60 25            [24] 3364 	jz	00130$
      006C9E 90 08 00         [24] 3365 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006CA1 E0               [24] 3366 	movx	a,@dptr
      006CA2 FB               [12] 3367 	mov	r3,a
      006CA3 F9               [12] 3368 	mov	r1,a
      006CA4 7A 00            [12] 3369 	mov	r2,#0x00
      006CA6 74 22            [12] 3370 	mov	a,#0x22
      006CA8 2A               [12] 3371 	add	a, r2
      006CA9 FA               [12] 3372 	mov	r2,a
      006CAA 89 82            [24] 3373 	mov	dpl,r1
      006CAC 8A 83            [24] 3374 	mov	dph,r2
      006CAE E0               [24] 3375 	movx	a,@dptr
      006CAF FA               [12] 3376 	mov	r2,a
      006CB0 53 02 03         [24] 3377 	anl	ar2,#0x03
      006CB3 BA 02 0D         [24] 3378 	cjne	r2,#0x02,00130$
                                   3379 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006CB6 BB 03 13         [24] 3380 	cjne	r3,#0x03,00192$
      006CB9 90 07 99         [24] 3381 	mov	dptr,#_raw_state
      006CBC E0               [24] 3382 	movx	a,@dptr
      006CBD FB               [12] 3383 	mov	r3,a
      006CBE BB 03 02         [24] 3384 	cjne	r3,#0x03,00331$
      006CC1 80 09            [24] 3385 	sjmp	00192$
      006CC3                       3386 00331$:
      006CC3                       3387 00130$:
                                   3388 ;	assignBit
      006CC3 EF               [12] 3389 	mov	a,r7
      006CC4 24 FF            [12] 3390 	add	a,#0xff
      006CC6 92 AF            [24] 3391 	mov	_EA,c
      006CC8 75 82 00         [24] 3392 	mov	dpl, #0x00
      006CCB 22               [24] 3393 	ret
                                   3394 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006CCC                       3395 00192$:
      006CCC 7B 00            [12] 3396 	mov	r3,#0x00
      006CCE                       3397 00144$:
      006CCE C3               [12] 3398 	clr	c
      006CCF EB               [12] 3399 	mov	a,r3
      006CD0 9E               [12] 3400 	subb	a,r6
      006CD1 50 67            [24] 3401 	jnc	00137$
                                   3402 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006CD3 C0 07            [24] 3403 	push	ar7
      006CD5 90 08 00         [24] 3404 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006CD8 E0               [24] 3405 	movx	a,@dptr
      006CD9 F9               [12] 3406 	mov	r1,a
      006CDA E4               [12] 3407 	clr	a
      006CDB C3               [12] 3408 	clr	c
      006CDC C9               [12] 3409 	xch	a,r1
      006CDD 13               [12] 3410 	rrc	a
      006CDE C9               [12] 3411 	xch	a,r1
      006CDF 13               [12] 3412 	rrc	a
      006CE0 A2 E0            [12] 3413 	mov	c,acc.0
      006CE2 C9               [12] 3414 	xch	a,r1
      006CE3 13               [12] 3415 	rrc	a
      006CE4 C9               [12] 3416 	xch	a,r1
      006CE5 13               [12] 3417 	rrc	a
      006CE6 C9               [12] 3418 	xch	a,r1
      006CE7 FA               [12] 3419 	mov	r2,a
      006CE8 8B 00            [24] 3420 	mov	ar0,r3
      006CEA 7F 00            [12] 3421 	mov	r7,#0x00
      006CEC E8               [12] 3422 	mov	a,r0
      006CED 29               [12] 3423 	add	a, r1
      006CEE F9               [12] 3424 	mov	r1,a
      006CEF EF               [12] 3425 	mov	a,r7
      006CF0 3A               [12] 3426 	addc	a, r2
      006CF1 24 10            [12] 3427 	add	a,#0x10
      006CF3 FA               [12] 3428 	mov	r2,a
      006CF4 90 07 FD         [24] 3429 	mov	dptr,#_ak820_usb_send_PARM_2
      006CF7 E0               [24] 3430 	movx	a,@dptr
      006CF8 F8               [12] 3431 	mov	r0,a
      006CF9 A3               [24] 3432 	inc	dptr
      006CFA E0               [24] 3433 	movx	a,@dptr
      006CFB FF               [12] 3434 	mov	r7,a
      006CFC EB               [12] 3435 	mov	a,r3
      006CFD 28               [12] 3436 	add	a, r0
      006CFE F5 1B            [12] 3437 	mov	_ak820_usb_send_sloc0_1_0,a
      006D00 E4               [12] 3438 	clr	a
      006D01 3F               [12] 3439 	addc	a, r7
      006D02 F5 1C            [12] 3440 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006D04 85 1B 82         [24] 3441 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006D07 85 1C 83         [24] 3442 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006D0A E0               [24] 3443 	movx	a,@dptr
      006D0B 89 82            [24] 3444 	mov	dpl,r1
      006D0D 8A 83            [24] 3445 	mov	dph,r2
      006D0F F0               [24] 3446 	movx	@dptr,a
                                   3447 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      006D10 90 08 01         [24] 3448 	mov	dptr,#_ak820_usb_send_offset_10000_424
      006D13 E0               [24] 3449 	movx	a,@dptr
      006D14 F5 1D            [12] 3450 	mov	_ak820_usb_send_sloc1_1_0,a
      006D16 74 34            [12] 3451 	mov	a,#0x34
      006D18 B5 1D 04         [24] 3452 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      006D1B D0 07            [24] 3453 	pop	ar7
      006D1D 80 18            [24] 3454 	sjmp	00145$
      006D1F                       3455 00333$:
      006D1F D0 07            [24] 3456 	pop	ar7
      006D21 EB               [12] 3457 	mov	a,r3
      006D22 25 1D            [12] 3458 	add	a, _ak820_usb_send_sloc1_1_0
      006D24 24 BC            [12] 3459 	add	a, #_input_snapshot
      006D26 F9               [12] 3460 	mov	r1,a
      006D27 E4               [12] 3461 	clr	a
      006D28 34 07            [12] 3462 	addc	a,#(_input_snapshot >> 8)
      006D2A FA               [12] 3463 	mov	r2,a
      006D2B 85 1B 82         [24] 3464 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006D2E 85 1C 83         [24] 3465 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006D31 E0               [24] 3466 	movx	a,@dptr
      006D32 89 82            [24] 3467 	mov	dpl,r1
      006D34 8A 83            [24] 3468 	mov	dph,r2
      006D36 F0               [24] 3469 	movx	@dptr,a
      006D37                       3470 00145$:
                                   3471 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006D37 0B               [12] 3472 	inc	r3
      006D38 80 94            [24] 3473 	sjmp	00144$
      006D3A                       3474 00137$:
                                   3475 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      006D3A 90 08 00         [24] 3476 	mov	dptr,#_ak820_usb_send_endpoint_10000_423
      006D3D E0               [24] 3477 	movx	a,@dptr
      006D3E FB               [12] 3478 	mov	r3,a
      006D3F F9               [12] 3479 	mov	r1,a
      006D40 7A 00            [12] 3480 	mov	r2,#0x00
      006D42 74 08            [12] 3481 	mov	a,#0x08
      006D44 29               [12] 3482 	add	a, r1
      006D45 F9               [12] 3483 	mov	r1,a
      006D46 74 22            [12] 3484 	mov	a,#0x22
      006D48 3A               [12] 3485 	addc	a, r2
      006D49 FA               [12] 3486 	mov	r2,a
      006D4A 89 82            [24] 3487 	mov	dpl,r1
      006D4C 8A 83            [24] 3488 	mov	dph,r2
      006D4E EE               [12] 3489 	mov	a,r6
      006D4F F0               [24] 3490 	movx	@dptr,a
                                   3491 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      006D50 BB 03 06         [24] 3492 	cjne	r3,#0x03,00139$
      006D53 90 07 99         [24] 3493 	mov	dptr,#_raw_state
      006D56 74 04            [12] 3494 	mov	a,#0x04
      006D58 F0               [24] 3495 	movx	@dptr,a
      006D59                       3496 00139$:
                                   3497 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      006D59 74 22            [12] 3498 	mov	a,#0x22
      006D5B 2D               [12] 3499 	add	a, r5
      006D5C FD               [12] 3500 	mov	r5,a
      006D5D 8C 82            [24] 3501 	mov	dpl,r4
      006D5F 8D 83            [24] 3502 	mov	dph,r5
      006D61 E0               [24] 3503 	movx	a,@dptr
      006D62 FE               [12] 3504 	mov	r6,a
      006D63 53 06 FC         [24] 3505 	anl	ar6,#0xfc
      006D66 8C 82            [24] 3506 	mov	dpl,r4
      006D68 8D 83            [24] 3507 	mov	dph,r5
      006D6A EE               [12] 3508 	mov	a,r6
      006D6B F0               [24] 3509 	movx	@dptr,a
                                   3510 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3511 ;	assignBit
      006D6C EF               [12] 3512 	mov	a,r7
      006D6D 24 FF            [12] 3513 	add	a,#0xff
      006D6F 92 AF            [24] 3514 	mov	_EA,c
                                   3515 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      006D71 75 82 01         [24] 3516 	mov	dpl, #0x01
                                   3517 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006D74 22               [24] 3518 	ret
                                   3519 ;------------------------------------------------------------
                                   3520 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3521 ;------------------------------------------------------------
                                   3522 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3523 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3524 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_444'
                                   3525 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_445'
                                   3526 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_445'
                                   3527 ;------------------------------------------------------------
                                   3528 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3529 ;	-----------------------------------------
                                   3530 ;	 function ak820_usb_try_send
                                   3531 ;	-----------------------------------------
      006D75                       3532 _ak820_usb_try_send:
      006D75 E5 82            [12] 3533 	mov	a,dpl
      006D77 90 08 05         [24] 3534 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006D7A F0               [24] 3535 	movx	@dptr,a
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3537 ;	assignBit
      006D7B A2 AF            [12] 3538 	mov	c,_EA
      006D7D 92 1D            [24] 3539 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3540 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006D7F 90 08 06         [24] 3541 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006D82 E4               [12] 3542 	clr	a
      006D83 F0               [24] 3543 	movx	@dptr,a
                                   3544 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3545 ;	assignBit
      006D84 C2 AF            [12] 3546 	clr	_EA
                                   3547 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006D86 90 08 05         [24] 3548 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_444
      006D89 E0               [24] 3549 	movx	a,@dptr
      006D8A FF               [12] 3550 	mov	r7,a
      006D8B BF 01 00         [24] 3551 	cjne	r7,#0x01,00152$
      006D8E                       3552 00152$:
      006D8E 40 4E            [24] 3553 	jc	00102$
      006D90 EF               [12] 3554 	mov	a,r7
      006D91 24 FD            [12] 3555 	add	a,#0xff - 0x02
      006D93 40 49            [24] 3556 	jc	00102$
                                   3557 ;	free result
      006D95 90 07 92         [24] 3558 	mov	dptr,#_USB_EnumStatus
      006D98 E0               [24] 3559 	movx	a,@dptr
      006D99 60 43            [24] 3560 	jz	00102$
                                   3561 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006D9B 90 07 93         [24] 3562 	mov	dptr,#_USB_SleepStatus
      006D9E E0               [24] 3563 	movx	a,@dptr
      006D9F 20 E1 3C         [24] 3564 	jb	acc.1,00102$
      006DA2 90 07 BB         [24] 3565 	mov	dptr,#_keyboard_reset
      006DA5 E0               [24] 3566 	movx	a,@dptr
                                   3567 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006DA6 70 36            [24] 3568 	jnz	00102$
      006DA8 8F 06            [24] 3569 	mov	ar6,r7
      006DAA 24 22            [12] 3570 	add	a,#0x22
      006DAC FD               [12] 3571 	mov	r5,a
      006DAD 8E 82            [24] 3572 	mov	dpl,r6
      006DAF 8D 83            [24] 3573 	mov	dph,r5
      006DB1 E0               [24] 3574 	movx	a,@dptr
      006DB2 FE               [12] 3575 	mov	r6,a
      006DB3 53 06 03         [24] 3576 	anl	ar6,#0x03
      006DB6 BE 02 25         [24] 3577 	cjne	r6,#0x02,00102$
                                   3578 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006DB9 90 08 02         [24] 3579 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006DBC E0               [24] 3580 	movx	a,@dptr
      006DBD FD               [12] 3581 	mov	r5,a
      006DBE A3               [24] 3582 	inc	dptr
      006DBF E0               [24] 3583 	movx	a,@dptr
      006DC0 FE               [12] 3584 	mov	r6,a
      006DC1 90 08 04         [24] 3585 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006DC4 E0               [24] 3586 	movx	a,@dptr
      006DC5 FC               [12] 3587 	mov	r4,a
      006DC6 90 07 FD         [24] 3588 	mov	dptr,#_ak820_usb_send_PARM_2
      006DC9 ED               [12] 3589 	mov	a,r5
      006DCA F0               [24] 3590 	movx	@dptr,a
      006DCB EE               [12] 3591 	mov	a,r6
      006DCC A3               [24] 3592 	inc	dptr
      006DCD F0               [24] 3593 	movx	@dptr,a
      006DCE 90 07 FF         [24] 3594 	mov	dptr,#_ak820_usb_send_PARM_3
      006DD1 EC               [12] 3595 	mov	a,r4
      006DD2 F0               [24] 3596 	movx	@dptr,a
      006DD3 8F 82            [24] 3597 	mov	dpl, r7
      006DD5 12 6B DA         [24] 3598 	lcall	_ak820_usb_send
      006DD8 E5 82            [12] 3599 	mov	a, dpl
      006DDA 90 08 06         [24] 3600 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006DDD F0               [24] 3601 	movx	@dptr,a
      006DDE                       3602 00102$:
                                   3603 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3604 ;	assignBit
      006DDE A2 1D            [12] 3605 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006DE0 92 AF            [24] 3606 	mov	_EA,c
                                   3607 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006DE2 90 08 06         [24] 3608 	mov	dptr,#_ak820_usb_try_send_sent_10000_445
      006DE5 E0               [24] 3609 	movx	a,@dptr
                                   3610 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006DE6 F5 82            [12] 3611 	mov	dpl,a
      006DE8 22               [24] 3612 	ret
                                   3613 ;------------------------------------------------------------
                                   3614 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3615 ;------------------------------------------------------------
                                   3616 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3617 ;	-----------------------------------------
                                   3618 ;	 function raw_request_is_nonpersistent
                                   3619 ;	-----------------------------------------
      006DE9                       3620 _raw_request_is_nonpersistent:
                                   3621 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006DE9 90 07 9A         [24] 3622 	mov	dptr,#_raw_buffer
      006DEC E0               [24] 3623 	movx	a,@dptr
      006DED FF               [12] 3624 	mov	r7,a
      006DEE BF 01 02         [24] 3625 	cjne	r7,#0x01,00302$
      006DF1 80 35            [24] 3626 	sjmp	00108$
      006DF3                       3627 00302$:
      006DF3 BF 02 02         [24] 3628 	cjne	r7,#0x02,00303$
      006DF6 80 34            [24] 3629 	sjmp	00109$
      006DF8                       3630 00303$:
      006DF8 BF 04 02         [24] 3631 	cjne	r7,#0x04,00304$
      006DFB 80 2B            [24] 3632 	sjmp	00108$
      006DFD                       3633 00304$:
      006DFD BF 08 02         [24] 3634 	cjne	r7,#0x08,00305$
      006E00 80 47            [24] 3635 	sjmp	00116$
      006E02                       3636 00305$:
      006E02 BF 0B 02         [24] 3637 	cjne	r7,#0x0b,00306$
      006E05 80 21            [24] 3638 	sjmp	00108$
      006E07                       3639 00306$:
      006E07 BF 0C 02         [24] 3640 	cjne	r7,#0x0c,00307$
      006E0A 80 1C            [24] 3641 	sjmp	00108$
      006E0C                       3642 00307$:
      006E0C BF 0D 02         [24] 3643 	cjne	r7,#0x0d,00308$
      006E0F 80 17            [24] 3644 	sjmp	00108$
      006E11                       3645 00308$:
      006E11 BF 0E 02         [24] 3646 	cjne	r7,#0x0e,00309$
      006E14 80 12            [24] 3647 	sjmp	00108$
      006E16                       3648 00309$:
      006E16 BF 11 02         [24] 3649 	cjne	r7,#0x11,00310$
      006E19 80 0D            [24] 3650 	sjmp	00108$
      006E1B                       3651 00310$:
      006E1B BF 12 02         [24] 3652 	cjne	r7,#0x12,00311$
      006E1E 80 08            [24] 3653 	sjmp	00108$
      006E20                       3654 00311$:
      006E20 BF FE 02         [24] 3655 	cjne	r7,#0xfe,00312$
      006E23 80 46            [24] 3656 	sjmp	00124$
      006E25                       3657 00312$:
      006E25 02 6E C0         [24] 3658 	ljmp	00144$
                                   3659 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006E28                       3660 00108$:
                                   3661 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006E28 75 82 01         [24] 3662 	mov	dpl, #0x01
      006E2B 22               [24] 3663 	ret
                                   3664 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006E2C                       3665 00109$:
                                   3666 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006E2C 12 70 F2         [24] 3667 	lcall	_ak820_outline_0166
      006E2F BF 01 02         [24] 3668 	cjne	r7,#0x01,00313$
      006E32 80 0D            [24] 3669 	sjmp	00113$
      006E34                       3670 00313$:
      006E34 BF 02 02         [24] 3671 	cjne	r7,#0x02,00314$
      006E37 80 08            [24] 3672 	sjmp	00113$
      006E39                       3673 00314$:
      006E39 BF 03 02         [24] 3674 	cjne	r7,#0x03,00315$
      006E3C 80 03            [24] 3675 	sjmp	00113$
      006E3E                       3676 00315$:
      006E3E BF 04 04         [24] 3677 	cjne	r7,#0x04,00114$
                                   3678 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006E41                       3679 00113$:
                                   3680 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006E41 75 82 01         [24] 3681 	mov	dpl, #0x01
      006E44 22               [24] 3682 	ret
                                   3683 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006E45                       3684 00114$:
      006E45 75 82 00         [24] 3685 	mov	dpl, #0x00
      006E48 22               [24] 3686 	ret
                                   3687 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006E49                       3688 00116$:
                                   3689 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006E49 12 70 F2         [24] 3690 	lcall	_ak820_outline_0166
      006E4C BF 40 02         [24] 3691 	cjne	r7,#0x40,00318$
      006E4F 80 12            [24] 3692 	sjmp	00121$
      006E51                       3693 00318$:
      006E51 BF 41 02         [24] 3694 	cjne	r7,#0x41,00319$
      006E54 80 0D            [24] 3695 	sjmp	00121$
      006E56                       3696 00319$:
      006E56 BF 42 02         [24] 3697 	cjne	r7,#0x42,00320$
      006E59 80 08            [24] 3698 	sjmp	00121$
      006E5B                       3699 00320$:
      006E5B BF 43 02         [24] 3700 	cjne	r7,#0x43,00321$
      006E5E 80 03            [24] 3701 	sjmp	00121$
      006E60                       3702 00321$:
      006E60 BF 44 04         [24] 3703 	cjne	r7,#0x44,00122$
                                   3704 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006E63                       3705 00121$:
                                   3706 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006E63 75 82 01         [24] 3707 	mov	dpl, #0x01
                                   3708 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006E66 22               [24] 3709 	ret
      006E67                       3710 00122$:
      006E67 75 82 00         [24] 3711 	mov	dpl, #0x00
                                   3712 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006E6A 22               [24] 3713 	ret
      006E6B                       3714 00124$:
                                   3715 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006E6B 12 70 F2         [24] 3716 	lcall	_ak820_outline_0166
      006E6E 24 F2            [12] 3717 	add	a,#0xff - 0x0d
      006E70 40 4A            [24] 3718 	jc	00142$
                                   3719 ;	free result
      006E72 EF               [12] 3720 	mov	a,r7
      006E73 24 0A            [12] 3721 	add	a,#(00325$-3-.)
      006E75 83               [24] 3722 	movc	a,@a+pc
      006E76 F5 82            [12] 3723 	mov	dpl,a
      006E78 EF               [12] 3724 	mov	a,r7
      006E79 24 12            [12] 3725 	add	a,#(00326$-3-.)
      006E7B 83               [24] 3726 	movc	a,@a+pc
      006E7C F5 83            [12] 3727 	mov	dph,a
      006E7E E4               [12] 3728 	clr	a
      006E7F 73               [24] 3729 	jmp	@a+dptr
      006E80                       3730 00325$:
      006E80 9C                    3731 	.db	00134$
      006E81 9C                    3732 	.db	00134$
      006E82 9C                    3733 	.db	00134$
      006E83 9C                    3734 	.db	00134$
      006E84 BC                    3735 	.db	00142$
      006E85 9C                    3736 	.db	00134$
      006E86 9C                    3737 	.db	00134$
      006E87 9C                    3738 	.db	00134$
      006E88 9C                    3739 	.db	00134$
      006E89 9C                    3740 	.db	00134$
      006E8A 9C                    3741 	.db	00134$
      006E8B BC                    3742 	.db	00142$
      006E8C BC                    3743 	.db	00142$
      006E8D A0                    3744 	.db	00135$
      006E8E                       3745 00326$:
      006E8E 6E                    3746 	.db	00134$>>8
      006E8F 6E                    3747 	.db	00134$>>8
      006E90 6E                    3748 	.db	00134$>>8
      006E91 6E                    3749 	.db	00134$>>8
      006E92 6E                    3750 	.db	00142$>>8
      006E93 6E                    3751 	.db	00134$>>8
      006E94 6E                    3752 	.db	00134$>>8
      006E95 6E                    3753 	.db	00134$>>8
      006E96 6E                    3754 	.db	00134$>>8
      006E97 6E                    3755 	.db	00134$>>8
      006E98 6E                    3756 	.db	00134$>>8
      006E99 6E                    3757 	.db	00142$>>8
      006E9A 6E                    3758 	.db	00142$>>8
      006E9B 6E                    3759 	.db	00135$>>8
                                   3760 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006E9C                       3761 00134$:
                                   3762 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006E9C 75 82 01         [24] 3763 	mov	dpl, #0x01
                                   3764 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006E9F 22               [24] 3765 	ret
      006EA0                       3766 00135$:
                                   3767 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006EA0 90 07 9C         [24] 3768 	mov	dptr,#(_raw_buffer + 0x0002)
      006EA3 E0               [24] 3769 	movx	a,@dptr
      006EA4 FF               [12] 3770 	mov	r7,a
      006EA5 60 0D            [24] 3771 	jz	00139$
      006EA7 BF 01 02         [24] 3772 	cjne	r7,#0x01,00328$
      006EAA 80 08            [24] 3773 	sjmp	00139$
      006EAC                       3774 00328$:
      006EAC BF 03 02         [24] 3775 	cjne	r7,#0x03,00329$
      006EAF 80 03            [24] 3776 	sjmp	00139$
      006EB1                       3777 00329$:
      006EB1 BF 05 04         [24] 3778 	cjne	r7,#0x05,00140$
                                   3779 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006EB4                       3780 00139$:
                                   3781 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006EB4 75 82 01         [24] 3782 	mov	dpl, #0x01
                                   3783 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006EB7 22               [24] 3784 	ret
      006EB8                       3785 00140$:
      006EB8 75 82 00         [24] 3786 	mov	dpl, #0x00
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006EBB 22               [24] 3788 	ret
      006EBC                       3789 00142$:
      006EBC 75 82 00         [24] 3790 	mov	dpl, #0x00
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006EBF 22               [24] 3792 	ret
      006EC0                       3793 00144$:
      006EC0 75 82 00         [24] 3794 	mov	dpl, #0x00
                                   3795 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3796 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006EC3 22               [24] 3797 	ret
                                   3798 ;------------------------------------------------------------
                                   3799 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3800 ;------------------------------------------------------------
                                   3801 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3802 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_460'
                                   3803 ;------------------------------------------------------------
                                   3804 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3805 ;	-----------------------------------------
                                   3806 ;	 function ak820_usb_raw_send
                                   3807 ;	-----------------------------------------
      006EC4                       3808 _ak820_usb_raw_send:
      006EC4 12 45 55         [24] 3809 	lcall	_ak820_outline_0037
      006EC7 90 08 08         [24] 3810 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006ECA 12 3A 69         [24] 3811 	lcall	_ak820_outline_0017
                                   3812 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006ECD 90 08 07         [24] 3813 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006ED0 E0               [24] 3814 	movx	a,@dptr
      006ED1 FF               [12] 3815 	mov	r7,a
      006ED2 BF 20 2B         [24] 3816 	cjne	r7,#0x20,00106$
                                   3817 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006ED5 C0 07            [24] 3818 	push	ar7
      006ED7 12 40 6B         [24] 3819 	lcall	_ak820_nvm_flush
      006EDA D0 07            [24] 3820 	pop	ar7
                                   3821 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006EDC 90 07 BA         [24] 3822 	mov	dptr,#_raw_reply_without_nvm
      006EDF E0               [24] 3823 	movx	a,@dptr
      006EE0 70 07            [24] 3824 	jnz	00103$
      006EE2 12 40 5C         [24] 3825 	lcall	_ak820_nvm_ok
      006EE5 E5 82            [12] 3826 	mov	a, dpl
      006EE7 60 17            [24] 3827 	jz	00106$
      006EE9                       3828 00103$:
      006EE9 90 08 08         [24] 3829 	mov	dptr,#_ak820_usb_raw_send_report_10000_460
      006EEC 12 3A AA         [24] 3830 	lcall	_ak820_outline_0084
      006EEF 90 07 FD         [24] 3831 	mov	dptr,#_ak820_usb_send_PARM_2
      006EF2 12 45 B8         [24] 3832 	lcall	_ak820_outline_0164
      006EF5 90 07 FF         [24] 3833 	mov	dptr,#_ak820_usb_send_PARM_3
      006EF8 EF               [12] 3834 	mov	a,r7
      006EF9 F0               [24] 3835 	movx	@dptr,a
      006EFA 75 82 03         [24] 3836 	mov	dpl, #0x03
                                   3837 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006EFD 02 6B DA         [24] 3838 	ljmp	_ak820_usb_send
      006F00                       3839 00106$:
      006F00 22               [24] 3840 	ret
                                   3841 ;------------------------------------------------------------
                                   3842 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3843 ;------------------------------------------------------------
                                   3844 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3845 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_465'
                                   3846 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_465'
                                   3847 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_465'
                                   3848 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_465'
                                   3849 ;------------------------------------------------------------
                                   3850 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3851 ;	-----------------------------------------
                                   3852 ;	 function ak820_usb_raw_task
                                   3853 ;	-----------------------------------------
      006F01                       3854 _ak820_usb_raw_task:
                                   3855 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006F01 A2 AF            [12] 3856 	mov	c,_EA
      006F03 E4               [12] 3857 	clr	a
      006F04 33               [12] 3858 	rlc	a
      006F05 FF               [12] 3859 	mov	r7,a
                                   3860 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3861 ;	assignBit
      006F06 C2 AF            [12] 3862 	clr	_EA
                                   3863 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006F08 90 07 92         [24] 3864 	mov	dptr,#_USB_EnumStatus
      006F0B E0               [24] 3865 	movx	a,@dptr
      006F0C 60 0A            [24] 3866 	jz	00101$
      006F0E 90 07 99         [24] 3867 	mov	dptr,#_raw_state
      006F11 E0               [24] 3868 	movx	a,@dptr
      006F12 FE               [12] 3869 	mov	r6,a
      006F13 BE 02 02         [24] 3870 	cjne	r6,#0x02,00270$
      006F16 80 06            [24] 3871 	sjmp	00102$
      006F18                       3872 00270$:
      006F18                       3873 00101$:
                                   3874 ;	assignBit
      006F18 EF               [12] 3875 	mov	a,r7
      006F19 24 FF            [12] 3876 	add	a,#0xff
      006F1B 92 AF            [24] 3877 	mov	_EA,c
      006F1D 22               [24] 3878 	ret
      006F1E                       3879 00102$:
                                   3880 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006F1E 90 07 99         [24] 3881 	mov	dptr,#_raw_state
      006F21 74 03            [12] 3882 	mov	a,#0x03
      006F23 F0               [24] 3883 	movx	@dptr,a
                                   3884 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3885 ;	assignBit
      006F24 EF               [12] 3886 	mov	a,r7
      006F25 24 FF            [12] 3887 	add	a,#0xff
      006F27 92 AF            [24] 3888 	mov	_EA,c
                                   3889 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006F29 90 07 9A         [24] 3890 	mov	dptr,#_raw_buffer
      006F2C E0               [24] 3891 	movx	a,@dptr
      006F2D FF               [12] 3892 	mov	r7,a
      006F2E E4               [12] 3893 	clr	a
      006F2F BF FD 01         [24] 3894 	cjne	r7,#0xfd,00271$
      006F32 04               [12] 3895 	inc	a
      006F33                       3896 00271$:
      006F33 FF               [12] 3897 	mov	r7,a
      006F34 70 03            [24] 3898 	jnz	00273$
      006F36 02 6F D6         [24] 3899 	ljmp	00118$
      006F39                       3900 00273$:
      006F39 90 07 9B         [24] 3901 	mov	dptr,#(_raw_buffer + 0x0001)
      006F3C E0               [24] 3902 	movx	a,@dptr
      006F3D 60 03            [24] 3903 	jz	00274$
      006F3F 02 6F D6         [24] 3904 	ljmp	00118$
      006F42                       3905 00274$:
                                   3906 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006F42 90 07 9C         [24] 3907 	mov	dptr,#(_raw_buffer + 0x0002)
      006F45 E0               [24] 3908 	movx	a,@dptr
      006F46 FD               [12] 3909 	mov	r5,a
      006F47 7E 00            [12] 3910 	mov	r6,#0x00
      006F49 90 07 9D         [24] 3911 	mov	dptr,#(_raw_buffer + 0x0003)
      006F4C E0               [24] 3912 	movx	a,@dptr
      006F4D 7B 00            [12] 3913 	mov	r3,#0x00
      006F4F 42 06            [12] 3914 	orl	ar6,a
      006F51 EB               [12] 3915 	mov	a,r3
      006F52 42 05            [12] 3916 	orl	ar5,a
                                   3917 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006F54 90 07 9E         [24] 3918 	mov	dptr,#(_raw_buffer + 0x0004)
      006F57 E0               [24] 3919 	movx	a,@dptr
      006F58 FC               [12] 3920 	mov	r4,a
                                   3921 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006F59 7B 05            [12] 3922 	mov	r3,#0x05
      006F5B                       3923 00128$:
      006F5B EB               [12] 3924 	mov	a,r3
      006F5C 12 70 E0         [24] 3925 	lcall	_ak820_outline_0104
      006F5F 0B               [12] 3926 	inc	r3
      006F60 BB 20 00         [24] 3927 	cjne	r3,#0x20,00275$
      006F63                       3928 00275$:
      006F63 40 F6            [24] 3929 	jc	00128$
                                   3930 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006F65 EC               [12] 3931 	mov	a,r4
      006F66 24 E4            [12] 3932 	add	a,#0xff - 0x1b
      006F68 40 1C            [24] 3933 	jc	00106$
                                   3934 ;	free result
      006F6A EC               [12] 3935 	mov	a,r4
      006F6B 60 26            [24] 3936 	jz	00165$
      006F6D 8C 03            [24] 3937 	mov	ar3,r4
      006F6F 1B               [12] 3938 	dec	r3
      006F70 7A 00            [12] 3939 	mov	r2,#0x00
      006F72 74 FF            [12] 3940 	mov	a,#0xff
      006F74 C3               [12] 3941 	clr	c
      006F75 9B               [12] 3942 	subb	a,r3
      006F76 FB               [12] 3943 	mov	r3,a
      006F77 74 FF            [12] 3944 	mov	a,#0xff
      006F79 9A               [12] 3945 	subb	a,r2
      006F7A FA               [12] 3946 	mov	r2,a
      006F7B 8E 00            [24] 3947 	mov	ar0,r6
      006F7D 8D 01            [24] 3948 	mov	ar1,r5
      006F7F C3               [12] 3949 	clr	c
      006F80 EB               [12] 3950 	mov	a,r3
      006F81 98               [12] 3951 	subb	a,r0
      006F82 EA               [12] 3952 	mov	a,r2
      006F83 99               [12] 3953 	subb	a,r1
      006F84 50 0D            [24] 3954 	jnc	00165$
                                   3955 ;	free result
      006F86                       3956 00106$:
                                   3957 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006F86 90 07 9B         [24] 3958 	mov	dptr,#(_raw_buffer + 0x0001)
      006F89 74 FF            [12] 3959 	mov	a,#0xff
      006F8B F0               [24] 3960 	movx	@dptr,a
                                   3961 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006F8C 90 07 9E         [24] 3962 	mov	dptr,#(_raw_buffer + 0x0004)
      006F8F E4               [12] 3963 	clr	a
      006F90 F0               [24] 3964 	movx	@dptr,a
                                   3965 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006F91 80 3A            [24] 3966 	sjmp	00108$
      006F93                       3967 00165$:
      006F93 7B 00            [12] 3968 	mov	r3,#0x00
      006F95                       3969 00131$:
      006F95 C3               [12] 3970 	clr	c
      006F96 EB               [12] 3971 	mov	a,r3
      006F97 9C               [12] 3972 	subb	a,r4
      006F98 50 33            [24] 3973 	jnc	00108$
      006F9A C0 04            [24] 3974 	push	ar4
      006F9C 8B 02            [24] 3975 	mov	ar2,r3
      006F9E 74 05            [12] 3976 	mov	a,#0x05
      006FA0 2A               [12] 3977 	add	a, r2
      006FA1 F9               [12] 3978 	mov	r1,a
      006FA2 33               [12] 3979 	rlc	a
      006FA3 95 E0            [12] 3980 	subb	a,acc
      006FA5 FA               [12] 3981 	mov	r2,a
      006FA6 E9               [12] 3982 	mov	a,r1
      006FA7 24 9A            [12] 3983 	add	a, #_raw_buffer
      006FA9 F9               [12] 3984 	mov	r1,a
      006FAA EA               [12] 3985 	mov	a,r2
      006FAB 34 07            [12] 3986 	addc	a, #(_raw_buffer >> 8)
      006FAD FA               [12] 3987 	mov	r2,a
      006FAE 8B 1E            [24] 3988 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006FB0 75 1F 00         [24] 3989 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006FB3 8E 00            [24] 3990 	mov	ar0,r6
      006FB5 8D 04            [24] 3991 	mov	ar4,r5
      006FB7 E5 1E            [12] 3992 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006FB9 28               [12] 3993 	add	a, r0
      006FBA F8               [12] 3994 	mov	r0,a
      006FBB E5 1F            [12] 3995 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006FBD 3C               [12] 3996 	addc	a, r4
      006FBE FC               [12] 3997 	mov	r4,a
      006FBF 88 82            [24] 3998 	mov	dpl,r0
      006FC1 8C 83            [24] 3999 	mov	dph,r4
      006FC3 E4               [12] 4000 	clr	a
      006FC4 93               [24] 4001 	movc	a,@a+dptr
      006FC5 12 70 EC         [24] 4002 	lcall	_ak820_outline_0139
      006FC8 0B               [12] 4003 	inc	r3
      006FC9 D0 04            [24] 4004 	pop	ar4
      006FCB 80 C8            [24] 4005 	sjmp	00131$
      006FCD                       4006 00108$:
                                   4007 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006FCD 12 70 CC         [24] 4008 	lcall	_ak820_outline_0045
      006FD0 12 6B DA         [24] 4009 	lcall	_ak820_usb_send
      006FD3 02 70 7C         [24] 4010 	ljmp	00119$
      006FD6                       4011 00118$:
                                   4012 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006FD6 EF               [12] 4013 	mov	a,r7
      006FD7 70 03            [24] 4014 	jnz	00281$
      006FD9 02 70 59         [24] 4015 	ljmp	00114$
      006FDC                       4016 00281$:
      006FDC 12 70 F2         [24] 4017 	lcall	_ak820_outline_0166
      006FDF BF 01 02         [24] 4018 	cjne	r7,#0x01,00282$
      006FE2 80 03            [24] 4019 	sjmp	00283$
      006FE4                       4020 00282$:
      006FE4 02 70 59         [24] 4021 	ljmp	00114$
      006FE7                       4022 00283$:
                                   4023 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006FE7 7F 02            [12] 4024 	mov	r7,#0x02
      006FE9                       4025 00133$:
      006FE9 EF               [12] 4026 	mov	a,r7
      006FEA 12 70 E0         [24] 4027 	lcall	_ak820_outline_0104
      006FED 0F               [12] 4028 	inc	r7
      006FEE BF 20 00         [24] 4029 	cjne	r7,#0x20,00284$
      006FF1                       4030 00284$:
      006FF1 40 F6            [24] 4031 	jc	00133$
                                   4032 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      006FF3 90 07 9C         [24] 4033 	mov	dptr,#(_raw_buffer + 0x0002)
      006FF6 74 01            [12] 4034 	mov	a,#0x01
      006FF8 F0               [24] 4035 	movx	@dptr,a
                                   4036 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      006FF9 90 07 9D         [24] 4037 	mov	dptr,#(_raw_buffer + 0x0003)
      006FFC 74 A8            [12] 4038 	mov	a,#0xa8
      006FFE F0               [24] 4039 	movx	@dptr,a
                                   4040 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      006FFF 90 07 9E         [24] 4041 	mov	dptr,#(_raw_buffer + 0x0004)
      007002 12 3D D7         [24] 4042 	lcall	_ak820_nvm_diagnostic
                                   4043 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      007005 7F 00            [12] 4044 	mov	r7,#0x00
      007007                       4045 00135$:
      007007 8F 06            [24] 4046 	mov	ar6,r7
      007009 74 0B            [12] 4047 	mov	a,#0x0b
      00700B 2E               [12] 4048 	add	a, r6
      00700C 24 9A            [12] 4049 	add	a,#_raw_buffer
      00700E FE               [12] 4050 	mov	r6,a
      00700F E4               [12] 4051 	clr	a
      007010 34 07            [12] 4052 	addc	a, #(_raw_buffer >> 8)
      007012 FD               [12] 4053 	mov	r5,a
      007013 EF               [12] 4054 	mov	a,r7
      007014 24 74            [12] 4055 	add	a, #_ak820_flash_diagnostic
      007016 F5 82            [12] 4056 	mov	dpl,a
      007018 E4               [12] 4057 	clr	a
      007019 34 04            [12] 4058 	addc	a, #(_ak820_flash_diagnostic >> 8)
      00701B F5 83            [12] 4059 	mov	dph,a
      00701D E0               [24] 4060 	movx	a,@dptr
      00701E 8E 82            [24] 4061 	mov	dpl,r6
      007020 8D 83            [24] 4062 	mov	dph,r5
      007022 F0               [24] 4063 	movx	@dptr,a
      007023 0F               [12] 4064 	inc	r7
      007024 BF 06 00         [24] 4065 	cjne	r7,#0x06,00286$
      007027                       4066 00286$:
      007027 40 DE            [24] 4067 	jc	00135$
                                   4068 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      007029 90 0E 4F         [24] 4069 	mov	dptr,#_vial_unlocked
      00702C E0               [24] 4070 	movx	a,@dptr
      00702D 90 07 AB         [24] 4071 	mov	dptr,#(_raw_buffer + 0x0011)
      007030 F0               [24] 4072 	movx	@dptr,a
                                   4073 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      007031 90 0E 50         [24] 4074 	mov	dptr,#_vial_unlock_in_progress
      007034 E0               [24] 4075 	movx	a,@dptr
      007035 90 07 AC         [24] 4076 	mov	dptr,#(_raw_buffer + 0x0012)
      007038 F0               [24] 4077 	movx	@dptr,a
                                   4078 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      007039 90 07 92         [24] 4079 	mov	dptr,#_USB_EnumStatus
      00703C E0               [24] 4080 	movx	a,@dptr
      00703D 90 07 AD         [24] 4081 	mov	dptr,#(_raw_buffer + 0x0013)
      007040 F0               [24] 4082 	movx	@dptr,a
                                   4083 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      007041 90 07 93         [24] 4084 	mov	dptr,#_USB_SleepStatus
      007044 E0               [24] 4085 	movx	a,@dptr
      007045 90 07 AE         [24] 4086 	mov	dptr,#(_raw_buffer + 0x0014)
      007048 F0               [24] 4087 	movx	@dptr,a
                                   4088 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      007049 90 07 99         [24] 4089 	mov	dptr,#_raw_state
      00704C E0               [24] 4090 	movx	a,@dptr
      00704D 90 07 AF         [24] 4091 	mov	dptr,#(_raw_buffer + 0x0015)
      007050 F0               [24] 4092 	movx	@dptr,a
                                   4093 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      007051 12 70 CC         [24] 4094 	lcall	_ak820_outline_0045
      007054 12 6B DA         [24] 4095 	lcall	_ak820_usb_send
      007057 80 23            [24] 4096 	sjmp	00119$
      007059                       4097 00114$:
                                   4098 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      007059 12 6D E9         [24] 4099 	lcall	_raw_request_is_nonpersistent
      00705C E5 82            [12] 4100 	mov	a, dpl
      00705E 90 07 BA         [24] 4101 	mov	dptr,#_raw_reply_without_nvm
      007061 F0               [24] 4102 	movx	@dptr,a
                                   4103 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      007062 12 41 BE         [24] 4104 	lcall	_ak820_nvm_begin
                                   4105 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      007065 90 0C 80         [24] 4106 	mov	dptr,#_raw_hid_receive_PARM_2
      007068 74 20            [12] 4107 	mov	a,#0x20
      00706A F0               [24] 4108 	movx	@dptr,a
      00706B 90 07 9A         [24] 4109 	mov	dptr,#_raw_buffer
      00706E 75 F0 00         [24] 4110 	mov	b, #0x00
      007071 12 AB B4         [24] 4111 	lcall	_raw_hid_receive
                                   4112 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      007074 12 41 D3         [24] 4113 	lcall	_ak820_nvm_end
                                   4114 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      007077 90 07 BA         [24] 4115 	mov	dptr,#_raw_reply_without_nvm
      00707A E4               [12] 4116 	clr	a
      00707B F0               [24] 4117 	movx	@dptr,a
      00707C                       4118 00119$:
                                   4119 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4120 ;	assignBit
      00707C A2 AF            [12] 4121 	mov	c,_EA
      00707E 92 1E            [24] 4122 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4123 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4124 ;	assignBit
      007080 C2 AF            [12] 4125 	clr	_EA
                                   4126 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      007082 12 70 F8         [24] 4127 	lcall	_ak820_outline_0168
      007085 BF 04 08         [24] 4128 	cjne	r7,#0x04,00126$
      007088 90 07 99         [24] 4129 	mov	dptr,#_raw_state
      00708B 74 05            [12] 4130 	mov	a,#0x05
      00708D F0               [24] 4131 	movx	@dptr,a
      00708E 80 1B            [24] 4132 	sjmp	00127$
      007090                       4133 00126$:
                                   4134 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      007090 12 70 F8         [24] 4135 	lcall	_ak820_outline_0168
      007093 BF 03 02         [24] 4136 	cjne	r7,#0x03,00290$
      007096 80 0E            [24] 4137 	sjmp	00121$
      007098                       4138 00290$:
      007098 12 70 F8         [24] 4139 	lcall	_ak820_outline_0168
      00709B BF 06 02         [24] 4140 	cjne	r7,#0x06,00291$
      00709E 80 06            [24] 4141 	sjmp	00121$
      0070A0                       4142 00291$:
      0070A0 12 70 F8         [24] 4143 	lcall	_ak820_outline_0168
      0070A3 BF 07 05         [24] 4144 	cjne	r7,#0x07,00127$
      0070A6                       4145 00121$:
      0070A6 90 07 99         [24] 4146 	mov	dptr,#_raw_state
      0070A9 E4               [12] 4147 	clr	a
      0070AA F0               [24] 4148 	movx	@dptr,a
      0070AB                       4149 00127$:
                                   4150 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4151 ;	assignBit
      0070AB A2 1E            [12] 4152 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      0070AD 92 AF            [24] 4153 	mov	_EA,c
                                   4154 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      0070AF 22               [24] 4155 	ret
                                   4156 ;------------------------------------------------------------
                                   4157 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4158 ;------------------------------------------------------------
                                   4159 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_483'
                                   4160 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_483'
                                   4161 ;------------------------------------------------------------
                                   4162 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4163 ;	-----------------------------------------
                                   4164 ;	 function ak820_usb_take_keyboard_reset
                                   4165 ;	-----------------------------------------
      0070B0                       4166 _ak820_usb_take_keyboard_reset:
                                   4167 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4168 ;	assignBit
      0070B0 A2 AF            [12] 4169 	mov	c,_EA
      0070B2 92 1F            [24] 4170 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4171 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4172 ;	assignBit
      0070B4 C2 AF            [12] 4173 	clr	_EA
                                   4174 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      0070B6 90 07 BB         [24] 4175 	mov	dptr,#_keyboard_reset
      0070B9 E0               [24] 4176 	movx	a,@dptr
      0070BA FF               [12] 4177 	mov	r7,a
                                   4178 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      0070BB E4               [12] 4179 	clr	a
      0070BC F0               [24] 4180 	movx	@dptr,a
                                   4181 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4182 ;	assignBit
      0070BD A2 1F            [12] 4183 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      0070BF 92 AF            [24] 4184 	mov	_EA,c
                                   4185 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      0070C1 EF               [12] 4186 	mov	a,r7
      0070C2 B4 01 00         [24] 4187 	cjne	a,#0x01,00103$
      0070C5                       4188 00103$:
      0070C5 B3               [12] 4189 	cpl	c
      0070C6 92 1F            [24] 4190 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      0070C8 12 3A F1         [24] 4191 	lcall	_ak820_outline_0159
                                   4192 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      0070CB 22               [24] 4193 	ret
                                   4194 	.area CSEG    (CODE)
                                   4195 	.area CONST   (CODE)
                                   4196 	.area CONST   (CODE)
      00BE61                       4197 _shared_offsets:
      00BE61 00                    4198 	.db #0x00	; 0
      00BE62 00                    4199 	.db #0x00	; 0
      00BE63 28                    4200 	.db #0x28	; 40
      00BE64 2E                    4201 	.db #0x2e	; 46
      00BE65 31                    4202 	.db #0x31	; 49	'1'
      00BE66 00                    4203 	.db #0x00	; 0
      00BE67 08                    4204 	.db #0x08	; 8
                                   4205 	.area CSEG    (CODE)
                                   4206 	.area CONST   (CODE)
      00BE68                       4207 _shared_lengths:
      00BE68 00                    4208 	.db #0x00	; 0
      00BE69 00                    4209 	.db #0x00	; 0
      00BE6A 06                    4210 	.db #0x06	; 6
      00BE6B 03                    4211 	.db #0x03	; 3
      00BE6C 03                    4212 	.db #0x03	; 3
      00BE6D 00                    4213 	.db #0x00	; 0
      00BE6E 20                    4214 	.db #0x20	; 32
                                   4215 	.area CSEG    (CODE)
                                   4216 	.area CONST   (CODE)
      00BE6F                       4217 _interface_descriptors:
      00BE6F 12 C4                 4218 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BE71 5B C5                 4219 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BE73 0E C5                 4220 	.byte _RawReport, (_RawReport >> 8)
      00BE75 74 C5                 4221 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BE77 57 C4                 4222 	.byte _SharedReport, (_SharedReport >> 8)
      00BE79 8D C5                 4223 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4224 	.area CSEG    (CODE)
                                   4225 	.area XINIT   (CODE)
                                   4226 	.area CABS    (ABS,CODE)
                                   4227 
                                   4228 ; Experimental exact instruction outlining.
                                   4229 	.globl _ak820_outline_0017
                                   4230 	.globl _ak820_outline_0037
                                   4231 	.globl _ak820_outline_0045
                                   4232 	.globl _ak820_outline_0084
                                   4233 	.globl _ak820_outline_0104
                                   4234 	.globl _ak820_outline_0139
                                   4235 	.globl _ak820_outline_0159
                                   4236 	.globl _ak820_outline_0164
                                   4237 	.globl _ak820_outline_0166
                                   4238 	.globl _ak820_outline_0168
                                   4239 
                                   4240 	.area CSEG (CODE)
                                   4241 ; function ak820_outline_0045
      0070CC                       4242 _ak820_outline_0045:
      0070CC 90 07 FD         [24] 4243 	mov	dptr,#_ak820_usb_send_PARM_2
      0070CF 74 9A            [12] 4244 	mov	a,#_raw_buffer
      0070D1 F0               [24] 4245 	movx	@dptr,a
      0070D2 74 07            [12] 4246 	mov	a,#(_raw_buffer>>8)
      0070D4 A3               [24] 4247 	inc	dptr
      0070D5 F0               [24] 4248 	movx	@dptr,a
      0070D6 90 07 FF         [24] 4249 	mov	dptr,#_ak820_usb_send_PARM_3
      0070D9 74 20            [12] 4250 	mov	a,#0x20
      0070DB F0               [24] 4251 	movx	@dptr,a
      0070DC 75 82 03         [24] 4252 	mov	dpl,#0x03
      0070DF 22               [24] 4253 	ret
                                   4254 
                                   4255 	.area CSEG (CODE)
                                   4256 ; function ak820_outline_0104
      0070E0                       4257 _ak820_outline_0104:
      0070E0 24 9A            [12] 4258 	add	a,#_raw_buffer
      0070E2 F5 82            [12] 4259 	mov	dpl,a
      0070E4 E4               [12] 4260 	clr	a
      0070E5 34 07            [12] 4261 	addc	a,#(_raw_buffer>>8)
      0070E7 F5 83            [12] 4262 	mov	dph,a
      0070E9 E4               [12] 4263 	clr	a
      0070EA F0               [24] 4264 	movx	@dptr,a
      0070EB 22               [24] 4265 	ret
                                   4266 
                                   4267 	.area CSEG (CODE)
                                   4268 ; function ak820_outline_0139
      0070EC                       4269 _ak820_outline_0139:
      0070EC 89 82            [24] 4270 	mov	dpl,r1
      0070EE 8A 83            [24] 4271 	mov	dph,r2
      0070F0 F0               [24] 4272 	movx	@dptr,a
      0070F1 22               [24] 4273 	ret
                                   4274 
                                   4275 	.area CSEG (CODE)
                                   4276 ; function ak820_outline_0166
      0070F2                       4277 _ak820_outline_0166:
      0070F2 90 07 9B         [24] 4278 	mov	dptr,#(_raw_buffer+0x0001)
      0070F5 E0               [24] 4279 	movx	a,@dptr
      0070F6 FF               [12] 4280 	mov	r7,a
      0070F7 22               [24] 4281 	ret
                                   4282 
                                   4283 	.area CSEG (CODE)
                                   4284 ; function ak820_outline_0168
      0070F8                       4285 _ak820_outline_0168:
      0070F8 90 07 99         [24] 4286 	mov	dptr,#_raw_state
      0070FB E0               [24] 4287 	movx	a,@dptr
      0070FC FF               [12] 4288 	mov	r7,a
      0070FD 22               [24] 4289 	ret
