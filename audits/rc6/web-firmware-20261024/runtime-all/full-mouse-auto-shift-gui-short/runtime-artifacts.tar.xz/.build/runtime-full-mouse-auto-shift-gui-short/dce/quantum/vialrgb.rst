                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000CBA                        569 _g_direct_mode_colors::
      000CBA                        570 	.ds 246
      000DB0                        571 _get_supported_PARM_2:
      000DB0                        572 	.ds 1
      000DB1                        573 _get_supported_args_10000_255:
      000DB1                        574 	.ds 2
      000DB3                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000DB3                        576 	.ds 2
      000DB5                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000DB5                        578 	.ds 2
      000DB7                        579 _set_mode_mode_10000_275:
      000DB7                        580 	.ds 2
      000DB9                        581 _get_matrix_pos_for_led_PARM_2:
      000DB9                        582 	.ds 2
      000DBB                        583 _get_matrix_pos_for_led_led_10000_280:
      000DBB                        584 	.ds 2
      000DBD                        585 _fast_set_leds_PARM_2:
      000DBD                        586 	.ds 1
      000DBE                        587 _fast_set_leds_args_10000_282:
      000DBE                        588 	.ds 2
      000DC0                        589 _fast_set_leds_first_index_10001_285:
      000DC0                        590 	.ds 2
      000DC2                        591 _fast_set_leds_num_leds_10001_285:
      000DC2                        592 	.ds 1
      000DC3                        593 _vialrgb_get_value_PARM_2:
      000DC3                        594 	.ds 1
      000DC4                        595 _vialrgb_get_value_data_10000_291:
      000DC4                        596 	.ds 3
      000DC7                        597 _vialrgb_set_value_PARM_2:
      000DC7                        598 	.ds 1
      000DC8                        599 _vialrgb_set_value_data_10000_302:
      000DC8                        600 	.ds 3
      000DCB                        601 _vialrgb_save_PARM_2:
      000DCB                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B758                        654 _get_supported:
      00B758 12 3A C2         [24]  655 	lcall	_ak820_outline_0107
      00B75B 90 0D B1         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B75E 12 3A C7         [24]  657 	lcall	_ak820_outline_0108
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B761 90 0D B1         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B764 12 3A 34         [24]  660 	lcall	_ak820_outline_0005
      00B767 E0               [24]  661 	movx	a,@dptr
      00B768 FD               [12]  662 	mov	r5,a
      00B769 7C 00            [12]  663 	mov	r4,#0x00
      00B76B 12 3A CC         [24]  664 	lcall	_ak820_outline_0118
      00B76E A3               [24]  665 	inc	dptr
      00B76F E0               [24]  666 	movx	a,@dptr
      00B770 FA               [12]  667 	mov	r2,a
      00B771 E4               [12]  668 	clr	a
      00B772 12 45 A2         [24]  669 	lcall	_ak820_outline_0144
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B775 90 0D B0         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00B778 E0               [24]  672 	movx	a,@dptr
      00B779 FB               [12]  673 	mov	r3,a
      00B77A 7A 00            [12]  674 	mov	r2,#0x00
      00B77C                        675 00107$:
      00B77C C3               [12]  676 	clr	c
      00B77D EA               [12]  677 	mov	a,r2
      00B77E 9B               [12]  678 	subb	a,r3
      00B77F 50 0A            [24]  679 	jnc	00101$
      00B781 EA               [12]  680 	mov	a,r2
      00B782 12 3A 71         [24]  681 	lcall	_ak820_outline_0021
      00B785 74 FF            [12]  682 	mov	a,#0xff
      00B787 F0               [24]  683 	movx	@dptr,a
      00B788 0A               [12]  684 	inc	r2
      00B789 80 F1            [24]  685 	sjmp	00107$
      00B78B                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B78B 8D 06            [24]  688 	mov	ar6,r5
      00B78D 8C 07            [24]  689 	mov	ar7,r4
      00B78F 8B 05            [24]  690 	mov	ar5,r3
      00B791 90 0D B1         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00B794 12 3A D1         [24]  692 	lcall	_ak820_outline_0122
      00B797 7A 00            [12]  693 	mov	r2,#0x00
      00B799                        694 00110$:
      00B799 BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00B79C                        696 00159$:
      00B79C 50 46            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B79E EA               [12]  699 	mov	a,r2
      00B79F 75 F0 02         [24]  700 	mov	b,#0x02
      00B7A2 A4               [48]  701 	mul	ab
      00B7A3 24 00            [12]  702 	add	a, #_supported_modes
      00B7A5 F5 82            [12]  703 	mov	dpl,a
      00B7A7 74 C4            [12]  704 	mov	a,#(_supported_modes >> 8)
      00B7A9 12 5B C6         [24]  705 	lcall	_ak820_outline_0109
      00B7AC F8               [12]  706 	mov	r0,a
      00B7AD 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B7AF C3               [12]  709 	clr	c
      00B7B0 EE               [12]  710 	mov	a,r6
      00B7B1 98               [12]  711 	subb	a,r0
      00B7B2 EF               [12]  712 	mov	a,r7
      00B7B3 99               [12]  713 	subb	a,r1
      00B7B4 50 2B            [24]  714 	jnc	00111$
                                    715 ;	free result
      00B7B6 BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00B7B9                        717 00162$:
      00B7B9 40 26            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00B7BB C0 06            [24]  720 	push	ar6
      00B7BD C0 07            [24]  721 	push	ar7
      00B7BF 88 07            [24]  722 	mov	ar7,r0
      00B7C1 12 36 47         [24]  723 	lcall	_ak820_outline_0123
      00B7C4 EF               [12]  724 	mov	a,r7
      00B7C5 F0               [24]  725 	movx	@dptr,a
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B7C6 12 36 47         [24]  727 	lcall	_ak820_outline_0123
      00B7C9 A3               [24]  728 	inc	dptr
      00B7CA 89 00            [24]  729 	mov	ar0,r1
      00B7CC E8               [12]  730 	mov	a,r0
      00B7CD F0               [24]  731 	movx	@dptr,a
                                    732 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B7CE 1D               [12]  733 	dec	r5
      00B7CF 1D               [12]  734 	dec	r5
                                    735 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B7D0 74 02            [12]  736 	mov	a,#0x02
      00B7D2 2B               [12]  737 	add	a, r3
      00B7D3 FB               [12]  738 	mov	r3,a
      00B7D4 E4               [12]  739 	clr	a
      00B7D5 3C               [12]  740 	addc	a, r4
      00B7D6 FC               [12]  741 	mov	r4,a
      00B7D7 90 0D B1         [24]  742 	mov	dptr,#_get_supported_args_10000_255
      00B7DA 12 3A A4         [24]  743 	lcall	_ak820_outline_0083
                                    744 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7DD D0 07            [24]  745 	pop	ar7
      00B7DF D0 06            [24]  746 	pop	ar6
                                    747 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B7E1                        748 00111$:
                                    749 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7E1 0A               [12]  750 	inc	r2
      00B7E2 80 B5            [24]  751 	sjmp	00110$
      00B7E4                        752 00127$:
      00B7E4 90 0D B1         [24]  753 	mov	dptr,#_get_supported_args_10000_255
      00B7E7 12 3A A4         [24]  754 	lcall	_ak820_outline_0083
                                    755 ;	quantum/vialrgb.c:55: }
      00B7EA 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    759 ;------------------------------------------------------------
                                    760 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    761 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    762 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    763 ;------------------------------------------------------------
                                    764 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function qmk_id_to_vialrgb_id
                                    767 ;	-----------------------------------------
      00B7EB                        768 _qmk_id_to_vialrgb_id:
      00B7EB 12 3A C2         [24]  769 	lcall	_ak820_outline_0107
      00B7EE 90 0D B3         [24]  770 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B7F1 12 3A C7         [24]  771 	lcall	_ak820_outline_0108
                                    772 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B7F4 90 0D B3         [24]  773 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B7F7 12 3A 81         [24]  774 	lcall	_ak820_outline_0051
      00B7FA 7D 00            [12]  775 	mov	r5,#0x00
      00B7FC                        776 00105$:
      00B7FC BD 07 00         [24]  777 	cjne	r5,#0x07,00130$
      00B7FF                        778 00130$:
      00B7FF 50 19            [24]  779 	jnc	00103$
                                    780 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B801 12 BC 17         [24]  781 	lcall	_ak820_outline_0047
      00B804 A3               [24]  782 	inc	dptr
      00B805 E4               [12]  783 	clr	a
      00B806 93               [24]  784 	movc	a,@a+dptr
                                    785 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B807 7A 00            [12]  786 	mov	r2,#0x00
      00B809 B5 06 0B         [24]  787 	cjne	a,ar6,00106$
      00B80C EA               [12]  788 	mov	a,r2
      00B80D B5 07 07         [24]  789 	cjne	a,ar7,00106$
                                    790 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B810 12 36 47         [24]  791 	lcall	_ak820_outline_0123
      00B813 12 BC 43         [24]  792 	lcall	_ak820_outline_0146
      00B816 22               [24]  793 	ret
      00B817                        794 00106$:
                                    795 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B817 0D               [12]  796 	inc	r5
      00B818 80 E2            [24]  797 	sjmp	00105$
      00B81A                        798 00103$:
                                    799 ;	quantum/vialrgb.c:63: return 0;
      00B81A 90 00 00         [24]  800 	mov	dptr,#0x0000
                                    801 ;	quantum/vialrgb.c:64: }
      00B81D 22               [24]  802 	ret
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    805 ;------------------------------------------------------------
                                    806 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    807 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    808 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    809 ;------------------------------------------------------------
                                    810 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    811 ;	-----------------------------------------
                                    812 ;	 function vialrgb_id_to_qmk_id
                                    813 ;	-----------------------------------------
      00B81E                        814 _vialrgb_id_to_qmk_id:
      00B81E 12 3A C2         [24]  815 	lcall	_ak820_outline_0107
      00B821 90 0D B5         [24]  816 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B824 12 3A C7         [24]  817 	lcall	_ak820_outline_0108
                                    818 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B827 90 0D B5         [24]  819 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B82A 12 3A 81         [24]  820 	lcall	_ak820_outline_0051
      00B82D 7D 00            [12]  821 	mov	r5,#0x00
      00B82F                        822 00105$:
      00B82F BD 07 00         [24]  823 	cjne	r5,#0x07,00130$
      00B832                        824 00130$:
      00B832 50 19            [24]  825 	jnc	00103$
                                    826 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B834 12 BC 17         [24]  827 	lcall	_ak820_outline_0047
      00B837 E4               [12]  828 	clr	a
      00B838 93               [24]  829 	movc	a,@a+dptr
                                    830 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B839 7A 00            [12]  831 	mov	r2,#0x00
      00B83B B5 06 0C         [24]  832 	cjne	a,ar6,00106$
      00B83E EA               [12]  833 	mov	a,r2
      00B83F B5 07 08         [24]  834 	cjne	a,ar7,00106$
                                    835 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B842 12 36 47         [24]  836 	lcall	_ak820_outline_0123
      00B845 A3               [24]  837 	inc	dptr
      00B846 12 BC 43         [24]  838 	lcall	_ak820_outline_0146
      00B849 22               [24]  839 	ret
      00B84A                        840 00106$:
                                    841 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B84A 0D               [12]  842 	inc	r5
      00B84B 80 E2            [24]  843 	sjmp	00105$
      00B84D                        844 00103$:
                                    845 ;	quantum/vialrgb.c:72: return 0;
      00B84D 90 00 00         [24]  846 	mov	dptr,#0x0000
                                    847 ;	quantum/vialrgb.c:73: }
      00B850 22               [24]  848 	ret
                                    849 ;------------------------------------------------------------
                                    850 ;Allocation info for local variables in function 'get_mode'
                                    851 ;------------------------------------------------------------
                                    852 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    853 ;	-----------------------------------------
                                    854 ;	 function get_mode
                                    855 ;	-----------------------------------------
      00B851                        856 _get_mode:
                                    857 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B851 12 59 BA         [24]  858 	lcall	_rgb_matrix_is_enabled
      00B854 E5 82            [12]  859 	mov	a, dpl
      00B856 70 04            [24]  860 	jnz	00102$
                                    861 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B858 90 00 00         [24]  862 	mov	dptr,#0x0000
      00B85B 22               [24]  863 	ret
      00B85C                        864 00102$:
                                    865 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B85C 12 59 C0         [24]  866 	lcall	_rgb_matrix_get_mode
      00B85F 7E 00            [12]  867 	mov	r6,#0x00
      00B861 8E 83            [24]  868 	mov	dph, r6
                                    869 ;	quantum/vialrgb.c:80: }
      00B863 02 B7 EB         [24]  870 	ljmp	_qmk_id_to_vialrgb_id
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'set_mode'
                                    873 ;------------------------------------------------------------
                                    874 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    875 ;------------------------------------------------------------
                                    876 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    877 ;	-----------------------------------------
                                    878 ;	 function set_mode
                                    879 ;	-----------------------------------------
      00B866                        880 _set_mode:
      00B866 12 3A C2         [24]  881 	lcall	_ak820_outline_0107
      00B869 90 0D B7         [24]  882 	mov	dptr,#_set_mode_mode_10000_275
      00B86C 12 3A C7         [24]  883 	lcall	_ak820_outline_0108
                                    884 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B86F 90 0D B7         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00B872 12 3A 81         [24]  886 	lcall	_ak820_outline_0051
      00B875 90 0D B7         [24]  887 	mov	dptr,#_set_mode_mode_10000_275
      00B878 12 72 1B         [24]  888 	lcall	_ak820_outline_0040
      00B87B 70 03            [24]  889 	jnz	00102$
                                    890 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B87D 02 5A 0D         [24]  891 	ljmp	_rgb_matrix_disable_noeeprom
      00B880                        892 00102$:
                                    893 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B880 C0 07            [24]  894 	push	ar7
      00B882 C0 06            [24]  895 	push	ar6
      00B884 12 59 FC         [24]  896 	lcall	_rgb_matrix_enable_noeeprom
      00B887 D0 06            [24]  897 	pop	ar6
      00B889 D0 07            [24]  898 	pop	ar7
                                    899 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B88B 12 3A CC         [24]  900 	lcall	_ak820_outline_0118
      00B88E 11 1E            [12]  901 	acall	_vialrgb_id_to_qmk_id
                                    902 ;	quantum/vialrgb.c:90: }
      00B890 02 5A 16         [24]  903 	ljmp	_rgb_matrix_mode_noeeprom
                                    904 ;------------------------------------------------------------
                                    905 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    906 ;------------------------------------------------------------
                                    907 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    908 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    909 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    910 ;------------------------------------------------------------
                                    911 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    912 ;	-----------------------------------------
                                    913 ;	 function get_matrix_pos_for_led
                                    914 ;	-----------------------------------------
      00B893                        915 _get_matrix_pos_for_led:
      00B893 12 3A C2         [24]  916 	lcall	_ak820_outline_0107
      00B896 90 0D BB         [24]  917 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B899 12 3A C7         [24]  918 	lcall	_ak820_outline_0108
                                    919 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B89C 90 0D BB         [24]  920 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B89F 12 3A 81         [24]  921 	lcall	_ak820_outline_0051
      00B8A2 EE               [12]  922 	mov	a,r6
      00B8A3 24 FF            [12]  923 	add	a, #_ak820_rgb_slots
      00B8A5 F5 82            [12]  924 	mov	dpl,a
      00B8A7 EF               [12]  925 	mov	a,r7
      00B8A8 34 BD            [12]  926 	addc	a, #(_ak820_rgb_slots >> 8)
      00B8AA F5 83            [12]  927 	mov	dph,a
      00B8AC E4               [12]  928 	clr	a
      00B8AD 93               [24]  929 	movc	a,@a+dptr
      00B8AE FF               [12]  930 	mov	r7,a
                                    931 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B8AF 90 0D B9         [24]  932 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B8B2 12 3A AA         [24]  933 	lcall	_ak820_outline_0084
      00B8B5 EF               [12]  934 	mov	a,r7
      00B8B6 12 5B FC         [24]  935 	lcall	_ak820_outline_0188
      00B8B9 12 86 09         [24]  936 	lcall	_ak820_outline_0121
                                    937 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B8BC 12 3A DC         [24]  938 	lcall	_ak820_outline_0133
      00B8BF A3               [24]  939 	inc	dptr
      00B8C0 53 07 07         [24]  940 	anl	ar7,#0x07
      00B8C3 EF               [12]  941 	mov	a,r7
      00B8C4 F0               [24]  942 	movx	@dptr,a
                                    943 ;	quantum/vialrgb.c:110: }
      00B8C5 22               [24]  944 	ret
                                    945 ;------------------------------------------------------------
                                    946 ;Allocation info for local variables in function 'fast_set_leds'
                                    947 ;------------------------------------------------------------
                                    948 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    949 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    950 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    951 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    952 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    953 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    954 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    955 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    956 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function fast_set_leds
                                    961 ;	-----------------------------------------
      00B8C6                        962 _fast_set_leds:
      00B8C6 12 3A C2         [24]  963 	lcall	_ak820_outline_0107
      00B8C9 90 0D BE         [24]  964 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8CC 12 3A C7         [24]  965 	lcall	_ak820_outline_0108
                                    966 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B8CF 90 0D BD         [24]  967 	mov	dptr,#_fast_set_leds_PARM_2
      00B8D2 E0               [24]  968 	movx	a,@dptr
      00B8D3 FF               [12]  969 	mov	r7,a
      00B8D4 BF 03 00         [24]  970 	cjne	r7,#0x03,00159$
      00B8D7                        971 00159$:
      00B8D7 50 01            [24]  972 	jnc	00102$
      00B8D9 22               [24]  973 	ret
      00B8DA                        974 00102$:
                                    975 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B8DA 90 0D BE         [24]  976 	mov	dptr,#_fast_set_leds_args_10000_282
      00B8DD E0               [24]  977 	movx	a,@dptr
      00B8DE FD               [12]  978 	mov	r5,a
      00B8DF A3               [24]  979 	inc	dptr
      00B8E0 E0               [24]  980 	movx	a,@dptr
      00B8E1 12 4A C3         [24]  981 	lcall	_ak820_outline_0056
      00B8E4 7B 00            [12]  982 	mov	r3,#0x00
      00B8E6 12 3A DC         [24]  983 	lcall	_ak820_outline_0133
      00B8E9 A3               [24]  984 	inc	dptr
      00B8EA E0               [24]  985 	movx	a,@dptr
      00B8EB FA               [12]  986 	mov	r2,a
      00B8EC 79 00            [12]  987 	mov	r1,#0x00
      00B8EE 90 0D C0         [24]  988 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B8F1 E9               [12]  989 	mov	a,r1
      00B8F2 4C               [12]  990 	orl	a,r4
      00B8F3 F0               [24]  991 	movx	@dptr,a
      00B8F4 EA               [12]  992 	mov	a,r2
      00B8F5 4B               [12]  993 	orl	a,r3
      00B8F6 A3               [24]  994 	inc	dptr
      00B8F7 F0               [24]  995 	movx	@dptr,a
                                    996 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B8F8 12 3A DC         [24]  997 	lcall	_ak820_outline_0133
      00B8FB A3               [24]  998 	inc	dptr
      00B8FC A3               [24]  999 	inc	dptr
      00B8FD E0               [24] 1000 	movx	a,@dptr
      00B8FE 90 0D C2         [24] 1001 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B901 F0               [24] 1002 	movx	@dptr,a
                                   1003 ;	quantum/vialrgb.c:119: length -= 3;
      00B902 EF               [12] 1004 	mov	a,r7
      00B903 24 FD            [12] 1005 	add	a,#0xfd
      00B905 90 0D BD         [24] 1006 	mov	dptr,#_fast_set_leds_PARM_2
      00B908 F0               [24] 1007 	movx	@dptr,a
                                   1008 ;	quantum/vialrgb.c:120: args += 3;
      00B909 90 0D BE         [24] 1009 	mov	dptr,#_fast_set_leds_args_10000_282
      00B90C 74 03            [12] 1010 	mov	a,#0x03
      00B90E 2D               [12] 1011 	add	a, r5
      00B90F F0               [24] 1012 	movx	@dptr,a
      00B910 E4               [12] 1013 	clr	a
      00B911 3E               [12] 1014 	addc	a, r6
      00B912 A3               [24] 1015 	inc	dptr
      00B913 F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B914 90 0D C2         [24] 1018 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B917 E0               [24] 1019 	movx	a,@dptr
      00B918 FF               [12] 1020 	mov	r7,a
      00B919 75 F0 03         [24] 1021 	mov	b,#0x03
      00B91C A4               [48] 1022 	mul	ab
      00B91D FE               [12] 1023 	mov	r6,a
      00B91E AD F0            [24] 1024 	mov	r5,b
      00B920 90 0D BD         [24] 1025 	mov	dptr,#_fast_set_leds_PARM_2
      00B923 E0               [24] 1026 	movx	a,@dptr
      00B924 FB               [12] 1027 	mov	r3,a
      00B925 7C 00            [12] 1028 	mov	r4,#0x00
      00B927 C3               [12] 1029 	clr	c
      00B928 EB               [12] 1030 	mov	a,r3
      00B929 9E               [12] 1031 	subb	a,r6
      00B92A EC               [12] 1032 	mov	a,r4
      00B92B 9D               [12] 1033 	subb	a,r5
      00B92C 40 13            [24] 1034 	jc	00103$
                                   1035 ;	free result
      00B92E 90 0D C0         [24] 1036 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B931 12 3A AA         [24] 1037 	lcall	_ak820_outline_0084
      00B934 8D 03            [24] 1038 	mov	ar3,r5
      00B936 8E 04            [24] 1039 	mov	ar4,r6
      00B938 C3               [12] 1040 	clr	c
      00B939 EB               [12] 1041 	mov	a,r3
      00B93A 94 52            [12] 1042 	subb	a,#0x52
      00B93C EC               [12] 1043 	mov	a,r4
      00B93D 94 00            [12] 1044 	subb	a,#0x00
      00B93F 40 01            [24] 1045 	jc	00104$
      00B941                       1046 00103$:
      00B941 22               [24] 1047 	ret
      00B942                       1048 00104$:
                                   1049 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B942 74 52            [12] 1050 	mov	a,#0x52
      00B944 C3               [12] 1051 	clr	c
      00B945 9D               [12] 1052 	subb	a,r5
      00B946 FB               [12] 1053 	mov	r3,a
      00B947 E4               [12] 1054 	clr	a
      00B948 9E               [12] 1055 	subb	a,r6
      00B949 FC               [12] 1056 	mov	r4,a
      00B94A 7A 00            [12] 1057 	mov	r2,#0x00
      00B94C C3               [12] 1058 	clr	c
      00B94D EB               [12] 1059 	mov	a,r3
      00B94E 9F               [12] 1060 	subb	a,r7
      00B94F EC               [12] 1061 	mov	a,r4
      00B950 9A               [12] 1062 	subb	a,r2
      00B951 50 08            [24] 1063 	jnc	00127$
                                   1064 ;	free result
      00B953 90 0D C2         [24] 1065 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B956 74 52            [12] 1066 	mov	a,#0x52
      00B958 C3               [12] 1067 	clr	c
      00B959 9D               [12] 1068 	subb	a,r5
      00B95A F0               [24] 1069 	movx	@dptr,a
                                   1070 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B95B                       1071 00127$:
      00B95B 90 0D C2         [24] 1072 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B95E E0               [24] 1073 	movx	a,@dptr
      00B95F FF               [12] 1074 	mov	r7,a
      00B960 90 0D C0         [24] 1075 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B963 12 3A AA         [24] 1076 	lcall	_ak820_outline_0084
      00B966 7C 00            [12] 1077 	mov	r4,#0x00
      00B968                       1078 00110$:
      00B968 C3               [12] 1079 	clr	c
      00B969 EC               [12] 1080 	mov	a,r4
      00B96A 9F               [12] 1081 	subb	a,r7
      00B96B 40 01            [24] 1082 	jc	00164$
      00B96D 22               [24] 1083 	ret
      00B96E                       1084 00164$:
                                   1085 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B96E C0 07            [24] 1086 	push	ar7
      00B970 90 0D DA         [24] 1087 	mov	dptr,#__mulint_PARM_2
      00B973 12 45 B8         [24] 1088 	lcall	_ak820_outline_0164
      00B976 90 00 03         [24] 1089 	mov	dptr,#0x0003
      00B979 C0 07            [24] 1090 	push	ar7
      00B97B C0 06            [24] 1091 	push	ar6
      00B97D C0 05            [24] 1092 	push	ar5
      00B97F C0 04            [24] 1093 	push	ar4
      00B981 B1 AF            [12] 1094 	acall	__mulint
      00B983 AA 82            [24] 1095 	mov	r2, dpl
      00B985 AB 83            [24] 1096 	mov	r3, dph
      00B987 D0 04            [24] 1097 	pop	ar4
      00B989 D0 05            [24] 1098 	pop	ar5
      00B98B D0 06            [24] 1099 	pop	ar6
      00B98D D0 07            [24] 1100 	pop	ar7
      00B98F 0D               [12] 1101 	inc	r5
      00B990 BD 00 01         [24] 1102 	cjne	r5,#0x00,00165$
      00B993 0E               [12] 1103 	inc	r6
      00B994                       1104 00165$:
      00B994 EA               [12] 1105 	mov	a,r2
      00B995 24 BA            [12] 1106 	add	a, #_g_direct_mode_colors
      00B997 FA               [12] 1107 	mov	r2,a
      00B998 EB               [12] 1108 	mov	a,r3
      00B999 34 0C            [12] 1109 	addc	a, #(_g_direct_mode_colors >> 8)
      00B99B FB               [12] 1110 	mov	r3,a
                                   1111 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B99C 8A 4A            [24] 1112 	mov	_fast_set_leds_sloc0_1_0,r2
      00B99E 8B 4B            [24] 1113 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B9A0 12 BC 29         [24] 1114 	lcall	_ak820_outline_0082
      00B9A3 F8               [12] 1115 	mov	r0,a
      00B9A4 12 BC 37         [24] 1116 	lcall	_ak820_outline_0106
      00B9A7 85 4A 82         [24] 1117 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B9AA 85 4B 83         [24] 1118 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B9AD E8               [12] 1119 	mov	a,r0
      00B9AE F0               [24] 1120 	movx	@dptr,a
                                   1121 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B9AF 74 01            [12] 1122 	mov	a,#0x01
      00B9B1 2A               [12] 1123 	add	a, r2
      00B9B2 F5 4A            [12] 1124 	mov	_fast_set_leds_sloc0_1_0,a
      00B9B4 E4               [12] 1125 	clr	a
      00B9B5 3B               [12] 1126 	addc	a, r3
      00B9B6 F5 4B            [12] 1127 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B9B8 90 0D BE         [24] 1128 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9BB E0               [24] 1129 	movx	a,@dptr
      00B9BC F8               [12] 1130 	mov	r0,a
      00B9BD A3               [24] 1131 	inc	dptr
      00B9BE E0               [24] 1132 	movx	a,@dptr
      00B9BF FF               [12] 1133 	mov	r7,a
      00B9C0 88 82            [24] 1134 	mov	dpl,r0
      00B9C2 8F 83            [24] 1135 	mov	dph,r7
      00B9C4 E0               [24] 1136 	movx	a,@dptr
      00B9C5 F9               [12] 1137 	mov	r1,a
      00B9C6 90 0D BE         [24] 1138 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9C9 74 01            [12] 1139 	mov	a,#0x01
      00B9CB 28               [12] 1140 	add	a, r0
      00B9CC F0               [24] 1141 	movx	@dptr,a
      00B9CD E4               [12] 1142 	clr	a
      00B9CE 3F               [12] 1143 	addc	a, r7
      00B9CF A3               [24] 1144 	inc	dptr
      00B9D0 F0               [24] 1145 	movx	@dptr,a
      00B9D1 85 4A 82         [24] 1146 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B9D4 85 4B 83         [24] 1147 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B9D7 E9               [12] 1148 	mov	a,r1
      00B9D8 F0               [24] 1149 	movx	@dptr,a
                                   1150 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B9D9 12 BC 29         [24] 1151 	lcall	_ak820_outline_0082
      00B9DC F5 4A            [12] 1152 	mov	_fast_set_leds_sloc0_1_0,a
      00B9DE 12 BC 37         [24] 1153 	lcall	_ak820_outline_0106
                                   1154 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B9E1 74 02            [12] 1155 	mov	a,#0x02
      00B9E3 2A               [12] 1156 	add	a, r2
      00B9E4 F5 4C            [12] 1157 	mov	_fast_set_leds_sloc1_1_0,a
      00B9E6 E4               [12] 1158 	clr	a
      00B9E7 3B               [12] 1159 	addc	a, r3
      00B9E8 F5 4D            [12] 1160 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B9EA C3               [12] 1161 	clr	c
      00B9EB 74 A0            [12] 1162 	mov	a,#0xa0
      00B9ED 95 4A            [12] 1163 	subb	a,_fast_set_leds_sloc0_1_0
      00B9EF D0 07            [24] 1164 	pop	ar7
      00B9F1 50 04            [24] 1165 	jnc	00114$
                                   1166 ;	free result
      00B9F3 7B A0            [12] 1167 	mov	r3,#0xa0
      00B9F5 80 04            [24] 1168 	sjmp	00115$
      00B9F7                       1169 00114$:
      00B9F7 AA 4A            [24] 1170 	mov	r2,_fast_set_leds_sloc0_1_0
      00B9F9 8A 03            [24] 1171 	mov	ar3,r2
      00B9FB                       1172 00115$:
      00B9FB 85 4C 82         [24] 1173 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B9FE 85 4D 83         [24] 1174 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00BA01 EB               [12] 1175 	mov	a,r3
      00BA02 F0               [24] 1176 	movx	@dptr,a
                                   1177 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00BA03 0C               [12] 1178 	inc	r4
                                   1179 ;	quantum/vialrgb.c:133: }
      00BA04 21 68            [24] 1180 	ajmp	00110$
                                   1181 ;------------------------------------------------------------
                                   1182 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1183 ;------------------------------------------------------------
                                   1184 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1185 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1186 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1187 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1188 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1189 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1190 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1191 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1192 ;------------------------------------------------------------
                                   1193 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1194 ;	-----------------------------------------
                                   1195 ;	 function vialrgb_get_value
                                   1196 ;	-----------------------------------------
      00BA06                       1197 _vialrgb_get_value:
      00BA06 12 45 55         [24] 1198 	lcall	_ak820_outline_0037
      00BA09 90 0D C4         [24] 1199 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BA0C 12 3A 69         [24] 1200 	lcall	_ak820_outline_0017
                                   1201 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00BA0F 90 0D C3         [24] 1202 	mov	dptr,#_vialrgb_get_value_PARM_2
      00BA12 E0               [24] 1203 	movx	a,@dptr
      00BA13 FF               [12] 1204 	mov	r7,a
      00BA14 BF 20 02         [24] 1205 	cjne	r7,#0x20,00162$
      00BA17 80 01            [24] 1206 	sjmp	00102$
      00BA19                       1207 00162$:
      00BA19 22               [24] 1208 	ret
      00BA1A                       1209 00102$:
                                   1210 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BA1A 90 0D C4         [24] 1211 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00BA1D 12 BC 03         [24] 1212 	lcall	_ak820_outline_0046
                                   1213 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1214 ;	quantum/vialrgb.c:142: switch (cmd) {
      00BA20 BA 40 02         [24] 1215 	cjne	r2,#0x40,00163$
      00BA23 80 15            [24] 1216 	sjmp	00103$
      00BA25                       1217 00163$:
      00BA25 BA 41 02         [24] 1218 	cjne	r2,#0x41,00164$
      00BA28 80 23            [24] 1219 	sjmp	00104$
      00BA2A                       1220 00164$:
      00BA2A BA 42 02         [24] 1221 	cjne	r2,#0x42,00165$
      00BA2D 41 DE            [12] 1222 	ajmp	00105$
      00BA2F                       1223 00165$:
      00BA2F BA 43 02         [24] 1224 	cjne	r2,#0x43,00166$
      00BA32 41 EB            [12] 1225 	ajmp	00106$
      00BA34                       1226 00166$:
      00BA34 BA 44 02         [24] 1227 	cjne	r2,#0x44,00167$
      00BA37 41 F7            [12] 1228 	ajmp	00107$
      00BA39                       1229 00167$:
      00BA39 22               [24] 1230 	ret
                                   1231 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00BA3A                       1232 00103$:
                                   1233 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00BA3A 12 36 47         [24] 1234 	lcall	_ak820_outline_0123
      00BA3D 74 01            [12] 1235 	mov	a,#0x01
      00BA3F F0               [24] 1236 	movx	@dptr,a
                                   1237 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00BA40 12 BB FB         [24] 1238 	lcall	_ak820_outline_0039
      00BA43 E4               [12] 1239 	clr	a
      00BA44 F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00BA45 12 BB FB         [24] 1242 	lcall	_ak820_outline_0039
      00BA48 A3               [24] 1243 	inc	dptr
      00BA49 74 A0            [12] 1244 	mov	a,#0xa0
      00BA4B F0               [24] 1245 	movx	@dptr,a
                                   1246 ;	quantum/vialrgb.c:147: break;
      00BA4C 22               [24] 1247 	ret
                                   1248 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00BA4D                       1249 00104$:
                                   1250 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00BA4D C0 06            [24] 1251 	push	ar6
      00BA4F C0 05            [24] 1252 	push	ar5
      00BA51 C0 04            [24] 1253 	push	ar4
      00BA53 C0 03            [24] 1254 	push	ar3
      00BA55 11 51            [12] 1255 	acall	_get_mode
      00BA57 A9 82            [24] 1256 	mov	r1, dpl
      00BA59 AA 83            [24] 1257 	mov	r2, dph
      00BA5B D0 03            [24] 1258 	pop	ar3
      00BA5D D0 04            [24] 1259 	pop	ar4
      00BA5F D0 05            [24] 1260 	pop	ar5
      00BA61 D0 06            [24] 1261 	pop	ar6
                                   1262 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00BA63 89 00            [24] 1263 	mov	ar0,r1
      00BA65 12 36 47         [24] 1264 	lcall	_ak820_outline_0123
      00BA68 E8               [12] 1265 	mov	a,r0
      00BA69 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00BA6A 12 BB FB         [24] 1268 	lcall	_ak820_outline_0039
      00BA6D 8A 01            [24] 1269 	mov	ar1,r2
      00BA6F E9               [12] 1270 	mov	a,r1
      00BA70 F0               [24] 1271 	movx	@dptr,a
                                   1272 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00BA71 74 04            [12] 1273 	mov	a,#0x04
      00BA73 12 93 5B         [24] 1274 	lcall	_ak820_outline_0136
      00BA76 C0 06            [24] 1275 	push	ar6
      00BA78 C0 05            [24] 1276 	push	ar5
      00BA7A C0 02            [24] 1277 	push	ar2
      00BA7C C0 01            [24] 1278 	push	ar1
      00BA7E 12 59 DB         [24] 1279 	lcall	_rgb_matrix_get_speed
      00BA81 A8 82            [24] 1280 	mov	r0, dpl
      00BA83 D0 01            [24] 1281 	pop	ar1
      00BA85 D0 02            [24] 1282 	pop	ar2
      00BA87 D0 05            [24] 1283 	pop	ar5
      00BA89 D0 06            [24] 1284 	pop	ar6
      00BA8B 12 85 E2         [24] 1285 	lcall	_ak820_outline_0062
                                   1286 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00BA8E 74 05            [12] 1287 	mov	a,#0x05
      00BA90 12 93 5B         [24] 1288 	lcall	_ak820_outline_0136
      00BA93 C0 06            [24] 1289 	push	ar6
      00BA95 C0 05            [24] 1290 	push	ar5
      00BA97 C0 02            [24] 1291 	push	ar2
      00BA99 C0 01            [24] 1292 	push	ar1
      00BA9B 12 59 C6         [24] 1293 	lcall	_rgb_matrix_get_hue
      00BA9E A8 82            [24] 1294 	mov	r0, dpl
      00BAA0 D0 01            [24] 1295 	pop	ar1
      00BAA2 D0 02            [24] 1296 	pop	ar2
      00BAA4 D0 05            [24] 1297 	pop	ar5
      00BAA6 D0 06            [24] 1298 	pop	ar6
      00BAA8 12 85 E2         [24] 1299 	lcall	_ak820_outline_0062
                                   1300 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00BAAB 74 06            [12] 1301 	mov	a,#0x06
      00BAAD 12 93 5B         [24] 1302 	lcall	_ak820_outline_0136
      00BAB0 C0 06            [24] 1303 	push	ar6
      00BAB2 C0 05            [24] 1304 	push	ar5
      00BAB4 C0 02            [24] 1305 	push	ar2
      00BAB6 C0 01            [24] 1306 	push	ar1
      00BAB8 12 59 CD         [24] 1307 	lcall	_rgb_matrix_get_sat
      00BABB A8 82            [24] 1308 	mov	r0, dpl
      00BABD D0 01            [24] 1309 	pop	ar1
      00BABF D0 02            [24] 1310 	pop	ar2
      00BAC1 D0 05            [24] 1311 	pop	ar5
      00BAC3 D0 06            [24] 1312 	pop	ar6
      00BAC5 12 85 E2         [24] 1313 	lcall	_ak820_outline_0062
                                   1314 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00BAC8 74 07            [12] 1315 	mov	a,#0x07
      00BACA 12 93 5B         [24] 1316 	lcall	_ak820_outline_0136
      00BACD C0 02            [24] 1317 	push	ar2
      00BACF C0 01            [24] 1318 	push	ar1
      00BAD1 12 59 D4         [24] 1319 	lcall	_rgb_matrix_get_val
      00BAD4 A8 82            [24] 1320 	mov	r0, dpl
      00BAD6 D0 01            [24] 1321 	pop	ar1
      00BAD8 D0 02            [24] 1322 	pop	ar2
      00BADA 12 85 E2         [24] 1323 	lcall	_ak820_outline_0062
                                   1324 ;	quantum/vialrgb.c:156: break;
      00BADD 22               [24] 1325 	ret
                                   1326 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00BADE                       1327 00105$:
                                   1328 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00BADE EF               [12] 1329 	mov	a,r7
      00BADF 24 FE            [12] 1330 	add	a,#0xfe
      00BAE1 90 0D B0         [24] 1331 	mov	dptr,#_get_supported_PARM_2
      00BAE4 F0               [24] 1332 	movx	@dptr,a
      00BAE5 12 36 47         [24] 1333 	lcall	_ak820_outline_0123
                                   1334 ;	quantum/vialrgb.c:160: break;
      00BAE8 02 B7 58         [24] 1335 	ljmp	_get_supported
                                   1336 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00BAEB                       1337 00106$:
                                   1338 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00BAEB 12 36 47         [24] 1339 	lcall	_ak820_outline_0123
      00BAEE 74 52            [12] 1340 	mov	a,#0x52
      00BAF0 F0               [24] 1341 	movx	@dptr,a
                                   1342 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00BAF1 12 BB FB         [24] 1343 	lcall	_ak820_outline_0039
      00BAF4 E4               [12] 1344 	clr	a
      00BAF5 F0               [24] 1345 	movx	@dptr,a
                                   1346 ;	quantum/vialrgb.c:166: break;
      00BAF6 22               [24] 1347 	ret
                                   1348 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00BAF7                       1349 00107$:
                                   1350 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00BAF7 12 36 47         [24] 1351 	lcall	_ak820_outline_0123
      00BAFA E0               [24] 1352 	movx	a,@dptr
      00BAFB FF               [12] 1353 	mov	r7,a
      00BAFC 7A 00            [12] 1354 	mov	r2,#0x00
      00BAFE 74 03            [12] 1355 	mov	a,#0x03
      00BB00 2D               [12] 1356 	add	a, r5
      00BB01 F8               [12] 1357 	mov	r0,a
      00BB02 E4               [12] 1358 	clr	a
      00BB03 3E               [12] 1359 	addc	a, r6
      00BB04 F9               [12] 1360 	mov	r1,a
      00BB05 C0 03            [24] 1361 	push	ar3
      00BB07 C0 04            [24] 1362 	push	ar4
      00BB09 12 3A F6         [24] 1363 	lcall	_ak820_outline_0160
      00BB0C E0               [24] 1364 	movx	a,@dptr
      00BB0D FB               [12] 1365 	mov	r3,a
      00BB0E E4               [12] 1366 	clr	a
      00BB0F 4F               [12] 1367 	orl	a,r7
      00BB10 F5 4E            [12] 1368 	mov	_vialrgb_get_value_sloc0_1_0,a
      00BB12 EB               [12] 1369 	mov	a,r3
      00BB13 4A               [12] 1370 	orl	a,r2
      00BB14 F5 4F            [12] 1371 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1372 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00BB16 AC 4E            [24] 1373 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00BB18 AF 4F            [24] 1374 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB1A C3               [12] 1375 	clr	c
      00BB1B EC               [12] 1376 	mov	a,r4
      00BB1C 94 52            [12] 1377 	subb	a,#0x52
      00BB1E EF               [12] 1378 	mov	a,r7
      00BB1F 94 00            [12] 1379 	subb	a,#0x00
      00BB21 D0 04            [24] 1380 	pop	ar4
      00BB23 D0 03            [24] 1381 	pop	ar3
      00BB25 40 01            [24] 1382 	jc	00109$
      00BB27 22               [24] 1383 	ret
      00BB28                       1384 00109$:
                                   1385 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00BB28 E5 4E            [12] 1386 	mov	a,_vialrgb_get_value_sloc0_1_0
      00BB2A 25 4E            [12] 1387 	add	a,_vialrgb_get_value_sloc0_1_0
      00BB2C FA               [12] 1388 	mov	r2,a
      00BB2D E5 4F            [12] 1389 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00BB2F 33               [12] 1390 	rlc	a
      00BB30 FF               [12] 1391 	mov	r7,a
      00BB31 EA               [12] 1392 	mov	a,r2
      00BB32 24 B9            [12] 1393 	add	a, #_ak820_led_points
      00BB34 F5 50            [12] 1394 	mov	_vialrgb_get_value_sloc1_1_0,a
      00BB36 EF               [12] 1395 	mov	a,r7
      00BB37 34 C0            [12] 1396 	addc	a, #(_ak820_led_points >> 8)
      00BB39 F5 51            [12] 1397 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00BB3B 85 50 82         [24] 1398 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB3E 85 51 83         [24] 1399 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB41 E4               [12] 1400 	clr	a
      00BB42 93               [24] 1401 	movc	a,@a+dptr
      00BB43 12 36 47         [24] 1402 	lcall	_ak820_outline_0123
      00BB46 F0               [24] 1403 	movx	@dptr,a
                                   1404 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00BB47 85 50 82         [24] 1405 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00BB4A 85 51 83         [24] 1406 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00BB4D A3               [24] 1407 	inc	dptr
      00BB4E E4               [12] 1408 	clr	a
      00BB4F 93               [24] 1409 	movc	a,@a+dptr
      00BB50 12 3A F6         [24] 1410 	lcall	_ak820_outline_0160
      00BB53 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00BB54 12 BB FB         [24] 1413 	lcall	_ak820_outline_0039
      00BB57 A3               [24] 1414 	inc	dptr
      00BB58 74 04            [12] 1415 	mov	a,#0x04
      00BB5A F0               [24] 1416 	movx	@dptr,a
                                   1417 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00BB5B 90 0D B9         [24] 1418 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00BB5E 04               [12] 1419 	inc	a
      00BB5F 2D               [12] 1420 	add	a, r5
      00BB60 F0               [24] 1421 	movx	@dptr,a
      00BB61 E4               [12] 1422 	clr	a
      00BB62 3E               [12] 1423 	addc	a, r6
      00BB63 A3               [24] 1424 	inc	dptr
      00BB64 F0               [24] 1425 	movx	@dptr,a
      00BB65 85 4E 82         [24] 1426 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00BB68 85 4F 83         [24] 1427 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1428 ;	quantum/vialrgb.c:187: }
                                   1429 ;	quantum/vialrgb.c:188: }
      00BB6B 01 93            [24] 1430 	ajmp	_get_matrix_pos_for_led
                                   1431 ;------------------------------------------------------------
                                   1432 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1433 ;------------------------------------------------------------
                                   1434 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1435 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1436 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1437 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1438 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1439 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1440 ;------------------------------------------------------------
                                   1441 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1442 ;	-----------------------------------------
                                   1443 ;	 function vialrgb_set_value
                                   1444 ;	-----------------------------------------
      00BB6D                       1445 _vialrgb_set_value:
      00BB6D 12 45 55         [24] 1446 	lcall	_ak820_outline_0037
      00BB70 90 0D C8         [24] 1447 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BB73 12 3A 69         [24] 1448 	lcall	_ak820_outline_0017
                                   1449 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00BB76 90 0D C7         [24] 1450 	mov	dptr,#_vialrgb_set_value_PARM_2
      00BB79 E0               [24] 1451 	movx	a,@dptr
      00BB7A FF               [12] 1452 	mov	r7,a
      00BB7B BF 20 02         [24] 1453 	cjne	r7,#0x20,00129$
      00BB7E 80 01            [24] 1454 	sjmp	00102$
      00BB80                       1455 00129$:
      00BB80 22               [24] 1456 	ret
      00BB81                       1457 00102$:
                                   1458 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00BB81 90 0D C8         [24] 1459 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00BB84 12 BC 03         [24] 1460 	lcall	_ak820_outline_0046
                                   1461 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1462 ;	quantum/vialrgb.c:196: switch (cmd) {
      00BB87 BA 41 02         [24] 1463 	cjne	r2,#0x41,00130$
      00BB8A 80 06            [24] 1464 	sjmp	00103$
      00BB8C                       1465 00130$:
      00BB8C BA 42 02         [24] 1466 	cjne	r2,#0x42,00131$
      00BB8F 80 5B            [24] 1467 	sjmp	00104$
      00BB91                       1468 00131$:
      00BB91 22               [24] 1469 	ret
                                   1470 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00BB92                       1471 00103$:
                                   1472 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00BB92 12 4A D1         [24] 1473 	lcall	_ak820_outline_0063
      00BB95 12 BB FB         [24] 1474 	lcall	_ak820_outline_0039
      00BB98 E0               [24] 1475 	movx	a,@dptr
      00BB99 F8               [12] 1476 	mov	r0,a
      00BB9A 79 00            [12] 1477 	mov	r1,#0x00
      00BB9C 88 53            [24] 1478 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00BB9E 89 52            [24] 1479 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00BBA0 8A 01            [24] 1480 	mov	ar1,r2
      00BBA2 7A 00            [12] 1481 	mov	r2,#0x00
      00BBA4 E5 53            [12] 1482 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00BBA6 42 02            [12] 1483 	orl	ar2,a
                                   1484 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00BBA8 12 45 BE         [24] 1485 	lcall	_ak820_outline_0183
      00BBAB C0 06            [24] 1486 	push	ar6
      00BBAD C0 05            [24] 1487 	push	ar5
      00BBAF 11 66            [24] 1488 	acall	_set_mode
      00BBB1 D0 05            [24] 1489 	pop	ar5
      00BBB3 D0 06            [24] 1490 	pop	ar6
                                   1491 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00BBB5 12 BB FB         [24] 1492 	lcall	_ak820_outline_0039
      00BBB8 A3               [24] 1493 	inc	dptr
      00BBB9 E0               [24] 1494 	movx	a,@dptr
      00BBBA F5 82            [12] 1495 	mov	dpl,a
      00BBBC C0 06            [24] 1496 	push	ar6
      00BBBE C0 05            [24] 1497 	push	ar5
      00BBC0 12 5A A7         [24] 1498 	lcall	_rgb_matrix_set_speed_noeeprom
      00BBC3 D0 05            [24] 1499 	pop	ar5
      00BBC5 D0 06            [24] 1500 	pop	ar6
                                   1501 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00BBC7 12 BB FB         [24] 1502 	lcall	_ak820_outline_0039
      00BBCA A3               [24] 1503 	inc	dptr
      00BBCB A3               [24] 1504 	inc	dptr
      00BBCC E0               [24] 1505 	movx	a,@dptr
      00BBCD F9               [12] 1506 	mov	r1,a
      00BBCE 7A 00            [12] 1507 	mov	r2,#0x00
      00BBD0 74 06            [12] 1508 	mov	a,#0x06
      00BBD2 12 BC 4D         [24] 1509 	lcall	_ak820_outline_0171
      00BBD5 F8               [12] 1510 	mov	r0,a
      00BBD6 74 07            [12] 1511 	mov	a,#0x07
      00BBD8 12 BC 4D         [24] 1512 	lcall	_ak820_outline_0171
      00BBDB FE               [12] 1513 	mov	r6,a
      00BBDC 90 07 56         [24] 1514 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00BBDF E8               [12] 1515 	mov	a,r0
      00BBE0 F0               [24] 1516 	movx	@dptr,a
      00BBE1 90 07 57         [24] 1517 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00BBE4 EE               [12] 1518 	mov	a,r6
      00BBE5 F0               [24] 1519 	movx	@dptr,a
      00BBE6 12 45 BE         [24] 1520 	lcall	_ak820_outline_0183
                                   1521 ;	quantum/vialrgb.c:202: break;
                                   1522 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00BBE9 02 5A 78         [24] 1523 	ljmp	_rgb_matrix_sethsv_noeeprom
      00BBEC                       1524 00104$:
                                   1525 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00BBEC EF               [12] 1526 	mov	a,r7
      00BBED 24 FE            [12] 1527 	add	a,#0xfe
      00BBEF 90 0D BD         [24] 1528 	mov	dptr,#_fast_set_leds_PARM_2
      00BBF2 F0               [24] 1529 	movx	@dptr,a
      00BBF3 12 36 47         [24] 1530 	lcall	_ak820_outline_0123
                                   1531 ;	quantum/vialrgb.c:210: }
                                   1532 ;	quantum/vialrgb.c:211: }
      00BBF6 01 C6            [24] 1533 	ajmp	_fast_set_leds
                                   1534 ;------------------------------------------------------------
                                   1535 ;Allocation info for local variables in function 'vialrgb_save'
                                   1536 ;------------------------------------------------------------
                                   1537 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1538 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1539 ;------------------------------------------------------------
                                   1540 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1541 ;	-----------------------------------------
                                   1542 ;	 function vialrgb_save
                                   1543 ;	-----------------------------------------
      00BBF8                       1544 _vialrgb_save:
                                   1545 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1546 ;	quantum/vialrgb.c:218: }
      00BBF8 02 55 0B         [24] 1547 	ljmp	_eeconfig_update_rgb_matrix
                                   1548 	.area CSEG    (CODE)
                                   1549 	.area CONST   (CODE)
                                   1550 	.area CONST   (CODE)
      00C400                       1551 _supported_modes:
      00C400 00                    1552 	.db #0x00	; 0
      00C401 00                    1553 	.db #0x00	; 0
      00C402 01                    1554 	.db #0x01	; 1
      00C403 05                    1555 	.db #0x05	; 5
      00C404 02                    1556 	.db #0x02	; 2
      00C405 01                    1557 	.db #0x01	; 1
      00C406 06                    1558 	.db #0x06	; 6
      00C407 02                    1559 	.db #0x02	; 2
      00C408 0D                    1560 	.db #0x0d	; 13
      00C409 03                    1561 	.db #0x03	; 3
      00C40A 0E                    1562 	.db #0x0e	; 14
      00C40B 04                    1563 	.db #0x04	; 4
      00C40C 1F                    1564 	.db #0x1f	; 31
      00C40D 06                    1565 	.db #0x06	; 6
                                   1566 	.area CSEG    (CODE)
                                   1567 	.area XINIT   (CODE)
                                   1568 	.area CABS    (ABS,CODE)
                                   1569 
                                   1570 ; Experimental exact instruction outlining.
                                   1571 	.globl _ak820_outline_0005
                                   1572 	.globl _ak820_outline_0017
                                   1573 	.globl _ak820_outline_0021
                                   1574 	.globl _ak820_outline_0037
                                   1575 	.globl _ak820_outline_0039
                                   1576 	.globl _ak820_outline_0040
                                   1577 	.globl _ak820_outline_0046
                                   1578 	.globl _ak820_outline_0047
                                   1579 	.globl _ak820_outline_0051
                                   1580 	.globl _ak820_outline_0056
                                   1581 	.globl _ak820_outline_0062
                                   1582 	.globl _ak820_outline_0063
                                   1583 	.globl _ak820_outline_0082
                                   1584 	.globl _ak820_outline_0083
                                   1585 	.globl _ak820_outline_0084
                                   1586 	.globl _ak820_outline_0106
                                   1587 	.globl _ak820_outline_0107
                                   1588 	.globl _ak820_outline_0108
                                   1589 	.globl _ak820_outline_0109
                                   1590 	.globl _ak820_outline_0118
                                   1591 	.globl _ak820_outline_0121
                                   1592 	.globl _ak820_outline_0122
                                   1593 	.globl _ak820_outline_0123
                                   1594 	.globl _ak820_outline_0133
                                   1595 	.globl _ak820_outline_0136
                                   1596 	.globl _ak820_outline_0144
                                   1597 	.globl _ak820_outline_0146
                                   1598 	.globl _ak820_outline_0160
                                   1599 	.globl _ak820_outline_0164
                                   1600 	.globl _ak820_outline_0171
                                   1601 	.globl _ak820_outline_0183
                                   1602 	.globl _ak820_outline_0188
                                   1603 
                                   1604 	.area CSEG (CODE)
                                   1605 ; function ak820_outline_0039
      00BBFB                       1606 _ak820_outline_0039:
      00BBFB 8D 82            [24] 1607 	mov	dpl,r5
      00BBFD 8E 83            [24] 1608 	mov	dph,r6
      00BBFF A3               [24] 1609 	inc	dptr
      00BC00 A3               [24] 1610 	inc	dptr
      00BC01 A3               [24] 1611 	inc	dptr
      00BC02 22               [24] 1612 	ret
                                   1613 
                                   1614 	.area CSEG (CODE)
                                   1615 ; function ak820_outline_0046
      00BC03                       1616 _ak820_outline_0046:
      00BC03 E0               [24] 1617 	movx	a,@dptr
      00BC04 FD               [12] 1618 	mov	r5,a
      00BC05 A3               [24] 1619 	inc	dptr
      00BC06 E0               [24] 1620 	movx	a,@dptr
      00BC07 FE               [12] 1621 	mov	r6,a
      00BC08 74 02            [12] 1622 	mov	a,#0x02
      00BC0A 2D               [12] 1623 	add	a,r5
      00BC0B FB               [12] 1624 	mov	r3,a
      00BC0C E4               [12] 1625 	clr	a
      00BC0D 3E               [12] 1626 	addc	a,r6
      00BC0E FC               [12] 1627 	mov	r4,a
      00BC0F 8D 82            [24] 1628 	mov	dpl,r5
      00BC11 8E 83            [24] 1629 	mov	dph,r6
      00BC13 A3               [24] 1630 	inc	dptr
      00BC14 E0               [24] 1631 	movx	a,@dptr
      00BC15 FA               [12] 1632 	mov	r2,a
      00BC16 22               [24] 1633 	ret
                                   1634 
                                   1635 	.area CSEG (CODE)
                                   1636 ; function ak820_outline_0047
      00BC17                       1637 _ak820_outline_0047:
      00BC17 ED               [12] 1638 	mov	a,r5
      00BC18 75 F0 02         [24] 1639 	mov	b,#0x02
      00BC1B A4               [48] 1640 	mul	ab
      00BC1C 24 00            [12] 1641 	add	a,#_supported_modes
      00BC1E FB               [12] 1642 	mov	r3,a
      00BC1F 74 C4            [12] 1643 	mov	a,#(_supported_modes>>8)
      00BC21 35 F0            [12] 1644 	addc	a,b
      00BC23 FC               [12] 1645 	mov	r4,a
      00BC24 8B 82            [24] 1646 	mov	dpl,r3
      00BC26 8C 83            [24] 1647 	mov	dph,r4
      00BC28 22               [24] 1648 	ret
                                   1649 
                                   1650 	.area CSEG (CODE)
                                   1651 ; function ak820_outline_0082
      00BC29                       1652 _ak820_outline_0082:
      00BC29 90 0D BE         [24] 1653 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC2C E0               [24] 1654 	movx	a,@dptr
      00BC2D F9               [12] 1655 	mov	r1,a
      00BC2E A3               [24] 1656 	inc	dptr
      00BC2F E0               [24] 1657 	movx	a,@dptr
      00BC30 FF               [12] 1658 	mov	r7,a
      00BC31 89 82            [24] 1659 	mov	dpl,r1
      00BC33 8F 83            [24] 1660 	mov	dph,r7
      00BC35 E0               [24] 1661 	movx	a,@dptr
      00BC36 22               [24] 1662 	ret
                                   1663 
                                   1664 	.area CSEG (CODE)
                                   1665 ; function ak820_outline_0106
      00BC37                       1666 _ak820_outline_0106:
      00BC37 90 0D BE         [24] 1667 	mov	dptr,#_fast_set_leds_args_10000_282
      00BC3A 74 01            [12] 1668 	mov	a,#0x01
      00BC3C 29               [12] 1669 	add	a,r1
      00BC3D F0               [24] 1670 	movx	@dptr,a
      00BC3E E4               [12] 1671 	clr	a
      00BC3F 3F               [12] 1672 	addc	a,r7
      00BC40 A3               [24] 1673 	inc	dptr
      00BC41 F0               [24] 1674 	movx	@dptr,a
      00BC42 22               [24] 1675 	ret
                                   1676 
                                   1677 	.area CSEG (CODE)
                                   1678 ; function ak820_outline_0146
      00BC43                       1679 _ak820_outline_0146:
      00BC43 E4               [12] 1680 	clr	a
      00BC44 93               [24] 1681 	movc	a,@a+dptr
      00BC45 FC               [12] 1682 	mov	r4,a
      00BC46 7B 00            [12] 1683 	mov	r3,#0x00
      00BC48 8C 82            [24] 1684 	mov	dpl,r4
      00BC4A 8B 83            [24] 1685 	mov	dph,r3
      00BC4C 22               [24] 1686 	ret
                                   1687 
                                   1688 	.area CSEG (CODE)
                                   1689 ; function ak820_outline_0171
      00BC4D                       1690 _ak820_outline_0171:
      00BC4D 2D               [12] 1691 	add	a,r5
      00BC4E F5 82            [12] 1692 	mov	dpl,a
      00BC50 E4               [12] 1693 	clr	a
      00BC51 3E               [12] 1694 	addc	a,r6
      00BC52 F5 83            [12] 1695 	mov	dph,a
      00BC54 E0               [24] 1696 	movx	a,@dptr
      00BC55 22               [24] 1697 	ret
