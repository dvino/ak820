                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _ak820_leader_cancel
                                     21 	.globl _ak820_leader_task
                                     22 	.globl _pre_process_record_quantum
                                     23 	.globl _get_record_keycode
                                     24 	.globl _repeat_key_cancel
                                     25 	.globl _clear_owned_usages
                                     26 	.globl _owned_usage_key
                                     27 	.globl _clear_owned_keys
                                     28 	.globl _del_owned_key
                                     29 	.globl _add_owned_key
                                     30 	.globl _clear_owned_mods
                                     31 	.globl _del_owned_weak_mods
                                     32 	.globl _add_owned_weak_mods
                                     33 	.globl _del_owned_mods
                                     34 	.globl _add_owned_mods
                                     35 	.globl _clear_weak_mods
                                     36 	.globl _clear_mods
                                     37 	.globl _send_keyboard_report
                                     38 	.globl _layer_hold_clear
                                     39 	.globl _layer_hold_off
                                     40 	.globl _layer_hold_on
                                     41 	.globl _ak820_resolve_key
                                     42 	.globl _layer_xor
                                     43 	.globl _layer_and
                                     44 	.globl _layer_or
                                     45 	.globl _layer_off
                                     46 	.globl _layer_on
                                     47 	.globl _layer_move
                                     48 	.globl _layer_clear
                                     49 	.globl _layer_state_set
                                     50 	.globl _default_layer_xor
                                     51 	.globl _default_layer_and
                                     52 	.globl _default_layer_or
                                     53 	.globl _default_layer_set
                                     54 	.globl _post_process_record_quantum
                                     55 	.globl _process_record_quantum
                                     56 	.globl _action_for_keycode
                                     57 	.globl _mDelaymS
                                     58 	.globl _host_consumer_send
                                     59 	.globl _host_system_send
                                     60 	.globl _host_keyboard_leds
                                     61 	.globl _led_set
                                     62 	.globl _clear_keys_from_report
                                     63 	.globl ___memcpy
                                     64 	.globl _ADC_START
                                     65 	.globl _S0_R_FIFO
                                     66 	.globl _S0_T_FIFO
                                     67 	.globl _S0_FREE
                                     68 	.globl _S0_IF_BYTE
                                     69 	.globl _S0_IF_FIRST
                                     70 	.globl _S0_IF_OV
                                     71 	.globl _S0_FST_ACT
                                     72 	.globl _CP_RL2
                                     73 	.globl _C_T2
                                     74 	.globl _TR2
                                     75 	.globl _EXEN2
                                     76 	.globl _TCLK
                                     77 	.globl _RCLK
                                     78 	.globl _EXF2
                                     79 	.globl _CAP1F
                                     80 	.globl _TF2
                                     81 	.globl _RI
                                     82 	.globl _TI
                                     83 	.globl _RB8
                                     84 	.globl _TB8
                                     85 	.globl _REN
                                     86 	.globl _SM2
                                     87 	.globl _SM1
                                     88 	.globl _SM0
                                     89 	.globl _IT0
                                     90 	.globl _IE0
                                     91 	.globl _IT1
                                     92 	.globl _IE1
                                     93 	.globl _TR0
                                     94 	.globl _TF0
                                     95 	.globl _TR1
                                     96 	.globl _TF1
                                     97 	.globl _P4_0
                                     98 	.globl _P4_1
                                     99 	.globl _P4_2
                                    100 	.globl _P4_3
                                    101 	.globl _P4_4
                                    102 	.globl _P4_5
                                    103 	.globl _P4_6
                                    104 	.globl _RXD
                                    105 	.globl _TXD
                                    106 	.globl _INT0
                                    107 	.globl _INT1
                                    108 	.globl _T0
                                    109 	.globl _T1
                                    110 	.globl _MOSI1
                                    111 	.globl _MISO1
                                    112 	.globl _SCK1
                                    113 	.globl _P3_0
                                    114 	.globl _P3_1
                                    115 	.globl _P3_2
                                    116 	.globl _P3_3
                                    117 	.globl _P3_4
                                    118 	.globl _P3_5
                                    119 	.globl _P3_6
                                    120 	.globl _P3_7
                                    121 	.globl _CAP1_
                                    122 	.globl _T2_
                                    123 	.globl _CAP2_
                                    124 	.globl _T2EX_
                                    125 	.globl _RXD1
                                    126 	.globl _TXD1
                                    127 	.globl _P2_0
                                    128 	.globl _P2_1
                                    129 	.globl _P2_2
                                    130 	.globl _P2_3
                                    131 	.globl _P2_4
                                    132 	.globl _P2_5
                                    133 	.globl _P2_6
                                    134 	.globl _P2_7
                                    135 	.globl _AIN0
                                    136 	.globl _AIN1
                                    137 	.globl _AIN2
                                    138 	.globl _AIN3
                                    139 	.globl _AIN4
                                    140 	.globl _AIN5
                                    141 	.globl _AIN6
                                    142 	.globl _AIN7
                                    143 	.globl _CAP1
                                    144 	.globl _T2
                                    145 	.globl _CAP2
                                    146 	.globl _T2EX
                                    147 	.globl _INT0_
                                    148 	.globl _SCS
                                    149 	.globl _MOSI
                                    150 	.globl _MISO
                                    151 	.globl _SCK
                                    152 	.globl _RXD1_
                                    153 	.globl _TXD1_
                                    154 	.globl _P1_0
                                    155 	.globl _P1_1
                                    156 	.globl _P1_2
                                    157 	.globl _P1_3
                                    158 	.globl _P1_4
                                    159 	.globl _P1_5
                                    160 	.globl _P1_6
                                    161 	.globl _P1_7
                                    162 	.globl _AIN8
                                    163 	.globl _AIN9
                                    164 	.globl _AIN10
                                    165 	.globl _AIN11
                                    166 	.globl _AIN12
                                    167 	.globl _AIN13
                                    168 	.globl _RXD_
                                    169 	.globl _TXD_
                                    170 	.globl _SCL0
                                    171 	.globl _SDA0
                                    172 	.globl _P0_0
                                    173 	.globl _P0_1
                                    174 	.globl _P0_2
                                    175 	.globl _P0_3
                                    176 	.globl _P0_4
                                    177 	.globl _P0_5
                                    178 	.globl _P0_6
                                    179 	.globl _P0_7
                                    180 	.globl _IE_SPI0
                                    181 	.globl _IE_USB
                                    182 	.globl _IE_ADC
                                    183 	.globl _IE_UART1
                                    184 	.globl _IE_PWM_I2C
                                    185 	.globl _IE_GPIO
                                    186 	.globl _IE_WDOG
                                    187 	.globl _PX0
                                    188 	.globl _PT0
                                    189 	.globl _PX1
                                    190 	.globl _PT1
                                    191 	.globl _PS
                                    192 	.globl _PT2
                                    193 	.globl _PL_FLAG
                                    194 	.globl _PH_FLAG
                                    195 	.globl _EX0
                                    196 	.globl _ET0
                                    197 	.globl _EX1
                                    198 	.globl _ET1
                                    199 	.globl _ES
                                    200 	.globl _ET2
                                    201 	.globl _E_DIS
                                    202 	.globl _EA
                                    203 	.globl _P
                                    204 	.globl _F1
                                    205 	.globl _OV
                                    206 	.globl _RS0
                                    207 	.globl _RS1
                                    208 	.globl _F0
                                    209 	.globl _AC
                                    210 	.globl _CY
                                    211 	.globl _I2CS_INT_ST
                                    212 	.globl _I2CX_INT
                                    213 	.globl _LED_STATUS
                                    214 	.globl _LED_DMA_H
                                    215 	.globl _LED_DMA_L
                                    216 	.globl _LED_DMA
                                    217 	.globl _LED_PWM_OE
                                    218 	.globl _LED_COMMON
                                    219 	.globl _ADC_CHAN
                                    220 	.globl _ADC_DAT_H
                                    221 	.globl _ADC_DAT_L
                                    222 	.globl _ADC_DAT
                                    223 	.globl _ADC_CTRL
                                    224 	.globl _SPI1_CK_SE
                                    225 	.globl _SPI1_CTRL
                                    226 	.globl _SPI1_DATA
                                    227 	.globl _SPI1_STAT
                                    228 	.globl _SIF1
                                    229 	.globl _SBAUD1
                                    230 	.globl _SBUF1
                                    231 	.globl _SCON1
                                    232 	.globl _SPI0_SETUP
                                    233 	.globl _SPI0_CK_SE
                                    234 	.globl _SPI0_CTRL
                                    235 	.globl _SPI0_DATA
                                    236 	.globl _SPI0_STAT
                                    237 	.globl _T2CAP1H
                                    238 	.globl _T2CAP1L
                                    239 	.globl _T2CAP1
                                    240 	.globl _TH2
                                    241 	.globl _TL2
                                    242 	.globl _T2COUNT
                                    243 	.globl _RCAP2H
                                    244 	.globl _RCAP2L
                                    245 	.globl _RCAP2
                                    246 	.globl _T2MOD
                                    247 	.globl _T2CON
                                    248 	.globl _SBUF
                                    249 	.globl _SCON
                                    250 	.globl _TH1
                                    251 	.globl _TH0
                                    252 	.globl _TL1
                                    253 	.globl _TL0
                                    254 	.globl _TMOD
                                    255 	.globl _TCON
                                    256 	.globl _XBUS_AUX
                                    257 	.globl _P7
                                    258 	.globl _P6_DIR
                                    259 	.globl _P6_OUT_PU
                                    260 	.globl _P6_IN
                                    261 	.globl _P5_DIR
                                    262 	.globl _P5_OUT_PU
                                    263 	.globl _P5_IN
                                    264 	.globl _P4_LED_KEY
                                    265 	.globl _P4_DIR_PU
                                    266 	.globl _P4_MOD_OC
                                    267 	.globl _P4
                                    268 	.globl _P3_DIR_PU
                                    269 	.globl _P3_MOD_OC
                                    270 	.globl _P3
                                    271 	.globl _P2_DIR_PU
                                    272 	.globl _P2_MOD_OC
                                    273 	.globl _P2
                                    274 	.globl _P1_DIR_PU
                                    275 	.globl _P1_MOD_OC
                                    276 	.globl _P1
                                    277 	.globl _P0_DIR_PU
                                    278 	.globl _P0_MOD_OC
                                    279 	.globl _P0
                                    280 	.globl _ROM_CTRL
                                    281 	.globl _ROM_DATA_HH
                                    282 	.globl _ROM_DATA_HL
                                    283 	.globl _ROM_DATA_HI
                                    284 	.globl _ROM_ADDR_H
                                    285 	.globl _ROM_ADDR_L
                                    286 	.globl _ROM_ADDR
                                    287 	.globl _GPIO_IE
                                    288 	.globl _IP_EX
                                    289 	.globl _IE_EX
                                    290 	.globl _IP
                                    291 	.globl _IE
                                    292 	.globl _WDOG_COUNT
                                    293 	.globl _RESET_KEEP
                                    294 	.globl _WAKE_CTRL
                                    295 	.globl _CLOCK_CFG
                                    296 	.globl _POWER_CFG
                                    297 	.globl _PCON
                                    298 	.globl _GLOBAL_CFG
                                    299 	.globl _SAFE_MOD
                                    300 	.globl _DPH
                                    301 	.globl _DPL
                                    302 	.globl _SP
                                    303 	.globl _A_INV
                                    304 	.globl _B
                                    305 	.globl _ACC
                                    306 	.globl _PSW
                                    307 	.globl _disable_action_cache
                                    308 	.globl _tap_code_delay_PARM_2
                                    309 	.globl _process_action_PARM_2
                                    310 	.globl _action_exec_PARM_1
                                    311 	.globl _tp_buttons
                                    312 	.globl _action_exec
                                    313 	.globl _ak820_action_exec
                                    314 	.globl _process_record
                                    315 	.globl _process_record_handler
                                    316 	.globl _process_action
                                    317 	.globl _register_code
                                    318 	.globl _unregister_code
                                    319 	.globl _tap_code_delay
                                    320 	.globl _tap_code
                                    321 	.globl _register_mods
                                    322 	.globl _unregister_mods
                                    323 	.globl _register_weak_mods
                                    324 	.globl _unregister_weak_mods
                                    325 	.globl _clear_keyboard
                                    326 	.globl _clear_keyboard_but_mods
                                    327 	.globl _clear_keyboard_but_mods_and_keys
                                    328 ;--------------------------------------------------------
                                    329 ; special function registers
                                    330 ;--------------------------------------------------------
                                    331 	.area RSEG    (ABS,DATA)
      000000                        332 	.org 0x0000
                           0000D0   333 _PSW	=	0x00d0
                           0000E0   334 _ACC	=	0x00e0
                           0000F0   335 _B	=	0x00f0
                           0000FD   336 _A_INV	=	0x00fd
                           000081   337 _SP	=	0x0081
                           000082   338 _DPL	=	0x0082
                           000083   339 _DPH	=	0x0083
                           0000A1   340 _SAFE_MOD	=	0x00a1
                           0000B1   341 _GLOBAL_CFG	=	0x00b1
                           000087   342 _PCON	=	0x0087
                           0000BA   343 _POWER_CFG	=	0x00ba
                           0000B9   344 _CLOCK_CFG	=	0x00b9
                           0000A9   345 _WAKE_CTRL	=	0x00a9
                           0000FE   346 _RESET_KEEP	=	0x00fe
                           0000FF   347 _WDOG_COUNT	=	0x00ff
                           0000A8   348 _IE	=	0x00a8
                           0000B8   349 _IP	=	0x00b8
                           0000E8   350 _IE_EX	=	0x00e8
                           0000E9   351 _IP_EX	=	0x00e9
                           0000B2   352 _GPIO_IE	=	0x00b2
                           008584   353 _ROM_ADDR	=	0x8584
                           000084   354 _ROM_ADDR_L	=	0x0084
                           000085   355 _ROM_ADDR_H	=	0x0085
                           008F8E   356 _ROM_DATA_HI	=	0x8f8e
                           00008E   357 _ROM_DATA_HL	=	0x008e
                           00008F   358 _ROM_DATA_HH	=	0x008f
                           000086   359 _ROM_CTRL	=	0x0086
                           000080   360 _P0	=	0x0080
                           0000C4   361 _P0_MOD_OC	=	0x00c4
                           0000C5   362 _P0_DIR_PU	=	0x00c5
                           000090   363 _P1	=	0x0090
                           000092   364 _P1_MOD_OC	=	0x0092
                           000093   365 _P1_DIR_PU	=	0x0093
                           0000A0   366 _P2	=	0x00a0
                           000094   367 _P2_MOD_OC	=	0x0094
                           000095   368 _P2_DIR_PU	=	0x0095
                           0000B0   369 _P3	=	0x00b0
                           000096   370 _P3_MOD_OC	=	0x0096
                           000097   371 _P3_DIR_PU	=	0x0097
                           0000C0   372 _P4	=	0x00c0
                           0000C2   373 _P4_MOD_OC	=	0x00c2
                           0000C3   374 _P4_DIR_PU	=	0x00c3
                           0000C1   375 _P4_LED_KEY	=	0x00c1
                           0000AA   376 _P5_IN	=	0x00aa
                           0000AB   377 _P5_OUT_PU	=	0x00ab
                           0000AC   378 _P5_DIR	=	0x00ac
                           0000AD   379 _P6_IN	=	0x00ad
                           0000AE   380 _P6_OUT_PU	=	0x00ae
                           0000AF   381 _P6_DIR	=	0x00af
                           0000F1   382 _P7	=	0x00f1
                           0000A2   383 _XBUS_AUX	=	0x00a2
                           000088   384 _TCON	=	0x0088
                           000089   385 _TMOD	=	0x0089
                           00008A   386 _TL0	=	0x008a
                           00008B   387 _TL1	=	0x008b
                           00008C   388 _TH0	=	0x008c
                           00008D   389 _TH1	=	0x008d
                           000098   390 _SCON	=	0x0098
                           000099   391 _SBUF	=	0x0099
                           0000C8   392 _T2CON	=	0x00c8
                           0000C9   393 _T2MOD	=	0x00c9
                           00CBCA   394 _RCAP2	=	0xcbca
                           0000CA   395 _RCAP2L	=	0x00ca
                           0000CB   396 _RCAP2H	=	0x00cb
                           00CDCC   397 _T2COUNT	=	0xcdcc
                           0000CC   398 _TL2	=	0x00cc
                           0000CD   399 _TH2	=	0x00cd
                           00CFCE   400 _T2CAP1	=	0xcfce
                           0000CE   401 _T2CAP1L	=	0x00ce
                           0000CF   402 _T2CAP1H	=	0x00cf
                           0000F8   403 _SPI0_STAT	=	0x00f8
                           0000F9   404 _SPI0_DATA	=	0x00f9
                           0000FA   405 _SPI0_CTRL	=	0x00fa
                           0000FB   406 _SPI0_CK_SE	=	0x00fb
                           0000FC   407 _SPI0_SETUP	=	0x00fc
                           0000BC   408 _SCON1	=	0x00bc
                           0000BD   409 _SBUF1	=	0x00bd
                           0000BE   410 _SBAUD1	=	0x00be
                           0000BF   411 _SIF1	=	0x00bf
                           0000B4   412 _SPI1_STAT	=	0x00b4
                           0000B5   413 _SPI1_DATA	=	0x00b5
                           0000B6   414 _SPI1_CTRL	=	0x00b6
                           0000B7   415 _SPI1_CK_SE	=	0x00b7
                           0000F3   416 _ADC_CTRL	=	0x00f3
                           00F5F4   417 _ADC_DAT	=	0xf5f4
                           0000F4   418 _ADC_DAT_L	=	0x00f4
                           0000F5   419 _ADC_DAT_H	=	0x00f5
                           0000F6   420 _ADC_CHAN	=	0x00f6
                           0000A6   421 _LED_COMMON	=	0x00a6
                           0000A7   422 _LED_PWM_OE	=	0x00a7
                           00C7C6   423 _LED_DMA	=	0xc7c6
                           0000C6   424 _LED_DMA_L	=	0x00c6
                           0000C7   425 _LED_DMA_H	=	0x00c7
                           0000F7   426 _LED_STATUS	=	0x00f7
                           0000B3   427 _I2CX_INT	=	0x00b3
                           0000BB   428 _I2CS_INT_ST	=	0x00bb
                                    429 ;--------------------------------------------------------
                                    430 ; special function bits
                                    431 ;--------------------------------------------------------
                                    432 	.area RSEG    (ABS,DATA)
      000000                        433 	.org 0x0000
                           0000D7   434 _CY	=	0x00d7
                           0000D6   435 _AC	=	0x00d6
                           0000D5   436 _F0	=	0x00d5
                           0000D4   437 _RS1	=	0x00d4
                           0000D3   438 _RS0	=	0x00d3
                           0000D2   439 _OV	=	0x00d2
                           0000D1   440 _F1	=	0x00d1
                           0000D0   441 _P	=	0x00d0
                           0000AF   442 _EA	=	0x00af
                           0000AE   443 _E_DIS	=	0x00ae
                           0000AD   444 _ET2	=	0x00ad
                           0000AC   445 _ES	=	0x00ac
                           0000AB   446 _ET1	=	0x00ab
                           0000AA   447 _EX1	=	0x00aa
                           0000A9   448 _ET0	=	0x00a9
                           0000A8   449 _EX0	=	0x00a8
                           0000BF   450 _PH_FLAG	=	0x00bf
                           0000BE   451 _PL_FLAG	=	0x00be
                           0000BD   452 _PT2	=	0x00bd
                           0000BC   453 _PS	=	0x00bc
                           0000BB   454 _PT1	=	0x00bb
                           0000BA   455 _PX1	=	0x00ba
                           0000B9   456 _PT0	=	0x00b9
                           0000B8   457 _PX0	=	0x00b8
                           0000EF   458 _IE_WDOG	=	0x00ef
                           0000EE   459 _IE_GPIO	=	0x00ee
                           0000ED   460 _IE_PWM_I2C	=	0x00ed
                           0000EC   461 _IE_UART1	=	0x00ec
                           0000EB   462 _IE_ADC	=	0x00eb
                           0000E9   463 _IE_USB	=	0x00e9
                           0000E8   464 _IE_SPI0	=	0x00e8
                           000087   465 _P0_7	=	0x0087
                           000086   466 _P0_6	=	0x0086
                           000085   467 _P0_5	=	0x0085
                           000084   468 _P0_4	=	0x0084
                           000083   469 _P0_3	=	0x0083
                           000082   470 _P0_2	=	0x0082
                           000081   471 _P0_1	=	0x0081
                           000080   472 _P0_0	=	0x0080
                           000081   473 _SDA0	=	0x0081
                           000080   474 _SCL0	=	0x0080
                           000083   475 _TXD_	=	0x0083
                           000082   476 _RXD_	=	0x0082
                           000085   477 _AIN13	=	0x0085
                           000084   478 _AIN12	=	0x0084
                           000083   479 _AIN11	=	0x0083
                           000082   480 _AIN10	=	0x0082
                           000081   481 _AIN9	=	0x0081
                           000080   482 _AIN8	=	0x0080
                           000097   483 _P1_7	=	0x0097
                           000096   484 _P1_6	=	0x0096
                           000095   485 _P1_5	=	0x0095
                           000094   486 _P1_4	=	0x0094
                           000093   487 _P1_3	=	0x0093
                           000092   488 _P1_2	=	0x0092
                           000091   489 _P1_1	=	0x0091
                           000090   490 _P1_0	=	0x0090
                           000097   491 _TXD1_	=	0x0097
                           000096   492 _RXD1_	=	0x0096
                           000097   493 _SCK	=	0x0097
                           000096   494 _MISO	=	0x0096
                           000095   495 _MOSI	=	0x0095
                           000094   496 _SCS	=	0x0094
                           000092   497 _INT0_	=	0x0092
                           000091   498 _T2EX	=	0x0091
                           000091   499 _CAP2	=	0x0091
                           000090   500 _T2	=	0x0090
                           000090   501 _CAP1	=	0x0090
                           000097   502 _AIN7	=	0x0097
                           000096   503 _AIN6	=	0x0096
                           000095   504 _AIN5	=	0x0095
                           000094   505 _AIN4	=	0x0094
                           000093   506 _AIN3	=	0x0093
                           000092   507 _AIN2	=	0x0092
                           000091   508 _AIN1	=	0x0091
                           000090   509 _AIN0	=	0x0090
                           0000A7   510 _P2_7	=	0x00a7
                           0000A6   511 _P2_6	=	0x00a6
                           0000A5   512 _P2_5	=	0x00a5
                           0000A4   513 _P2_4	=	0x00a4
                           0000A3   514 _P2_3	=	0x00a3
                           0000A2   515 _P2_2	=	0x00a2
                           0000A1   516 _P2_1	=	0x00a1
                           0000A0   517 _P2_0	=	0x00a0
                           0000A7   518 _TXD1	=	0x00a7
                           0000A6   519 _RXD1	=	0x00a6
                           0000A5   520 _T2EX_	=	0x00a5
                           0000A5   521 _CAP2_	=	0x00a5
                           0000A4   522 _T2_	=	0x00a4
                           0000A4   523 _CAP1_	=	0x00a4
                           0000B7   524 _P3_7	=	0x00b7
                           0000B6   525 _P3_6	=	0x00b6
                           0000B5   526 _P3_5	=	0x00b5
                           0000B4   527 _P3_4	=	0x00b4
                           0000B3   528 _P3_3	=	0x00b3
                           0000B2   529 _P3_2	=	0x00b2
                           0000B1   530 _P3_1	=	0x00b1
                           0000B0   531 _P3_0	=	0x00b0
                           0000B7   532 _SCK1	=	0x00b7
                           0000B6   533 _MISO1	=	0x00b6
                           0000B5   534 _MOSI1	=	0x00b5
                           0000B5   535 _T1	=	0x00b5
                           0000B4   536 _T0	=	0x00b4
                           0000B3   537 _INT1	=	0x00b3
                           0000B2   538 _INT0	=	0x00b2
                           0000B1   539 _TXD	=	0x00b1
                           0000B0   540 _RXD	=	0x00b0
                           0000C6   541 _P4_6	=	0x00c6
                           0000C5   542 _P4_5	=	0x00c5
                           0000C4   543 _P4_4	=	0x00c4
                           0000C3   544 _P4_3	=	0x00c3
                           0000C2   545 _P4_2	=	0x00c2
                           0000C1   546 _P4_1	=	0x00c1
                           0000C0   547 _P4_0	=	0x00c0
                           00008F   548 _TF1	=	0x008f
                           00008E   549 _TR1	=	0x008e
                           00008D   550 _TF0	=	0x008d
                           00008C   551 _TR0	=	0x008c
                           00008B   552 _IE1	=	0x008b
                           00008A   553 _IT1	=	0x008a
                           000089   554 _IE0	=	0x0089
                           000088   555 _IT0	=	0x0088
                           00009F   556 _SM0	=	0x009f
                           00009E   557 _SM1	=	0x009e
                           00009D   558 _SM2	=	0x009d
                           00009C   559 _REN	=	0x009c
                           00009B   560 _TB8	=	0x009b
                           00009A   561 _RB8	=	0x009a
                           000099   562 _TI	=	0x0099
                           000098   563 _RI	=	0x0098
                           0000CF   564 _TF2	=	0x00cf
                           0000CF   565 _CAP1F	=	0x00cf
                           0000CE   566 _EXF2	=	0x00ce
                           0000CD   567 _RCLK	=	0x00cd
                           0000CC   568 _TCLK	=	0x00cc
                           0000CB   569 _EXEN2	=	0x00cb
                           0000CA   570 _TR2	=	0x00ca
                           0000C9   571 _C_T2	=	0x00c9
                           0000C8   572 _CP_RL2	=	0x00c8
                           0000FF   573 _S0_FST_ACT	=	0x00ff
                           0000FE   574 _S0_IF_OV	=	0x00fe
                           0000FD   575 _S0_IF_FIRST	=	0x00fd
                           0000FC   576 _S0_IF_BYTE	=	0x00fc
                           0000FB   577 _S0_FREE	=	0x00fb
                           0000FA   578 _S0_T_FIFO	=	0x00fa
                           0000F8   579 _S0_R_FIFO	=	0x00f8
                           0000F7   580 _ADC_START	=	0x00f7
                                    581 ;--------------------------------------------------------
                                    582 ; overlayable register banks
                                    583 ;--------------------------------------------------------
                                    584 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        585 	.ds 8
                                    586 ;--------------------------------------------------------
                                    587 ; internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area DSEG    (DATA)
      000018                        590 _process_action_sloc0_1_0:
      000018                        591 	.ds 1
                                    592 ;--------------------------------------------------------
                                    593 ; overlayable items in internal ram
                                    594 ;--------------------------------------------------------
                                    595 ;--------------------------------------------------------
                                    596 ; indirectly addressable internal ram data
                                    597 ;--------------------------------------------------------
                                    598 	.area ISEG    (DATA)
                                    599 ;--------------------------------------------------------
                                    600 ; absolute internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area IABS    (ABS,DATA)
                                    603 	.area IABS    (ABS,DATA)
                                    604 ;--------------------------------------------------------
                                    605 ; bit data
                                    606 ;--------------------------------------------------------
                                    607 	.area BSEG    (BIT)
      00001F                        608 _process_action_sloc1_1_0:
      00001F                        609 	.ds 1
                                    610 ;--------------------------------------------------------
                                    611 ; paged external ram data
                                    612 ;--------------------------------------------------------
                                    613 	.area PSEG    (PAG,XDATA)
                                    614 ;--------------------------------------------------------
                                    615 ; uninitialized external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area XSEG    (XDATA)
      000828                        618 _tp_buttons::
      000828                        619 	.ds 2
      00082A                        620 _action_exec_PARM_1:
      00082A                        621 	.ds 6
      000830                        622 _action_exec_record_10001_627:
      000830                        623 	.ds 9
      000839                        624 _ak820_action_exec_event_10000_632:
      000839                        625 	.ds 2
      00083B                        626 _ak820_action_exec_snapshot_10000_633:
      00083B                        627 	.ds 6
      000841                        628 _process_record_record_10000_636:
      000841                        629 	.ds 3
      000844                        630 _process_record_handler_record_argument_10000_644:
      000844                        631 	.ds 3
      000847                        632 _process_record_handler_action_10000_645:
      000847                        633 	.ds 2
      000849                        634 _process_action_PARM_2:
      000849                        635 	.ds 2
      00084B                        636 _process_action_record_argument_10000_656:
      00084B                        637 	.ds 3
      00084E                        638 _process_action_on_40000_679:
      00084E                        639 	.ds 1
      00084F                        640 _register_code_code_10000_713:
      00084F                        641 	.ds 1
      000850                        642 _unregister_code_code_10000_727:
      000850                        643 	.ds 1
      000851                        644 _tap_code_delay_PARM_2:
      000851                        645 	.ds 2
      000853                        646 _tap_code_delay_code_10000_740:
      000853                        647 	.ds 1
      000854                        648 _tap_code_code_10000_747:
      000854                        649 	.ds 1
      000855                        650 _register_mods_mods_10000_749:
      000855                        651 	.ds 1
      000856                        652 _unregister_mods_mods_10000_753:
      000856                        653 	.ds 1
      000857                        654 _register_weak_mods_mods_10000_757:
      000857                        655 	.ds 1
      000858                        656 _unregister_weak_mods_mods_10000_761:
      000858                        657 	.ds 1
                                    658 ;--------------------------------------------------------
                                    659 ; absolute external ram data
                                    660 ;--------------------------------------------------------
                                    661 	.area XABS    (ABS,XDATA)
                                    662 ;--------------------------------------------------------
                                    663 ; initialized external ram data
                                    664 ;--------------------------------------------------------
                                    665 	.area XISEG   (XDATA)
      000DD8                        666 _disable_action_cache::
      000DD8                        667 	.ds 1
                                    668 	.area HOME    (CODE)
                                    669 	.area GSINIT0 (CODE)
                                    670 	.area GSINIT1 (CODE)
                                    671 	.area GSINIT2 (CODE)
                                    672 	.area GSINIT3 (CODE)
                                    673 	.area GSINIT4 (CODE)
                                    674 	.area GSINIT5 (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area CSEG    (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; global & static initialisations
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 	.area GSFINAL (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 ;--------------------------------------------------------
                                    686 ; Home
                                    687 ;--------------------------------------------------------
                                    688 	.area HOME    (CODE)
                                    689 	.area HOME    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; code
                                    692 ;--------------------------------------------------------
                                    693 	.area CSEG    (CODE)
                                    694 ;------------------------------------------------------------
                                    695 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    696 ;------------------------------------------------------------
                                    697 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    698 ;------------------------------------------------------------
                                    699 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    700 ;	-----------------------------------------
                           000007   701 	ar7 = 0x07
                           000006   702 	ar6 = 0x06
                           000005   703 	ar5 = 0x05
                           000004   704 	ar4 = 0x04
                           000003   705 	ar3 = 0x03
                           000002   706 	ar2 = 0x02
                           000001   707 	ar1 = 0x01
                           000000   708 	ar0 = 0x00
                                    709 ;	 function action_exec
                                    710 ;	-----------------------------------------
      007253                        711 _action_exec:
                                    712 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      007253 90 08 2C         [24]  713 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007256 12 37 F1         [24]  714 	lcall	_ak820_outline_0005
      007259 12 36 04         [24]  715 	lcall	_ak820_combo_tick
                                    716 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      00725C 90 08 2A         [24]  717 	mov	dptr,#_action_exec_PARM_1
      00725F 12 46 AF         [24]  718 	lcall	_ak820_tapping_before
      007262 E5 82            [12]  719 	mov	a, dpl
      007264 70 01            [24]  720 	jnz	00102$
      007266 22               [24]  721 	ret
      007267                        722 00102$:
                                    723 ;	quantum/action.c:116: if (event.pressed) {
      007267 90 08 2F         [24]  724 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      00726A E0               [24]  725 	movx	a,@dptr
      00726B 60 03            [24]  726 	jz	00104$
                                    727 ;	quantum/action.c:118: clear_weak_mods();
      00726D 12 82 C0         [24]  728 	lcall	_clear_weak_mods
      007270                        729 00104$:
                                    730 ;	quantum/action.c:130: record.event = event;
      007270 90 0D B7         [24]  731 	mov	dptr,#___memcpy_PARM_2
      007273 74 2A            [12]  732 	mov	a,#_action_exec_PARM_1
      007275 F0               [24]  733 	movx	@dptr,a
      007276 74 08            [12]  734 	mov	a,#(_action_exec_PARM_1 >> 8)
      007278 12 38 6D         [24]  735 	lcall	_ak820_outline_0093
      00727B 12 79 35         [24]  736 	lcall	_ak820_outline_0070
      00727E 90 08 30         [24]  737 	mov	dptr,#_action_exec_record_10001_627
      007281 F5 F0            [12]  738 	mov	b,a
      007283 12 BA 56         [24]  739 	lcall	___memcpy
                                    740 ;	quantum/action.c:132: record.tap.count = 0;
      007286 90 08 36         [24]  741 	mov	dptr,#(_action_exec_record_10001_627 + 0x0006)
      007289 E0               [24]  742 	movx	a,@dptr
      00728A 54 0F            [12]  743 	anl	a,#0x0f
      00728C F0               [24]  744 	movx	@dptr,a
                                    745 ;	quantum/action.c:137: record.keycode = 0;
      00728D 90 08 37         [24]  746 	mov	dptr,#(_action_exec_record_10001_627 + 0x0007)
      007290 12 51 99         [24]  747 	lcall	_ak820_outline_0184
                                    748 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      007293 90 08 34         [24]  749 	mov	dptr,#(_action_exec_record_10001_627 + 0x0004)
      007296 E0               [24]  750 	movx	a,@dptr
      007297 60 0D            [24]  751 	jz	00107$
      007299 90 08 30         [24]  752 	mov	dptr,#_action_exec_record_10001_627
      00729C 75 F0 00         [24]  753 	mov	b, #0x00
      00729F 12 A0 9E         [24]  754 	lcall	_pre_process_record_quantum
      0072A2 E5 82            [12]  755 	mov	a, dpl
      0072A4 60 14            [24]  756 	jz	00108$
      0072A6                        757 00107$:
                                    758 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      0072A6 90 08 30         [24]  759 	mov	dptr,#_action_exec_record_10001_627
      0072A9 12 47 96         [24]  760 	lcall	_ak820_tapping_process
      0072AC E5 82            [12]  761 	mov	a, dpl
      0072AE 70 01            [24]  762 	jnz	00106$
      0072B0 22               [24]  763 	ret
      0072B1                        764 00106$:
                                    765 ;	quantum/action.c:175: process_record(&record);
      0072B1 90 08 30         [24]  766 	mov	dptr,#_action_exec_record_10001_627
      0072B4 75 F0 00         [24]  767 	mov	b, #0x00
      0072B7 12 73 06         [24]  768 	lcall	_process_record
      0072BA                        769 00108$:
                                    770 ;	quantum/action.c:188: if (IS_NOEVENT(event)) ak820_leader_task(event.time);
      0072BA 90 08 2E         [24]  771 	mov	dptr,#(_action_exec_PARM_1 + 0x0004)
      0072BD E0               [24]  772 	movx	a,@dptr
      0072BE 70 09            [24]  773 	jnz	00112$
      0072C0 90 08 2C         [24]  774 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      0072C3 12 37 F1         [24]  775 	lcall	_ak820_outline_0005
                                    776 ;	quantum/action.c:190: }
      0072C6 02 3B AE         [24]  777 	ljmp	_ak820_leader_task
      0072C9                        778 00112$:
      0072C9 22               [24]  779 	ret
                                    780 ;------------------------------------------------------------
                                    781 ;Allocation info for local variables in function 'ak820_action_exec'
                                    782 ;------------------------------------------------------------
                                    783 ;event         Allocated with name '_ak820_action_exec_event_10000_632'
                                    784 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_633'
                                    785 ;------------------------------------------------------------
                                    786 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    787 ;	-----------------------------------------
                                    788 ;	 function ak820_action_exec
                                    789 ;	-----------------------------------------
      0072CA                        790 _ak820_action_exec:
      0072CA 12 38 85         [24]  791 	lcall	_ak820_outline_0108
      0072CD 90 08 39         [24]  792 	mov	dptr,#_ak820_action_exec_event_10000_632
      0072D0 12 38 8A         [24]  793 	lcall	_ak820_outline_0109
                                    794 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      0072D3 90 08 39         [24]  795 	mov	dptr,#_ak820_action_exec_event_10000_632
      0072D6 12 38 61         [24]  796 	lcall	_ak820_outline_0079
      0072D9 7F 00            [12]  797 	mov	r7,#0x00
      0072DB 90 0D B7         [24]  798 	mov	dptr,#___memcpy_PARM_2
      0072DE ED               [12]  799 	mov	a,r5
      0072DF 12 38 26         [24]  800 	lcall	_ak820_outline_0017
      0072E2 12 79 35         [24]  801 	lcall	_ak820_outline_0070
      0072E5 90 08 3B         [24]  802 	mov	dptr,#_ak820_action_exec_snapshot_10000_633
      0072E8 F5 F0            [12]  803 	mov	b,a
      0072EA 12 BA 56         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:197: action_exec(snapshot);
      0072ED 90 0D B7         [24]  806 	mov	dptr,#___memcpy_PARM_2
      0072F0 74 3B            [12]  807 	mov	a,#_ak820_action_exec_snapshot_10000_633
      0072F2 F0               [24]  808 	movx	@dptr,a
      0072F3 74 08            [12]  809 	mov	a,#(_ak820_action_exec_snapshot_10000_633 >> 8)
      0072F5 12 38 6D         [24]  810 	lcall	_ak820_outline_0093
      0072F8 12 79 35         [24]  811 	lcall	_ak820_outline_0070
      0072FB 90 08 2A         [24]  812 	mov	dptr,#_action_exec_PARM_1
      0072FE F5 F0            [12]  813 	mov	b,a
      007300 12 BA 56         [24]  814 	lcall	___memcpy
                                    815 ;	quantum/action.c:198: }
      007303 02 72 53         [24]  816 	ljmp	_action_exec
                                    817 ;------------------------------------------------------------
                                    818 ;Allocation info for local variables in function 'process_record_nocache'
                                    819 ;------------------------------------------------------------
                                    820 ;record        Allocated with name '_process_record_nocache_record_10000_634'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function process_record
                                    825 ;	-----------------------------------------
      007306                        826 _process_record:
      007306 12 45 6F         [24]  827 	lcall	_ak820_outline_0037
      007309 90 08 41         [24]  828 	mov	dptr,#_process_record_record_10000_636
      00730C 12 38 26         [24]  829 	lcall	_ak820_outline_0017
                                    830 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      00730F 90 08 41         [24]  831 	mov	dptr,#_process_record_record_10000_636
      007312 12 51 46         [24]  832 	lcall	_ak820_outline_0012
      007315 74 04            [12]  833 	mov	a,#0x04
      007317 12 79 08         [24]  834 	lcall	_ak820_outline_0014
      00731A 12 BB 2F         [24]  835 	lcall	__gptrget
      00731D 70 01            [24]  836 	jnz	00102$
                                    837 ;	quantum/action.c:338: return;
      00731F 22               [24]  838 	ret
      007320                        839 00102$:
                                    840 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007320 8D 02            [24]  841 	mov	ar2,r5
      007322 8E 03            [24]  842 	mov	ar3,r6
      007324 8F 04            [24]  843 	mov	ar4,r7
      007326 90 0D B7         [24]  844 	mov	dptr,#___memcpy_PARM_2
      007329 EA               [12]  845 	mov	a,r2
      00732A 12 79 7C         [24]  846 	lcall	_ak820_outline_0189
      00732D EC               [12]  847 	mov	a,r4
      00732E A3               [24]  848 	inc	dptr
      00732F F0               [24]  849 	movx	@dptr,a
      007330 90 0D BA         [24]  850 	mov	dptr,#___memcpy_PARM_3
      007333 12 51 8B         [24]  851 	lcall	_ak820_outline_0111
      007336 90 06 3E         [24]  852 	mov	dptr,#_ak820_tapping_source_PARM_1
      007339 F5 F0            [12]  853 	mov	b,a
      00733B C0 07            [24]  854 	push	ar7
      00733D C0 06            [24]  855 	push	ar6
      00733F C0 05            [24]  856 	push	ar5
      007341 12 BA 56         [24]  857 	lcall	___memcpy
      007344 12 45 E9         [24]  858 	lcall	_ak820_tapping_source
      007347 AC 82            [24]  859 	mov	r4, dpl
      007349 D0 05            [24]  860 	pop	ar5
      00734B D0 06            [24]  861 	pop	ar6
      00734D D0 07            [24]  862 	pop	ar7
                                    863 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      00734F 74 05            [12]  864 	mov	a,#0x05
      007351 12 78 FA         [24]  865 	lcall	_ak820_outline_0013
      007354 12 BB 2F         [24]  866 	lcall	__gptrget
      007357 FB               [12]  867 	mov	r3,a
                                    868 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      007358 12 79 61         [24]  869 	lcall	_ak820_outline_0148
      00735B 90 0C 0E         [24]  870 	mov	dptr,#_get_record_keycode_PARM_2
      00735E 74 01            [12]  871 	mov	a,#0x01
      007360 12 51 4F         [24]  872 	lcall	_ak820_outline_0034
      007363 C0 04            [24]  873 	push	ar4
      007365 C0 03            [24]  874 	push	ar3
      007367 C0 02            [24]  875 	push	ar2
      007369 C0 01            [24]  876 	push	ar1
      00736B C0 00            [24]  877 	push	ar0
      00736D 12 A0 60         [24]  878 	lcall	_get_record_keycode
      007370 12 45 B8         [24]  879 	lcall	_ak820_outline_0135
      007373 D0 00            [24]  880 	pop	ar0
      007375 D0 01            [24]  881 	pop	ar1
      007377 D0 02            [24]  882 	pop	ar2
      007379 D0 03            [24]  883 	pop	ar3
      00737B D0 04            [24]  884 	pop	ar4
      00737D 12 4B 0F         [24]  885 	lcall	_ak820_outline_0113
      007380 EE               [12]  886 	mov	a,r6
      007381 12 BA F4         [24]  887 	lcall	__gptrput
      007384 A3               [24]  888 	inc	dptr
      007385 EF               [12]  889 	mov	a,r7
      007386 12 BA F4         [24]  890 	lcall	__gptrput
                                    891 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007389 90 08 41         [24]  892 	mov	dptr,#_process_record_record_10000_636
      00738C 12 51 46         [24]  893 	lcall	_ak820_outline_0012
      00738F 12 79 61         [24]  894 	lcall	_ak820_outline_0148
      007392 12 4B 0F         [24]  895 	lcall	_ak820_outline_0113
      007395 12 BB 2F         [24]  896 	lcall	__gptrget
      007398 F8               [12]  897 	mov	r0,a
      007399 A3               [24]  898 	inc	dptr
      00739A 12 BB 2F         [24]  899 	lcall	__gptrget
      00739D F9               [12]  900 	mov	r1,a
      00739E 90 06 4E         [24]  901 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0073A1 EC               [12]  902 	mov	a,r4
      0073A2 F0               [24]  903 	movx	@dptr,a
      0073A3 90 06 4F         [24]  904 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0073A6 EB               [12]  905 	mov	a,r3
      0073A7 F0               [24]  906 	movx	@dptr,a
      0073A8 12 38 C0         [24]  907 	lcall	_ak820_outline_0159
      0073AB C0 07            [24]  908 	push	ar7
      0073AD C0 06            [24]  909 	push	ar6
      0073AF C0 05            [24]  910 	push	ar5
      0073B1 C0 04            [24]  911 	push	ar4
      0073B3 C0 03            [24]  912 	push	ar3
      0073B5 12 49 49         [24]  913 	lcall	_ak820_oneshot_process
      0073B8 E5 82            [12]  914 	mov	a, dpl
      0073BA D0 03            [24]  915 	pop	ar3
      0073BC D0 04            [24]  916 	pop	ar4
      0073BE D0 05            [24]  917 	pop	ar5
      0073C0 D0 06            [24]  918 	pop	ar6
      0073C2 D0 07            [24]  919 	pop	ar7
      0073C4 70 01            [24]  920 	jnz	00104$
      0073C6 22               [24]  921 	ret
      0073C7                        922 00104$:
                                    923 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      0073C7 12 6F B6         [24]  924 	lcall	_ak820_outline_0057
      0073CA C0 04            [24]  925 	push	ar4
      0073CC C0 03            [24]  926 	push	ar3
      0073CE 12 A1 8E         [24]  927 	lcall	_process_record_quantum
      0073D1 E5 82            [12]  928 	mov	a, dpl
      0073D3 D0 03            [24]  929 	pop	ar3
      0073D5 D0 04            [24]  930 	pop	ar4
      0073D7 70 0A            [24]  931 	jnz	00106$
                                    932 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0073D9 90 05 B6         [24]  933 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0073DC EB               [12]  934 	mov	a,r3
      0073DD F0               [24]  935 	movx	@dptr,a
      0073DE 8C 82            [24]  936 	mov	dpl, r4
                                    937 ;	quantum/action.c:360: return;
      0073E0 02 2E BB         [24]  938 	ljmp	_ak820_oneshot_post
      0073E3                        939 00106$:
                                    940 ;	quantum/action.c:366: process_record_handler(record);
      0073E3 90 08 41         [24]  941 	mov	dptr,#_process_record_record_10000_636
      0073E6 12 51 20         [24]  942 	lcall	_ak820_outline_0001
      0073E9 C0 04            [24]  943 	push	ar4
      0073EB C0 03            [24]  944 	push	ar3
      0073ED 12 74 07         [24]  945 	lcall	_process_record_handler
                                    946 ;	quantum/action.c:370: post_process_record_quantum(record);
      0073F0 90 08 41         [24]  947 	mov	dptr,#_process_record_record_10000_636
      0073F3 12 51 20         [24]  948 	lcall	_ak820_outline_0001
      0073F6 12 A1 63         [24]  949 	lcall	_post_process_record_quantum
      0073F9 D0 03            [24]  950 	pop	ar3
      0073FB D0 04            [24]  951 	pop	ar4
                                    952 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0073FD 90 05 B6         [24]  953 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007400 EB               [12]  954 	mov	a,r3
      007401 F0               [24]  955 	movx	@dptr,a
      007402 8C 82            [24]  956 	mov	dpl, r4
                                    957 ;	quantum/action.c:374: }
      007404 02 2E BB         [24]  958 	ljmp	_ak820_oneshot_post
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'process_record_handler'
                                    961 ;------------------------------------------------------------
                                    962 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_644'
                                    963 ;record        Allocated with name '_process_record_handler_record_10000_645'
                                    964 ;action        Allocated with name '_process_record_handler_action_10000_645'
                                    965 ;------------------------------------------------------------
                                    966 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function process_record_handler
                                    969 ;	-----------------------------------------
      007407                        970 _process_record_handler:
      007407 12 45 6F         [24]  971 	lcall	_ak820_outline_0037
      00740A 90 08 44         [24]  972 	mov	dptr,#_process_record_handler_record_argument_10000_644
      00740D 12 38 26         [24]  973 	lcall	_ak820_outline_0017
                                    974 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007410 90 08 44         [24]  975 	mov	dptr,#_process_record_handler_record_argument_10000_644
      007413 12 37 FB         [24]  976 	lcall	_ak820_outline_0007
                                    977 ;	quantum/action.c:387: if (record->keycode) {
      007416 4C               [12]  978 	orl	a,r4
      007417 60 19            [24]  979 	jz	00102$
                                    980 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      007419 12 38 A1         [24]  981 	lcall	_ak820_outline_0126
      00741C C0 07            [24]  982 	push	ar7
      00741E C0 06            [24]  983 	push	ar6
      007420 12 96 9F         [24]  984 	lcall	_action_for_keycode
      007423 12 45 C9         [24]  985 	lcall	_ak820_outline_0151
      007426 D0 06            [24]  986 	pop	ar6
      007428 D0 07            [24]  987 	pop	ar7
      00742A 90 08 47         [24]  988 	mov	dptr,#_process_record_handler_action_10000_645
      00742D 12 38 5B         [24]  989 	lcall	_ak820_outline_0072
      007430 80 2B            [24]  990 	sjmp	00104$
      007432                        991 00102$:
                                    992 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007432 12 79 16         [24]  993 	lcall	_ak820_outline_0022
      007435 7A 00            [12]  994 	mov	r2,#0x00
      007437 12 45 C3         [24]  995 	lcall	_ak820_outline_0144
      00743A 12 45 5D         [24]  996 	lcall	_ak820_outline_0011
      00743D E0               [24]  997 	movx	a,@dptr
      00743E 90 09 83         [24]  998 	mov	dptr,#_ak820_resolve_key_PARM_2
      007441 F0               [24]  999 	movx	@dptr,a
      007442 8D 82            [24] 1000 	mov	dpl, r5
      007444 8C 83            [24] 1001 	mov	dph, r4
      007446 C0 07            [24] 1002 	push	ar7
      007448 C0 06            [24] 1003 	push	ar6
      00744A 12 7C BC         [24] 1004 	lcall	_ak820_resolve_key
      00744D 12 96 9F         [24] 1005 	lcall	_action_for_keycode
      007450 12 45 C9         [24] 1006 	lcall	_ak820_outline_0151
      007453 D0 06            [24] 1007 	pop	ar6
      007455 D0 07            [24] 1008 	pop	ar7
      007457 90 08 47         [24] 1009 	mov	dptr,#_process_record_handler_action_10000_645
      00745A 12 38 5B         [24] 1010 	lcall	_ak820_outline_0072
                                   1011 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      00745D                       1012 00104$:
                                   1013 ;	quantum/action.c:411: process_action(record, action);
      00745D 7D 00            [12] 1014 	mov	r5,#0x00
      00745F 90 0D B7         [24] 1015 	mov	dptr,#___memcpy_PARM_2
      007462 74 47            [12] 1016 	mov	a,#_process_record_handler_action_10000_645
      007464 F0               [24] 1017 	movx	@dptr,a
      007465 74 08            [12] 1018 	mov	a,#(_process_record_handler_action_10000_645 >> 8)
      007467 12 38 6D         [24] 1019 	lcall	_ak820_outline_0093
      00746A 90 0D BA         [24] 1020 	mov	dptr,#___memcpy_PARM_3
      00746D 12 51 8B         [24] 1021 	lcall	_ak820_outline_0111
      007470 90 08 49         [24] 1022 	mov	dptr,#_process_action_PARM_2
      007473 F5 F0            [12] 1023 	mov	b,a
      007475 C0 07            [24] 1024 	push	ar7
      007477 C0 06            [24] 1025 	push	ar6
      007479 C0 05            [24] 1026 	push	ar5
      00747B 12 BA 56         [24] 1027 	lcall	___memcpy
      00747E D0 05            [24] 1028 	pop	ar5
      007480 D0 06            [24] 1029 	pop	ar6
      007482 D0 07            [24] 1030 	pop	ar7
      007484 12 71 CB         [24] 1031 	lcall	_ak820_outline_0064
                                   1032 ;	quantum/action.c:412: }
      007487 02 74 8A         [24] 1033 	ljmp	_process_action
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'register_mouse'
                                   1036 ;------------------------------------------------------------
                                   1037 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1038 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_653'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function process_action
                                   1043 ;	-----------------------------------------
      00748A                       1044 _process_action:
      00748A 12 45 6F         [24] 1045 	lcall	_ak820_outline_0037
      00748D 90 08 4B         [24] 1046 	mov	dptr,#_process_action_record_argument_10000_656
      007490 12 38 26         [24] 1047 	lcall	_ak820_outline_0017
                                   1048 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007493 90 08 4B         [24] 1049 	mov	dptr,#_process_action_record_argument_10000_656
      007496 12 37 F1         [24] 1050 	lcall	_ak820_outline_0005
                                   1051 ;	quantum/action.c:483: pressed = record->event.pressed;
      007499 A3               [24] 1052 	inc	dptr
      00749A A3               [24] 1053 	inc	dptr
      00749B A3               [24] 1054 	inc	dptr
      00749C A3               [24] 1055 	inc	dptr
      00749D A3               [24] 1056 	inc	dptr
      00749E E0               [24] 1057 	movx	a,@dptr
      00749F F5 18            [12] 1058 	mov	_process_action_sloc0_1_0,a
                                   1059 ;	quantum/action.c:507: switch (action.kind.id) {
      0074A1 90 08 4A         [24] 1060 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074A4 E0               [24] 1061 	movx	a,@dptr
      0074A5 C4               [12] 1062 	swap	a
      0074A6 54 0F            [12] 1063 	anl	a,#0x0f
      0074A8 FD               [12] 1064 	mov  r5,a
      0074A9 24 F4            [12] 1065 	add	a,#0xff - 0x0b
      0074AB 50 03            [24] 1066 	jnc	00434$
      0074AD 02 77 2B         [24] 1067 	ljmp	00181$
      0074B0                       1068 00434$:
                                   1069 ;	free result
      0074B0 ED               [12] 1070 	mov	a,r5
      0074B1 24 0A            [12] 1071 	add	a,#(00435$-3-.)
      0074B3 83               [24] 1072 	movc	a,@a+pc
      0074B4 F5 82            [12] 1073 	mov	dpl,a
      0074B6 ED               [12] 1074 	mov	a,r5
      0074B7 24 10            [12] 1075 	add	a,#(00436$-3-.)
      0074B9 83               [24] 1076 	movc	a,@a+pc
      0074BA F5 83            [12] 1077 	mov	dph,a
      0074BC E4               [12] 1078 	clr	a
      0074BD 73               [24] 1079 	jmp	@a+dptr
      0074BE                       1080 00435$:
      0074BE D6                    1081 	.db	00102$
      0074BF D6                    1082 	.db	00102$
      0074C0 2B                    1083 	.db	00181$
      0074C1 2B                    1084 	.db	00181$
      0074C2 60                    1085 	.db	00123$
      0074C3 2B                    1086 	.db	00181$
      0074C4 2B                    1087 	.db	00181$
      0074C5 2B                    1088 	.db	00181$
      0074C6 C0                    1089 	.db	00131$
      0074C7 92                    1090 	.db	00147$
      0074C8 B8                    1091 	.db	00152$
      0074C9 B8                    1092 	.db	00152$
      0074CA                       1093 00436$:
      0074CA 74                    1094 	.db	00102$>>8
      0074CB 74                    1095 	.db	00102$>>8
      0074CC 77                    1096 	.db	00181$>>8
      0074CD 77                    1097 	.db	00181$>>8
      0074CE 75                    1098 	.db	00123$>>8
      0074CF 77                    1099 	.db	00181$>>8
      0074D0 77                    1100 	.db	00181$>>8
      0074D1 77                    1101 	.db	00181$>>8
      0074D2 75                    1102 	.db	00131$>>8
      0074D3 76                    1103 	.db	00147$>>8
      0074D4 76                    1104 	.db	00152$>>8
      0074D5 76                    1105 	.db	00152$>>8
                                   1106 ;	quantum/action.c:510: case ACT_RMODS: {
      0074D6                       1107 00102$:
                                   1108 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0074D6 90 08 4A         [24] 1109 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074D9 E0               [24] 1110 	movx	a,@dptr
      0074DA 54 F0            [12] 1111 	anl	a,#0xf0
      0074DC 70 06            [24] 1112 	jnz	00194$
      0074DE 12 79 4F         [24] 1113 	lcall	_ak820_outline_0115
      0074E1 FD               [12] 1114 	mov	r5,a
      0074E2 80 07            [24] 1115 	sjmp	00195$
      0074E4                       1116 00194$:
      0074E4 12 79 4F         [24] 1117 	lcall	_ak820_outline_0115
      0074E7 C4               [12] 1118 	swap	a
      0074E8 54 F0            [12] 1119 	anl	a,#0xf0
      0074EA FD               [12] 1120 	mov	r5,a
      0074EB                       1121 00195$:
                                   1122 ;	quantum/action.c:513: if (pressed) {
      0074EB E5 18            [12] 1123 	mov	a,_process_action_sloc0_1_0
      0074ED 60 35            [24] 1124 	jz	00119$
                                   1125 ;	quantum/action.c:514: if (mods) {
      0074EF ED               [12] 1126 	mov	a,r5
      0074F0 60 29            [24] 1127 	jz	00110$
                                   1128 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0074F2 12 79 6B         [24] 1129 	lcall	_ak820_outline_0161
      0074F5 FC               [12] 1130 	mov	r4,a
      0074F6 BC E0 00         [24] 1131 	cjne	r4,#0xe0,00440$
      0074F9                       1132 00440$:
      0074F9 40 07            [24] 1133 	jc	00108$
      0074FB 12 79 6B         [24] 1134 	lcall	_ak820_outline_0161
      0074FE 24 18            [12] 1135 	add	a,#0xff - 0xe7
      007500 50 0A            [24] 1136 	jnc	00104$
                                   1137 ;	free result
      007502                       1138 00108$:
      007502 7B 49            [12] 1139 	mov	r3,#_process_action_PARM_2
      007504 7C 08            [12] 1140 	mov	r4,#(_process_action_PARM_2 >> 8)
      007506 12 33 FC         [24] 1141 	lcall	_ak820_outline_0125
      007509 E0               [24] 1142 	movx	a,@dptr
      00750A 70 07            [24] 1143 	jnz	00105$
      00750C                       1144 00104$:
                                   1145 ;	quantum/action.c:519: add_owned_mods(mods);
      00750C 8D 82            [24] 1146 	mov	dpl, r5
      00750E 12 7E D6         [24] 1147 	lcall	_add_owned_mods
      007511 80 05            [24] 1148 	sjmp	00106$
      007513                       1149 00105$:
                                   1150 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      007513 8D 82            [24] 1151 	mov	dpl, r5
      007515 12 7E F5         [24] 1152 	lcall	_add_owned_weak_mods
      007518                       1153 00106$:
                                   1154 ;	quantum/action.c:523: send_keyboard_report();
      007518 12 82 10         [24] 1155 	lcall	_send_keyboard_report
      00751B                       1156 00110$:
                                   1157 ;	quantum/action.c:525: register_code(action.key.code);
      00751B 12 79 3F         [24] 1158 	lcall	_ak820_outline_0078
      00751E 12 77 42         [24] 1159 	lcall	_register_code
      007521 02 77 2B         [24] 1160 	ljmp	00181$
      007524                       1161 00119$:
                                   1162 ;	quantum/action.c:527: unregister_code(action.key.code);
      007524 12 79 3F         [24] 1163 	lcall	_ak820_outline_0078
      007527 C0 05            [24] 1164 	push	ar5
      007529 12 77 AF         [24] 1165 	lcall	_unregister_code
      00752C D0 05            [24] 1166 	pop	ar5
                                   1167 ;	quantum/action.c:528: if (mods) {
      00752E ED               [12] 1168 	mov	a,r5
      00752F 70 03            [24] 1169 	jnz	00444$
      007531 02 77 2B         [24] 1170 	ljmp	00181$
      007534                       1171 00444$:
                                   1172 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007534 12 79 6B         [24] 1173 	lcall	_ak820_outline_0161
      007537 FC               [12] 1174 	mov	r4,a
      007538 BC E0 00         [24] 1175 	cjne	r4,#0xe0,00445$
      00753B                       1176 00445$:
      00753B 40 07            [24] 1177 	jc	00115$
      00753D 12 79 6B         [24] 1178 	lcall	_ak820_outline_0161
      007540 24 18            [12] 1179 	add	a,#0xff - 0xe7
      007542 50 0A            [24] 1180 	jnc	00111$
                                   1181 ;	free result
      007544                       1182 00115$:
      007544 7B 49            [12] 1183 	mov	r3,#_process_action_PARM_2
      007546 7C 08            [12] 1184 	mov	r4,#(_process_action_PARM_2 >> 8)
      007548 12 33 FC         [24] 1185 	lcall	_ak820_outline_0125
      00754B E0               [24] 1186 	movx	a,@dptr
      00754C 70 07            [24] 1187 	jnz	00112$
      00754E                       1188 00111$:
                                   1189 ;	quantum/action.c:530: del_owned_mods(mods);
      00754E 8D 82            [24] 1190 	mov	dpl, r5
      007550 12 7E E6         [24] 1191 	lcall	_del_owned_mods
      007553 80 05            [24] 1192 	sjmp	00113$
      007555                       1193 00112$:
                                   1194 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      007555 8D 82            [24] 1195 	mov	dpl, r5
      007557 12 7F 05         [24] 1196 	lcall	_del_owned_weak_mods
      00755A                       1197 00113$:
                                   1198 ;	quantum/action.c:534: send_keyboard_report();
      00755A 12 82 10         [24] 1199 	lcall	_send_keyboard_report
                                   1200 ;	quantum/action.c:537: } break;
      00755D 02 77 2B         [24] 1201 	ljmp	00181$
                                   1202 ;	quantum/action.c:614: case ACT_USAGE:
      007560                       1203 00123$:
                                   1204 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007560 74 07            [12] 1205 	mov	a,#0x07
      007562 12 38 2E         [24] 1206 	lcall	_ak820_outline_0023
      007565 12 4A 83         [24] 1207 	lcall	_ak820_outline_0008
      007568 C3               [12] 1208 	clr	c
      007569 EC               [12] 1209 	mov	a,r4
      00756A 94 A5            [12] 1210 	subb	a,#0xa5
      00756C ED               [12] 1211 	mov	a,r5
      00756D 94 00            [12] 1212 	subb	a,#0x00
      00756F 40 15            [24] 1213 	jc	00125$
      007571 74 C2            [12] 1214 	mov	a,#0xc2
      007573 9C               [12] 1215 	subb	a,r4
      007574 E4               [12] 1216 	clr	a
      007575 9D               [12] 1217 	subb	a,r5
      007576 40 0E            [24] 1218 	jc	00125$
                                   1219 ;	free result
                                   1220 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      007578 90 0A AA         [24] 1221 	mov	dptr,#_owned_usage_key_PARM_2
      00757B E5 18            [12] 1222 	mov	a,_process_action_sloc0_1_0
      00757D F0               [24] 1223 	movx	@dptr,a
      00757E 8E 82            [24] 1224 	mov	dpl, r6
      007580 12 80 BB         [24] 1225 	lcall	_owned_usage_key
                                   1226 ;	quantum/action.c:622: break;
      007583 02 77 2B         [24] 1227 	ljmp	00181$
      007586                       1228 00125$:
                                   1229 ;	quantum/action.c:625: switch (action.usage.page) {
      007586 12 79 46         [24] 1230 	lcall	_ak820_outline_0089
      007589 FF               [12] 1231 	mov	r7,a
      00758A 60 08            [24] 1232 	jz	00127$
      00758C BF 01 02         [24] 1233 	cjne	r7,#0x01,00452$
      00758F 80 19            [24] 1234 	sjmp	00128$
      007591                       1235 00452$:
      007591 02 77 2B         [24] 1236 	ljmp	00181$
                                   1237 ;	quantum/action.c:626: case PAGE_SYSTEM:
      007594                       1238 00127$:
                                   1239 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      007594 E5 18            [12] 1240 	mov	a,_process_action_sloc0_1_0
      007596 60 05            [24] 1241 	jz	00196$
      007598 12 79 56         [24] 1242 	lcall	_ak820_outline_0132
      00759B 80 04            [24] 1243 	sjmp	00197$
      00759D                       1244 00196$:
      00759D 7E 00            [12] 1245 	mov	r6,#0x00
      00759F 7F 00            [12] 1246 	mov	r7,#0x00
      0075A1                       1247 00197$:
      0075A1 12 38 96         [24] 1248 	lcall	_ak820_outline_0122
      0075A4 12 6F 40         [24] 1249 	lcall	_host_system_send
                                   1250 ;	quantum/action.c:628: break;
      0075A7 02 77 2B         [24] 1251 	ljmp	00181$
                                   1252 ;	quantum/action.c:629: case PAGE_CONSUMER:
      0075AA                       1253 00128$:
                                   1254 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      0075AA E5 18            [12] 1255 	mov	a,_process_action_sloc0_1_0
      0075AC 60 05            [24] 1256 	jz	00198$
      0075AE 12 79 56         [24] 1257 	lcall	_ak820_outline_0132
      0075B1 80 04            [24] 1258 	sjmp	00199$
      0075B3                       1259 00198$:
      0075B3 7E 00            [12] 1260 	mov	r6,#0x00
      0075B5 7F 00            [12] 1261 	mov	r7,#0x00
      0075B7                       1262 00199$:
      0075B7 12 38 96         [24] 1263 	lcall	_ak820_outline_0122
      0075BA 12 6F 70         [24] 1264 	lcall	_host_consumer_send
                                   1265 ;	quantum/action.c:633: break;
      0075BD 02 77 2B         [24] 1266 	ljmp	00181$
                                   1267 ;	quantum/action.c:640: case ACT_LAYER: {
      0075C0                       1268 00131$:
                                   1269 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      0075C0 90 08 4A         [24] 1270 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0075C3 E0               [24] 1271 	movx	a,@dptr
      0075C4 54 03            [12] 1272 	anl	a,#0x03
      0075C6 90 08 4E         [24] 1273 	mov	dptr,#_process_action_on_40000_679
      0075C9 F0               [24] 1274 	movx	@dptr,a
                                   1275 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0075CA E0               [24] 1276 	movx	a,@dptr
      0075CB FF               [12] 1277 	mov	r7,a
      0075CC 60 11            [24] 1278 	jz	00200$
      0075CE E5 18            [12] 1279 	mov	a,_process_action_sloc0_1_0
      0075D0 60 07            [24] 1280 	jz	00202$
      0075D2 8F 06            [24] 1281 	mov	ar6,r7
      0075D4 53 06 01         [24] 1282 	anl	ar6,#0x01
      0075D7 80 10            [24] 1283 	sjmp	00201$
      0075D9                       1284 00202$:
      0075D9 74 02            [12] 1285 	mov	a,#0x02
      0075DB 5F               [12] 1286 	anl	a,r7
      0075DC FE               [12] 1287 	mov	r6,a
      0075DD 80 0A            [24] 1288 	sjmp	00201$
      0075DF                       1289 00200$:
      0075DF E5 18            [12] 1290 	mov	a,_process_action_sloc0_1_0
      0075E1 B4 01 00         [24] 1291 	cjne	a,#0x01,00457$
      0075E4                       1292 00457$:
      0075E4 92 1F            [24] 1293 	mov  _process_action_sloc1_1_0,c
      0075E6 E4               [12] 1294 	clr	a
      0075E7 33               [12] 1295 	rlc	a
      0075E8 FE               [12] 1296 	mov	r6,a
      0075E9                       1297 00201$:
      0075E9 EE               [12] 1298 	mov	a,r6
      0075EA 70 03            [24] 1299 	jnz	00458$
      0075EC 02 77 2B         [24] 1300 	ljmp	00181$
      0075EF                       1301 00458$:
                                   1302 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      0075EF 12 79 6B         [24] 1303 	lcall	_ak820_outline_0161
      0075F2 C4               [12] 1304 	swap	a
      0075F3 03               [12] 1305 	rr	a
      0075F4 54 07            [12] 1306 	anl	a,#0x07
      0075F6 25 E0            [12] 1307 	add	a,acc
      0075F8 25 E0            [12] 1308 	add	a,acc
      0075FA FF               [12] 1309 	mov	r7,a
                                   1310 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0075FB 12 79 6B         [24] 1311 	lcall	_ak820_outline_0161
      0075FE 54 0F            [12] 1312 	anl	a,#0x0f
      007600 FE               [12] 1313 	mov	r6,a
      007601 8F F0            [24] 1314 	mov	b,r7
      007603 05 F0            [12] 1315 	inc	b
      007605 EE               [12] 1316 	mov	a,r6
      007606 80 02            [24] 1317 	sjmp	00460$
      007608                       1318 00459$:
      007608 25 E0            [12] 1319 	add	a,acc
      00760A                       1320 00460$:
      00760A D5 F0 FB         [24] 1321 	djnz	b,00459$
      00760D FE               [12] 1322 	mov	r6,a
                                   1323 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      00760E 12 79 6B         [24] 1324 	lcall	_ak820_outline_0161
      007611 30 E4 11         [24] 1325 	jnb	acc.4,00204$
      007614 8F F0            [24] 1326 	mov	b,r7
      007616 05 F0            [12] 1327 	inc	b
      007618 74 0F            [12] 1328 	mov	a,#0x0f
      00761A 80 02            [24] 1329 	sjmp	00463$
      00761C                       1330 00462$:
      00761C 25 E0            [12] 1331 	add	a,acc
      00761E                       1332 00463$:
      00761E D5 F0 FB         [24] 1333 	djnz	b,00462$
      007621 F4               [12] 1334 	cpl	a
      007622 FF               [12] 1335 	mov	r7,a
      007623 80 02            [24] 1336 	sjmp	00205$
      007625                       1337 00204$:
      007625 7F 00            [12] 1338 	mov	r7,#0x00
      007627                       1339 00205$:
                                   1340 ;	quantum/action.c:648: bits |= mask;
      007627 EE               [12] 1341 	mov	a,r6
      007628 42 07            [12] 1342 	orl	ar7,a
                                   1343 ;	quantum/action.c:649: if (!on) {
      00762A 90 08 4E         [24] 1344 	mov	dptr,#_process_action_on_40000_679
      00762D E0               [24] 1345 	movx	a,@dptr
      00762E 70 31            [24] 1346 	jnz	00143$
                                   1347 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      007630 12 79 46         [24] 1348 	lcall	_ak820_outline_0089
      007633 FE               [12] 1349 	mov	r6,a
      007634 2E               [12] 1350 	add	a,r6
                                   1351 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      007635 90 76 39         [24] 1352 	mov	dptr,#00465$
      007638 73               [24] 1353 	jmp	@a+dptr
      007639                       1354 00465$:
      007639 80 06            [24] 1355 	sjmp	00132$
      00763B 80 0C            [24] 1356 	sjmp	00133$
      00763D 80 12            [24] 1357 	sjmp	00134$
      00763F 80 18            [24] 1358 	sjmp	00135$
      007641                       1359 00132$:
      007641 8F 82            [24] 1360 	mov	dpl, r7
      007643 12 79 CB         [24] 1361 	lcall	_default_layer_and
      007646 02 77 2B         [24] 1362 	ljmp	00181$
                                   1363 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      007649                       1364 00133$:
      007649 8F 82            [24] 1365 	mov	dpl, r7
      00764B 12 79 BA         [24] 1366 	lcall	_default_layer_or
      00764E 02 77 2B         [24] 1367 	ljmp	00181$
                                   1368 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      007651                       1369 00134$:
      007651 8F 82            [24] 1370 	mov	dpl, r7
      007653 12 79 E1         [24] 1371 	lcall	_default_layer_xor
      007656 02 77 2B         [24] 1372 	ljmp	00181$
                                   1373 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      007659                       1374 00135$:
      007659 8F 82            [24] 1375 	mov	dpl, r7
      00765B 12 79 AF         [24] 1376 	lcall	_default_layer_set
                                   1377 ;	quantum/action.c:655: }
      00765E 02 77 2B         [24] 1378 	ljmp	00181$
      007661                       1379 00143$:
                                   1380 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      007661 12 79 46         [24] 1381 	lcall	_ak820_outline_0089
      007664 FE               [12] 1382 	mov	r6,a
      007665 2E               [12] 1383 	add	a,r6
                                   1384 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      007666 90 76 6A         [24] 1385 	mov	dptr,#00466$
      007669 73               [24] 1386 	jmp	@a+dptr
      00766A                       1387 00466$:
      00766A 80 06            [24] 1388 	sjmp	00137$
      00766C 80 0C            [24] 1389 	sjmp	00138$
      00766E 80 12            [24] 1390 	sjmp	00139$
      007670 80 18            [24] 1391 	sjmp	00140$
      007672                       1392 00137$:
      007672 8F 82            [24] 1393 	mov	dpl, r7
      007674 12 7B 64         [24] 1394 	lcall	_layer_and
      007677 02 77 2B         [24] 1395 	ljmp	00181$
                                   1396 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      00767A                       1397 00138$:
      00767A 8F 82            [24] 1398 	mov	dpl, r7
      00767C 12 7B 53         [24] 1399 	lcall	_layer_or
      00767F 02 77 2B         [24] 1400 	ljmp	00181$
                                   1401 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      007682                       1402 00139$:
      007682 8F 82            [24] 1403 	mov	dpl, r7
      007684 12 7B 7A         [24] 1404 	lcall	_layer_xor
      007687 02 77 2B         [24] 1405 	ljmp	00181$
                                   1406 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      00768A                       1407 00140$:
      00768A 8F 82            [24] 1408 	mov	dpl, r7
      00768C 12 7A F0         [24] 1409 	lcall	_layer_state_set
                                   1410 ;	quantum/action.c:665: break;
      00768F 02 77 2B         [24] 1411 	ljmp	00181$
                                   1412 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      007692                       1413 00147$:
                                   1414 ;	quantum/action.c:668: if (pressed) {
      007692 E5 18            [12] 1415 	mov	a,_process_action_sloc0_1_0
      007694 60 11            [24] 1416 	jz	00149$
                                   1417 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      007696 12 79 4F         [24] 1418 	lcall	_ak820_outline_0115
      007699 F5 82            [12] 1419 	mov	dpl,a
      00769B 12 7A 51         [24] 1420 	lcall	_layer_hold_on
                                   1421 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      00769E 12 79 3F         [24] 1422 	lcall	_ak820_outline_0078
      0076A1 12 78 65         [24] 1423 	lcall	_register_mods
      0076A4 02 77 2B         [24] 1424 	ljmp	00181$
      0076A7                       1425 00149$:
                                   1426 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      0076A7 12 79 3F         [24] 1427 	lcall	_ak820_outline_0078
      0076AA 12 78 79         [24] 1428 	lcall	_unregister_mods
                                   1429 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      0076AD 12 79 4F         [24] 1430 	lcall	_ak820_outline_0115
      0076B0 F5 82            [12] 1431 	mov	dpl,a
      0076B2 12 7A 89         [24] 1432 	lcall	_layer_hold_off
                                   1433 ;	quantum/action.c:675: break;
      0076B5 02 77 2B         [24] 1434 	ljmp	00181$
                                   1435 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      0076B8                       1436 00152$:
                                   1437 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      0076B8 12 79 6B         [24] 1438 	lcall	_ak820_outline_0161
      0076BB FF               [12] 1439 	mov	r7,a
      0076BC BF F1 02         [24] 1440 	cjne	r7,#0xf1,00468$
      0076BF 80 0A            [24] 1441 	sjmp	00154$
      0076C1                       1442 00468$:
      0076C1 BF F2 02         [24] 1443 	cjne	r7,#0xf2,00469$
      0076C4 80 19            [24] 1444 	sjmp	00155$
      0076C6                       1445 00469$:
                                   1446 ;	quantum/action.c:694: momentary_layer_action:
      0076C6 BF F3 3B         [24] 1447 	cjne	r7,#0xf3,00160$
      0076C9 80 28            [24] 1448 	sjmp	00156$
      0076CB                       1449 00154$:
                                   1450 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0076CB E5 18            [12] 1451 	mov	a,_process_action_sloc0_1_0
      0076CD 60 08            [24] 1452 	jz	00206$
      0076CF 12 79 25         [24] 1453 	lcall	_ak820_outline_0042
      0076D2 12 7A 51         [24] 1454 	lcall	_layer_hold_on
      0076D5 80 54            [24] 1455 	sjmp	00181$
      0076D7                       1456 00206$:
      0076D7 12 79 25         [24] 1457 	lcall	_ak820_outline_0042
      0076DA 12 7A 89         [24] 1458 	lcall	_layer_hold_off
                                   1459 ;	quantum/action.c:696: break;
                                   1460 ;	quantum/action.c:697: case OP_OFF_ON:
      0076DD 80 4C            [24] 1461 	sjmp	00181$
      0076DF                       1462 00155$:
                                   1463 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0076DF E5 18            [12] 1464 	mov	a,_process_action_sloc0_1_0
      0076E1 60 08            [24] 1465 	jz	00208$
      0076E3 12 79 25         [24] 1466 	lcall	_ak820_outline_0042
      0076E6 12 7B 35         [24] 1467 	lcall	_layer_off
      0076E9 80 40            [24] 1468 	sjmp	00181$
      0076EB                       1469 00208$:
      0076EB 12 79 25         [24] 1470 	lcall	_ak820_outline_0042
      0076EE 12 7B 1A         [24] 1471 	lcall	_layer_on
                                   1472 ;	quantum/action.c:699: break;
                                   1473 ;	quantum/action.c:700: case OP_SET_CLEAR:
      0076F1 80 38            [24] 1474 	sjmp	00181$
      0076F3                       1475 00156$:
                                   1476 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0076F3 E5 18            [12] 1477 	mov	a,_process_action_sloc0_1_0
      0076F5 60 08            [24] 1478 	jz	00210$
      0076F7 12 79 25         [24] 1479 	lcall	_ak820_outline_0042
      0076FA 12 7B 04         [24] 1480 	lcall	_layer_move
      0076FD 80 2C            [24] 1481 	sjmp	00181$
      0076FF                       1482 00210$:
      0076FF 12 7A FE         [24] 1483 	lcall	_layer_clear
                                   1484 ;	quantum/action.c:702: break;
                                   1485 ;	quantum/action.c:748: default:
      007702 80 27            [24] 1486 	sjmp	00181$
      007704                       1487 00160$:
                                   1488 ;	quantum/action.c:755: if (pressed) {
      007704 E5 18            [12] 1489 	mov	a,_process_action_sloc0_1_0
      007706 60 08            [24] 1490 	jz	00163$
                                   1491 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      007708 12 79 3F         [24] 1492 	lcall	_ak820_outline_0078
      00770B 12 77 42         [24] 1493 	lcall	_register_code
                                   1494 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      00770E 80 1B            [24] 1495 	sjmp	00181$
      007710                       1496 00163$:
                                   1497 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      007710 12 79 6B         [24] 1498 	lcall	_ak820_outline_0161
      007713 FF               [12] 1499 	mov	r7,a
      007714 BF 39 0E         [24] 1500 	cjne	r7,#0x39,00175$
                                   1501 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      007717 7F 50            [12] 1502 	mov	r7,#0x50
      007719                       1503 00187$:
      007719 EF               [12] 1504 	mov	a,r7
      00771A 60 09            [24] 1505 	jz	00175$
      00771C 90 00 01         [24] 1506 	mov	dptr,#0x0001
      00771F 12 5B 1A         [24] 1507 	lcall	_mDelaymS
      007722 1F               [12] 1508 	dec	r7
                                   1509 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      007723 80 F4            [24] 1510 	sjmp	00187$
      007725                       1511 00175$:
                                   1512 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      007725 12 79 3F         [24] 1513 	lcall	_ak820_outline_0078
      007728 12 77 AF         [24] 1514 	lcall	_unregister_code
                                   1515 ;	quantum/action.c:848: }
      00772B                       1516 00181$:
                                   1517 ;	quantum/action.c:869: switch (action.kind.id) {
      00772B 90 08 4A         [24] 1518 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00772E E0               [24] 1519 	movx	a,@dptr
      00772F C4               [12] 1520 	swap	a
      007730 54 0F            [12] 1521 	anl	a,#0x0f
      007732 FF               [12] 1522 	mov	r7,a
      007733 BF 08 02         [24] 1523 	cjne	r7,#0x08,00478$
      007736 80 03            [24] 1524 	sjmp	00183$
      007738                       1525 00478$:
      007738 BF 09 06         [24] 1526 	cjne	r7,#0x09,00192$
                                   1527 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      00773B                       1528 00183$:
                                   1529 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      00773B 12 6E A5         [24] 1530 	lcall	_host_keyboard_leds
                                   1531 ;	quantum/action.c:880: }
                                   1532 ;	quantum/action.c:933: }
      00773E 02 99 54         [24] 1533 	ljmp	_led_set
      007741                       1534 00192$:
      007741 22               [24] 1535 	ret
                                   1536 ;------------------------------------------------------------
                                   1537 ;Allocation info for local variables in function 'register_code'
                                   1538 ;------------------------------------------------------------
                                   1539 ;code          Allocated with name '_register_code_code_10000_713'
                                   1540 ;------------------------------------------------------------
                                   1541 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1542 ;	-----------------------------------------
                                   1543 ;	 function register_code
                                   1544 ;	-----------------------------------------
      007742                       1545 _register_code:
      007742 E5 82            [12] 1546 	mov	a,dpl
      007744 90 08 4F         [24] 1547 	mov	dptr,#_register_code_code_10000_713
      007747 F0               [24] 1548 	movx	@dptr,a
                                   1549 ;	quantum/action.c:940: if (code == KC_NO) {
      007748 E0               [24] 1550 	movx	a,@dptr
      007749 FF               [12] 1551 	mov	r7,a
      00774A 70 01            [24] 1552 	jnz	00123$
                                   1553 ;	quantum/action.c:941: return;
      00774C 22               [24] 1554 	ret
      00774D                       1555 00123$:
                                   1556 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      00774D BF 04 00         [24] 1557 	cjne	r7,#0x04,00186$
      007750                       1558 00186$:
      007750 40 12            [24] 1559 	jc	00119$
      007752 EF               [12] 1560 	mov	a,r7
      007753 24 5B            [12] 1561 	add	a,#0xff - 0xa4
      007755 40 0D            [24] 1562 	jc	00119$
                                   1563 ;	free result
                                   1564 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      007757 8F 82            [24] 1565 	mov	dpl, r7
      007759 12 7F 7A         [24] 1566 	lcall	_add_owned_key
      00775C E5 82            [12] 1567 	mov	a, dpl
      00775E 70 01            [24] 1568 	jnz	00104$
      007760 22               [24] 1569 	ret
      007761                       1570 00104$:
                                   1571 ;	quantum/action.c:995: send_keyboard_report();
      007761 02 82 10         [24] 1572 	ljmp	_send_keyboard_report
      007764                       1573 00119$:
                                   1574 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      007764 12 79 70         [24] 1575 	lcall	_ak820_outline_0169
      007767 BF E0 00         [24] 1576 	cjne	r7,#0xe0,00190$
      00776A                       1577 00190$:
      00776A 40 1A            [24] 1578 	jc	00115$
      00776C EF               [12] 1579 	mov	a,r7
      00776D 24 18            [12] 1580 	add	a,#0xff - 0xe7
      00776F 40 15            [24] 1581 	jc	00115$
                                   1582 ;	free result
                                   1583 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      007771 74 07            [12] 1584 	mov	a,#0x07
      007773 5F               [12] 1585 	anl	a,r7
      007774 12 79 2E         [24] 1586 	lcall	_ak820_outline_0061
      007777 80 02            [24] 1587 	sjmp	00194$
      007779                       1588 00193$:
      007779 25 E0            [12] 1589 	add	a,acc
      00777B                       1590 00194$:
      00777B D5 F0 FB         [24] 1591 	djnz	b,00193$
      00777E F5 82            [12] 1592 	mov	dpl,a
      007780 12 7E D6         [24] 1593 	lcall	_add_owned_mods
                                   1594 ;	quantum/action.c:998: send_keyboard_report();
      007783 02 82 10         [24] 1595 	ljmp	_send_keyboard_report
      007786                       1596 00115$:
                                   1597 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007786 12 79 70         [24] 1598 	lcall	_ak820_outline_0169
      007789 BF A5 00         [24] 1599 	cjne	r7,#0xa5,00195$
      00778C                       1600 00195$:
      00778C 40 05            [24] 1601 	jc	00113$
      00778E EF               [12] 1602 	mov	a,r7
      00778F 24 58            [12] 1603 	add	a,#0xff - 0xa7
      007791 50 0D            [24] 1604 	jnc	00108$
                                   1605 ;	free result
      007793                       1606 00113$:
      007793 12 79 70         [24] 1607 	lcall	_ak820_outline_0169
      007796 BF A8 00         [24] 1608 	cjne	r7,#0xa8,00198$
      007799                       1609 00198$:
      007799 40 13            [24] 1610 	jc	00125$
      00779B EF               [12] 1611 	mov	a,r7
      00779C 24 3D            [12] 1612 	add	a,#0xff - 0xc2
      00779E 40 0E            [24] 1613 	jc	00125$
                                   1614 ;	free result
      0077A0                       1615 00108$:
                                   1616 ;	quantum/action.c:1003: owned_usage_key(code, true);
      0077A0 12 79 70         [24] 1617 	lcall	_ak820_outline_0169
      0077A3 90 0A AA         [24] 1618 	mov	dptr,#_owned_usage_key_PARM_2
      0077A6 74 01            [12] 1619 	mov	a,#0x01
      0077A8 F0               [24] 1620 	movx	@dptr,a
      0077A9 8F 82            [24] 1621 	mov	dpl, r7
                                   1622 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1623 ;	quantum/action.c:1013: }
      0077AB 02 80 BB         [24] 1624 	ljmp	_owned_usage_key
      0077AE                       1625 00125$:
      0077AE 22               [24] 1626 	ret
                                   1627 ;------------------------------------------------------------
                                   1628 ;Allocation info for local variables in function 'unregister_code'
                                   1629 ;------------------------------------------------------------
                                   1630 ;code          Allocated with name '_unregister_code_code_10000_727'
                                   1631 ;------------------------------------------------------------
                                   1632 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1633 ;	-----------------------------------------
                                   1634 ;	 function unregister_code
                                   1635 ;	-----------------------------------------
      0077AF                       1636 _unregister_code:
      0077AF E5 82            [12] 1637 	mov	a,dpl
      0077B1 90 08 50         [24] 1638 	mov	dptr,#_unregister_code_code_10000_727
      0077B4 F0               [24] 1639 	movx	@dptr,a
                                   1640 ;	quantum/action.c:1020: if (code == KC_NO) {
      0077B5 E0               [24] 1641 	movx	a,@dptr
      0077B6 FF               [12] 1642 	mov	r7,a
      0077B7 70 01            [24] 1643 	jnz	00121$
                                   1644 ;	quantum/action.c:1021: return;
      0077B9 22               [24] 1645 	ret
      0077BA                       1646 00121$:
                                   1647 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      0077BA BF 04 00         [24] 1648 	cjne	r7,#0x04,00184$
      0077BD                       1649 00184$:
      0077BD 40 12            [24] 1650 	jc	00117$
      0077BF EF               [12] 1651 	mov	a,r7
      0077C0 24 5B            [12] 1652 	add	a,#0xff - 0xa4
      0077C2 40 0D            [24] 1653 	jc	00117$
                                   1654 ;	free result
                                   1655 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      0077C4 8F 82            [24] 1656 	mov	dpl, r7
      0077C6 12 7F F4         [24] 1657 	lcall	_del_owned_key
      0077C9 E5 82            [12] 1658 	mov	a, dpl
      0077CB 70 01            [24] 1659 	jnz	00102$
      0077CD 22               [24] 1660 	ret
      0077CE                       1661 00102$:
                                   1662 ;	quantum/action.c:1062: send_keyboard_report();
      0077CE 02 82 10         [24] 1663 	ljmp	_send_keyboard_report
      0077D1                       1664 00117$:
                                   1665 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      0077D1 12 79 76         [24] 1666 	lcall	_ak820_outline_0170
      0077D4 BF E0 00         [24] 1667 	cjne	r7,#0xe0,00188$
      0077D7                       1668 00188$:
      0077D7 40 1A            [24] 1669 	jc	00113$
      0077D9 EF               [12] 1670 	mov	a,r7
      0077DA 24 18            [12] 1671 	add	a,#0xff - 0xe7
      0077DC 40 15            [24] 1672 	jc	00113$
                                   1673 ;	free result
                                   1674 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      0077DE 74 07            [12] 1675 	mov	a,#0x07
      0077E0 5F               [12] 1676 	anl	a,r7
      0077E1 12 79 2E         [24] 1677 	lcall	_ak820_outline_0061
      0077E4 80 02            [24] 1678 	sjmp	00192$
      0077E6                       1679 00191$:
      0077E6 25 E0            [12] 1680 	add	a,acc
      0077E8                       1681 00192$:
      0077E8 D5 F0 FB         [24] 1682 	djnz	b,00191$
      0077EB F5 82            [12] 1683 	mov	dpl,a
      0077ED 12 7E E6         [24] 1684 	lcall	_del_owned_mods
                                   1685 ;	quantum/action.c:1065: send_keyboard_report();
      0077F0 02 82 10         [24] 1686 	ljmp	_send_keyboard_report
      0077F3                       1687 00113$:
                                   1688 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0077F3 12 79 76         [24] 1689 	lcall	_ak820_outline_0170
      0077F6 BF A5 00         [24] 1690 	cjne	r7,#0xa5,00193$
      0077F9                       1691 00193$:
      0077F9 40 05            [24] 1692 	jc	00111$
      0077FB EF               [12] 1693 	mov	a,r7
      0077FC 24 58            [12] 1694 	add	a,#0xff - 0xa7
      0077FE 50 0D            [24] 1695 	jnc	00106$
                                   1696 ;	free result
      007800                       1697 00111$:
      007800 12 79 76         [24] 1698 	lcall	_ak820_outline_0170
      007803 BF A8 00         [24] 1699 	cjne	r7,#0xa8,00196$
      007806                       1700 00196$:
      007806 40 12            [24] 1701 	jc	00123$
      007808 EF               [12] 1702 	mov	a,r7
      007809 24 3D            [12] 1703 	add	a,#0xff - 0xc2
      00780B 40 0D            [24] 1704 	jc	00123$
                                   1705 ;	free result
      00780D                       1706 00106$:
                                   1707 ;	quantum/action.c:1070: owned_usage_key(code, false);
      00780D 12 79 76         [24] 1708 	lcall	_ak820_outline_0170
      007810 90 0A AA         [24] 1709 	mov	dptr,#_owned_usage_key_PARM_2
      007813 E4               [12] 1710 	clr	a
      007814 F0               [24] 1711 	movx	@dptr,a
      007815 8F 82            [24] 1712 	mov	dpl, r7
                                   1713 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1714 ;	quantum/action.c:1080: }
      007817 02 80 BB         [24] 1715 	ljmp	_owned_usage_key
      00781A                       1716 00123$:
      00781A 22               [24] 1717 	ret
                                   1718 ;------------------------------------------------------------
                                   1719 ;Allocation info for local variables in function 'tap_code_delay'
                                   1720 ;------------------------------------------------------------
                                   1721 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1722 ;code          Allocated with name '_tap_code_delay_code_10000_740'
                                   1723 ;i             Allocated with name '_tap_code_delay_i_20000_742'
                                   1724 ;i             Allocated with name '_tap_code_delay_i_50000_745'
                                   1725 ;------------------------------------------------------------
                                   1726 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1727 ;	-----------------------------------------
                                   1728 ;	 function tap_code_delay
                                   1729 ;	-----------------------------------------
      00781B                       1730 _tap_code_delay:
      00781B E5 82            [12] 1731 	mov	a,dpl
      00781D 90 08 53         [24] 1732 	mov	dptr,#_tap_code_delay_code_10000_740
      007820 F0               [24] 1733 	movx	@dptr,a
                                   1734 ;	quantum/action.c:1088: register_code(code);
      007821 E0               [24] 1735 	movx	a,@dptr
      007822 FF               [12] 1736 	mov	r7,a
      007823 F5 82            [12] 1737 	mov	dpl,a
      007825 C0 07            [24] 1738 	push	ar7
      007827 12 77 42         [24] 1739 	lcall	_register_code
      00782A D0 07            [24] 1740 	pop	ar7
                                   1741 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      00782C 90 08 51         [24] 1742 	mov	dptr,#_tap_code_delay_PARM_2
      00782F 12 38 61         [24] 1743 	lcall	_ak820_outline_0079
      007832                       1744 00110$:
      007832 ED               [12] 1745 	mov	a,r5
      007833 4E               [12] 1746 	orl	a,r6
      007834 60 0D            [24] 1747 	jz	00105$
                                   1748 ;	quantum/action.c:1090: wait_ms(1);
      007836 90 00 01         [24] 1749 	mov	dptr,#0x0001
      007839 12 5B 1A         [24] 1750 	lcall	_mDelaymS
                                   1751 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      00783C 1D               [12] 1752 	dec	r5
      00783D BD FF 01         [24] 1753 	cjne	r5,#0xff,00141$
      007840 1E               [12] 1754 	dec	r6
      007841                       1755 00141$:
      007841 80 EF            [24] 1756 	sjmp	00110$
      007843                       1757 00105$:
                                   1758 ;	quantum/action.c:1092: unregister_code(code);
      007843 8F 82            [24] 1759 	mov	dpl, r7
                                   1760 ;	quantum/action.c:1093: }
      007845 02 77 AF         [24] 1761 	ljmp	_unregister_code
                                   1762 ;------------------------------------------------------------
                                   1763 ;Allocation info for local variables in function 'tap_code'
                                   1764 ;------------------------------------------------------------
                                   1765 ;code          Allocated with name '_tap_code_code_10000_747'
                                   1766 ;------------------------------------------------------------
                                   1767 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1768 ;	-----------------------------------------
                                   1769 ;	 function tap_code
                                   1770 ;	-----------------------------------------
      007848                       1771 _tap_code:
      007848 E5 82            [12] 1772 	mov	a,dpl
      00784A 90 08 54         [24] 1773 	mov	dptr,#_tap_code_code_10000_747
      00784D F0               [24] 1774 	movx	@dptr,a
                                   1775 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      00784E E0               [24] 1776 	movx	a,@dptr
      00784F FF               [12] 1777 	mov	r7,a
      007850 BF 39 04         [24] 1778 	cjne	r7,#0x39,00103$
      007853 7E 50            [12] 1779 	mov	r6,#0x50
      007855 80 02            [24] 1780 	sjmp	00104$
      007857                       1781 00103$:
      007857 7E 00            [12] 1782 	mov	r6,#0x00
      007859                       1783 00104$:
      007859 90 08 51         [24] 1784 	mov	dptr,#_tap_code_delay_PARM_2
      00785C EE               [12] 1785 	mov	a,r6
      00785D 12 38 A6         [24] 1786 	lcall	_ak820_outline_0136
      007860 8F 82            [24] 1787 	mov	dpl, r7
                                   1788 ;	quantum/action.c:1101: }
      007862 02 78 1B         [24] 1789 	ljmp	_tap_code_delay
                                   1790 ;------------------------------------------------------------
                                   1791 ;Allocation info for local variables in function 'register_mods'
                                   1792 ;------------------------------------------------------------
                                   1793 ;mods          Allocated with name '_register_mods_mods_10000_749'
                                   1794 ;------------------------------------------------------------
                                   1795 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1796 ;	-----------------------------------------
                                   1797 ;	 function register_mods
                                   1798 ;	-----------------------------------------
      007865                       1799 _register_mods:
      007865 E5 82            [12] 1800 	mov	a,dpl
      007867 90 08 55         [24] 1801 	mov	dptr,#_register_mods_mods_10000_749
      00786A F0               [24] 1802 	movx	@dptr,a
                                   1803 ;	quantum/action.c:1108: if (mods) {
      00786B E0               [24] 1804 	movx	a,@dptr
      00786C FF               [12] 1805 	mov	r7,a
      00786D E0               [24] 1806 	movx	a,@dptr
      00786E 60 08            [24] 1807 	jz	00103$
                                   1808 ;	quantum/action.c:1109: add_owned_mods(mods);
      007870 8F 82            [24] 1809 	mov	dpl, r7
      007872 12 7E D6         [24] 1810 	lcall	_add_owned_mods
                                   1811 ;	quantum/action.c:1110: send_keyboard_report();
                                   1812 ;	quantum/action.c:1112: }
      007875 02 82 10         [24] 1813 	ljmp	_send_keyboard_report
      007878                       1814 00103$:
      007878 22               [24] 1815 	ret
                                   1816 ;------------------------------------------------------------
                                   1817 ;Allocation info for local variables in function 'unregister_mods'
                                   1818 ;------------------------------------------------------------
                                   1819 ;mods          Allocated with name '_unregister_mods_mods_10000_753'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1822 ;	-----------------------------------------
                                   1823 ;	 function unregister_mods
                                   1824 ;	-----------------------------------------
      007879                       1825 _unregister_mods:
      007879 E5 82            [12] 1826 	mov	a,dpl
      00787B 90 08 56         [24] 1827 	mov	dptr,#_unregister_mods_mods_10000_753
      00787E F0               [24] 1828 	movx	@dptr,a
                                   1829 ;	quantum/action.c:1119: if (mods) {
      00787F E0               [24] 1830 	movx	a,@dptr
      007880 FF               [12] 1831 	mov	r7,a
      007881 E0               [24] 1832 	movx	a,@dptr
      007882 60 08            [24] 1833 	jz	00103$
                                   1834 ;	quantum/action.c:1120: del_owned_mods(mods);
      007884 8F 82            [24] 1835 	mov	dpl, r7
      007886 12 7E E6         [24] 1836 	lcall	_del_owned_mods
                                   1837 ;	quantum/action.c:1121: send_keyboard_report();
                                   1838 ;	quantum/action.c:1123: }
      007889 02 82 10         [24] 1839 	ljmp	_send_keyboard_report
      00788C                       1840 00103$:
      00788C 22               [24] 1841 	ret
                                   1842 ;------------------------------------------------------------
                                   1843 ;Allocation info for local variables in function 'register_weak_mods'
                                   1844 ;------------------------------------------------------------
                                   1845 ;mods          Allocated with name '_register_weak_mods_mods_10000_757'
                                   1846 ;------------------------------------------------------------
                                   1847 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1848 ;	-----------------------------------------
                                   1849 ;	 function register_weak_mods
                                   1850 ;	-----------------------------------------
      00788D                       1851 _register_weak_mods:
      00788D E5 82            [12] 1852 	mov	a,dpl
      00788F 90 08 57         [24] 1853 	mov	dptr,#_register_weak_mods_mods_10000_757
      007892 F0               [24] 1854 	movx	@dptr,a
                                   1855 ;	quantum/action.c:1130: if (mods) {
      007893 E0               [24] 1856 	movx	a,@dptr
      007894 FF               [12] 1857 	mov	r7,a
      007895 E0               [24] 1858 	movx	a,@dptr
      007896 60 08            [24] 1859 	jz	00103$
                                   1860 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      007898 8F 82            [24] 1861 	mov	dpl, r7
      00789A 12 7E F5         [24] 1862 	lcall	_add_owned_weak_mods
                                   1863 ;	quantum/action.c:1132: send_keyboard_report();
                                   1864 ;	quantum/action.c:1134: }
      00789D 02 82 10         [24] 1865 	ljmp	_send_keyboard_report
      0078A0                       1866 00103$:
      0078A0 22               [24] 1867 	ret
                                   1868 ;------------------------------------------------------------
                                   1869 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1870 ;------------------------------------------------------------
                                   1871 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_761'
                                   1872 ;------------------------------------------------------------
                                   1873 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1874 ;	-----------------------------------------
                                   1875 ;	 function unregister_weak_mods
                                   1876 ;	-----------------------------------------
      0078A1                       1877 _unregister_weak_mods:
      0078A1 E5 82            [12] 1878 	mov	a,dpl
      0078A3 90 08 58         [24] 1879 	mov	dptr,#_unregister_weak_mods_mods_10000_761
      0078A6 F0               [24] 1880 	movx	@dptr,a
                                   1881 ;	quantum/action.c:1141: if (mods) {
      0078A7 E0               [24] 1882 	movx	a,@dptr
      0078A8 FF               [12] 1883 	mov	r7,a
      0078A9 E0               [24] 1884 	movx	a,@dptr
      0078AA 60 08            [24] 1885 	jz	00103$
                                   1886 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      0078AC 8F 82            [24] 1887 	mov	dpl, r7
      0078AE 12 7F 05         [24] 1888 	lcall	_del_owned_weak_mods
                                   1889 ;	quantum/action.c:1143: send_keyboard_report();
                                   1890 ;	quantum/action.c:1145: }
      0078B1 02 82 10         [24] 1891 	ljmp	_send_keyboard_report
      0078B4                       1892 00103$:
      0078B4 22               [24] 1893 	ret
                                   1894 ;------------------------------------------------------------
                                   1895 ;Allocation info for local variables in function 'clear_keyboard'
                                   1896 ;------------------------------------------------------------
                                   1897 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   1898 ;	-----------------------------------------
                                   1899 ;	 function clear_keyboard
                                   1900 ;	-----------------------------------------
      0078B5                       1901 _clear_keyboard:
                                   1902 ;	quantum/action.c:1152: clear_mods();
      0078B5 12 82 8B         [24] 1903 	lcall	_clear_mods
                                   1904 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   1905 ;	quantum/action.c:1154: }
      0078B8 02 78 BB         [24] 1906 	ljmp	_clear_keyboard_but_mods
                                   1907 ;------------------------------------------------------------
                                   1908 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1909 ;------------------------------------------------------------
                                   1910 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   1911 ;	-----------------------------------------
                                   1912 ;	 function clear_keyboard_but_mods
                                   1913 ;	-----------------------------------------
      0078BB                       1914 _clear_keyboard_but_mods:
                                   1915 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0078BB 90 0D DD         [24] 1916 	mov	dptr,#_actual_keyboard_report
      0078BE 12 71 6C         [24] 1917 	lcall	_clear_keys_from_report
                                   1918 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   1919 ;	quantum/action.c:1163: }
      0078C1 02 78 C4         [24] 1920 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1921 ;------------------------------------------------------------
                                   1922 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1923 ;------------------------------------------------------------
                                   1924 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   1925 ;	-----------------------------------------
                                   1926 ;	 function clear_keyboard_but_mods_and_keys
                                   1927 ;	-----------------------------------------
      0078C4                       1928 _clear_keyboard_but_mods_and_keys:
                                   1929 ;	quantum/action.c:1171: ak820_tapping_cancel();
      0078C4 12 49 28         [24] 1930 	lcall	_ak820_tapping_cancel
                                   1931 ;	quantum/action.c:1173: ak820_leader_cancel();
      0078C7 12 3B 8D         [24] 1932 	lcall	_ak820_leader_cancel
                                   1933 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      0078CA 12 2E F0         [24] 1934 	lcall	_ak820_oneshot_cancel
                                   1935 ;	quantum/action.c:1185: ak820_combo_cancel();
      0078CD 12 35 70         [24] 1936 	lcall	_ak820_combo_cancel
                                   1937 ;	quantum/action.c:1188: repeat_key_cancel();
      0078D0 12 A3 AB         [24] 1938 	lcall	_repeat_key_cancel
                                   1939 ;	quantum/action.c:1190: clear_owned_mods();
      0078D3 12 7F 15         [24] 1940 	lcall	_clear_owned_mods
                                   1941 ;	quantum/action.c:1191: clear_owned_keys();
      0078D6 12 7F 4D         [24] 1942 	lcall	_clear_owned_keys
                                   1943 ;	quantum/action.c:1192: clear_owned_usages();
      0078D9 12 80 83         [24] 1944 	lcall	_clear_owned_usages
                                   1945 ;	quantum/action.c:1193: layer_hold_clear();
      0078DC 12 7A C1         [24] 1946 	lcall	_layer_hold_clear
                                   1947 ;	quantum/action.c:1195: clear_macro_tri_layer();
      0078DF 12 9E 06         [24] 1948 	lcall	_clear_macro_tri_layer
                                   1949 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0078E2 90 0D DD         [24] 1950 	mov	dptr,#_actual_keyboard_report
      0078E5 12 71 6C         [24] 1951 	lcall	_clear_keys_from_report
                                   1952 ;	quantum/action.c:1200: host_system_send(0);
      0078E8 90 00 00         [24] 1953 	mov	dptr,#0x0000
      0078EB 12 6F 40         [24] 1954 	lcall	_host_system_send
                                   1955 ;	quantum/action.c:1201: host_consumer_send(0);
      0078EE 90 00 00         [24] 1956 	mov	dptr,#0x0000
      0078F1 12 6F 70         [24] 1957 	lcall	_host_consumer_send
                                   1958 ;	quantum/action.c:1203: clear_weak_mods();
      0078F4 12 82 C0         [24] 1959 	lcall	_clear_weak_mods
                                   1960 ;	quantum/action.c:1204: send_keyboard_report();
                                   1961 ;	quantum/action.c:1212: }
      0078F7 02 82 10         [24] 1962 	ljmp	_send_keyboard_report
                                   1963 ;------------------------------------------------------------
                                   1964 ;Allocation info for local variables in function 'is_tap_record'
                                   1965 ;------------------------------------------------------------
                                   1966 ;record        Allocated with name '_is_tap_record_record_10000_777'
                                   1967 ;action        Allocated with name '_is_tap_record_action_10001_781'
                                   1968 ;------------------------------------------------------------
                                   1969 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   1970 ;	-----------------------------------------
                                   1971 	.area CSEG    (CODE)
                                   1972 	.area CONST   (CODE)
                                   1973 	.area XINIT   (CODE)
      00C327                       1974 __xinit__disable_action_cache:
      00C327 00                    1975 	.db #0x00	;  0
                                   1976 	.area CABS    (ABS,CODE)
                                   1977 
                                   1978 ; Experimental exact instruction outlining.
                                   1979 	.globl _ak820_outline_0001
                                   1980 	.globl _ak820_outline_0005
                                   1981 	.globl _ak820_outline_0007
                                   1982 	.globl _ak820_outline_0008
                                   1983 	.globl _ak820_outline_0011
                                   1984 	.globl _ak820_outline_0012
                                   1985 	.globl _ak820_outline_0013
                                   1986 	.globl _ak820_outline_0014
                                   1987 	.globl _ak820_outline_0017
                                   1988 	.globl _ak820_outline_0022
                                   1989 	.globl _ak820_outline_0023
                                   1990 	.globl _ak820_outline_0034
                                   1991 	.globl _ak820_outline_0037
                                   1992 	.globl _ak820_outline_0042
                                   1993 	.globl _ak820_outline_0057
                                   1994 	.globl _ak820_outline_0061
                                   1995 	.globl _ak820_outline_0064
                                   1996 	.globl _ak820_outline_0070
                                   1997 	.globl _ak820_outline_0072
                                   1998 	.globl _ak820_outline_0078
                                   1999 	.globl _ak820_outline_0079
                                   2000 	.globl _ak820_outline_0089
                                   2001 	.globl _ak820_outline_0093
                                   2002 	.globl _ak820_outline_0108
                                   2003 	.globl _ak820_outline_0109
                                   2004 	.globl _ak820_outline_0111
                                   2005 	.globl _ak820_outline_0113
                                   2006 	.globl _ak820_outline_0115
                                   2007 	.globl _ak820_outline_0122
                                   2008 	.globl _ak820_outline_0125
                                   2009 	.globl _ak820_outline_0126
                                   2010 	.globl _ak820_outline_0132
                                   2011 	.globl _ak820_outline_0135
                                   2012 	.globl _ak820_outline_0136
                                   2013 	.globl _ak820_outline_0144
                                   2014 	.globl _ak820_outline_0148
                                   2015 	.globl _ak820_outline_0151
                                   2016 	.globl _ak820_outline_0159
                                   2017 	.globl _ak820_outline_0161
                                   2018 	.globl _ak820_outline_0169
                                   2019 	.globl _ak820_outline_0170
                                   2020 	.globl _ak820_outline_0184
                                   2021 	.globl _ak820_outline_0189
                                   2022 
                                   2023 	.area CSEG (CODE)
                                   2024 ; function ak820_outline_0013
      0078FA                       2025 _ak820_outline_0013:
      0078FA 2D               [12] 2026 	add	a,r5
      0078FB F9               [12] 2027 	mov	r1,a
      0078FC E4               [12] 2028 	clr	a
      0078FD 3E               [12] 2029 	addc	a,r6
      0078FE FA               [12] 2030 	mov	r2,a
      0078FF 8F 03            [24] 2031 	mov	ar3,r7
      007901 89 82            [24] 2032 	mov	dpl,r1
      007903 8A 83            [24] 2033 	mov	dph,r2
      007905 8B F0            [24] 2034 	mov	b,r3
      007907 22               [24] 2035 	ret
                                   2036 
                                   2037 	.area CSEG (CODE)
                                   2038 ; function ak820_outline_0014
      007908                       2039 _ak820_outline_0014:
      007908 2D               [12] 2040 	add	a,r5
      007909 FA               [12] 2041 	mov	r2,a
      00790A E4               [12] 2042 	clr	a
      00790B 3E               [12] 2043 	addc	a,r6
      00790C FB               [12] 2044 	mov	r3,a
      00790D 8F 04            [24] 2045 	mov	ar4,r7
      00790F 8A 82            [24] 2046 	mov	dpl,r2
      007911 8B 83            [24] 2047 	mov	dph,r3
      007913 8C F0            [24] 2048 	mov	b,r4
      007915 22               [24] 2049 	ret
                                   2050 
                                   2051 	.area CSEG (CODE)
                                   2052 ; function ak820_outline_0022
      007916                       2053 _ak820_outline_0022:
      007916 8E 82            [24] 2054 	mov	dpl,r6
      007918 8F 83            [24] 2055 	mov	dph,r7
      00791A A3               [24] 2056 	inc	dptr
      00791B E0               [24] 2057 	movx	a,@dptr
      00791C FC               [12] 2058 	mov	r4,a
      00791D 7D 00            [12] 2059 	mov	r5,#0x00
      00791F 8E 82            [24] 2060 	mov	dpl,r6
      007921 8F 83            [24] 2061 	mov	dph,r7
      007923 E0               [24] 2062 	movx	a,@dptr
      007924 22               [24] 2063 	ret
                                   2064 
                                   2065 	.area CSEG (CODE)
                                   2066 ; function ak820_outline_0042
      007925                       2067 _ak820_outline_0042:
      007925 90 08 4A         [24] 2068 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007928 E0               [24] 2069 	movx	a,@dptr
      007929 54 1F            [12] 2070 	anl	a,#0x1f
      00792B F5 82            [12] 2071 	mov	dpl,a
      00792D 22               [24] 2072 	ret
                                   2073 
                                   2074 	.area CSEG (CODE)
                                   2075 ; function ak820_outline_0061
      00792E                       2076 _ak820_outline_0061:
      00792E F5 F0            [12] 2077 	mov	b,a
      007930 05 F0            [12] 2078 	inc	b
      007932 74 01            [12] 2079 	mov	a,#0x01
      007934 22               [24] 2080 	ret
                                   2081 
                                   2082 	.area CSEG (CODE)
                                   2083 ; function ak820_outline_0070
      007935                       2084 _ak820_outline_0070:
      007935 90 0D BA         [24] 2085 	mov	dptr,#___memcpy_PARM_3
      007938 74 06            [12] 2086 	mov	a,#0x06
      00793A F0               [24] 2087 	movx	@dptr,a
      00793B E4               [12] 2088 	clr	a
      00793C A3               [24] 2089 	inc	dptr
      00793D F0               [24] 2090 	movx	@dptr,a
      00793E 22               [24] 2091 	ret
                                   2092 
                                   2093 	.area CSEG (CODE)
                                   2094 ; function ak820_outline_0078
      00793F                       2095 _ak820_outline_0078:
      00793F 90 08 49         [24] 2096 	mov	dptr,#_process_action_PARM_2
      007942 E0               [24] 2097 	movx	a,@dptr
      007943 F5 82            [12] 2098 	mov	dpl,a
      007945 22               [24] 2099 	ret
                                   2100 
                                   2101 	.area CSEG (CODE)
                                   2102 ; function ak820_outline_0089
      007946                       2103 _ak820_outline_0089:
      007946 90 08 4A         [24] 2104 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007949 E0               [24] 2105 	movx	a,@dptr
      00794A 03               [12] 2106 	rr	a
      00794B 03               [12] 2107 	rr	a
      00794C 54 03            [12] 2108 	anl	a,#0x03
      00794E 22               [24] 2109 	ret
                                   2110 
                                   2111 	.area CSEG (CODE)
                                   2112 ; function ak820_outline_0115
      00794F                       2113 _ak820_outline_0115:
      00794F 90 08 4A         [24] 2114 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007952 E0               [24] 2115 	movx	a,@dptr
      007953 54 0F            [12] 2116 	anl	a,#0x0f
      007955 22               [24] 2117 	ret
                                   2118 
                                   2119 	.area CSEG (CODE)
                                   2120 ; function ak820_outline_0132
      007956                       2121 _ak820_outline_0132:
      007956 90 08 49         [24] 2122 	mov	dptr,#_process_action_PARM_2
      007959 E0               [24] 2123 	movx	a,@dptr
      00795A FE               [12] 2124 	mov	r6,a
      00795B A3               [24] 2125 	inc	dptr
      00795C E0               [24] 2126 	movx	a,@dptr
      00795D 54 03            [12] 2127 	anl	a,#0x03
      00795F FF               [12] 2128 	mov	r7,a
      007960 22               [24] 2129 	ret
                                   2130 
                                   2131 	.area CSEG (CODE)
                                   2132 ; function ak820_outline_0148
      007961                       2133 _ak820_outline_0148:
      007961 74 07            [12] 2134 	mov	a,#0x07
      007963 2D               [12] 2135 	add	a,r5
      007964 F8               [12] 2136 	mov	r0,a
      007965 E4               [12] 2137 	clr	a
      007966 3E               [12] 2138 	addc	a,r6
      007967 F9               [12] 2139 	mov	r1,a
      007968 8F 02            [24] 2140 	mov	ar2,r7
      00796A 22               [24] 2141 	ret
                                   2142 
                                   2143 	.area CSEG (CODE)
                                   2144 ; function ak820_outline_0161
      00796B                       2145 _ak820_outline_0161:
      00796B 90 08 49         [24] 2146 	mov	dptr,#_process_action_PARM_2
      00796E E0               [24] 2147 	movx	a,@dptr
      00796F 22               [24] 2148 	ret
                                   2149 
                                   2150 	.area CSEG (CODE)
                                   2151 ; function ak820_outline_0169
      007970                       2152 _ak820_outline_0169:
      007970 90 08 4F         [24] 2153 	mov	dptr,#_register_code_code_10000_713
      007973 E0               [24] 2154 	movx	a,@dptr
      007974 FF               [12] 2155 	mov	r7,a
      007975 22               [24] 2156 	ret
                                   2157 
                                   2158 	.area CSEG (CODE)
                                   2159 ; function ak820_outline_0170
      007976                       2160 _ak820_outline_0170:
      007976 90 08 50         [24] 2161 	mov	dptr,#_unregister_code_code_10000_727
      007979 E0               [24] 2162 	movx	a,@dptr
      00797A FF               [12] 2163 	mov	r7,a
      00797B 22               [24] 2164 	ret
                                   2165 
                                   2166 	.area CSEG (CODE)
                                   2167 ; function ak820_outline_0189
      00797C                       2168 _ak820_outline_0189:
      00797C F0               [24] 2169 	movx	@dptr,a
      00797D EB               [12] 2170 	mov	a,r3
      00797E A3               [24] 2171 	inc	dptr
      00797F F0               [24] 2172 	movx	@dptr,a
      007980 22               [24] 2173 	ret
