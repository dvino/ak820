                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_layer
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_macro_change
                                     12 	.globl _ak820_tri_layer_derived
                                     13 	.globl _ak820_keycode_at
                                     14 	.globl _action_for_keycode
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _layer_state
                                    259 	.globl _default_layer_state
                                    260 	.globl _ak820_resolve_key_PARM_2
                                    261 	.globl _ak820_cache_layer_PARM_2
                                    262 	.globl _ak820_cache_keycode_PARM_2
                                    263 	.globl _default_layer_state_set_user
                                    264 	.globl _default_layer_state_set_kb
                                    265 	.globl _default_layer_set
                                    266 	.globl _default_layer_or
                                    267 	.globl _default_layer_and
                                    268 	.globl _default_layer_xor
                                    269 	.globl _ak820_layer_refresh
                                    270 	.globl _layer_hold_on
                                    271 	.globl _layer_hold_off
                                    272 	.globl _layer_hold_clear
                                    273 	.globl _layer_state_set_user
                                    274 	.globl _layer_state_set_kb
                                    275 	.globl _layer_state_set
                                    276 	.globl _layer_clear
                                    277 	.globl _layer_move
                                    278 	.globl _layer_on
                                    279 	.globl _layer_off
                                    280 	.globl _layer_or
                                    281 	.globl _layer_and
                                    282 	.globl _layer_xor
                                    283 	.globl _ak820_cache_keycode
                                    284 	.globl _ak820_cache_layer
                                    285 	.globl _ak820_cached_key
                                    286 	.globl _ak820_resolve_key
                                    287 	.globl _ak820_layer_for_key
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
                                    550 ;--------------------------------------------------------
                                    551 ; overlayable items in internal ram
                                    552 ;--------------------------------------------------------
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
                                    566 ;--------------------------------------------------------
                                    567 ; paged external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area PSEG    (PAG,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; uninitialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XSEG    (XDATA)
      000859                        574 _default_layer_state_set_user_state_10000_317:
      000859                        575 	.ds 1
      00085A                        576 _default_layer_state_set_kb_state_10000_319:
      00085A                        577 	.ds 1
      00085B                        578 _default_layer_state_set_state_10000_321:
      00085B                        579 	.ds 1
      00085C                        580 _default_layer_set_state_10000_326:
      00085C                        581 	.ds 1
      00085D                        582 _default_layer_or_state_10000_328:
      00085D                        583 	.ds 1
      00085E                        584 _default_layer_and_state_10000_330:
      00085E                        585 	.ds 1
      00085F                        586 _default_layer_xor_state_10000_332:
      00085F                        587 	.ds 1
      000860                        588 _persistent_layers:
      000860                        589 	.ds 1
      000861                        590 _layer_refs:
      000861                        591 	.ds 6
      000867                        592 _macro_layers:
      000867                        593 	.ds 1
      000868                        594 _ak820_layer_refresh_state_10000_335:
      000868                        595 	.ds 1
      000869                        596 _layer_hold_on_layer_10000_338:
      000869                        597 	.ds 1
      00086A                        598 _layer_hold_off_layer_10000_342:
      00086A                        599 	.ds 1
      00086B                        600 _layer_state_set_user_state_10000_349:
      00086B                        601 	.ds 1
      00086C                        602 _layer_state_set_kb_state_10000_351:
      00086C                        603 	.ds 1
      00086D                        604 _layer_state_set_state_10000_353:
      00086D                        605 	.ds 1
      00086E                        606 _layer_move_layer_10000_366:
      00086E                        607 	.ds 1
      00086F                        608 _layer_on_layer_10000_368:
      00086F                        609 	.ds 1
      000870                        610 _layer_off_layer_10000_370:
      000870                        611 	.ds 1
      000871                        612 _layer_or_state_10000_374:
      000871                        613 	.ds 1
      000872                        614 _layer_and_state_10000_376:
      000872                        615 	.ds 1
      000873                        616 _layer_xor_state_10000_378:
      000873                        617 	.ds 1
      000874                        618 _source_keycodes_cache:
      000874                        619 	.ds 256
      000974                        620 _encoder_source_keycodes_cache:
      000974                        621 	.ds 4
      000978                        622 _source_keycode_cache_slot_position_10000_380:
      000978                        623 	.ds 2
      00097A                        624 _ak820_cache_keycode_PARM_2:
      00097A                        625 	.ds 2
      00097C                        626 _ak820_cache_keycode_position_10000_386:
      00097C                        627 	.ds 2
      00097E                        628 _ak820_cache_layer_PARM_2:
      00097E                        629 	.ds 1
      00097F                        630 _ak820_cache_layer_position_10000_389:
      00097F                        631 	.ds 2
      000981                        632 _ak820_cached_key_position_10000_392:
      000981                        633 	.ds 2
      000983                        634 _ak820_resolve_key_PARM_2:
      000983                        635 	.ds 1
      000984                        636 _ak820_resolve_key_position_10000_403:
      000984                        637 	.ds 2
      000986                        638 _ak820_layer_for_key_position_10000_410:
      000986                        639 	.ds 2
      000988                        640 _ak820_layer_for_key_layers_10000_411:
      000988                        641 	.ds 1
                                    642 ;--------------------------------------------------------
                                    643 ; absolute external ram data
                                    644 ;--------------------------------------------------------
                                    645 	.area XABS    (ABS,XDATA)
                                    646 ;--------------------------------------------------------
                                    647 ; initialized external ram data
                                    648 ;--------------------------------------------------------
                                    649 	.area XISEG   (XDATA)
      000DD9                        650 _default_layer_state::
      000DD9                        651 	.ds 1
      000DDA                        652 _layer_state::
      000DDA                        653 	.ds 1
                                    654 	.area HOME    (CODE)
                                    655 	.area GSINIT0 (CODE)
                                    656 	.area GSINIT1 (CODE)
                                    657 	.area GSINIT2 (CODE)
                                    658 	.area GSINIT3 (CODE)
                                    659 	.area GSINIT4 (CODE)
                                    660 	.area GSINIT5 (CODE)
                                    661 	.area GSINIT  (CODE)
                                    662 	.area GSFINAL (CODE)
                                    663 	.area CSEG    (CODE)
                                    664 ;--------------------------------------------------------
                                    665 ; global & static initialisations
                                    666 ;--------------------------------------------------------
                                    667 	.area HOME    (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area GSINIT  (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; Home
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area HOME    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; code
                                    678 ;--------------------------------------------------------
                                    679 	.area CSEG    (CODE)
                                    680 ;------------------------------------------------------------
                                    681 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    682 ;------------------------------------------------------------
                                    683 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_190'
                                    684 ;------------------------------------------------------------
                                    685 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    686 ;	-----------------------------------------
                           000007   687 	ar7 = 0x07
                           000006   688 	ar6 = 0x06
                           000005   689 	ar5 = 0x05
                           000004   690 	ar4 = 0x04
                           000003   691 	ar3 = 0x03
                           000002   692 	ar2 = 0x02
                           000001   693 	ar1 = 0x01
                           000000   694 	ar0 = 0x00
                                    695 ;	 function default_layer_state_set_user
                                    696 ;	-----------------------------------------
      007981                        697 _default_layer_state_set_user:
      007981 E5 82            [12]  698 	mov	a,dpl
      007983 90 08 59         [24]  699 	mov	dptr,#_default_layer_state_set_user_state_10000_317
      007986 12 59 77         [24]  700 	lcall	_ak820_outline_0172
                                    701 ;	quantum/action_layer.c:32: return state;
                                    702 ;	quantum/action_layer.c:33: }
      007989 22               [24]  703 	ret
                                    704 ;------------------------------------------------------------
                                    705 ;Allocation info for local variables in function 'default_layer_state_set_kb'
                                    706 ;------------------------------------------------------------
                                    707 ;state         Allocated with name '_default_layer_state_set_kb_state_10000_319'
                                    708 ;------------------------------------------------------------
                                    709 ;	quantum/action_layer.c:39: __attribute__((weak)) layer_state_t default_layer_state_set_kb(layer_state_t state) {
                                    710 ;	-----------------------------------------
                                    711 ;	 function default_layer_state_set_kb
                                    712 ;	-----------------------------------------
      00798A                        713 _default_layer_state_set_kb:
      00798A E5 82            [12]  714 	mov	a,dpl
      00798C 90 08 5A         [24]  715 	mov	dptr,#_default_layer_state_set_kb_state_10000_319
      00798F 12 59 77         [24]  716 	lcall	_ak820_outline_0172
                                    717 ;	quantum/action_layer.c:40: return default_layer_state_set_user(state);
                                    718 ;	quantum/action_layer.c:41: }
      007992 02 79 81         [24]  719 	ljmp	_default_layer_state_set_user
                                    720 ;------------------------------------------------------------
                                    721 ;Allocation info for local variables in function 'default_layer_state_set'
                                    722 ;------------------------------------------------------------
                                    723 ;state         Allocated with name '_default_layer_state_set_state_10000_321'
                                    724 ;------------------------------------------------------------
                                    725 ;	quantum/action_layer.c:47: static void default_layer_state_set(layer_state_t state) {
                                    726 ;	-----------------------------------------
                                    727 ;	 function default_layer_state_set
                                    728 ;	-----------------------------------------
      007995                        729 _default_layer_state_set:
      007995 E5 82            [12]  730 	mov	a,dpl
      007997 90 08 5B         [24]  731 	mov	dptr,#_default_layer_state_set_state_10000_321
      00799A 12 59 77         [24]  732 	lcall	_ak820_outline_0172
                                    733 ;	quantum/action_layer.c:48: state = default_layer_state_set_kb(state);
      00799D 12 79 8A         [24]  734 	lcall	_default_layer_state_set_kb
      0079A0 AF 82            [24]  735 	mov	r7, dpl
      0079A2 90 08 5B         [24]  736 	mov	dptr,#_default_layer_state_set_state_10000_321
      0079A5 EF               [12]  737 	mov	a,r7
      0079A6 F0               [24]  738 	movx	@dptr,a
                                    739 ;	quantum/action_layer.c:52: default_layer_state = state;
      0079A7 90 0D D9         [24]  740 	mov	dptr,#_default_layer_state
      0079AA EF               [12]  741 	mov	a,r7
      0079AB F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action_layer.c:54: ak820_layer_refresh();
                                    744 ;	quantum/action_layer.c:57: ac_dprintf("\n");
                                    745 ;	quantum/action_layer.c:63: }
      0079AC 02 79 F4         [24]  746 	ljmp	_ak820_layer_refresh
                                    747 ;------------------------------------------------------------
                                    748 ;Allocation info for local variables in function 'default_layer_set'
                                    749 ;------------------------------------------------------------
                                    750 ;state         Allocated with name '_default_layer_set_state_10000_326'
                                    751 ;------------------------------------------------------------
                                    752 ;	quantum/action_layer.c:79: void default_layer_set(layer_state_t state) {
                                    753 ;	-----------------------------------------
                                    754 ;	 function default_layer_set
                                    755 ;	-----------------------------------------
      0079AF                        756 _default_layer_set:
      0079AF E5 82            [12]  757 	mov	a,dpl
      0079B1 90 08 5C         [24]  758 	mov	dptr,#_default_layer_set_state_10000_326
      0079B4 12 59 77         [24]  759 	lcall	_ak820_outline_0172
                                    760 ;	quantum/action_layer.c:80: default_layer_state_set(state);
                                    761 ;	quantum/action_layer.c:81: }
      0079B7 02 79 95         [24]  762 	ljmp	_default_layer_state_set
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'default_layer_or'
                                    765 ;------------------------------------------------------------
                                    766 ;state         Allocated with name '_default_layer_or_state_10000_328'
                                    767 ;------------------------------------------------------------
                                    768 ;	quantum/action_layer.c:88: void default_layer_or(layer_state_t state) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function default_layer_or
                                    771 ;	-----------------------------------------
      0079BA                        772 _default_layer_or:
      0079BA E5 82            [12]  773 	mov	a,dpl
      0079BC 90 08 5D         [24]  774 	mov	dptr,#_default_layer_or_state_10000_328
      0079BF F0               [24]  775 	movx	@dptr,a
                                    776 ;	quantum/action_layer.c:89: default_layer_state_set(default_layer_state | state);
      0079C0 E0               [24]  777 	movx	a,@dptr
      0079C1 FF               [12]  778 	mov	r7,a
      0079C2 90 0D D9         [24]  779 	mov	dptr,#_default_layer_state
      0079C5 12 7D 86         [24]  780 	lcall	_ak820_outline_0143
                                    781 ;	quantum/action_layer.c:90: }
      0079C8 02 79 95         [24]  782 	ljmp	_default_layer_state_set
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'default_layer_and'
                                    785 ;------------------------------------------------------------
                                    786 ;state         Allocated with name '_default_layer_and_state_10000_330'
                                    787 ;------------------------------------------------------------
                                    788 ;	quantum/action_layer.c:95: void default_layer_and(layer_state_t state) {
                                    789 ;	-----------------------------------------
                                    790 ;	 function default_layer_and
                                    791 ;	-----------------------------------------
      0079CB                        792 _default_layer_and:
      0079CB E5 82            [12]  793 	mov	a,dpl
      0079CD 90 08 5E         [24]  794 	mov	dptr,#_default_layer_and_state_10000_330
      0079D0 F0               [24]  795 	movx	@dptr,a
                                    796 ;	quantum/action_layer.c:96: default_layer_state_set(default_layer_state & state);
      0079D1 90 0D D9         [24]  797 	mov	dptr,#_default_layer_state
      0079D4 E0               [24]  798 	movx	a,@dptr
      0079D5 FF               [12]  799 	mov	r7,a
      0079D6 90 08 5E         [24]  800 	mov	dptr,#_default_layer_and_state_10000_330
      0079D9 E0               [24]  801 	movx	a,@dptr
      0079DA 52 07            [12]  802 	anl	ar7,a
      0079DC 8F 82            [24]  803 	mov	dpl, r7
                                    804 ;	quantum/action_layer.c:97: }
      0079DE 02 79 95         [24]  805 	ljmp	_default_layer_state_set
                                    806 ;------------------------------------------------------------
                                    807 ;Allocation info for local variables in function 'default_layer_xor'
                                    808 ;------------------------------------------------------------
                                    809 ;state         Allocated with name '_default_layer_xor_state_10000_332'
                                    810 ;------------------------------------------------------------
                                    811 ;	quantum/action_layer.c:102: void default_layer_xor(layer_state_t state) {
                                    812 ;	-----------------------------------------
                                    813 ;	 function default_layer_xor
                                    814 ;	-----------------------------------------
      0079E1                        815 _default_layer_xor:
      0079E1 E5 82            [12]  816 	mov	a,dpl
      0079E3 90 08 5F         [24]  817 	mov	dptr,#_default_layer_xor_state_10000_332
      0079E6 F0               [24]  818 	movx	@dptr,a
                                    819 ;	quantum/action_layer.c:103: default_layer_state_set(default_layer_state ^ state);
      0079E7 E0               [24]  820 	movx	a,@dptr
      0079E8 FF               [12]  821 	mov	r7,a
      0079E9 90 0D D9         [24]  822 	mov	dptr,#_default_layer_state
      0079EC E0               [24]  823 	movx	a,@dptr
      0079ED 62 07            [12]  824 	xrl	ar7,a
      0079EF 8F 82            [24]  825 	mov	dpl, r7
                                    826 ;	quantum/action_layer.c:104: }
      0079F1 02 79 95         [24]  827 	ljmp	_default_layer_state_set
                                    828 ;------------------------------------------------------------
                                    829 ;Allocation info for local variables in function 'ak820_layer_refresh'
                                    830 ;------------------------------------------------------------
                                    831 ;state         Allocated with name '_ak820_layer_refresh_state_10000_335'
                                    832 ;i             Allocated with name '_ak820_layer_refresh_i_20000_336'
                                    833 ;------------------------------------------------------------
                                    834 ;	quantum/action_layer.c:114: void ak820_layer_refresh(void) {
                                    835 ;	-----------------------------------------
                                    836 ;	 function ak820_layer_refresh
                                    837 ;	-----------------------------------------
      0079F4                        838 _ak820_layer_refresh:
                                    839 ;	quantum/action_layer.c:115: layer_state_t state = persistent_layers;
      0079F4 90 08 60         [24]  840 	mov	dptr,#_persistent_layers
      0079F7 E0               [24]  841 	movx	a,@dptr
      0079F8 90 08 68         [24]  842 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      0079FB F0               [24]  843 	movx	@dptr,a
                                    844 ;	quantum/action_layer.c:116: for (uint8_t i = 0; i < MAX_LAYER; ++i) if (layer_refs[i]) state |= (layer_state_t)1 << i;
      0079FC 7F 00            [12]  845 	mov	r7,#0x00
      0079FE                        846 00105$:
      0079FE BF 06 00         [24]  847 	cjne	r7,#0x06,00131$
      007A01                        848 00131$:
      007A01 50 25            [24]  849 	jnc	00103$
      007A03 EF               [12]  850 	mov	a,r7
      007A04 24 61            [12]  851 	add	a, #_layer_refs
      007A06 FD               [12]  852 	mov	r5,a
      007A07 E4               [12]  853 	clr	a
      007A08 34 08            [12]  854 	addc	a, #(_layer_refs >> 8)
      007A0A FE               [12]  855 	mov	r6,a
      007A0B 12 38 AB         [24]  856 	lcall	_ak820_outline_0137
      007A0E E0               [24]  857 	movx	a,@dptr
      007A0F 60 14            [24]  858 	jz	00106$
      007A11 8F F0            [24]  859 	mov	b,r7
      007A13 05 F0            [12]  860 	inc	b
      007A15 74 01            [12]  861 	mov	a,#0x01
      007A17 80 02            [24]  862 	sjmp	00135$
      007A19                        863 00134$:
      007A19 25 E0            [12]  864 	add	a,acc
      007A1B                        865 00135$:
      007A1B D5 F0 FB         [24]  866 	djnz	b,00134$
      007A1E FE               [12]  867 	mov	r6,a
      007A1F 90 08 68         [24]  868 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007A22 E0               [24]  869 	movx	a,@dptr
      007A23 4E               [12]  870 	orl	a,r6
      007A24 F0               [24]  871 	movx	@dptr,a
      007A25                        872 00106$:
      007A25 0F               [12]  873 	inc	r7
      007A26 80 D6            [24]  874 	sjmp	00105$
      007A28                        875 00103$:
                                    876 ;	quantum/action_layer.c:118: state |= ak820_tri_layer_derived(state | default_layer_state);
      007A28 90 0D D9         [24]  877 	mov	dptr,#_default_layer_state
      007A2B E0               [24]  878 	movx	a,@dptr
      007A2C FF               [12]  879 	mov	r7,a
      007A2D 90 08 68         [24]  880 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007A30 E0               [24]  881 	movx	a,@dptr
      007A31 FE               [12]  882 	mov	r6,a
      007A32 42 07            [12]  883 	orl	ar7,a
      007A34 8F 82            [24]  884 	mov	dpl, r7
      007A36 C0 06            [24]  885 	push	ar6
      007A38 12 A7 90         [24]  886 	lcall	_ak820_tri_layer_derived
      007A3B AF 82            [24]  887 	mov	r7, dpl
      007A3D D0 06            [24]  888 	pop	ar6
      007A3F 90 08 68         [24]  889 	mov	dptr,#_ak820_layer_refresh_state_10000_335
      007A42 EF               [12]  890 	mov	a,r7
      007A43 4E               [12]  891 	orl	a,r6
      007A44 12 59 77         [24]  892 	lcall	_ak820_outline_0172
                                    893 ;	quantum/action_layer.c:120: layer_state = layer_state_set_kb(state);
      007A47 12 7A E5         [24]  894 	lcall	_layer_state_set_kb
      007A4A E5 82            [12]  895 	mov	a, dpl
      007A4C 90 0D DA         [24]  896 	mov	dptr,#_layer_state
      007A4F F0               [24]  897 	movx	@dptr,a
                                    898 ;	quantum/action_layer.c:121: }
      007A50 22               [24]  899 	ret
                                    900 ;------------------------------------------------------------
                                    901 ;Allocation info for local variables in function 'layer_hold_on'
                                    902 ;------------------------------------------------------------
                                    903 ;layer         Allocated with name '_layer_hold_on_layer_10000_338'
                                    904 ;------------------------------------------------------------
                                    905 ;	quantum/action_layer.c:122: void layer_hold_on(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, true)) { ++layer_refs[layer]; ak820_layer_refresh(); } }
                                    906 ;	-----------------------------------------
                                    907 ;	 function layer_hold_on
                                    908 ;	-----------------------------------------
      007A51                        909 _layer_hold_on:
      007A51 E5 82            [12]  910 	mov	a,dpl
      007A53 90 08 69         [24]  911 	mov	dptr,#_layer_hold_on_layer_10000_338
      007A56 F0               [24]  912 	movx	@dptr,a
      007A57 E0               [24]  913 	movx	a,@dptr
      007A58 FF               [12]  914 	mov	r7,a
      007A59 BF 06 00         [24]  915 	cjne	r7,#0x06,00120$
      007A5C                        916 00120$:
      007A5C 50 2A            [24]  917 	jnc	00104$
      007A5E 12 7D 92         [24]  918 	lcall	_ak820_outline_0178
      007A61 74 01            [12]  919 	mov	a,#0x01
      007A63 F0               [24]  920 	movx	@dptr,a
      007A64 90 08 67         [24]  921 	mov	dptr,#_macro_layers
      007A67 C0 07            [24]  922 	push	ar7
      007A69 12 7D 9B         [24]  923 	lcall	_ak820_macro_change
      007A6C E5 82            [12]  924 	mov	a, dpl
      007A6E D0 07            [24]  925 	pop	ar7
      007A70 60 16            [24]  926 	jz	00104$
      007A72 EF               [12]  927 	mov	a,r7
      007A73 24 61            [12]  928 	add	a, #_layer_refs
      007A75 FF               [12]  929 	mov	r7,a
      007A76 E4               [12]  930 	clr	a
      007A77 34 08            [12]  931 	addc	a, #(_layer_refs >> 8)
      007A79 FE               [12]  932 	mov	r6,a
      007A7A 12 45 CE         [24]  933 	lcall	_ak820_outline_0160
      007A7D E0               [24]  934 	movx	a,@dptr
      007A7E FD               [12]  935 	mov	r5,a
      007A7F 0D               [12]  936 	inc	r5
      007A80 12 45 CE         [24]  937 	lcall	_ak820_outline_0160
      007A83 ED               [12]  938 	mov	a,r5
      007A84 F0               [24]  939 	movx	@dptr,a
      007A85 02 79 F4         [24]  940 	ljmp	_ak820_layer_refresh
      007A88                        941 00104$:
      007A88 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'layer_hold_off'
                                    945 ;------------------------------------------------------------
                                    946 ;layer         Allocated with name '_layer_hold_off_layer_10000_342'
                                    947 ;------------------------------------------------------------
                                    948 ;	quantum/action_layer.c:123: void layer_hold_off(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, false) && layer_refs[layer]) { --layer_refs[layer]; ak820_layer_refresh(); } }
                                    949 ;	-----------------------------------------
                                    950 ;	 function layer_hold_off
                                    951 ;	-----------------------------------------
      007A89                        952 _layer_hold_off:
      007A89 E5 82            [12]  953 	mov	a,dpl
      007A8B 90 08 6A         [24]  954 	mov	dptr,#_layer_hold_off_layer_10000_342
      007A8E F0               [24]  955 	movx	@dptr,a
      007A8F E0               [24]  956 	movx	a,@dptr
      007A90 FF               [12]  957 	mov	r7,a
      007A91 BF 06 00         [24]  958 	cjne	r7,#0x06,00128$
      007A94                        959 00128$:
      007A94 50 2A            [24]  960 	jnc	00105$
      007A96 12 7D 92         [24]  961 	lcall	_ak820_outline_0178
      007A99 E4               [12]  962 	clr	a
      007A9A F0               [24]  963 	movx	@dptr,a
      007A9B 90 08 67         [24]  964 	mov	dptr,#_macro_layers
      007A9E C0 07            [24]  965 	push	ar7
      007AA0 12 7D 9B         [24]  966 	lcall	_ak820_macro_change
      007AA3 E5 82            [12]  967 	mov	a, dpl
      007AA5 D0 07            [24]  968 	pop	ar7
      007AA7 60 17            [24]  969 	jz	00105$
      007AA9 EF               [12]  970 	mov	a,r7
      007AAA 24 61            [12]  971 	add	a, #_layer_refs
      007AAC FE               [12]  972 	mov	r6,a
      007AAD E4               [12]  973 	clr	a
      007AAE 34 08            [12]  974 	addc	a, #(_layer_refs >> 8)
      007AB0 FF               [12]  975 	mov	r7,a
      007AB1 12 38 73         [24]  976 	lcall	_ak820_outline_0100
      007AB4 FD               [12]  977 	mov	r5,a
      007AB5 60 09            [24]  978 	jz	00105$
      007AB7 1D               [12]  979 	dec	r5
      007AB8 12 38 96         [24]  980 	lcall	_ak820_outline_0122
      007ABB ED               [12]  981 	mov	a,r5
      007ABC F0               [24]  982 	movx	@dptr,a
      007ABD 02 79 F4         [24]  983 	ljmp	_ak820_layer_refresh
      007AC0                        984 00105$:
      007AC0 22               [24]  985 	ret
                                    986 ;------------------------------------------------------------
                                    987 ;Allocation info for local variables in function 'layer_hold_clear'
                                    988 ;------------------------------------------------------------
                                    989 ;i             Allocated with name '_layer_hold_clear_i_20000_348'
                                    990 ;------------------------------------------------------------
                                    991 ;	quantum/action_layer.c:124: void layer_hold_clear(void) { macro_layers = 0; for (uint8_t i = 0; i < MAX_LAYER; ++i) layer_refs[i] = 0; ak820_layer_refresh(); }
                                    992 ;	-----------------------------------------
                                    993 ;	 function layer_hold_clear
                                    994 ;	-----------------------------------------
      007AC1                        995 _layer_hold_clear:
      007AC1 90 08 67         [24]  996 	mov	dptr,#_macro_layers
      007AC4 E4               [12]  997 	clr	a
      007AC5 F0               [24]  998 	movx	@dptr,a
      007AC6 FF               [12]  999 	mov	r7,a
      007AC7                       1000 00103$:
      007AC7 BF 06 00         [24] 1001 	cjne	r7,#0x06,00122$
      007ACA                       1002 00122$:
      007ACA 50 0D            [24] 1003 	jnc	00101$
      007ACC EF               [12] 1004 	mov	a,r7
      007ACD 24 61            [12] 1005 	add	a, #_layer_refs
      007ACF F5 82            [12] 1006 	mov	dpl,a
      007AD1 E4               [12] 1007 	clr	a
      007AD2 34 08            [12] 1008 	addc	a, #(_layer_refs >> 8)
      007AD4 12 7D 8C         [24] 1009 	lcall	_ak820_outline_0165
      007AD7 80 EE            [24] 1010 	sjmp	00103$
      007AD9                       1011 00101$:
      007AD9 02 79 F4         [24] 1012 	ljmp	_ak820_layer_refresh
                                   1013 ;------------------------------------------------------------
                                   1014 ;Allocation info for local variables in function 'layer_state_set_user'
                                   1015 ;------------------------------------------------------------
                                   1016 ;state         Allocated with name '_layer_state_set_user_state_10000_349'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/action_layer.c:131: __attribute__((weak)) layer_state_t layer_state_set_user(layer_state_t state) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function layer_state_set_user
                                   1021 ;	-----------------------------------------
      007ADC                       1022 _layer_state_set_user:
      007ADC E5 82            [12] 1023 	mov	a,dpl
      007ADE 90 08 6B         [24] 1024 	mov	dptr,#_layer_state_set_user_state_10000_349
      007AE1 12 59 77         [24] 1025 	lcall	_ak820_outline_0172
                                   1026 ;	quantum/action_layer.c:132: return state;
                                   1027 ;	quantum/action_layer.c:133: }
      007AE4 22               [24] 1028 	ret
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'layer_state_set_kb'
                                   1031 ;------------------------------------------------------------
                                   1032 ;state         Allocated with name '_layer_state_set_kb_state_10000_351'
                                   1033 ;------------------------------------------------------------
                                   1034 ;	quantum/action_layer.c:139: __attribute__((weak)) layer_state_t layer_state_set_kb(layer_state_t state) {
                                   1035 ;	-----------------------------------------
                                   1036 ;	 function layer_state_set_kb
                                   1037 ;	-----------------------------------------
      007AE5                       1038 _layer_state_set_kb:
      007AE5 E5 82            [12] 1039 	mov	a,dpl
      007AE7 90 08 6C         [24] 1040 	mov	dptr,#_layer_state_set_kb_state_10000_351
      007AEA 12 59 77         [24] 1041 	lcall	_ak820_outline_0172
                                   1042 ;	quantum/action_layer.c:140: return layer_state_set_user(state);
                                   1043 ;	quantum/action_layer.c:141: }
      007AED 02 7A DC         [24] 1044 	ljmp	_layer_state_set_user
                                   1045 ;------------------------------------------------------------
                                   1046 ;Allocation info for local variables in function 'layer_state_set'
                                   1047 ;------------------------------------------------------------
                                   1048 ;state         Allocated with name '_layer_state_set_state_10000_353'
                                   1049 ;------------------------------------------------------------
                                   1050 ;	quantum/action_layer.c:147: void layer_state_set(layer_state_t state) {
                                   1051 ;	-----------------------------------------
                                   1052 ;	 function layer_state_set
                                   1053 ;	-----------------------------------------
      007AF0                       1054 _layer_state_set:
      007AF0 E5 82            [12] 1055 	mov	a,dpl
      007AF2 90 08 6D         [24] 1056 	mov	dptr,#_layer_state_set_state_10000_353
      007AF5 F0               [24] 1057 	movx	@dptr,a
                                   1058 ;	quantum/action_layer.c:149: persistent_layers = state;
      007AF6 E0               [24] 1059 	movx	a,@dptr
      007AF7 90 08 60         [24] 1060 	mov	dptr,#_persistent_layers
      007AFA F0               [24] 1061 	movx	@dptr,a
                                   1062 ;	quantum/action_layer.c:150: ak820_layer_refresh();
                                   1063 ;	quantum/action_layer.c:151: return;
                                   1064 ;	quantum/action_layer.c:159: ac_dprintf("\n");
                                   1065 ;	quantum/action_layer.c:165: }
      007AFB 02 79 F4         [24] 1066 	ljmp	_ak820_layer_refresh
                                   1067 ;------------------------------------------------------------
                                   1068 ;Allocation info for local variables in function 'layer_clear'
                                   1069 ;------------------------------------------------------------
                                   1070 ;	quantum/action_layer.c:171: void layer_clear(void) {
                                   1071 ;	-----------------------------------------
                                   1072 ;	 function layer_clear
                                   1073 ;	-----------------------------------------
      007AFE                       1074 _layer_clear:
                                   1075 ;	quantum/action_layer.c:172: layer_state_set(0);
      007AFE 75 82 00         [24] 1076 	mov	dpl, #0x00
                                   1077 ;	quantum/action_layer.c:173: }
      007B01 02 7A F0         [24] 1078 	ljmp	_layer_state_set
                                   1079 ;------------------------------------------------------------
                                   1080 ;Allocation info for local variables in function 'layer_state_is'
                                   1081 ;------------------------------------------------------------
                                   1082 ;layer         Allocated with name '_layer_state_is_layer_10000_360'
                                   1083 ;------------------------------------------------------------
                                   1084 ;	quantum/action_layer.c:179: bool layer_state_is(uint8_t layer) {
                                   1085 ;	-----------------------------------------
                                   1086 ;	 function layer_move
                                   1087 ;	-----------------------------------------
      007B04                       1088 _layer_move:
      007B04 E5 82            [12] 1089 	mov	a,dpl
      007B06 90 08 6E         [24] 1090 	mov	dptr,#_layer_move_layer_10000_366
      007B09 F0               [24] 1091 	movx	@dptr,a
                                   1092 ;	quantum/action_layer.c:199: layer_state_set((layer_state_t)1 << layer);
      007B0A E0               [24] 1093 	movx	a,@dptr
      007B0B 12 79 2E         [24] 1094 	lcall	_ak820_outline_0061
      007B0E 80 02            [24] 1095 	sjmp	00104$
      007B10                       1096 00103$:
      007B10 25 E0            [12] 1097 	add	a,acc
      007B12                       1098 00104$:
      007B12 D5 F0 FB         [24] 1099 	djnz	b,00103$
      007B15 F5 82            [12] 1100 	mov	dpl,a
                                   1101 ;	quantum/action_layer.c:200: }
      007B17 02 7A F0         [24] 1102 	ljmp	_layer_state_set
                                   1103 ;------------------------------------------------------------
                                   1104 ;Allocation info for local variables in function 'layer_on'
                                   1105 ;------------------------------------------------------------
                                   1106 ;layer         Allocated with name '_layer_on_layer_10000_368'
                                   1107 ;------------------------------------------------------------
                                   1108 ;	quantum/action_layer.c:206: void layer_on(uint8_t layer) {
                                   1109 ;	-----------------------------------------
                                   1110 ;	 function layer_on
                                   1111 ;	-----------------------------------------
      007B1A                       1112 _layer_on:
      007B1A E5 82            [12] 1113 	mov	a,dpl
      007B1C 90 08 6F         [24] 1114 	mov	dptr,#_layer_on_layer_10000_368
      007B1F F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/action_layer.c:213: ((layer_state_t)1 << layer));
      007B20 E0               [24] 1117 	movx	a,@dptr
      007B21 12 79 2E         [24] 1118 	lcall	_ak820_outline_0061
      007B24 80 02            [24] 1119 	sjmp	00104$
      007B26                       1120 00103$:
      007B26 25 E0            [12] 1121 	add	a,acc
      007B28                       1122 00104$:
      007B28 D5 F0 FB         [24] 1123 	djnz	b,00103$
      007B2B FF               [12] 1124 	mov	r7,a
      007B2C 90 08 60         [24] 1125 	mov	dptr,#_persistent_layers
      007B2F 12 7D 86         [24] 1126 	lcall	_ak820_outline_0143
                                   1127 ;	quantum/action_layer.c:214: }
      007B32 02 7A F0         [24] 1128 	ljmp	_layer_state_set
                                   1129 ;------------------------------------------------------------
                                   1130 ;Allocation info for local variables in function 'layer_off'
                                   1131 ;------------------------------------------------------------
                                   1132 ;layer         Allocated with name '_layer_off_layer_10000_370'
                                   1133 ;------------------------------------------------------------
                                   1134 ;	quantum/action_layer.c:220: void layer_off(uint8_t layer) {
                                   1135 ;	-----------------------------------------
                                   1136 ;	 function layer_off
                                   1137 ;	-----------------------------------------
      007B35                       1138 _layer_off:
      007B35 E5 82            [12] 1139 	mov	a,dpl
      007B37 90 08 70         [24] 1140 	mov	dptr,#_layer_off_layer_10000_370
      007B3A F0               [24] 1141 	movx	@dptr,a
                                   1142 ;	quantum/action_layer.c:227: ~((layer_state_t)1 << layer));
      007B3B E0               [24] 1143 	movx	a,@dptr
      007B3C 12 79 2E         [24] 1144 	lcall	_ak820_outline_0061
      007B3F 80 02            [24] 1145 	sjmp	00104$
      007B41                       1146 00103$:
      007B41 25 E0            [12] 1147 	add	a,acc
      007B43                       1148 00104$:
      007B43 D5 F0 FB         [24] 1149 	djnz	b,00103$
      007B46 F4               [12] 1150 	cpl	a
      007B47 FF               [12] 1151 	mov	r7,a
      007B48 90 08 60         [24] 1152 	mov	dptr,#_persistent_layers
      007B4B E0               [24] 1153 	movx	a,@dptr
      007B4C 52 07            [12] 1154 	anl	ar7,a
      007B4E 8F 82            [24] 1155 	mov	dpl, r7
                                   1156 ;	quantum/action_layer.c:228: }
      007B50 02 7A F0         [24] 1157 	ljmp	_layer_state_set
                                   1158 ;------------------------------------------------------------
                                   1159 ;Allocation info for local variables in function 'layer_invert'
                                   1160 ;------------------------------------------------------------
                                   1161 ;layer         Allocated with name '_layer_invert_layer_10000_372'
                                   1162 ;------------------------------------------------------------
                                   1163 ;	quantum/action_layer.c:234: void layer_invert(uint8_t layer) {
                                   1164 ;	-----------------------------------------
                                   1165 ;	 function layer_or
                                   1166 ;	-----------------------------------------
      007B53                       1167 _layer_or:
      007B53 E5 82            [12] 1168 	mov	a,dpl
      007B55 90 08 71         [24] 1169 	mov	dptr,#_layer_or_state_10000_374
      007B58 F0               [24] 1170 	movx	@dptr,a
                                   1171 ;	quantum/action_layer.c:255: state);
      007B59 E0               [24] 1172 	movx	a,@dptr
      007B5A FF               [12] 1173 	mov	r7,a
      007B5B 90 08 60         [24] 1174 	mov	dptr,#_persistent_layers
      007B5E 12 7D 86         [24] 1175 	lcall	_ak820_outline_0143
                                   1176 ;	quantum/action_layer.c:256: }
      007B61 02 7A F0         [24] 1177 	ljmp	_layer_state_set
                                   1178 ;------------------------------------------------------------
                                   1179 ;Allocation info for local variables in function 'layer_and'
                                   1180 ;------------------------------------------------------------
                                   1181 ;state         Allocated with name '_layer_and_state_10000_376'
                                   1182 ;------------------------------------------------------------
                                   1183 ;	quantum/action_layer.c:261: void layer_and(layer_state_t state) {
                                   1184 ;	-----------------------------------------
                                   1185 ;	 function layer_and
                                   1186 ;	-----------------------------------------
      007B64                       1187 _layer_and:
      007B64 E5 82            [12] 1188 	mov	a,dpl
      007B66 90 08 72         [24] 1189 	mov	dptr,#_layer_and_state_10000_376
      007B69 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/action_layer.c:268: state);
      007B6A 90 08 60         [24] 1192 	mov	dptr,#_persistent_layers
      007B6D E0               [24] 1193 	movx	a,@dptr
      007B6E FF               [12] 1194 	mov	r7,a
      007B6F 90 08 72         [24] 1195 	mov	dptr,#_layer_and_state_10000_376
      007B72 E0               [24] 1196 	movx	a,@dptr
      007B73 52 07            [12] 1197 	anl	ar7,a
      007B75 8F 82            [24] 1198 	mov	dpl, r7
                                   1199 ;	quantum/action_layer.c:269: }
      007B77 02 7A F0         [24] 1200 	ljmp	_layer_state_set
                                   1201 ;------------------------------------------------------------
                                   1202 ;Allocation info for local variables in function 'layer_xor'
                                   1203 ;------------------------------------------------------------
                                   1204 ;state         Allocated with name '_layer_xor_state_10000_378'
                                   1205 ;------------------------------------------------------------
                                   1206 ;	quantum/action_layer.c:274: void layer_xor(layer_state_t state) {
                                   1207 ;	-----------------------------------------
                                   1208 ;	 function layer_xor
                                   1209 ;	-----------------------------------------
      007B7A                       1210 _layer_xor:
      007B7A E5 82            [12] 1211 	mov	a,dpl
      007B7C 90 08 73         [24] 1212 	mov	dptr,#_layer_xor_state_10000_378
      007B7F F0               [24] 1213 	movx	@dptr,a
                                   1214 ;	quantum/action_layer.c:281: state);
      007B80 E0               [24] 1215 	movx	a,@dptr
      007B81 FF               [12] 1216 	mov	r7,a
      007B82 90 08 60         [24] 1217 	mov	dptr,#_persistent_layers
      007B85 E0               [24] 1218 	movx	a,@dptr
      007B86 62 07            [12] 1219 	xrl	ar7,a
      007B88 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	quantum/action_layer.c:282: }
      007B8A 02 7A F0         [24] 1222 	ljmp	_layer_state_set
                                   1223 ;------------------------------------------------------------
                                   1224 ;Allocation info for local variables in function 'source_keycode_cache_slot'
                                   1225 ;------------------------------------------------------------
                                   1226 ;position      Allocated with name '_source_keycode_cache_slot_position_10000_380'
                                   1227 ;row           Allocated with name '_source_keycode_cache_slot_row_10000_381'
                                   1228 ;col           Allocated with name '_source_keycode_cache_slot_col_10000_381'
                                   1229 ;------------------------------------------------------------
                                   1230 ;	quantum/action_layer.c:324: static uint16_t SOURCE_CACHE_MEM *source_keycode_cache_slot(uint16_t position) {
                                   1231 ;	-----------------------------------------
                                   1232 ;	 function source_keycode_cache_slot
                                   1233 ;	-----------------------------------------
      007B8D                       1234 _source_keycode_cache_slot:
      007B8D 12 38 85         [24] 1235 	lcall	_ak820_outline_0108
      007B90 90 09 78         [24] 1236 	mov	dptr,#_source_keycode_cache_slot_position_10000_380
      007B93 12 38 8A         [24] 1237 	lcall	_ak820_outline_0109
                                   1238 ;	quantum/action_layer.c:325: uint8_t row = position >> 8, col = position;
      007B96 90 09 78         [24] 1239 	mov	dptr,#_source_keycode_cache_slot_position_10000_380
      007B99 E0               [24] 1240 	movx	a,@dptr
      007B9A FE               [12] 1241 	mov	r6,a
      007B9B A3               [24] 1242 	inc	dptr
      007B9C E0               [24] 1243 	movx	a,@dptr
      007B9D FD               [12] 1244 	mov	r5,a
                                   1245 ;	quantum/action_layer.c:326: if (row < MATRIX_ROWS && col < MATRIX_COLS) {
      007B9E BD 10 00         [24] 1246 	cjne	r5,#0x10,00147$
      007BA1                       1247 00147$:
      007BA1 50 21            [24] 1248 	jnc	00102$
      007BA3 BE 08 00         [24] 1249 	cjne	r6,#0x08,00149$
      007BA6                       1250 00149$:
      007BA6 50 1C            [24] 1251 	jnc	00102$
                                   1252 ;	quantum/action_layer.c:327: return &source_keycodes_cache[(uint8_t)(row * MATRIX_COLS + col)];
      007BA8 8D 07            [24] 1253 	mov	ar7,r5
      007BAA EF               [12] 1254 	mov	a,r7
      007BAB 12 38 D0         [24] 1255 	lcall	_ak820_outline_0192
      007BAE FF               [12] 1256 	mov	r7,a
      007BAF 8E 04            [24] 1257 	mov	ar4,r6
      007BB1 EC               [12] 1258 	mov	a,r4
      007BB2 2F               [12] 1259 	add	a, r7
      007BB3 75 F0 02         [24] 1260 	mov	b,#0x02
      007BB6 A4               [48] 1261 	mul	ab
      007BB7 24 74            [12] 1262 	add	a, #_source_keycodes_cache
      007BB9 FC               [12] 1263 	mov	r4,a
      007BBA 74 08            [12] 1264 	mov	a,#(_source_keycodes_cache >> 8)
      007BBC 35 F0            [12] 1265 	addc	a, b
      007BBE FF               [12] 1266 	mov	r7,a
      007BBF 8C 82            [24] 1267 	mov	dpl, r4
      007BC1 8F 83            [24] 1268 	mov	dph, r7
      007BC3 22               [24] 1269 	ret
      007BC4                       1270 00102$:
                                   1271 ;	quantum/action_layer.c:330: if ((row == KEYLOC_ENCODER_CW || row == KEYLOC_ENCODER_CCW) && col < NUM_ENCODERS) {
      007BC4 BD FD 02         [24] 1272 	cjne	r5,#0xfd,00151$
      007BC7 80 03            [24] 1273 	sjmp	00107$
      007BC9                       1274 00151$:
      007BC9 BD FC 2E         [24] 1275 	cjne	r5,#0xfc,00105$
      007BCC                       1276 00107$:
      007BCC BE 01 00         [24] 1277 	cjne	r6,#0x01,00154$
      007BCF                       1278 00154$:
      007BCF 50 29            [24] 1279 	jnc	00105$
                                   1280 ;	quantum/action_layer.c:331: return &encoder_source_keycodes_cache[col + (row == KEYLOC_ENCODER_CCW ? NUM_ENCODERS : 0)];
      007BD1 BD FC 04         [24] 1281 	cjne	r5,#0xfc,00110$
      007BD4 7F 01            [12] 1282 	mov	r7,#0x01
      007BD6 80 02            [24] 1283 	sjmp	00111$
      007BD8                       1284 00110$:
      007BD8 7F 00            [12] 1285 	mov	r7,#0x00
      007BDA                       1286 00111$:
      007BDA C2 D5            [12] 1287 	clr	F0
      007BDC 75 F0 02         [24] 1288 	mov	b,#0x02
      007BDF EF               [12] 1289 	mov	a,r7
      007BE0 30 E7 04         [24] 1290 	jnb	acc.7,00158$
      007BE3 B2 D5            [12] 1291 	cpl	F0
      007BE5 F4               [12] 1292 	cpl	a
      007BE6 04               [12] 1293 	inc	a
      007BE7                       1294 00158$:
      007BE7 A4               [48] 1295 	mul	ab
      007BE8 30 D5 03         [24] 1296 	jnb	F0,00159$
      007BEB 12 71 D2         [24] 1297 	lcall	_ak820_outline_0131
      007BEE                       1298 00159$:
      007BEE 24 74            [12] 1299 	add	a, #_encoder_source_keycodes_cache
      007BF0 FE               [12] 1300 	mov	r6,a
      007BF1 74 09            [12] 1301 	mov	a,#(_encoder_source_keycodes_cache >> 8)
      007BF3 35 F0            [12] 1302 	addc	a, b
      007BF5 FF               [12] 1303 	mov	r7,a
      007BF6 12 38 96         [24] 1304 	lcall	_ak820_outline_0122
      007BF9 22               [24] 1305 	ret
      007BFA                       1306 00105$:
                                   1307 ;	quantum/action_layer.c:334: return 0;
      007BFA 90 00 00         [24] 1308 	mov	dptr,#0x0000
                                   1309 ;	quantum/action_layer.c:335: }
      007BFD 22               [24] 1310 	ret
                                   1311 ;------------------------------------------------------------
                                   1312 ;Allocation info for local variables in function 'ak820_cache_keycode'
                                   1313 ;------------------------------------------------------------
                                   1314 ;keycode       Allocated with name '_ak820_cache_keycode_PARM_2'
                                   1315 ;position      Allocated with name '_ak820_cache_keycode_position_10000_386'
                                   1316 ;slot          Allocated with name '_ak820_cache_keycode_slot_10000_387'
                                   1317 ;------------------------------------------------------------
                                   1318 ;	quantum/action_layer.c:339: bool ak820_cache_keycode(uint16_t position, uint16_t keycode) {
                                   1319 ;	-----------------------------------------
                                   1320 ;	 function ak820_cache_keycode
                                   1321 ;	-----------------------------------------
      007BFE                       1322 _ak820_cache_keycode:
      007BFE 12 38 85         [24] 1323 	lcall	_ak820_outline_0108
      007C01 90 09 7C         [24] 1324 	mov	dptr,#_ak820_cache_keycode_position_10000_386
      007C04 12 38 8A         [24] 1325 	lcall	_ak820_outline_0109
                                   1326 ;	quantum/action_layer.c:340: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007C07 90 09 7C         [24] 1327 	mov	dptr,#_ak820_cache_keycode_position_10000_386
      007C0A 12 37 F1         [24] 1328 	lcall	_ak820_outline_0005
      007C0D 12 7B 8D         [24] 1329 	lcall	_source_keycode_cache_slot
      007C10 12 45 B8         [24] 1330 	lcall	_ak820_outline_0135
                                   1331 ;	quantum/action_layer.c:341: if (!slot) return false;
      007C13 EE               [12] 1332 	mov	a,r6
      007C14 4F               [12] 1333 	orl	a,r7
      007C15 70 03            [24] 1334 	jnz	00102$
      007C17 F5 82            [12] 1335 	mov	dpl,a
      007C19 22               [24] 1336 	ret
      007C1A                       1337 00102$:
                                   1338 ;	quantum/action_layer.c:342: *slot = keycode;
      007C1A 90 09 7A         [24] 1339 	mov	dptr,#_ak820_cache_keycode_PARM_2
      007C1D 12 38 55         [24] 1340 	lcall	_ak820_outline_0059
      007C20 12 38 96         [24] 1341 	lcall	_ak820_outline_0122
      007C23 12 38 5B         [24] 1342 	lcall	_ak820_outline_0072
                                   1343 ;	quantum/action_layer.c:343: return true;
      007C26 75 82 01         [24] 1344 	mov	dpl, #0x01
                                   1345 ;	quantum/action_layer.c:344: }
      007C29 22               [24] 1346 	ret
                                   1347 ;------------------------------------------------------------
                                   1348 ;Allocation info for local variables in function 'ak820_cache_layer'
                                   1349 ;------------------------------------------------------------
                                   1350 ;layer         Allocated with name '_ak820_cache_layer_PARM_2'
                                   1351 ;position      Allocated with name '_ak820_cache_layer_position_10000_389'
                                   1352 ;slot          Allocated with name '_ak820_cache_layer_slot_10000_390'
                                   1353 ;------------------------------------------------------------
                                   1354 ;	quantum/action_layer.c:346: void ak820_cache_layer(uint16_t position, uint8_t layer) {
                                   1355 ;	-----------------------------------------
                                   1356 ;	 function ak820_cache_layer
                                   1357 ;	-----------------------------------------
      007C2A                       1358 _ak820_cache_layer:
      007C2A 12 38 85         [24] 1359 	lcall	_ak820_outline_0108
      007C2D 90 09 7F         [24] 1360 	mov	dptr,#_ak820_cache_layer_position_10000_389
      007C30 12 38 8A         [24] 1361 	lcall	_ak820_outline_0109
                                   1362 ;	quantum/action_layer.c:347: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007C33 90 09 7F         [24] 1363 	mov	dptr,#_ak820_cache_layer_position_10000_389
      007C36 12 37 F1         [24] 1364 	lcall	_ak820_outline_0005
      007C39 C0 07            [24] 1365 	push	ar7
      007C3B C0 06            [24] 1366 	push	ar6
      007C3D 12 7B 8D         [24] 1367 	lcall	_source_keycode_cache_slot
      007C40 12 45 C9         [24] 1368 	lcall	_ak820_outline_0151
      007C43 D0 06            [24] 1369 	pop	ar6
      007C45 D0 07            [24] 1370 	pop	ar7
                                   1371 ;	quantum/action_layer.c:348: if (!slot) return;
      007C47 EC               [12] 1372 	mov	a,r4
      007C48 4D               [12] 1373 	orl	a,r5
      007C49 70 01            [24] 1374 	jnz	00102$
      007C4B 22               [24] 1375 	ret
      007C4C                       1376 00102$:
                                   1377 ;	quantum/action_layer.c:349: layer &= (1u << MAX_LAYER_BITS) - 1;
      007C4C 90 09 7E         [24] 1378 	mov	dptr,#_ak820_cache_layer_PARM_2
      007C4F E0               [24] 1379 	movx	a,@dptr
      007C50 53 E0 07         [24] 1380 	anl	acc,#0x07
      007C53 F0               [24] 1381 	movx	@dptr,a
                                   1382 ;	quantum/action_layer.c:361: *slot = ak820_keycode_at(layer, position);
      007C54 90 09 7E         [24] 1383 	mov	dptr,#_ak820_cache_layer_PARM_2
      007C57 E0               [24] 1384 	movx	a,@dptr
      007C58 FB               [12] 1385 	mov	r3,a
      007C59 90 0B AF         [24] 1386 	mov	dptr,#_ak820_keycode_at_PARM_2
      007C5C 12 4A E0         [24] 1387 	lcall	_ak820_outline_0058
      007C5F 8B 82            [24] 1388 	mov	dpl, r3
      007C61 C0 05            [24] 1389 	push	ar5
      007C63 C0 04            [24] 1390 	push	ar4
      007C65 12 98 03         [24] 1391 	lcall	_ak820_keycode_at
      007C68 12 45 B8         [24] 1392 	lcall	_ak820_outline_0135
      007C6B D0 04            [24] 1393 	pop	ar4
      007C6D D0 05            [24] 1394 	pop	ar5
      007C6F 12 38 A1         [24] 1395 	lcall	_ak820_outline_0126
      007C72 12 4A E0         [24] 1396 	lcall	_ak820_outline_0058
                                   1397 ;	quantum/action_layer.c:362: }
      007C75 22               [24] 1398 	ret
                                   1399 ;------------------------------------------------------------
                                   1400 ;Allocation info for local variables in function 'ak820_cached_key'
                                   1401 ;------------------------------------------------------------
                                   1402 ;position      Allocated with name '_ak820_cached_key_position_10000_392'
                                   1403 ;slot          Allocated with name '_ak820_cached_key_slot_10001_396'
                                   1404 ;------------------------------------------------------------
                                   1405 ;	quantum/action_layer.c:383: uint16_t ak820_cached_key(uint16_t position) {
                                   1406 ;	-----------------------------------------
                                   1407 ;	 function ak820_cached_key
                                   1408 ;	-----------------------------------------
      007C76                       1409 _ak820_cached_key:
      007C76 12 38 85         [24] 1410 	lcall	_ak820_outline_0108
      007C79 90 09 81         [24] 1411 	mov	dptr,#_ak820_cached_key_position_10000_392
      007C7C 12 38 8A         [24] 1412 	lcall	_ak820_outline_0109
                                   1413 ;	quantum/action_layer.c:386: if (vial_unlock_in_progress) return KC_NO;
      007C7F 90 0E 39         [24] 1414 	mov	dptr,#_vial_unlock_in_progress
      007C82 E0               [24] 1415 	movx	a,@dptr
      007C83 60 04            [24] 1416 	jz	00102$
      007C85 90 00 00         [24] 1417 	mov	dptr,#0x0000
      007C88 22               [24] 1418 	ret
      007C89                       1419 00102$:
                                   1420 ;	quantum/action_layer.c:387: if (position == (((uint16_t)VIAL_MATRIX_MAGIC << 8) | VIAL_MATRIX_MAGIC)) return g_vial_magic_keycode_override;
      007C89 90 09 81         [24] 1421 	mov	dptr,#_ak820_cached_key_position_10000_392
      007C8C 12 38 3E         [24] 1422 	lcall	_ak820_outline_0051
      007C8F BE F0 0D         [24] 1423 	cjne	r6,#0xf0,00104$
      007C92 BF F0 0A         [24] 1424 	cjne	r7,#0xf0,00104$
      007C95 90 0C 8F         [24] 1425 	mov	dptr,#_g_vial_magic_keycode_override
      007C98 12 38 55         [24] 1426 	lcall	_ak820_outline_0059
      007C9B 12 38 A1         [24] 1427 	lcall	_ak820_outline_0126
      007C9E 22               [24] 1428 	ret
      007C9F                       1429 00104$:
                                   1430 ;	quantum/action_layer.c:389: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007C9F 12 38 96         [24] 1431 	lcall	_ak820_outline_0122
      007CA2 12 7B 8D         [24] 1432 	lcall	_source_keycode_cache_slot
      007CA5 12 45 B8         [24] 1433 	lcall	_ak820_outline_0135
                                   1434 ;	quantum/action_layer.c:390: return slot ? *slot : KC_NO;
      007CA8 EE               [12] 1435 	mov	a,r6
      007CA9 4F               [12] 1436 	orl	a,r7
      007CAA 60 08            [24] 1437 	jz	00107$
      007CAC 12 38 96         [24] 1438 	lcall	_ak820_outline_0122
      007CAF 12 38 3E         [24] 1439 	lcall	_ak820_outline_0051
      007CB2 80 04            [24] 1440 	sjmp	00108$
      007CB4                       1441 00107$:
      007CB4 7E 00            [12] 1442 	mov	r6,#0x00
      007CB6 7F 00            [12] 1443 	mov	r7,#0x00
      007CB8                       1444 00108$:
      007CB8 12 38 96         [24] 1445 	lcall	_ak820_outline_0122
                                   1446 ;	quantum/action_layer.c:391: }
      007CBB 22               [24] 1447 	ret
                                   1448 ;------------------------------------------------------------
                                   1449 ;Allocation info for local variables in function 'update_source_keycode_cache'
                                   1450 ;------------------------------------------------------------
                                   1451 ;key           Allocated with name '_update_source_keycode_cache_PARM_1'
                                   1452 ;keycode       Allocated with name '_update_source_keycode_cache_keycode_10000_397'
                                   1453 ;------------------------------------------------------------
                                   1454 ;	quantum/action_layer.c:394: bool update_source_keycode_cache(keypos_t key, uint16_t keycode) {
                                   1455 ;	-----------------------------------------
                                   1456 ;	 function ak820_resolve_key
                                   1457 ;	-----------------------------------------
      007CBC                       1458 _ak820_resolve_key:
      007CBC 12 38 85         [24] 1459 	lcall	_ak820_outline_0108
      007CBF 90 09 84         [24] 1460 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007CC2 12 38 8A         [24] 1461 	lcall	_ak820_outline_0109
                                   1462 ;	quantum/action_layer.c:493: if (disable_action_cache) {
      007CC5 90 0D D8         [24] 1463 	mov	dptr,#_disable_action_cache
      007CC8 E0               [24] 1464 	movx	a,@dptr
      007CC9 60 1E            [24] 1465 	jz	00102$
                                   1466 ;	quantum/action_layer.c:494: return ak820_keycode_at(ak820_layer_for_key(position), position);
      007CCB 90 09 84         [24] 1467 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007CCE 12 37 F1         [24] 1468 	lcall	_ak820_outline_0005
      007CD1 C0 07            [24] 1469 	push	ar7
      007CD3 C0 06            [24] 1470 	push	ar6
      007CD5 12 7D 14         [24] 1471 	lcall	_ak820_layer_for_key
      007CD8 AD 82            [24] 1472 	mov	r5, dpl
      007CDA D0 06            [24] 1473 	pop	ar6
      007CDC D0 07            [24] 1474 	pop	ar7
      007CDE 90 0B AF         [24] 1475 	mov	dptr,#_ak820_keycode_at_PARM_2
      007CE1 12 4A E0         [24] 1476 	lcall	_ak820_outline_0058
      007CE4 8D 82            [24] 1477 	mov	dpl, r5
      007CE6 02 98 03         [24] 1478 	ljmp	_ak820_keycode_at
      007CE9                       1479 00102$:
                                   1480 ;	quantum/action_layer.c:496: if (cache_press) ak820_cache_layer(position, ak820_layer_for_key(position));
      007CE9 90 09 83         [24] 1481 	mov	dptr,#_ak820_resolve_key_PARM_2
      007CEC E0               [24] 1482 	movx	a,@dptr
      007CED 60 1C            [24] 1483 	jz	00104$
      007CEF 90 09 84         [24] 1484 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007CF2 12 37 F1         [24] 1485 	lcall	_ak820_outline_0005
      007CF5 C0 07            [24] 1486 	push	ar7
      007CF7 C0 06            [24] 1487 	push	ar6
      007CF9 12 7D 14         [24] 1488 	lcall	_ak820_layer_for_key
      007CFC E5 82            [12] 1489 	mov	a, dpl
      007CFE D0 06            [24] 1490 	pop	ar6
      007D00 D0 07            [24] 1491 	pop	ar7
      007D02 90 09 7E         [24] 1492 	mov	dptr,#_ak820_cache_layer_PARM_2
      007D05 12 45 9A         [24] 1493 	lcall	_ak820_outline_0071
      007D08 12 7C 2A         [24] 1494 	lcall	_ak820_cache_layer
      007D0B                       1495 00104$:
                                   1496 ;	quantum/action_layer.c:497: return ak820_cached_key(position);
      007D0B 90 09 84         [24] 1497 	mov	dptr,#_ak820_resolve_key_position_10000_403
      007D0E 12 37 F1         [24] 1498 	lcall	_ak820_outline_0005
                                   1499 ;	quantum/action_layer.c:498: }
      007D11 02 7C 76         [24] 1500 	ljmp	_ak820_cached_key
                                   1501 ;------------------------------------------------------------
                                   1502 ;Allocation info for local variables in function 'store_or_get_action'
                                   1503 ;------------------------------------------------------------
                                   1504 ;key           Allocated with name '_store_or_get_action_PARM_2'
                                   1505 ;pressed       Allocated with name '_store_or_get_action_pressed_10000_408'
                                   1506 ;------------------------------------------------------------
                                   1507 ;	quantum/action_layer.c:499: uint16_t store_or_get_action(bool pressed, keypos_t key) {
                                   1508 ;	-----------------------------------------
                                   1509 ;	 function ak820_layer_for_key
                                   1510 ;	-----------------------------------------
      007D14                       1511 _ak820_layer_for_key:
      007D14 12 38 85         [24] 1512 	lcall	_ak820_outline_0108
      007D17 90 09 86         [24] 1513 	mov	dptr,#_ak820_layer_for_key_position_10000_410
      007D1A 12 38 8A         [24] 1514 	lcall	_ak820_outline_0109
                                   1515 ;	quantum/action_layer.c:539: layer_state_t layers = layer_state | default_layer_state;
      007D1D 90 0D D9         [24] 1516 	mov	dptr,#_default_layer_state
      007D20 E0               [24] 1517 	movx	a,@dptr
      007D21 FF               [12] 1518 	mov	r7,a
      007D22 90 0D DA         [24] 1519 	mov	dptr,#_layer_state
      007D25 E0               [24] 1520 	movx	a,@dptr
      007D26 90 09 88         [24] 1521 	mov	dptr,#_ak820_layer_for_key_layers_10000_411
      007D29 4F               [12] 1522 	orl	a,r7
      007D2A F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007D2B 90 09 86         [24] 1525 	mov	dptr,#_ak820_layer_for_key_position_10000_410
      007D2E 12 38 3E         [24] 1526 	lcall	_ak820_outline_0051
      007D31 7D 05            [12] 1527 	mov	r5,#0x05
      007D33                       1528 00107$:
      007D33 ED               [12] 1529 	mov	a,r5
      007D34 20 E7 4B         [24] 1530 	jb	acc.7,00105$
                                   1531 ;	quantum/action_layer.c:542: if (layers & ((layer_state_t)1 << i)) {
      007D37 8D F0            [24] 1532 	mov	b,r5
      007D39 05 F0            [12] 1533 	inc	b
      007D3B 7B 01            [12] 1534 	mov	r3,#0x01
      007D3D 7C 00            [12] 1535 	mov	r4,#0x00
      007D3F 80 06            [24] 1536 	sjmp	00141$
      007D41                       1537 00140$:
      007D41 EB               [12] 1538 	mov	a,r3
      007D42 2B               [12] 1539 	add	a,r3
      007D43 FB               [12] 1540 	mov	r3,a
      007D44 EC               [12] 1541 	mov	a,r4
      007D45 33               [12] 1542 	rlc	a
      007D46 FC               [12] 1543 	mov	r4,a
      007D47                       1544 00141$:
      007D47 D5 F0 F7         [24] 1545 	djnz	b,00140$
      007D4A 90 09 88         [24] 1546 	mov	dptr,#_ak820_layer_for_key_layers_10000_411
      007D4D E0               [24] 1547 	movx	a,@dptr
      007D4E 7A 00            [12] 1548 	mov	r2,#0x00
      007D50 52 03            [12] 1549 	anl	ar3,a
      007D52 EA               [12] 1550 	mov	a,r2
      007D53 52 04            [12] 1551 	anl	ar4,a
      007D55 EB               [12] 1552 	mov	a,r3
      007D56 4C               [12] 1553 	orl	a,r4
      007D57 60 26            [24] 1554 	jz	00108$
                                   1555 ;	quantum/action_layer.c:546: if (ak820_keycode_at(i, position) != KC_TRANSPARENT) {
      007D59 90 0B AF         [24] 1556 	mov	dptr,#_ak820_keycode_at_PARM_2
      007D5C 12 4A E0         [24] 1557 	lcall	_ak820_outline_0058
      007D5F 8D 82            [24] 1558 	mov	dpl, r5
      007D61 C0 07            [24] 1559 	push	ar7
      007D63 C0 06            [24] 1560 	push	ar6
      007D65 C0 05            [24] 1561 	push	ar5
      007D67 12 98 03         [24] 1562 	lcall	_ak820_keycode_at
      007D6A AB 82            [24] 1563 	mov	r3, dpl
      007D6C AC 83            [24] 1564 	mov	r4, dph
      007D6E D0 05            [24] 1565 	pop	ar5
      007D70 D0 06            [24] 1566 	pop	ar6
      007D72 D0 07            [24] 1567 	pop	ar7
      007D74 BB 01 05         [24] 1568 	cjne	r3,#0x01,00143$
      007D77 BC 00 02         [24] 1569 	cjne	r4,#0x00,00143$
      007D7A 80 03            [24] 1570 	sjmp	00108$
      007D7C                       1571 00143$:
                                   1572 ;	quantum/action_layer.c:555: return i;
      007D7C 8D 82            [24] 1573 	mov	dpl, r5
      007D7E 22               [24] 1574 	ret
      007D7F                       1575 00108$:
                                   1576 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007D7F 1D               [12] 1577 	dec	r5
      007D80 80 B1            [24] 1578 	sjmp	00107$
      007D82                       1579 00105$:
                                   1580 ;	quantum/action_layer.c:560: return 0;
      007D82 75 82 00         [24] 1581 	mov	dpl, #0x00
                                   1582 ;	quantum/action_layer.c:565: }
      007D85 22               [24] 1583 	ret
                                   1584 ;------------------------------------------------------------
                                   1585 ;Allocation info for local variables in function 'layer_switch_get_layer'
                                   1586 ;------------------------------------------------------------
                                   1587 ;key           Allocated with name '_layer_switch_get_layer_PARM_1'
                                   1588 ;------------------------------------------------------------
                                   1589 ;	quantum/action_layer.c:567: uint8_t layer_switch_get_layer(keypos_t key) {
                                   1590 ;	-----------------------------------------
                                   1591 	.area CSEG    (CODE)
                                   1592 	.area CONST   (CODE)
                                   1593 	.area XINIT   (CODE)
      00C328                       1594 __xinit__default_layer_state:
      00C328 00                    1595 	.db #0x00	; 0
      00C329                       1596 __xinit__layer_state:
      00C329 00                    1597 	.db #0x00	; 0
                                   1598 	.area CABS    (ABS,CODE)
                                   1599 
                                   1600 ; Experimental exact instruction outlining.
                                   1601 	.globl _ak820_outline_0005
                                   1602 	.globl _ak820_outline_0051
                                   1603 	.globl _ak820_outline_0058
                                   1604 	.globl _ak820_outline_0059
                                   1605 	.globl _ak820_outline_0061
                                   1606 	.globl _ak820_outline_0071
                                   1607 	.globl _ak820_outline_0072
                                   1608 	.globl _ak820_outline_0100
                                   1609 	.globl _ak820_outline_0108
                                   1610 	.globl _ak820_outline_0109
                                   1611 	.globl _ak820_outline_0122
                                   1612 	.globl _ak820_outline_0126
                                   1613 	.globl _ak820_outline_0131
                                   1614 	.globl _ak820_outline_0135
                                   1615 	.globl _ak820_outline_0137
                                   1616 	.globl _ak820_outline_0143
                                   1617 	.globl _ak820_outline_0151
                                   1618 	.globl _ak820_outline_0160
                                   1619 	.globl _ak820_outline_0165
                                   1620 	.globl _ak820_outline_0172
                                   1621 	.globl _ak820_outline_0178
                                   1622 	.globl _ak820_outline_0192
                                   1623 
                                   1624 	.area CSEG (CODE)
                                   1625 ; function ak820_outline_0143
      007D86                       1626 _ak820_outline_0143:
      007D86 E0               [24] 1627 	movx	a,@dptr
      007D87 42 07            [12] 1628 	orl	ar7,a
      007D89 8F 82            [24] 1629 	mov	dpl,r7
      007D8B 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0165
      007D8C                       1634 _ak820_outline_0165:
      007D8C F5 83            [12] 1635 	mov	dph,a
      007D8E E4               [12] 1636 	clr	a
      007D8F F0               [24] 1637 	movx	@dptr,a
      007D90 0F               [12] 1638 	inc	r7
      007D91 22               [24] 1639 	ret
                                   1640 
                                   1641 	.area CSEG (CODE)
                                   1642 ; function ak820_outline_0178
      007D92                       1643 _ak820_outline_0178:
      007D92 90 09 9F         [24] 1644 	mov	dptr,#_ak820_macro_change_PARM_2
      007D95 EF               [12] 1645 	mov	a,r7
      007D96 F0               [24] 1646 	movx	@dptr,a
      007D97 90 09 A0         [24] 1647 	mov	dptr,#_ak820_macro_change_PARM_3
      007D9A 22               [24] 1648 	ret
