                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000E                        552 _ak820_tapping_before_sloc0_1_0:
      00000E                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      0005B8                        562 _source_state:
      0005B8                        563 	.ds 130
      00063A                        564 _pending_time:
      00063A                        565 	.ds 2
      00063C                        566 _pending_code:
      00063C                        567 	.ds 2
      00063E                        568 _ak820_tapping_source_PARM_1:
      00063E                        569 	.ds 2
      000640                        570 _hold_PARM_2:
      000640                        571 	.ds 1
      000641                        572 _hold_code_10000_601:
      000641                        573 	.ds 2
      000643                        574 _hold_mods_30000_604:
      000643                        575 	.ds 1
      000644                        576 _commit_pending_id_10000_610:
      000644                        577 	.ds 1
      000645                        578 _ak820_tapping_before_event_10000_611:
      000645                        579 	.ds 2
      000647                        580 _ak820_tapping_process_record_10000_622:
      000647                        581 	.ds 2
      000649                        582 _ak820_tapping_process_code_10000_623:
      000649                        583 	.ds 2
      00064B                        584 _ak820_tapping_process_sc_mods_10000_623:
      00064B                        585 	.ds 1
      00064C                        586 _ak820_oneshot_mods::
      00064C                        587 	.ds 1
      00064D                        588 _ak820_oneshot_consumed::
      00064D                        589 	.ds 1
      00064E                        590 _ak820_oneshot_process_PARM_2:
      00064E                        591 	.ds 1
      00064F                        592 _ak820_oneshot_process_PARM_3:
      00064F                        593 	.ds 1
      000650                        594 _ak820_oneshot_process_code_10000_648:
      000650                        595 	.ds 2
      000652                        596 _ak820_oneshot_process_mods_10000_649:
      000652                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000DC8                        606 _pending:
      000DC8                        607 	.ds 1
      000DC9                        608 _ak820_oneshot_target::
      000DC9                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0045E9                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0045E9 90 06 3F         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0045EC E0               [24]  656 	movx	a,@dptr
      0045ED FF               [12]  657 	mov	r7,a
      0045EE BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0045F1                        659 00147$:
      0045F1 50 14            [24]  660 	jnc	00102$
      0045F3 90 06 3E         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0045F6 E0               [24]  662 	movx	a,@dptr
      0045F7 FE               [12]  663 	mov	r6,a
      0045F8 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0045FB                        665 00149$:
      0045FB 50 0A            [24]  666 	jnc	00102$
      0045FD 8F 05            [24]  667 	mov	ar5,r7
      0045FF ED               [12]  668 	mov	a,r5
      004600 12 38 D0         [24]  669 	lcall	_ak820_outline_0192
      004603 2E               [12]  670 	add	a,r6
      004604 F5 82            [12]  671 	mov	dpl,a
      004606 22               [24]  672 	ret
      004607                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      004607 90 06 3E         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      00460A E0               [24]  676 	movx	a,@dptr
      00460B FE               [12]  677 	mov	r6,a
      00460C BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      00460F                        679 00151$:
      00460F 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004611 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      004614 75 82 80         [24]  683 	mov	dpl, #0x80
      004617 22               [24]  684 	ret
      004618                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      004618 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      00461B 75 82 81         [24]  688 	mov	dpl, #0x81
      00461E 22               [24]  689 	ret
      00461F                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      00461F 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      004622 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_601'
                                    700 ;mods          Allocated with name '_hold_mods_30000_604'
                                    701 ;layer         Allocated with name '_hold_layer_30000_607'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      004623                        707 _hold:
      004623 12 38 85         [24]  708 	lcall	_ak820_outline_0108
      004626 90 06 41         [24]  709 	mov	dptr,#_hold_code_10000_601
      004629 12 38 8A         [24]  710 	lcall	_ak820_outline_0109
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      00462C 90 06 41         [24]  712 	mov	dptr,#_hold_code_10000_601
      00462F 12 4A 83         [24]  713 	lcall	_ak820_outline_0008
      004632 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004634 2D               [12]  715 	add	a,r5
      004635 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      004637 8F 05            [24]  718 	mov	ar5,r7
      004639 53 05 1F         [24]  719 	anl	ar5,#0x1f
      00463C 90 06 43         [24]  720 	mov	dptr,#_hold_mods_30000_604
      00463F ED               [12]  721 	mov	a,r5
      004640 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      004641 ED               [12]  724 	mov	a,r5
      004642 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004645 ED               [12]  726 	mov	a,r5
      004646 C4               [12]  727 	swap	a
      004647 54 F0            [12]  728 	anl	a,#0xf0
      004649 90 06 43         [24]  729 	mov	dptr,#_hold_mods_30000_604
      00464C F0               [24]  730 	movx	@dptr,a
      00464D                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      00464D 90 06 40         [24]  733 	mov	dptr,#_hold_PARM_2
      004650 E0               [24]  734 	movx	a,@dptr
      004651 60 09            [24]  735 	jz	00104$
      004653 90 06 43         [24]  736 	mov	dptr,#_hold_mods_30000_604
      004656 E0               [24]  737 	movx	a,@dptr
      004657 F5 82            [12]  738 	mov	dpl,a
      004659 02 78 65         [24]  739 	ljmp	_register_mods
      00465C                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      00465C 90 06 43         [24]  742 	mov	dptr,#_hold_mods_30000_604
      00465F E0               [24]  743 	movx	a,@dptr
      004660 F5 82            [12]  744 	mov	dpl,a
      004662 02 78 79         [24]  745 	ljmp	_unregister_mods
      004665                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004665 8F 06            [24]  748 	mov	ar6,r7
      004667 74 0F            [12]  749 	mov	a,#0x0f
      004669 5E               [12]  750 	anl	a,r6
      00466A FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      00466B 90 06 40         [24]  753 	mov	dptr,#_hold_PARM_2
      00466E E0               [24]  754 	movx	a,@dptr
      00466F 60 05            [24]  755 	jz	00107$
      004671 8F 82            [24]  756 	mov	dpl, r7
      004673 02 7A 51         [24]  757 	ljmp	_layer_hold_on
      004676                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      004676 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      004678 02 7A 89         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_610'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      00467B                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      00467B 90 0D C8         [24]  774 	mov	dptr,#_pending
      00467E E0               [24]  775 	movx	a,@dptr
      00467F 90 06 44         [24]  776 	mov	dptr,#_commit_pending_id_10000_610
      004682 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      004683 12 4B 16         [24]  779 	lcall	_ak820_outline_0156
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      004686 90 06 44         [24]  781 	mov	dptr,#_commit_pending_id_10000_610
      004689 E0               [24]  782 	movx	a,@dptr
      00468A 24 B8            [12]  783 	add	a,#_source_state
      00468C FF               [12]  784 	mov	r7,a
      00468D E4               [12]  785 	clr	a
      00468E 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004690 FE               [12]  787 	mov	r6,a
      004691 12 45 CE         [24]  788 	lcall	_ak820_outline_0160
      004694 E0               [24]  789 	movx	a,@dptr
      004695 FD               [12]  790 	mov	r5,a
      004696 43 05 04         [24]  791 	orl	ar5,#0x04
      004699 12 45 CE         [24]  792 	lcall	_ak820_outline_0160
      00469C ED               [12]  793 	mov	a,r5
      00469D F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      00469E 90 06 3C         [24]  796 	mov	dptr,#_pending_code
      0046A1 12 38 3E         [24]  797 	lcall	_ak820_outline_0051
      0046A4 90 06 40         [24]  798 	mov	dptr,#_hold_PARM_2
      0046A7 74 01            [12]  799 	mov	a,#0x01
      0046A9 12 45 9A         [24]  800 	lcall	_ak820_outline_0071
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0046AC 02 46 23         [24]  802 	ljmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_611'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_612'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      0046AF                        813 _ak820_tapping_before:
      0046AF 12 38 85         [24]  814 	lcall	_ak820_outline_0108
      0046B2 90 06 45         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_611
      0046B5 12 38 8A         [24]  816 	lcall	_ak820_outline_0109
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      0046B8 90 06 45         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_611
      0046BB 12 4A 83         [24]  819 	lcall	_ak820_outline_0008
      0046BE 12 4A B3         [24]  820 	lcall	_ak820_outline_0025
      0046C1 C0 07            [24]  821 	push	ar7
      0046C3 C0 06            [24]  822 	push	ar6
      0046C5 12 BA 56         [24]  823 	lcall	___memcpy
      0046C8 12 45 E9         [24]  824 	lcall	_ak820_tapping_source
      0046CB AD 82            [24]  825 	mov	r5, dpl
      0046CD D0 06            [24]  826 	pop	ar6
      0046CF D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      0046D1 90 0E 39         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      0046D4 E0               [24]  830 	movx	a,@dptr
      0046D5 60 26            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0046D7 12 4B 02         [24]  833 	lcall	_ak820_outline_0097
      0046DA 60 1D            [24]  834 	jz	00102$
      0046DC BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      0046DF 80 18            [24]  836 	sjmp	00102$
      0046E1                        837 00218$:
      0046E1 12 4A 8D         [24]  838 	lcall	_ak820_outline_0015
      0046E4 E0               [24]  839 	movx	a,@dptr
      0046E5 70 12            [24]  840 	jnz	00102$
      0046E7 ED               [12]  841 	mov	a,r5
      0046E8 24 B8            [12]  842 	add	a, #_source_state
      0046EA FB               [12]  843 	mov	r3,a
      0046EB E4               [12]  844 	clr	a
      0046EC 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      0046EE 12 4A D8         [24]  846 	lcall	_ak820_outline_0055
      0046F1 53 02 FD         [24]  847 	anl	ar2,#0xfd
      0046F4 12 33 FC         [24]  848 	lcall	_ak820_outline_0125
      0046F7 EA               [12]  849 	mov	a,r2
      0046F8 F0               [24]  850 	movx	@dptr,a
      0046F9                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      0046F9 75 82 00         [24]  853 	mov	dpl, #0x00
      0046FC 22               [24]  854 	ret
      0046FD                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      0046FD 90 0D C8         [24]  857 	mov	dptr,#_pending
      004700 E0               [24]  858 	movx	a,@dptr
      004701 FC               [12]  859 	mov	r4,a
      004702 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      004705 80 3B            [24]  861 	sjmp	00108$
      004707                        862 00220$:
      004707 12 38 36         [24]  863 	lcall	_ak820_outline_0032
      00470A FA               [12]  864 	mov	r2,a
      00470B A3               [24]  865 	inc	dptr
      00470C E0               [24]  866 	movx	a,@dptr
      00470D FB               [12]  867 	mov	r3,a
      00470E 90 06 3A         [24]  868 	mov	dptr,#_pending_time
      004711 12 38 7F         [24]  869 	lcall	_ak820_outline_0103
      004714 EA               [12]  870 	mov	a,r2
      004715 C3               [12]  871 	clr	c
      004716 98               [12]  872 	subb	a,r0
      004717 FA               [12]  873 	mov	r2,a
      004718 EB               [12]  874 	mov	a,r3
      004719 99               [12]  875 	subb	a,r1
      00471A FB               [12]  876 	mov	r3,a
      00471B C3               [12]  877 	clr	c
      00471C EA               [12]  878 	mov	a,r2
      00471D 94 C8            [12]  879 	subb	a,#0xc8
      00471F EB               [12]  880 	mov	a,r3
      004720 94 00            [12]  881 	subb	a,#0x00
      004722 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004724 74 04            [12]  884 	mov	a,#0x04
      004726 12 4A 99         [24]  885 	lcall	_ak820_outline_0019
      004729 60 17            [24]  886 	jz	00108$
      00472B 12 38 0F         [24]  887 	lcall	_ak820_outline_0009
      00472E 60 12            [24]  888 	jz	00108$
      004730 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      004733 80 06            [24]  890 	sjmp	00107$
      004735                        891 00224$:
      004735 ED               [12]  892 	mov	a,r5
      004736 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      004739 80 07            [24]  894 	sjmp	00108$
      00473B                        895 00225$:
      00473B                        896 00107$:
      00473B C0 05            [24]  897 	push	ar5
      00473D 12 46 7B         [24]  898 	lcall	_commit_pending
      004740 D0 05            [24]  899 	pop	ar5
      004742                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      004742 90 06 45         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_611
      004745 12 38 3E         [24]  903 	lcall	_ak820_outline_0051
      004748 12 4B 02         [24]  904 	lcall	_ak820_outline_0097
      00474B 60 03            [24]  905 	jz	00114$
      00474D BD FF 04         [24]  906 	cjne	r5,#0xff,00115$
      004750                        907 00114$:
      004750 75 82 01         [24]  908 	mov	dpl, #0x01
      004753 22               [24]  909 	ret
      004754                        910 00115$:
                                    911 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      004754 ED               [12]  912 	mov	a,r5
      004755 12 4A F4         [24]  913 	lcall	_ak820_outline_0080
      004758 30 E1 13         [24]  914 	jnb	acc.1,00120$
                                    915 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00475B 74 05            [12]  916 	mov	a,#0x05
      00475D 2E               [12]  917 	add	a, r6
      00475E 12 38 1C         [24]  918 	lcall	_ak820_outline_0016
      004761 70 07            [24]  919 	jnz	00118$
      004763 74 FD            [12]  920 	mov	a,#0xfd
      004765 5B               [12]  921 	anl	a,r3
      004766 12 38 A1         [24]  922 	lcall	_ak820_outline_0126
      004769 F0               [24]  923 	movx	@dptr,a
      00476A                        924 00118$:
                                    925 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      00476A 75 82 00         [24]  926 	mov	dpl, #0x00
      00476D 22               [24]  927 	ret
      00476E                        928 00120$:
                                    929 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      00476E 12 45 5D         [24]  930 	lcall	_ak820_outline_0011
      004771 E0               [24]  931 	movx	a,@dptr
      004772 FF               [12]  932 	mov	r7,a
      004773 8B 06            [24]  933 	mov	ar6,r3
      004775 53 06 01         [24]  934 	anl	ar6,#0x01
      004778 EE               [12]  935 	mov	a,r6
      004779 B4 01 00         [24]  936 	cjne	a,#0x01,00231$
      00477C                        937 00231$:
      00477C B3               [12]  938 	cpl	c
      00477D 92 0E            [24]  939 	mov	_ak820_tapping_before_sloc0_1_0,c
      00477F 8F F0            [24]  940 	mov	b,r7
      004781 E4               [12]  941 	clr	a
      004782 33               [12]  942 	rlc	a
      004783 B5 F0 04         [24]  943 	cjne	a,b,00122$
      004786 75 82 00         [24]  944 	mov	dpl, #0x00
      004789 22               [24]  945 	ret
      00478A                        946 00122$:
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      00478A 63 03 01         [24]  948 	xrl	ar3,#0x01
      00478D 12 38 A1         [24]  949 	lcall	_ak820_outline_0126
      004790 EB               [12]  950 	mov	a,r3
      004791 F0               [24]  951 	movx	@dptr,a
                                    952 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      004792 75 82 01         [24]  953 	mov	dpl, #0x01
                                    954 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      004795 22               [24]  955 	ret
                                    956 ;------------------------------------------------------------
                                    957 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    958 ;------------------------------------------------------------
                                    959 ;record        Allocated with name '_ak820_tapping_process_record_10000_622'
                                    960 ;id            Allocated with name '_ak820_tapping_process_id_10000_623'
                                    961 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_623'
                                    962 ;code          Allocated with name '_ak820_tapping_process_code_10000_623'
                                    963 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_623'
                                    964 ;------------------------------------------------------------
                                    965 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    966 ;	-----------------------------------------
                                    967 ;	 function ak820_tapping_process
                                    968 ;	-----------------------------------------
      004796                        969 _ak820_tapping_process:
      004796 12 38 85         [24]  970 	lcall	_ak820_outline_0108
      004799 90 06 47         [24]  971 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00479C 12 38 8A         [24]  972 	lcall	_ak820_outline_0109
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: uint8_t sc_mods = 0;
      00479F 90 06 4B         [24]  974 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0047A2 E4               [12]  975 	clr	a
      0047A3 F0               [24]  976 	movx	@dptr,a
                                    977 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      0047A4 90 06 47         [24]  978 	mov	dptr,#_ak820_tapping_process_record_10000_622
      0047A7 12 38 3E         [24]  979 	lcall	_ak820_outline_0051
      0047AA 74 04            [12]  980 	mov	a,#0x04
      0047AC 12 4A CD         [24]  981 	lcall	_ak820_outline_0033
      0047AF 70 04            [24]  982 	jnz	00102$
      0047B1 75 82 01         [24]  983 	mov	dpl, #0x01
      0047B4 22               [24]  984 	ret
      0047B5                        985 00102$:
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      0047B5 8E 04            [24]  987 	mov	ar4,r6
      0047B7 8F 05            [24]  988 	mov	ar5,r7
      0047B9 12 4A B3         [24]  989 	lcall	_ak820_outline_0025
      0047BC C0 07            [24]  990 	push	ar7
      0047BE C0 06            [24]  991 	push	ar6
      0047C0 12 BA 56         [24]  992 	lcall	___memcpy
      0047C3 12 45 E9         [24]  993 	lcall	_ak820_tapping_source
      0047C6 AD 82            [24]  994 	mov	r5, dpl
      0047C8 D0 06            [24]  995 	pop	ar6
      0047CA D0 07            [24]  996 	pop	ar7
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      0047CC BD FF 04         [24]  998 	cjne	r5,#0xff,00104$
      0047CF 75 82 01         [24]  999 	mov	dpl, #0x01
      0047D2 22               [24] 1000 	ret
      0047D3                       1001 00104$:
                                   1002 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      0047D3 74 07            [12] 1003 	mov	a,#0x07
      0047D5 12 38 2E         [24] 1004 	lcall	_ak820_outline_0023
      0047D8 12 38 3E         [24] 1005 	lcall	_ak820_outline_0051
      0047DB 90 06 49         [24] 1006 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047DE 12 4A E0         [24] 1007 	lcall	_ak820_outline_0058
                                   1008 ;	keyboards/ajazz/ak820/ak820_tapping.c:90: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      0047E1 BE 1A 15         [24] 1009 	cjne	r6,#0x1a,00111$
      0047E4 BF 7C 12         [24] 1010 	cjne	r7,#0x7c,00111$
      0047E7 90 06 49         [24] 1011 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0047EA 74 26            [12] 1012 	mov	a,#0x26
      0047EC F0               [24] 1013 	movx	@dptr,a
      0047ED 74 22            [12] 1014 	mov	a,#0x22
      0047EF A3               [24] 1015 	inc	dptr
      0047F0 F0               [24] 1016 	movx	@dptr,a
      0047F1 90 06 4B         [24] 1017 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0047F4 74 02            [12] 1018 	mov	a,#0x02
      0047F6 F0               [24] 1019 	movx	@dptr,a
      0047F7 80 28            [24] 1020 	sjmp	00112$
      0047F9                       1021 00111$:
                                   1022 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0047F9 BE 1B 15         [24] 1023 	cjne	r6,#0x1b,00108$
      0047FC BF 7C 12         [24] 1024 	cjne	r7,#0x7c,00108$
      0047FF 90 06 49         [24] 1025 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004802 74 27            [12] 1026 	mov	a,#0x27
      004804 F0               [24] 1027 	movx	@dptr,a
      004805 74 32            [12] 1028 	mov	a,#0x32
      004807 A3               [24] 1029 	inc	dptr
      004808 F0               [24] 1030 	movx	@dptr,a
      004809 90 06 4B         [24] 1031 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      00480C 74 20            [12] 1032 	mov	a,#0x20
      00480E F0               [24] 1033 	movx	@dptr,a
      00480F 80 10            [24] 1034 	sjmp	00112$
      004811                       1035 00108$:
                                   1036 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004811 BE 1E 0D         [24] 1037 	cjne	r6,#0x1e,00112$
      004814 BF 7C 0A         [24] 1038 	cjne	r7,#0x7c,00112$
      004817 90 06 49         [24] 1039 	mov	dptr,#_ak820_tapping_process_code_10000_623
      00481A 74 28            [12] 1040 	mov	a,#0x28
      00481C F0               [24] 1041 	movx	@dptr,a
      00481D 74 32            [12] 1042 	mov	a,#0x32
      00481F A3               [24] 1043 	inc	dptr
      004820 F0               [24] 1044 	movx	@dptr,a
      004821                       1045 00112$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      004821 90 06 49         [24] 1047 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004824 E0               [24] 1048 	movx	a,@dptr
      004825 A3               [24] 1049 	inc	dptr
      004826 E0               [24] 1050 	movx	a,@dptr
      004827 FF               [12] 1051 	mov	r7,a
                                   1052 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      004828 BF 20 00         [24] 1053 	cjne	r7,#0x20,00242$
      00482B                       1054 00242$:
      00482B 40 05            [24] 1055 	jc	00113$
      00482D BF 50 00         [24] 1056 	cjne	r7,#0x50,00244$
      004830                       1057 00244$:
      004830 40 04            [24] 1058 	jc	00114$
      004832                       1059 00113$:
      004832 75 82 01         [24] 1060 	mov	dpl, #0x01
      004835 22               [24] 1061 	ret
      004836                       1062 00114$:
                                   1063 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004836 BF 40 00         [24] 1064 	cjne	r7,#0x40,00246$
      004839                       1065 00246$:
      004839 40 0C            [24] 1066 	jc	00117$
      00483B 53 07 0F         [24] 1067 	anl	ar7,#0x0f
      00483E BF 06 00         [24] 1068 	cjne	r7,#0x06,00248$
      004841                       1069 00248$:
      004841 40 04            [24] 1070 	jc	00117$
      004843 75 82 00         [24] 1071 	mov	dpl, #0x00
      004846 22               [24] 1072 	ret
      004847                       1073 00117$:
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      004847 90 06 47         [24] 1075 	mov	dptr,#_ak820_tapping_process_record_10000_622
      00484A 12 38 3E         [24] 1076 	lcall	_ak820_outline_0051
      00484D 12 4A 8D         [24] 1077 	lcall	_ak820_outline_0015
      004850 E0               [24] 1078 	movx	a,@dptr
      004851 60 21            [24] 1079 	jz	00131$
                                   1080 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      004853 90 0D C8         [24] 1081 	mov	dptr,#_pending
      004856 ED               [12] 1082 	mov	a,r5
      004857 F0               [24] 1083 	movx	@dptr,a
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      004858 12 38 36         [24] 1085 	lcall	_ak820_outline_0032
      00485B FE               [12] 1086 	mov	r6,a
      00485C A3               [24] 1087 	inc	dptr
      00485D E0               [24] 1088 	movx	a,@dptr
      00485E FF               [12] 1089 	mov	r7,a
      00485F 90 06 3A         [24] 1090 	mov	dptr,#_pending_time
      004862 12 4A E0         [24] 1091 	lcall	_ak820_outline_0058
                                   1092 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      004865 90 06 49         [24] 1093 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004868 12 38 3E         [24] 1094 	lcall	_ak820_outline_0051
      00486B 90 06 3C         [24] 1095 	mov	dptr,#_pending_code
      00486E 12 4A E0         [24] 1096 	lcall	_ak820_outline_0058
      004871 02 49 24         [24] 1097 	ljmp	00132$
      004874                       1098 00131$:
                                   1099 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      004874 90 0D C8         [24] 1100 	mov	dptr,#_pending
      004877 E0               [24] 1101 	movx	a,@dptr
      004878 FF               [12] 1102 	mov	r7,a
      004879 ED               [12] 1103 	mov	a,r5
      00487A B5 07 02         [24] 1104 	cjne	a,ar7,00251$
      00487D 80 03            [24] 1105 	sjmp	00252$
      00487F                       1106 00251$:
      00487F 02 48 FD         [24] 1107 	ljmp	00128$
      004882                       1108 00252$:
                                   1109 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      004882 12 4B 16         [24] 1110 	lcall	_ak820_outline_0156
                                   1111 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: if (sc_mods) add_owned_mods(sc_mods);
      004885 90 06 4B         [24] 1112 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      004888 E0               [24] 1113 	movx	a,@dptr
      004889 FF               [12] 1114 	mov	r7,a
      00488A E0               [24] 1115 	movx	a,@dptr
      00488B 60 05            [24] 1116 	jz	00120$
      00488D 8F 82            [24] 1117 	mov	dpl, r7
      00488F 12 7E D6         [24] 1118 	lcall	_add_owned_mods
      004892                       1119 00120$:
                                   1120 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      004892 90 06 47         [24] 1121 	mov	dptr,#_ak820_tapping_process_record_10000_622
      004895 12 38 3E         [24] 1122 	lcall	_ak820_outline_0051
      004898 74 07            [12] 1123 	mov	a,#0x07
      00489A 2E               [12] 1124 	add	a, r6
      00489B FB               [12] 1125 	mov	r3,a
      00489C E4               [12] 1126 	clr	a
      00489D 3F               [12] 1127 	addc	a, r7
      00489E FC               [12] 1128 	mov	r4,a
      00489F 90 06 49         [24] 1129 	mov	dptr,#_ak820_tapping_process_code_10000_623
      0048A2 E0               [24] 1130 	movx	a,@dptr
      0048A3 F9               [12] 1131 	mov	r1,a
      0048A4 7A 00            [12] 1132 	mov	r2,#0x00
      0048A6 12 33 FC         [24] 1133 	lcall	_ak820_outline_0125
      0048A9 E9               [12] 1134 	mov	a,r1
      0048AA F0               [24] 1135 	movx	@dptr,a
      0048AB EA               [12] 1136 	mov	a,r2
      0048AC A3               [24] 1137 	inc	dptr
      0048AD F0               [24] 1138 	movx	@dptr,a
                                   1139 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      0048AE C3               [12] 1140 	clr	c
      0048AF 04               [12] 1141 	inc	a
      0048B0 99               [12] 1142 	subb	a,r1
      0048B1 50 38            [24] 1143 	jnc	00122$
                                   1144 ;	free result
                                   1145 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      0048B3 74 06            [12] 1146 	mov	a,#0x06
      0048B5 12 38 2E         [24] 1147 	lcall	_ak820_outline_0023
      0048B8 E0               [24] 1148 	movx	a,@dptr
      0048B9 54 0F            [12] 1149 	anl	a,#0x0f
      0048BB 44 10            [12] 1150 	orl	a,#0x10
      0048BD F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      0048BE 12 4A 8D         [24] 1153 	lcall	_ak820_outline_0015
      0048C1 74 01            [12] 1154 	mov	a,#0x01
      0048C3 F0               [24] 1155 	movx	@dptr,a
                                   1156 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      0048C4 12 4A E6         [24] 1157 	lcall	_ak820_outline_0076
      0048C7 12 4B 0F         [24] 1158 	lcall	_ak820_outline_0113
      0048CA C0 07            [24] 1159 	push	ar7
      0048CC C0 06            [24] 1160 	push	ar6
      0048CE C0 04            [24] 1161 	push	ar4
      0048D0 C0 03            [24] 1162 	push	ar3
      0048D2 12 73 06         [24] 1163 	lcall	_process_record
      0048D5 D0 03            [24] 1164 	pop	ar3
      0048D7 D0 04            [24] 1165 	pop	ar4
      0048D9 D0 06            [24] 1166 	pop	ar6
      0048DB D0 07            [24] 1167 	pop	ar7
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      0048DD 12 33 FC         [24] 1169 	lcall	_ak820_outline_0125
      0048E0 E4               [12] 1170 	clr	a
      0048E1 F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      0048E2 FC               [12] 1173 	mov	r4,a
      0048E3 12 38 96         [24] 1174 	lcall	_ak820_outline_0122
      0048E6 8C F0            [24] 1175 	mov	b, r4
      0048E8 12 73 06         [24] 1176 	lcall	_process_record
      0048EB                       1177 00122$:
                                   1178 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: if (sc_mods) {
      0048EB 90 06 4B         [24] 1179 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_623
      0048EE E0               [24] 1180 	movx	a,@dptr
      0048EF FF               [12] 1181 	mov	r7,a
      0048F0 E0               [24] 1182 	movx	a,@dptr
      0048F1 60 31            [24] 1183 	jz	00132$
                                   1184 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: del_owned_mods(sc_mods);
      0048F3 8F 82            [24] 1185 	mov	dpl, r7
      0048F5 12 7E E6         [24] 1186 	lcall	_del_owned_mods
                                   1187 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: send_keyboard_report();
      0048F8 12 82 10         [24] 1188 	lcall	_send_keyboard_report
      0048FB 80 27            [24] 1189 	sjmp	00132$
      0048FD                       1190 00128$:
                                   1191 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      0048FD ED               [12] 1192 	mov	a,r5
      0048FE 24 B8            [12] 1193 	add	a, #_source_state
      004900 FE               [12] 1194 	mov	r6,a
      004901 E4               [12] 1195 	clr	a
      004902 34 05            [12] 1196 	addc	a, #(_source_state >> 8)
      004904 FF               [12] 1197 	mov	r7,a
      004905 12 38 73         [24] 1198 	lcall	_ak820_outline_0100
      004908 FD               [12] 1199 	mov	r5,a
      004909 30 E2 18         [24] 1200 	jnb	acc.2,00132$
                                   1201 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      00490C 53 05 FB         [24] 1202 	anl	ar5,#0xfb
      00490F 12 38 96         [24] 1203 	lcall	_ak820_outline_0122
      004912 ED               [12] 1204 	mov	a,r5
      004913 F0               [24] 1205 	movx	@dptr,a
                                   1206 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      004914 90 06 49         [24] 1207 	mov	dptr,#_ak820_tapping_process_code_10000_623
      004917 12 38 3E         [24] 1208 	lcall	_ak820_outline_0051
      00491A 90 06 40         [24] 1209 	mov	dptr,#_hold_PARM_2
      00491D E4               [12] 1210 	clr	a
      00491E 12 45 9A         [24] 1211 	lcall	_ak820_outline_0071
      004921 12 46 23         [24] 1212 	lcall	_hold
      004924                       1213 00132$:
                                   1214 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      004924 75 82 00         [24] 1215 	mov	dpl, #0x00
                                   1216 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      004927 22               [24] 1217 	ret
                                   1218 ;------------------------------------------------------------
                                   1219 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1220 ;------------------------------------------------------------
                                   1221 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_646'
                                   1222 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_647'
                                   1223 ;------------------------------------------------------------
                                   1224 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1225 ;	-----------------------------------------
                                   1226 ;	 function ak820_tapping_cancel
                                   1227 ;	-----------------------------------------
      004928                       1228 _ak820_tapping_cancel:
                                   1229 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      004928 12 4B 16         [24] 1230 	lcall	_ak820_outline_0156
                                   1231 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      00492B 7F 00            [12] 1232 	mov	r7,#0x00
      00492D                       1233 00103$:
      00492D BF 82 00         [24] 1234 	cjne	r7,#0x82,00122$
      004930                       1235 00122$:
      004930 50 16            [24] 1236 	jnc	00105$
                                   1237 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      004932 12 4A A4         [24] 1238 	lcall	_ak820_outline_0021
                                   1239 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004935 74 02            [12] 1240 	mov	a,#0x02
      004937 5C               [12] 1241 	anl	a,r4
      004938 FB               [12] 1242 	mov	r3,a
      004939 53 04 01         [24] 1243 	anl	ar4,#0x01
      00493C EC               [12] 1244 	mov	a,r4
      00493D 2C               [12] 1245 	add	a,r4
      00493E 42 03            [12] 1246 	orl	ar3,a
      004940 12 38 AB         [24] 1247 	lcall	_ak820_outline_0137
      004943 EB               [12] 1248 	mov	a,r3
      004944 F0               [24] 1249 	movx	@dptr,a
                                   1250 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004945 0F               [12] 1251 	inc	r7
      004946 80 E5            [24] 1252 	sjmp	00103$
      004948                       1253 00105$:
                                   1254 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      004948 22               [24] 1255 	ret
                                   1256 ;------------------------------------------------------------
                                   1257 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1258 ;------------------------------------------------------------
                                   1259 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1260 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1261 ;code          Allocated with name '_ak820_oneshot_process_code_10000_648'
                                   1262 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_649'
                                   1263 ;i             Allocated with name '_ak820_oneshot_process_i_40000_663'
                                   1264 ;------------------------------------------------------------
                                   1265 ;	keyboards/ajazz/ak820/ak820_tapping.c:143: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1266 ;	-----------------------------------------
                                   1267 ;	 function ak820_oneshot_process
                                   1268 ;	-----------------------------------------
      004949                       1269 _ak820_oneshot_process:
      004949 12 38 85         [24] 1270 	lcall	_ak820_outline_0108
      00494C 90 06 50         [24] 1271 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      00494F 12 38 8A         [24] 1272 	lcall	_ak820_outline_0109
                                   1273 ;	keyboards/ajazz/ak820/ak820_tapping.c:145: if (id == NONE || get_repeat_key_count()) return true;
      004952 90 06 4E         [24] 1274 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004955 E0               [24] 1275 	movx	a,@dptr
      004956 FF               [12] 1276 	mov	r7,a
      004957 BF FF 02         [24] 1277 	cjne	r7,#0xff,00248$
      00495A 80 0B            [24] 1278 	sjmp	00101$
      00495C                       1279 00248$:
      00495C C0 07            [24] 1280 	push	ar7
      00495E 12 A4 3F         [24] 1281 	lcall	_get_repeat_key_count
      004961 E5 82            [12] 1282 	mov	a, dpl
      004963 D0 07            [24] 1283 	pop	ar7
      004965 60 04            [24] 1284 	jz	00102$
      004967                       1285 00101$:
      004967 75 82 01         [24] 1286 	mov	dpl, #0x01
      00496A 22               [24] 1287 	ret
      00496B                       1288 00102$:
                                   1289 ;	keyboards/ajazz/ak820/ak820_tapping.c:158: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      00496B 90 06 50         [24] 1290 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      00496E E0               [24] 1291 	movx	a,@dptr
      00496F FD               [12] 1292 	mov	r5,a
      004970 A3               [24] 1293 	inc	dptr
      004971 E0               [24] 1294 	movx	a,@dptr
      004972 FB               [12] 1295 	mov	r3,a
      004973 BB 52 02         [24] 1296 	cjne	r3,#0x52,00250$
      004976 80 03            [24] 1297 	sjmp	00251$
      004978                       1298 00250$:
      004978 02 4A 1D         [24] 1299 	ljmp	00116$
      00497B                       1300 00251$:
      00497B 8D 04            [24] 1301 	mov	ar4,r5
      00497D 53 04 E0         [24] 1302 	anl	ar4,#0xe0
      004980 BC A0 02         [24] 1303 	cjne	r4,#0xa0,00252$
      004983 80 03            [24] 1304 	sjmp	00253$
      004985                       1305 00252$:
      004985 02 4A 1D         [24] 1306 	ljmp	00116$
      004988                       1307 00253$:
                                   1308 ;	keyboards/ajazz/ak820/ak820_tapping.c:159: mods = code & 15;
      004988 8D 04            [24] 1309 	mov	ar4,r5
      00498A 53 04 0F         [24] 1310 	anl	ar4,#0x0f
      00498D 90 06 52         [24] 1311 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004990 EC               [12] 1312 	mov	a,r4
      004991 F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_tapping.c:160: if (code & 16) mods <<= 4;
      004992 ED               [12] 1315 	mov	a,r5
      004993 30 E4 08         [24] 1316 	jnb	acc.4,00105$
      004996 EC               [12] 1317 	mov	a,r4
      004997 C4               [12] 1318 	swap	a
      004998 54 F0            [12] 1319 	anl	a,#0xf0
      00499A 90 06 52         [24] 1320 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      00499D F0               [24] 1321 	movx	@dptr,a
      00499E                       1322 00105$:
                                   1323 ;	keyboards/ajazz/ak820/ak820_tapping.c:161: if (pressed) {
      00499E 90 06 4F         [24] 1324 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0049A1 E0               [24] 1325 	movx	a,@dptr
      0049A2 60 2D            [24] 1326 	jz	00113$
                                   1327 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: source_state[id] |= SOURCE_ONESHOT;
      0049A4 12 4A A4         [24] 1328 	lcall	_ak820_outline_0021
      0049A7 43 04 08         [24] 1329 	orl	ar4,#0x08
      0049AA 12 45 93         [24] 1330 	lcall	_ak820_outline_0063
                                   1331 ;	keyboards/ajazz/ak820/ak820_tapping.c:163: source_state[id] &= ~SOURCE_ONESHOT_USED;
      0049AD 53 04 EF         [24] 1332 	anl	ar4,#0xef
      0049B0 12 45 93         [24] 1333 	lcall	_ak820_outline_0063
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      0049B3 90 0D C9         [24] 1335 	mov	dptr,#_ak820_oneshot_target
      0049B6 E0               [24] 1336 	movx	a,@dptr
      0049B7 FC               [12] 1337 	mov	r4,a
      0049B8 BC FF 02         [24] 1338 	cjne	r4,#0xff,00256$
      0049BB 80 09            [24] 1339 	sjmp	00107$
      0049BD                       1340 00256$:
      0049BD 12 4A ED         [24] 1341 	lcall	_ak820_outline_0077
      0049C0 43 04 10         [24] 1342 	orl	ar4,#0x10
      0049C3 12 45 93         [24] 1343 	lcall	_ak820_outline_0063
      0049C6                       1344 00107$:
                                   1345 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: register_mods(mods);
      0049C6 90 06 52         [24] 1346 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      0049C9 E0               [24] 1347 	movx	a,@dptr
      0049CA F5 82            [12] 1348 	mov	dpl,a
      0049CC 12 78 65         [24] 1349 	lcall	_register_mods
      0049CF 80 48            [24] 1350 	sjmp	00114$
      0049D1                       1351 00113$:
                                   1352 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: } else if (source_state[id] & SOURCE_ONESHOT) {
      0049D1 12 4A A4         [24] 1353 	lcall	_ak820_outline_0021
      0049D4 30 E3 42         [24] 1354 	jnb	acc.3,00114$
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      0049D7 EC               [12] 1356 	mov	a,r4
      0049D8 20 E4 24         [24] 1357 	jb	acc.4,00109$
                                   1358 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: add_owned_mods(mods & ~ak820_oneshot_mods);
      0049DB 90 06 4C         [24] 1359 	mov	dptr,#_ak820_oneshot_mods
      0049DE E0               [24] 1360 	movx	a,@dptr
      0049DF F4               [12] 1361 	cpl	a
      0049E0 FC               [12] 1362 	mov	r4,a
      0049E1 90 06 52         [24] 1363 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      0049E4 E0               [24] 1364 	movx	a,@dptr
      0049E5 FB               [12] 1365 	mov	r3,a
      0049E6 52 04            [12] 1366 	anl	ar4,a
      0049E8 8C 82            [24] 1367 	mov	dpl, r4
      0049EA C0 06            [24] 1368 	push	ar6
      0049EC C0 05            [24] 1369 	push	ar5
      0049EE C0 03            [24] 1370 	push	ar3
      0049F0 12 7E D6         [24] 1371 	lcall	_add_owned_mods
      0049F3 D0 03            [24] 1372 	pop	ar3
      0049F5 D0 05            [24] 1373 	pop	ar5
      0049F7 D0 06            [24] 1374 	pop	ar6
                                   1375 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: ak820_oneshot_mods |= mods;
      0049F9 90 06 4C         [24] 1376 	mov	dptr,#_ak820_oneshot_mods
      0049FC E0               [24] 1377 	movx	a,@dptr
      0049FD 4B               [12] 1378 	orl	a,r3
      0049FE F0               [24] 1379 	movx	@dptr,a
      0049FF                       1380 00109$:
                                   1381 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: unregister_mods(mods);
      0049FF 90 06 52         [24] 1382 	mov	dptr,#_ak820_oneshot_process_mods_10000_649
      004A02 E0               [24] 1383 	movx	a,@dptr
      004A03 F5 82            [12] 1384 	mov	dpl,a
      004A05 C0 06            [24] 1385 	push	ar6
      004A07 C0 05            [24] 1386 	push	ar5
      004A09 12 78 79         [24] 1387 	lcall	_unregister_mods
      004A0C D0 05            [24] 1388 	pop	ar5
      004A0E D0 06            [24] 1389 	pop	ar6
                                   1390 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004A10 12 4A ED         [24] 1391 	lcall	_ak820_outline_0077
      004A13 53 04 E7         [24] 1392 	anl	ar4,#0xe7
      004A16 12 45 93         [24] 1393 	lcall	_ak820_outline_0063
      004A19                       1394 00114$:
                                   1395 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: return false;
      004A19 75 82 00         [24] 1396 	mov	dpl, #0x00
      004A1C 22               [24] 1397 	ret
      004A1D                       1398 00116$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_tapping.c:176: if (pressed && code > KC_TRANSPARENT &&
      004A1D 90 06 4F         [24] 1400 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004A20 E0               [24] 1401 	movx	a,@dptr
      004A21 60 5C            [24] 1402 	jz	00124$
      004A23 90 06 50         [24] 1403 	mov	dptr,#_ak820_oneshot_process_code_10000_648
      004A26 12 38 61         [24] 1404 	lcall	_ak820_outline_0079
      004A29 C3               [12] 1405 	clr	c
      004A2A 74 01            [12] 1406 	mov	a,#0x01
      004A2C 9D               [12] 1407 	subb	a,r5
      004A2D E4               [12] 1408 	clr	a
      004A2E 9E               [12] 1409 	subb	a,r6
      004A2F 50 4E            [24] 1410 	jnc	00124$
                                   1411 ;	free result
                                   1412 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004A31 C3               [12] 1413 	clr	c
      004A32 ED               [12] 1414 	mov	a,r5
      004A33 94 E0            [12] 1415 	subb	a,#0xe0
      004A35 EE               [12] 1416 	mov	a,r6
      004A36 94 00            [12] 1417 	subb	a,#0x00
      004A38 40 07            [24] 1418 	jc	00129$
      004A3A 74 E7            [12] 1419 	mov	a,#0xe7
      004A3C 9D               [12] 1420 	subb	a,r5
      004A3D E4               [12] 1421 	clr	a
      004A3E 9E               [12] 1422 	subb	a,r6
      004A3F 50 3E            [24] 1423 	jnc	00124$
                                   1424 ;	free result
      004A41                       1425 00129$:
                                   1426 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004A41 74 AE            [12] 1427 	mov	a,#0x100 - 0x52
      004A43 2E               [12] 1428 	add	a,r6
      004A44 50 09            [24] 1429 	jnc	00165$
      004A46 C3               [12] 1430 	clr	c
      004A47 74 DF            [12] 1431 	mov	a,#0xdf
      004A49 9D               [12] 1432 	subb	a,r5
      004A4A 74 52            [12] 1433 	mov	a,#0x52
      004A4C 9E               [12] 1434 	subb	a,r6
      004A4D 50 30            [24] 1435 	jnc	00124$
                                   1436 ;	free result
                                   1437 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: for (uint8_t i = 0; i < SOURCES; ++i)
      004A4F                       1438 00165$:
      004A4F 7E 00            [12] 1439 	mov	r6,#0x00
      004A51                       1440 00131$:
      004A51 BE 82 00         [24] 1441 	cjne	r6,#0x82,00265$
      004A54                       1442 00265$:
      004A54 50 12            [24] 1443 	jnc	00120$
                                   1444 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004A56 EE               [12] 1445 	mov	a,r6
      004A57 12 4A F4         [24] 1446 	lcall	_ak820_outline_0080
      004A5A 30 E3 08         [24] 1447 	jnb	acc.3,00132$
      004A5D 43 03 10         [24] 1448 	orl	ar3,#0x10
      004A60 12 38 A1         [24] 1449 	lcall	_ak820_outline_0126
      004A63 EB               [12] 1450 	mov	a,r3
      004A64 F0               [24] 1451 	movx	@dptr,a
      004A65                       1452 00132$:
                                   1453 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: for (uint8_t i = 0; i < SOURCES; ++i)
      004A65 0E               [12] 1454 	inc	r6
      004A66 80 E9            [24] 1455 	sjmp	00131$
      004A68                       1456 00120$:
                                   1457 ;	keyboards/ajazz/ak820/ak820_tapping.c:181: if (ak820_oneshot_mods) {
      004A68 90 06 4C         [24] 1458 	mov	dptr,#_ak820_oneshot_mods
      004A6B E0               [24] 1459 	movx	a,@dptr
      004A6C FE               [12] 1460 	mov	r6,a
      004A6D E0               [24] 1461 	movx	a,@dptr
      004A6E 60 0F            [24] 1462 	jz	00124$
                                   1463 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: ak820_oneshot_consumed = ak820_oneshot_mods;
      004A70 90 06 4D         [24] 1464 	mov	dptr,#_ak820_oneshot_consumed
      004A73 EE               [12] 1465 	mov	a,r6
      004A74 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: ak820_oneshot_target = id;
      004A75 90 0D C9         [24] 1468 	mov	dptr,#_ak820_oneshot_target
      004A78 EF               [12] 1469 	mov	a,r7
      004A79 F0               [24] 1470 	movx	@dptr,a
                                   1471 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: ak820_oneshot_mods = 0;
      004A7A 90 06 4C         [24] 1472 	mov	dptr,#_ak820_oneshot_mods
      004A7D E4               [12] 1473 	clr	a
      004A7E F0               [24] 1474 	movx	@dptr,a
      004A7F                       1475 00124$:
                                   1476 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: return true;
      004A7F 75 82 01         [24] 1477 	mov	dpl, #0x01
                                   1478 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: }
      004A82 22               [24] 1479 	ret
                                   1480 	.area CSEG    (CODE)
                                   1481 	.area CONST   (CODE)
                                   1482 	.area XINIT   (CODE)
      00C317                       1483 __xinit__pending:
      00C317 FF                    1484 	.db #0xff	; 255
      00C318                       1485 __xinit__ak820_oneshot_target:
      00C318 FF                    1486 	.db #0xff	; 255
                                   1487 	.area CABS    (ABS,CODE)
                                   1488 
                                   1489 ; Experimental exact instruction outlining.
                                   1490 	.globl _ak820_outline_0008
                                   1491 	.globl _ak820_outline_0009
                                   1492 	.globl _ak820_outline_0011
                                   1493 	.globl _ak820_outline_0015
                                   1494 	.globl _ak820_outline_0016
                                   1495 	.globl _ak820_outline_0019
                                   1496 	.globl _ak820_outline_0021
                                   1497 	.globl _ak820_outline_0023
                                   1498 	.globl _ak820_outline_0025
                                   1499 	.globl _ak820_outline_0032
                                   1500 	.globl _ak820_outline_0033
                                   1501 	.globl _ak820_outline_0051
                                   1502 	.globl _ak820_outline_0055
                                   1503 	.globl _ak820_outline_0058
                                   1504 	.globl _ak820_outline_0063
                                   1505 	.globl _ak820_outline_0071
                                   1506 	.globl _ak820_outline_0076
                                   1507 	.globl _ak820_outline_0077
                                   1508 	.globl _ak820_outline_0079
                                   1509 	.globl _ak820_outline_0080
                                   1510 	.globl _ak820_outline_0097
                                   1511 	.globl _ak820_outline_0100
                                   1512 	.globl _ak820_outline_0103
                                   1513 	.globl _ak820_outline_0108
                                   1514 	.globl _ak820_outline_0109
                                   1515 	.globl _ak820_outline_0113
                                   1516 	.globl _ak820_outline_0122
                                   1517 	.globl _ak820_outline_0125
                                   1518 	.globl _ak820_outline_0126
                                   1519 	.globl _ak820_outline_0137
                                   1520 	.globl _ak820_outline_0156
                                   1521 	.globl _ak820_outline_0160
                                   1522 	.globl _ak820_outline_0192
                                   1523 
                                   1524 	.area CSEG (CODE)
                                   1525 ; function ak820_outline_0008
      004A83                       1526 _ak820_outline_0008:
      004A83 E0               [24] 1527 	movx	a,@dptr
      004A84 FE               [12] 1528 	mov	r6,a
      004A85 A3               [24] 1529 	inc	dptr
      004A86 E0               [24] 1530 	movx	a,@dptr
      004A87 FF               [12] 1531 	mov	r7,a
      004A88 8E 04            [24] 1532 	mov	ar4,r6
      004A8A 8F 05            [24] 1533 	mov	ar5,r7
      004A8C 22               [24] 1534 	ret
                                   1535 
                                   1536 	.area CSEG (CODE)
                                   1537 ; function ak820_outline_0015
      004A8D                       1538 _ak820_outline_0015:
      004A8D 74 05            [12] 1539 	mov	a,#0x05
      004A8F 2E               [12] 1540 	add	a,r6
      004A90 FB               [12] 1541 	mov	r3,a
      004A91 E4               [12] 1542 	clr	a
      004A92 3F               [12] 1543 	addc	a,r7
      004A93 FC               [12] 1544 	mov	r4,a
      004A94 8B 82            [24] 1545 	mov	dpl,r3
      004A96 8C 83            [24] 1546 	mov	dph,r4
      004A98 22               [24] 1547 	ret
                                   1548 
                                   1549 	.area CSEG (CODE)
                                   1550 ; function ak820_outline_0019
      004A99                       1551 _ak820_outline_0019:
      004A99 2E               [12] 1552 	add	a,r6
      004A9A FA               [12] 1553 	mov	r2,a
      004A9B E4               [12] 1554 	clr	a
      004A9C 3F               [12] 1555 	addc	a,r7
      004A9D FB               [12] 1556 	mov	r3,a
      004A9E 8A 82            [24] 1557 	mov	dpl,r2
      004AA0 8B 83            [24] 1558 	mov	dph,r3
      004AA2 E0               [24] 1559 	movx	a,@dptr
      004AA3 22               [24] 1560 	ret
                                   1561 
                                   1562 	.area CSEG (CODE)
                                   1563 ; function ak820_outline_0021
      004AA4                       1564 _ak820_outline_0021:
      004AA4 EF               [12] 1565 	mov	a,r7
      004AA5 24 B8            [12] 1566 	add	a,#_source_state
      004AA7 FD               [12] 1567 	mov	r5,a
      004AA8 E4               [12] 1568 	clr	a
      004AA9 34 05            [12] 1569 	addc	a,#(_source_state>>8)
      004AAB FE               [12] 1570 	mov	r6,a
      004AAC 8D 82            [24] 1571 	mov	dpl,r5
      004AAE 8E 83            [24] 1572 	mov	dph,r6
      004AB0 E0               [24] 1573 	movx	a,@dptr
      004AB1 FC               [12] 1574 	mov	r4,a
      004AB2 22               [24] 1575 	ret
                                   1576 
                                   1577 	.area CSEG (CODE)
                                   1578 ; function ak820_outline_0025
      004AB3                       1579 _ak820_outline_0025:
      004AB3 90 0D B7         [24] 1580 	mov	dptr,#___memcpy_PARM_2
      004AB6 EC               [12] 1581 	mov	a,r4
      004AB7 F0               [24] 1582 	movx	@dptr,a
      004AB8 ED               [12] 1583 	mov	a,r5
      004AB9 A3               [24] 1584 	inc	dptr
      004ABA F0               [24] 1585 	movx	@dptr,a
      004ABB E4               [12] 1586 	clr	a
      004ABC A3               [24] 1587 	inc	dptr
      004ABD F0               [24] 1588 	movx	@dptr,a
      004ABE 90 0D BA         [24] 1589 	mov	dptr,#___memcpy_PARM_3
      004AC1 74 02            [12] 1590 	mov	a,#0x02
      004AC3 F0               [24] 1591 	movx	@dptr,a
      004AC4 E4               [12] 1592 	clr	a
      004AC5 A3               [24] 1593 	inc	dptr
      004AC6 F0               [24] 1594 	movx	@dptr,a
      004AC7 90 06 3E         [24] 1595 	mov	dptr,#_ak820_tapping_source_PARM_1
      004ACA F5 F0            [12] 1596 	mov	b,a
      004ACC 22               [24] 1597 	ret
                                   1598 
                                   1599 	.area CSEG (CODE)
                                   1600 ; function ak820_outline_0033
      004ACD                       1601 _ak820_outline_0033:
      004ACD 2E               [12] 1602 	add	a,r6
      004ACE FC               [12] 1603 	mov	r4,a
      004ACF E4               [12] 1604 	clr	a
      004AD0 3F               [12] 1605 	addc	a,r7
      004AD1 FD               [12] 1606 	mov	r5,a
      004AD2 8C 82            [24] 1607 	mov	dpl,r4
      004AD4 8D 83            [24] 1608 	mov	dph,r5
      004AD6 E0               [24] 1609 	movx	a,@dptr
      004AD7 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0055
      004AD8                       1614 _ak820_outline_0055:
      004AD8 FC               [12] 1615 	mov	r4,a
      004AD9 8B 82            [24] 1616 	mov	dpl,r3
      004ADB 8C 83            [24] 1617 	mov	dph,r4
      004ADD E0               [24] 1618 	movx	a,@dptr
      004ADE FA               [12] 1619 	mov	r2,a
      004ADF 22               [24] 1620 	ret
                                   1621 
                                   1622 	.area CSEG (CODE)
                                   1623 ; function ak820_outline_0058
      004AE0                       1624 _ak820_outline_0058:
      004AE0 EE               [12] 1625 	mov	a,r6
      004AE1 F0               [24] 1626 	movx	@dptr,a
      004AE2 EF               [12] 1627 	mov	a,r7
      004AE3 A3               [24] 1628 	inc	dptr
      004AE4 F0               [24] 1629 	movx	@dptr,a
      004AE5 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0076
      004AE6                       1634 _ak820_outline_0076:
      004AE6 8E 00            [24] 1635 	mov	ar0,r6
      004AE8 8F 01            [24] 1636 	mov	ar1,r7
      004AEA 7A 00            [12] 1637 	mov	r2,#0x00
      004AEC 22               [24] 1638 	ret
                                   1639 
                                   1640 	.area CSEG (CODE)
                                   1641 ; function ak820_outline_0077
      004AED                       1642 _ak820_outline_0077:
      004AED 8D 82            [24] 1643 	mov	dpl,r5
      004AEF 8E 83            [24] 1644 	mov	dph,r6
      004AF1 E0               [24] 1645 	movx	a,@dptr
      004AF2 FC               [12] 1646 	mov	r4,a
      004AF3 22               [24] 1647 	ret
                                   1648 
                                   1649 	.area CSEG (CODE)
                                   1650 ; function ak820_outline_0080
      004AF4                       1651 _ak820_outline_0080:
      004AF4 24 B8            [12] 1652 	add	a,#_source_state
      004AF6 FC               [12] 1653 	mov	r4,a
      004AF7 E4               [12] 1654 	clr	a
      004AF8 34 05            [12] 1655 	addc	a,#(_source_state>>8)
      004AFA FD               [12] 1656 	mov	r5,a
      004AFB 8C 82            [24] 1657 	mov	dpl,r4
      004AFD 8D 83            [24] 1658 	mov	dph,r5
      004AFF E0               [24] 1659 	movx	a,@dptr
      004B00 FB               [12] 1660 	mov	r3,a
      004B01 22               [24] 1661 	ret
                                   1662 
                                   1663 	.area CSEG (CODE)
                                   1664 ; function ak820_outline_0097
      004B02                       1665 _ak820_outline_0097:
      004B02 74 04            [12] 1666 	mov	a,#0x04
      004B04 2E               [12] 1667 	add	a,r6
      004B05 FB               [12] 1668 	mov	r3,a
      004B06 E4               [12] 1669 	clr	a
      004B07 3F               [12] 1670 	addc	a,r7
      004B08 FC               [12] 1671 	mov	r4,a
      004B09 8B 82            [24] 1672 	mov	dpl,r3
      004B0B 8C 83            [24] 1673 	mov	dph,r4
      004B0D E0               [24] 1674 	movx	a,@dptr
      004B0E 22               [24] 1675 	ret
                                   1676 
                                   1677 	.area CSEG (CODE)
                                   1678 ; function ak820_outline_0113
      004B0F                       1679 _ak820_outline_0113:
      004B0F 88 82            [24] 1680 	mov	dpl,r0
      004B11 89 83            [24] 1681 	mov	dph,r1
      004B13 8A F0            [24] 1682 	mov	b,r2
      004B15 22               [24] 1683 	ret
                                   1684 
                                   1685 	.area CSEG (CODE)
                                   1686 ; function ak820_outline_0156
      004B16                       1687 _ak820_outline_0156:
      004B16 90 0D C8         [24] 1688 	mov	dptr,#_pending
      004B19 74 FF            [12] 1689 	mov	a,#0xff
      004B1B F0               [24] 1690 	movx	@dptr,a
      004B1C 22               [24] 1691 	ret
