                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _ak820_combo_tick
                                     18 	.globl _ak820_leader_process
                                     19 	.globl _process_repeat_key
                                     20 	.globl _process_last_key
                                     21 	.globl _process_caps_word
                                     22 	.globl _process_record_via
                                     23 	.globl _mcu_reset
                                     24 	.globl _bootloader_jump
                                     25 	.globl _ak820_resolve_key
                                     26 	.globl _default_layer_set
                                     27 	.globl _clear_keyboard
                                     28 	.globl _unregister_weak_mods
                                     29 	.globl _register_weak_mods
                                     30 	.globl _unregister_mods
                                     31 	.globl _register_mods
                                     32 	.globl _unregister_code
                                     33 	.globl _register_code
                                     34 	.globl _eeconfig_disable
                                     35 	.globl _rgb_matrix_set_suspend_state
                                     36 	.globl _rgb_matrix_task
                                     37 	.globl _mDelaymS
                                     38 	.globl _ADC_START
                                     39 	.globl _S0_R_FIFO
                                     40 	.globl _S0_T_FIFO
                                     41 	.globl _S0_FREE
                                     42 	.globl _S0_IF_BYTE
                                     43 	.globl _S0_IF_FIRST
                                     44 	.globl _S0_IF_OV
                                     45 	.globl _S0_FST_ACT
                                     46 	.globl _CP_RL2
                                     47 	.globl _C_T2
                                     48 	.globl _TR2
                                     49 	.globl _EXEN2
                                     50 	.globl _TCLK
                                     51 	.globl _RCLK
                                     52 	.globl _EXF2
                                     53 	.globl _CAP1F
                                     54 	.globl _TF2
                                     55 	.globl _RI
                                     56 	.globl _TI
                                     57 	.globl _RB8
                                     58 	.globl _TB8
                                     59 	.globl _REN
                                     60 	.globl _SM2
                                     61 	.globl _SM1
                                     62 	.globl _SM0
                                     63 	.globl _IT0
                                     64 	.globl _IE0
                                     65 	.globl _IT1
                                     66 	.globl _IE1
                                     67 	.globl _TR0
                                     68 	.globl _TF0
                                     69 	.globl _TR1
                                     70 	.globl _TF1
                                     71 	.globl _P4_0
                                     72 	.globl _P4_1
                                     73 	.globl _P4_2
                                     74 	.globl _P4_3
                                     75 	.globl _P4_4
                                     76 	.globl _P4_5
                                     77 	.globl _P4_6
                                     78 	.globl _RXD
                                     79 	.globl _TXD
                                     80 	.globl _INT0
                                     81 	.globl _INT1
                                     82 	.globl _T0
                                     83 	.globl _T1
                                     84 	.globl _MOSI1
                                     85 	.globl _MISO1
                                     86 	.globl _SCK1
                                     87 	.globl _P3_0
                                     88 	.globl _P3_1
                                     89 	.globl _P3_2
                                     90 	.globl _P3_3
                                     91 	.globl _P3_4
                                     92 	.globl _P3_5
                                     93 	.globl _P3_6
                                     94 	.globl _P3_7
                                     95 	.globl _CAP1_
                                     96 	.globl _T2_
                                     97 	.globl _CAP2_
                                     98 	.globl _T2EX_
                                     99 	.globl _RXD1
                                    100 	.globl _TXD1
                                    101 	.globl _P2_0
                                    102 	.globl _P2_1
                                    103 	.globl _P2_2
                                    104 	.globl _P2_3
                                    105 	.globl _P2_4
                                    106 	.globl _P2_5
                                    107 	.globl _P2_6
                                    108 	.globl _P2_7
                                    109 	.globl _AIN0
                                    110 	.globl _AIN1
                                    111 	.globl _AIN2
                                    112 	.globl _AIN3
                                    113 	.globl _AIN4
                                    114 	.globl _AIN5
                                    115 	.globl _AIN6
                                    116 	.globl _AIN7
                                    117 	.globl _CAP1
                                    118 	.globl _T2
                                    119 	.globl _CAP2
                                    120 	.globl _T2EX
                                    121 	.globl _INT0_
                                    122 	.globl _SCS
                                    123 	.globl _MOSI
                                    124 	.globl _MISO
                                    125 	.globl _SCK
                                    126 	.globl _RXD1_
                                    127 	.globl _TXD1_
                                    128 	.globl _P1_0
                                    129 	.globl _P1_1
                                    130 	.globl _P1_2
                                    131 	.globl _P1_3
                                    132 	.globl _P1_4
                                    133 	.globl _P1_5
                                    134 	.globl _P1_6
                                    135 	.globl _P1_7
                                    136 	.globl _AIN8
                                    137 	.globl _AIN9
                                    138 	.globl _AIN10
                                    139 	.globl _AIN11
                                    140 	.globl _AIN12
                                    141 	.globl _AIN13
                                    142 	.globl _RXD_
                                    143 	.globl _TXD_
                                    144 	.globl _SCL0
                                    145 	.globl _SDA0
                                    146 	.globl _P0_0
                                    147 	.globl _P0_1
                                    148 	.globl _P0_2
                                    149 	.globl _P0_3
                                    150 	.globl _P0_4
                                    151 	.globl _P0_5
                                    152 	.globl _P0_6
                                    153 	.globl _P0_7
                                    154 	.globl _IE_SPI0
                                    155 	.globl _IE_USB
                                    156 	.globl _IE_ADC
                                    157 	.globl _IE_UART1
                                    158 	.globl _IE_PWM_I2C
                                    159 	.globl _IE_GPIO
                                    160 	.globl _IE_WDOG
                                    161 	.globl _PX0
                                    162 	.globl _PT0
                                    163 	.globl _PX1
                                    164 	.globl _PT1
                                    165 	.globl _PS
                                    166 	.globl _PT2
                                    167 	.globl _PL_FLAG
                                    168 	.globl _PH_FLAG
                                    169 	.globl _EX0
                                    170 	.globl _ET0
                                    171 	.globl _EX1
                                    172 	.globl _ET1
                                    173 	.globl _ES
                                    174 	.globl _ET2
                                    175 	.globl _E_DIS
                                    176 	.globl _EA
                                    177 	.globl _P
                                    178 	.globl _F1
                                    179 	.globl _OV
                                    180 	.globl _RS0
                                    181 	.globl _RS1
                                    182 	.globl _F0
                                    183 	.globl _AC
                                    184 	.globl _CY
                                    185 	.globl _I2CS_INT_ST
                                    186 	.globl _I2CX_INT
                                    187 	.globl _LED_STATUS
                                    188 	.globl _LED_DMA_H
                                    189 	.globl _LED_DMA_L
                                    190 	.globl _LED_DMA
                                    191 	.globl _LED_PWM_OE
                                    192 	.globl _LED_COMMON
                                    193 	.globl _ADC_CHAN
                                    194 	.globl _ADC_DAT_H
                                    195 	.globl _ADC_DAT_L
                                    196 	.globl _ADC_DAT
                                    197 	.globl _ADC_CTRL
                                    198 	.globl _SPI1_CK_SE
                                    199 	.globl _SPI1_CTRL
                                    200 	.globl _SPI1_DATA
                                    201 	.globl _SPI1_STAT
                                    202 	.globl _SIF1
                                    203 	.globl _SBAUD1
                                    204 	.globl _SBUF1
                                    205 	.globl _SCON1
                                    206 	.globl _SPI0_SETUP
                                    207 	.globl _SPI0_CK_SE
                                    208 	.globl _SPI0_CTRL
                                    209 	.globl _SPI0_DATA
                                    210 	.globl _SPI0_STAT
                                    211 	.globl _T2CAP1H
                                    212 	.globl _T2CAP1L
                                    213 	.globl _T2CAP1
                                    214 	.globl _TH2
                                    215 	.globl _TL2
                                    216 	.globl _T2COUNT
                                    217 	.globl _RCAP2H
                                    218 	.globl _RCAP2L
                                    219 	.globl _RCAP2
                                    220 	.globl _T2MOD
                                    221 	.globl _T2CON
                                    222 	.globl _SBUF
                                    223 	.globl _SCON
                                    224 	.globl _TH1
                                    225 	.globl _TH0
                                    226 	.globl _TL1
                                    227 	.globl _TL0
                                    228 	.globl _TMOD
                                    229 	.globl _TCON
                                    230 	.globl _XBUS_AUX
                                    231 	.globl _P7
                                    232 	.globl _P6_DIR
                                    233 	.globl _P6_OUT_PU
                                    234 	.globl _P6_IN
                                    235 	.globl _P5_DIR
                                    236 	.globl _P5_OUT_PU
                                    237 	.globl _P5_IN
                                    238 	.globl _P4_LED_KEY
                                    239 	.globl _P4_DIR_PU
                                    240 	.globl _P4_MOD_OC
                                    241 	.globl _P4
                                    242 	.globl _P3_DIR_PU
                                    243 	.globl _P3_MOD_OC
                                    244 	.globl _P3
                                    245 	.globl _P2_DIR_PU
                                    246 	.globl _P2_MOD_OC
                                    247 	.globl _P2
                                    248 	.globl _P1_DIR_PU
                                    249 	.globl _P1_MOD_OC
                                    250 	.globl _P1
                                    251 	.globl _P0_DIR_PU
                                    252 	.globl _P0_MOD_OC
                                    253 	.globl _P0
                                    254 	.globl _ROM_CTRL
                                    255 	.globl _ROM_DATA_HH
                                    256 	.globl _ROM_DATA_HL
                                    257 	.globl _ROM_DATA_HI
                                    258 	.globl _ROM_ADDR_H
                                    259 	.globl _ROM_ADDR_L
                                    260 	.globl _ROM_ADDR
                                    261 	.globl _GPIO_IE
                                    262 	.globl _IP_EX
                                    263 	.globl _IE_EX
                                    264 	.globl _IP
                                    265 	.globl _IE
                                    266 	.globl _WDOG_COUNT
                                    267 	.globl _RESET_KEEP
                                    268 	.globl _WAKE_CTRL
                                    269 	.globl _CLOCK_CFG
                                    270 	.globl _POWER_CFG
                                    271 	.globl _PCON
                                    272 	.globl _GLOBAL_CFG
                                    273 	.globl _SAFE_MOD
                                    274 	.globl _DPH
                                    275 	.globl _DPL
                                    276 	.globl _SP
                                    277 	.globl _A_INV
                                    278 	.globl _B
                                    279 	.globl _ACC
                                    280 	.globl _PSW
                                    281 	.globl _process_record_quantum_helper_PARM_2
                                    282 	.globl _get_record_keycode_PARM_2
                                    283 	.globl _post_process_record_user_PARM_2
                                    284 	.globl _post_process_record_kb_PARM_2
                                    285 	.globl _process_record_user_PARM_2
                                    286 	.globl _process_record_kb_PARM_2
                                    287 	.globl _pre_process_record_user_PARM_2
                                    288 	.globl _pre_process_record_kb_PARM_2
                                    289 	.globl _register_code16
                                    290 	.globl _unregister_code16
                                    291 	.globl _pre_process_record_kb
                                    292 	.globl _pre_process_record_user
                                    293 	.globl _process_action_kb
                                    294 	.globl _process_record_kb
                                    295 	.globl _process_record_user
                                    296 	.globl _post_process_record_kb
                                    297 	.globl _post_process_record_user
                                    298 	.globl _reset_keyboard
                                    299 	.globl _soft_reset_keyboard
                                    300 	.globl _get_record_keycode
                                    301 	.globl _pre_process_record_quantum
                                    302 	.globl _post_process_record_quantum
                                    303 	.globl _process_record_quantum
                                    304 	.globl _process_record_quantum_helper
                                    305 	.globl _shutdown_user
                                    306 ;--------------------------------------------------------
                                    307 ; special function registers
                                    308 ;--------------------------------------------------------
                                    309 	.area RSEG    (ABS,DATA)
      000000                        310 	.org 0x0000
                           0000D0   311 _PSW	=	0x00d0
                           0000E0   312 _ACC	=	0x00e0
                           0000F0   313 _B	=	0x00f0
                           0000FD   314 _A_INV	=	0x00fd
                           000081   315 _SP	=	0x0081
                           000082   316 _DPL	=	0x0082
                           000083   317 _DPH	=	0x0083
                           0000A1   318 _SAFE_MOD	=	0x00a1
                           0000B1   319 _GLOBAL_CFG	=	0x00b1
                           000087   320 _PCON	=	0x0087
                           0000BA   321 _POWER_CFG	=	0x00ba
                           0000B9   322 _CLOCK_CFG	=	0x00b9
                           0000A9   323 _WAKE_CTRL	=	0x00a9
                           0000FE   324 _RESET_KEEP	=	0x00fe
                           0000FF   325 _WDOG_COUNT	=	0x00ff
                           0000A8   326 _IE	=	0x00a8
                           0000B8   327 _IP	=	0x00b8
                           0000E8   328 _IE_EX	=	0x00e8
                           0000E9   329 _IP_EX	=	0x00e9
                           0000B2   330 _GPIO_IE	=	0x00b2
                           008584   331 _ROM_ADDR	=	0x8584
                           000084   332 _ROM_ADDR_L	=	0x0084
                           000085   333 _ROM_ADDR_H	=	0x0085
                           008F8E   334 _ROM_DATA_HI	=	0x8f8e
                           00008E   335 _ROM_DATA_HL	=	0x008e
                           00008F   336 _ROM_DATA_HH	=	0x008f
                           000086   337 _ROM_CTRL	=	0x0086
                           000080   338 _P0	=	0x0080
                           0000C4   339 _P0_MOD_OC	=	0x00c4
                           0000C5   340 _P0_DIR_PU	=	0x00c5
                           000090   341 _P1	=	0x0090
                           000092   342 _P1_MOD_OC	=	0x0092
                           000093   343 _P1_DIR_PU	=	0x0093
                           0000A0   344 _P2	=	0x00a0
                           000094   345 _P2_MOD_OC	=	0x0094
                           000095   346 _P2_DIR_PU	=	0x0095
                           0000B0   347 _P3	=	0x00b0
                           000096   348 _P3_MOD_OC	=	0x0096
                           000097   349 _P3_DIR_PU	=	0x0097
                           0000C0   350 _P4	=	0x00c0
                           0000C2   351 _P4_MOD_OC	=	0x00c2
                           0000C3   352 _P4_DIR_PU	=	0x00c3
                           0000C1   353 _P4_LED_KEY	=	0x00c1
                           0000AA   354 _P5_IN	=	0x00aa
                           0000AB   355 _P5_OUT_PU	=	0x00ab
                           0000AC   356 _P5_DIR	=	0x00ac
                           0000AD   357 _P6_IN	=	0x00ad
                           0000AE   358 _P6_OUT_PU	=	0x00ae
                           0000AF   359 _P6_DIR	=	0x00af
                           0000F1   360 _P7	=	0x00f1
                           0000A2   361 _XBUS_AUX	=	0x00a2
                           000088   362 _TCON	=	0x0088
                           000089   363 _TMOD	=	0x0089
                           00008A   364 _TL0	=	0x008a
                           00008B   365 _TL1	=	0x008b
                           00008C   366 _TH0	=	0x008c
                           00008D   367 _TH1	=	0x008d
                           000098   368 _SCON	=	0x0098
                           000099   369 _SBUF	=	0x0099
                           0000C8   370 _T2CON	=	0x00c8
                           0000C9   371 _T2MOD	=	0x00c9
                           00CBCA   372 _RCAP2	=	0xcbca
                           0000CA   373 _RCAP2L	=	0x00ca
                           0000CB   374 _RCAP2H	=	0x00cb
                           00CDCC   375 _T2COUNT	=	0xcdcc
                           0000CC   376 _TL2	=	0x00cc
                           0000CD   377 _TH2	=	0x00cd
                           00CFCE   378 _T2CAP1	=	0xcfce
                           0000CE   379 _T2CAP1L	=	0x00ce
                           0000CF   380 _T2CAP1H	=	0x00cf
                           0000F8   381 _SPI0_STAT	=	0x00f8
                           0000F9   382 _SPI0_DATA	=	0x00f9
                           0000FA   383 _SPI0_CTRL	=	0x00fa
                           0000FB   384 _SPI0_CK_SE	=	0x00fb
                           0000FC   385 _SPI0_SETUP	=	0x00fc
                           0000BC   386 _SCON1	=	0x00bc
                           0000BD   387 _SBUF1	=	0x00bd
                           0000BE   388 _SBAUD1	=	0x00be
                           0000BF   389 _SIF1	=	0x00bf
                           0000B4   390 _SPI1_STAT	=	0x00b4
                           0000B5   391 _SPI1_DATA	=	0x00b5
                           0000B6   392 _SPI1_CTRL	=	0x00b6
                           0000B7   393 _SPI1_CK_SE	=	0x00b7
                           0000F3   394 _ADC_CTRL	=	0x00f3
                           00F5F4   395 _ADC_DAT	=	0xf5f4
                           0000F4   396 _ADC_DAT_L	=	0x00f4
                           0000F5   397 _ADC_DAT_H	=	0x00f5
                           0000F6   398 _ADC_CHAN	=	0x00f6
                           0000A6   399 _LED_COMMON	=	0x00a6
                           0000A7   400 _LED_PWM_OE	=	0x00a7
                           00C7C6   401 _LED_DMA	=	0xc7c6
                           0000C6   402 _LED_DMA_L	=	0x00c6
                           0000C7   403 _LED_DMA_H	=	0x00c7
                           0000F7   404 _LED_STATUS	=	0x00f7
                           0000B3   405 _I2CX_INT	=	0x00b3
                           0000BB   406 _I2CS_INT_ST	=	0x00bb
                                    407 ;--------------------------------------------------------
                                    408 ; special function bits
                                    409 ;--------------------------------------------------------
                                    410 	.area RSEG    (ABS,DATA)
      000000                        411 	.org 0x0000
                           0000D7   412 _CY	=	0x00d7
                           0000D6   413 _AC	=	0x00d6
                           0000D5   414 _F0	=	0x00d5
                           0000D4   415 _RS1	=	0x00d4
                           0000D3   416 _RS0	=	0x00d3
                           0000D2   417 _OV	=	0x00d2
                           0000D1   418 _F1	=	0x00d1
                           0000D0   419 _P	=	0x00d0
                           0000AF   420 _EA	=	0x00af
                           0000AE   421 _E_DIS	=	0x00ae
                           0000AD   422 _ET2	=	0x00ad
                           0000AC   423 _ES	=	0x00ac
                           0000AB   424 _ET1	=	0x00ab
                           0000AA   425 _EX1	=	0x00aa
                           0000A9   426 _ET0	=	0x00a9
                           0000A8   427 _EX0	=	0x00a8
                           0000BF   428 _PH_FLAG	=	0x00bf
                           0000BE   429 _PL_FLAG	=	0x00be
                           0000BD   430 _PT2	=	0x00bd
                           0000BC   431 _PS	=	0x00bc
                           0000BB   432 _PT1	=	0x00bb
                           0000BA   433 _PX1	=	0x00ba
                           0000B9   434 _PT0	=	0x00b9
                           0000B8   435 _PX0	=	0x00b8
                           0000EF   436 _IE_WDOG	=	0x00ef
                           0000EE   437 _IE_GPIO	=	0x00ee
                           0000ED   438 _IE_PWM_I2C	=	0x00ed
                           0000EC   439 _IE_UART1	=	0x00ec
                           0000EB   440 _IE_ADC	=	0x00eb
                           0000E9   441 _IE_USB	=	0x00e9
                           0000E8   442 _IE_SPI0	=	0x00e8
                           000087   443 _P0_7	=	0x0087
                           000086   444 _P0_6	=	0x0086
                           000085   445 _P0_5	=	0x0085
                           000084   446 _P0_4	=	0x0084
                           000083   447 _P0_3	=	0x0083
                           000082   448 _P0_2	=	0x0082
                           000081   449 _P0_1	=	0x0081
                           000080   450 _P0_0	=	0x0080
                           000081   451 _SDA0	=	0x0081
                           000080   452 _SCL0	=	0x0080
                           000083   453 _TXD_	=	0x0083
                           000082   454 _RXD_	=	0x0082
                           000085   455 _AIN13	=	0x0085
                           000084   456 _AIN12	=	0x0084
                           000083   457 _AIN11	=	0x0083
                           000082   458 _AIN10	=	0x0082
                           000081   459 _AIN9	=	0x0081
                           000080   460 _AIN8	=	0x0080
                           000097   461 _P1_7	=	0x0097
                           000096   462 _P1_6	=	0x0096
                           000095   463 _P1_5	=	0x0095
                           000094   464 _P1_4	=	0x0094
                           000093   465 _P1_3	=	0x0093
                           000092   466 _P1_2	=	0x0092
                           000091   467 _P1_1	=	0x0091
                           000090   468 _P1_0	=	0x0090
                           000097   469 _TXD1_	=	0x0097
                           000096   470 _RXD1_	=	0x0096
                           000097   471 _SCK	=	0x0097
                           000096   472 _MISO	=	0x0096
                           000095   473 _MOSI	=	0x0095
                           000094   474 _SCS	=	0x0094
                           000092   475 _INT0_	=	0x0092
                           000091   476 _T2EX	=	0x0091
                           000091   477 _CAP2	=	0x0091
                           000090   478 _T2	=	0x0090
                           000090   479 _CAP1	=	0x0090
                           000097   480 _AIN7	=	0x0097
                           000096   481 _AIN6	=	0x0096
                           000095   482 _AIN5	=	0x0095
                           000094   483 _AIN4	=	0x0094
                           000093   484 _AIN3	=	0x0093
                           000092   485 _AIN2	=	0x0092
                           000091   486 _AIN1	=	0x0091
                           000090   487 _AIN0	=	0x0090
                           0000A7   488 _P2_7	=	0x00a7
                           0000A6   489 _P2_6	=	0x00a6
                           0000A5   490 _P2_5	=	0x00a5
                           0000A4   491 _P2_4	=	0x00a4
                           0000A3   492 _P2_3	=	0x00a3
                           0000A2   493 _P2_2	=	0x00a2
                           0000A1   494 _P2_1	=	0x00a1
                           0000A0   495 _P2_0	=	0x00a0
                           0000A7   496 _TXD1	=	0x00a7
                           0000A6   497 _RXD1	=	0x00a6
                           0000A5   498 _T2EX_	=	0x00a5
                           0000A5   499 _CAP2_	=	0x00a5
                           0000A4   500 _T2_	=	0x00a4
                           0000A4   501 _CAP1_	=	0x00a4
                           0000B7   502 _P3_7	=	0x00b7
                           0000B6   503 _P3_6	=	0x00b6
                           0000B5   504 _P3_5	=	0x00b5
                           0000B4   505 _P3_4	=	0x00b4
                           0000B3   506 _P3_3	=	0x00b3
                           0000B2   507 _P3_2	=	0x00b2
                           0000B1   508 _P3_1	=	0x00b1
                           0000B0   509 _P3_0	=	0x00b0
                           0000B7   510 _SCK1	=	0x00b7
                           0000B6   511 _MISO1	=	0x00b6
                           0000B5   512 _MOSI1	=	0x00b5
                           0000B5   513 _T1	=	0x00b5
                           0000B4   514 _T0	=	0x00b4
                           0000B3   515 _INT1	=	0x00b3
                           0000B2   516 _INT0	=	0x00b2
                           0000B1   517 _TXD	=	0x00b1
                           0000B0   518 _RXD	=	0x00b0
                           0000C6   519 _P4_6	=	0x00c6
                           0000C5   520 _P4_5	=	0x00c5
                           0000C4   521 _P4_4	=	0x00c4
                           0000C3   522 _P4_3	=	0x00c3
                           0000C2   523 _P4_2	=	0x00c2
                           0000C1   524 _P4_1	=	0x00c1
                           0000C0   525 _P4_0	=	0x00c0
                           00008F   526 _TF1	=	0x008f
                           00008E   527 _TR1	=	0x008e
                           00008D   528 _TF0	=	0x008d
                           00008C   529 _TR0	=	0x008c
                           00008B   530 _IE1	=	0x008b
                           00008A   531 _IT1	=	0x008a
                           000089   532 _IE0	=	0x0089
                           000088   533 _IT0	=	0x0088
                           00009F   534 _SM0	=	0x009f
                           00009E   535 _SM1	=	0x009e
                           00009D   536 _SM2	=	0x009d
                           00009C   537 _REN	=	0x009c
                           00009B   538 _TB8	=	0x009b
                           00009A   539 _RB8	=	0x009a
                           000099   540 _TI	=	0x0099
                           000098   541 _RI	=	0x0098
                           0000CF   542 _TF2	=	0x00cf
                           0000CF   543 _CAP1F	=	0x00cf
                           0000CE   544 _EXF2	=	0x00ce
                           0000CD   545 _RCLK	=	0x00cd
                           0000CC   546 _TCLK	=	0x00cc
                           0000CB   547 _EXEN2	=	0x00cb
                           0000CA   548 _TR2	=	0x00ca
                           0000C9   549 _C_T2	=	0x00c9
                           0000C8   550 _CP_RL2	=	0x00c8
                           0000FF   551 _S0_FST_ACT	=	0x00ff
                           0000FE   552 _S0_IF_OV	=	0x00fe
                           0000FD   553 _S0_IF_FIRST	=	0x00fd
                           0000FC   554 _S0_IF_BYTE	=	0x00fc
                           0000FB   555 _S0_FREE	=	0x00fb
                           0000FA   556 _S0_T_FIFO	=	0x00fa
                           0000F8   557 _S0_R_FIFO	=	0x00f8
                           0000F7   558 _ADC_START	=	0x00f7
                                    559 ;--------------------------------------------------------
                                    560 ; overlayable register banks
                                    561 ;--------------------------------------------------------
                                    562 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        563 	.ds 8
                                    564 ;--------------------------------------------------------
                                    565 ; internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area DSEG    (DATA)
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable items in internal ram
                                    570 ;--------------------------------------------------------
                                    571 ;--------------------------------------------------------
                                    572 ; indirectly addressable internal ram data
                                    573 ;--------------------------------------------------------
                                    574 	.area ISEG    (DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; absolute internal ram data
                                    577 ;--------------------------------------------------------
                                    578 	.area IABS    (ABS,DATA)
                                    579 	.area IABS    (ABS,DATA)
                                    580 ;--------------------------------------------------------
                                    581 ; bit data
                                    582 ;--------------------------------------------------------
                                    583 	.area BSEG    (BIT)
      000025                        584 _get_record_keycode_sloc0_1_0:
      000025                        585 	.ds 1
      000026                        586 _pre_process_record_quantum_sloc0_1_0:
      000026                        587 	.ds 1
      000027                        588 _process_ak820_nkro_sloc0_1_0:
      000027                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; paged external ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area PSEG    (PAG,XDATA)
                                    594 ;--------------------------------------------------------
                                    595 ; uninitialized external ram data
                                    596 ;--------------------------------------------------------
                                    597 	.area XSEG    (XDATA)
      000BF0                        598 _extract_mod_bits_code_10000_602:
      000BF0                        599 	.ds 2
      000BF2                        600 _register_code16_code_10000_608:
      000BF2                        601 	.ds 2
      000BF4                        602 _unregister_code16_code_10000_613:
      000BF4                        603 	.ds 2
      000BF6                        604 _pre_process_record_kb_PARM_2:
      000BF6                        605 	.ds 3
      000BF9                        606 _pre_process_record_kb_keycode_10000_627:
      000BF9                        607 	.ds 2
      000BFB                        608 _pre_process_record_user_PARM_2:
      000BFB                        609 	.ds 3
      000BFE                        610 _process_record_kb_PARM_2:
      000BFE                        611 	.ds 3
      000C01                        612 _process_record_kb_keycode_10000_633:
      000C01                        613 	.ds 2
      000C03                        614 _process_record_user_PARM_2:
      000C03                        615 	.ds 3
      000C06                        616 _post_process_record_kb_PARM_2:
      000C06                        617 	.ds 3
      000C09                        618 _post_process_record_kb_keycode_10000_637:
      000C09                        619 	.ds 2
      000C0B                        620 _post_process_record_user_PARM_2:
      000C0B                        621 	.ds 3
      000C0E                        622 _get_record_keycode_PARM_2:
      000C0E                        623 	.ds 1
      000C0F                        624 _get_record_keycode_record_argument_10000_651:
      000C0F                        625 	.ds 3
      000C12                        626 _pre_process_record_quantum_record_argument_10000_657:
      000C12                        627 	.ds 3
      000C15                        628 _post_process_record_quantum_record_10000_661:
      000C15                        629 	.ds 3
      000C18                        630 _process_record_quantum_record_10000_663:
      000C18                        631 	.ds 3
      000C1B                        632 _process_ak820_nkro_PARM_2:
      000C1B                        633 	.ds 3
      000C1E                        634 _process_ak820_nkro_keycode_10000_665:
      000C1E                        635 	.ds 2
      000C20                        636 _process_record_quantum_helper_PARM_2:
      000C20                        637 	.ds 3
      000C23                        638 _process_record_quantum_helper_keycode_10000_670:
      000C23                        639 	.ds 2
      000C25                        640 _get_u8_str_last_num_10000_696:
      000C25                        641 	.ds 1
      000C26                        642 _get_u16_str_last_num_10000_700:
      000C26                        643 	.ds 2
                                    644 ;--------------------------------------------------------
                                    645 ; absolute external ram data
                                    646 ;--------------------------------------------------------
                                    647 	.area XABS    (ABS,XDATA)
                                    648 ;--------------------------------------------------------
                                    649 ; initialized external ram data
                                    650 ;--------------------------------------------------------
                                    651 	.area XISEG   (XDATA)
                                    652 	.area HOME    (CODE)
                                    653 	.area GSINIT0 (CODE)
                                    654 	.area GSINIT1 (CODE)
                                    655 	.area GSINIT2 (CODE)
                                    656 	.area GSINIT3 (CODE)
                                    657 	.area GSINIT4 (CODE)
                                    658 	.area GSINIT5 (CODE)
                                    659 	.area GSINIT  (CODE)
                                    660 	.area GSFINAL (CODE)
                                    661 	.area CSEG    (CODE)
                                    662 ;--------------------------------------------------------
                                    663 ; global & static initialisations
                                    664 ;--------------------------------------------------------
                                    665 	.area HOME    (CODE)
                                    666 	.area GSINIT  (CODE)
                                    667 	.area GSFINAL (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 ;------------------------------------------------------------
                                    670 ;Allocation info for local variables in function 'get_u8_str'
                                    671 ;------------------------------------------------------------
                                    672 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    673 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_695'
                                    674 ;buf           Allocated with name '_get_u8_str_buf_10000_696'
                                    675 ;last_num      Allocated with name '_get_u8_str_last_num_10000_696'
                                    676 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_696'
                                    677 ;------------------------------------------------------------
                                    678 ;	quantum/quantum.c:750: static uint8_t last_num = 0xFF;
      0030F3 90 0C 25         [24]  679 	mov	dptr,#_get_u8_str_last_num_10000_696
      0030F6 74 FF            [12]  680 	mov	a,#0xff
      0030F8 F0               [24]  681 	movx	@dptr,a
                                    682 ;------------------------------------------------------------
                                    683 ;Allocation info for local variables in function 'get_u16_str'
                                    684 ;------------------------------------------------------------
                                    685 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    686 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_699'
                                    687 ;buf           Allocated with name '_get_u16_str_buf_10000_700'
                                    688 ;last_num      Allocated with name '_get_u16_str_last_num_10000_700'
                                    689 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_700'
                                    690 ;------------------------------------------------------------
                                    691 ;	quantum/quantum.c:770: static uint16_t last_num = 0xFF;
      0030F9 90 0C 26         [24]  692 	mov	dptr,#_get_u16_str_last_num_10000_700
      0030FC 74 FF            [12]  693 	mov	a,#0xff
      0030FE F0               [24]  694 	movx	@dptr,a
      0030FF E4               [12]  695 	clr	a
      003100 A3               [24]  696 	inc	dptr
      003101 F0               [24]  697 	movx	@dptr,a
                                    698 ;--------------------------------------------------------
                                    699 ; Home
                                    700 ;--------------------------------------------------------
                                    701 	.area HOME    (CODE)
                                    702 	.area HOME    (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; code
                                    705 ;--------------------------------------------------------
                                    706 	.area CSEG    (CODE)
                                    707 ;------------------------------------------------------------
                                    708 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    709 ;------------------------------------------------------------
                                    710 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    711 ;------------------------------------------------------------
                                    712 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    713 ;	-----------------------------------------
                           000007   714 	ar7 = 0x07
                           000006   715 	ar6 = 0x06
                           000005   716 	ar5 = 0x05
                           000004   717 	ar4 = 0x04
                           000003   718 	ar3 = 0x03
                           000002   719 	ar2 = 0x02
                           000001   720 	ar1 = 0x01
                           000000   721 	ar0 = 0x00
                                    722 ;	 function extract_mod_bits
                                    723 ;	-----------------------------------------
      009F1F                        724 _extract_mod_bits:
      009F1F 12 38 85         [24]  725 	lcall	_ak820_outline_0108
      009F22 90 0B F0         [24]  726 	mov	dptr,#_extract_mod_bits_code_10000_602
      009F25 12 38 8A         [24]  727 	lcall	_ak820_outline_0109
                                    728 ;	quantum/quantum.c:107: uint8_t mods = (uint8_t)(code >> 8);
      009F28 90 0B F0         [24]  729 	mov	dptr,#_extract_mod_bits_code_10000_602
      009F2B E0               [24]  730 	movx	a,@dptr
      009F2C A3               [24]  731 	inc	dptr
      009F2D E0               [24]  732 	movx	a,@dptr
                                    733 ;	quantum/quantum.c:108: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009F2E FF               [12]  734 	mov	r7,a
      009F2F 60 05            [24]  735 	jz	00101$
      009F31 EF               [12]  736 	mov	a,r7
      009F32 24 E0            [12]  737 	add	a,#0xff - 0x1f
      009F34 50 04            [24]  738 	jnc	00102$
                                    739 ;	free result
      009F36                        740 00101$:
      009F36 75 82 00         [24]  741 	mov	dpl, #0x00
      009F39 22               [24]  742 	ret
      009F3A                        743 00102$:
                                    744 ;	quantum/quantum.c:109: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009F3A EF               [12]  745 	mov	a,r7
      009F3B 30 E4 07         [24]  746 	jnb	acc.4,00106$
      009F3E EF               [12]  747 	mov	a,r7
      009F3F C4               [12]  748 	swap	a
      009F40 54 F0            [12]  749 	anl	a,#0xf0
      009F42 FE               [12]  750 	mov	r6,a
      009F43 80 02            [24]  751 	sjmp	00107$
      009F45                        752 00106$:
      009F45 8F 06            [24]  753 	mov	ar6,r7
      009F47                        754 00107$:
      009F47 8E 82            [24]  755 	mov	dpl, r6
                                    756 ;	quantum/quantum.c:137: }
      009F49 22               [24]  757 	ret
                                    758 ;------------------------------------------------------------
                                    759 ;Allocation info for local variables in function 'do_code16'
                                    760 ;------------------------------------------------------------
                                    761 ;f             Allocated with name '_do_code16_PARM_2'
                                    762 ;code          Allocated with name '_do_code16_code_10000_605'
                                    763 ;------------------------------------------------------------
                                    764 ;	quantum/quantum.c:139: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function register_code16
                                    767 ;	-----------------------------------------
      009F4A                        768 _register_code16:
      009F4A 12 38 85         [24]  769 	lcall	_ak820_outline_0108
      009F4D 90 0B F2         [24]  770 	mov	dptr,#_register_code16_code_10000_608
      009F50 12 38 8A         [24]  771 	lcall	_ak820_outline_0109
                                    772 ;	quantum/quantum.c:145: uint8_t mods = extract_mod_bits(code);
      009F53 90 0B F2         [24]  773 	mov	dptr,#_register_code16_code_10000_608
      009F56 12 37 F1         [24]  774 	lcall	_ak820_outline_0005
      009F59 C0 07            [24]  775 	push	ar7
      009F5B C0 06            [24]  776 	push	ar6
      009F5D 12 9F 1F         [24]  777 	lcall	_extract_mod_bits
      009F60 AD 82            [24]  778 	mov	r5, dpl
      009F62 D0 06            [24]  779 	pop	ar6
      009F64 D0 07            [24]  780 	pop	ar7
                                    781 ;	quantum/quantum.c:146: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009F66 12 9D 58         [24]  782 	lcall	_ak820_outline_0120
      009F69 40 07            [24]  783 	jc	00105$
      009F6B 74 E7            [12]  784 	mov	a,#0xe7
      009F6D 9E               [12]  785 	subb	a,r6
      009F6E E4               [12]  786 	clr	a
      009F6F 9F               [12]  787 	subb	a,r7
      009F70 50 08            [24]  788 	jnc	00101$
                                    789 ;	free result
      009F72                        790 00105$:
      009F72 90 0B F2         [24]  791 	mov	dptr,#_register_code16_code_10000_608
      009F75 12 6F AE         [24]  792 	lcall	_ak820_outline_0040
      009F78 70 07            [24]  793 	jnz	00102$
      009F7A                        794 00101$:
                                    795 ;	quantum/quantum.c:147: register_mods(mods);
      009F7A 8D 82            [24]  796 	mov	dpl, r5
      009F7C 12 78 65         [24]  797 	lcall	_register_mods
      009F7F 80 05            [24]  798 	sjmp	00103$
      009F81                        799 00102$:
                                    800 ;	quantum/quantum.c:149: register_weak_mods(mods);
      009F81 8D 82            [24]  801 	mov	dpl, r5
      009F83 12 78 8D         [24]  802 	lcall	_register_weak_mods
      009F86                        803 00103$:
                                    804 ;	quantum/quantum.c:151: register_code(code);
      009F86 90 0B F2         [24]  805 	mov	dptr,#_register_code16_code_10000_608
      009F89 E0               [24]  806 	movx	a,@dptr
      009F8A F5 82            [12]  807 	mov	dpl,a
                                    808 ;	quantum/quantum.c:161: }
      009F8C 02 77 42         [24]  809 	ljmp	_register_code
                                    810 ;------------------------------------------------------------
                                    811 ;Allocation info for local variables in function 'unregister_code16'
                                    812 ;------------------------------------------------------------
                                    813 ;code          Allocated with name '_unregister_code16_code_10000_613'
                                    814 ;mods          Allocated with name '_unregister_code16_mods_10000_614'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/quantum.c:163: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    817 ;	-----------------------------------------
                                    818 ;	 function unregister_code16
                                    819 ;	-----------------------------------------
      009F8F                        820 _unregister_code16:
      009F8F 12 38 85         [24]  821 	lcall	_ak820_outline_0108
      009F92 90 0B F4         [24]  822 	mov	dptr,#_unregister_code16_code_10000_613
      009F95 12 38 8A         [24]  823 	lcall	_ak820_outline_0109
                                    824 ;	quantum/quantum.c:165: uint8_t mods = extract_mod_bits(code);
      009F98 90 0B F4         [24]  825 	mov	dptr,#_unregister_code16_code_10000_613
      009F9B 12 37 F1         [24]  826 	lcall	_ak820_outline_0005
      009F9E C0 07            [24]  827 	push	ar7
      009FA0 C0 06            [24]  828 	push	ar6
      009FA2 12 9F 1F         [24]  829 	lcall	_extract_mod_bits
      009FA5 AD 82            [24]  830 	mov	r5, dpl
      009FA7 D0 06            [24]  831 	pop	ar6
                                    832 ;	quantum/quantum.c:166: unregister_code(code);
      009FA9 8E 04            [24]  833 	mov	ar4,r6
      009FAB 8C 82            [24]  834 	mov	dpl, r4
      009FAD C0 06            [24]  835 	push	ar6
      009FAF C0 05            [24]  836 	push	ar5
      009FB1 12 77 AF         [24]  837 	lcall	_unregister_code
      009FB4 D0 05            [24]  838 	pop	ar5
      009FB6 D0 06            [24]  839 	pop	ar6
      009FB8 D0 07            [24]  840 	pop	ar7
                                    841 ;	quantum/quantum.c:167: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009FBA 12 9D 58         [24]  842 	lcall	_ak820_outline_0120
      009FBD 40 07            [24]  843 	jc	00105$
      009FBF 74 E7            [12]  844 	mov	a,#0xe7
      009FC1 9E               [12]  845 	subb	a,r6
      009FC2 E4               [12]  846 	clr	a
      009FC3 9F               [12]  847 	subb	a,r7
      009FC4 50 08            [24]  848 	jnc	00101$
                                    849 ;	free result
      009FC6                        850 00105$:
      009FC6 90 0B F4         [24]  851 	mov	dptr,#_unregister_code16_code_10000_613
      009FC9 12 6F AE         [24]  852 	lcall	_ak820_outline_0040
      009FCC 70 05            [24]  853 	jnz	00102$
      009FCE                        854 00101$:
                                    855 ;	quantum/quantum.c:168: unregister_mods(mods);
      009FCE 8D 82            [24]  856 	mov	dpl, r5
      009FD0 02 78 79         [24]  857 	ljmp	_unregister_mods
      009FD3                        858 00102$:
                                    859 ;	quantum/quantum.c:170: unregister_weak_mods(mods);
      009FD3 8D 82            [24]  860 	mov	dpl, r5
                                    861 ;	quantum/quantum.c:181: }
      009FD5 02 78 A1         [24]  862 	ljmp	_unregister_weak_mods
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'tap_code16_delay'
                                    865 ;------------------------------------------------------------
                                    866 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    867 ;code          Allocated with name '_tap_code16_delay_code_10000_618'
                                    868 ;i             Allocated with name '_tap_code16_delay_i_20000_620'
                                    869 ;i             Allocated with name '_tap_code16_delay_i_50000_623'
                                    870 ;------------------------------------------------------------
                                    871 ;	quantum/quantum.c:188: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    872 ;	-----------------------------------------
                                    873 ;	 function pre_process_record_kb
                                    874 ;	-----------------------------------------
      009FD8                        875 _pre_process_record_kb:
      009FD8 12 38 85         [24]  876 	lcall	_ak820_outline_0108
      009FDB 90 0B F9         [24]  877 	mov	dptr,#_pre_process_record_kb_keycode_10000_627
      009FDE 12 38 8A         [24]  878 	lcall	_ak820_outline_0109
                                    879 ;	quantum/quantum.c:205: return pre_process_record_user(keycode, record);
      009FE1 90 0B F9         [24]  880 	mov	dptr,#_pre_process_record_kb_keycode_10000_627
      009FE4 12 38 3E         [24]  881 	lcall	_ak820_outline_0051
      009FE7 90 0B F6         [24]  882 	mov	dptr,#_pre_process_record_kb_PARM_2
      009FEA 12 9D 4F         [24]  883 	lcall	_ak820_outline_0027
      009FED 90 0B FB         [24]  884 	mov	dptr,#_pre_process_record_user_PARM_2
      009FF0 12 A3 9E         [24]  885 	lcall	_ak820_outline_0010
                                    886 ;	quantum/quantum.c:206: }
      009FF3 02 9F F6         [24]  887 	ljmp	_pre_process_record_user
                                    888 ;------------------------------------------------------------
                                    889 ;Allocation info for local variables in function 'pre_process_record_user'
                                    890 ;------------------------------------------------------------
                                    891 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    892 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_629'
                                    893 ;------------------------------------------------------------
                                    894 ;	quantum/quantum.c:208: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    895 ;	-----------------------------------------
                                    896 ;	 function pre_process_record_user
                                    897 ;	-----------------------------------------
      009FF6                        898 _pre_process_record_user:
                                    899 ;	quantum/quantum.c:209: return true;
      009FF6 75 82 01         [24]  900 	mov	dpl, #0x01
                                    901 ;	quantum/quantum.c:210: }
      009FF9 22               [24]  902 	ret
                                    903 ;------------------------------------------------------------
                                    904 ;Allocation info for local variables in function 'process_action_kb'
                                    905 ;------------------------------------------------------------
                                    906 ;record        Allocated with name '_process_action_kb_record_10000_631'
                                    907 ;------------------------------------------------------------
                                    908 ;	quantum/quantum.c:212: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    909 ;	-----------------------------------------
                                    910 ;	 function process_action_kb
                                    911 ;	-----------------------------------------
      009FFA                        912 _process_action_kb:
                                    913 ;	quantum/quantum.c:213: return true;
      009FFA 75 82 01         [24]  914 	mov	dpl, #0x01
                                    915 ;	quantum/quantum.c:214: }
      009FFD 22               [24]  916 	ret
                                    917 ;------------------------------------------------------------
                                    918 ;Allocation info for local variables in function 'process_record_kb'
                                    919 ;------------------------------------------------------------
                                    920 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    921 ;keycode       Allocated with name '_process_record_kb_keycode_10000_633'
                                    922 ;------------------------------------------------------------
                                    923 ;	quantum/quantum.c:216: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    924 ;	-----------------------------------------
                                    925 ;	 function process_record_kb
                                    926 ;	-----------------------------------------
      009FFE                        927 _process_record_kb:
      009FFE 12 38 85         [24]  928 	lcall	_ak820_outline_0108
      00A001 90 0C 01         [24]  929 	mov	dptr,#_process_record_kb_keycode_10000_633
      00A004 12 38 8A         [24]  930 	lcall	_ak820_outline_0109
                                    931 ;	quantum/quantum.c:217: return process_record_user(keycode, record);
      00A007 90 0C 01         [24]  932 	mov	dptr,#_process_record_kb_keycode_10000_633
      00A00A 12 38 3E         [24]  933 	lcall	_ak820_outline_0051
      00A00D 90 0B FE         [24]  934 	mov	dptr,#_process_record_kb_PARM_2
      00A010 12 9D 4F         [24]  935 	lcall	_ak820_outline_0027
      00A013 90 0C 03         [24]  936 	mov	dptr,#_process_record_user_PARM_2
      00A016 12 A3 9E         [24]  937 	lcall	_ak820_outline_0010
                                    938 ;	quantum/quantum.c:218: }
      00A019 02 A0 1C         [24]  939 	ljmp	_process_record_user
                                    940 ;------------------------------------------------------------
                                    941 ;Allocation info for local variables in function 'process_record_user'
                                    942 ;------------------------------------------------------------
                                    943 ;record        Allocated with name '_process_record_user_PARM_2'
                                    944 ;keycode       Allocated with name '_process_record_user_keycode_10000_635'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/quantum.c:220: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function process_record_user
                                    949 ;	-----------------------------------------
      00A01C                        950 _process_record_user:
                                    951 ;	quantum/quantum.c:221: return true;
      00A01C 75 82 01         [24]  952 	mov	dpl, #0x01
                                    953 ;	quantum/quantum.c:222: }
      00A01F 22               [24]  954 	ret
                                    955 ;------------------------------------------------------------
                                    956 ;Allocation info for local variables in function 'post_process_record_kb'
                                    957 ;------------------------------------------------------------
                                    958 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    959 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_637'
                                    960 ;------------------------------------------------------------
                                    961 ;	quantum/quantum.c:224: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    962 ;	-----------------------------------------
                                    963 ;	 function post_process_record_kb
                                    964 ;	-----------------------------------------
      00A020                        965 _post_process_record_kb:
      00A020 12 38 85         [24]  966 	lcall	_ak820_outline_0108
      00A023 90 0C 09         [24]  967 	mov	dptr,#_post_process_record_kb_keycode_10000_637
      00A026 12 38 8A         [24]  968 	lcall	_ak820_outline_0109
                                    969 ;	quantum/quantum.c:225: post_process_record_user(keycode, record);
      00A029 90 0C 09         [24]  970 	mov	dptr,#_post_process_record_kb_keycode_10000_637
      00A02C 12 38 3E         [24]  971 	lcall	_ak820_outline_0051
      00A02F 90 0C 06         [24]  972 	mov	dptr,#_post_process_record_kb_PARM_2
      00A032 12 9D 4F         [24]  973 	lcall	_ak820_outline_0027
      00A035 90 0C 0B         [24]  974 	mov	dptr,#_post_process_record_user_PARM_2
      00A038 12 A3 9E         [24]  975 	lcall	_ak820_outline_0010
                                    976 ;	quantum/quantum.c:226: }
      00A03B 02 A0 3E         [24]  977 	ljmp	_post_process_record_user
                                    978 ;------------------------------------------------------------
                                    979 ;Allocation info for local variables in function 'post_process_record_user'
                                    980 ;------------------------------------------------------------
                                    981 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    982 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_639'
                                    983 ;------------------------------------------------------------
                                    984 ;	quantum/quantum.c:228: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    985 ;	-----------------------------------------
                                    986 ;	 function post_process_record_user
                                    987 ;	-----------------------------------------
      00A03E                        988 _post_process_record_user:
      00A03E 22               [24]  989 	ret
                                    990 ;------------------------------------------------------------
                                    991 ;Allocation info for local variables in function 'shutdown_quantum'
                                    992 ;------------------------------------------------------------
                                    993 ;i             Allocated with name '_shutdown_quantum_i_30000_645'
                                    994 ;------------------------------------------------------------
                                    995 ;	quantum/quantum.c:230: void shutdown_quantum(void) {
                                    996 ;	-----------------------------------------
                                    997 ;	 function shutdown_quantum
                                    998 ;	-----------------------------------------
      00A03F                        999 _shutdown_quantum:
                                   1000 ;	quantum/quantum.c:231: clear_keyboard();
      00A03F 12 78 B5         [24] 1001 	lcall	_clear_keyboard
                                   1002 ;	quantum/quantum.c:246: shutdown_user();
      00A042 12 A3 90         [24] 1003 	lcall	_shutdown_user
                                   1004 ;	quantum/quantum.c:247: wait_ms(250);
      00A045 7F FA            [12] 1005 	mov	r7,#0xfa
      00A047                       1006 00106$:
      00A047 EF               [12] 1007 	mov	a,r7
      00A048 60 09            [24] 1008 	jz	00108$
      00A04A 90 00 01         [24] 1009 	mov	dptr,#0x0001
      00A04D 12 5B 1A         [24] 1010 	lcall	_mDelaymS
      00A050 1F               [12] 1011 	dec	r7
      00A051 80 F4            [24] 1012 	sjmp	00106$
      00A053                       1013 00108$:
                                   1014 ;	quantum/quantum.c:252: }
      00A053 22               [24] 1015 	ret
                                   1016 ;------------------------------------------------------------
                                   1017 ;Allocation info for local variables in function 'reset_keyboard'
                                   1018 ;------------------------------------------------------------
                                   1019 ;	quantum/quantum.c:254: void reset_keyboard(void) {
                                   1020 ;	-----------------------------------------
                                   1021 ;	 function reset_keyboard
                                   1022 ;	-----------------------------------------
      00A054                       1023 _reset_keyboard:
                                   1024 ;	quantum/quantum.c:255: shutdown_quantum();
      00A054 12 A0 3F         [24] 1025 	lcall	_shutdown_quantum
                                   1026 ;	quantum/quantum.c:256: bootloader_jump();
                                   1027 ;	quantum/quantum.c:257: }
      00A057 02 34 0E         [24] 1028 	ljmp	_bootloader_jump
                                   1029 ;------------------------------------------------------------
                                   1030 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/quantum.c:259: void soft_reset_keyboard(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function soft_reset_keyboard
                                   1035 ;	-----------------------------------------
      00A05A                       1036 _soft_reset_keyboard:
                                   1037 ;	quantum/quantum.c:260: shutdown_quantum();
      00A05A 12 A0 3F         [24] 1038 	lcall	_shutdown_quantum
                                   1039 ;	quantum/quantum.c:261: mcu_reset();
                                   1040 ;	quantum/quantum.c:262: }
      00A05D 02 34 01         [24] 1041 	ljmp	_mcu_reset
                                   1042 ;------------------------------------------------------------
                                   1043 ;Allocation info for local variables in function 'get_record_keycode'
                                   1044 ;------------------------------------------------------------
                                   1045 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1046 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_651'
                                   1047 ;record        Allocated with name '_get_record_keycode_record_10000_652'
                                   1048 ;------------------------------------------------------------
                                   1049 ;	quantum/quantum.c:265: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1050 ;	-----------------------------------------
                                   1051 ;	 function get_record_keycode
                                   1052 ;	-----------------------------------------
      00A060                       1053 _get_record_keycode:
      00A060 12 45 6F         [24] 1054 	lcall	_ak820_outline_0037
      00A063 90 0C 0F         [24] 1055 	mov	dptr,#_get_record_keycode_record_argument_10000_651
      00A066 12 38 26         [24] 1056 	lcall	_ak820_outline_0017
                                   1057 ;	quantum/quantum.c:267: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A069 90 0C 0F         [24] 1058 	mov	dptr,#_get_record_keycode_record_argument_10000_651
      00A06C 12 37 FB         [24] 1059 	lcall	_ak820_outline_0007
                                   1060 ;	quantum/quantum.c:272: if (record->keycode) {
      00A06F 4C               [12] 1061 	orl	a,r4
      00A070 60 04            [24] 1062 	jz	00102$
                                   1063 ;	quantum/quantum.c:273: return record->keycode;
      00A072 12 38 A1         [24] 1064 	lcall	_ak820_outline_0126
      00A075 22               [24] 1065 	ret
      00A076                       1066 00102$:
                                   1067 ;	quantum/quantum.c:277: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A076 12 79 16         [24] 1068 	lcall	_ak820_outline_0022
      00A079 7A 00            [12] 1069 	mov	r2,#0x00
      00A07B 12 45 C3         [24] 1070 	lcall	_ak820_outline_0144
      00A07E 12 38 0F         [24] 1071 	lcall	_ak820_outline_0009
      00A081 60 06            [24] 1072 	jz	00105$
      00A083 90 0C 0E         [24] 1073 	mov	dptr,#_get_record_keycode_PARM_2
      00A086 E0               [24] 1074 	movx	a,@dptr
      00A087 70 04            [24] 1075 	jnz	00106$
      00A089                       1076 00105$:
                                   1077 ;	assignBit
      00A089 C2 25            [12] 1078 	clr	_get_record_keycode_sloc0_1_0
      00A08B 80 02            [24] 1079 	sjmp	00107$
      00A08D                       1080 00106$:
                                   1081 ;	assignBit
      00A08D D2 25            [12] 1082 	setb	_get_record_keycode_sloc0_1_0
      00A08F                       1083 00107$:
      00A08F 90 09 83         [24] 1084 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A092 A2 25            [12] 1085 	mov	c,_get_record_keycode_sloc0_1_0
      00A094 E4               [12] 1086 	clr	a
      00A095 33               [12] 1087 	rlc	a
      00A096 F0               [24] 1088 	movx	@dptr,a
      00A097 8D 82            [24] 1089 	mov	dpl, r5
      00A099 8C 83            [24] 1090 	mov	dph, r4
                                   1091 ;	quantum/quantum.c:281: }
      00A09B 02 7C BC         [24] 1092 	ljmp	_ak820_resolve_key
                                   1093 ;------------------------------------------------------------
                                   1094 ;Allocation info for local variables in function 'get_event_keycode'
                                   1095 ;------------------------------------------------------------
                                   1096 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1097 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_655'
                                   1098 ;------------------------------------------------------------
                                   1099 ;	quantum/quantum.c:289: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1100 ;	-----------------------------------------
                                   1101 ;	 function pre_process_record_quantum
                                   1102 ;	-----------------------------------------
      00A09E                       1103 _pre_process_record_quantum:
      00A09E 12 45 6F         [24] 1104 	lcall	_ak820_outline_0037
      00A0A1 90 0C 12         [24] 1105 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_657
      00A0A4 12 38 26         [24] 1106 	lcall	_ak820_outline_0017
                                   1107 ;	quantum/quantum.c:322: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A0A7 90 0C 12         [24] 1108 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_657
      00A0AA 12 38 3E         [24] 1109 	lcall	_ak820_outline_0051
                                   1110 ;	quantum/quantum.c:326: uint16_t keycode = get_record_keycode(record, true);
      00A0AD 8E 03            [24] 1111 	mov	ar3,r6
      00A0AF 8F 04            [24] 1112 	mov	ar4,r7
      00A0B1 7D 00            [12] 1113 	mov	r5,#0x00
      00A0B3 90 0C 0E         [24] 1114 	mov	dptr,#_get_record_keycode_PARM_2
      00A0B6 74 01            [12] 1115 	mov	a,#0x01
      00A0B8 F0               [24] 1116 	movx	@dptr,a
      00A0B9 12 33 FC         [24] 1117 	lcall	_ak820_outline_0125
      00A0BC 8D F0            [24] 1118 	mov	b, r5
      00A0BE C0 07            [24] 1119 	push	ar7
      00A0C0 C0 06            [24] 1120 	push	ar6
      00A0C2 12 A0 60         [24] 1121 	lcall	_get_record_keycode
      00A0C5 12 45 C9         [24] 1122 	lcall	_ak820_outline_0151
      00A0C8 D0 06            [24] 1123 	pop	ar6
      00A0CA D0 07            [24] 1124 	pop	ar7
                                   1125 ;	quantum/quantum.c:328: record->keycode = keycode;
      00A0CC 74 07            [12] 1126 	mov	a,#0x07
      00A0CE 12 38 2E         [24] 1127 	lcall	_ak820_outline_0023
      00A0D1 12 38 5B         [24] 1128 	lcall	_ak820_outline_0072
                                   1129 ;	quantum/quantum.c:333: if (keycode == QK_LEAD && record->event.pressed && record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS)
      00A0D4 8C 02            [24] 1130 	mov	ar2,r4
      00A0D6 8D 03            [24] 1131 	mov	ar3,r5
      00A0D8 BA 58 40         [24] 1132 	cjne	r2,#0x58,00102$
      00A0DB BB 7C 3D         [24] 1133 	cjne	r3,#0x7c,00102$
      00A0DE 74 05            [12] 1134 	mov	a,#0x05
      00A0E0 12 4A 99         [24] 1135 	lcall	_ak820_outline_0019
      00A0E3 60 36            [24] 1136 	jz	00102$
      00A0E5 12 38 8F         [24] 1137 	lcall	_ak820_outline_0114
      00A0E8 FB               [12] 1138 	mov	r3,a
      00A0E9 BB 10 00         [24] 1139 	cjne	r3,#0x10,00161$
      00A0EC                       1140 00161$:
      00A0EC 50 2D            [24] 1141 	jnc	00102$
      00A0EE 12 38 73         [24] 1142 	lcall	_ak820_outline_0100
      00A0F1 FB               [12] 1143 	mov	r3,a
      00A0F2 BB 08 00         [24] 1144 	cjne	r3,#0x08,00163$
      00A0F5                       1145 00163$:
      00A0F5 50 24            [24] 1146 	jnc	00102$
                                   1147 ;	quantum/quantum.c:334: ak820_combo_tick(record->event.time + 40);
      00A0F7 12 38 36         [24] 1148 	lcall	_ak820_outline_0032
      00A0FA FA               [12] 1149 	mov	r2,a
      00A0FB A3               [24] 1150 	inc	dptr
      00A0FC E0               [24] 1151 	movx	a,@dptr
      00A0FD FB               [12] 1152 	mov	r3,a
      00A0FE 74 28            [12] 1153 	mov	a,#0x28
      00A100 2A               [12] 1154 	add	a, r2
      00A101 FA               [12] 1155 	mov	r2,a
      00A102 E4               [12] 1156 	clr	a
      00A103 3B               [12] 1157 	addc	a, r3
      00A104 FB               [12] 1158 	mov	r3,a
      00A105 12 38 B6         [24] 1159 	lcall	_ak820_outline_0145
      00A108 C0 07            [24] 1160 	push	ar7
      00A10A C0 06            [24] 1161 	push	ar6
      00A10C C0 05            [24] 1162 	push	ar5
      00A10E C0 04            [24] 1163 	push	ar4
      00A110 12 36 04         [24] 1164 	lcall	_ak820_combo_tick
      00A113 D0 04            [24] 1165 	pop	ar4
      00A115 D0 05            [24] 1166 	pop	ar5
      00A117 D0 06            [24] 1167 	pop	ar6
      00A119 D0 07            [24] 1168 	pop	ar7
      00A11B                       1169 00102$:
                                   1170 ;	quantum/quantum.c:336: if (!ak820_leader_process((keyrecord_t AK820_STATE_MEM *)record)) return false;
      00A11B 12 38 96         [24] 1171 	lcall	_ak820_outline_0122
      00A11E C0 07            [24] 1172 	push	ar7
      00A120 C0 06            [24] 1173 	push	ar6
      00A122 C0 05            [24] 1174 	push	ar5
      00A124 C0 04            [24] 1175 	push	ar4
      00A126 12 3C 1D         [24] 1176 	lcall	_ak820_leader_process
      00A129 E5 82            [12] 1177 	mov	a, dpl
      00A12B D0 04            [24] 1178 	pop	ar4
      00A12D D0 05            [24] 1179 	pop	ar5
      00A12F D0 06            [24] 1180 	pop	ar6
      00A131 D0 07            [24] 1181 	pop	ar7
      00A133 70 03            [24] 1182 	jnz	00107$
      00A135 F5 82            [12] 1183 	mov	dpl,a
      00A137 22               [24] 1184 	ret
      00A138                       1185 00107$:
                                   1186 ;	quantum/quantum.c:338: return pre_process_record_kb(keycode, record) &&
      00A138 90 0B F6         [24] 1187 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A13B 12 A3 91         [24] 1188 	lcall	_ak820_outline_0002
      00A13E C0 07            [24] 1189 	push	ar7
      00A140 C0 06            [24] 1190 	push	ar6
      00A142 12 9F D8         [24] 1191 	lcall	_pre_process_record_kb
      00A145 E5 82            [12] 1192 	mov	a, dpl
      00A147 D0 06            [24] 1193 	pop	ar6
      00A149 D0 07            [24] 1194 	pop	ar7
      00A14B 60 0A            [24] 1195 	jz	00110$
                                   1196 ;	quantum/quantum.c:341: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A14D 12 38 96         [24] 1197 	lcall	_ak820_outline_0122
      00A150 12 36 3B         [24] 1198 	lcall	_ak820_combo_process
      00A153 E5 82            [12] 1199 	mov	a, dpl
      00A155 70 04            [24] 1200 	jnz	00111$
                                   1201 ;	quantum/quantum.c:346: true;
      00A157                       1202 00110$:
                                   1203 ;	assignBit
      00A157 C2 26            [12] 1204 	clr	_pre_process_record_quantum_sloc0_1_0
      00A159 80 02            [24] 1205 	sjmp	00112$
      00A15B                       1206 00111$:
                                   1207 ;	assignBit
      00A15B D2 26            [12] 1208 	setb	_pre_process_record_quantum_sloc0_1_0
      00A15D                       1209 00112$:
      00A15D A2 26            [12] 1210 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A15F 12 38 BB         [24] 1211 	lcall	_ak820_outline_0158
                                   1212 ;	quantum/quantum.c:347: }
      00A162 22               [24] 1213 	ret
                                   1214 ;------------------------------------------------------------
                                   1215 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1216 ;------------------------------------------------------------
                                   1217 ;record        Allocated with name '_post_process_record_quantum_record_10000_661'
                                   1218 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_662'
                                   1219 ;------------------------------------------------------------
                                   1220 ;	quantum/quantum.c:350: void post_process_record_quantum(keyrecord_t *record) {
                                   1221 ;	-----------------------------------------
                                   1222 ;	 function post_process_record_quantum
                                   1223 ;	-----------------------------------------
      00A163                       1224 _post_process_record_quantum:
      00A163 12 45 6F         [24] 1225 	lcall	_ak820_outline_0037
      00A166 90 0C 15         [24] 1226 	mov	dptr,#_post_process_record_quantum_record_10000_661
      00A169 12 38 26         [24] 1227 	lcall	_ak820_outline_0017
                                   1228 ;	quantum/quantum.c:351: uint16_t keycode = get_record_keycode(record, false);
      00A16C 90 0C 15         [24] 1229 	mov	dptr,#_post_process_record_quantum_record_10000_661
      00A16F 12 51 46         [24] 1230 	lcall	_ak820_outline_0012
      00A172 90 0C 0E         [24] 1231 	mov	dptr,#_get_record_keycode_PARM_2
      00A175 E4               [12] 1232 	clr	a
      00A176 12 51 4F         [24] 1233 	lcall	_ak820_outline_0034
      00A179 12 A0 60         [24] 1234 	lcall	_get_record_keycode
      00A17C 12 45 B8         [24] 1235 	lcall	_ak820_outline_0135
                                   1236 ;	quantum/quantum.c:352: post_process_record_kb(keycode, record);
      00A17F 90 0C 15         [24] 1237 	mov	dptr,#_post_process_record_quantum_record_10000_661
      00A182 12 9D 4F         [24] 1238 	lcall	_ak820_outline_0027
      00A185 90 0C 06         [24] 1239 	mov	dptr,#_post_process_record_kb_PARM_2
      00A188 12 A3 9E         [24] 1240 	lcall	_ak820_outline_0010
                                   1241 ;	quantum/quantum.c:353: }
      00A18B 02 A0 20         [24] 1242 	ljmp	_post_process_record_kb
                                   1243 ;------------------------------------------------------------
                                   1244 ;Allocation info for local variables in function 'process_record_quantum'
                                   1245 ;------------------------------------------------------------
                                   1246 ;record        Allocated with name '_process_record_quantum_record_10000_663'
                                   1247 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_664'
                                   1248 ;------------------------------------------------------------
                                   1249 ;	quantum/quantum.c:355: bool process_record_quantum(keyrecord_t *record) {
                                   1250 ;	-----------------------------------------
                                   1251 ;	 function process_record_quantum
                                   1252 ;	-----------------------------------------
      00A18E                       1253 _process_record_quantum:
      00A18E 12 45 6F         [24] 1254 	lcall	_ak820_outline_0037
      00A191 90 0C 18         [24] 1255 	mov	dptr,#_process_record_quantum_record_10000_663
      00A194 12 38 26         [24] 1256 	lcall	_ak820_outline_0017
                                   1257 ;	quantum/quantum.c:357: uint16_t keycode = get_record_keycode(record, false);
      00A197 90 0C 18         [24] 1258 	mov	dptr,#_process_record_quantum_record_10000_663
      00A19A 12 51 46         [24] 1259 	lcall	_ak820_outline_0012
      00A19D 90 0C 0E         [24] 1260 	mov	dptr,#_get_record_keycode_PARM_2
      00A1A0 E4               [12] 1261 	clr	a
      00A1A1 12 51 4F         [24] 1262 	lcall	_ak820_outline_0034
      00A1A4 12 A0 60         [24] 1263 	lcall	_get_record_keycode
      00A1A7 12 45 B8         [24] 1264 	lcall	_ak820_outline_0135
                                   1265 ;	quantum/quantum.c:361: return process_record_quantum_helper(keycode, record);
      00A1AA 90 0C 18         [24] 1266 	mov	dptr,#_process_record_quantum_record_10000_663
      00A1AD 12 9D 4F         [24] 1267 	lcall	_ak820_outline_0027
      00A1B0 90 0C 20         [24] 1268 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A1B3 12 A3 9E         [24] 1269 	lcall	_ak820_outline_0010
                                   1270 ;	quantum/quantum.c:362: }
      00A1B6 02 A2 24         [24] 1271 	ljmp	_process_record_quantum_helper
                                   1272 ;------------------------------------------------------------
                                   1273 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1274 ;------------------------------------------------------------
                                   1275 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1276 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_665'
                                   1277 ;record        Allocated with name '_process_ak820_nkro_record_10000_666'
                                   1278 ;------------------------------------------------------------
                                   1279 ;	quantum/quantum.c:369: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1280 ;	-----------------------------------------
                                   1281 ;	 function process_ak820_nkro
                                   1282 ;	-----------------------------------------
      00A1B9                       1283 _process_ak820_nkro:
      00A1B9 12 38 85         [24] 1284 	lcall	_ak820_outline_0108
      00A1BC 90 0C 1E         [24] 1285 	mov	dptr,#_process_ak820_nkro_keycode_10000_665
      00A1BF 12 38 8A         [24] 1286 	lcall	_ak820_outline_0109
                                   1287 ;	quantum/quantum.c:371: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A1C2 90 0C 1B         [24] 1288 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A1C5 12 38 3E         [24] 1289 	lcall	_ak820_outline_0051
                                   1290 ;	quantum/quantum.c:375: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A1C8 90 0C 1E         [24] 1291 	mov	dptr,#_process_ak820_nkro_keycode_10000_665
      00A1CB 12 38 55         [24] 1292 	lcall	_ak820_outline_0059
      00A1CE C3               [12] 1293 	clr	c
      00A1CF EC               [12] 1294 	mov	a,r4
      00A1D0 94 11            [12] 1295 	subb	a,#0x11
      00A1D2 ED               [12] 1296 	mov	a,r5
      00A1D3 94 70            [12] 1297 	subb	a,#0x70
      00A1D5 40 08            [24] 1298 	jc	00101$
      00A1D7 74 13            [12] 1299 	mov	a,#0x13
      00A1D9 9C               [12] 1300 	subb	a,r4
      00A1DA 74 70            [12] 1301 	mov	a,#0x70
      00A1DC 9D               [12] 1302 	subb	a,r5
      00A1DD 50 04            [24] 1303 	jnc	00102$
                                   1304 ;	free result
      00A1DF                       1305 00101$:
      00A1DF 75 82 01         [24] 1306 	mov	dpl, #0x01
      00A1E2 22               [24] 1307 	ret
      00A1E3                       1308 00102$:
                                   1309 ;	quantum/quantum.c:376: if (record->event.pressed) {
      00A1E3 12 38 0F         [24] 1310 	lcall	_ak820_outline_0009
      00A1E6 60 38            [24] 1311 	jz	00105$
                                   1312 ;	quantum/quantum.c:377: clear_keyboard();
      00A1E8 C0 05            [24] 1313 	push	ar5
      00A1EA C0 04            [24] 1314 	push	ar4
      00A1EC 12 78 B5         [24] 1315 	lcall	_clear_keyboard
      00A1EF D0 04            [24] 1316 	pop	ar4
      00A1F1 D0 05            [24] 1317 	pop	ar5
                                   1318 ;	quantum/quantum.c:378: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A1F3 BC 13 14         [24] 1319 	cjne	r4,#0x13,00108$
      00A1F6 BD 70 11         [24] 1320 	cjne	r5,#0x70,00108$
      00A1F9 90 0A D5         [24] 1321 	mov	dptr,#_keymap_config
      00A1FC E0               [24] 1322 	movx	a,@dptr
      00A1FD 23               [12] 1323 	rl	a
      00A1FE 54 01            [12] 1324 	anl	a,#0x01
      00A200 B4 01 00         [24] 1325 	cjne	a,#0x01,00136$
      00A203                       1326 00136$:
      00A203 92 27            [24] 1327 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A205 E4               [12] 1328 	clr	a
      00A206 33               [12] 1329 	rlc	a
      00A207 FF               [12] 1330 	mov	r7,a
      00A208 80 09            [24] 1331 	sjmp	00109$
      00A20A                       1332 00108$:
      00A20A E4               [12] 1333 	clr	a
      00A20B BC 11 04         [24] 1334 	cjne	r4,#0x11,00137$
      00A20E BD 70 01         [24] 1335 	cjne	r5,#0x70,00137$
      00A211 04               [12] 1336 	inc	a
      00A212                       1337 00137$:
      00A212 FF               [12] 1338 	mov	r7,a
      00A213                       1339 00109$:
                                   1340 ;	assignBit
      00A213 EF               [12] 1341 	mov	a,r7
      00A214 24 FF            [12] 1342 	add	a,#0xff
      00A216 E4               [12] 1343 	clr	a
      00A217 33               [12] 1344 	rlc	a
      00A218 90 0A D5         [24] 1345 	mov	dptr,#_keymap_config
      00A21B 13               [12] 1346 	rrc	a
      00A21C E0               [24] 1347 	movx	a,@dptr
      00A21D 92 E7            [24] 1348 	mov	acc.7,c
      00A21F F0               [24] 1349 	movx	@dptr,a
      00A220                       1350 00105$:
                                   1351 ;	quantum/quantum.c:380: return false;
      00A220 75 82 00         [24] 1352 	mov	dpl, #0x00
                                   1353 ;	quantum/quantum.c:381: }
      00A223 22               [24] 1354 	ret
                                   1355 ;------------------------------------------------------------
                                   1356 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1357 ;------------------------------------------------------------
                                   1358 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1359 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_670'
                                   1360 ;record        Allocated with name '_process_record_quantum_helper_record_10000_671'
                                   1361 ;------------------------------------------------------------
                                   1362 ;	quantum/quantum.c:384: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1363 ;	-----------------------------------------
                                   1364 ;	 function process_record_quantum_helper
                                   1365 ;	-----------------------------------------
      00A224                       1366 _process_record_quantum_helper:
      00A224 12 38 85         [24] 1367 	lcall	_ak820_outline_0108
      00A227 90 0C 23         [24] 1368 	mov	dptr,#_process_record_quantum_helper_keycode_10000_670
      00A22A 12 38 8A         [24] 1369 	lcall	_ak820_outline_0109
                                   1370 ;	quantum/quantum.c:386: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A22D 90 0C 20         [24] 1371 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A230 12 38 3E         [24] 1372 	lcall	_ak820_outline_0051
                                   1373 ;	quantum/quantum.c:429: process_ak820_nkro(keycode, record) &&
      00A233 90 0C 23         [24] 1374 	mov	dptr,#_process_record_quantum_helper_keycode_10000_670
      00A236 12 38 55         [24] 1375 	lcall	_ak820_outline_0059
      00A239 90 0C 1B         [24] 1376 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A23C 12 A3 91         [24] 1377 	lcall	_ak820_outline_0002
      00A23F C0 07            [24] 1378 	push	ar7
      00A241 C0 06            [24] 1379 	push	ar6
      00A243 C0 05            [24] 1380 	push	ar5
      00A245 C0 04            [24] 1381 	push	ar4
      00A247 12 A1 B9         [24] 1382 	lcall	_process_ak820_nkro
      00A24A E5 82            [12] 1383 	mov	a, dpl
      00A24C D0 04            [24] 1384 	pop	ar4
      00A24E D0 05            [24] 1385 	pop	ar5
      00A250 D0 06            [24] 1386 	pop	ar6
      00A252 D0 07            [24] 1387 	pop	ar7
      00A254 70 03            [24] 1388 	jnz	00204$
      00A256 02 A3 4D         [24] 1389 	ljmp	00101$
      00A259                       1390 00204$:
                                   1391 ;	quantum/quantum.c:440: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A259 90 0B D9         [24] 1392 	mov	dptr,#_process_last_key_PARM_2
      00A25C 12 A3 91         [24] 1393 	lcall	_ak820_outline_0002
      00A25F C0 07            [24] 1394 	push	ar7
      00A261 C0 06            [24] 1395 	push	ar6
      00A263 C0 05            [24] 1396 	push	ar5
      00A265 C0 04            [24] 1397 	push	ar4
      00A267 12 9C 88         [24] 1398 	lcall	_process_last_key
      00A26A E5 82            [12] 1399 	mov	a, dpl
      00A26C D0 04            [24] 1400 	pop	ar4
      00A26E D0 05            [24] 1401 	pop	ar5
      00A270 D0 06            [24] 1402 	pop	ar6
      00A272 D0 07            [24] 1403 	pop	ar7
      00A274 70 03            [24] 1404 	jnz	00205$
      00A276 02 A3 4D         [24] 1405 	ljmp	00101$
      00A279                       1406 00205$:
      00A279 90 0B DF         [24] 1407 	mov	dptr,#_process_repeat_key_PARM_2
      00A27C 12 A3 91         [24] 1408 	lcall	_ak820_outline_0002
      00A27F C0 07            [24] 1409 	push	ar7
      00A281 C0 06            [24] 1410 	push	ar6
      00A283 C0 05            [24] 1411 	push	ar5
      00A285 C0 04            [24] 1412 	push	ar4
      00A287 12 9D 06         [24] 1413 	lcall	_process_repeat_key
      00A28A E5 82            [12] 1414 	mov	a, dpl
      00A28C D0 04            [24] 1415 	pop	ar4
      00A28E D0 05            [24] 1416 	pop	ar5
      00A290 D0 06            [24] 1417 	pop	ar6
      00A292 D0 07            [24] 1418 	pop	ar7
      00A294 70 03            [24] 1419 	jnz	00206$
      00A296 02 A3 4D         [24] 1420 	ljmp	00101$
      00A299                       1421 00206$:
                                   1422 ;	quantum/quantum.c:449: process_record_via(keycode, record) &&
      00A299 90 0C 60         [24] 1423 	mov	dptr,#_process_record_via_PARM_2
      00A29C 12 A3 91         [24] 1424 	lcall	_ak820_outline_0002
      00A29F C0 07            [24] 1425 	push	ar7
      00A2A1 C0 06            [24] 1426 	push	ar6
      00A2A3 C0 05            [24] 1427 	push	ar5
      00A2A5 C0 04            [24] 1428 	push	ar4
      00A2A7 12 A8 A2         [24] 1429 	lcall	_process_record_via
      00A2AA E5 82            [12] 1430 	mov	a, dpl
      00A2AC D0 04            [24] 1431 	pop	ar4
      00A2AE D0 05            [24] 1432 	pop	ar5
      00A2B0 D0 06            [24] 1433 	pop	ar6
      00A2B2 D0 07            [24] 1434 	pop	ar7
      00A2B4 70 03            [24] 1435 	jnz	00207$
      00A2B6 02 A3 4D         [24] 1436 	ljmp	00101$
      00A2B9                       1437 00207$:
                                   1438 ;	quantum/quantum.c:459: process_record_kb(keycode, record) &&
      00A2B9 90 0B FE         [24] 1439 	mov	dptr,#_process_record_kb_PARM_2
      00A2BC 12 A3 91         [24] 1440 	lcall	_ak820_outline_0002
      00A2BF C0 07            [24] 1441 	push	ar7
      00A2C1 C0 06            [24] 1442 	push	ar6
      00A2C3 C0 05            [24] 1443 	push	ar5
      00A2C5 C0 04            [24] 1444 	push	ar4
      00A2C7 12 9F FE         [24] 1445 	lcall	_process_record_kb
      00A2CA E5 82            [12] 1446 	mov	a, dpl
      00A2CC D0 04            [24] 1447 	pop	ar4
      00A2CE D0 05            [24] 1448 	pop	ar5
      00A2D0 D0 06            [24] 1449 	pop	ar6
      00A2D2 D0 07            [24] 1450 	pop	ar7
      00A2D4 70 03            [24] 1451 	jnz	00208$
      00A2D6 02 A3 4D         [24] 1452 	ljmp	00101$
      00A2D9                       1453 00208$:
                                   1454 ;	quantum/quantum.c:482: process_caps_word(keycode, record) &&
      00A2D9 90 0B C1         [24] 1455 	mov	dptr,#_process_caps_word_PARM_2
      00A2DC 12 A3 91         [24] 1456 	lcall	_ak820_outline_0002
      00A2DF C0 07            [24] 1457 	push	ar7
      00A2E1 C0 06            [24] 1458 	push	ar6
      00A2E3 C0 05            [24] 1459 	push	ar5
      00A2E5 C0 04            [24] 1460 	push	ar4
      00A2E7 12 9A 13         [24] 1461 	lcall	_process_caps_word
      00A2EA E5 82            [12] 1462 	mov	a, dpl
      00A2EC D0 04            [24] 1463 	pop	ar4
      00A2EE D0 05            [24] 1464 	pop	ar5
      00A2F0 D0 06            [24] 1465 	pop	ar6
      00A2F2 D0 07            [24] 1466 	pop	ar7
      00A2F4 60 57            [24] 1467 	jz	00101$
                                   1468 ;	quantum/quantum.c:509: process_grave_esc(keycode, record) &&
      00A2F6 90 0B C6         [24] 1469 	mov	dptr,#_process_grave_esc_PARM_2
      00A2F9 12 A3 91         [24] 1470 	lcall	_ak820_outline_0002
      00A2FC C0 07            [24] 1471 	push	ar7
      00A2FE C0 06            [24] 1472 	push	ar6
      00A300 C0 05            [24] 1473 	push	ar5
      00A302 C0 04            [24] 1474 	push	ar4
      00A304 12 9B 26         [24] 1475 	lcall	_process_grave_esc
      00A307 E5 82            [12] 1476 	mov	a, dpl
      00A309 D0 04            [24] 1477 	pop	ar4
      00A30B D0 05            [24] 1478 	pop	ar5
      00A30D D0 06            [24] 1479 	pop	ar6
      00A30F D0 07            [24] 1480 	pop	ar7
      00A311 60 3A            [24] 1481 	jz	00101$
                                   1482 ;	quantum/quantum.c:512: process_rgb(keycode, record) &&
      00A313 90 0B E4         [24] 1483 	mov	dptr,#_process_rgb_PARM_2
      00A316 12 A3 91         [24] 1484 	lcall	_ak820_outline_0002
      00A319 C0 07            [24] 1485 	push	ar7
      00A31B C0 06            [24] 1486 	push	ar6
      00A31D C0 05            [24] 1487 	push	ar5
      00A31F C0 04            [24] 1488 	push	ar4
      00A321 12 9D 60         [24] 1489 	lcall	_process_rgb
      00A324 E5 82            [12] 1490 	mov	a, dpl
      00A326 D0 04            [24] 1491 	pop	ar4
      00A328 D0 05            [24] 1492 	pop	ar5
      00A32A D0 06            [24] 1493 	pop	ar6
      00A32C D0 07            [24] 1494 	pop	ar7
      00A32E 60 1D            [24] 1495 	jz	00101$
                                   1496 ;	quantum/quantum.c:524: process_tri_layer(keycode, record) &&
      00A330 90 0B EA         [24] 1497 	mov	dptr,#_process_tri_layer_PARM_2
      00A333 12 A3 91         [24] 1498 	lcall	_ak820_outline_0002
      00A336 C0 07            [24] 1499 	push	ar7
      00A338 C0 06            [24] 1500 	push	ar6
      00A33A C0 05            [24] 1501 	push	ar5
      00A33C C0 04            [24] 1502 	push	ar4
      00A33E 12 9E 11         [24] 1503 	lcall	_process_tri_layer
      00A341 E5 82            [12] 1504 	mov	a, dpl
      00A343 D0 04            [24] 1505 	pop	ar4
      00A345 D0 05            [24] 1506 	pop	ar5
      00A347 D0 06            [24] 1507 	pop	ar6
      00A349 D0 07            [24] 1508 	pop	ar7
      00A34B 70 04            [24] 1509 	jnz	00102$
                                   1510 ;	quantum/quantum.c:526: true)) {
      00A34D                       1511 00101$:
                                   1512 ;	quantum/quantum.c:527: return false;
      00A34D 75 82 00         [24] 1513 	mov	dpl, #0x00
      00A350 22               [24] 1514 	ret
      00A351                       1515 00102$:
                                   1516 ;	quantum/quantum.c:530: if (record->event.pressed) {
      00A351 74 05            [12] 1517 	mov	a,#0x05
      00A353 12 4A 99         [24] 1518 	lcall	_ak820_outline_0019
      00A356 60 30            [24] 1519 	jz	00117$
                                   1520 ;	quantum/quantum.c:531: switch (keycode) {
      00A358 BC 00 05         [24] 1521 	cjne	r4,#0x00,00214$
      00A35B BD 7C 02         [24] 1522 	cjne	r5,#0x7c,00214$
      00A35E 80 10            [24] 1523 	sjmp	00112$
      00A360                       1524 00214$:
      00A360 BC 01 05         [24] 1525 	cjne	r4,#0x01,00215$
      00A363 BD 7C 02         [24] 1526 	cjne	r5,#0x7c,00215$
      00A366 80 0F            [24] 1527 	sjmp	00113$
      00A368                       1528 00215$:
                                   1529 ;	quantum/quantum.c:533: case QK_BOOTLOADER:
      00A368 BC 03 1D         [24] 1530 	cjne	r4,#0x03,00117$
      00A36B BD 7C 1A         [24] 1531 	cjne	r5,#0x7c,00117$
      00A36E 80 0E            [24] 1532 	sjmp	00114$
      00A370                       1533 00112$:
                                   1534 ;	quantum/quantum.c:534: reset_keyboard();
      00A370 12 A0 54         [24] 1535 	lcall	_reset_keyboard
                                   1536 ;	quantum/quantum.c:535: return false;
      00A373 75 82 00         [24] 1537 	mov	dpl, #0x00
                                   1538 ;	quantum/quantum.c:536: case QK_REBOOT:
      00A376 22               [24] 1539 	ret
      00A377                       1540 00113$:
                                   1541 ;	quantum/quantum.c:537: soft_reset_keyboard();
      00A377 12 A0 5A         [24] 1542 	lcall	_soft_reset_keyboard
                                   1543 ;	quantum/quantum.c:538: return false;
      00A37A 75 82 00         [24] 1544 	mov	dpl, #0x00
                                   1545 ;	quantum/quantum.c:550: case QK_CLEAR_EEPROM:
      00A37D 22               [24] 1546 	ret
      00A37E                       1547 00114$:
                                   1548 ;	quantum/quantum.c:557: eeconfig_disable();
      00A37E 12 91 7F         [24] 1549 	lcall	_eeconfig_disable
                                   1550 ;	quantum/quantum.c:558: soft_reset_keyboard();
      00A381 12 A0 5A         [24] 1551 	lcall	_soft_reset_keyboard
                                   1552 ;	quantum/quantum.c:560: return false;
      00A384 75 82 00         [24] 1553 	mov	dpl, #0x00
                                   1554 ;	quantum/quantum.c:615: }
      00A387 22               [24] 1555 	ret
      00A388                       1556 00117$:
                                   1557 ;	quantum/quantum.c:618: return process_action_kb(record);
      00A388 7D 00            [12] 1558 	mov	r5,#0x00
      00A38A 12 71 CB         [24] 1559 	lcall	_ak820_outline_0064
                                   1560 ;	quantum/quantum.c:619: }
      00A38D 02 9F FA         [24] 1561 	ljmp	_process_action_kb
                                   1562 ;------------------------------------------------------------
                                   1563 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1564 ;------------------------------------------------------------
                                   1565 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_678'
                                   1566 ;------------------------------------------------------------
                                   1567 ;	quantum/quantum.c:621: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1568 ;	-----------------------------------------
                                   1569 ;	 function shutdown_user
                                   1570 ;	-----------------------------------------
      00A390                       1571 _shutdown_user:
      00A390 22               [24] 1572 	ret
                                   1573 ;------------------------------------------------------------
                                   1574 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1575 ;------------------------------------------------------------
                                   1576 ;	quantum/quantum.c:637: void suspend_power_down_quantum(void) {
                                   1577 ;	-----------------------------------------
                                   1578 	.area CSEG    (CODE)
                                   1579 	.area CONST   (CODE)
                                   1580 	.area XINIT   (CODE)
                                   1581 	.area CABS    (ABS,CODE)
                                   1582 
                                   1583 ; Experimental exact instruction outlining.
                                   1584 	.globl _ak820_outline_0002
                                   1585 	.globl _ak820_outline_0005
                                   1586 	.globl _ak820_outline_0007
                                   1587 	.globl _ak820_outline_0009
                                   1588 	.globl _ak820_outline_0010
                                   1589 	.globl _ak820_outline_0012
                                   1590 	.globl _ak820_outline_0017
                                   1591 	.globl _ak820_outline_0019
                                   1592 	.globl _ak820_outline_0022
                                   1593 	.globl _ak820_outline_0023
                                   1594 	.globl _ak820_outline_0027
                                   1595 	.globl _ak820_outline_0032
                                   1596 	.globl _ak820_outline_0034
                                   1597 	.globl _ak820_outline_0037
                                   1598 	.globl _ak820_outline_0040
                                   1599 	.globl _ak820_outline_0051
                                   1600 	.globl _ak820_outline_0059
                                   1601 	.globl _ak820_outline_0064
                                   1602 	.globl _ak820_outline_0072
                                   1603 	.globl _ak820_outline_0100
                                   1604 	.globl _ak820_outline_0108
                                   1605 	.globl _ak820_outline_0109
                                   1606 	.globl _ak820_outline_0114
                                   1607 	.globl _ak820_outline_0120
                                   1608 	.globl _ak820_outline_0122
                                   1609 	.globl _ak820_outline_0125
                                   1610 	.globl _ak820_outline_0126
                                   1611 	.globl _ak820_outline_0135
                                   1612 	.globl _ak820_outline_0144
                                   1613 	.globl _ak820_outline_0145
                                   1614 	.globl _ak820_outline_0151
                                   1615 	.globl _ak820_outline_0158
                                   1616 
                                   1617 	.area CSEG (CODE)
                                   1618 ; function ak820_outline_0002
      00A391                       1619 _ak820_outline_0002:
      00A391 EE               [12] 1620 	mov	a,r6
      00A392 F0               [24] 1621 	movx	@dptr,a
      00A393 EF               [12] 1622 	mov	a,r7
      00A394 A3               [24] 1623 	inc	dptr
      00A395 F0               [24] 1624 	movx	@dptr,a
      00A396 E4               [12] 1625 	clr	a
      00A397 A3               [24] 1626 	inc	dptr
      00A398 F0               [24] 1627 	movx	@dptr,a
      00A399 8C 82            [24] 1628 	mov	dpl,r4
      00A39B 8D 83            [24] 1629 	mov	dph,r5
      00A39D 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0010
      00A39E                       1634 _ak820_outline_0010:
      00A39E EB               [12] 1635 	mov	a,r3
      00A39F F0               [24] 1636 	movx	@dptr,a
      00A3A0 EC               [12] 1637 	mov	a,r4
      00A3A1 A3               [24] 1638 	inc	dptr
      00A3A2 F0               [24] 1639 	movx	@dptr,a
      00A3A3 ED               [12] 1640 	mov	a,r5
      00A3A4 A3               [24] 1641 	inc	dptr
      00A3A5 F0               [24] 1642 	movx	@dptr,a
      00A3A6 8E 82            [24] 1643 	mov	dpl,r6
      00A3A8 8F 83            [24] 1644 	mov	dph,r7
      00A3AA 22               [24] 1645 	ret
