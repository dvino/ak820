                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      00003C                        553 _raw_hid_receive_sloc0_1_0:
      00003C                        554 	.ds 4
      000040                        555 _raw_hid_receive_sloc1_1_0:
      000040                        556 	.ds 1
      000041                        557 _raw_hid_receive_sloc2_1_0:
      000041                        558 	.ds 1
      000042                        559 _raw_hid_receive_sloc3_1_0:
      000042                        560 	.ds 2
      000044                        561 _raw_hid_receive_sloc4_1_0:
      000044                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      000029                        579 _via_eeprom_is_valid_sloc0_1_0:
      000029                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C5B                        589 _via_eeprom_set_valid_valid_10000_609:
      000C5B                        590 	.ds 1
      000C5C                        591 _via_set_layout_options_value_10000_625:
      000C5C                        592 	.ds 4
      000C60                        593 _process_record_via_PARM_2:
      000C60                        594 	.ds 3
      000C63                        595 _process_record_via_keycode_10000_627:
      000C63                        596 	.ds 2
      000C65                        597 _raw_hid_receive_kb_PARM_2:
      000C65                        598 	.ds 1
      000C66                        599 _raw_hid_receive_kb_data_10000_633:
      000C66                        600 	.ds 3
      000C69                        601 _raw_hid_receive_PARM_2:
      000C69                        602 	.ds 1
      000C6A                        603 _raw_hid_receive_packet_10000_635:
      000C6A                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A7BD                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A7BD 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A7C0 75 F0 00         [24]  659 	mov	b, #0x00
      00A7C3 12 42 D0         [24]  660 	lcall	_eeprom_read_byte
      00A7C6 AF 82            [24]  661 	mov	r7, dpl
      00A7C8 BF 02 1E         [24]  662 	cjne	r7,#0x02,00103$
      00A7CB 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A7CE 75 F0 00         [24]  664 	mov	b, #0x00
      00A7D1 12 42 D0         [24]  665 	lcall	_eeprom_read_byte
      00A7D4 AF 82            [24]  666 	mov	r7, dpl
      00A7D6 BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A7D9 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A7DC 75 F0 00         [24]  669 	mov	b, #0x00
      00A7DF 12 42 D0         [24]  670 	lcall	_eeprom_read_byte
      00A7E2 AF 82            [24]  671 	mov	r7, dpl
      00A7E4 BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A7E7 80 04            [24]  673 	sjmp	00104$
      00A7E9                        674 00126$:
      00A7E9                        675 00103$:
                                    676 ;	assignBit
      00A7E9 C2 29            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A7EB 80 02            [24]  678 	sjmp	00105$
      00A7ED                        679 00104$:
                                    680 ;	assignBit
      00A7ED D2 29            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A7EF                        682 00105$:
      00A7EF A2 29            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A7F1 12 38 BB         [24]  684 	lcall	_ak820_outline_0158
                                    685 ;	quantum/via.c:104: }
      00A7F4 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_609'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_610'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_610'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_610'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A7F5                        699 _via_eeprom_set_valid:
      00A7F5 E5 82            [12]  700 	mov	a,dpl
      00A7F7 90 0C 5B         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A7FA F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A7FB E0               [24]  704 	movx	a,@dptr
      00A7FC 60 04            [24]  705 	jz	00103$
      00A7FE 7F 02            [12]  706 	mov	r7,#0x02
      00A800 80 02            [24]  707 	sjmp	00104$
      00A802                        708 00103$:
      00A802 7F FF            [12]  709 	mov	r7,#0xff
      00A804                        710 00104$:
      00A804 90 06 B5         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A807 EF               [12]  712 	mov	a,r7
      00A808 F0               [24]  713 	movx	@dptr,a
      00A809 90 00 25         [24]  714 	mov	dptr,#0x0025
      00A80C 75 F0 00         [24]  715 	mov	b, #0x00
      00A80F 12 50 3A         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00A812 90 0C 5B         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A815 E0               [24]  719 	movx	a,@dptr
      00A816 60 04            [24]  720 	jz	00105$
      00A818 7F 20            [12]  721 	mov	r7,#0x20
      00A81A 80 02            [24]  722 	sjmp	00106$
      00A81C                        723 00105$:
      00A81C 7F FF            [12]  724 	mov	r7,#0xff
      00A81E                        725 00106$:
      00A81E 90 06 B5         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A821 EF               [12]  727 	mov	a,r7
      00A822 F0               [24]  728 	movx	@dptr,a
      00A823 90 00 26         [24]  729 	mov	dptr,#0x0026
      00A826 75 F0 00         [24]  730 	mov	b, #0x00
      00A829 12 50 3A         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00A82C 90 0C 5B         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A82F E0               [24]  734 	movx	a,@dptr
      00A830 60 04            [24]  735 	jz	00107$
      00A832 7F 08            [12]  736 	mov	r7,#0x08
      00A834 80 02            [24]  737 	sjmp	00108$
      00A836                        738 00107$:
      00A836 7F FF            [12]  739 	mov	r7,#0xff
      00A838                        740 00108$:
      00A838 90 06 B5         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A83B EF               [12]  742 	mov	a,r7
      00A83C F0               [24]  743 	movx	@dptr,a
      00A83D 90 00 27         [24]  744 	mov	dptr,#0x0027
      00A840 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00A843 02 50 3A         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00A846                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00A846 12 A8 6F         [24]  757 	lcall	_via_get_layout_options
      00A849 12 A8 87         [24]  758 	lcall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00A84C 12 A7 BD         [24]  760 	lcall	_via_eeprom_is_valid
      00A84F E5 82            [12]  761 	mov	a, dpl
      00A851 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00A853 02 40 7F         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00A856                        766 00103$:
      00A856 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00A857                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00A857 75 82 00         [24]  777 	mov	dpl, #0x00
      00A85A 12 A7 F5         [24]  778 	lcall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00A85D 12 92 3E         [24]  780 	lcall	_ak820_outline_0154
      00A860 12 A8 88         [24]  781 	lcall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00A863 12 88 C4         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00A866 12 8D 37         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00A869 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00A86C 02 A7 F5         [24]  789 	ljmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00A86F                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00A86F 90 00 28         [24]  799 	mov	dptr,#0x0028
      00A872 75 F0 00         [24]  800 	mov	b, #0x00
      00A875 12 42 D0         [24]  801 	lcall	_eeprom_read_byte
      00A878 AF 82            [24]  802 	mov	r7, dpl
      00A87A 7E 00            [12]  803 	mov	r6,#0x00
      00A87C 7D 00            [12]  804 	mov	r5,#0x00
      00A87E 7C 00            [12]  805 	mov	r4,#0x00
      00A880 12 45 CE         [24]  806 	lcall	_ak820_outline_0160
      00A883 8D F0            [24]  807 	mov	b, r5
      00A885 EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00A886 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_622'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00A887                        820 _via_set_layout_options_kb:
      00A887 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_625'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00A888                        831 _via_set_layout_options:
      00A888 12 92 36         [24]  832 	lcall	_ak820_outline_0121
      00A88B 90 0C 5C         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A88E 12 92 24         [24]  834 	lcall	_ak820_outline_0044
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00A891 90 0C 5C         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A894 E0               [24]  837 	movx	a,@dptr
      00A895 90 06 B5         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A898 F0               [24]  839 	movx	@dptr,a
      00A899 90 00 28         [24]  840 	mov	dptr,#0x0028
      00A89C 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00A89F 02 50 3A         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_627'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_632'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00A8A2                        855 _process_record_via:
      00A8A2 12 38 85         [24]  856 	lcall	_ak820_outline_0108
      00A8A5 90 0C 63         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_627
      00A8A8 12 38 8A         [24]  858 	lcall	_ak820_outline_0109
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00A8AB 90 0C 60         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00A8AE 12 51 46         [24]  861 	lcall	_ak820_outline_0012
      00A8B1 74 05            [12]  862 	mov	a,#0x05
      00A8B3 12 38 C5         [24]  863 	lcall	_ak820_outline_0162
      00A8B6 12 6F B6         [24]  864 	lcall	_ak820_outline_0057
      00A8B9 12 BB 2F         [24]  865 	lcall	__gptrget
      00A8BC 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00A8BE 90 0C 63         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_627
      00A8C1 12 4A 83         [24]  869 	lcall	_ak820_outline_0008
      00A8C4 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00A8C6 2D               [12]  871 	add	a,r5
      00A8C7 50 12            [24]  872 	jnc	00105$
      00A8C9 C3               [12]  873 	clr	c
      00A8CA 74 7F            [12]  874 	mov	a,#0x7f
      00A8CC 9C               [12]  875 	subb	a,r4
      00A8CD 74 77            [12]  876 	mov	a,#0x77
      00A8CF 9D               [12]  877 	subb	a,r5
      00A8D0 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00A8D2 8E 82            [24]  882 	mov	dpl, r6
      00A8D4 12 8D 5D         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00A8D7 75 82 00         [24]  885 	mov	dpl, #0x00
      00A8DA 22               [24]  886 	ret
      00A8DB                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00A8DB 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00A8DE 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_633'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_634'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00A8DF                        903 _raw_hid_receive_kb:
      00A8DF 12 45 6F         [24]  904 	lcall	_ak820_outline_0037
      00A8E2 90 0C 66         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A8E5 12 38 26         [24]  906 	lcall	_ak820_outline_0017
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00A8E8 90 0C 66         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A8EB 12 51 20         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00A8EE 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00A8F0 02 BA F4         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_635'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_636'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_636'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_636'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_642'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_650'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_654'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_655'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_656'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_661'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_663'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_672'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_673'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_678'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_678'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_683'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_683'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_690'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00A8F3                        950 _raw_hid_receive:
      00A8F3 12 45 6F         [24]  951 	lcall	_ak820_outline_0037
      00A8F6 90 0C 6A         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A8F9 12 38 26         [24]  953 	lcall	_ak820_outline_0017
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00A8FC 90 0C 6A         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A8FF 12 38 3E         [24]  956 	lcall	_ak820_outline_0051
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00A902 74 01            [12]  958 	mov	a,#0x01
      00A904 12 45 D3         [24]  959 	lcall	_ak820_outline_0163
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00A907 90 0C 69         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00A90A E0               [24]  962 	movx	a,@dptr
      00A90B FB               [12]  963 	mov	r3,a
      00A90C BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00A90F 80 01            [24]  965 	sjmp	00102$
      00A911                        966 00520$:
      00A911 22               [24]  967 	ret
      00A912                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00A912 90 0E 39         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00A915 E0               [24]  971 	movx	a,@dptr
      00A916 60 31            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00A918 12 38 73         [24]  974 	lcall	_ak820_outline_0100
      00A91B FA               [12]  975 	mov	r2,a
      00A91C BA FE 02         [24]  976 	cjne	r2,#0xfe,00522$
      00A91F 80 01            [24]  977 	sjmp	00104$
      00A921                        978 00522$:
                                    979 ;	quantum/via.c:252: return;
      00A921 22               [24]  980 	ret
      00A922                        981 00104$:
                                    982 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00A922 12 45 A0         [24]  983 	lcall	_ak820_outline_0095
                                    984 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00A925 FA               [12]  985 	mov	r2,a
      00A926 60 21            [24]  986 	jz	00114$
      00A928 BA 01 02         [24]  987 	cjne	r2,#0x01,00524$
      00A92B 80 1C            [24]  988 	sjmp	00114$
      00A92D                        989 00524$:
      00A92D BA 02 02         [24]  990 	cjne	r2,#0x02,00525$
      00A930 80 17            [24]  991 	sjmp	00114$
      00A932                        992 00525$:
      00A932 BA 05 02         [24]  993 	cjne	r2,#0x05,00526$
      00A935 80 12            [24]  994 	sjmp	00114$
      00A937                        995 00526$:
      00A937 BA 06 02         [24]  996 	cjne	r2,#0x06,00527$
      00A93A 80 0D            [24]  997 	sjmp	00114$
      00A93C                        998 00527$:
      00A93C BA 07 02         [24]  999 	cjne	r2,#0x07,00528$
      00A93F 80 08            [24] 1000 	sjmp	00114$
      00A941                       1001 00528$:
      00A941 BA 08 02         [24] 1002 	cjne	r2,#0x08,00529$
      00A944 80 03            [24] 1003 	sjmp	00530$
      00A946                       1004 00529$:
      00A946 02 AE 7D         [24] 1005 	ljmp	00171$
      00A949                       1006 00530$:
                                   1007 ;	quantum/via.c:259: goto skip;
      00A949                       1008 00114$:
                                   1009 ;	quantum/via.c:263: switch (*command_id) {
      00A949 12 38 73         [24] 1010 	lcall	_ak820_outline_0100
      00A94C FA               [12] 1011 	mov	r2,a
      00A94D BA 01 02         [24] 1012 	cjne	r2,#0x01,00531$
      00A950 80 6E            [24] 1013 	sjmp	00115$
      00A952                       1014 00531$:
      00A952 BA 02 02         [24] 1015 	cjne	r2,#0x02,00532$
      00A955 80 76            [24] 1016 	sjmp	00116$
      00A957                       1017 00532$:
      00A957 BA 03 03         [24] 1018 	cjne	r2,#0x03,00533$
      00A95A 02 AA 8F         [24] 1019 	ljmp	00125$
      00A95D                       1020 00533$:
      00A95D BA 04 03         [24] 1021 	cjne	r2,#0x04,00534$
      00A960 02 AB 24         [24] 1022 	ljmp	00129$
      00A963                       1023 00534$:
      00A963 BA 05 03         [24] 1024 	cjne	r2,#0x05,00535$
      00A966 02 AB 5E         [24] 1025 	ljmp	00130$
      00A969                       1026 00535$:
      00A969 BA 06 03         [24] 1027 	cjne	r2,#0x06,00536$
      00A96C 02 AB CA         [24] 1028 	ljmp	00135$
      00A96F                       1029 00536$:
      00A96F BA 07 03         [24] 1030 	cjne	r2,#0x07,00537$
      00A972 02 AB DC         [24] 1031 	ljmp	00136$
      00A975                       1032 00537$:
      00A975 BA 08 03         [24] 1033 	cjne	r2,#0x08,00538$
      00A978 02 AB F7         [24] 1034 	ljmp	00137$
      00A97B                       1035 00538$:
      00A97B BA 09 03         [24] 1036 	cjne	r2,#0x09,00539$
      00A97E 02 AC 12         [24] 1037 	ljmp	00138$
      00A981                       1038 00539$:
      00A981 BA 0B 03         [24] 1039 	cjne	r2,#0x0b,00540$
      00A984 02 AE 0B         [24] 1040 	ljmp	00161$
      00A987                       1041 00540$:
      00A987 BA 0C 03         [24] 1042 	cjne	r2,#0x0c,00541$
      00A98A 02 AC 2D         [24] 1043 	ljmp	00139$
      00A98D                       1044 00541$:
      00A98D BA 0D 03         [24] 1045 	cjne	r2,#0x0d,00542$
      00A990 02 AC 4E         [24] 1046 	ljmp	00140$
      00A993                       1047 00542$:
      00A993 BA 0E 03         [24] 1048 	cjne	r2,#0x0e,00543$
      00A996 02 AC 77         [24] 1049 	ljmp	00141$
      00A999                       1050 00543$:
      00A999 BA 0F 03         [24] 1051 	cjne	r2,#0x0f,00544$
      00A99C 02 AC BF         [24] 1052 	ljmp	00144$
      00A99F                       1053 00544$:
      00A99F BA 10 03         [24] 1054 	cjne	r2,#0x10,00545$
      00A9A2 02 AD 2E         [24] 1055 	ljmp	00151$
      00A9A5                       1056 00545$:
      00A9A5 BA 11 03         [24] 1057 	cjne	r2,#0x11,00546$
      00A9A8 02 AD 47         [24] 1058 	ljmp	00154$
      00A9AB                       1059 00546$:
      00A9AB BA 12 03         [24] 1060 	cjne	r2,#0x12,00547$
      00A9AE 02 AD 68         [24] 1061 	ljmp	00155$
      00A9B1                       1062 00547$:
      00A9B1 BA 13 03         [24] 1063 	cjne	r2,#0x13,00548$
      00A9B4 02 AD B0         [24] 1064 	ljmp	00158$
      00A9B7                       1065 00548$:
      00A9B7 BA FE 03         [24] 1066 	cjne	r2,#0xfe,00549$
      00A9BA 02 AE 4B         [24] 1067 	ljmp	00168$
      00A9BD                       1068 00549$:
      00A9BD 02 AE 65         [24] 1069 	ljmp	00169$
                                   1070 ;	quantum/via.c:264: case id_get_protocol_version: {
      00A9C0                       1071 00115$:
                                   1072 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00A9C0 12 38 A1         [24] 1073 	lcall	_ak820_outline_0126
      00A9C3 E4               [12] 1074 	clr	a
      00A9C4 12 45 67         [24] 1075 	lcall	_ak820_outline_0035
                                   1076 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00A9C7 74 09            [12] 1077 	mov	a,#0x09
      00A9C9 F0               [24] 1078 	movx	@dptr,a
                                   1079 ;	quantum/via.c:267: break;
      00A9CA 02 AE 7D         [24] 1080 	ljmp	00171$
                                   1081 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00A9CD                       1082 00116$:
                                   1083 ;	quantum/via.c:270: switch (command_data[0]) {
      00A9CD 12 45 A0         [24] 1084 	lcall	_ak820_outline_0095
      00A9D0 FA               [12] 1085 	mov	r2,a
      00A9D1 BA 01 02         [24] 1086 	cjne	r2,#0x01,00550$
      00A9D4 80 0E            [24] 1087 	sjmp	00117$
      00A9D6                       1088 00550$:
      00A9D6 BA 02 02         [24] 1089 	cjne	r2,#0x02,00551$
      00A9D9 80 34            [24] 1090 	sjmp	00118$
      00A9DB                       1091 00551$:
      00A9DB BA 03 03         [24] 1092 	cjne	r2,#0x03,00552$
      00A9DE 02 AA 4A         [24] 1093 	ljmp	00119$
      00A9E1                       1094 00552$:
      00A9E1 02 AA 74         [24] 1095 	ljmp	00123$
                                   1096 ;	quantum/via.c:271: case id_uptime: {
      00A9E4                       1097 00117$:
                                   1098 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00A9E4 12 4B 62         [24] 1099 	lcall	_timer_read32
      00A9E7 85 82 3C         [24] 1100 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A9EA 85 83 3D         [24] 1101 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A9ED 85 F0 3E         [24] 1102 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A9F0 F5 3F            [12] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1104 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00A9F2 12 38 96         [24] 1105 	lcall	_ak820_outline_0122
      00A9F5 A3               [24] 1106 	inc	dptr
      00A9F6 A3               [24] 1107 	inc	dptr
      00A9F7 E5 3F            [12] 1108 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A9F9 12 45 67         [24] 1109 	lcall	_ak820_outline_0035
                                   1110 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00A9FC A3               [24] 1111 	inc	dptr
      00A9FD E5 3E            [12] 1112 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A9FF F0               [24] 1113 	movx	@dptr,a
                                   1114 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00AA00 12 AE AA         [24] 1115 	lcall	_ak820_outline_0024
      00AA03 E5 3D            [12] 1116 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AA05 F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00AA06 12 45 5D         [24] 1119 	lcall	_ak820_outline_0011
      00AA09 E5 3C            [12] 1120 	mov	a,_raw_hid_receive_sloc0_1_0
      00AA0B F0               [24] 1121 	movx	@dptr,a
                                   1122 ;	quantum/via.c:277: break;
      00AA0C 02 AE 7D         [24] 1123 	ljmp	00171$
                                   1124 ;	quantum/via.c:279: case id_layout_options: {
      00AA0F                       1125 00118$:
                                   1126 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00AA0F C0 03            [24] 1127 	push	ar3
      00AA11 C0 07            [24] 1128 	push	ar7
      00AA13 C0 06            [24] 1129 	push	ar6
      00AA15 C0 03            [24] 1130 	push	ar3
      00AA17 12 A8 6F         [24] 1131 	lcall	_via_get_layout_options
      00AA1A 85 82 3C         [24] 1132 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00AA1D 85 83 3D         [24] 1133 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00AA20 85 F0 3E         [24] 1134 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00AA23 F5 3F            [12] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AA25 D0 03            [24] 1136 	pop	ar3
      00AA27 D0 06            [24] 1137 	pop	ar6
      00AA29 D0 07            [24] 1138 	pop	ar7
                                   1139 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00AA2B 12 38 96         [24] 1140 	lcall	_ak820_outline_0122
      00AA2E A3               [24] 1141 	inc	dptr
      00AA2F A3               [24] 1142 	inc	dptr
      00AA30 E5 3F            [12] 1143 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AA32 12 45 67         [24] 1144 	lcall	_ak820_outline_0035
                                   1145 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00AA35 A3               [24] 1146 	inc	dptr
      00AA36 E5 3E            [12] 1147 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AA38 F0               [24] 1148 	movx	@dptr,a
                                   1149 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00AA39 12 AE AA         [24] 1150 	lcall	_ak820_outline_0024
      00AA3C E5 3D            [12] 1151 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AA3E F0               [24] 1152 	movx	@dptr,a
                                   1153 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00AA3F 12 45 5D         [24] 1154 	lcall	_ak820_outline_0011
      00AA42 E5 3C            [12] 1155 	mov	a,_raw_hid_receive_sloc0_1_0
      00AA44 F0               [24] 1156 	movx	@dptr,a
                                   1157 ;	quantum/via.c:285: break;
      00AA45 D0 03            [24] 1158 	pop	ar3
      00AA47 02 AE 7D         [24] 1159 	ljmp	00171$
                                   1160 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00AA4A                       1161 00119$:
                                   1162 ;	quantum/via.c:290: if (!vial_unlocked)
      00AA4A 90 0E 38         [24] 1163 	mov	dptr,#_vial_unlocked
      00AA4D E0               [24] 1164 	movx	a,@dptr
      00AA4E 70 03            [24] 1165 	jnz	00553$
      00AA50 02 AE 7D         [24] 1166 	ljmp	00171$
      00AA53                       1167 00553$:
                                   1168 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AA53 7A 01            [12] 1169 	mov	r2,#0x01
      00AA55 79 00            [12] 1170 	mov	r1,#0x00
      00AA57                       1171 00173$:
      00AA57 B9 10 00         [24] 1172 	cjne	r1,#0x10,00554$
      00AA5A                       1173 00554$:
      00AA5A 40 03            [24] 1174 	jc	00555$
      00AA5C 02 AE 7D         [24] 1175 	ljmp	00171$
      00AA5F                       1176 00555$:
                                   1177 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00AA5F 89 82            [24] 1178 	mov	dpl, r1
      00AA61 12 5B DB         [24] 1179 	lcall	_matrix_get_row
      00AA64 A8 82            [24] 1180 	mov	r0, dpl
                                   1181 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00AA66 EA               [12] 1182 	mov	a,r2
      00AA67 2C               [12] 1183 	add	a, r4
      00AA68 F5 82            [12] 1184 	mov	dpl,a
      00AA6A E4               [12] 1185 	clr	a
      00AA6B 3D               [12] 1186 	addc	a, r5
      00AA6C F5 83            [12] 1187 	mov	dph,a
      00AA6E 0A               [12] 1188 	inc	r2
      00AA6F E8               [12] 1189 	mov	a,r0
      00AA70 F0               [24] 1190 	movx	@dptr,a
                                   1191 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00AA71 09               [12] 1192 	inc	r1
                                   1193 ;	quantum/via.c:312: default: {
      00AA72 80 E3            [24] 1194 	sjmp	00173$
      00AA74                       1195 00123$:
                                   1196 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00AA74 12 4A E6         [24] 1197 	lcall	_ak820_outline_0076
      00AA77 90 0C 65         [24] 1198 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AA7A 12 AE B3         [24] 1199 	lcall	_ak820_outline_0041
      00AA7D C0 07            [24] 1200 	push	ar7
      00AA7F C0 06            [24] 1201 	push	ar6
      00AA81 C0 03            [24] 1202 	push	ar3
      00AA83 12 A8 DF         [24] 1203 	lcall	_raw_hid_receive_kb
      00AA86 D0 03            [24] 1204 	pop	ar3
      00AA88 D0 06            [24] 1205 	pop	ar6
      00AA8A D0 07            [24] 1206 	pop	ar7
                                   1207 ;	quantum/via.c:317: break;
      00AA8C 02 AE 7D         [24] 1208 	ljmp	00171$
                                   1209 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00AA8F                       1210 00125$:
                                   1211 ;	quantum/via.c:320: switch (command_data[0]) {
      00AA8F 12 45 A0         [24] 1212 	lcall	_ak820_outline_0095
      00AA92 FA               [12] 1213 	mov	r2,a
      00AA93 BA 02 02         [24] 1214 	cjne	r2,#0x02,00556$
      00AA96 80 03            [24] 1215 	sjmp	00557$
      00AA98                       1216 00556$:
      00AA98 02 AB 09         [24] 1217 	ljmp	00127$
      00AA9B                       1218 00557$:
                                   1219 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00AA9B C0 03            [24] 1220 	push	ar3
      00AA9D 12 38 36         [24] 1221 	lcall	_ak820_outline_0032
      00AAA0 F8               [12] 1222 	mov	r0,a
      00AAA1 79 00            [12] 1223 	mov	r1,#0x00
      00AAA3 7B 00            [12] 1224 	mov	r3,#0x00
      00AAA5 88 3F            [24] 1225 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00AAA7 8B 3C            [24] 1226 	mov	_raw_hid_receive_sloc0_1_0,r3
      00AAA9 8B 3D            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00AAAB 8B 3E            [24] 1228 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00AAAD 12 AE A1         [24] 1229 	lcall	_ak820_outline_0018
      00AAB0 F8               [12] 1230 	mov	r0,a
      00AAB1 89 03            [24] 1231 	mov	ar3,r1
      00AAB3 88 02            [24] 1232 	mov	ar2,r0
      00AAB5 E4               [12] 1233 	clr	a
      00AAB6 42 3C            [12] 1234 	orl	_raw_hid_receive_sloc0_1_0,a
      00AAB8 E9               [12] 1235 	mov	a,r1
      00AAB9 42 3D            [12] 1236 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AABB EA               [12] 1237 	mov	a,r2
      00AABC 42 3E            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AABE EB               [12] 1239 	mov	a,r3
      00AABF 42 3F            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AAC1 12 AE AA         [24] 1241 	lcall	_ak820_outline_0024
      00AAC4 E0               [24] 1242 	movx	a,@dptr
      00AAC5 F8               [12] 1243 	mov	r0,a
      00AAC6 79 00            [12] 1244 	mov	r1,#0x00
      00AAC8 7A 00            [12] 1245 	mov	r2,#0x00
      00AACA 8A 03            [24] 1246 	mov	ar3,r2
      00AACC 89 02            [24] 1247 	mov	ar2,r1
      00AACE 88 01            [24] 1248 	mov	ar1,r0
      00AAD0 E4               [12] 1249 	clr	a
      00AAD1 42 3C            [12] 1250 	orl	_raw_hid_receive_sloc0_1_0,a
      00AAD3 E9               [12] 1251 	mov	a,r1
      00AAD4 42 3D            [12] 1252 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00AAD6 EA               [12] 1253 	mov	a,r2
      00AAD7 42 3E            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00AAD9 EB               [12] 1255 	mov	a,r3
      00AADA 42 3F            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00AADC 12 45 5D         [24] 1257 	lcall	_ak820_outline_0011
      00AADF E0               [24] 1258 	movx	a,@dptr
      00AAE0 F8               [12] 1259 	mov	r0,a
      00AAE1 E4               [12] 1260 	clr	a
      00AAE2 F9               [12] 1261 	mov	r1,a
      00AAE3 FA               [12] 1262 	mov	r2,a
      00AAE4 FB               [12] 1263 	mov	r3,a
      00AAE5 E5 3D            [12] 1264 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AAE7 42 01            [12] 1265 	orl	ar1,a
      00AAE9 E5 3E            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00AAEB 42 02            [12] 1267 	orl	ar2,a
      00AAED E5 3F            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00AAEF 42 03            [12] 1269 	orl	ar3,a
                                   1270 ;	quantum/via.c:323: via_set_layout_options(value);
      00AAF1 12 4B 0F         [24] 1271 	lcall	_ak820_outline_0113
      00AAF4 EB               [12] 1272 	mov	a, r3
      00AAF5 C0 07            [24] 1273 	push	ar7
      00AAF7 C0 06            [24] 1274 	push	ar6
      00AAF9 C0 03            [24] 1275 	push	ar3
      00AAFB 12 A8 88         [24] 1276 	lcall	_via_set_layout_options
      00AAFE D0 03            [24] 1277 	pop	ar3
      00AB00 D0 06            [24] 1278 	pop	ar6
      00AB02 D0 07            [24] 1279 	pop	ar7
                                   1280 ;	quantum/via.c:324: break;
      00AB04 D0 03            [24] 1281 	pop	ar3
      00AB06 02 AE 7D         [24] 1282 	ljmp	00171$
                                   1283 ;	quantum/via.c:326: default: {
      00AB09                       1284 00127$:
                                   1285 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00AB09 12 4A E6         [24] 1286 	lcall	_ak820_outline_0076
      00AB0C 90 0C 65         [24] 1287 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AB0F 12 AE B3         [24] 1288 	lcall	_ak820_outline_0041
      00AB12 C0 07            [24] 1289 	push	ar7
      00AB14 C0 06            [24] 1290 	push	ar6
      00AB16 C0 03            [24] 1291 	push	ar3
      00AB18 12 A8 DF         [24] 1292 	lcall	_raw_hid_receive_kb
      00AB1B D0 03            [24] 1293 	pop	ar3
      00AB1D D0 06            [24] 1294 	pop	ar6
      00AB1F D0 07            [24] 1295 	pop	ar7
                                   1296 ;	quantum/via.c:331: break;
      00AB21 02 AE 7D         [24] 1297 	ljmp	00171$
                                   1298 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00AB24                       1299 00129$:
                                   1300 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00AB24 12 45 A0         [24] 1301 	lcall	_ak820_outline_0095
      00AB27 FA               [12] 1302 	mov	r2,a
      00AB28 12 38 36         [24] 1303 	lcall	_ak820_outline_0032
      00AB2B F9               [12] 1304 	mov	r1,a
      00AB2C 12 AE A1         [24] 1305 	lcall	_ak820_outline_0018
      00AB2F F8               [12] 1306 	mov	r0,a
      00AB30 90 0A F2         [24] 1307 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00AB33 E9               [12] 1308 	mov	a,r1
      00AB34 F0               [24] 1309 	movx	@dptr,a
      00AB35 90 0A F3         [24] 1310 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00AB38 E8               [12] 1311 	mov	a,r0
      00AB39 F0               [24] 1312 	movx	@dptr,a
      00AB3A 8A 82            [24] 1313 	mov	dpl, r2
      00AB3C C0 07            [24] 1314 	push	ar7
      00AB3E C0 06            [24] 1315 	push	ar6
      00AB40 C0 03            [24] 1316 	push	ar3
      00AB42 12 85 EF         [24] 1317 	lcall	_dynamic_keymap_get_keycode
      00AB45 A9 82            [24] 1318 	mov	r1, dpl
      00AB47 AA 83            [24] 1319 	mov	r2, dph
      00AB49 D0 03            [24] 1320 	pop	ar3
      00AB4B D0 06            [24] 1321 	pop	ar6
      00AB4D D0 07            [24] 1322 	pop	ar7
                                   1323 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00AB4F 12 AE AA         [24] 1324 	lcall	_ak820_outline_0024
      00AB52 8A 00            [24] 1325 	mov	ar0,r2
      00AB54 E8               [12] 1326 	mov	a,r0
      00AB55 F0               [24] 1327 	movx	@dptr,a
                                   1328 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00AB56 12 45 5D         [24] 1329 	lcall	_ak820_outline_0011
      00AB59 E9               [12] 1330 	mov	a,r1
      00AB5A F0               [24] 1331 	movx	@dptr,a
                                   1332 ;	quantum/via.c:337: break;
      00AB5B 02 AE 7D         [24] 1333 	ljmp	00171$
                                   1334 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00AB5E                       1335 00130$:
                                   1336 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00AB5E 90 0E 38         [24] 1337 	mov	dptr,#_vial_unlocked
      00AB61 E0               [24] 1338 	movx	a,@dptr
      00AB62 70 19            [24] 1339 	jnz	00132$
      00AB64 12 AE AA         [24] 1340 	lcall	_ak820_outline_0024
      00AB67 E0               [24] 1341 	movx	a,@dptr
      00AB68 FA               [12] 1342 	mov	r2,a
      00AB69 BA 7C 11         [24] 1343 	cjne	r2,#0x7c,00132$
      00AB6C 74 05            [12] 1344 	mov	a,#0x05
      00AB6E 2E               [12] 1345 	add	a, r6
      00AB6F 12 38 1C         [24] 1346 	lcall	_ak820_outline_0016
      00AB72 70 09            [24] 1347 	jnz	00132$
                                   1348 ;	quantum/via.c:344: *command_id = id_unhandled;
      00AB74 12 38 96         [24] 1349 	lcall	_ak820_outline_0122
      00AB77 74 FF            [12] 1350 	mov	a,#0xff
      00AB79 F0               [24] 1351 	movx	@dptr,a
                                   1352 ;	quantum/via.c:345: break;
      00AB7A 02 AE 7D         [24] 1353 	ljmp	00171$
      00AB7D                       1354 00132$:
                                   1355 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00AB7D C0 03            [24] 1356 	push	ar3
      00AB7F 12 45 A0         [24] 1357 	lcall	_ak820_outline_0095
      00AB82 F5 41            [12] 1358 	mov	_raw_hid_receive_sloc2_1_0,a
      00AB84 12 38 36         [24] 1359 	lcall	_ak820_outline_0032
      00AB87 F5 40            [12] 1360 	mov	_raw_hid_receive_sloc1_1_0,a
      00AB89 12 AE A1         [24] 1361 	lcall	_ak820_outline_0018
      00AB8C F5 3C            [12] 1362 	mov	_raw_hid_receive_sloc0_1_0,a
      00AB8E 12 AE AA         [24] 1363 	lcall	_ak820_outline_0024
      00AB91 E0               [24] 1364 	movx	a,@dptr
      00AB92 FB               [12] 1365 	mov	r3,a
      00AB93 78 00            [12] 1366 	mov	r0,#0x00
      00AB95 12 45 5D         [24] 1367 	lcall	_ak820_outline_0011
      00AB98 E0               [24] 1368 	movx	a,@dptr
      00AB99 7A 00            [12] 1369 	mov	r2,#0x00
      00AB9B 42 00            [12] 1370 	orl	ar0,a
      00AB9D EA               [12] 1371 	mov	a,r2
      00AB9E 42 03            [12] 1372 	orl	ar3,a
      00ABA0 90 0A F5         [24] 1373 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00ABA3 E5 40            [12] 1374 	mov	a,_raw_hid_receive_sloc1_1_0
      00ABA5 F0               [24] 1375 	movx	@dptr,a
      00ABA6 90 0A F6         [24] 1376 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00ABA9 E5 3C            [12] 1377 	mov	a,_raw_hid_receive_sloc0_1_0
      00ABAB F0               [24] 1378 	movx	@dptr,a
      00ABAC 90 0A F7         [24] 1379 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00ABAF E8               [12] 1380 	mov	a,r0
      00ABB0 12 79 7C         [24] 1381 	lcall	_ak820_outline_0189
      00ABB3 85 41 82         [24] 1382 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00ABB6 C0 07            [24] 1383 	push	ar7
      00ABB8 C0 06            [24] 1384 	push	ar6
      00ABBA C0 03            [24] 1385 	push	ar3
      00ABBC 12 86 3D         [24] 1386 	lcall	_dynamic_keymap_set_keycode
      00ABBF D0 03            [24] 1387 	pop	ar3
      00ABC1 D0 06            [24] 1388 	pop	ar6
      00ABC3 D0 07            [24] 1389 	pop	ar7
                                   1390 ;	quantum/via.c:349: break;
      00ABC5 D0 03            [24] 1391 	pop	ar3
      00ABC7 02 AE 7D         [24] 1392 	ljmp	00171$
                                   1393 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00ABCA                       1394 00135$:
                                   1395 ;	quantum/via.c:352: dynamic_keymap_reset();
      00ABCA C0 07            [24] 1396 	push	ar7
      00ABCC C0 06            [24] 1397 	push	ar6
      00ABCE C0 03            [24] 1398 	push	ar3
      00ABD0 12 88 C4         [24] 1399 	lcall	_dynamic_keymap_reset
      00ABD3 D0 03            [24] 1400 	pop	ar3
      00ABD5 D0 06            [24] 1401 	pop	ar6
      00ABD7 D0 07            [24] 1402 	pop	ar7
                                   1403 ;	quantum/via.c:353: break;
      00ABD9 02 AE 7D         [24] 1404 	ljmp	00171$
                                   1405 ;	quantum/via.c:355: case id_lighting_set_value: {
      00ABDC                       1406 00136$:
                                   1407 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00ABDC 12 4A E6         [24] 1408 	lcall	_ak820_outline_0076
      00ABDF 90 0D B0         [24] 1409 	mov	dptr,#_vialrgb_set_value_PARM_2
      00ABE2 12 AE B3         [24] 1410 	lcall	_ak820_outline_0041
      00ABE5 C0 07            [24] 1411 	push	ar7
      00ABE7 C0 06            [24] 1412 	push	ar6
      00ABE9 C0 03            [24] 1413 	push	ar3
      00ABEB 12 B8 C9         [24] 1414 	lcall	_vialrgb_set_value
      00ABEE D0 03            [24] 1415 	pop	ar3
      00ABF0 D0 06            [24] 1416 	pop	ar6
      00ABF2 D0 07            [24] 1417 	pop	ar7
                                   1418 ;	quantum/via.c:375: break;
      00ABF4 02 AE 7D         [24] 1419 	ljmp	00171$
                                   1420 ;	quantum/via.c:377: case id_lighting_get_value: {
      00ABF7                       1421 00137$:
                                   1422 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00ABF7 12 4A E6         [24] 1423 	lcall	_ak820_outline_0076
      00ABFA 90 0D AC         [24] 1424 	mov	dptr,#_vialrgb_get_value_PARM_2
      00ABFD 12 AE B3         [24] 1425 	lcall	_ak820_outline_0041
      00AC00 C0 07            [24] 1426 	push	ar7
      00AC02 C0 06            [24] 1427 	push	ar6
      00AC04 C0 03            [24] 1428 	push	ar3
      00AC06 12 B7 5D         [24] 1429 	lcall	_vialrgb_get_value
      00AC09 D0 03            [24] 1430 	pop	ar3
      00AC0B D0 06            [24] 1431 	pop	ar6
      00AC0D D0 07            [24] 1432 	pop	ar7
                                   1433 ;	quantum/via.c:397: break;
      00AC0F 02 AE 7D         [24] 1434 	ljmp	00171$
                                   1435 ;	quantum/via.c:399: case id_lighting_save: {
      00AC12                       1436 00138$:
                                   1437 ;	quantum/via.c:407: vialrgb_save(data, length);
      00AC12 12 4A E6         [24] 1438 	lcall	_ak820_outline_0076
      00AC15 90 0D B4         [24] 1439 	mov	dptr,#_vialrgb_save_PARM_2
      00AC18 12 AE B3         [24] 1440 	lcall	_ak820_outline_0041
      00AC1B C0 07            [24] 1441 	push	ar7
      00AC1D C0 06            [24] 1442 	push	ar6
      00AC1F C0 03            [24] 1443 	push	ar3
      00AC21 12 B9 58         [24] 1444 	lcall	_vialrgb_save
      00AC24 D0 03            [24] 1445 	pop	ar3
      00AC26 D0 06            [24] 1446 	pop	ar6
      00AC28 D0 07            [24] 1447 	pop	ar7
                                   1448 ;	quantum/via.c:419: break;
      00AC2A 02 AE 7D         [24] 1449 	ljmp	00171$
                                   1450 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00AC2D                       1451 00139$:
                                   1452 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00AC2D C0 07            [24] 1453 	push	ar7
      00AC2F C0 06            [24] 1454 	push	ar6
      00AC31 C0 05            [24] 1455 	push	ar5
      00AC33 C0 04            [24] 1456 	push	ar4
      00AC35 C0 03            [24] 1457 	push	ar3
      00AC37 12 8C B3         [24] 1458 	lcall	_dynamic_keymap_macro_get_count
      00AC3A AA 82            [24] 1459 	mov	r2, dpl
      00AC3C D0 03            [24] 1460 	pop	ar3
      00AC3E D0 04            [24] 1461 	pop	ar4
      00AC40 D0 05            [24] 1462 	pop	ar5
      00AC42 D0 06            [24] 1463 	pop	ar6
      00AC44 D0 07            [24] 1464 	pop	ar7
      00AC46 12 38 A1         [24] 1465 	lcall	_ak820_outline_0126
      00AC49 EA               [12] 1466 	mov	a,r2
      00AC4A F0               [24] 1467 	movx	@dptr,a
                                   1468 ;	quantum/via.c:430: break;
      00AC4B 02 AE 7D         [24] 1469 	ljmp	00171$
                                   1470 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00AC4E                       1471 00140$:
                                   1472 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00AC4E C0 07            [24] 1473 	push	ar7
      00AC50 C0 06            [24] 1474 	push	ar6
      00AC52 C0 05            [24] 1475 	push	ar5
      00AC54 C0 04            [24] 1476 	push	ar4
      00AC56 C0 03            [24] 1477 	push	ar3
      00AC58 12 8C B7         [24] 1478 	lcall	_dynamic_keymap_macro_get_buffer_size
      00AC5B A9 82            [24] 1479 	mov	r1, dpl
      00AC5D AA 83            [24] 1480 	mov	r2, dph
      00AC5F D0 03            [24] 1481 	pop	ar3
      00AC61 D0 04            [24] 1482 	pop	ar4
      00AC63 D0 05            [24] 1483 	pop	ar5
      00AC65 D0 06            [24] 1484 	pop	ar6
      00AC67 D0 07            [24] 1485 	pop	ar7
                                   1486 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00AC69 8A 00            [24] 1487 	mov	ar0,r2
      00AC6B 12 38 A1         [24] 1488 	lcall	_ak820_outline_0126
      00AC6E E8               [12] 1489 	mov	a,r0
      00AC6F 12 45 67         [24] 1490 	lcall	_ak820_outline_0035
                                   1491 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00AC72 E9               [12] 1492 	mov	a,r1
      00AC73 F0               [24] 1493 	movx	@dptr,a
                                   1494 ;	quantum/via.c:436: break;
      00AC74 02 AE 7D         [24] 1495 	ljmp	00171$
                                   1496 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00AC77                       1497 00141$:
                                   1498 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AC77 C0 03            [24] 1499 	push	ar3
      00AC79 12 AE 8A         [24] 1500 	lcall	_ak820_outline_0003
      00AC7C 89 3C            [24] 1501 	mov	_raw_hid_receive_sloc0_1_0,r1
      00AC7E 8A 3D            [24] 1502 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1503 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00AC80 12 AE A1         [24] 1504 	lcall	_ak820_outline_0018
      00AC83 FB               [12] 1505 	mov	r3,a
                                   1506 ;	quantum/via.c:441: if (size <= 28)
      00AC84 8B 42            [24] 1507 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AC86 75 43 00         [24] 1508 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AC89 C3               [12] 1509 	clr	c
      00AC8A 74 1C            [12] 1510 	mov	a,#0x1c
      00AC8C 9B               [12] 1511 	subb	a,r3
      00AC8D D0 03            [24] 1512 	pop	ar3
      00AC8F 50 03            [24] 1513 	jnc	00562$
      00AC91 02 AE 7D         [24] 1514 	ljmp	00171$
      00AC94                       1515 00562$:
                                   1516 ;	free result
                                   1517 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00AC94 12 AE BC         [24] 1518 	lcall	_ak820_outline_0068
      00AC97 90 0B 44         [24] 1519 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00AC9A E5 42            [12] 1520 	mov	a,_raw_hid_receive_sloc3_1_0
      00AC9C F0               [24] 1521 	movx	@dptr,a
      00AC9D E5 43            [12] 1522 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AC9F A3               [24] 1523 	inc	dptr
      00ACA0 F0               [24] 1524 	movx	@dptr,a
      00ACA1 90 0B 46         [24] 1525 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00ACA4 12 AE C6         [24] 1526 	lcall	_ak820_outline_0087
      00ACA7 85 3C 82         [24] 1527 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00ACAA 85 3D 83         [24] 1528 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00ACAD C0 07            [24] 1529 	push	ar7
      00ACAF C0 06            [24] 1530 	push	ar6
      00ACB1 C0 03            [24] 1531 	push	ar3
      00ACB3 12 8C BB         [24] 1532 	lcall	_dynamic_keymap_macro_get_buffer
      00ACB6 D0 03            [24] 1533 	pop	ar3
      00ACB8 D0 06            [24] 1534 	pop	ar6
      00ACBA D0 07            [24] 1535 	pop	ar7
                                   1536 ;	quantum/via.c:443: break;
      00ACBC 02 AE 7D         [24] 1537 	ljmp	00171$
                                   1538 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00ACBF                       1539 00144$:
                                   1540 ;	quantum/via.c:448: if (!vial_unlocked) {
      00ACBF 90 0E 38         [24] 1541 	mov	dptr,#_vial_unlocked
      00ACC2 E0               [24] 1542 	movx	a,@dptr
      00ACC3 70 01            [24] 1543 	jnz	00146$
                                   1544 ;	quantum/via.c:450: return;
      00ACC5 22               [24] 1545 	ret
      00ACC6                       1546 00146$:
                                   1547 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00ACC6 C0 03            [24] 1548 	push	ar3
      00ACC8 12 AE 8A         [24] 1549 	lcall	_ak820_outline_0003
      00ACCB 89 42            [24] 1550 	mov	_raw_hid_receive_sloc3_1_0,r1
      00ACCD 8A 43            [24] 1551 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1552 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00ACCF 12 AE A1         [24] 1553 	lcall	_ak820_outline_0018
      00ACD2 F5 3C            [12] 1554 	mov	_raw_hid_receive_sloc0_1_0, a
      00ACD4 75 3D 00         [24] 1555 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1556 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00ACD7 85 3C 44         [24] 1557 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00ACDA 85 3D 45         [24] 1558 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00ACDD C3               [12] 1559 	clr	c
      00ACDE 74 1C            [12] 1560 	mov	a,#0x1c
      00ACE0 95 44            [12] 1561 	subb	a,_raw_hid_receive_sloc4_1_0
      00ACE2 E4               [12] 1562 	clr	a
      00ACE3 95 45            [12] 1563 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00ACE5 D0 03            [24] 1564 	pop	ar3
      00ACE7 40 44            [24] 1565 	jc	00147$
                                   1566 ;	free result
      00ACE9 8B 01            [24] 1567 	mov	ar1,r3
      00ACEB 7A 00            [12] 1568 	mov	r2,#0x00
      00ACED E9               [12] 1569 	mov	a,r1
      00ACEE 24 FC            [12] 1570 	add	a,#0xfc
      00ACF0 F9               [12] 1571 	mov	r1,a
      00ACF1 EA               [12] 1572 	mov	a,r2
      00ACF2 34 FF            [12] 1573 	addc	a,#0xff
      00ACF4 FA               [12] 1574 	mov	r2,a
      00ACF5 C3               [12] 1575 	clr	c
      00ACF6 E9               [12] 1576 	mov	a,r1
      00ACF7 95 44            [12] 1577 	subb	a,_raw_hid_receive_sloc4_1_0
      00ACF9 EA               [12] 1578 	mov	a,r2
      00ACFA 95 45            [12] 1579 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00ACFC 40 2F            [24] 1580 	jc	00147$
                                   1581 ;	free result
      00ACFE 12 AE BC         [24] 1582 	lcall	_ak820_outline_0068
      00AD01 90 0B 4B         [24] 1583 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00AD04 E5 3C            [12] 1584 	mov	a,_raw_hid_receive_sloc0_1_0
      00AD06 F0               [24] 1585 	movx	@dptr,a
      00AD07 E5 3D            [12] 1586 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00AD09 A3               [24] 1587 	inc	dptr
      00AD0A F0               [24] 1588 	movx	@dptr,a
      00AD0B 90 0B 4D         [24] 1589 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00AD0E 12 AE C6         [24] 1590 	lcall	_ak820_outline_0087
      00AD11 85 42 82         [24] 1591 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00AD14 85 43 83         [24] 1592 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00AD17 C0 07            [24] 1593 	push	ar7
      00AD19 C0 06            [24] 1594 	push	ar6
      00AD1B C0 03            [24] 1595 	push	ar3
      00AD1D 12 8D 09         [24] 1596 	lcall	_dynamic_keymap_macro_set_buffer
      00AD20 E5 82            [12] 1597 	mov	a, dpl
      00AD22 D0 03            [24] 1598 	pop	ar3
      00AD24 D0 06            [24] 1599 	pop	ar6
      00AD26 D0 07            [24] 1600 	pop	ar7
      00AD28 60 03            [24] 1601 	jz	00566$
      00AD2A 02 AE 7D         [24] 1602 	ljmp	00171$
      00AD2D                       1603 00566$:
      00AD2D                       1604 00147$:
      00AD2D 22               [24] 1605 	ret
                                   1606 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00AD2E                       1607 00151$:
                                   1608 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00AD2E 90 0E 38         [24] 1609 	mov	dptr,#_vial_unlocked
      00AD31 E0               [24] 1610 	movx	a,@dptr
      00AD32 70 01            [24] 1611 	jnz	00153$
      00AD34 22               [24] 1612 	ret
      00AD35                       1613 00153$:
                                   1614 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00AD35 C0 07            [24] 1615 	push	ar7
      00AD37 C0 06            [24] 1616 	push	ar6
      00AD39 C0 03            [24] 1617 	push	ar3
      00AD3B 12 8D 37         [24] 1618 	lcall	_dynamic_keymap_macro_reset
      00AD3E D0 03            [24] 1619 	pop	ar3
      00AD40 D0 06            [24] 1620 	pop	ar6
      00AD42 D0 07            [24] 1621 	pop	ar7
                                   1622 ;	quantum/via.c:473: break;
      00AD44 02 AE 7D         [24] 1623 	ljmp	00171$
                                   1624 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00AD47                       1625 00154$:
                                   1626 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00AD47 C0 07            [24] 1627 	push	ar7
      00AD49 C0 06            [24] 1628 	push	ar6
      00AD4B C0 05            [24] 1629 	push	ar5
      00AD4D C0 04            [24] 1630 	push	ar4
      00AD4F C0 03            [24] 1631 	push	ar3
      00AD51 12 85 B6         [24] 1632 	lcall	_dynamic_keymap_get_layer_count
      00AD54 AA 82            [24] 1633 	mov	r2, dpl
      00AD56 D0 03            [24] 1634 	pop	ar3
      00AD58 D0 04            [24] 1635 	pop	ar4
      00AD5A D0 05            [24] 1636 	pop	ar5
      00AD5C D0 06            [24] 1637 	pop	ar6
      00AD5E D0 07            [24] 1638 	pop	ar7
      00AD60 12 38 A1         [24] 1639 	lcall	_ak820_outline_0126
      00AD63 EA               [12] 1640 	mov	a,r2
      00AD64 F0               [24] 1641 	movx	@dptr,a
                                   1642 ;	quantum/via.c:477: break;
      00AD65 02 AE 7D         [24] 1643 	ljmp	00171$
                                   1644 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00AD68                       1645 00155$:
                                   1646 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00AD68 C0 03            [24] 1647 	push	ar3
      00AD6A 12 AE 8A         [24] 1648 	lcall	_ak820_outline_0003
      00AD6D 89 44            [24] 1649 	mov	_raw_hid_receive_sloc4_1_0,r1
      00AD6F 8A 45            [24] 1650 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1651 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00AD71 12 AE A1         [24] 1652 	lcall	_ak820_outline_0018
      00AD74 FB               [12] 1653 	mov	r3,a
                                   1654 ;	quantum/via.c:482: if (size <= 28)
      00AD75 8B 42            [24] 1655 	mov	_raw_hid_receive_sloc3_1_0,r3
      00AD77 75 43 00         [24] 1656 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00AD7A C3               [12] 1657 	clr	c
      00AD7B 74 1C            [12] 1658 	mov	a,#0x1c
      00AD7D 9B               [12] 1659 	subb	a,r3
      00AD7E D0 03            [24] 1660 	pop	ar3
      00AD80 50 03            [24] 1661 	jnc	00568$
      00AD82 02 AE 7D         [24] 1662 	ljmp	00171$
      00AD85                       1663 00568$:
                                   1664 ;	free result
                                   1665 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00AD85 12 AE BC         [24] 1666 	lcall	_ak820_outline_0068
      00AD88 90 0B 2D         [24] 1667 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00AD8B E5 42            [12] 1668 	mov	a,_raw_hid_receive_sloc3_1_0
      00AD8D F0               [24] 1669 	movx	@dptr,a
      00AD8E E5 43            [12] 1670 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00AD90 A3               [24] 1671 	inc	dptr
      00AD91 F0               [24] 1672 	movx	@dptr,a
      00AD92 90 0B 2F         [24] 1673 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00AD95 12 AE C6         [24] 1674 	lcall	_ak820_outline_0087
      00AD98 85 44 82         [24] 1675 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00AD9B 85 45 83         [24] 1676 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00AD9E C0 07            [24] 1677 	push	ar7
      00ADA0 C0 06            [24] 1678 	push	ar6
      00ADA2 C0 03            [24] 1679 	push	ar3
      00ADA4 12 8A 83         [24] 1680 	lcall	_dynamic_keymap_get_buffer
      00ADA7 D0 03            [24] 1681 	pop	ar3
      00ADA9 D0 06            [24] 1682 	pop	ar6
      00ADAB D0 07            [24] 1683 	pop	ar7
                                   1684 ;	quantum/via.c:484: break;
      00ADAD 02 AE 7D         [24] 1685 	ljmp	00171$
                                   1686 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00ADB0                       1687 00158$:
                                   1688 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00ADB0 12 45 A0         [24] 1689 	lcall	_ak820_outline_0095
      00ADB3 FD               [12] 1690 	mov	r5,a
      00ADB4 7C 00            [12] 1691 	mov	r4,#0x00
      00ADB6 12 38 36         [24] 1692 	lcall	_ak820_outline_0032
      00ADB9 7A 00            [12] 1693 	mov	r2,#0x00
      00ADBB 42 04            [12] 1694 	orl	ar4,a
      00ADBD EA               [12] 1695 	mov	a,r2
      00ADBE 42 05            [12] 1696 	orl	ar5,a
      00ADC0 8C 44            [24] 1697 	mov	_raw_hid_receive_sloc4_1_0,r4
      00ADC2 8D 45            [24] 1698 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1699 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00ADC4 12 AE A1         [24] 1700 	lcall	_ak820_outline_0018
      00ADC7 F9               [12] 1701 	mov	r1,a
      00ADC8 7A 00            [12] 1702 	mov	r2,#0x00
                                   1703 ;	quantum/via.c:489: if (size <= 28)
      00ADCA 89 00            [24] 1704 	mov	ar0,r1
      00ADCC E8               [12] 1705 	mov	a,r0
      00ADCD 24 E3            [12] 1706 	add	a,#0xff - 0x1c
      00ADCF 50 03            [24] 1707 	jnc	00569$
      00ADD1 02 AE 7D         [24] 1708 	ljmp	00171$
      00ADD4                       1709 00569$:
                                   1710 ;	free result
                                   1711 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00ADD4 C0 03            [24] 1712 	push	ar3
      00ADD6 74 04            [12] 1713 	mov	a,#0x04
      00ADD8 2E               [12] 1714 	add	a, r6
      00ADD9 F8               [12] 1715 	mov	r0,a
      00ADDA E4               [12] 1716 	clr	a
      00ADDB 3F               [12] 1717 	addc	a, r7
      00ADDC FB               [12] 1718 	mov	r3,a
      00ADDD 7D 00            [12] 1719 	mov	r5,#0x00
      00ADDF 90 0B 34         [24] 1720 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00ADE2 E9               [12] 1721 	mov	a,r1
      00ADE3 F0               [24] 1722 	movx	@dptr,a
      00ADE4 EA               [12] 1723 	mov	a,r2
      00ADE5 A3               [24] 1724 	inc	dptr
      00ADE6 F0               [24] 1725 	movx	@dptr,a
      00ADE7 90 0B 36         [24] 1726 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00ADEA E8               [12] 1727 	mov	a,r0
      00ADEB 12 79 7C         [24] 1728 	lcall	_ak820_outline_0189
      00ADEE ED               [12] 1729 	mov	a,r5
      00ADEF A3               [24] 1730 	inc	dptr
      00ADF0 F0               [24] 1731 	movx	@dptr,a
      00ADF1 85 44 82         [24] 1732 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00ADF4 85 45 83         [24] 1733 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00ADF7 C0 07            [24] 1734 	push	ar7
      00ADF9 C0 06            [24] 1735 	push	ar6
      00ADFB C0 03            [24] 1736 	push	ar3
      00ADFD 12 8A C1         [24] 1737 	lcall	_dynamic_keymap_set_buffer
      00AE00 D0 03            [24] 1738 	pop	ar3
      00AE02 D0 06            [24] 1739 	pop	ar6
      00AE04 D0 07            [24] 1740 	pop	ar7
                                   1741 ;	quantum/via.c:491: break;
      00AE06 D0 03            [24] 1742 	pop	ar3
      00AE08 02 AE 7D         [24] 1743 	ljmp	00171$
                                   1744 ;	quantum/via.c:495: case id_bootloader_jump: {
      00AE0B                       1745 00161$:
                                   1746 ;	quantum/via.c:497: if (!vial_unlocked)
      00AE0B 90 0E 38         [24] 1747 	mov	dptr,#_vial_unlocked
      00AE0E E0               [24] 1748 	movx	a,@dptr
      00AE0F 70 03            [24] 1749 	jnz	00570$
      00AE11 02 AE 7D         [24] 1750 	ljmp	00171$
      00AE14                       1751 00570$:
                                   1752 ;	quantum/via.c:501: raw_hid_send(data, length);
      00AE14 12 AE D8         [24] 1753 	lcall	_ak820_outline_0152
      00AE17 90 06 8F         [24] 1754 	mov	dptr,#_raw_hid_send_PARM_2
      00AE1A 12 AE CF         [24] 1755 	lcall	_ak820_outline_0088
      00AE1D C0 07            [24] 1756 	push	ar7
      00AE1F C0 06            [24] 1757 	push	ar6
      00AE21 C0 03            [24] 1758 	push	ar3
      00AE23 12 4D 4E         [24] 1759 	lcall	_raw_hid_send
      00AE26 D0 03            [24] 1760 	pop	ar3
      00AE28 D0 06            [24] 1761 	pop	ar6
      00AE2A D0 07            [24] 1762 	pop	ar7
                                   1763 ;	quantum/via.c:503: wait_ms(100);
      00AE2C 7D 64            [12] 1764 	mov	r5,#0x64
      00AE2E                       1765 00176$:
      00AE2E ED               [12] 1766 	mov	a,r5
      00AE2F 60 09            [24] 1767 	jz	00166$
      00AE31 90 00 01         [24] 1768 	mov	dptr,#0x0001
      00AE34 12 5B 1A         [24] 1769 	lcall	_mDelaymS
      00AE37 1D               [12] 1770 	dec	r5
      00AE38 80 F4            [24] 1771 	sjmp	00176$
      00AE3A                       1772 00166$:
                                   1773 ;	quantum/via.c:504: bootloader_jump();
      00AE3A C0 07            [24] 1774 	push	ar7
      00AE3C C0 06            [24] 1775 	push	ar6
      00AE3E C0 03            [24] 1776 	push	ar3
      00AE40 12 34 0E         [24] 1777 	lcall	_bootloader_jump
      00AE43 D0 03            [24] 1778 	pop	ar3
      00AE45 D0 06            [24] 1779 	pop	ar6
      00AE47 D0 07            [24] 1780 	pop	ar7
                                   1781 ;	quantum/via.c:505: break;
                                   1782 ;	quantum/via.c:509: case id_vial_prefix: {
      00AE49 80 32            [24] 1783 	sjmp	00171$
      00AE4B                       1784 00168$:
                                   1785 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00AE4B 12 AE D8         [24] 1786 	lcall	_ak820_outline_0152
      00AE4E 90 0C 77         [24] 1787 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AE51 12 AE CF         [24] 1788 	lcall	_ak820_outline_0088
      00AE54 C0 07            [24] 1789 	push	ar7
      00AE56 C0 06            [24] 1790 	push	ar6
      00AE58 C0 03            [24] 1791 	push	ar3
      00AE5A 12 AF C5         [24] 1792 	lcall	_vial_handle_cmd
      00AE5D D0 03            [24] 1793 	pop	ar3
      00AE5F D0 06            [24] 1794 	pop	ar6
      00AE61 D0 07            [24] 1795 	pop	ar7
                                   1796 ;	quantum/via.c:511: break;
                                   1797 ;	quantum/via.c:514: default: {
      00AE63 80 18            [24] 1798 	sjmp	00171$
      00AE65                       1799 00169$:
                                   1800 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00AE65 12 AE D8         [24] 1801 	lcall	_ak820_outline_0152
      00AE68 90 0C 65         [24] 1802 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00AE6B 12 AE CF         [24] 1803 	lcall	_ak820_outline_0088
      00AE6E C0 07            [24] 1804 	push	ar7
      00AE70 C0 06            [24] 1805 	push	ar6
      00AE72 C0 03            [24] 1806 	push	ar3
      00AE74 12 A8 DF         [24] 1807 	lcall	_raw_hid_receive_kb
      00AE77 D0 03            [24] 1808 	pop	ar3
      00AE79 D0 06            [24] 1809 	pop	ar6
      00AE7B D0 07            [24] 1810 	pop	ar7
                                   1811 ;	quantum/via.c:521: skip:
      00AE7D                       1812 00171$:
                                   1813 ;	quantum/via.c:525: raw_hid_send(data, length);
      00AE7D 7D 00            [12] 1814 	mov	r5,#0x00
      00AE7F 90 06 8F         [24] 1815 	mov	dptr,#_raw_hid_send_PARM_2
      00AE82 EB               [12] 1816 	mov	a,r3
      00AE83 F0               [24] 1817 	movx	@dptr,a
      00AE84 12 71 CB         [24] 1818 	lcall	_ak820_outline_0064
                                   1819 ;	quantum/via.c:526: }
      00AE87 02 4D 4E         [24] 1820 	ljmp	_raw_hid_send
                                   1821 	.area CSEG    (CODE)
                                   1822 	.area CONST   (CODE)
                                   1823 	.area XINIT   (CODE)
                                   1824 	.area CABS    (ABS,CODE)
                                   1825 
                                   1826 ; Experimental exact instruction outlining.
                                   1827 	.globl _ak820_outline_0001
                                   1828 	.globl _ak820_outline_0003
                                   1829 	.globl _ak820_outline_0008
                                   1830 	.globl _ak820_outline_0011
                                   1831 	.globl _ak820_outline_0012
                                   1832 	.globl _ak820_outline_0016
                                   1833 	.globl _ak820_outline_0017
                                   1834 	.globl _ak820_outline_0018
                                   1835 	.globl _ak820_outline_0024
                                   1836 	.globl _ak820_outline_0032
                                   1837 	.globl _ak820_outline_0035
                                   1838 	.globl _ak820_outline_0037
                                   1839 	.globl _ak820_outline_0041
                                   1840 	.globl _ak820_outline_0044
                                   1841 	.globl _ak820_outline_0051
                                   1842 	.globl _ak820_outline_0057
                                   1843 	.globl _ak820_outline_0064
                                   1844 	.globl _ak820_outline_0068
                                   1845 	.globl _ak820_outline_0076
                                   1846 	.globl _ak820_outline_0087
                                   1847 	.globl _ak820_outline_0088
                                   1848 	.globl _ak820_outline_0095
                                   1849 	.globl _ak820_outline_0100
                                   1850 	.globl _ak820_outline_0108
                                   1851 	.globl _ak820_outline_0109
                                   1852 	.globl _ak820_outline_0113
                                   1853 	.globl _ak820_outline_0121
                                   1854 	.globl _ak820_outline_0122
                                   1855 	.globl _ak820_outline_0126
                                   1856 	.globl _ak820_outline_0152
                                   1857 	.globl _ak820_outline_0154
                                   1858 	.globl _ak820_outline_0158
                                   1859 	.globl _ak820_outline_0160
                                   1860 	.globl _ak820_outline_0162
                                   1861 	.globl _ak820_outline_0163
                                   1862 	.globl _ak820_outline_0189
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0003
      00AE8A                       1866 _ak820_outline_0003:
      00AE8A 8C 82            [24] 1867 	mov	dpl,r4
      00AE8C 8D 83            [24] 1868 	mov	dph,r5
      00AE8E E0               [24] 1869 	movx	a,@dptr
      00AE8F FA               [12] 1870 	mov	r2,a
      00AE90 79 00            [12] 1871 	mov	r1,#0x00
      00AE92 8E 82            [24] 1872 	mov	dpl,r6
      00AE94 8F 83            [24] 1873 	mov	dph,r7
      00AE96 A3               [24] 1874 	inc	dptr
      00AE97 A3               [24] 1875 	inc	dptr
      00AE98 E0               [24] 1876 	movx	a,@dptr
      00AE99 7B 00            [12] 1877 	mov	r3,#0x00
      00AE9B 42 01            [12] 1878 	orl	ar1,a
      00AE9D EB               [12] 1879 	mov	a,r3
      00AE9E 42 02            [12] 1880 	orl	ar2,a
      00AEA0 22               [24] 1881 	ret
                                   1882 
                                   1883 	.area CSEG (CODE)
                                   1884 ; function ak820_outline_0018
      00AEA1                       1885 _ak820_outline_0018:
      00AEA1 8E 82            [24] 1886 	mov	dpl,r6
      00AEA3 8F 83            [24] 1887 	mov	dph,r7
      00AEA5 A3               [24] 1888 	inc	dptr
      00AEA6 A3               [24] 1889 	inc	dptr
      00AEA7 A3               [24] 1890 	inc	dptr
      00AEA8 E0               [24] 1891 	movx	a,@dptr
      00AEA9 22               [24] 1892 	ret
                                   1893 
                                   1894 	.area CSEG (CODE)
                                   1895 ; function ak820_outline_0024
      00AEAA                       1896 _ak820_outline_0024:
      00AEAA 8E 82            [24] 1897 	mov	dpl,r6
      00AEAC 8F 83            [24] 1898 	mov	dph,r7
      00AEAE A3               [24] 1899 	inc	dptr
      00AEAF A3               [24] 1900 	inc	dptr
      00AEB0 A3               [24] 1901 	inc	dptr
      00AEB1 A3               [24] 1902 	inc	dptr
      00AEB2 22               [24] 1903 	ret
                                   1904 
                                   1905 	.area CSEG (CODE)
                                   1906 ; function ak820_outline_0041
      00AEB3                       1907 _ak820_outline_0041:
      00AEB3 EB               [12] 1908 	mov	a,r3
      00AEB4 F0               [24] 1909 	movx	@dptr,a
      00AEB5 88 82            [24] 1910 	mov	dpl,r0
      00AEB7 89 83            [24] 1911 	mov	dph,r1
      00AEB9 8A F0            [24] 1912 	mov	b,r2
      00AEBB 22               [24] 1913 	ret
                                   1914 
                                   1915 	.area CSEG (CODE)
                                   1916 ; function ak820_outline_0068
      00AEBC                       1917 _ak820_outline_0068:
      00AEBC 74 04            [12] 1918 	mov	a,#0x04
      00AEBE 2E               [12] 1919 	add	a,r6
      00AEBF F9               [12] 1920 	mov	r1,a
      00AEC0 E4               [12] 1921 	clr	a
      00AEC1 3F               [12] 1922 	addc	a,r7
      00AEC2 F8               [12] 1923 	mov	r0,a
      00AEC3 7A 00            [12] 1924 	mov	r2,#0x00
      00AEC5 22               [24] 1925 	ret
                                   1926 
                                   1927 	.area CSEG (CODE)
                                   1928 ; function ak820_outline_0087
      00AEC6                       1929 _ak820_outline_0087:
      00AEC6 E9               [12] 1930 	mov	a,r1
      00AEC7 F0               [24] 1931 	movx	@dptr,a
      00AEC8 E8               [12] 1932 	mov	a,r0
      00AEC9 A3               [24] 1933 	inc	dptr
      00AECA F0               [24] 1934 	movx	@dptr,a
      00AECB EA               [12] 1935 	mov	a,r2
      00AECC A3               [24] 1936 	inc	dptr
      00AECD F0               [24] 1937 	movx	@dptr,a
      00AECE 22               [24] 1938 	ret
                                   1939 
                                   1940 	.area CSEG (CODE)
                                   1941 ; function ak820_outline_0088
      00AECF                       1942 _ak820_outline_0088:
      00AECF EB               [12] 1943 	mov	a,r3
      00AED0 F0               [24] 1944 	movx	@dptr,a
      00AED1 8A 82            [24] 1945 	mov	dpl,r2
      00AED3 8C 83            [24] 1946 	mov	dph,r4
      00AED5 8D F0            [24] 1947 	mov	b,r5
      00AED7 22               [24] 1948 	ret
                                   1949 
                                   1950 	.area CSEG (CODE)
                                   1951 ; function ak820_outline_0152
      00AED8                       1952 _ak820_outline_0152:
      00AED8 8E 02            [24] 1953 	mov	ar2,r6
      00AEDA 8F 04            [24] 1954 	mov	ar4,r7
      00AEDC 7D 00            [12] 1955 	mov	r5,#0x00
      00AEDE 22               [24] 1956 	ret
