;--------------------------------------------------------
; File Created by SDCC : free open source ISO C Compiler
; Version 4.6.0 #16555 (Linux)
;--------------------------------------------------------
	.module quantum
	
	.optsdcc -mmcs51 --model-large
;--------------------------------------------------------
; Public variables in this module
;--------------------------------------------------------
	.globl _shutdown_quantum
	.globl _do_code16
	.globl _extract_mod_bits
	.globl _process_tri_layer
	.globl _process_rgb
	.globl _process_grave_esc
	.globl _ak820_combo_process
	.globl _ak820_combo_tick
	.globl _ak820_leader_process
	.globl _process_repeat_key
	.globl _process_last_key
	.globl _process_caps_word
	.globl _process_record_via
	.globl _suspend_power_down_kb
	.globl _suspend_wakeup_init_kb
	.globl _led_wakeup
	.globl _led_suspend
	.globl _mcu_reset
	.globl _bootloader_jump
	.globl _ak820_resolve_key
	.globl _default_layer_set
	.globl _clear_keyboard
	.globl _unregister_weak_mods
	.globl _register_weak_mods
	.globl _unregister_mods
	.globl _register_mods
	.globl _unregister_code
	.globl _register_code
	.globl _eeconfig_update_default_layer
	.globl _eeconfig_disable
	.globl _rgb_matrix_set_suspend_state
	.globl _rgb_matrix_task
	.globl _mDelaymS
	.globl _ADC_START
	.globl _S0_R_FIFO
	.globl _S0_T_FIFO
	.globl _S0_FREE
	.globl _S0_IF_BYTE
	.globl _S0_IF_FIRST
	.globl _S0_IF_OV
	.globl _S0_FST_ACT
	.globl _CP_RL2
	.globl _C_T2
	.globl _TR2
	.globl _EXEN2
	.globl _TCLK
	.globl _RCLK
	.globl _EXF2
	.globl _CAP1F
	.globl _TF2
	.globl _RI
	.globl _TI
	.globl _RB8
	.globl _TB8
	.globl _REN
	.globl _SM2
	.globl _SM1
	.globl _SM0
	.globl _IT0
	.globl _IE0
	.globl _IT1
	.globl _IE1
	.globl _TR0
	.globl _TF0
	.globl _TR1
	.globl _TF1
	.globl _P4_0
	.globl _P4_1
	.globl _P4_2
	.globl _P4_3
	.globl _P4_4
	.globl _P4_5
	.globl _P4_6
	.globl _RXD
	.globl _TXD
	.globl _INT0
	.globl _INT1
	.globl _T0
	.globl _T1
	.globl _MOSI1
	.globl _MISO1
	.globl _SCK1
	.globl _P3_0
	.globl _P3_1
	.globl _P3_2
	.globl _P3_3
	.globl _P3_4
	.globl _P3_5
	.globl _P3_6
	.globl _P3_7
	.globl _CAP1_
	.globl _T2_
	.globl _CAP2_
	.globl _T2EX_
	.globl _RXD1
	.globl _TXD1
	.globl _P2_0
	.globl _P2_1
	.globl _P2_2
	.globl _P2_3
	.globl _P2_4
	.globl _P2_5
	.globl _P2_6
	.globl _P2_7
	.globl _AIN0
	.globl _AIN1
	.globl _AIN2
	.globl _AIN3
	.globl _AIN4
	.globl _AIN5
	.globl _AIN6
	.globl _AIN7
	.globl _CAP1
	.globl _T2
	.globl _CAP2
	.globl _T2EX
	.globl _INT0_
	.globl _SCS
	.globl _MOSI
	.globl _MISO
	.globl _SCK
	.globl _RXD1_
	.globl _TXD1_
	.globl _P1_0
	.globl _P1_1
	.globl _P1_2
	.globl _P1_3
	.globl _P1_4
	.globl _P1_5
	.globl _P1_6
	.globl _P1_7
	.globl _AIN8
	.globl _AIN9
	.globl _AIN10
	.globl _AIN11
	.globl _AIN12
	.globl _AIN13
	.globl _RXD_
	.globl _TXD_
	.globl _SCL0
	.globl _SDA0
	.globl _P0_0
	.globl _P0_1
	.globl _P0_2
	.globl _P0_3
	.globl _P0_4
	.globl _P0_5
	.globl _P0_6
	.globl _P0_7
	.globl _IE_SPI0
	.globl _IE_USB
	.globl _IE_ADC
	.globl _IE_UART1
	.globl _IE_PWM_I2C
	.globl _IE_GPIO
	.globl _IE_WDOG
	.globl _PX0
	.globl _PT0
	.globl _PX1
	.globl _PT1
	.globl _PS
	.globl _PT2
	.globl _PL_FLAG
	.globl _PH_FLAG
	.globl _EX0
	.globl _ET0
	.globl _EX1
	.globl _ET1
	.globl _ES
	.globl _ET2
	.globl _E_DIS
	.globl _EA
	.globl _P
	.globl _F1
	.globl _OV
	.globl _RS0
	.globl _RS1
	.globl _F0
	.globl _AC
	.globl _CY
	.globl _I2CS_INT_ST
	.globl _I2CX_INT
	.globl _LED_STATUS
	.globl _LED_DMA_H
	.globl _LED_DMA_L
	.globl _LED_DMA
	.globl _LED_PWM_OE
	.globl _LED_COMMON
	.globl _ADC_CHAN
	.globl _ADC_DAT_H
	.globl _ADC_DAT_L
	.globl _ADC_DAT
	.globl _ADC_CTRL
	.globl _SPI1_CK_SE
	.globl _SPI1_CTRL
	.globl _SPI1_DATA
	.globl _SPI1_STAT
	.globl _SIF1
	.globl _SBAUD1
	.globl _SBUF1
	.globl _SCON1
	.globl _SPI0_SETUP
	.globl _SPI0_CK_SE
	.globl _SPI0_CTRL
	.globl _SPI0_DATA
	.globl _SPI0_STAT
	.globl _T2CAP1H
	.globl _T2CAP1L
	.globl _T2CAP1
	.globl _TH2
	.globl _TL2
	.globl _T2COUNT
	.globl _RCAP2H
	.globl _RCAP2L
	.globl _RCAP2
	.globl _T2MOD
	.globl _T2CON
	.globl _SBUF
	.globl _SCON
	.globl _TH1
	.globl _TH0
	.globl _TL1
	.globl _TL0
	.globl _TMOD
	.globl _TCON
	.globl _XBUS_AUX
	.globl _P7
	.globl _P6_DIR
	.globl _P6_OUT_PU
	.globl _P6_IN
	.globl _P5_DIR
	.globl _P5_OUT_PU
	.globl _P5_IN
	.globl _P4_LED_KEY
	.globl _P4_DIR_PU
	.globl _P4_MOD_OC
	.globl _P4
	.globl _P3_DIR_PU
	.globl _P3_MOD_OC
	.globl _P3
	.globl _P2_DIR_PU
	.globl _P2_MOD_OC
	.globl _P2
	.globl _P1_DIR_PU
	.globl _P1_MOD_OC
	.globl _P1
	.globl _P0_DIR_PU
	.globl _P0_MOD_OC
	.globl _P0
	.globl _ROM_CTRL
	.globl _ROM_DATA_HH
	.globl _ROM_DATA_HL
	.globl _ROM_DATA_HI
	.globl _ROM_ADDR_H
	.globl _ROM_ADDR_L
	.globl _ROM_ADDR
	.globl _GPIO_IE
	.globl _IP_EX
	.globl _IE_EX
	.globl _IP
	.globl _IE
	.globl _WDOG_COUNT
	.globl _RESET_KEEP
	.globl _WAKE_CTRL
	.globl _CLOCK_CFG
	.globl _POWER_CFG
	.globl _PCON
	.globl _GLOBAL_CFG
	.globl _SAFE_MOD
	.globl _DPH
	.globl _DPL
	.globl _SP
	.globl _A_INV
	.globl _B
	.globl _ACC
	.globl _PSW
	.globl _get_u16_str_PARM_2
	.globl _get_u8_str_PARM_2
	.globl _get_numeric_str_PARM_4
	.globl _get_numeric_str_PARM_3
	.globl _get_numeric_str_PARM_2
	.globl _process_record_quantum_helper_PARM_2
	.globl _get_event_keycode_PARM_1
	.globl _get_record_keycode_PARM_2
	.globl _post_process_record_user_PARM_2
	.globl _post_process_record_kb_PARM_2
	.globl _process_record_user_PARM_2
	.globl _process_record_kb_PARM_2
	.globl _pre_process_record_user_PARM_2
	.globl _pre_process_record_kb_PARM_2
	.globl _tap_code16_delay_PARM_2
	.globl _do_code16_PARM_2
	.globl _register_code16
	.globl _unregister_code16
	.globl _tap_code16_delay
	.globl _tap_code16
	.globl _pre_process_record_kb
	.globl _pre_process_record_user
	.globl _process_action_kb
	.globl _process_record_kb
	.globl _process_record_user
	.globl _post_process_record_kb
	.globl _post_process_record_user
	.globl _reset_keyboard
	.globl _soft_reset_keyboard
	.globl _get_record_keycode
	.globl _get_event_keycode
	.globl _pre_process_record_quantum
	.globl _post_process_record_quantum
	.globl _process_record_quantum
	.globl _process_record_quantum_helper
	.globl _set_single_persistent_default_layer
	.globl _startup_user
	.globl _shutdown_user
	.globl _suspend_power_down_quantum
	.globl _suspend_wakeup_init_quantum
	.globl _get_numeric_str
	.globl _get_u8_str
	.globl _get_u16_str
;--------------------------------------------------------
; special function registers
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_PSW	=	0x00d0
_ACC	=	0x00e0
_B	=	0x00f0
_A_INV	=	0x00fd
_SP	=	0x0081
_DPL	=	0x0082
_DPH	=	0x0083
_SAFE_MOD	=	0x00a1
_GLOBAL_CFG	=	0x00b1
_PCON	=	0x0087
_POWER_CFG	=	0x00ba
_CLOCK_CFG	=	0x00b9
_WAKE_CTRL	=	0x00a9
_RESET_KEEP	=	0x00fe
_WDOG_COUNT	=	0x00ff
_IE	=	0x00a8
_IP	=	0x00b8
_IE_EX	=	0x00e8
_IP_EX	=	0x00e9
_GPIO_IE	=	0x00b2
_ROM_ADDR	=	0x8584
_ROM_ADDR_L	=	0x0084
_ROM_ADDR_H	=	0x0085
_ROM_DATA_HI	=	0x8f8e
_ROM_DATA_HL	=	0x008e
_ROM_DATA_HH	=	0x008f
_ROM_CTRL	=	0x0086
_P0	=	0x0080
_P0_MOD_OC	=	0x00c4
_P0_DIR_PU	=	0x00c5
_P1	=	0x0090
_P1_MOD_OC	=	0x0092
_P1_DIR_PU	=	0x0093
_P2	=	0x00a0
_P2_MOD_OC	=	0x0094
_P2_DIR_PU	=	0x0095
_P3	=	0x00b0
_P3_MOD_OC	=	0x0096
_P3_DIR_PU	=	0x0097
_P4	=	0x00c0
_P4_MOD_OC	=	0x00c2
_P4_DIR_PU	=	0x00c3
_P4_LED_KEY	=	0x00c1
_P5_IN	=	0x00aa
_P5_OUT_PU	=	0x00ab
_P5_DIR	=	0x00ac
_P6_IN	=	0x00ad
_P6_OUT_PU	=	0x00ae
_P6_DIR	=	0x00af
_P7	=	0x00f1
_XBUS_AUX	=	0x00a2
_TCON	=	0x0088
_TMOD	=	0x0089
_TL0	=	0x008a
_TL1	=	0x008b
_TH0	=	0x008c
_TH1	=	0x008d
_SCON	=	0x0098
_SBUF	=	0x0099
_T2CON	=	0x00c8
_T2MOD	=	0x00c9
_RCAP2	=	0xcbca
_RCAP2L	=	0x00ca
_RCAP2H	=	0x00cb
_T2COUNT	=	0xcdcc
_TL2	=	0x00cc
_TH2	=	0x00cd
_T2CAP1	=	0xcfce
_T2CAP1L	=	0x00ce
_T2CAP1H	=	0x00cf
_SPI0_STAT	=	0x00f8
_SPI0_DATA	=	0x00f9
_SPI0_CTRL	=	0x00fa
_SPI0_CK_SE	=	0x00fb
_SPI0_SETUP	=	0x00fc
_SCON1	=	0x00bc
_SBUF1	=	0x00bd
_SBAUD1	=	0x00be
_SIF1	=	0x00bf
_SPI1_STAT	=	0x00b4
_SPI1_DATA	=	0x00b5
_SPI1_CTRL	=	0x00b6
_SPI1_CK_SE	=	0x00b7
_ADC_CTRL	=	0x00f3
_ADC_DAT	=	0xf5f4
_ADC_DAT_L	=	0x00f4
_ADC_DAT_H	=	0x00f5
_ADC_CHAN	=	0x00f6
_LED_COMMON	=	0x00a6
_LED_PWM_OE	=	0x00a7
_LED_DMA	=	0xc7c6
_LED_DMA_L	=	0x00c6
_LED_DMA_H	=	0x00c7
_LED_STATUS	=	0x00f7
_I2CX_INT	=	0x00b3
_I2CS_INT_ST	=	0x00bb
;--------------------------------------------------------
; special function bits
;--------------------------------------------------------
	.area RSEG    (ABS,DATA)
	.org 0x0000
_CY	=	0x00d7
_AC	=	0x00d6
_F0	=	0x00d5
_RS1	=	0x00d4
_RS0	=	0x00d3
_OV	=	0x00d2
_F1	=	0x00d1
_P	=	0x00d0
_EA	=	0x00af
_E_DIS	=	0x00ae
_ET2	=	0x00ad
_ES	=	0x00ac
_ET1	=	0x00ab
_EX1	=	0x00aa
_ET0	=	0x00a9
_EX0	=	0x00a8
_PH_FLAG	=	0x00bf
_PL_FLAG	=	0x00be
_PT2	=	0x00bd
_PS	=	0x00bc
_PT1	=	0x00bb
_PX1	=	0x00ba
_PT0	=	0x00b9
_PX0	=	0x00b8
_IE_WDOG	=	0x00ef
_IE_GPIO	=	0x00ee
_IE_PWM_I2C	=	0x00ed
_IE_UART1	=	0x00ec
_IE_ADC	=	0x00eb
_IE_USB	=	0x00e9
_IE_SPI0	=	0x00e8
_P0_7	=	0x0087
_P0_6	=	0x0086
_P0_5	=	0x0085
_P0_4	=	0x0084
_P0_3	=	0x0083
_P0_2	=	0x0082
_P0_1	=	0x0081
_P0_0	=	0x0080
_SDA0	=	0x0081
_SCL0	=	0x0080
_TXD_	=	0x0083
_RXD_	=	0x0082
_AIN13	=	0x0085
_AIN12	=	0x0084
_AIN11	=	0x0083
_AIN10	=	0x0082
_AIN9	=	0x0081
_AIN8	=	0x0080
_P1_7	=	0x0097
_P1_6	=	0x0096
_P1_5	=	0x0095
_P1_4	=	0x0094
_P1_3	=	0x0093
_P1_2	=	0x0092
_P1_1	=	0x0091
_P1_0	=	0x0090
_TXD1_	=	0x0097
_RXD1_	=	0x0096
_SCK	=	0x0097
_MISO	=	0x0096
_MOSI	=	0x0095
_SCS	=	0x0094
_INT0_	=	0x0092
_T2EX	=	0x0091
_CAP2	=	0x0091
_T2	=	0x0090
_CAP1	=	0x0090
_AIN7	=	0x0097
_AIN6	=	0x0096
_AIN5	=	0x0095
_AIN4	=	0x0094
_AIN3	=	0x0093
_AIN2	=	0x0092
_AIN1	=	0x0091
_AIN0	=	0x0090
_P2_7	=	0x00a7
_P2_6	=	0x00a6
_P2_5	=	0x00a5
_P2_4	=	0x00a4
_P2_3	=	0x00a3
_P2_2	=	0x00a2
_P2_1	=	0x00a1
_P2_0	=	0x00a0
_TXD1	=	0x00a7
_RXD1	=	0x00a6
_T2EX_	=	0x00a5
_CAP2_	=	0x00a5
_T2_	=	0x00a4
_CAP1_	=	0x00a4
_P3_7	=	0x00b7
_P3_6	=	0x00b6
_P3_5	=	0x00b5
_P3_4	=	0x00b4
_P3_3	=	0x00b3
_P3_2	=	0x00b2
_P3_1	=	0x00b1
_P3_0	=	0x00b0
_SCK1	=	0x00b7
_MISO1	=	0x00b6
_MOSI1	=	0x00b5
_T1	=	0x00b5
_T0	=	0x00b4
_INT1	=	0x00b3
_INT0	=	0x00b2
_TXD	=	0x00b1
_RXD	=	0x00b0
_P4_6	=	0x00c6
_P4_5	=	0x00c5
_P4_4	=	0x00c4
_P4_3	=	0x00c3
_P4_2	=	0x00c2
_P4_1	=	0x00c1
_P4_0	=	0x00c0
_TF1	=	0x008f
_TR1	=	0x008e
_TF0	=	0x008d
_TR0	=	0x008c
_IE1	=	0x008b
_IT1	=	0x008a
_IE0	=	0x0089
_IT0	=	0x0088
_SM0	=	0x009f
_SM1	=	0x009e
_SM2	=	0x009d
_REN	=	0x009c
_TB8	=	0x009b
_RB8	=	0x009a
_TI	=	0x0099
_RI	=	0x0098
_TF2	=	0x00cf
_CAP1F	=	0x00cf
_EXF2	=	0x00ce
_RCLK	=	0x00cd
_TCLK	=	0x00cc
_EXEN2	=	0x00cb
_TR2	=	0x00ca
_C_T2	=	0x00c9
_CP_RL2	=	0x00c8
_S0_FST_ACT	=	0x00ff
_S0_IF_OV	=	0x00fe
_S0_IF_FIRST	=	0x00fd
_S0_IF_BYTE	=	0x00fc
_S0_FREE	=	0x00fb
_S0_T_FIFO	=	0x00fa
_S0_R_FIFO	=	0x00f8
_ADC_START	=	0x00f7
;--------------------------------------------------------
; overlayable register banks
;--------------------------------------------------------
	.area REG_BANK_0	(REL,OVR,DATA)
	.ds 8
;--------------------------------------------------------
; internal ram data
;--------------------------------------------------------
	.area DSEG    (DATA)
_get_numeric_str_sloc0_1_0:
	.ds 3
_get_numeric_str_sloc1_1_0:
	.ds 1
;--------------------------------------------------------
; overlayable items in internal ram
;--------------------------------------------------------
;--------------------------------------------------------
; indirectly addressable internal ram data
;--------------------------------------------------------
	.area ISEG    (DATA)
;--------------------------------------------------------
; absolute internal ram data
;--------------------------------------------------------
	.area IABS    (ABS,DATA)
	.area IABS    (ABS,DATA)
;--------------------------------------------------------
; bit data
;--------------------------------------------------------
	.area BSEG    (BIT)
_rgb_matrix_check_finished_leds_sloc0_1_0:
	.ds 1
_get_record_keycode_sloc0_1_0:
	.ds 1
_get_event_keycode_sloc0_1_0:
	.ds 1
_pre_process_record_quantum_sloc0_1_0:
	.ds 1
_process_ak820_nkro_sloc0_1_0:
	.ds 1
;--------------------------------------------------------
; paged external ram data
;--------------------------------------------------------
	.area PSEG    (PAG,XDATA)
;--------------------------------------------------------
; uninitialized external ram data
;--------------------------------------------------------
	.area XSEG    (XDATA)
_rgb_matrix_check_finished_leds_led_idx_10000_193:
	.ds 1
_KEYCODE2SYSTEM_key_10000_320:
	.ds 1
_extract_mod_bits_code_10000_602:
	.ds 2
_do_code16_PARM_2:
	.ds 2
_do_code16_code_10000_605:
	.ds 2
_register_code16_code_10000_608:
	.ds 2
_unregister_code16_code_10000_613:
	.ds 2
_tap_code16_delay_PARM_2:
	.ds 2
_tap_code16_delay_code_10000_618:
	.ds 2
_tap_code16_code_10000_625:
	.ds 2
_pre_process_record_kb_PARM_2:
	.ds 3
_pre_process_record_kb_keycode_10000_627:
	.ds 2
_pre_process_record_user_PARM_2:
	.ds 3
_process_record_kb_PARM_2:
	.ds 3
_process_record_kb_keycode_10000_633:
	.ds 2
_process_record_user_PARM_2:
	.ds 3
_post_process_record_kb_PARM_2:
	.ds 3
_post_process_record_kb_keycode_10000_637:
	.ds 2
_post_process_record_user_PARM_2:
	.ds 3
_get_record_keycode_PARM_2:
	.ds 1
_get_record_keycode_record_argument_10000_651:
	.ds 3
_get_event_keycode_PARM_1:
	.ds 6
_get_event_keycode_update_layer_cache_10000_655:
	.ds 1
_pre_process_record_quantum_record_argument_10000_657:
	.ds 3
_post_process_record_quantum_record_10000_661:
	.ds 3
_process_record_quantum_record_10000_663:
	.ds 3
_process_ak820_nkro_PARM_2:
	.ds 3
_process_ak820_nkro_keycode_10000_665:
	.ds 2
_process_record_quantum_helper_PARM_2:
	.ds 3
_process_record_quantum_helper_keycode_10000_670:
	.ds 2
_set_single_persistent_default_layer_default_layer_10000_678:
	.ds 1
_get_numeric_str_PARM_2:
	.ds 2
_get_numeric_str_PARM_3:
	.ds 4
_get_numeric_str_PARM_4:
	.ds 1
_get_numeric_str_buf_10000_690:
	.ds 3
_get_numeric_str_first_10000_691:
	.ds 1
_get_numeric_str_selected_20000_692:
	.ds 1
_get_u8_str_PARM_2:
	.ds 1
_get_u8_str_curr_num_10000_695:
	.ds 1
_get_u8_str_buf_10000_696:
	.ds 4
_get_u8_str_last_num_10000_696:
	.ds 1
_get_u8_str_last_pad_10000_696:
	.ds 1
_get_u16_str_PARM_2:
	.ds 1
_get_u16_str_curr_num_10000_699:
	.ds 2
_get_u16_str_buf_10000_700:
	.ds 6
_get_u16_str_last_num_10000_700:
	.ds 2
_get_u16_str_last_pad_10000_700:
	.ds 1
;--------------------------------------------------------
; absolute external ram data
;--------------------------------------------------------
	.area XABS    (ABS,XDATA)
;--------------------------------------------------------
; initialized external ram data
;--------------------------------------------------------
	.area XISEG   (XDATA)
	.area HOME    (CODE)
	.area GSINIT0 (CODE)
	.area GSINIT1 (CODE)
	.area GSINIT2 (CODE)
	.area GSINIT3 (CODE)
	.area GSINIT4 (CODE)
	.area GSINIT5 (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area CSEG    (CODE)
;--------------------------------------------------------
; global & static initialisations
;--------------------------------------------------------
	.area HOME    (CODE)
	.area GSINIT  (CODE)
	.area GSFINAL (CODE)
	.area GSINIT  (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'get_u8_str'
;------------------------------------------------------------
;curr_pad      Allocated with name '_get_u8_str_PARM_2'
;curr_num      Allocated with name '_get_u8_str_curr_num_10000_695'
;buf           Allocated with name '_get_u8_str_buf_10000_696'
;last_num      Allocated with name '_get_u8_str_last_num_10000_696'
;last_pad      Allocated with name '_get_u8_str_last_pad_10000_696'
;------------------------------------------------------------
;	quantum/quantum.c:750: static uint8_t last_num = 0xFF;
	mov	dptr,#_get_u8_str_last_num_10000_696
	mov	a,#0xff
	movx	@dptr,a
;------------------------------------------------------------
;Allocation info for local variables in function 'get_u16_str'
;------------------------------------------------------------
;curr_pad      Allocated with name '_get_u16_str_PARM_2'
;curr_num      Allocated with name '_get_u16_str_curr_num_10000_699'
;buf           Allocated with name '_get_u16_str_buf_10000_700'
;last_num      Allocated with name '_get_u16_str_last_num_10000_700'
;last_pad      Allocated with name '_get_u16_str_last_pad_10000_700'
;------------------------------------------------------------
;	quantum/quantum.c:770: static uint16_t last_num = 0xFF;
	mov	dptr,#_get_u16_str_last_num_10000_700
	mov	a,#0xff
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
;--------------------------------------------------------
; Home
;--------------------------------------------------------
	.area HOME    (CODE)
	.area HOME    (CODE)
;--------------------------------------------------------
; code
;--------------------------------------------------------
	.area CSEG    (CODE)
;------------------------------------------------------------
;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
;------------------------------------------------------------
;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
;------------------------------------------------------------
;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
;	-----------------------------------------
;	 function rgb_matrix_check_finished_leds
;	-----------------------------------------
_rgb_matrix_check_finished_leds:
	ar7 = 0x07
	ar6 = 0x06
	ar5 = 0x05
	ar4 = 0x04
	ar3 = 0x03
	ar2 = 0x02
	ar1 = 0x01
	ar0 = 0x00
	mov	a,dpl
	mov	dptr,#_rgb_matrix_check_finished_leds_led_idx_10000_193
	movx	@dptr,a
;	quantum/rgb_matrix/rgb_matrix.h:268: return led_idx < RGB_MATRIX_LED_COUNT;
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0x52,00103$
00103$:
	mov  _rgb_matrix_check_finished_leds_sloc0_1_0,c
	clr	a
	rlc	a
	mov	dpl, a
;	quantum/rgb_matrix/rgb_matrix.h:270: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'KEYCODE2SYSTEM'
;------------------------------------------------------------
;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_320'
;------------------------------------------------------------
;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
;	-----------------------------------------
;	 function KEYCODE2SYSTEM
;	-----------------------------------------
_KEYCODE2SYSTEM:
	mov	a,dpl
	mov	dptr,#_KEYCODE2SYSTEM_key_10000_320
	movx	@dptr,a
;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
	movx	a,@dptr
	mov	r7,a
	cjne	r7,#0xa5,00113$
00113$:
	jc	00101$
	mov	a,r7
	add	a,#0xff - 0xa7
	jnc	00102$
;	free result
00101$:
	mov	dptr,#0x0000
	ret
00102$:
;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
	mov	a,#0xdc
	add	a, r7
	mov	r7,a
	mov	r6,#0x00
	mov	dpl, r7
	mov	dph, r6
;	tmk_core/protocol/report.h:278: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'extract_mod_bits'
;------------------------------------------------------------
;code          Allocated with name '_extract_mod_bits_code_10000_602'
;mods          Allocated with name '_extract_mod_bits_mods_10000_603'
;------------------------------------------------------------
;	quantum/quantum.c:98: uint8_t extract_mod_bits(uint16_t code) {
;	-----------------------------------------
;	 function extract_mod_bits
;	-----------------------------------------
_extract_mod_bits:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_extract_mod_bits_code_10000_602
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:107: uint8_t mods = (uint8_t)(code >> 8);
	mov	dptr,#_extract_mod_bits_code_10000_602
	movx	a,@dptr
	inc	dptr
	movx	a,@dptr
;	quantum/quantum.c:108: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
	mov	r7,a
	jz	00101$
	mov	a,r7
	add	a,#0xff - 0x1f
	jnc	00102$
;	free result
00101$:
	mov	dpl, #0x00
	ret
00102$:
;	quantum/quantum.c:109: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
	mov	a,r7
	jnb	acc.4,00106$
	mov	a,r7
	swap	a
	anl	a,#0xf0
	mov	r6,a
	sjmp	00107$
00106$:
	mov	ar6,r7
00107$:
	mov	dpl, r6
;	quantum/quantum.c:137: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'do_code16'
;------------------------------------------------------------
;f             Allocated with name '_do_code16_PARM_2'
;code          Allocated with name '_do_code16_code_10000_605'
;------------------------------------------------------------
;	quantum/quantum.c:139: void do_code16(uint16_t code, void (*f)(uint8_t)) {
;	-----------------------------------------
;	 function do_code16
;	-----------------------------------------
_do_code16:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_do_code16_code_10000_605
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:140: f(extract_mod_bits(code));
	mov	dptr,#_do_code16_code_10000_605
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	lcall	_extract_mod_bits
	mov	r7, dpl
	mov	dptr,#_do_code16_PARM_2
	movx	a,@dptr
	push	acc
	inc	dptr
	movx	a,@dptr
	push	acc
	mov	dpl, r7
	ret
;	quantum/quantum.c:141: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'register_code16'
;------------------------------------------------------------
;code          Allocated with name '_register_code16_code_10000_608'
;mods          Allocated with name '_register_code16_mods_10000_609'
;------------------------------------------------------------
;	quantum/quantum.c:143: __attribute__((weak)) void register_code16(uint16_t code) {
;	-----------------------------------------
;	 function register_code16
;	-----------------------------------------
_register_code16:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_register_code16_code_10000_608
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:145: uint8_t mods = extract_mod_bits(code);
	mov	dptr,#_register_code16_code_10000_608
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	push	ar7
	push	ar6
	lcall	_extract_mod_bits
	mov	r5, dpl
	pop	ar6
	pop	ar7
;	quantum/quantum.c:146: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
	clr	c
	mov	a,r6
	subb	a,#0xe0
	mov	a,r7
	subb	a,#0x00
	jc	00105$
	mov	a,#0xe7
	subb	a,r6
	clr	a
	subb	a,r7
	jnc	00101$
;	free result
00105$:
	mov	dptr,#_register_code16_code_10000_608
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jnz	00102$
00101$:
;	quantum/quantum.c:147: register_mods(mods);
	mov	dpl, r5
	lcall	_register_mods
	sjmp	00103$
00102$:
;	quantum/quantum.c:149: register_weak_mods(mods);
	mov	dpl, r5
	lcall	_register_weak_mods
00103$:
;	quantum/quantum.c:151: register_code(code);
	mov	dptr,#_register_code16_code_10000_608
	movx	a,@dptr
	mov	dpl,a
;	quantum/quantum.c:161: }
	ljmp	_register_code
;------------------------------------------------------------
;Allocation info for local variables in function 'unregister_code16'
;------------------------------------------------------------
;code          Allocated with name '_unregister_code16_code_10000_613'
;mods          Allocated with name '_unregister_code16_mods_10000_614'
;------------------------------------------------------------
;	quantum/quantum.c:163: __attribute__((weak)) void unregister_code16(uint16_t code) {
;	-----------------------------------------
;	 function unregister_code16
;	-----------------------------------------
_unregister_code16:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_unregister_code16_code_10000_613
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:165: uint8_t mods = extract_mod_bits(code);
	mov	dptr,#_unregister_code16_code_10000_613
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	push	ar7
	push	ar6
	lcall	_extract_mod_bits
	mov	r5, dpl
	pop	ar6
;	quantum/quantum.c:166: unregister_code(code);
	mov	ar4,r6
	mov	dpl, r4
	push	ar6
	push	ar5
	lcall	_unregister_code
	pop	ar5
	pop	ar6
	pop	ar7
;	quantum/quantum.c:167: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
	clr	c
	mov	a,r6
	subb	a,#0xe0
	mov	a,r7
	subb	a,#0x00
	jc	00105$
	mov	a,#0xe7
	subb	a,r6
	clr	a
	subb	a,r7
	jnc	00101$
;	free result
00105$:
	mov	dptr,#_unregister_code16_code_10000_613
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jnz	00102$
00101$:
;	quantum/quantum.c:168: unregister_mods(mods);
	mov	dpl, r5
	ljmp	_unregister_mods
00102$:
;	quantum/quantum.c:170: unregister_weak_mods(mods);
	mov	dpl, r5
;	quantum/quantum.c:181: }
	ljmp	_unregister_weak_mods
;------------------------------------------------------------
;Allocation info for local variables in function 'tap_code16_delay'
;------------------------------------------------------------
;delay         Allocated with name '_tap_code16_delay_PARM_2'
;code          Allocated with name '_tap_code16_delay_code_10000_618'
;i             Allocated with name '_tap_code16_delay_i_20000_620'
;i             Allocated with name '_tap_code16_delay_i_50000_623'
;------------------------------------------------------------
;	quantum/quantum.c:188: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
;	-----------------------------------------
;	 function tap_code16_delay
;	-----------------------------------------
_tap_code16_delay:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_tap_code16_delay_code_10000_618
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:189: register_code16(code);
	mov	dptr,#_tap_code16_delay_code_10000_618
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r6
	mov	dph, r7
	push	ar7
	push	ar6
	lcall	_register_code16
	pop	ar6
	pop	ar7
;	quantum/quantum.c:190: for (uint16_t i = delay; i > 0; i--) {
	mov	dptr,#_tap_code16_delay_PARM_2
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
00110$:
	mov	a,r4
	orl	a,r5
	jz	00105$
;	quantum/quantum.c:191: wait_ms(1);
	mov	dptr,#0x0001
	lcall	_mDelaymS
;	quantum/quantum.c:190: for (uint16_t i = delay; i > 0; i--) {
	dec	r4
	cjne	r4,#0xff,00141$
	dec	r5
00141$:
	sjmp	00110$
00105$:
;	quantum/quantum.c:193: unregister_code16(code);
	mov	dpl, r6
	mov	dph, r7
;	quantum/quantum.c:194: }
	ljmp	_unregister_code16
;------------------------------------------------------------
;Allocation info for local variables in function 'tap_code16'
;------------------------------------------------------------
;code          Allocated with name '_tap_code16_code_10000_625'
;------------------------------------------------------------
;	quantum/quantum.c:200: __attribute__((weak)) void tap_code16(uint16_t code) {
;	-----------------------------------------
;	 function tap_code16
;	-----------------------------------------
_tap_code16:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_tap_code16_code_10000_625
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:201: tap_code16_delay(code, code == KC_CAPS_LOCK ? QS_tap_hold_caps_delay : QS_tap_code_delay);
	mov	dptr,#_tap_code16_code_10000_625
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	ar4,r6
	mov	ar5,r7
	cjne	r4,#0x39,00103$
	cjne	r5,#0x00,00103$
	mov	r5,#0x50
	sjmp	00104$
00103$:
	mov	r5,#0x00
00104$:
	mov	dptr,#_tap_code16_delay_PARM_2
	mov	a,r5
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
;	quantum/quantum.c:202: }
	ljmp	_tap_code16_delay
;------------------------------------------------------------
;Allocation info for local variables in function 'pre_process_record_kb'
;------------------------------------------------------------
;record        Allocated with name '_pre_process_record_kb_PARM_2'
;keycode       Allocated with name '_pre_process_record_kb_keycode_10000_627'
;------------------------------------------------------------
;	quantum/quantum.c:204: __attribute__((weak)) bool pre_process_record_kb(uint16_t keycode, keyrecord_t *record) {
;	-----------------------------------------
;	 function pre_process_record_kb
;	-----------------------------------------
_pre_process_record_kb:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_pre_process_record_kb_keycode_10000_627
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:205: return pre_process_record_user(keycode, record);
	mov	dptr,#_pre_process_record_kb_keycode_10000_627
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_pre_process_record_kb_PARM_2
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_pre_process_record_user_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
;	quantum/quantum.c:206: }
	ljmp	_pre_process_record_user
;------------------------------------------------------------
;Allocation info for local variables in function 'pre_process_record_user'
;------------------------------------------------------------
;record        Allocated with name '_pre_process_record_user_PARM_2'
;keycode       Allocated with name '_pre_process_record_user_keycode_10000_629'
;------------------------------------------------------------
;	quantum/quantum.c:208: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
;	-----------------------------------------
;	 function pre_process_record_user
;	-----------------------------------------
_pre_process_record_user:
;	quantum/quantum.c:209: return true;
	mov	dpl, #0x01
;	quantum/quantum.c:210: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'process_action_kb'
;------------------------------------------------------------
;record        Allocated with name '_process_action_kb_record_10000_631'
;------------------------------------------------------------
;	quantum/quantum.c:212: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
;	-----------------------------------------
;	 function process_action_kb
;	-----------------------------------------
_process_action_kb:
;	quantum/quantum.c:213: return true;
	mov	dpl, #0x01
;	quantum/quantum.c:214: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'process_record_kb'
;------------------------------------------------------------
;record        Allocated with name '_process_record_kb_PARM_2'
;keycode       Allocated with name '_process_record_kb_keycode_10000_633'
;------------------------------------------------------------
;	quantum/quantum.c:216: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
;	-----------------------------------------
;	 function process_record_kb
;	-----------------------------------------
_process_record_kb:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_process_record_kb_keycode_10000_633
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:217: return process_record_user(keycode, record);
	mov	dptr,#_process_record_kb_keycode_10000_633
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_process_record_kb_PARM_2
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_process_record_user_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
;	quantum/quantum.c:218: }
	ljmp	_process_record_user
;------------------------------------------------------------
;Allocation info for local variables in function 'process_record_user'
;------------------------------------------------------------
;record        Allocated with name '_process_record_user_PARM_2'
;keycode       Allocated with name '_process_record_user_keycode_10000_635'
;------------------------------------------------------------
;	quantum/quantum.c:220: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
;	-----------------------------------------
;	 function process_record_user
;	-----------------------------------------
_process_record_user:
;	quantum/quantum.c:221: return true;
	mov	dpl, #0x01
;	quantum/quantum.c:222: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'post_process_record_kb'
;------------------------------------------------------------
;record        Allocated with name '_post_process_record_kb_PARM_2'
;keycode       Allocated with name '_post_process_record_kb_keycode_10000_637'
;------------------------------------------------------------
;	quantum/quantum.c:224: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
;	-----------------------------------------
;	 function post_process_record_kb
;	-----------------------------------------
_post_process_record_kb:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_post_process_record_kb_keycode_10000_637
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:225: post_process_record_user(keycode, record);
	mov	dptr,#_post_process_record_kb_keycode_10000_637
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_post_process_record_kb_PARM_2
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_post_process_record_user_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
;	quantum/quantum.c:226: }
	ljmp	_post_process_record_user
;------------------------------------------------------------
;Allocation info for local variables in function 'post_process_record_user'
;------------------------------------------------------------
;record        Allocated with name '_post_process_record_user_PARM_2'
;keycode       Allocated with name '_post_process_record_user_keycode_10000_639'
;------------------------------------------------------------
;	quantum/quantum.c:228: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
;	-----------------------------------------
;	 function post_process_record_user
;	-----------------------------------------
_post_process_record_user:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'shutdown_quantum'
;------------------------------------------------------------
;i             Allocated with name '_shutdown_quantum_i_30000_645'
;------------------------------------------------------------
;	quantum/quantum.c:230: void shutdown_quantum(void) {
;	-----------------------------------------
;	 function shutdown_quantum
;	-----------------------------------------
_shutdown_quantum:
;	quantum/quantum.c:231: clear_keyboard();
	lcall	_clear_keyboard
;	quantum/quantum.c:246: shutdown_user();
	lcall	_shutdown_user
;	quantum/quantum.c:247: wait_ms(250);
	mov	r7,#0xfa
00106$:
	mov	a,r7
	jz	00108$
	mov	dptr,#0x0001
	lcall	_mDelaymS
	dec	r7
	sjmp	00106$
00108$:
;	quantum/quantum.c:252: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'reset_keyboard'
;------------------------------------------------------------
;	quantum/quantum.c:254: void reset_keyboard(void) {
;	-----------------------------------------
;	 function reset_keyboard
;	-----------------------------------------
_reset_keyboard:
;	quantum/quantum.c:255: shutdown_quantum();
	lcall	_shutdown_quantum
;	quantum/quantum.c:256: bootloader_jump();
;	quantum/quantum.c:257: }
	ljmp	_bootloader_jump
;------------------------------------------------------------
;Allocation info for local variables in function 'soft_reset_keyboard'
;------------------------------------------------------------
;	quantum/quantum.c:259: void soft_reset_keyboard(void) {
;	-----------------------------------------
;	 function soft_reset_keyboard
;	-----------------------------------------
_soft_reset_keyboard:
;	quantum/quantum.c:260: shutdown_quantum();
	lcall	_shutdown_quantum
;	quantum/quantum.c:261: mcu_reset();
;	quantum/quantum.c:262: }
	ljmp	_mcu_reset
;------------------------------------------------------------
;Allocation info for local variables in function 'get_record_keycode'
;------------------------------------------------------------
;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
;record_argument Allocated with name '_get_record_keycode_record_argument_10000_651'
;record        Allocated with name '_get_record_keycode_record_10000_652'
;------------------------------------------------------------
;	quantum/quantum.c:265: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
;	-----------------------------------------
;	 function get_record_keycode
;	-----------------------------------------
_get_record_keycode:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_get_record_keycode_record_argument_10000_651
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:267: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
	mov	dptr,#_get_record_keycode_record_argument_10000_651
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	quantum/quantum.c:272: if (record->keycode) {
	mov	a,#0x07
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	orl	a,r4
	jz	00102$
;	quantum/quantum.c:273: return record->keycode;
	mov	dpl, r4
	mov	dph, r5
	ret
00102$:
;	quantum/quantum.c:277: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	mov	r5,#0x00
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r2,#0x00
	orl	ar5,a
	mov	a,r2
	orl	ar4,a
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jz	00105$
	mov	dptr,#_get_record_keycode_PARM_2
	movx	a,@dptr
	jnz	00106$
00105$:
;	assignBit
	clr	_get_record_keycode_sloc0_1_0
	sjmp	00107$
00106$:
;	assignBit
	setb	_get_record_keycode_sloc0_1_0
00107$:
	mov	dptr,#_ak820_resolve_key_PARM_2
	mov	c,_get_record_keycode_sloc0_1_0
	clr	a
	rlc	a
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r4
;	quantum/quantum.c:281: }
	ljmp	_ak820_resolve_key
;------------------------------------------------------------
;Allocation info for local variables in function 'get_event_keycode'
;------------------------------------------------------------
;event         Allocated with name '_get_event_keycode_PARM_1'
;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_655'
;------------------------------------------------------------
;	quantum/quantum.c:289: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
;	-----------------------------------------
;	 function get_event_keycode
;	-----------------------------------------
_get_event_keycode:
	mov	a,dpl
	mov	dptr,#_get_event_keycode_update_layer_cache_10000_655
	movx	@dptr,a
;	quantum/quantum.c:291: return ak820_resolve_key(AK820_KEYPOS_VALUE(event.key), event.pressed && update_layer_cache);
	mov	dptr,#(_get_event_keycode_PARM_1 + 0x0001)
	movx	a,@dptr
	mov	r6,a
	mov	r7,#0x00
	mov	dptr,#_get_event_keycode_PARM_1
	movx	a,@dptr
	mov	r4,#0x00
	orl	ar7,a
	mov	a,r4
	orl	ar6,a
	mov	dptr,#(_get_event_keycode_PARM_1 + 0x0005)
	movx	a,@dptr
	jz	00103$
	mov	dptr,#_get_event_keycode_update_layer_cache_10000_655
	movx	a,@dptr
	jnz	00104$
00103$:
;	assignBit
	clr	_get_event_keycode_sloc0_1_0
	sjmp	00105$
00104$:
;	assignBit
	setb	_get_event_keycode_sloc0_1_0
00105$:
	mov	dptr,#_ak820_resolve_key_PARM_2
	mov	c,_get_event_keycode_sloc0_1_0
	clr	a
	rlc	a
	movx	@dptr,a
	mov	dpl, r7
	mov	dph, r6
;	quantum/quantum.c:317: }
	ljmp	_ak820_resolve_key
;------------------------------------------------------------
;Allocation info for local variables in function 'pre_process_record_quantum'
;------------------------------------------------------------
;record_argument Allocated with name '_pre_process_record_quantum_record_argument_10000_657'
;record        Allocated with name '_pre_process_record_quantum_record_10000_658'
;keycode       Allocated with name '_pre_process_record_quantum_keycode_10000_658'
;------------------------------------------------------------
;	quantum/quantum.c:320: bool pre_process_record_quantum(keyrecord_t *record_argument) {
;	-----------------------------------------
;	 function pre_process_record_quantum
;	-----------------------------------------
_pre_process_record_quantum:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_pre_process_record_quantum_record_argument_10000_657
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:322: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
	mov	dptr,#_pre_process_record_quantum_record_argument_10000_657
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	quantum/quantum.c:326: uint16_t keycode = get_record_keycode(record, true);
	mov	ar3,r6
	mov	ar4,r7
	mov	r5,#0x00
	mov	dptr,#_get_record_keycode_PARM_2
	mov	a,#0x01
	movx	@dptr,a
	mov	dpl, r3
	mov	dph, r4
	mov	b, r5
	push	ar7
	push	ar6
	lcall	_get_record_keycode
	mov	r4, dpl
	mov	r5, dph
	pop	ar6
	pop	ar7
;	quantum/quantum.c:328: record->keycode = keycode;
	mov	a,#0x07
	add	a, r6
	mov	dpl,a
	clr	a
	addc	a, r7
	mov	dph,a
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:333: if (keycode == QK_LEAD && record->event.pressed && record->event.key.row < MATRIX_ROWS && record->event.key.col < MATRIX_COLS)
	mov	ar2,r4
	mov	ar3,r5
	cjne	r2,#0x58,00102$
	cjne	r3,#0x7c,00102$
	mov	a,#0x05
	add	a, r6
	mov	r2,a
	clr	a
	addc	a, r7
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	jz	00102$
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x10,00161$
00161$:
	jnc	00102$
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	mov	r3,a
	cjne	r3,#0x08,00163$
00163$:
	jnc	00102$
;	quantum/quantum.c:334: ak820_combo_tick(record->event.time + 40);
	mov	dpl,r6
	mov	dph,r7
	inc	dptr
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	mov	a,#0x28
	add	a, r2
	mov	r2,a
	clr	a
	addc	a, r3
	mov	r3,a
	mov	dpl, r2
	mov	dph, r3
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_ak820_combo_tick
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
00102$:
;	quantum/quantum.c:336: if (!ak820_leader_process((keyrecord_t AK820_STATE_MEM *)record)) return false;
	mov	dpl, r6
	mov	dph, r7
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_ak820_leader_process
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00107$
	mov	dpl,a
	ret
00107$:
;	quantum/quantum.c:338: return pre_process_record_kb(keycode, record) &&
	mov	dptr,#_pre_process_record_kb_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	lcall	_pre_process_record_kb
	mov	a, dpl
	pop	ar6
	pop	ar7
	jz	00110$
;	quantum/quantum.c:341: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
	mov	dpl, r6
	mov	dph, r7
	lcall	_ak820_combo_process
	mov	a, dpl
	jnz	00111$
;	quantum/quantum.c:346: true;
00110$:
;	assignBit
	clr	_pre_process_record_quantum_sloc0_1_0
	sjmp	00112$
00111$:
;	assignBit
	setb	_pre_process_record_quantum_sloc0_1_0
00112$:
	mov	c,_pre_process_record_quantum_sloc0_1_0
	clr	a
	rlc	a
	mov	dpl, a
;	quantum/quantum.c:347: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'post_process_record_quantum'
;------------------------------------------------------------
;record        Allocated with name '_post_process_record_quantum_record_10000_661'
;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_662'
;------------------------------------------------------------
;	quantum/quantum.c:350: void post_process_record_quantum(keyrecord_t *record) {
;	-----------------------------------------
;	 function post_process_record_quantum
;	-----------------------------------------
_post_process_record_quantum:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_post_process_record_quantum_record_10000_661
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:351: uint16_t keycode = get_record_keycode(record, false);
	mov	dptr,#_post_process_record_quantum_record_10000_661
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_get_record_keycode_PARM_2
	clr	a
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
	lcall	_get_record_keycode
	mov	r6, dpl
	mov	r7, dph
;	quantum/quantum.c:352: post_process_record_kb(keycode, record);
	mov	dptr,#_post_process_record_quantum_record_10000_661
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_post_process_record_kb_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
;	quantum/quantum.c:353: }
	ljmp	_post_process_record_kb
;------------------------------------------------------------
;Allocation info for local variables in function 'process_record_quantum'
;------------------------------------------------------------
;record        Allocated with name '_process_record_quantum_record_10000_663'
;keycode       Allocated with name '_process_record_quantum_keycode_10000_664'
;------------------------------------------------------------
;	quantum/quantum.c:355: bool process_record_quantum(keyrecord_t *record) {
;	-----------------------------------------
;	 function process_record_quantum
;	-----------------------------------------
_process_record_quantum:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_process_record_quantum_record_10000_663
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:357: uint16_t keycode = get_record_keycode(record, false);
	mov	dptr,#_process_record_quantum_record_10000_663
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_get_record_keycode_PARM_2
	clr	a
	movx	@dptr,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
	lcall	_get_record_keycode
	mov	r6, dpl
	mov	r7, dph
;	quantum/quantum.c:361: return process_record_quantum_helper(keycode, record);
	mov	dptr,#_process_record_quantum_record_10000_663
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_process_record_quantum_helper_PARM_2
	mov	a,r3
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	dpl, r6
	mov	dph, r7
;	quantum/quantum.c:362: }
	ljmp	_process_record_quantum_helper
;------------------------------------------------------------
;Allocation info for local variables in function 'process_ak820_nkro'
;------------------------------------------------------------
;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_665'
;record        Allocated with name '_process_ak820_nkro_record_10000_666'
;------------------------------------------------------------
;	quantum/quantum.c:369: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
;	-----------------------------------------
;	 function process_ak820_nkro
;	-----------------------------------------
_process_ak820_nkro:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_process_ak820_nkro_keycode_10000_665
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:371: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
	mov	dptr,#_process_ak820_nkro_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	quantum/quantum.c:375: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
	mov	dptr,#_process_ak820_nkro_keycode_10000_665
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	clr	c
	mov	a,r4
	subb	a,#0x11
	mov	a,r5
	subb	a,#0x70
	jc	00101$
	mov	a,#0x13
	subb	a,r4
	mov	a,#0x70
	subb	a,r5
	jnc	00102$
;	free result
00101$:
	mov	dpl, #0x01
	ret
00102$:
;	quantum/quantum.c:376: if (record->event.pressed) {
	mov	a,#0x05
	add	a, r6
	mov	r6,a
	clr	a
	addc	a, r7
	mov	r7,a
	mov	dpl,r6
	mov	dph,r7
	movx	a,@dptr
	jz	00105$
;	quantum/quantum.c:377: clear_keyboard();
	push	ar5
	push	ar4
	lcall	_clear_keyboard
	pop	ar4
	pop	ar5
;	quantum/quantum.c:378: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
	cjne	r4,#0x13,00108$
	cjne	r5,#0x70,00108$
	mov	dptr,#_keymap_config
	movx	a,@dptr
	rl	a
	anl	a,#0x01
	cjne	a,#0x01,00136$
00136$:
	mov  _process_ak820_nkro_sloc0_1_0,c
	clr	a
	rlc	a
	mov	r7,a
	sjmp	00109$
00108$:
	clr	a
	cjne	r4,#0x11,00137$
	cjne	r5,#0x70,00137$
	inc	a
00137$:
	mov	r7,a
00109$:
;	assignBit
	mov	a,r7
	add	a,#0xff
	clr	a
	rlc	a
	mov	dptr,#_keymap_config
	rrc	a
	movx	a,@dptr
	mov	acc.7,c
	movx	@dptr,a
00105$:
;	quantum/quantum.c:380: return false;
	mov	dpl, #0x00
;	quantum/quantum.c:381: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'process_record_quantum_helper'
;------------------------------------------------------------
;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_670'
;record        Allocated with name '_process_record_quantum_helper_record_10000_671'
;------------------------------------------------------------
;	quantum/quantum.c:384: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
;	-----------------------------------------
;	 function process_record_quantum_helper
;	-----------------------------------------
_process_record_quantum_helper:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_process_record_quantum_helper_keycode_10000_670
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:386: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
	mov	dptr,#_process_record_quantum_helper_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
;	quantum/quantum.c:429: process_ak820_nkro(keycode, record) &&
	mov	dptr,#_process_record_quantum_helper_keycode_10000_670
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#_process_ak820_nkro_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_process_ak820_nkro
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00204$
	ljmp	00101$
00204$:
;	quantum/quantum.c:440: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
	mov	dptr,#_process_last_key_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_process_last_key
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00205$
	ljmp	00101$
00205$:
	mov	dptr,#_process_repeat_key_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_process_repeat_key
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00206$
	ljmp	00101$
00206$:
;	quantum/quantum.c:449: process_record_via(keycode, record) &&
	mov	dptr,#_process_record_via_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_process_record_via
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00207$
	ljmp	00101$
00207$:
;	quantum/quantum.c:459: process_record_kb(keycode, record) &&
	mov	dptr,#_process_record_kb_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_process_record_kb
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00208$
	ljmp	00101$
00208$:
;	quantum/quantum.c:482: process_caps_word(keycode, record) &&
	mov	dptr,#_process_caps_word_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_process_caps_word
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jz	00101$
;	quantum/quantum.c:509: process_grave_esc(keycode, record) &&
	mov	dptr,#_process_grave_esc_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_process_grave_esc
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jz	00101$
;	quantum/quantum.c:512: process_rgb(keycode, record) &&
	mov	dptr,#_process_rgb_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_process_rgb
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jz	00101$
;	quantum/quantum.c:524: process_tri_layer(keycode, record) &&
	mov	dptr,#_process_tri_layer_PARM_2
	mov	a,r6
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r4
	mov	dph, r5
	push	ar7
	push	ar6
	push	ar5
	push	ar4
	lcall	_process_tri_layer
	mov	a, dpl
	pop	ar4
	pop	ar5
	pop	ar6
	pop	ar7
	jnz	00102$
;	quantum/quantum.c:526: true)) {
00101$:
;	quantum/quantum.c:527: return false;
	mov	dpl, #0x00
	ret
00102$:
;	quantum/quantum.c:530: if (record->event.pressed) {
	mov	a,#0x05
	add	a, r6
	mov	r2,a
	clr	a
	addc	a, r7
	mov	r3,a
	mov	dpl,r2
	mov	dph,r3
	movx	a,@dptr
	jz	00117$
;	quantum/quantum.c:531: switch (keycode) {
	cjne	r4,#0x00,00214$
	cjne	r5,#0x7c,00214$
	sjmp	00112$
00214$:
	cjne	r4,#0x01,00215$
	cjne	r5,#0x7c,00215$
	sjmp	00113$
00215$:
;	quantum/quantum.c:533: case QK_BOOTLOADER:
	cjne	r4,#0x03,00117$
	cjne	r5,#0x7c,00117$
	sjmp	00114$
00112$:
;	quantum/quantum.c:534: reset_keyboard();
	lcall	_reset_keyboard
;	quantum/quantum.c:535: return false;
	mov	dpl, #0x00
;	quantum/quantum.c:536: case QK_REBOOT:
	ret
00113$:
;	quantum/quantum.c:537: soft_reset_keyboard();
	lcall	_soft_reset_keyboard
;	quantum/quantum.c:538: return false;
	mov	dpl, #0x00
;	quantum/quantum.c:550: case QK_CLEAR_EEPROM:
	ret
00114$:
;	quantum/quantum.c:557: eeconfig_disable();
	lcall	_eeconfig_disable
;	quantum/quantum.c:558: soft_reset_keyboard();
	lcall	_soft_reset_keyboard
;	quantum/quantum.c:560: return false;
	mov	dpl, #0x00
;	quantum/quantum.c:615: }
	ret
00117$:
;	quantum/quantum.c:618: return process_action_kb(record);
	mov	r5,#0x00
	mov	dpl, r6
	mov	dph, r7
	mov	b, r5
;	quantum/quantum.c:619: }
	ljmp	_process_action_kb
;------------------------------------------------------------
;Allocation info for local variables in function 'set_single_persistent_default_layer'
;------------------------------------------------------------
;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_678'
;------------------------------------------------------------
;	quantum/quantum.c:621: void set_single_persistent_default_layer(uint8_t default_layer) {
;	-----------------------------------------
;	 function set_single_persistent_default_layer
;	-----------------------------------------
_set_single_persistent_default_layer:
	mov	a,dpl
	mov	dptr,#_set_single_persistent_default_layer_default_layer_10000_678
	movx	@dptr,a
;	quantum/quantum.c:625: eeconfig_update_default_layer((layer_state_t)1 << default_layer);
	movx	a,@dptr
	mov	b, a
	inc	b
	mov	a,#0x01
	sjmp	00104$
00103$:
	add	a,acc
00104$:
	djnz	b,00103$
	mov	r7,a
	mov	dpl,a
	push	ar7
	lcall	_eeconfig_update_default_layer
	pop	ar7
;	quantum/quantum.c:626: default_layer_set((layer_state_t)1 << default_layer);
	mov	dpl, r7
;	quantum/quantum.c:627: }
	ljmp	_default_layer_set
;------------------------------------------------------------
;Allocation info for local variables in function 'startup_user'
;------------------------------------------------------------
;	quantum/quantum.c:633: __attribute__((weak)) void startup_user(void) {}
;	-----------------------------------------
;	 function startup_user
;	-----------------------------------------
_startup_user:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'shutdown_user'
;------------------------------------------------------------
;	quantum/quantum.c:635: __attribute__((weak)) void shutdown_user(void) {}
;	-----------------------------------------
;	 function shutdown_user
;	-----------------------------------------
_shutdown_user:
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'suspend_power_down_quantum'
;------------------------------------------------------------
;	quantum/quantum.c:637: void suspend_power_down_quantum(void) {
;	-----------------------------------------
;	 function suspend_power_down_quantum
;	-----------------------------------------
_suspend_power_down_quantum:
;	quantum/quantum.c:638: suspend_power_down_kb();
	lcall	_suspend_power_down_kb
;	quantum/quantum.c:649: rgb_matrix_task();
	lcall	_rgb_matrix_task
;	quantum/quantum.c:653: led_suspend();
	lcall	_led_suspend
;	quantum/quantum.c:669: rgb_matrix_set_suspend_state(true);
	mov	dpl, #0x01
;	quantum/quantum.c:683: }
	ljmp	_rgb_matrix_set_suspend_state
;------------------------------------------------------------
;Allocation info for local variables in function 'suspend_wakeup_init_quantum'
;------------------------------------------------------------
;	quantum/quantum.c:685: __attribute__((weak)) void suspend_wakeup_init_quantum(void) {
;	-----------------------------------------
;	 function suspend_wakeup_init_quantum
;	-----------------------------------------
_suspend_wakeup_init_quantum:
;	quantum/quantum.c:692: led_wakeup();
	lcall	_led_wakeup
;	quantum/quantum.c:703: rgb_matrix_set_suspend_state(false);
	mov	dpl, #0x00
	lcall	_rgb_matrix_set_suspend_state
;	quantum/quantum.c:705: suspend_wakeup_init_kb();
;	quantum/quantum.c:706: }
	ljmp	_suspend_wakeup_init_kb
;------------------------------------------------------------
;Allocation info for local variables in function 'get_numeric_str'
;------------------------------------------------------------
;sloc0         Allocated with name '_get_numeric_str_sloc0_1_0'
;sloc1         Allocated with name '_get_numeric_str_sloc1_1_0'
;buf_len       Allocated with name '_get_numeric_str_PARM_2'
;curr_num      Allocated with name '_get_numeric_str_PARM_3'
;curr_pad      Allocated with name '_get_numeric_str_PARM_4'
;buf           Allocated with name '_get_numeric_str_buf_10000_690'
;remaining     Allocated with name '_get_numeric_str_remaining_10000_691'
;first         Allocated with name '_get_numeric_str_first_10000_691'
;selected      Allocated with name '_get_numeric_str_selected_20000_692'
;------------------------------------------------------------
;	quantum/quantum.c:714: const char *get_numeric_str(char *buf, size_t buf_len, uint32_t curr_num, char curr_pad) {
;	-----------------------------------------
;	 function get_numeric_str
;	-----------------------------------------
_get_numeric_str:
	mov	r7,b
	mov	r6,dph
	mov	a,dpl
	mov	dptr,#_get_numeric_str_buf_10000_690
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:716: size_t remaining = buf_len - 1;
	mov	dptr,#_get_numeric_str_PARM_2
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	dec	r6
	cjne	r6,#0xff,00139$
	dec	r7
00139$:
;	quantum/quantum.c:717: uint8_t first = 1;
	mov	dptr,#_get_numeric_str_first_10000_691
	mov	a,#0x01
	movx	@dptr,a
;	quantum/quantum.c:718: buf[remaining] = '\0';
	mov	dptr,#_get_numeric_str_buf_10000_690
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	a,r6
	add	a, r3
	mov	r0,a
	mov	a,r7
	addc	a, r4
	mov	r1,a
	mov	ar2,r5
	mov	dpl,r0
	mov	dph,r1
	mov	b,r2
	clr	a
	lcall	__gptrput
;	quantum/quantum.c:719: while (remaining != 0) {
	mov	dptr,#_get_numeric_str_PARM_4
	movx	a,@dptr
	mov	r2,a
	mov	_get_numeric_str_sloc0_1_0,r3
	mov	(_get_numeric_str_sloc0_1_0 + 1),r4
	mov	(_get_numeric_str_sloc0_1_0 + 2),r5
00105$:
	mov	a,r6
	orl	a,r7
	jnz	00140$
	ljmp	00107$
00140$:
;	quantum/quantum.c:720: char selected = '0' + curr_num % 10;
	push	ar2
	mov	dptr,#_get_numeric_str_PARM_3
	movx	a,@dptr
	mov	r0,a
	inc	dptr
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r2,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#__modulong_PARM_2
	mov	a,#0x0a
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r0
	mov	dph, r1
	mov	b, r2
	mov	a, r5
	push	ar7
	push	ar6
	lcall	__modulong
	mov	r2, dpl
	pop	ar6
	pop	ar7
	mov	a,#0x30
	add	a, r2
	mov	_get_numeric_str_sloc1_1_0,a
	mov	dptr,#_get_numeric_str_selected_20000_692
	movx	@dptr,a
;	quantum/quantum.c:721: if (!(first && selected == '0') && curr_num == 0) {
	pop	ar2
	mov	dptr,#_get_numeric_str_first_10000_691
	movx	a,@dptr
	jz	00104$
	mov	a,#0x30
	cjne	a,_get_numeric_str_sloc1_1_0,00142$
	sjmp	00102$
00142$:
00104$:
	mov	dptr,#_get_numeric_str_PARM_3
	movx	a,@dptr
	mov	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	b,a
	inc	dptr
	movx	a,@dptr
	orl	a,b
	jnz	00102$
;	quantum/quantum.c:722: selected = curr_pad;
	mov	dptr,#_get_numeric_str_selected_20000_692
	mov	a,r2
	movx	@dptr,a
00102$:
;	quantum/quantum.c:724: --remaining;
	dec	r6
	cjne	r6,#0xff,00144$
	dec	r7
00144$:
;	quantum/quantum.c:725: buf[remaining] = selected;
	mov	a,r6
	add	a, _get_numeric_str_sloc0_1_0
	mov	r3,a
	mov	a,r7
	addc	a, (_get_numeric_str_sloc0_1_0 + 1)
	mov	r4,a
	mov	r5,(_get_numeric_str_sloc0_1_0 + 2)
	mov	dptr,#_get_numeric_str_selected_20000_692
	movx	a,@dptr
	mov	dpl,r3
	mov	dph,r4
	mov	b,r5
	lcall	__gptrput
;	quantum/quantum.c:726: first = 0;
	mov	dptr,#_get_numeric_str_first_10000_691
	clr	a
	movx	@dptr,a
;	quantum/quantum.c:727: curr_num /= 10;
	mov	dptr,#_get_numeric_str_PARM_3
	movx	a,@dptr
	mov	r1,a
	inc	dptr
	movx	a,@dptr
	mov	r3,a
	inc	dptr
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	dptr,#__divulong_PARM_2
	mov	a,#0x0a
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	inc	dptr
	movx	@dptr,a
	mov	dpl, r1
	mov	dph, r3
	mov	b, r4
	mov	a, r5
	push	ar7
	push	ar6
	push	ar2
	lcall	__divulong
	mov	r1, dpl
	mov	r3, dph
	mov	r4, b
	mov	r5, a
	pop	ar2
	pop	ar6
	pop	ar7
	mov	dptr,#_get_numeric_str_PARM_3
	mov	a,r1
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	ljmp	00105$
00107$:
;	quantum/quantum.c:737: return buf;
	mov	dptr,#_get_numeric_str_buf_10000_690
	movx	a,@dptr
	mov	r5,a
	inc	dptr
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dpl, r5
	mov	dph, r6
	mov	b, r7
;	quantum/quantum.c:738: }
	ret
;------------------------------------------------------------
;Allocation info for local variables in function 'get_u8_str'
;------------------------------------------------------------
;curr_pad      Allocated with name '_get_u8_str_PARM_2'
;curr_num      Allocated with name '_get_u8_str_curr_num_10000_695'
;buf           Allocated with name '_get_u8_str_buf_10000_696'
;last_num      Allocated with name '_get_u8_str_last_num_10000_696'
;last_pad      Allocated with name '_get_u8_str_last_pad_10000_696'
;------------------------------------------------------------
;	quantum/quantum.c:748: const char *get_u8_str(uint8_t curr_num, char curr_pad) {
;	-----------------------------------------
;	 function get_u8_str
;	-----------------------------------------
_get_u8_str:
	mov	a,dpl
	mov	dptr,#_get_u8_str_curr_num_10000_695
	movx	@dptr,a
;	quantum/quantum.c:752: if (last_num == curr_num && last_pad == curr_pad) {
	mov	dptr,#_get_u8_str_last_num_10000_696
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_get_u8_str_curr_num_10000_695
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00102$
	mov	dptr,#_get_u8_str_last_pad_10000_696
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_get_u8_str_PARM_2
	movx	a,@dptr
	mov	r5,a
	mov	a,r7
	cjne	a,ar5,00102$
;	quantum/quantum.c:753: return buf;
	mov	dptr,#_get_u8_str_buf_10000_696
	mov	b, #0x00
	ret
00102$:
;	quantum/quantum.c:755: last_num = curr_num;
	mov	dptr,#_get_u8_str_last_num_10000_696
	mov	a,r6
	movx	@dptr,a
;	quantum/quantum.c:756: last_pad = curr_pad;
	mov	dptr,#_get_u8_str_PARM_2
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_get_u8_str_last_pad_10000_696
	movx	@dptr,a
;	quantum/quantum.c:757: return get_numeric_str(buf, sizeof(buf), curr_num, curr_pad);
	mov	r5,#0x00
	mov	r4,#0x00
	mov	r3,#0x00
	mov	dptr,#_get_numeric_str_PARM_2
	mov	a,#0x04
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_get_numeric_str_PARM_3
	mov	a,r6
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r4
	inc	dptr
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_get_numeric_str_PARM_4
	mov	a,r7
	movx	@dptr,a
	mov	dptr,#_get_u8_str_buf_10000_696
	mov	b, #0x00
;	quantum/quantum.c:758: }
	ljmp	_get_numeric_str
;------------------------------------------------------------
;Allocation info for local variables in function 'get_u16_str'
;------------------------------------------------------------
;curr_pad      Allocated with name '_get_u16_str_PARM_2'
;curr_num      Allocated with name '_get_u16_str_curr_num_10000_699'
;buf           Allocated with name '_get_u16_str_buf_10000_700'
;last_num      Allocated with name '_get_u16_str_last_num_10000_700'
;last_pad      Allocated with name '_get_u16_str_last_pad_10000_700'
;------------------------------------------------------------
;	quantum/quantum.c:768: const char *get_u16_str(uint16_t curr_num, char curr_pad) {
;	-----------------------------------------
;	 function get_u16_str
;	-----------------------------------------
_get_u16_str:
	mov	r7,dph
	mov	a,dpl
	mov	dptr,#_get_u16_str_curr_num_10000_699
	movx	@dptr,a
	mov	a,r7
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:772: if (last_num == curr_num && last_pad == curr_pad) {
	mov	dptr,#_get_u16_str_last_num_10000_700
	movx	a,@dptr
	mov	r6,a
	inc	dptr
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_get_u16_str_curr_num_10000_699
	movx	a,@dptr
	mov	r4,a
	inc	dptr
	movx	a,@dptr
	mov	r5,a
	mov	a,r6
	cjne	a,ar4,00102$
	mov	a,r7
	cjne	a,ar5,00102$
	mov	dptr,#_get_u16_str_last_pad_10000_700
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_get_u16_str_PARM_2
	movx	a,@dptr
	mov	r6,a
	mov	a,r7
	cjne	a,ar6,00102$
;	quantum/quantum.c:773: return buf;
	mov	dptr,#_get_u16_str_buf_10000_700
	mov	b, #0x00
	ret
00102$:
;	quantum/quantum.c:775: last_num = curr_num;
	mov	dptr,#_get_u16_str_last_num_10000_700
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
;	quantum/quantum.c:776: last_pad = curr_pad;
	mov	dptr,#_get_u16_str_PARM_2
	movx	a,@dptr
	mov	r7,a
	mov	dptr,#_get_u16_str_last_pad_10000_700
	movx	@dptr,a
;	quantum/quantum.c:777: return get_numeric_str(buf, sizeof(buf), curr_num, curr_pad);
	mov	r6,#0x00
	mov	r3,#0x00
	mov	dptr,#_get_numeric_str_PARM_2
	mov	a,#0x06
	movx	@dptr,a
	clr	a
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_get_numeric_str_PARM_3
	mov	a,r4
	movx	@dptr,a
	mov	a,r5
	inc	dptr
	movx	@dptr,a
	mov	a,r6
	inc	dptr
	movx	@dptr,a
	mov	a,r3
	inc	dptr
	movx	@dptr,a
	mov	dptr,#_get_numeric_str_PARM_4
	mov	a,r7
	movx	@dptr,a
	mov	dptr,#_get_u16_str_buf_10000_700
	mov	b, #0x00
;	quantum/quantum.c:778: }
	ljmp	_get_numeric_str
	.area CSEG    (CODE)
	.area CONST   (CODE)
	.area XINIT   (CODE)
	.area CABS    (ABS,CODE)
