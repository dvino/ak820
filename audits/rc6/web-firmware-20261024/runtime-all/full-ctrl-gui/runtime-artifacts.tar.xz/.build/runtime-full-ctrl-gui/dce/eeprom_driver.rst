                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00067F                         85 _eeprom_read_word_addr_10000_91:
      00067F                         86 	.ds 3
      000682                         87 _eeprom_read_word_ret_10000_92:
      000682                         88 	.ds 2
      000684                         89 _eeprom_read_dword_addr_10000_93:
      000684                         90 	.ds 3
      000687                         91 _eeprom_read_dword_ret_10000_94:
      000687                         92 	.ds 4
      00068B                         93 _eeprom_write_byte_PARM_2:
      00068B                         94 	.ds 1
      00068C                         95 _eeprom_write_byte_addr_10000_95:
      00068C                         96 	.ds 3
      00068F                         97 _eeprom_write_word_PARM_2:
      00068F                         98 	.ds 2
      000691                         99 _eeprom_write_word_addr_10000_97:
      000691                        100 	.ds 3
      000694                        101 _eeprom_write_dword_PARM_2:
      000694                        102 	.ds 4
      000698                        103 _eeprom_write_dword_addr_10000_99:
      000698                        104 	.ds 3
      00069B                        105 _eeprom_update_byte_PARM_2:
      00069B                        106 	.ds 1
      00069C                        107 _eeprom_update_byte_addr_10000_107:
      00069C                        108 	.ds 3
      00069F                        109 _eeprom_update_word_PARM_2:
      00069F                        110 	.ds 2
      0006A1                        111 _eeprom_update_word_addr_10000_111:
      0006A1                        112 	.ds 3
      0006A4                        113 _eeprom_update_dword_PARM_2:
      0006A4                        114 	.ds 4
      0006A8                        115 _eeprom_update_dword_addr_10000_115:
      0006A8                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004D66                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004D66 12 43 15         [24]  170 	lcall	_ak820_outline_0037
      004D69 90 06 7F         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004D6C 12 38 29         [24]  172 	lcall	_ak820_outline_0017
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004D6F 90 06 82         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D72 12 4F 71         [24]  175 	lcall	_ak820_outline_0183
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004D75 90 06 7F         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004D78 12 4F 1E         [24]  178 	lcall	_ak820_outline_0012
      004D7B 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004D7E ED               [12]  180 	mov	a,r5
      004D7F 12 38 29         [24]  181 	lcall	_ak820_outline_0017
      004D82 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004D85 12 4F 63         [24]  183 	lcall	_ak820_outline_0111
      004D88 90 06 82         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D8B 12 40 B1         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004D8E 90 06 82         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004D91 12 4F 5A         [24]  188 	lcall	_ak820_outline_0091
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004D94 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004D95                        201 _eeprom_read_dword:
      004D95 12 43 15         [24]  202 	lcall	_ak820_outline_0037
      004D98 90 06 84         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004D9B 12 38 29         [24]  204 	lcall	_ak820_outline_0017
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004D9E 90 06 87         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004DA1 12 4F 2F         [24]  207 	lcall	_ak820_outline_0050
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004DA4 90 06 84         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004DA7 12 4F 1E         [24]  210 	lcall	_ak820_outline_0012
      004DAA 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004DAD ED               [12]  212 	mov	a,r5
      004DAE 12 38 29         [24]  213 	lcall	_ak820_outline_0017
      004DB1 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004DB4 74 04            [12]  215 	mov	a,#0x04
      004DB6 12 38 A1         [24]  216 	lcall	_ak820_outline_0135
      004DB9 90 06 87         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004DBC 12 40 B1         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004DBF 90 06 87         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004DC2 12 4F 38         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004DC5 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004DC6                        234 _eeprom_write_byte:
      004DC6 12 43 15         [24]  235 	lcall	_ak820_outline_0037
      004DC9 90 06 8C         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004DCC 12 38 29         [24]  237 	lcall	_ak820_outline_0017
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004DCF 90 06 8C         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004DD2 12 4F 07         [24]  240 	lcall	_ak820_outline_0004
      004DD5 74 01            [12]  241 	mov	a,#0x01
      004DD7 12 38 A1         [24]  242 	lcall	_ak820_outline_0135
      004DDA 90 06 8B         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004DDD 02 41 3D         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004DE0                        256 _eeprom_write_word:
      004DE0 12 43 15         [24]  257 	lcall	_ak820_outline_0037
      004DE3 90 06 91         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004DE6 12 38 29         [24]  259 	lcall	_ak820_outline_0017
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004DE9 90 06 91         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004DEC 12 4F 07         [24]  262 	lcall	_ak820_outline_0004
      004DEF 12 4F 63         [24]  263 	lcall	_ak820_outline_0111
      004DF2 90 06 8F         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004DF5 02 41 3D         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004DF8                        277 _eeprom_write_dword:
      004DF8 12 43 15         [24]  278 	lcall	_ak820_outline_0037
      004DFB 90 06 98         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004DFE 12 38 29         [24]  280 	lcall	_ak820_outline_0017
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004E01 90 06 98         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004E04 12 4F 07         [24]  283 	lcall	_ak820_outline_0004
      004E07 74 04            [12]  284 	mov	a,#0x04
      004E09 12 38 A1         [24]  285 	lcall	_ak820_outline_0135
      004E0C 90 06 94         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004E0F 02 41 3D         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004E12                        307 _eeprom_update_byte:
      004E12 C0 07            [24]  308 	push	ar7
      004E14 C0 06            [24]  309 	push	ar6
      004E16 C0 05            [24]  310 	push	ar5
      004E18 C0 04            [24]  311 	push	ar4
      004E1A 12 43 15         [24]  312 	lcall	_ak820_outline_0037
      004E1D 90 06 9C         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E20 12 38 29         [24]  314 	lcall	_ak820_outline_0017
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004E23 90 06 9C         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E26 12 4E F8         [24]  317 	lcall	_ak820_outline_0001
      004E29 12 40 76         [24]  318 	lcall	_eeprom_read_byte
      004E2C AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004E2E 90 06 9B         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004E31 E0               [24]  322 	movx	a,@dptr
      004E32 FE               [12]  323 	mov	r6,a
      004E33 EF               [12]  324 	mov	a,r7
      004E34 B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004E37 80 35            [24]  326 	sjmp	00103$
      004E39                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004E39 90 06 9C         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E3C 12 38 58         [24]  330 	lcall	_ak820_outline_0059
      004E3F A3               [24]  331 	inc	dptr
      004E40 E0               [24]  332 	movx	a,@dptr
      004E41 FF               [12]  333 	mov	r7,a
      004E42 90 06 8B         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004E45 EE               [12]  335 	mov	a,r6
      004E46 12 38 76         [24]  336 	lcall	_ak820_outline_0100
      004E49 8F F0            [24]  337 	mov	b, r7
      004E4B C0 07            [24]  338 	push	ar7
      004E4D C0 06            [24]  339 	push	ar6
      004E4F C0 05            [24]  340 	push	ar5
      004E51 C0 04            [24]  341 	push	ar4
      004E53 C0 03            [24]  342 	push	ar3
      004E55 C0 02            [24]  343 	push	ar2
      004E57 C0 01            [24]  344 	push	ar1
      004E59 C0 00            [24]  345 	push	ar0
      004E5B 12 4D C6         [24]  346 	lcall	_eeprom_write_byte
      004E5E D0 00            [24]  347 	pop	ar0
      004E60 D0 01            [24]  348 	pop	ar1
      004E62 D0 02            [24]  349 	pop	ar2
      004E64 D0 03            [24]  350 	pop	ar3
      004E66 D0 04            [24]  351 	pop	ar4
      004E68 D0 05            [24]  352 	pop	ar5
      004E6A D0 06            [24]  353 	pop	ar6
      004E6C D0 07            [24]  354 	pop	ar7
      004E6E                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      004E6E D0 04            [24]  357 	pop	ar4
      004E70 D0 05            [24]  358 	pop	ar5
      004E72 D0 06            [24]  359 	pop	ar6
      004E74 D0 07            [24]  360 	pop	ar7
      004E76 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      004E77                        373 _eeprom_update_word:
      004E77 12 43 15         [24]  374 	lcall	_ak820_outline_0037
      004E7A 90 06 A1         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E7D 12 38 29         [24]  376 	lcall	_ak820_outline_0017
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004E80 90 06 A1         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E83 12 4E F8         [24]  379 	lcall	_ak820_outline_0001
      004E86 12 4D 66         [24]  380 	lcall	_eeprom_read_word
      004E89 12 43 57         [24]  381 	lcall	_ak820_outline_0134
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004E8C 90 06 9F         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      004E8F 12 38 58         [24]  384 	lcall	_ak820_outline_0059
      004E92 EE               [12]  385 	mov	a,r6
      004E93 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      004E96 EF               [12]  387 	mov	a,r7
      004E97 B5 05 01         [24]  388 	cjne	a,ar5,00112$
      004E9A 22               [24]  389 	ret
      004E9B                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004E9B 90 06 A1         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004E9E E0               [24]  393 	movx	a,@dptr
      004E9F FB               [12]  394 	mov	r3,a
      004EA0 A3               [24]  395 	inc	dptr
      004EA1 12 38 41         [24]  396 	lcall	_ak820_outline_0051
      004EA4 90 06 8F         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      004EA7 12 38 5E         [24]  398 	lcall	_ak820_outline_0072
      004EAA 8B 82            [24]  399 	mov	dpl, r3
      004EAC 8E 83            [24]  400 	mov	dph, r6
      004EAE 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      004EB0 02 4D E0         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      004EB3                        415 _eeprom_update_dword:
      004EB3 12 43 15         [24]  416 	lcall	_ak820_outline_0037
      004EB6 90 06 A8         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004EB9 12 38 29         [24]  418 	lcall	_ak820_outline_0017
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004EBC 90 06 A8         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004EBF 12 4E F8         [24]  421 	lcall	_ak820_outline_0001
      004EC2 12 4D 95         [24]  422 	lcall	_eeprom_read_dword
      004EC5 12 4F 49         [24]  423 	lcall	_ak820_outline_0055
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004EC8 90 06 A4         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      004ECB E0               [24]  426 	movx	a,@dptr
      004ECC F8               [12]  427 	mov	r0,a
      004ECD A3               [24]  428 	inc	dptr
      004ECE 12 4F 51         [24]  429 	lcall	_ak820_outline_0090
      004ED1 EC               [12]  430 	mov	a,r4
      004ED2 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      004ED5 ED               [12]  432 	mov	a,r5
      004ED6 B5 01 09         [24]  433 	cjne	a,ar1,00112$
      004ED9 EE               [12]  434 	mov	a,r6
      004EDA B5 02 05         [24]  435 	cjne	a,ar2,00112$
      004EDD EF               [12]  436 	mov	a,r7
      004EDE B5 03 01         [24]  437 	cjne	a,ar3,00112$
      004EE1 22               [24]  438 	ret
      004EE2                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004EE2 90 06 A8         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004EE5 12 4F 1E         [24]  442 	lcall	_ak820_outline_0012
      004EE8 90 06 94         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      004EEB E8               [12]  444 	mov	a,r0
      004EEC F0               [24]  445 	movx	@dptr,a
      004EED E9               [12]  446 	mov	a,r1
      004EEE A3               [24]  447 	inc	dptr
      004EEF 12 4F 6A         [24]  448 	lcall	_ak820_outline_0155
      004EF2 12 4F 27         [24]  449 	lcall	_ak820_outline_0034
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      004EF5 02 4D F8         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0012
                                    461 	.globl _ak820_outline_0017
                                    462 	.globl _ak820_outline_0034
                                    463 	.globl _ak820_outline_0037
                                    464 	.globl _ak820_outline_0050
                                    465 	.globl _ak820_outline_0051
                                    466 	.globl _ak820_outline_0054
                                    467 	.globl _ak820_outline_0055
                                    468 	.globl _ak820_outline_0059
                                    469 	.globl _ak820_outline_0072
                                    470 	.globl _ak820_outline_0090
                                    471 	.globl _ak820_outline_0091
                                    472 	.globl _ak820_outline_0100
                                    473 	.globl _ak820_outline_0111
                                    474 	.globl _ak820_outline_0134
                                    475 	.globl _ak820_outline_0135
                                    476 	.globl _ak820_outline_0155
                                    477 	.globl _ak820_outline_0183
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      004EF8                        481 _ak820_outline_0001:
      004EF8 E0               [24]  482 	movx	a,@dptr
      004EF9 FD               [12]  483 	mov	r5,a
      004EFA A3               [24]  484 	inc	dptr
      004EFB E0               [24]  485 	movx	a,@dptr
      004EFC FE               [12]  486 	mov	r6,a
      004EFD A3               [24]  487 	inc	dptr
      004EFE E0               [24]  488 	movx	a,@dptr
      004EFF FF               [12]  489 	mov	r7,a
      004F00 8D 82            [24]  490 	mov	dpl,r5
      004F02 8E 83            [24]  491 	mov	dph,r6
      004F04 8F F0            [24]  492 	mov	b,r7
      004F06 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      004F07                        497 _ak820_outline_0004:
      004F07 E0               [24]  498 	movx	a,@dptr
      004F08 FD               [12]  499 	mov	r5,a
      004F09 A3               [24]  500 	inc	dptr
      004F0A E0               [24]  501 	movx	a,@dptr
      004F0B FE               [12]  502 	mov	r6,a
      004F0C A3               [24]  503 	inc	dptr
      004F0D E0               [24]  504 	movx	a,@dptr
      004F0E FF               [12]  505 	mov	r7,a
      004F0F 90 05 8E         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004F12 ED               [12]  507 	mov	a,r5
      004F13 F0               [24]  508 	movx	@dptr,a
      004F14 EE               [12]  509 	mov	a,r6
      004F15 A3               [24]  510 	inc	dptr
      004F16 F0               [24]  511 	movx	@dptr,a
      004F17 EF               [12]  512 	mov	a,r7
      004F18 A3               [24]  513 	inc	dptr
      004F19 F0               [24]  514 	movx	@dptr,a
      004F1A 90 05 91         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004F1D 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0012
      004F1E                        520 _ak820_outline_0012:
      004F1E E0               [24]  521 	movx	a,@dptr
      004F1F FD               [12]  522 	mov	r5,a
      004F20 A3               [24]  523 	inc	dptr
      004F21 E0               [24]  524 	movx	a,@dptr
      004F22 FE               [12]  525 	mov	r6,a
      004F23 A3               [24]  526 	inc	dptr
      004F24 E0               [24]  527 	movx	a,@dptr
      004F25 FF               [12]  528 	mov	r7,a
      004F26 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0034
      004F27                        533 _ak820_outline_0034:
      004F27 F0               [24]  534 	movx	@dptr,a
      004F28 8D 82            [24]  535 	mov	dpl,r5
      004F2A 8E 83            [24]  536 	mov	dph,r6
      004F2C 8F F0            [24]  537 	mov	b,r7
      004F2E 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0050
      004F2F                        542 _ak820_outline_0050:
      004F2F E4               [12]  543 	clr	a
      004F30 F0               [24]  544 	movx	@dptr,a
      004F31 A3               [24]  545 	inc	dptr
      004F32 F0               [24]  546 	movx	@dptr,a
      004F33 A3               [24]  547 	inc	dptr
      004F34 F0               [24]  548 	movx	@dptr,a
      004F35 A3               [24]  549 	inc	dptr
      004F36 F0               [24]  550 	movx	@dptr,a
      004F37 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0054
      004F38                        555 _ak820_outline_0054:
      004F38 E0               [24]  556 	movx	a,@dptr
      004F39 FC               [12]  557 	mov	r4,a
      004F3A A3               [24]  558 	inc	dptr
      004F3B E0               [24]  559 	movx	a,@dptr
      004F3C FD               [12]  560 	mov	r5,a
      004F3D A3               [24]  561 	inc	dptr
      004F3E E0               [24]  562 	movx	a,@dptr
      004F3F FE               [12]  563 	mov	r6,a
      004F40 A3               [24]  564 	inc	dptr
      004F41 E0               [24]  565 	movx	a,@dptr
      004F42 8C 82            [24]  566 	mov	dpl,r4
      004F44 8D 83            [24]  567 	mov	dph,r5
      004F46 8E F0            [24]  568 	mov	b,r6
      004F48 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0055
      004F49                        573 _ak820_outline_0055:
      004F49 AC 82            [24]  574 	mov	r4,dpl
      004F4B AD 83            [24]  575 	mov	r5,dph
      004F4D AE F0            [24]  576 	mov	r6,b
      004F4F FF               [12]  577 	mov	r7,a
      004F50 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0090
      004F51                        582 _ak820_outline_0090:
      004F51 E0               [24]  583 	movx	a,@dptr
      004F52 F9               [12]  584 	mov	r1,a
      004F53 A3               [24]  585 	inc	dptr
      004F54 E0               [24]  586 	movx	a,@dptr
      004F55 FA               [12]  587 	mov	r2,a
      004F56 A3               [24]  588 	inc	dptr
      004F57 E0               [24]  589 	movx	a,@dptr
      004F58 FB               [12]  590 	mov	r3,a
      004F59 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0091
      004F5A                        595 _ak820_outline_0091:
      004F5A E0               [24]  596 	movx	a,@dptr
      004F5B FE               [12]  597 	mov	r6,a
      004F5C A3               [24]  598 	inc	dptr
      004F5D E0               [24]  599 	movx	a,@dptr
      004F5E 8E 82            [24]  600 	mov	dpl,r6
      004F60 F5 83            [12]  601 	mov	dph,a
      004F62 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0111
      004F63                        606 _ak820_outline_0111:
      004F63 74 02            [12]  607 	mov	a,#0x02
      004F65 F0               [24]  608 	movx	@dptr,a
      004F66 E4               [12]  609 	clr	a
      004F67 A3               [24]  610 	inc	dptr
      004F68 F0               [24]  611 	movx	@dptr,a
      004F69 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0155
      004F6A                        616 _ak820_outline_0155:
      004F6A F0               [24]  617 	movx	@dptr,a
      004F6B EA               [12]  618 	mov	a,r2
      004F6C A3               [24]  619 	inc	dptr
      004F6D F0               [24]  620 	movx	@dptr,a
      004F6E EB               [12]  621 	mov	a,r3
      004F6F A3               [24]  622 	inc	dptr
      004F70 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0183
      004F71                        627 _ak820_outline_0183:
      004F71 E4               [12]  628 	clr	a
      004F72 F0               [24]  629 	movx	@dptr,a
      004F73 A3               [24]  630 	inc	dptr
      004F74 F0               [24]  631 	movx	@dptr,a
      004F75 22               [24]  632 	ret
