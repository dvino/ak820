                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vial
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _unregister_code16
                                     12 	.globl _register_code16
                                     13 	.globl _matrix_is_on
                                     14 	.globl _dynamic_keymap_set_combo
                                     15 	.globl _dynamic_keymap_get_combo
                                     16 	.globl _dynamic_keymap_set_encoder
                                     17 	.globl _dynamic_keymap_get_encoder
                                     18 	.globl _repeat_key_cancel
                                     19 	.globl _ak820_combo_reload
                                     20 	.globl _clear_keyboard
                                     21 	.globl _ak820_action_exec
                                     22 	.globl _timer_elapsed32
                                     23 	.globl _timer_read32
                                     24 	.globl _timer_read
                                     25 	.globl ___memcpy
                                     26 	.globl _ADC_START
                                     27 	.globl _S0_R_FIFO
                                     28 	.globl _S0_T_FIFO
                                     29 	.globl _S0_FREE
                                     30 	.globl _S0_IF_BYTE
                                     31 	.globl _S0_IF_FIRST
                                     32 	.globl _S0_IF_OV
                                     33 	.globl _S0_FST_ACT
                                     34 	.globl _CP_RL2
                                     35 	.globl _C_T2
                                     36 	.globl _TR2
                                     37 	.globl _EXEN2
                                     38 	.globl _TCLK
                                     39 	.globl _RCLK
                                     40 	.globl _EXF2
                                     41 	.globl _CAP1F
                                     42 	.globl _TF2
                                     43 	.globl _RI
                                     44 	.globl _TI
                                     45 	.globl _RB8
                                     46 	.globl _TB8
                                     47 	.globl _REN
                                     48 	.globl _SM2
                                     49 	.globl _SM1
                                     50 	.globl _SM0
                                     51 	.globl _IT0
                                     52 	.globl _IE0
                                     53 	.globl _IT1
                                     54 	.globl _IE1
                                     55 	.globl _TR0
                                     56 	.globl _TF0
                                     57 	.globl _TR1
                                     58 	.globl _TF1
                                     59 	.globl _P4_0
                                     60 	.globl _P4_1
                                     61 	.globl _P4_2
                                     62 	.globl _P4_3
                                     63 	.globl _P4_4
                                     64 	.globl _P4_5
                                     65 	.globl _P4_6
                                     66 	.globl _RXD
                                     67 	.globl _TXD
                                     68 	.globl _INT0
                                     69 	.globl _INT1
                                     70 	.globl _T0
                                     71 	.globl _T1
                                     72 	.globl _MOSI1
                                     73 	.globl _MISO1
                                     74 	.globl _SCK1
                                     75 	.globl _P3_0
                                     76 	.globl _P3_1
                                     77 	.globl _P3_2
                                     78 	.globl _P3_3
                                     79 	.globl _P3_4
                                     80 	.globl _P3_5
                                     81 	.globl _P3_6
                                     82 	.globl _P3_7
                                     83 	.globl _CAP1_
                                     84 	.globl _T2_
                                     85 	.globl _CAP2_
                                     86 	.globl _T2EX_
                                     87 	.globl _RXD1
                                     88 	.globl _TXD1
                                     89 	.globl _P2_0
                                     90 	.globl _P2_1
                                     91 	.globl _P2_2
                                     92 	.globl _P2_3
                                     93 	.globl _P2_4
                                     94 	.globl _P2_5
                                     95 	.globl _P2_6
                                     96 	.globl _P2_7
                                     97 	.globl _AIN0
                                     98 	.globl _AIN1
                                     99 	.globl _AIN2
                                    100 	.globl _AIN3
                                    101 	.globl _AIN4
                                    102 	.globl _AIN5
                                    103 	.globl _AIN6
                                    104 	.globl _AIN7
                                    105 	.globl _CAP1
                                    106 	.globl _T2
                                    107 	.globl _CAP2
                                    108 	.globl _T2EX
                                    109 	.globl _INT0_
                                    110 	.globl _SCS
                                    111 	.globl _MOSI
                                    112 	.globl _MISO
                                    113 	.globl _SCK
                                    114 	.globl _RXD1_
                                    115 	.globl _TXD1_
                                    116 	.globl _P1_0
                                    117 	.globl _P1_1
                                    118 	.globl _P1_2
                                    119 	.globl _P1_3
                                    120 	.globl _P1_4
                                    121 	.globl _P1_5
                                    122 	.globl _P1_6
                                    123 	.globl _P1_7
                                    124 	.globl _AIN8
                                    125 	.globl _AIN9
                                    126 	.globl _AIN10
                                    127 	.globl _AIN11
                                    128 	.globl _AIN12
                                    129 	.globl _AIN13
                                    130 	.globl _RXD_
                                    131 	.globl _TXD_
                                    132 	.globl _SCL0
                                    133 	.globl _SDA0
                                    134 	.globl _P0_0
                                    135 	.globl _P0_1
                                    136 	.globl _P0_2
                                    137 	.globl _P0_3
                                    138 	.globl _P0_4
                                    139 	.globl _P0_5
                                    140 	.globl _P0_6
                                    141 	.globl _P0_7
                                    142 	.globl _IE_SPI0
                                    143 	.globl _IE_USB
                                    144 	.globl _IE_ADC
                                    145 	.globl _IE_UART1
                                    146 	.globl _IE_PWM_I2C
                                    147 	.globl _IE_GPIO
                                    148 	.globl _IE_WDOG
                                    149 	.globl _PX0
                                    150 	.globl _PT0
                                    151 	.globl _PX1
                                    152 	.globl _PT1
                                    153 	.globl _PS
                                    154 	.globl _PT2
                                    155 	.globl _PL_FLAG
                                    156 	.globl _PH_FLAG
                                    157 	.globl _EX0
                                    158 	.globl _ET0
                                    159 	.globl _EX1
                                    160 	.globl _ET1
                                    161 	.globl _ES
                                    162 	.globl _ET2
                                    163 	.globl _E_DIS
                                    164 	.globl _EA
                                    165 	.globl _P
                                    166 	.globl _F1
                                    167 	.globl _OV
                                    168 	.globl _RS0
                                    169 	.globl _RS1
                                    170 	.globl _F0
                                    171 	.globl _AC
                                    172 	.globl _CY
                                    173 	.globl _I2CS_INT_ST
                                    174 	.globl _I2CX_INT
                                    175 	.globl _LED_STATUS
                                    176 	.globl _LED_DMA_H
                                    177 	.globl _LED_DMA_L
                                    178 	.globl _LED_DMA
                                    179 	.globl _LED_PWM_OE
                                    180 	.globl _LED_COMMON
                                    181 	.globl _ADC_CHAN
                                    182 	.globl _ADC_DAT_H
                                    183 	.globl _ADC_DAT_L
                                    184 	.globl _ADC_DAT
                                    185 	.globl _ADC_CTRL
                                    186 	.globl _SPI1_CK_SE
                                    187 	.globl _SPI1_CTRL
                                    188 	.globl _SPI1_DATA
                                    189 	.globl _SPI1_STAT
                                    190 	.globl _SIF1
                                    191 	.globl _SBAUD1
                                    192 	.globl _SBUF1
                                    193 	.globl _SCON1
                                    194 	.globl _SPI0_SETUP
                                    195 	.globl _SPI0_CK_SE
                                    196 	.globl _SPI0_CTRL
                                    197 	.globl _SPI0_DATA
                                    198 	.globl _SPI0_STAT
                                    199 	.globl _T2CAP1H
                                    200 	.globl _T2CAP1L
                                    201 	.globl _T2CAP1
                                    202 	.globl _TH2
                                    203 	.globl _TL2
                                    204 	.globl _T2COUNT
                                    205 	.globl _RCAP2H
                                    206 	.globl _RCAP2L
                                    207 	.globl _RCAP2
                                    208 	.globl _T2MOD
                                    209 	.globl _T2CON
                                    210 	.globl _SBUF
                                    211 	.globl _SCON
                                    212 	.globl _TH1
                                    213 	.globl _TH0
                                    214 	.globl _TL1
                                    215 	.globl _TL0
                                    216 	.globl _TMOD
                                    217 	.globl _TCON
                                    218 	.globl _XBUS_AUX
                                    219 	.globl _P7
                                    220 	.globl _P6_DIR
                                    221 	.globl _P6_OUT_PU
                                    222 	.globl _P6_IN
                                    223 	.globl _P5_DIR
                                    224 	.globl _P5_OUT_PU
                                    225 	.globl _P5_IN
                                    226 	.globl _P4_LED_KEY
                                    227 	.globl _P4_DIR_PU
                                    228 	.globl _P4_MOD_OC
                                    229 	.globl _P4
                                    230 	.globl _P3_DIR_PU
                                    231 	.globl _P3_MOD_OC
                                    232 	.globl _P3
                                    233 	.globl _P2_DIR_PU
                                    234 	.globl _P2_MOD_OC
                                    235 	.globl _P2
                                    236 	.globl _P1_DIR_PU
                                    237 	.globl _P1_MOD_OC
                                    238 	.globl _P1
                                    239 	.globl _P0_DIR_PU
                                    240 	.globl _P0_MOD_OC
                                    241 	.globl _P0
                                    242 	.globl _ROM_CTRL
                                    243 	.globl _ROM_DATA_HH
                                    244 	.globl _ROM_DATA_HL
                                    245 	.globl _ROM_DATA_HI
                                    246 	.globl _ROM_ADDR_H
                                    247 	.globl _ROM_ADDR_L
                                    248 	.globl _ROM_ADDR
                                    249 	.globl _GPIO_IE
                                    250 	.globl _IP_EX
                                    251 	.globl _IE_EX
                                    252 	.globl _IP
                                    253 	.globl _IE
                                    254 	.globl _WDOG_COUNT
                                    255 	.globl _RESET_KEEP
                                    256 	.globl _WAKE_CTRL
                                    257 	.globl _CLOCK_CFG
                                    258 	.globl _POWER_CFG
                                    259 	.globl _PCON
                                    260 	.globl _GLOBAL_CFG
                                    261 	.globl _SAFE_MOD
                                    262 	.globl _DPH
                                    263 	.globl _DPL
                                    264 	.globl _SP
                                    265 	.globl _A_INV
                                    266 	.globl _B
                                    267 	.globl _ACC
                                    268 	.globl _PSW
                                    269 	.globl _vial_unlock_in_progress
                                    270 	.globl _vial_unlocked
                                    271 	.globl _g_vial_magic_keycode_override
                                    272 	.globl _vial_handle_cmd_PARM_2
                                    273 	.globl _vial_unlock_task
                                    274 	.globl _vial_init
                                    275 	.globl _vial_handle_cmd
                                    276 	.globl _vial_keycode_down
                                    277 	.globl _vial_keycode_up
                                    278 	.globl _vial_keycode_tap
                                    279 ;--------------------------------------------------------
                                    280 ; special function registers
                                    281 ;--------------------------------------------------------
                                    282 	.area RSEG    (ABS,DATA)
      000000                        283 	.org 0x0000
                           0000D0   284 _PSW	=	0x00d0
                           0000E0   285 _ACC	=	0x00e0
                           0000F0   286 _B	=	0x00f0
                           0000FD   287 _A_INV	=	0x00fd
                           000081   288 _SP	=	0x0081
                           000082   289 _DPL	=	0x0082
                           000083   290 _DPH	=	0x0083
                           0000A1   291 _SAFE_MOD	=	0x00a1
                           0000B1   292 _GLOBAL_CFG	=	0x00b1
                           000087   293 _PCON	=	0x0087
                           0000BA   294 _POWER_CFG	=	0x00ba
                           0000B9   295 _CLOCK_CFG	=	0x00b9
                           0000A9   296 _WAKE_CTRL	=	0x00a9
                           0000FE   297 _RESET_KEEP	=	0x00fe
                           0000FF   298 _WDOG_COUNT	=	0x00ff
                           0000A8   299 _IE	=	0x00a8
                           0000B8   300 _IP	=	0x00b8
                           0000E8   301 _IE_EX	=	0x00e8
                           0000E9   302 _IP_EX	=	0x00e9
                           0000B2   303 _GPIO_IE	=	0x00b2
                           008584   304 _ROM_ADDR	=	0x8584
                           000084   305 _ROM_ADDR_L	=	0x0084
                           000085   306 _ROM_ADDR_H	=	0x0085
                           008F8E   307 _ROM_DATA_HI	=	0x8f8e
                           00008E   308 _ROM_DATA_HL	=	0x008e
                           00008F   309 _ROM_DATA_HH	=	0x008f
                           000086   310 _ROM_CTRL	=	0x0086
                           000080   311 _P0	=	0x0080
                           0000C4   312 _P0_MOD_OC	=	0x00c4
                           0000C5   313 _P0_DIR_PU	=	0x00c5
                           000090   314 _P1	=	0x0090
                           000092   315 _P1_MOD_OC	=	0x0092
                           000093   316 _P1_DIR_PU	=	0x0093
                           0000A0   317 _P2	=	0x00a0
                           000094   318 _P2_MOD_OC	=	0x0094
                           000095   319 _P2_DIR_PU	=	0x0095
                           0000B0   320 _P3	=	0x00b0
                           000096   321 _P3_MOD_OC	=	0x0096
                           000097   322 _P3_DIR_PU	=	0x0097
                           0000C0   323 _P4	=	0x00c0
                           0000C2   324 _P4_MOD_OC	=	0x00c2
                           0000C3   325 _P4_DIR_PU	=	0x00c3
                           0000C1   326 _P4_LED_KEY	=	0x00c1
                           0000AA   327 _P5_IN	=	0x00aa
                           0000AB   328 _P5_OUT_PU	=	0x00ab
                           0000AC   329 _P5_DIR	=	0x00ac
                           0000AD   330 _P6_IN	=	0x00ad
                           0000AE   331 _P6_OUT_PU	=	0x00ae
                           0000AF   332 _P6_DIR	=	0x00af
                           0000F1   333 _P7	=	0x00f1
                           0000A2   334 _XBUS_AUX	=	0x00a2
                           000088   335 _TCON	=	0x0088
                           000089   336 _TMOD	=	0x0089
                           00008A   337 _TL0	=	0x008a
                           00008B   338 _TL1	=	0x008b
                           00008C   339 _TH0	=	0x008c
                           00008D   340 _TH1	=	0x008d
                           000098   341 _SCON	=	0x0098
                           000099   342 _SBUF	=	0x0099
                           0000C8   343 _T2CON	=	0x00c8
                           0000C9   344 _T2MOD	=	0x00c9
                           00CBCA   345 _RCAP2	=	0xcbca
                           0000CA   346 _RCAP2L	=	0x00ca
                           0000CB   347 _RCAP2H	=	0x00cb
                           00CDCC   348 _T2COUNT	=	0xcdcc
                           0000CC   349 _TL2	=	0x00cc
                           0000CD   350 _TH2	=	0x00cd
                           00CFCE   351 _T2CAP1	=	0xcfce
                           0000CE   352 _T2CAP1L	=	0x00ce
                           0000CF   353 _T2CAP1H	=	0x00cf
                           0000F8   354 _SPI0_STAT	=	0x00f8
                           0000F9   355 _SPI0_DATA	=	0x00f9
                           0000FA   356 _SPI0_CTRL	=	0x00fa
                           0000FB   357 _SPI0_CK_SE	=	0x00fb
                           0000FC   358 _SPI0_SETUP	=	0x00fc
                           0000BC   359 _SCON1	=	0x00bc
                           0000BD   360 _SBUF1	=	0x00bd
                           0000BE   361 _SBAUD1	=	0x00be
                           0000BF   362 _SIF1	=	0x00bf
                           0000B4   363 _SPI1_STAT	=	0x00b4
                           0000B5   364 _SPI1_DATA	=	0x00b5
                           0000B6   365 _SPI1_CTRL	=	0x00b6
                           0000B7   366 _SPI1_CK_SE	=	0x00b7
                           0000F3   367 _ADC_CTRL	=	0x00f3
                           00F5F4   368 _ADC_DAT	=	0xf5f4
                           0000F4   369 _ADC_DAT_L	=	0x00f4
                           0000F5   370 _ADC_DAT_H	=	0x00f5
                           0000F6   371 _ADC_CHAN	=	0x00f6
                           0000A6   372 _LED_COMMON	=	0x00a6
                           0000A7   373 _LED_PWM_OE	=	0x00a7
                           00C7C6   374 _LED_DMA	=	0xc7c6
                           0000C6   375 _LED_DMA_L	=	0x00c6
                           0000C7   376 _LED_DMA_H	=	0x00c7
                           0000F7   377 _LED_STATUS	=	0x00f7
                           0000B3   378 _I2CX_INT	=	0x00b3
                           0000BB   379 _I2CS_INT_ST	=	0x00bb
                                    380 ;--------------------------------------------------------
                                    381 ; special function bits
                                    382 ;--------------------------------------------------------
                                    383 	.area RSEG    (ABS,DATA)
      000000                        384 	.org 0x0000
                           0000D7   385 _CY	=	0x00d7
                           0000D6   386 _AC	=	0x00d6
                           0000D5   387 _F0	=	0x00d5
                           0000D4   388 _RS1	=	0x00d4
                           0000D3   389 _RS0	=	0x00d3
                           0000D2   390 _OV	=	0x00d2
                           0000D1   391 _F1	=	0x00d1
                           0000D0   392 _P	=	0x00d0
                           0000AF   393 _EA	=	0x00af
                           0000AE   394 _E_DIS	=	0x00ae
                           0000AD   395 _ET2	=	0x00ad
                           0000AC   396 _ES	=	0x00ac
                           0000AB   397 _ET1	=	0x00ab
                           0000AA   398 _EX1	=	0x00aa
                           0000A9   399 _ET0	=	0x00a9
                           0000A8   400 _EX0	=	0x00a8
                           0000BF   401 _PH_FLAG	=	0x00bf
                           0000BE   402 _PL_FLAG	=	0x00be
                           0000BD   403 _PT2	=	0x00bd
                           0000BC   404 _PS	=	0x00bc
                           0000BB   405 _PT1	=	0x00bb
                           0000BA   406 _PX1	=	0x00ba
                           0000B9   407 _PT0	=	0x00b9
                           0000B8   408 _PX0	=	0x00b8
                           0000EF   409 _IE_WDOG	=	0x00ef
                           0000EE   410 _IE_GPIO	=	0x00ee
                           0000ED   411 _IE_PWM_I2C	=	0x00ed
                           0000EC   412 _IE_UART1	=	0x00ec
                           0000EB   413 _IE_ADC	=	0x00eb
                           0000E9   414 _IE_USB	=	0x00e9
                           0000E8   415 _IE_SPI0	=	0x00e8
                           000087   416 _P0_7	=	0x0087
                           000086   417 _P0_6	=	0x0086
                           000085   418 _P0_5	=	0x0085
                           000084   419 _P0_4	=	0x0084
                           000083   420 _P0_3	=	0x0083
                           000082   421 _P0_2	=	0x0082
                           000081   422 _P0_1	=	0x0081
                           000080   423 _P0_0	=	0x0080
                           000081   424 _SDA0	=	0x0081
                           000080   425 _SCL0	=	0x0080
                           000083   426 _TXD_	=	0x0083
                           000082   427 _RXD_	=	0x0082
                           000085   428 _AIN13	=	0x0085
                           000084   429 _AIN12	=	0x0084
                           000083   430 _AIN11	=	0x0083
                           000082   431 _AIN10	=	0x0082
                           000081   432 _AIN9	=	0x0081
                           000080   433 _AIN8	=	0x0080
                           000097   434 _P1_7	=	0x0097
                           000096   435 _P1_6	=	0x0096
                           000095   436 _P1_5	=	0x0095
                           000094   437 _P1_4	=	0x0094
                           000093   438 _P1_3	=	0x0093
                           000092   439 _P1_2	=	0x0092
                           000091   440 _P1_1	=	0x0091
                           000090   441 _P1_0	=	0x0090
                           000097   442 _TXD1_	=	0x0097
                           000096   443 _RXD1_	=	0x0096
                           000097   444 _SCK	=	0x0097
                           000096   445 _MISO	=	0x0096
                           000095   446 _MOSI	=	0x0095
                           000094   447 _SCS	=	0x0094
                           000092   448 _INT0_	=	0x0092
                           000091   449 _T2EX	=	0x0091
                           000091   450 _CAP2	=	0x0091
                           000090   451 _T2	=	0x0090
                           000090   452 _CAP1	=	0x0090
                           000097   453 _AIN7	=	0x0097
                           000096   454 _AIN6	=	0x0096
                           000095   455 _AIN5	=	0x0095
                           000094   456 _AIN4	=	0x0094
                           000093   457 _AIN3	=	0x0093
                           000092   458 _AIN2	=	0x0092
                           000091   459 _AIN1	=	0x0091
                           000090   460 _AIN0	=	0x0090
                           0000A7   461 _P2_7	=	0x00a7
                           0000A6   462 _P2_6	=	0x00a6
                           0000A5   463 _P2_5	=	0x00a5
                           0000A4   464 _P2_4	=	0x00a4
                           0000A3   465 _P2_3	=	0x00a3
                           0000A2   466 _P2_2	=	0x00a2
                           0000A1   467 _P2_1	=	0x00a1
                           0000A0   468 _P2_0	=	0x00a0
                           0000A7   469 _TXD1	=	0x00a7
                           0000A6   470 _RXD1	=	0x00a6
                           0000A5   471 _T2EX_	=	0x00a5
                           0000A5   472 _CAP2_	=	0x00a5
                           0000A4   473 _T2_	=	0x00a4
                           0000A4   474 _CAP1_	=	0x00a4
                           0000B7   475 _P3_7	=	0x00b7
                           0000B6   476 _P3_6	=	0x00b6
                           0000B5   477 _P3_5	=	0x00b5
                           0000B4   478 _P3_4	=	0x00b4
                           0000B3   479 _P3_3	=	0x00b3
                           0000B2   480 _P3_2	=	0x00b2
                           0000B1   481 _P3_1	=	0x00b1
                           0000B0   482 _P3_0	=	0x00b0
                           0000B7   483 _SCK1	=	0x00b7
                           0000B6   484 _MISO1	=	0x00b6
                           0000B5   485 _MOSI1	=	0x00b5
                           0000B5   486 _T1	=	0x00b5
                           0000B4   487 _T0	=	0x00b4
                           0000B3   488 _INT1	=	0x00b3
                           0000B2   489 _INT0	=	0x00b2
                           0000B1   490 _TXD	=	0x00b1
                           0000B0   491 _RXD	=	0x00b0
                           0000C6   492 _P4_6	=	0x00c6
                           0000C5   493 _P4_5	=	0x00c5
                           0000C4   494 _P4_4	=	0x00c4
                           0000C3   495 _P4_3	=	0x00c3
                           0000C2   496 _P4_2	=	0x00c2
                           0000C1   497 _P4_1	=	0x00c1
                           0000C0   498 _P4_0	=	0x00c0
                           00008F   499 _TF1	=	0x008f
                           00008E   500 _TR1	=	0x008e
                           00008D   501 _TF0	=	0x008d
                           00008C   502 _TR0	=	0x008c
                           00008B   503 _IE1	=	0x008b
                           00008A   504 _IT1	=	0x008a
                           000089   505 _IE0	=	0x0089
                           000088   506 _IT0	=	0x0088
                           00009F   507 _SM0	=	0x009f
                           00009E   508 _SM1	=	0x009e
                           00009D   509 _SM2	=	0x009d
                           00009C   510 _REN	=	0x009c
                           00009B   511 _TB8	=	0x009b
                           00009A   512 _RB8	=	0x009a
                           000099   513 _TI	=	0x0099
                           000098   514 _RI	=	0x0098
                           0000CF   515 _TF2	=	0x00cf
                           0000CF   516 _CAP1F	=	0x00cf
                           0000CE   517 _EXF2	=	0x00ce
                           0000CD   518 _RCLK	=	0x00cd
                           0000CC   519 _TCLK	=	0x00cc
                           0000CB   520 _EXEN2	=	0x00cb
                           0000CA   521 _TR2	=	0x00ca
                           0000C9   522 _C_T2	=	0x00c9
                           0000C8   523 _CP_RL2	=	0x00c8
                           0000FF   524 _S0_FST_ACT	=	0x00ff
                           0000FE   525 _S0_IF_OV	=	0x00fe
                           0000FD   526 _S0_IF_FIRST	=	0x00fd
                           0000FC   527 _S0_IF_BYTE	=	0x00fc
                           0000FB   528 _S0_FREE	=	0x00fb
                           0000FA   529 _S0_T_FIFO	=	0x00fa
                           0000F8   530 _S0_R_FIFO	=	0x00f8
                           0000F7   531 _ADC_START	=	0x00f7
                                    532 ;--------------------------------------------------------
                                    533 ; overlayable register banks
                                    534 ;--------------------------------------------------------
                                    535 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        536 	.ds 8
                                    537 ;--------------------------------------------------------
                                    538 ; internal ram data
                                    539 ;--------------------------------------------------------
                                    540 	.area DSEG    (DATA)
      000042                        541 _vial_handle_cmd_sloc0_1_0:
      000042                        542 	.ds 2
      000044                        543 _vial_handle_cmd_sloc1_1_0:
      000044                        544 	.ds 2
      000046                        545 _vial_handle_cmd_sloc2_1_0:
      000046                        546 	.ds 2
      000048                        547 _vial_handle_cmd_sloc3_1_0:
      000048                        548 	.ds 2
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 ;--------------------------------------------------------
                                    553 ; indirectly addressable internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area ISEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; absolute internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area IABS    (ABS,DATA)
                                    560 	.area IABS    (ABS,DATA)
                                    561 ;--------------------------------------------------------
                                    562 ; bit data
                                    563 ;--------------------------------------------------------
                                    564 	.area BSEG    (BIT)
                                    565 ;--------------------------------------------------------
                                    566 ; paged external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area PSEG    (PAG,XDATA)
                                    569 ;--------------------------------------------------------
                                    570 ; uninitialized external ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area XSEG    (XDATA)
      000C56                        573 _vial_unlock_timer:
      000C56                        574 	.ds 4
      000C5A                        575 _vial_unlock_holding:
      000C5A                        576 	.ds 1
      000C5B                        577 _vial_keycode_firewall_in_10000_610:
      000C5B                        578 	.ds 2
      000C5D                        579 _vial_fill_packet_PARM_2:
      000C5D                        580 	.ds 1
      000C5E                        581 _vial_fill_packet_msg_10000_613:
      000C5E                        582 	.ds 2
      000C60                        583 _vial_handle_cmd_PARM_2:
      000C60                        584 	.ds 1
      000C61                        585 _vial_handle_cmd_data_10000_618:
      000C61                        586 	.ds 3
      000C64                        587 _vial_handle_cmd_entry_70000_646:
      000C64                        588 	.ds 10
      000C6E                        589 _vial_handle_cmd_entry_70000_647:
      000C6E                        590 	.ds 10
      000C78                        591 _g_vial_magic_keycode_override::
      000C78                        592 	.ds 2
      000C7A                        593 _vial_keycode_down_keycode_10000_649:
      000C7A                        594 	.ds 2
      000C7C                        595 _vial_keycode_down_dummy_event_30000_656:
      000C7C                        596 	.ds 6
      000C82                        597 _vial_keycode_up_keycode_10000_657:
      000C82                        598 	.ds 2
      000C84                        599 _vial_keycode_up_dummy_event_30000_664:
      000C84                        600 	.ds 6
      000C8A                        601 _vial_keycode_tap_keycode_10000_665:
      000C8A                        602 	.ds 2
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
      000E20                        611 _vial_unlocked::
      000E20                        612 	.ds 1
      000E21                        613 _vial_unlock_in_progress::
      000E21                        614 	.ds 1
      000E22                        615 _vial_unlock_counter:
      000E22                        616 	.ds 1
      000E23                        617 _vial_unlock_combo_rows:
      000E23                        618 	.ds 2
      000E25                        619 _vial_unlock_combo_cols:
      000E25                        620 	.ds 2
                                    621 	.area HOME    (CODE)
                                    622 	.area GSINIT0 (CODE)
                                    623 	.area GSINIT1 (CODE)
                                    624 	.area GSINIT2 (CODE)
                                    625 	.area GSINIT3 (CODE)
                                    626 	.area GSINIT4 (CODE)
                                    627 	.area GSINIT5 (CODE)
                                    628 	.area GSINIT  (CODE)
                                    629 	.area GSFINAL (CODE)
                                    630 	.area CSEG    (CODE)
                                    631 ;--------------------------------------------------------
                                    632 ; global & static initialisations
                                    633 ;--------------------------------------------------------
                                    634 	.area HOME    (CODE)
                                    635 	.area GSINIT  (CODE)
                                    636 	.area GSFINAL (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 ;--------------------------------------------------------
                                    639 ; Home
                                    640 ;--------------------------------------------------------
                                    641 	.area HOME    (CODE)
                                    642 	.area HOME    (CODE)
                                    643 ;--------------------------------------------------------
                                    644 ; code
                                    645 ;--------------------------------------------------------
                                    646 	.area CSEG    (CODE)
                                    647 ;------------------------------------------------------------
                                    648 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    649 ;------------------------------------------------------------
                                    650 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_176'
                                    651 ;------------------------------------------------------------
                                    652 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    653 ;	-----------------------------------------
                           000007   654 	ar7 = 0x07
                           000006   655 	ar6 = 0x06
                           000005   656 	ar5 = 0x05
                           000004   657 	ar4 = 0x04
                           000003   658 	ar3 = 0x03
                           000002   659 	ar2 = 0x02
                           000001   660 	ar1 = 0x01
                           000000   661 	ar0 = 0x00
                                    662 ;	 function vial_unlock_task
                                    663 ;	-----------------------------------------
      00AD8D                        664 _vial_unlock_task:
                                    665 ;	quantum/vial.c:64: if (!vial_unlock_in_progress) return;
      00AD8D 90 0E 21         [24]  666 	mov	dptr,#_vial_unlock_in_progress
      00AD90 E0               [24]  667 	movx	a,@dptr
      00AD91 70 01            [24]  668 	jnz	00131$
      00AD93 22               [24]  669 	ret
                                    670 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00AD94                        671 00131$:
      00AD94 7F 00            [12]  672 	mov	r7,#0x00
      00AD96                        673 00115$:
      00AD96 BF 02 00         [24]  674 	cjne	r7,#0x02,00184$
      00AD99                        675 00184$:
      00AD99 50 29            [24]  676 	jnc	00105$
                                    677 ;	quantum/vial.c:66: if (!matrix_is_on(vial_unlock_combo_rows[i], vial_unlock_combo_cols[i])) {
      00AD9B EF               [12]  678 	mov	a,r7
      00AD9C 12 B3 52         [24]  679 	lcall	_ak820_outline_0127
      00AD9F FE               [12]  680 	mov	r6,a
      00ADA0 EF               [12]  681 	mov	a,r7
      00ADA1 12 B3 47         [24]  682 	lcall	_ak820_outline_0126
      00ADA4 90 07 5F         [24]  683 	mov	dptr,#_matrix_is_on_PARM_2
      00ADA7 F0               [24]  684 	movx	@dptr,a
      00ADA8 8E 82            [24]  685 	mov	dpl, r6
      00ADAA C0 07            [24]  686 	push	ar7
      00ADAC 12 59 64         [24]  687 	lcall	_matrix_is_on
      00ADAF E5 82            [12]  688 	mov	a, dpl
      00ADB1 D0 07            [24]  689 	pop	ar7
      00ADB3 70 0C            [24]  690 	jnz	00116$
                                    691 ;	quantum/vial.c:67: vial_unlock_holding = false;
      00ADB5 90 0C 5A         [24]  692 	mov	dptr,#_vial_unlock_holding
      00ADB8 E4               [12]  693 	clr	a
      00ADB9 F0               [24]  694 	movx	@dptr,a
                                    695 ;	quantum/vial.c:68: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00ADBA 90 0E 22         [24]  696 	mov	dptr,#_vial_unlock_counter
      00ADBD 74 1E            [12]  697 	mov	a,#0x1e
      00ADBF F0               [24]  698 	movx	@dptr,a
                                    699 ;	quantum/vial.c:69: return;
      00ADC0 22               [24]  700 	ret
      00ADC1                        701 00116$:
                                    702 ;	quantum/vial.c:65: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00ADC1 0F               [12]  703 	inc	r7
      00ADC2 80 D2            [24]  704 	sjmp	00115$
      00ADC4                        705 00105$:
                                    706 ;	quantum/vial.c:72: if (!vial_unlock_holding) {
      00ADC4 90 0C 5A         [24]  707 	mov	dptr,#_vial_unlock_holding
      00ADC7 E0               [24]  708 	movx	a,@dptr
      00ADC8 70 12            [24]  709 	jnz	00107$
                                    710 ;	quantum/vial.c:73: vial_unlock_holding = true;
      00ADCA 90 0C 5A         [24]  711 	mov	dptr,#_vial_unlock_holding
      00ADCD 74 01            [12]  712 	mov	a,#0x01
      00ADCF F0               [24]  713 	movx	@dptr,a
                                    714 ;	quantum/vial.c:74: vial_unlock_timer = timer_read32();
      00ADD0 12 49 3A         [24]  715 	lcall	_timer_read32
      00ADD3 12 4F 49         [24]  716 	lcall	_ak820_outline_0055
      00ADD6 90 0C 56         [24]  717 	mov	dptr,#_vial_unlock_timer
      00ADD9 12 90 AB         [24]  718 	lcall	_ak820_outline_0006
      00ADDC                        719 00107$:
                                    720 ;	quantum/vial.c:76: uint32_t elapsed = timer_elapsed32(vial_unlock_timer);
      00ADDC 90 0C 56         [24]  721 	mov	dptr,#_vial_unlock_timer
      00ADDF 12 4F 38         [24]  722 	lcall	_ak820_outline_0054
      00ADE2 12 49 93         [24]  723 	lcall	_timer_elapsed32
      00ADE5 12 4F 49         [24]  724 	lcall	_ak820_outline_0055
                                    725 ;	quantum/vial.c:80: while (counter && elapsed >= VIAL_UNLOCK_COUNTER_TICK_MS) {
      00ADE8 7B 1E            [12]  726 	mov	r3,#0x1e
      00ADEA                        727 00109$:
      00ADEA EB               [12]  728 	mov	a,r3
      00ADEB 60 22            [24]  729 	jz	00111$
      00ADED C3               [12]  730 	clr	c
      00ADEE EC               [12]  731 	mov	a,r4
      00ADEF 94 64            [12]  732 	subb	a,#0x64
      00ADF1 ED               [12]  733 	mov	a,r5
      00ADF2 94 00            [12]  734 	subb	a,#0x00
      00ADF4 EE               [12]  735 	mov	a,r6
      00ADF5 94 00            [12]  736 	subb	a,#0x00
      00ADF7 EF               [12]  737 	mov	a,r7
      00ADF8 94 00            [12]  738 	subb	a,#0x00
      00ADFA 40 13            [24]  739 	jc	00111$
                                    740 ;	quantum/vial.c:81: elapsed -= VIAL_UNLOCK_COUNTER_TICK_MS;
      00ADFC EC               [12]  741 	mov	a,r4
      00ADFD 24 9C            [12]  742 	add	a,#0x9c
      00ADFF FC               [12]  743 	mov	r4,a
      00AE00 ED               [12]  744 	mov	a,r5
      00AE01 34 FF            [12]  745 	addc	a,#0xff
      00AE03 FD               [12]  746 	mov	r5,a
      00AE04 EE               [12]  747 	mov	a,r6
      00AE05 34 FF            [12]  748 	addc	a,#0xff
      00AE07 FE               [12]  749 	mov	r6,a
      00AE08 EF               [12]  750 	mov	a,r7
      00AE09 34 FF            [12]  751 	addc	a,#0xff
      00AE0B FF               [12]  752 	mov	r7,a
                                    753 ;	quantum/vial.c:82: --counter;
      00AE0C 1B               [12]  754 	dec	r3
      00AE0D 80 DB            [24]  755 	sjmp	00109$
      00AE0F                        756 00111$:
                                    757 ;	quantum/vial.c:84: vial_unlock_counter = counter;
      00AE0F 90 0E 22         [24]  758 	mov	dptr,#_vial_unlock_counter
      00AE12 EB               [12]  759 	mov	a,r3
      00AE13 F0               [24]  760 	movx	@dptr,a
                                    761 ;	quantum/vial.c:85: if (!counter) {
      00AE14 EB               [12]  762 	mov	a,r3
      00AE15 70 0A            [24]  763 	jnz	00117$
                                    764 ;	quantum/vial.c:86: vial_unlock_in_progress = 0;
      00AE17 90 0E 21         [24]  765 	mov	dptr,#_vial_unlock_in_progress
      00AE1A E4               [12]  766 	clr	a
      00AE1B F0               [24]  767 	movx	@dptr,a
                                    768 ;	quantum/vial.c:87: vial_unlocked = 1;
      00AE1C 90 0E 20         [24]  769 	mov	dptr,#_vial_unlocked
      00AE1F 04               [12]  770 	inc	a
      00AE20 F0               [24]  771 	movx	@dptr,a
      00AE21                        772 00117$:
                                    773 ;	quantum/vial.c:90: }
      00AE21 22               [24]  774 	ret
                                    775 ;------------------------------------------------------------
                                    776 ;Allocation info for local variables in function 'vial_init'
                                    777 ;------------------------------------------------------------
                                    778 ;	quantum/vial.c:108: void vial_init(void) {
                                    779 ;	-----------------------------------------
                                    780 ;	 function vial_init
                                    781 ;	-----------------------------------------
      00AE22                        782 _vial_init:
                                    783 ;	quantum/vial.c:113: reload_combo();
                                    784 ;	quantum/vial.c:118: }
      00AE22 02 35 80         [24]  785 	ljmp	_ak820_combo_reload
                                    786 ;------------------------------------------------------------
                                    787 ;Allocation info for local variables in function 'vial_keycode_firewall'
                                    788 ;------------------------------------------------------------
                                    789 ;in            Allocated with name '_vial_keycode_firewall_in_10000_610'
                                    790 ;------------------------------------------------------------
                                    791 ;	quantum/vial.c:120: __attribute__((unused)) static uint16_t vial_keycode_firewall(uint16_t in) {
                                    792 ;	-----------------------------------------
                                    793 ;	 function vial_keycode_firewall
                                    794 ;	-----------------------------------------
      00AE25                        795 _vial_keycode_firewall:
      00AE25 12 38 88         [24]  796 	lcall	_ak820_outline_0108
      00AE28 90 0C 5B         [24]  797 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00AE2B 12 38 8D         [24]  798 	lcall	_ak820_outline_0109
                                    799 ;	quantum/vial.c:121: if (in == QK_BOOT && !vial_unlocked)
      00AE2E 90 0C 5B         [24]  800 	mov	dptr,#_vial_keycode_firewall_in_10000_610
      00AE31 12 48 55         [24]  801 	lcall	_ak820_outline_0008
      00AE34 BC 00 0D         [24]  802 	cjne	r4,#0x00,00102$
      00AE37 BD 7C 0A         [24]  803 	cjne	r5,#0x7c,00102$
      00AE3A 90 0E 20         [24]  804 	mov	dptr,#_vial_unlocked
      00AE3D E0               [24]  805 	movx	a,@dptr
      00AE3E 70 04            [24]  806 	jnz	00102$
                                    807 ;	quantum/vial.c:122: return 0;
      00AE40 90 00 00         [24]  808 	mov	dptr,#0x0000
      00AE43 22               [24]  809 	ret
      00AE44                        810 00102$:
                                    811 ;	quantum/vial.c:123: return in;
      00AE44 12 38 92         [24]  812 	lcall	_ak820_outline_0119
                                    813 ;	quantum/vial.c:124: }
      00AE47 22               [24]  814 	ret
                                    815 ;------------------------------------------------------------
                                    816 ;Allocation info for local variables in function 'vial_fill_packet'
                                    817 ;------------------------------------------------------------
                                    818 ;value         Allocated with name '_vial_fill_packet_PARM_2'
                                    819 ;msg           Allocated with name '_vial_fill_packet_msg_10000_613'
                                    820 ;i             Allocated with name '_vial_fill_packet_i_20000_615'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/vial.c:127: static void vial_fill_packet(uint8_t __xdata *msg, uint8_t value) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function vial_fill_packet
                                    825 ;	-----------------------------------------
      00AE48                        826 _vial_fill_packet:
      00AE48 12 38 88         [24]  827 	lcall	_ak820_outline_0108
      00AE4B 90 0C 5E         [24]  828 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00AE4E 12 38 8D         [24]  829 	lcall	_ak820_outline_0109
                                    830 ;	quantum/vial.c:128: for (uint8_t i = 0; i < VIAL_RAW_EPSIZE; ++i) msg[i] = value;
      00AE51 90 0C 5E         [24]  831 	mov	dptr,#_vial_fill_packet_msg_10000_613
      00AE54 12 38 41         [24]  832 	lcall	_ak820_outline_0051
      00AE57 90 0C 5D         [24]  833 	mov	dptr,#_vial_fill_packet_PARM_2
      00AE5A E0               [24]  834 	movx	a,@dptr
      00AE5B FD               [12]  835 	mov	r5,a
      00AE5C 7C 00            [12]  836 	mov	r4,#0x00
      00AE5E                        837 00103$:
      00AE5E BC 20 00         [24]  838 	cjne	r4,#0x20,00122$
      00AE61                        839 00122$:
      00AE61 50 09            [24]  840 	jnc	00105$
      00AE63 EC               [12]  841 	mov	a,r4
      00AE64 12 38 31         [24]  842 	lcall	_ak820_outline_0021
      00AE67 ED               [12]  843 	mov	a,r5
      00AE68 F0               [24]  844 	movx	@dptr,a
      00AE69 0C               [12]  845 	inc	r4
      00AE6A 80 F2            [24]  846 	sjmp	00103$
      00AE6C                        847 00105$:
                                    848 ;	quantum/vial.c:129: }
      00AE6C 22               [24]  849 	ret
                                    850 ;------------------------------------------------------------
                                    851 ;Allocation info for local variables in function 'vial_release_held_state'
                                    852 ;------------------------------------------------------------
                                    853 ;	quantum/vial.c:140: static void vial_release_held_state(void) {
                                    854 ;	-----------------------------------------
                                    855 ;	 function vial_release_held_state
                                    856 ;	-----------------------------------------
      00AE6D                        857 _vial_release_held_state:
                                    858 ;	quantum/vial.c:162: repeat_key_cancel();
      00AE6D 12 A2 57         [24]  859 	lcall	_repeat_key_cancel
                                    860 ;	quantum/vial.c:164: clear_keyboard();
                                    861 ;	quantum/vial.c:165: }
      00AE70 02 76 7F         [24]  862 	ljmp	_clear_keyboard
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'vial_handle_cmd'
                                    865 ;------------------------------------------------------------
                                    866 ;sloc0         Allocated with name '_vial_handle_cmd_sloc0_1_0'
                                    867 ;sloc1         Allocated with name '_vial_handle_cmd_sloc1_1_0'
                                    868 ;sloc2         Allocated with name '_vial_handle_cmd_sloc2_1_0'
                                    869 ;sloc3         Allocated with name '_vial_handle_cmd_sloc3_1_0'
                                    870 ;length        Allocated with name '_vial_handle_cmd_PARM_2'
                                    871 ;data          Allocated with name '_vial_handle_cmd_data_10000_618'
                                    872 ;msg           Allocated with name '_vial_handle_cmd_msg_10000_619'
                                    873 ;i             Allocated with name '_vial_handle_cmd_i_50000_624'
                                    874 ;sz            Allocated with name '_vial_handle_cmd_sz_40000_625'
                                    875 ;page          Allocated with name '_vial_handle_cmd_page_40001_628'
                                    876 ;start         Allocated with name '_vial_handle_cmd_start_40002_630'
                                    877 ;remaining     Allocated with name '_vial_handle_cmd_remaining_40002_630'
                                    878 ;count         Allocated with name '_vial_handle_cmd_count_40002_630'
                                    879 ;i             Allocated with name '_vial_handle_cmd_i_50002_631'
                                    880 ;layer         Allocated with name '_vial_handle_cmd_layer_40000_632'
                                    881 ;idx           Allocated with name '_vial_handle_cmd_idx_40000_632'
                                    882 ;keycode       Allocated with name '_vial_handle_cmd_keycode_40000_632'
                                    883 ;i             Allocated with name '_vial_handle_cmd_i_50000_635'
                                    884 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_646'
                                    885 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_646'
                                    886 ;idx           Allocated with name '_vial_handle_cmd_idx_70000_647'
                                    887 ;entry         Allocated with name '_vial_handle_cmd_entry_70000_647'
                                    888 ;------------------------------------------------------------
                                    889 ;	quantum/vial.c:168: void vial_handle_cmd(uint8_t *data, uint8_t length) {
                                    890 ;	-----------------------------------------
                                    891 ;	 function vial_handle_cmd
                                    892 ;	-----------------------------------------
      00AE73                        893 _vial_handle_cmd:
      00AE73 12 43 15         [24]  894 	lcall	_ak820_outline_0037
      00AE76 90 0C 61         [24]  895 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00AE79 12 38 29         [24]  896 	lcall	_ak820_outline_0017
                                    897 ;	quantum/vial.c:172: uint8_t __xdata *msg = (uint8_t __xdata *)data;
      00AE7C 90 0C 61         [24]  898 	mov	dptr,#_vial_handle_cmd_data_10000_618
      00AE7F 12 38 41         [24]  899 	lcall	_ak820_outline_0051
                                    900 ;	quantum/vial.c:177: if (length != VIAL_RAW_EPSIZE)
      00AE82 90 0C 60         [24]  901 	mov	dptr,#_vial_handle_cmd_PARM_2
      00AE85 E0               [24]  902 	movx	a,@dptr
      00AE86 FD               [12]  903 	mov	r5,a
      00AE87 BD 20 02         [24]  904 	cjne	r5,#0x20,00258$
      00AE8A 80 01            [24]  905 	sjmp	00102$
      00AE8C                        906 00258$:
                                    907 ;	quantum/vial.c:178: return;
      00AE8C 22               [24]  908 	ret
      00AE8D                        909 00102$:
                                    910 ;	quantum/vial.c:181: switch (msg[1]) {
      00AE8D 74 01            [12]  911 	mov	a,#0x01
      00AE8F 12 48 9E         [24]  912 	lcall	_ak820_outline_0033
      00AE92 FB               [12]  913 	mov  r3,a
      00AE93 24 F2            [12]  914 	add	a,#0xff - 0x0d
      00AE95 50 01            [24]  915 	jnc	00259$
      00AE97 22               [24]  916 	ret
      00AE98                        917 00259$:
                                    918 ;	free result
      00AE98 EB               [12]  919 	mov	a,r3
      00AE99 24 0A            [12]  920 	add	a,#(00260$-3-.)
      00AE9B 83               [24]  921 	movc	a,@a+pc
      00AE9C F5 82            [12]  922 	mov	dpl,a
      00AE9E EB               [12]  923 	mov	a,r3
      00AE9F 24 12            [12]  924 	add	a,#(00261$-3-.)
      00AEA1 83               [24]  925 	movc	a,@a+pc
      00AEA2 F5 83            [12]  926 	mov	dph,a
      00AEA4 E4               [12]  927 	clr	a
      00AEA5 73               [24]  928 	jmp	@a+dptr
      00AEA6                        929 00260$:
      00AEA6 C2                     930 	.db	00103$
      00AEA7 0A                     931 	.db	00105$
      00AEA8 1E                     932 	.db	00106$
      00AEA9 AA                     933 	.db	00112$
      00AEAA 30                     934 	.db	00113$
      00AEAB 7B                     935 	.db	00114$
      00AEAC EA                     936 	.db	00116$
      00AEAD 05                     937 	.db	00119$
      00AEAE 25                     938 	.db	00120$
      00AEAF 33                     939 	.db	00121$
      00AEB0 33                     940 	.db	00139$
      00AEB1 33                     941 	.db	00139$
      00AEB2 33                     942 	.db	00139$
      00AEB3 3E                     943 	.db	00122$
      00AEB4                        944 00261$:
      00AEB4 AE                     945 	.db	00103$>>8
      00AEB5 AF                     946 	.db	00105$>>8
      00AEB6 AF                     947 	.db	00106$>>8
      00AEB7 AF                     948 	.db	00112$>>8
      00AEB8 B0                     949 	.db	00113$>>8
      00AEB9 B0                     950 	.db	00114$>>8
      00AEBA B0                     951 	.db	00116$>>8
      00AEBB B1                     952 	.db	00119$>>8
      00AEBC B1                     953 	.db	00120$>>8
      00AEBD B1                     954 	.db	00121$>>8
      00AEBE B2                     955 	.db	00139$>>8
      00AEBF B2                     956 	.db	00139$>>8
      00AEC0 B2                     957 	.db	00139$>>8
      00AEC1 B1                     958 	.db	00122$>>8
                                    959 ;	quantum/vial.c:183: case vial_get_keyboard_id: {
      00AEC2                        960 00103$:
                                    961 ;	quantum/vial.c:186: VIAL_FILL_PACKET(msg, 0, length);
      00AEC2 90 0C 5D         [24]  962 	mov	dptr,#_vial_fill_packet_PARM_2
      00AEC5 E4               [12]  963 	clr	a
      00AEC6 12 43 39         [24]  964 	lcall	_ak820_outline_0071
      00AEC9 C0 07            [24]  965 	push	ar7
      00AECB C0 06            [24]  966 	push	ar6
      00AECD 12 AE 48         [24]  967 	lcall	_vial_fill_packet
      00AED0 D0 06            [24]  968 	pop	ar6
      00AED2 D0 07            [24]  969 	pop	ar7
                                    970 ;	quantum/vial.c:187: msg[0] = VIAL_PROTOCOL_VERSION & 0xFF;
      00AED4 12 38 92         [24]  971 	lcall	_ak820_outline_0119
      00AED7 74 06            [12]  972 	mov	a,#0x06
      00AED9 12 43 39         [24]  973 	lcall	_ak820_outline_0071
                                    974 ;	quantum/vial.c:188: msg[1] = (VIAL_PROTOCOL_VERSION >> 8) & 0xFF;
      00AEDC A3               [24]  975 	inc	dptr
      00AEDD E4               [12]  976 	clr	a
      00AEDE 12 43 0D         [24]  977 	lcall	_ak820_outline_0031
                                    978 ;	quantum/vial.c:189: msg[2] = (VIAL_PROTOCOL_VERSION >> 16) & 0xFF;
      00AEE1 12 43 0D         [24]  979 	lcall	_ak820_outline_0031
                                    980 ;	quantum/vial.c:190: msg[3] = (VIAL_PROTOCOL_VERSION >> 24) & 0xFF;
      00AEE4 A3               [24]  981 	inc	dptr
      00AEE5 F0               [24]  982 	movx	@dptr,a
                                    983 ;	quantum/vial.c:191: for (uint8_t i = 0; i < 8; ++i) msg[4 + i] = pgm_read_byte(&keyboard_uid[i]);
      00AEE6 FB               [12]  984 	mov	r3,a
      00AEE7                        985 00131$:
      00AEE7 BB 08 00         [24]  986 	cjne	r3,#0x08,00262$
      00AEEA                        987 00262$:
      00AEEA 50 15            [24]  988 	jnc	00104$
      00AEEC 8B 02            [24]  989 	mov	ar2,r3
      00AEEE 74 04            [12]  990 	mov	a,#0x04
      00AEF0 2A               [12]  991 	add	a, r2
      00AEF1 2E               [12]  992 	add	a, r6
      00AEF2 F9               [12]  993 	mov	r1,a
      00AEF3 E4               [12]  994 	clr	a
      00AEF4 3F               [12]  995 	addc	a,r7
      00AEF5 FA               [12]  996 	mov	r2,a
      00AEF6 EB               [12]  997 	mov	a,r3
      00AEF7 90 BF FF         [24]  998 	mov	dptr,#_vial_handle_cmd_keyboard_uid_40000_623
      00AEFA 93               [24]  999 	movc	a,@a+dptr
      00AEFB 12 6C 55         [24] 1000 	lcall	_ak820_outline_0139
      00AEFE 0B               [12] 1001 	inc	r3
      00AEFF 80 E6            [24] 1002 	sjmp	00131$
      00AF01                       1003 00104$:
                                   1004 ;	quantum/vial.c:193: msg[12] = 1; /* bit flag to indicate vialrgb is supported - so third-party apps don't have to query json */
      00AF01 74 0C            [12] 1005 	mov	a,#0x0c
      00AF03 12 38 31         [24] 1006 	lcall	_ak820_outline_0021
      00AF06 74 01            [12] 1007 	mov	a,#0x01
      00AF08 F0               [24] 1008 	movx	@dptr,a
                                   1009 ;	quantum/vial.c:195: break;
      00AF09 22               [24] 1010 	ret
                                   1011 ;	quantum/vial.c:198: case vial_get_size: {
      00AF0A                       1012 00105$:
                                   1013 ;	quantum/vial.c:200: msg[0] = sz & 0xFF;
      00AF0A 12 38 92         [24] 1014 	lcall	_ak820_outline_0119
      00AF0D 74 7C            [12] 1015 	mov	a,#0x7c
      00AF0F 12 38 76         [24] 1016 	lcall	_ak820_outline_0100
                                   1017 ;	quantum/vial.c:201: msg[1] = (sz >> 8) & 0xFF;
      00AF12 74 01            [12] 1018 	mov	a,#0x01
      00AF14 12 43 0D         [24] 1019 	lcall	_ak820_outline_0031
                                   1020 ;	quantum/vial.c:202: msg[2] = (sz >> 16) & 0xFF;
      00AF17 E4               [12] 1021 	clr	a
      00AF18 12 43 0D         [24] 1022 	lcall	_ak820_outline_0031
                                   1023 ;	quantum/vial.c:203: msg[3] = (sz >> 24) & 0xFF;
      00AF1B A3               [24] 1024 	inc	dptr
      00AF1C F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	quantum/vial.c:204: break;
      00AF1D 22               [24] 1027 	ret
                                   1028 ;	quantum/vial.c:207: case vial_get_def: {
      00AF1E                       1029 00106$:
                                   1030 ;	quantum/vial.c:214: if (msg[4] | msg[5]) return;
      00AF1E 12 AD 58         [24] 1031 	lcall	_ak820_outline_0022
      00AF21 E0               [24] 1032 	movx	a,@dptr
      00AF22 FB               [12] 1033 	mov	r3,a
      00AF23 12 43 03         [24] 1034 	lcall	_ak820_outline_0011
      00AF26 E0               [24] 1035 	movx	a,@dptr
      00AF27 4B               [12] 1036 	orl	a,r3
      00AF28 60 01            [24] 1037 	jz	00108$
      00AF2A 22               [24] 1038 	ret
      00AF2B                       1039 00108$:
                                   1040 ;	quantum/vial.c:215: uint16_t page = (uint16_t)msg[2] | ((uint16_t)msg[3] << 8);
      00AF2B 12 38 39         [24] 1041 	lcall	_ak820_outline_0036
      00AF2E FB               [12] 1042 	mov	r3,a
      00AF2F 7A 00            [12] 1043 	mov	r2,#0x00
      00AF31 12 AD 4F         [24] 1044 	lcall	_ak820_outline_0018
      00AF34 F9               [12] 1045 	mov	r1,a
      00AF35 E4               [12] 1046 	clr	a
      00AF36 42 03            [12] 1047 	orl	ar3,a
      00AF38 E9               [12] 1048 	mov	a,r1
      00AF39 42 02            [12] 1049 	orl	ar2,a
                                   1050 ;	quantum/vial.c:216: if (page >= (sizeof(keyboard_definition) + VIAL_RAW_EPSIZE - 1) / VIAL_RAW_EPSIZE) return;
      00AF3B C3               [12] 1051 	clr	c
      00AF3C EB               [12] 1052 	mov	a,r3
      00AF3D 94 0C            [12] 1053 	subb	a,#0x0c
      00AF3F EA               [12] 1054 	mov	a,r2
      00AF40 94 00            [12] 1055 	subb	a,#0x00
      00AF42 40 01            [24] 1056 	jc	00110$
      00AF44 22               [24] 1057 	ret
      00AF45                       1058 00110$:
                                   1059 ;	quantum/vial.c:217: uint16_t start = page * VIAL_RAW_EPSIZE;
      00AF45 EA               [12] 1060 	mov	a,r2
      00AF46 C4               [12] 1061 	swap	a
      00AF47 23               [12] 1062 	rl	a
      00AF48 54 E0            [12] 1063 	anl	a,#0xe0
      00AF4A CB               [12] 1064 	xch	a,r3
      00AF4B C4               [12] 1065 	swap	a
      00AF4C 23               [12] 1066 	rl	a
      00AF4D CB               [12] 1067 	xch	a,r3
      00AF4E 6B               [12] 1068 	xrl	a,r3
      00AF4F CB               [12] 1069 	xch	a,r3
      00AF50 54 E0            [12] 1070 	anl	a,#0xe0
      00AF52 CB               [12] 1071 	xch	a,r3
      00AF53 6B               [12] 1072 	xrl	a,r3
      00AF54 FA               [12] 1073 	mov	r2,a
      00AF55 8B 42            [24] 1074 	mov	_vial_handle_cmd_sloc0_1_0,r3
      00AF57 8A 43            [24] 1075 	mov	(_vial_handle_cmd_sloc0_1_0 + 1),r2
                                   1076 ;	quantum/vial.c:218: uint16_t remaining = sizeof(keyboard_definition) - start;
      00AF59 74 7C            [12] 1077 	mov	a,#0x7c
      00AF5B C3               [12] 1078 	clr	c
      00AF5C 95 42            [12] 1079 	subb	a,_vial_handle_cmd_sloc0_1_0
      00AF5E F8               [12] 1080 	mov	r0,a
      00AF5F 74 01            [12] 1081 	mov	a,#0x01
      00AF61 95 43            [12] 1082 	subb	a,(_vial_handle_cmd_sloc0_1_0 + 1)
      00AF63 F9               [12] 1083 	mov	r1,a
                                   1084 ;	quantum/vial.c:219: uint8_t count = remaining < VIAL_RAW_EPSIZE ? remaining : VIAL_RAW_EPSIZE;
      00AF64 C3               [12] 1085 	clr	c
      00AF65 E8               [12] 1086 	mov	a,r0
      00AF66 94 20            [12] 1087 	subb	a,#0x20
      00AF68 E9               [12] 1088 	mov	a,r1
      00AF69 94 00            [12] 1089 	subb	a,#0x00
      00AF6B 40 02            [24] 1090 	jc	00142$
      00AF6D 78 20            [12] 1091 	mov	r0,#0x20
      00AF6F                       1092 00142$:
                                   1093 ;	quantum/vial.c:220: for (uint8_t i = 0; i < count; ++i) msg[i] = pgm_read_byte(&keyboard_definition[start + i]);
      00AF6F 79 00            [12] 1094 	mov	r1,#0x00
      00AF71                       1095 00134$:
      00AF71 C3               [12] 1096 	clr	c
      00AF72 E9               [12] 1097 	mov	a,r1
      00AF73 98               [12] 1098 	subb	a,r0
      00AF74 40 01            [24] 1099 	jc	00267$
      00AF76 22               [24] 1100 	ret
      00AF77                       1101 00267$:
      00AF77 C0 00            [24] 1102 	push	ar0
      00AF79 E9               [12] 1103 	mov	a,r1
      00AF7A 2E               [12] 1104 	add	a, r6
      00AF7B F5 44            [12] 1105 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AF7D E4               [12] 1106 	clr	a
      00AF7E 3F               [12] 1107 	addc	a, r7
      00AF7F F5 45            [12] 1108 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AF81 89 46            [24] 1109 	mov	_vial_handle_cmd_sloc2_1_0,r1
      00AF83 75 47 00         [24] 1110 	mov	(_vial_handle_cmd_sloc2_1_0 + 1),#0x00
      00AF86 A8 42            [24] 1111 	mov	r0,_vial_handle_cmd_sloc0_1_0
      00AF88 AB 43            [24] 1112 	mov	r3,(_vial_handle_cmd_sloc0_1_0 + 1)
      00AF8A E5 46            [12] 1113 	mov	a,_vial_handle_cmd_sloc2_1_0
      00AF8C 28               [12] 1114 	add	a, r0
      00AF8D F8               [12] 1115 	mov	r0,a
      00AF8E E5 47            [12] 1116 	mov	a,(_vial_handle_cmd_sloc2_1_0 + 1)
      00AF90 3B               [12] 1117 	addc	a, r3
      00AF91 FB               [12] 1118 	mov	r3,a
      00AF92 E8               [12] 1119 	mov	a,r0
      00AF93 24 83            [12] 1120 	add	a, #_keyboard_definition
      00AF95 F5 82            [12] 1121 	mov	dpl,a
      00AF97 EB               [12] 1122 	mov	a,r3
      00AF98 34 BE            [12] 1123 	addc	a, #(_keyboard_definition >> 8)
      00AF9A F5 83            [12] 1124 	mov	dph,a
      00AF9C E4               [12] 1125 	clr	a
      00AF9D 93               [24] 1126 	movc	a,@a+dptr
      00AF9E 85 44 82         [24] 1127 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AFA1 85 45 83         [24] 1128 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AFA4 F0               [24] 1129 	movx	@dptr,a
      00AFA5 09               [12] 1130 	inc	r1
      00AFA6 D0 00            [24] 1131 	pop	ar0
                                   1132 ;	quantum/vial.c:234: case vial_get_encoder: {
      00AFA8 80 C7            [24] 1133 	sjmp	00134$
      00AFAA                       1134 00112$:
                                   1135 ;	quantum/vial.c:235: uint8_t layer = msg[2];
      00AFAA 74 02            [12] 1136 	mov	a,#0x02
      00AFAC 12 48 93         [24] 1137 	lcall	_ak820_outline_0032
      00AFAF F5 46            [12] 1138 	mov	_vial_handle_cmd_sloc2_1_0,a
                                   1139 ;	quantum/vial.c:236: uint8_t idx = msg[3];
      00AFB1 74 03            [12] 1140 	mov	a,#0x03
      00AFB3 2E               [12] 1141 	add	a, r6
      00AFB4 F5 44            [12] 1142 	mov	_vial_handle_cmd_sloc1_1_0,a
      00AFB6 E4               [12] 1143 	clr	a
      00AFB7 3F               [12] 1144 	addc	a, r7
      00AFB8 F5 45            [12] 1145 	mov	(_vial_handle_cmd_sloc1_1_0 + 1),a
      00AFBA 85 44 82         [24] 1146 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00AFBD 85 45 83         [24] 1147 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00AFC0 E0               [24] 1148 	movx	a,@dptr
                                   1149 ;	quantum/vial.c:237: uint16_t keycode = dynamic_keymap_get_encoder(layer, idx, 0);
      00AFC1 F5 42            [12] 1150 	mov	_vial_handle_cmd_sloc0_1_0,a
      00AFC3 90 0A E5         [24] 1151 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00AFC6 F0               [24] 1152 	movx	@dptr,a
      00AFC7 90 0A E6         [24] 1153 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00AFCA E4               [12] 1154 	clr	a
      00AFCB F0               [24] 1155 	movx	@dptr,a
      00AFCC 85 46 82         [24] 1156 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00AFCF C0 07            [24] 1157 	push	ar7
      00AFD1 C0 06            [24] 1158 	push	ar6
      00AFD3 C0 05            [24] 1159 	push	ar5
      00AFD5 C0 04            [24] 1160 	push	ar4
      00AFD7 C0 03            [24] 1161 	push	ar3
      00AFD9 C0 02            [24] 1162 	push	ar2
      00AFDB 12 85 42         [24] 1163 	lcall	_dynamic_keymap_get_encoder
      00AFDE 85 82 48         [24] 1164 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00AFE1 85 83 49         [24] 1165 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00AFE4 D0 02            [24] 1166 	pop	ar2
      00AFE6 D0 03            [24] 1167 	pop	ar3
      00AFE8 D0 04            [24] 1168 	pop	ar4
      00AFEA D0 05            [24] 1169 	pop	ar5
      00AFEC D0 06            [24] 1170 	pop	ar6
      00AFEE D0 07            [24] 1171 	pop	ar7
                                   1172 ;	quantum/vial.c:238: msg[0]  = keycode >> 8;
      00AFF0 A9 49            [24] 1173 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00AFF2 12 38 92         [24] 1174 	lcall	_ak820_outline_0119
      00AFF5 E9               [12] 1175 	mov	a,r1
      00AFF6 F0               [24] 1176 	movx	@dptr,a
                                   1177 ;	quantum/vial.c:239: msg[1]  = keycode & 0xFF;
      00AFF7 A8 48            [24] 1178 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00AFF9 12 38 97         [24] 1179 	lcall	_ak820_outline_0124
      00AFFC E8               [12] 1180 	mov	a,r0
      00AFFD F0               [24] 1181 	movx	@dptr,a
                                   1182 ;	quantum/vial.c:240: keycode = dynamic_keymap_get_encoder(layer, idx, 1);
      00AFFE 90 0A E5         [24] 1183 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      00B001 E5 42            [12] 1184 	mov	a,_vial_handle_cmd_sloc0_1_0
      00B003 F0               [24] 1185 	movx	@dptr,a
      00B004 90 0A E6         [24] 1186 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      00B007 74 01            [12] 1187 	mov	a,#0x01
      00B009 F0               [24] 1188 	movx	@dptr,a
      00B00A 85 46 82         [24] 1189 	mov	dpl, _vial_handle_cmd_sloc2_1_0
      00B00D C0 03            [24] 1190 	push	ar3
      00B00F C0 02            [24] 1191 	push	ar2
      00B011 12 85 42         [24] 1192 	lcall	_dynamic_keymap_get_encoder
      00B014 85 82 48         [24] 1193 	mov	_vial_handle_cmd_sloc3_1_0,dpl
      00B017 85 83 49         [24] 1194 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),dph
      00B01A D0 02            [24] 1195 	pop	ar2
      00B01C D0 03            [24] 1196 	pop	ar3
                                   1197 ;	quantum/vial.c:241: msg[2] = keycode >> 8;
      00B01E A9 49            [24] 1198 	mov	r1,(_vial_handle_cmd_sloc3_1_0 + 1)
      00B020 12 38 AC         [24] 1199 	lcall	_ak820_outline_0143
      00B023 E9               [12] 1200 	mov	a,r1
      00B024 F0               [24] 1201 	movx	@dptr,a
                                   1202 ;	quantum/vial.c:242: msg[3] = keycode & 0xFF;
      00B025 A8 48            [24] 1203 	mov	r0,_vial_handle_cmd_sloc3_1_0
      00B027 85 44 82         [24] 1204 	mov	dpl,_vial_handle_cmd_sloc1_1_0
      00B02A 85 45 83         [24] 1205 	mov	dph,(_vial_handle_cmd_sloc1_1_0 + 1)
      00B02D E8               [12] 1206 	mov	a,r0
      00B02E F0               [24] 1207 	movx	@dptr,a
                                   1208 ;	quantum/vial.c:243: break;
      00B02F 22               [24] 1209 	ret
                                   1210 ;	quantum/vial.c:245: case vial_set_encoder: {
      00B030                       1211 00113$:
                                   1212 ;	quantum/vial.c:246: dynamic_keymap_set_encoder(msg[2], msg[3], msg[4], vial_keycode_firewall((msg[5] << 8) | msg[6]));
      00B030 12 38 39         [24] 1213 	lcall	_ak820_outline_0036
      00B033 F5 44            [12] 1214 	mov	_vial_handle_cmd_sloc1_1_0,a
      00B035 12 AD 4F         [24] 1215 	lcall	_ak820_outline_0018
      00B038 F5 46            [12] 1216 	mov	_vial_handle_cmd_sloc2_1_0,a
      00B03A 12 AD 58         [24] 1217 	lcall	_ak820_outline_0022
      00B03D E0               [24] 1218 	movx	a,@dptr
                                   1219 ;	assignBit
      00B03E 24 FF            [12] 1220 	add	a,#0xff
      00B040 E4               [12] 1221 	clr	a
      00B041 33               [12] 1222 	rlc	a
      00B042 F5 48            [12] 1223 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B044 12 43 03         [24] 1224 	lcall	_ak820_outline_0011
      00B047 E0               [24] 1225 	movx	a,@dptr
      00B048 F9               [12] 1226 	mov	r1,a
      00B049 78 00            [12] 1227 	mov	r0,#0x00
      00B04B 74 06            [12] 1228 	mov	a,#0x06
      00B04D 12 38 31         [24] 1229 	lcall	_ak820_outline_0021
      00B050 E0               [24] 1230 	movx	a,@dptr
      00B051 7B 00            [12] 1231 	mov	r3,#0x00
      00B053 42 00            [12] 1232 	orl	ar0,a
      00B055 EB               [12] 1233 	mov	a,r3
      00B056 42 01            [12] 1234 	orl	ar1,a
      00B058 12 38 B6         [24] 1235 	lcall	_ak820_outline_0157
      00B05B 12 AE 25         [24] 1236 	lcall	_vial_keycode_firewall
      00B05E AA 82            [24] 1237 	mov	r2, dpl
      00B060 AB 83            [24] 1238 	mov	r3, dph
      00B062 90 0A E8         [24] 1239 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00B065 E5 46            [12] 1240 	mov	a,_vial_handle_cmd_sloc2_1_0
      00B067 F0               [24] 1241 	movx	@dptr,a
      00B068 90 0A E9         [24] 1242 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      00B06B E5 48            [12] 1243 	mov	a,_vial_handle_cmd_sloc3_1_0
      00B06D F0               [24] 1244 	movx	@dptr,a
      00B06E 90 0A EA         [24] 1245 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      00B071 EA               [12] 1246 	mov	a,r2
      00B072 12 77 43         [24] 1247 	lcall	_ak820_outline_0188
      00B075 85 44 82         [24] 1248 	mov	dpl, _vial_handle_cmd_sloc1_1_0
                                   1249 ;	quantum/vial.c:247: break;
      00B078 02 85 AA         [24] 1250 	ljmp	_dynamic_keymap_set_encoder
                                   1251 ;	quantum/vial.c:250: case vial_get_unlock_status: {
      00B07B                       1252 00114$:
                                   1253 ;	quantum/vial.c:252: VIAL_FILL_PACKET(msg, 0xFF, length);
      00B07B 90 0C 5D         [24] 1254 	mov	dptr,#_vial_fill_packet_PARM_2
      00B07E 74 FF            [12] 1255 	mov	a,#0xff
      00B080 12 43 39         [24] 1256 	lcall	_ak820_outline_0071
      00B083 C0 07            [24] 1257 	push	ar7
      00B085 C0 06            [24] 1258 	push	ar6
      00B087 12 AE 48         [24] 1259 	lcall	_vial_fill_packet
      00B08A D0 06            [24] 1260 	pop	ar6
      00B08C D0 07            [24] 1261 	pop	ar7
                                   1262 ;	quantum/vial.c:254: msg[0] = vial_unlocked;
      00B08E 90 0E 20         [24] 1263 	mov	dptr,#_vial_unlocked
      00B091 E0               [24] 1264 	movx	a,@dptr
      00B092 12 38 92         [24] 1265 	lcall	_ak820_outline_0119
      00B095 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/vial.c:256: msg[1] = vial_unlock_in_progress;
      00B096 74 01            [12] 1268 	mov	a,#0x01
      00B098 2E               [12] 1269 	add	a, r6
      00B099 FA               [12] 1270 	mov	r2,a
      00B09A E4               [12] 1271 	clr	a
      00B09B 3F               [12] 1272 	addc	a, r7
      00B09C FB               [12] 1273 	mov	r3,a
      00B09D 90 0E 21         [24] 1274 	mov	dptr,#_vial_unlock_in_progress
      00B0A0 E0               [24] 1275 	movx	a,@dptr
      00B0A1 12 38 AC         [24] 1276 	lcall	_ak820_outline_0143
      00B0A4 F0               [24] 1277 	movx	@dptr,a
                                   1278 ;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B0A5 7B 00            [12] 1279 	mov	r3,#0x00
      00B0A7                       1280 00137$:
      00B0A7 BB 02 00         [24] 1281 	cjne	r3,#0x02,00268$
      00B0AA                       1282 00268$:
      00B0AA 40 01            [24] 1283 	jc	00269$
      00B0AC 22               [24] 1284 	ret
      00B0AD                       1285 00269$:
                                   1286 ;	quantum/vial.c:260: msg[2 + i * 2] = vial_unlock_combo_rows[i];
      00B0AD 8B 01            [24] 1287 	mov	ar1,r3
      00B0AF 7A 00            [12] 1288 	mov	r2,#0x00
      00B0B1 E9               [12] 1289 	mov	a,r1
      00B0B2 29               [12] 1290 	add	a,r1
      00B0B3 F5 48            [12] 1291 	mov	_vial_handle_cmd_sloc3_1_0,a
      00B0B5 EA               [12] 1292 	mov	a,r2
      00B0B6 33               [12] 1293 	rlc	a
      00B0B7 F5 49            [12] 1294 	mov	(_vial_handle_cmd_sloc3_1_0 + 1),a
      00B0B9 74 02            [12] 1295 	mov	a,#0x02
      00B0BB 25 48            [12] 1296 	add	a, _vial_handle_cmd_sloc3_1_0
      00B0BD F8               [12] 1297 	mov	r0,a
      00B0BE E4               [12] 1298 	clr	a
      00B0BF 35 49            [12] 1299 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B0C1 FA               [12] 1300 	mov	r2,a
      00B0C2 E8               [12] 1301 	mov	a,r0
      00B0C3 2E               [12] 1302 	add	a, r6
      00B0C4 F8               [12] 1303 	mov	r0,a
      00B0C5 EA               [12] 1304 	mov	a,r2
      00B0C6 3F               [12] 1305 	addc	a, r7
      00B0C7 FA               [12] 1306 	mov	r2,a
      00B0C8 EB               [12] 1307 	mov	a,r3
      00B0C9 12 B3 52         [24] 1308 	lcall	_ak820_outline_0127
      00B0CC 88 82            [24] 1309 	mov	dpl,r0
      00B0CE 8A 83            [24] 1310 	mov	dph,r2
      00B0D0 F0               [24] 1311 	movx	@dptr,a
                                   1312 ;	quantum/vial.c:261: msg[2 + i * 2 + 1] = vial_unlock_combo_cols[i];
      00B0D1 74 03            [12] 1313 	mov	a,#0x03
      00B0D3 25 48            [12] 1314 	add	a, _vial_handle_cmd_sloc3_1_0
      00B0D5 F9               [12] 1315 	mov	r1,a
      00B0D6 E4               [12] 1316 	clr	a
      00B0D7 35 49            [12] 1317 	addc	a, (_vial_handle_cmd_sloc3_1_0 + 1)
      00B0D9 FA               [12] 1318 	mov	r2,a
      00B0DA E9               [12] 1319 	mov	a,r1
      00B0DB 2E               [12] 1320 	add	a, r6
      00B0DC F9               [12] 1321 	mov	r1,a
      00B0DD EA               [12] 1322 	mov	a,r2
      00B0DE 3F               [12] 1323 	addc	a, r7
      00B0DF FA               [12] 1324 	mov	r2,a
      00B0E0 EB               [12] 1325 	mov	a,r3
      00B0E1 12 B3 47         [24] 1326 	lcall	_ak820_outline_0126
      00B0E4 12 6C 55         [24] 1327 	lcall	_ak820_outline_0139
                                   1328 ;	quantum/vial.c:259: for (uint8_t i = 0; i < VIAL_UNLOCK_NUM_KEYS; ++i) {
      00B0E7 0B               [12] 1329 	inc	r3
                                   1330 ;	quantum/vial.c:266: case vial_unlock_start: {
      00B0E8 80 BD            [24] 1331 	sjmp	00137$
      00B0EA                       1332 00116$:
                                   1333 ;	quantum/vial.c:268: if (!vial_unlock_in_progress) vial_release_held_state();
      00B0EA 90 0E 21         [24] 1334 	mov	dptr,#_vial_unlock_in_progress
      00B0ED E0               [24] 1335 	movx	a,@dptr
      00B0EE 70 03            [24] 1336 	jnz	00118$
      00B0F0 12 AE 6D         [24] 1337 	lcall	_vial_release_held_state
      00B0F3                       1338 00118$:
                                   1339 ;	quantum/vial.c:270: vial_unlock_in_progress = 1;
      00B0F3 90 0E 21         [24] 1340 	mov	dptr,#_vial_unlock_in_progress
      00B0F6 74 01            [12] 1341 	mov	a,#0x01
      00B0F8 F0               [24] 1342 	movx	@dptr,a
                                   1343 ;	quantum/vial.c:271: vial_unlock_counter = VIAL_UNLOCK_COUNTER_MAX;
      00B0F9 90 0E 22         [24] 1344 	mov	dptr,#_vial_unlock_counter
      00B0FC 74 1E            [12] 1345 	mov	a,#0x1e
      00B0FE F0               [24] 1346 	movx	@dptr,a
                                   1347 ;	quantum/vial.c:273: vial_unlock_holding = false;
      00B0FF 90 0C 5A         [24] 1348 	mov	dptr,#_vial_unlock_holding
      00B102 E4               [12] 1349 	clr	a
      00B103 F0               [24] 1350 	movx	@dptr,a
                                   1351 ;	quantum/vial.c:275: break;
      00B104 22               [24] 1352 	ret
                                   1353 ;	quantum/vial.c:277: case vial_unlock_poll: {
      00B105                       1354 00119$:
                                   1355 ;	quantum/vial.c:278: msg[0] = vial_unlocked;
      00B105 90 0E 20         [24] 1356 	mov	dptr,#_vial_unlocked
      00B108 E0               [24] 1357 	movx	a,@dptr
      00B109 12 38 92         [24] 1358 	lcall	_ak820_outline_0119
      00B10C F0               [24] 1359 	movx	@dptr,a
                                   1360 ;	quantum/vial.c:279: msg[1] = vial_unlock_in_progress;
      00B10D 90 0E 21         [24] 1361 	mov	dptr,#_vial_unlock_in_progress
      00B110 E0               [24] 1362 	movx	a,@dptr
      00B111 12 38 97         [24] 1363 	lcall	_ak820_outline_0124
      00B114 F0               [24] 1364 	movx	@dptr,a
                                   1365 ;	quantum/vial.c:280: msg[2] = vial_unlock_counter;
      00B115 74 02            [12] 1366 	mov	a,#0x02
      00B117 2E               [12] 1367 	add	a, r6
      00B118 FA               [12] 1368 	mov	r2,a
      00B119 E4               [12] 1369 	clr	a
      00B11A 3F               [12] 1370 	addc	a, r7
      00B11B FB               [12] 1371 	mov	r3,a
      00B11C 90 0E 22         [24] 1372 	mov	dptr,#_vial_unlock_counter
      00B11F E0               [24] 1373 	movx	a,@dptr
      00B120 12 38 AC         [24] 1374 	lcall	_ak820_outline_0143
      00B123 F0               [24] 1375 	movx	@dptr,a
                                   1376 ;	quantum/vial.c:281: break;
      00B124 22               [24] 1377 	ret
                                   1378 ;	quantum/vial.c:283: case vial_lock: {
      00B125                       1379 00120$:
                                   1380 ;	quantum/vial.c:285: vial_unlocked = 0;
      00B125 90 0E 20         [24] 1381 	mov	dptr,#_vial_unlocked
      00B128 E4               [12] 1382 	clr	a
      00B129 F0               [24] 1383 	movx	@dptr,a
                                   1384 ;	quantum/vial.c:286: vial_unlock_in_progress = 0;
      00B12A 90 0E 21         [24] 1385 	mov	dptr,#_vial_unlock_in_progress
      00B12D F0               [24] 1386 	movx	@dptr,a
                                   1387 ;	quantum/vial.c:287: vial_unlock_holding = false;
      00B12E 90 0C 5A         [24] 1388 	mov	dptr,#_vial_unlock_holding
      00B131 F0               [24] 1389 	movx	@dptr,a
                                   1390 ;	quantum/vial.c:289: break;
      00B132 22               [24] 1391 	ret
                                   1392 ;	quantum/vial.c:291: case vial_qmk_settings_query: {
      00B133                       1393 00121$:
                                   1394 ;	quantum/vial.c:296: VIAL_FILL_PACKET(msg, 0xFF, length); /* indicate that we don't support any qsid */
      00B133 90 0C 5D         [24] 1395 	mov	dptr,#_vial_fill_packet_PARM_2
      00B136 74 FF            [12] 1396 	mov	a,#0xff
      00B138 12 43 39         [24] 1397 	lcall	_ak820_outline_0071
                                   1398 ;	quantum/vial.c:298: break;
      00B13B 02 AE 48         [24] 1399 	ljmp	_vial_fill_packet
                                   1400 ;	quantum/vial.c:318: case vial_dynamic_entry_op: {
      00B13E                       1401 00122$:
                                   1402 ;	quantum/vial.c:319: switch (msg[2]) {
      00B13E 12 38 39         [24] 1403 	lcall	_ak820_outline_0036
      00B141 FB               [12] 1404 	mov	r3,a
      00B142 60 0C            [24] 1405 	jz	00123$
      00B144 BB 03 02         [24] 1406 	cjne	r3,#0x03,00272$
      00B147 80 31            [24] 1407 	sjmp	00124$
      00B149                       1408 00272$:
      00B149 BB 04 03         [24] 1409 	cjne	r3,#0x04,00273$
      00B14C 02 B1 D8         [24] 1410 	ljmp	00125$
      00B14F                       1411 00273$:
      00B14F 22               [24] 1412 	ret
                                   1413 ;	quantum/vial.c:320: case dynamic_vial_get_number_of_entries: {
      00B150                       1414 00123$:
                                   1415 ;	quantum/vial.c:321: VIAL_FILL_PACKET(msg, 0, length);
      00B150 90 0C 5D         [24] 1416 	mov	dptr,#_vial_fill_packet_PARM_2
      00B153 E4               [12] 1417 	clr	a
      00B154 12 43 39         [24] 1418 	lcall	_ak820_outline_0071
      00B157 C0 07            [24] 1419 	push	ar7
      00B159 C0 06            [24] 1420 	push	ar6
      00B15B 12 AE 48         [24] 1421 	lcall	_vial_fill_packet
      00B15E D0 06            [24] 1422 	pop	ar6
      00B160 D0 07            [24] 1423 	pop	ar7
                                   1424 ;	quantum/vial.c:322: msg[0] = VIAL_TAP_DANCE_ENTRIES;
      00B162 12 38 92         [24] 1425 	lcall	_ak820_outline_0119
      00B165 E4               [12] 1426 	clr	a
      00B166 12 43 39         [24] 1427 	lcall	_ak820_outline_0071
                                   1428 ;	quantum/vial.c:323: msg[1] = VIAL_COMBO_ENTRIES;
      00B169 A3               [24] 1429 	inc	dptr
      00B16A 74 08            [12] 1430 	mov	a,#0x08
      00B16C 12 43 0D         [24] 1431 	lcall	_ak820_outline_0031
                                   1432 ;	quantum/vial.c:324: msg[2] = VIAL_KEY_OVERRIDE_ENTRIES;
      00B16F E4               [12] 1433 	clr	a
      00B170 F0               [24] 1434 	movx	@dptr,a
                                   1435 ;	quantum/vial.c:326: msg[VIAL_RAW_EPSIZE - 1] = 1; /* Standard Vial feature bit 0. */
      00B171 74 1F            [12] 1436 	mov	a,#0x1f
      00B173 12 38 31         [24] 1437 	lcall	_ak820_outline_0021
      00B176 74 01            [12] 1438 	mov	a,#0x01
      00B178 F0               [24] 1439 	movx	@dptr,a
                                   1440 ;	quantum/vial.c:328: break;
      00B179 22               [24] 1441 	ret
                                   1442 ;	quantum/vial.c:352: case dynamic_vial_combo_get: {
      00B17A                       1443 00124$:
                                   1444 ;	quantum/vial.c:353: uint8_t idx = msg[3];
      00B17A 12 AD 4F         [24] 1445 	lcall	_ak820_outline_0018
      00B17D FB               [12] 1446 	mov	r3,a
                                   1447 ;	quantum/vial.c:354: vial_combo_entry_t entry = { { 0 }, 0 };
      00B17E 90 0C 64         [24] 1448 	mov	dptr,#_vial_handle_cmd_entry_70000_646
      00B181 12 4F 71         [24] 1449 	lcall	_ak820_outline_0183
      00B184 90 0C 66         [24] 1450 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0002)
      00B187 F0               [24] 1451 	movx	@dptr,a
      00B188 A3               [24] 1452 	inc	dptr
      00B189 F0               [24] 1453 	movx	@dptr,a
      00B18A 90 0C 68         [24] 1454 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0004)
      00B18D F0               [24] 1455 	movx	@dptr,a
      00B18E A3               [24] 1456 	inc	dptr
      00B18F F0               [24] 1457 	movx	@dptr,a
      00B190 90 0C 6A         [24] 1458 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0006)
      00B193 F0               [24] 1459 	movx	@dptr,a
      00B194 A3               [24] 1460 	inc	dptr
      00B195 F0               [24] 1461 	movx	@dptr,a
      00B196 90 0C 6C         [24] 1462 	mov	dptr,#(_vial_handle_cmd_entry_70000_646 + 0x0008)
      00B199 F0               [24] 1463 	movx	@dptr,a
      00B19A A3               [24] 1464 	inc	dptr
      00B19B F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	quantum/vial.c:355: msg[0] = dynamic_keymap_get_combo(idx, &entry);
      00B19C 90 0A ED         [24] 1467 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      00B19F 74 64            [12] 1468 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B1A1 F0               [24] 1469 	movx	@dptr,a
      00B1A2 74 0C            [12] 1470 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B1A4 12 38 70         [24] 1471 	lcall	_ak820_outline_0092
      00B1A7 8B 82            [24] 1472 	mov	dpl, r3
      00B1A9 C0 07            [24] 1473 	push	ar7
      00B1AB C0 06            [24] 1474 	push	ar6
      00B1AD C0 05            [24] 1475 	push	ar5
      00B1AF C0 04            [24] 1476 	push	ar4
      00B1B1 12 86 16         [24] 1477 	lcall	_dynamic_keymap_get_combo
      00B1B4 AA 82            [24] 1478 	mov	r2, dpl
      00B1B6 D0 04            [24] 1479 	pop	ar4
      00B1B8 D0 05            [24] 1480 	pop	ar5
      00B1BA D0 06            [24] 1481 	pop	ar6
      00B1BC D0 07            [24] 1482 	pop	ar7
      00B1BE 12 38 92         [24] 1483 	lcall	_ak820_outline_0119
      00B1C1 EA               [12] 1484 	mov	a,r2
      00B1C2 F0               [24] 1485 	movx	@dptr,a
                                   1486 ;	quantum/vial.c:356: memcpy(&msg[1], &entry, sizeof(entry));
      00B1C3 7B 00            [12] 1487 	mov	r3,#0x00
      00B1C5 90 0D A0         [24] 1488 	mov	dptr,#___memcpy_PARM_2
      00B1C8 74 64            [12] 1489 	mov	a,#_vial_handle_cmd_entry_70000_646
      00B1CA F0               [24] 1490 	movx	@dptr,a
      00B1CB 74 0C            [12] 1491 	mov	a,#(_vial_handle_cmd_entry_70000_646 >> 8)
      00B1CD 12 B3 38         [24] 1492 	lcall	_ak820_outline_0074
      00B1D0 12 38 97         [24] 1493 	lcall	_ak820_outline_0124
      00B1D3 8B F0            [24] 1494 	mov	b, r3
                                   1495 ;	quantum/vial.c:357: break;
      00B1D5 02 B9 05         [24] 1496 	ljmp	___memcpy
                                   1497 ;	quantum/vial.c:359: case dynamic_vial_combo_set: {
      00B1D8                       1498 00125$:
                                   1499 ;	quantum/vial.c:360: uint8_t idx = msg[3];
      00B1D8 12 AD 4F         [24] 1500 	lcall	_ak820_outline_0018
      00B1DB FD               [12] 1501 	mov	r5,a
                                   1502 ;	quantum/vial.c:362: memcpy(&entry, &msg[4], sizeof(entry));
      00B1DC 74 04            [12] 1503 	mov	a,#0x04
      00B1DE 2E               [12] 1504 	add	a, r6
      00B1DF FB               [12] 1505 	mov	r3,a
      00B1E0 E4               [12] 1506 	clr	a
      00B1E1 3F               [12] 1507 	addc	a, r7
      00B1E2 FC               [12] 1508 	mov	r4,a
      00B1E3 90 0D A0         [24] 1509 	mov	dptr,#___memcpy_PARM_2
      00B1E6 EB               [12] 1510 	mov	a,r3
      00B1E7 F0               [24] 1511 	movx	@dptr,a
      00B1E8 EC               [12] 1512 	mov	a,r4
      00B1E9 12 B3 38         [24] 1513 	lcall	_ak820_outline_0074
      00B1EC 90 0C 6E         [24] 1514 	mov	dptr,#_vial_handle_cmd_entry_70000_647
      00B1EF F5 F0            [12] 1515 	mov	b,a
      00B1F1 C0 07            [24] 1516 	push	ar7
      00B1F3 C0 06            [24] 1517 	push	ar6
      00B1F5 C0 05            [24] 1518 	push	ar5
      00B1F7 12 B9 05         [24] 1519 	lcall	___memcpy
                                   1520 ;	quantum/vial.c:363: entry.output = vial_keycode_firewall(entry.output);
      00B1FA 90 0C 76         [24] 1521 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B1FD 12 38 82         [24] 1522 	lcall	_ak820_outline_0104
      00B200 12 33 FC         [24] 1523 	lcall	_ak820_outline_0123
      00B203 12 AE 25         [24] 1524 	lcall	_vial_keycode_firewall
      00B206 AB 82            [24] 1525 	mov	r3, dpl
      00B208 AC 83            [24] 1526 	mov	r4, dph
      00B20A D0 05            [24] 1527 	pop	ar5
      00B20C 90 0C 76         [24] 1528 	mov	dptr,#(_vial_handle_cmd_entry_70000_647 + 0x0008)
      00B20F 12 38 64         [24] 1529 	lcall	_ak820_outline_0083
                                   1530 ;	quantum/vial.c:364: msg[0] = dynamic_keymap_set_combo(idx, &entry);
      00B212 90 0A F1         [24] 1531 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      00B215 74 6E            [12] 1532 	mov	a,#_vial_handle_cmd_entry_70000_647
      00B217 F0               [24] 1533 	movx	@dptr,a
      00B218 74 0C            [12] 1534 	mov	a,#(_vial_handle_cmd_entry_70000_647 >> 8)
      00B21A 12 38 70         [24] 1535 	lcall	_ak820_outline_0092
      00B21D 8D 82            [24] 1536 	mov	dpl, r5
      00B21F 12 86 B6         [24] 1537 	lcall	_dynamic_keymap_set_combo
      00B222 AC 82            [24] 1538 	mov	r4, dpl
      00B224 D0 06            [24] 1539 	pop	ar6
      00B226 D0 07            [24] 1540 	pop	ar7
      00B228 12 38 92         [24] 1541 	lcall	_ak820_outline_0119
      00B22B EC               [12] 1542 	mov	a,r4
      00B22C F0               [24] 1543 	movx	@dptr,a
                                   1544 ;	quantum/vial.c:365: if (!msg[0]) reload_combo();
      00B22D EC               [12] 1545 	mov	a,r4
      00B22E 70 03            [24] 1546 	jnz	00139$
                                   1547 ;	quantum/vial.c:391: }
                                   1548 ;	quantum/vial.c:392: }
      00B230 02 35 80         [24] 1549 	ljmp	_ak820_combo_reload
      00B233                       1550 00139$:
      00B233 22               [24] 1551 	ret
                                   1552 ;------------------------------------------------------------
                                   1553 ;Allocation info for local variables in function 'vial_keycode_down'
                                   1554 ;------------------------------------------------------------
                                   1555 ;keycode       Allocated with name '_vial_keycode_down_keycode_10000_649'
                                   1556 ;dummy_event   Allocated with name '_vial_keycode_down_dummy_event_30000_656'
                                   1557 ;------------------------------------------------------------
                                   1558 ;	quantum/vial.c:396: void vial_keycode_down(uint16_t keycode) {
                                   1559 ;	-----------------------------------------
                                   1560 ;	 function vial_keycode_down
                                   1561 ;	-----------------------------------------
      00B234                       1562 _vial_keycode_down:
      00B234 12 38 88         [24] 1563 	lcall	_ak820_outline_0108
      00B237 90 0C 7A         [24] 1564 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B23A 12 38 8D         [24] 1565 	lcall	_ak820_outline_0109
                                   1566 ;	quantum/vial.c:400: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B23D 90 0C 7A         [24] 1567 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B240 12 48 55         [24] 1568 	lcall	_ak820_outline_0008
      00B243 74 E0            [12] 1569 	mov	a,#0x100 - 0x20
      00B245 2D               [12] 1570 	add	a,r5
      00B246 50 19            [24] 1571 	jnc	00104$
      00B248 C3               [12] 1572 	clr	c
      00B249 74 FF            [12] 1573 	mov	a,#0xff
      00B24B 9C               [12] 1574 	subb	a,r4
      00B24C 74 4F            [12] 1575 	mov	a,#0x4f
      00B24E 9D               [12] 1576 	subb	a,r5
      00B24F 40 10            [24] 1577 	jc	00104$
                                   1578 ;	free result
                                   1579 ;	quantum/vial.c:401: keycode = (uint8_t)keycode;
      00B251 90 0C 7A         [24] 1580 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B254 EE               [12] 1581 	mov	a,r6
      00B255 12 38 A1         [24] 1582 	lcall	_ak820_outline_0135
                                   1583 ;	quantum/vial.c:402: if (keycode <= KC_TRANSPARENT) return;
      00B258 90 0C 7A         [24] 1584 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B25B E0               [24] 1585 	movx	a,@dptr
      00B25C 24 FE            [12] 1586 	add	a,#0xff - 0x01
      00B25E 40 01            [24] 1587 	jc	00104$
                                   1588 ;	free result
      00B260 22               [24] 1589 	ret
      00B261                       1590 00104$:
                                   1591 ;	quantum/vial.c:405: g_vial_magic_keycode_override = keycode;
      00B261 90 0C 7A         [24] 1592 	mov	dptr,#_vial_keycode_down_keycode_10000_649
      00B264 12 B3 1F         [24] 1593 	lcall	_ak820_outline_0024
                                   1594 ;	quantum/vial.c:407: if (keycode <= QK_MODS_MAX) {
      00B267 40 06            [24] 1595 	jc	00107$
                                   1596 ;	free result
                                   1597 ;	quantum/vial.c:408: register_code16(keycode);
      00B269 12 38 92         [24] 1598 	lcall	_ak820_outline_0119
      00B26C 02 9D E3         [24] 1599 	ljmp	_register_code16
      00B26F                       1600 00107$:
                                   1601 ;	quantum/vial.c:410: keyevent_t dummy_event = {
      00B26F 90 0C 80         [24] 1602 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0004)
      00B272 74 01            [12] 1603 	mov	a,#0x01
      00B274 F0               [24] 1604 	movx	@dptr,a
      00B275 90 0C 7D         [24] 1605 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0001)
      00B278 74 F0            [12] 1606 	mov	a,#0xf0
      00B27A F0               [24] 1607 	movx	@dptr,a
      00B27B 90 0C 7C         [24] 1608 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
      00B27E F0               [24] 1609 	movx	@dptr,a
      00B27F 90 0C 81         [24] 1610 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0005)
      00B282 74 01            [12] 1611 	mov	a,#0x01
      00B284 F0               [24] 1612 	movx	@dptr,a
      00B285 12 49 6B         [24] 1613 	lcall	_timer_read
      00B288 12 43 57         [24] 1614 	lcall	_ak820_outline_0134
      00B28B 43 06 01         [24] 1615 	orl	ar6,#0x01
      00B28E 90 0C 7E         [24] 1616 	mov	dptr,#(_vial_keycode_down_dummy_event_30000_656 + 0x0002)
      00B291 12 48 B1         [24] 1617 	lcall	_ak820_outline_0058
                                   1618 ;	quantum/vial.c:414: AK820_ACTION_EXEC(dummy_event);
      00B294 90 0C 7C         [24] 1619 	mov	dptr,#_vial_keycode_down_dummy_event_30000_656
                                   1620 ;	quantum/vial.c:416: }
      00B297 02 70 94         [24] 1621 	ljmp	_ak820_action_exec
                                   1622 ;------------------------------------------------------------
                                   1623 ;Allocation info for local variables in function 'vial_keycode_up'
                                   1624 ;------------------------------------------------------------
                                   1625 ;keycode       Allocated with name '_vial_keycode_up_keycode_10000_657'
                                   1626 ;dummy_event   Allocated with name '_vial_keycode_up_dummy_event_30000_664'
                                   1627 ;------------------------------------------------------------
                                   1628 ;	quantum/vial.c:418: void vial_keycode_up(uint16_t keycode) {
                                   1629 ;	-----------------------------------------
                                   1630 ;	 function vial_keycode_up
                                   1631 ;	-----------------------------------------
      00B29A                       1632 _vial_keycode_up:
      00B29A 12 38 88         [24] 1633 	lcall	_ak820_outline_0108
      00B29D 90 0C 82         [24] 1634 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B2A0 12 38 8D         [24] 1635 	lcall	_ak820_outline_0109
                                   1636 ;	quantum/vial.c:422: if (keycode >= QK_MOD_TAP && keycode <= QK_LAYER_TAP_MAX) {
      00B2A3 90 0C 82         [24] 1637 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B2A6 12 48 55         [24] 1638 	lcall	_ak820_outline_0008
      00B2A9 74 E0            [12] 1639 	mov	a,#0x100 - 0x20
      00B2AB 2D               [12] 1640 	add	a,r5
      00B2AC 50 19            [24] 1641 	jnc	00104$
      00B2AE C3               [12] 1642 	clr	c
      00B2AF 74 FF            [12] 1643 	mov	a,#0xff
      00B2B1 9C               [12] 1644 	subb	a,r4
      00B2B2 74 4F            [12] 1645 	mov	a,#0x4f
      00B2B4 9D               [12] 1646 	subb	a,r5
      00B2B5 40 10            [24] 1647 	jc	00104$
                                   1648 ;	free result
                                   1649 ;	quantum/vial.c:423: keycode = (uint8_t)keycode;
      00B2B7 90 0C 82         [24] 1650 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B2BA EE               [12] 1651 	mov	a,r6
      00B2BB 12 38 A1         [24] 1652 	lcall	_ak820_outline_0135
                                   1653 ;	quantum/vial.c:424: if (keycode <= KC_TRANSPARENT) return;
      00B2BE 90 0C 82         [24] 1654 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B2C1 E0               [24] 1655 	movx	a,@dptr
      00B2C2 24 FE            [12] 1656 	add	a,#0xff - 0x01
      00B2C4 40 01            [24] 1657 	jc	00104$
                                   1658 ;	free result
      00B2C6 22               [24] 1659 	ret
      00B2C7                       1660 00104$:
                                   1661 ;	quantum/vial.c:427: g_vial_magic_keycode_override = keycode;
      00B2C7 90 0C 82         [24] 1662 	mov	dptr,#_vial_keycode_up_keycode_10000_657
      00B2CA 12 B3 1F         [24] 1663 	lcall	_ak820_outline_0024
                                   1664 ;	quantum/vial.c:429: if (keycode <= QK_MODS_MAX) {
      00B2CD 40 06            [24] 1665 	jc	00107$
                                   1666 ;	free result
                                   1667 ;	quantum/vial.c:430: unregister_code16(keycode);
      00B2CF 12 38 92         [24] 1668 	lcall	_ak820_outline_0119
      00B2D2 02 9E 28         [24] 1669 	ljmp	_unregister_code16
      00B2D5                       1670 00107$:
                                   1671 ;	quantum/vial.c:432: keyevent_t dummy_event = {
      00B2D5 90 0C 88         [24] 1672 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0004)
      00B2D8 74 01            [12] 1673 	mov	a,#0x01
      00B2DA F0               [24] 1674 	movx	@dptr,a
      00B2DB 90 0C 85         [24] 1675 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0001)
      00B2DE 74 F0            [12] 1676 	mov	a,#0xf0
      00B2E0 F0               [24] 1677 	movx	@dptr,a
      00B2E1 90 0C 84         [24] 1678 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
      00B2E4 F0               [24] 1679 	movx	@dptr,a
      00B2E5 90 0C 89         [24] 1680 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0005)
      00B2E8 E4               [12] 1681 	clr	a
      00B2E9 F0               [24] 1682 	movx	@dptr,a
      00B2EA 12 49 6B         [24] 1683 	lcall	_timer_read
      00B2ED 12 43 57         [24] 1684 	lcall	_ak820_outline_0134
      00B2F0 43 06 01         [24] 1685 	orl	ar6,#0x01
      00B2F3 90 0C 86         [24] 1686 	mov	dptr,#(_vial_keycode_up_dummy_event_30000_664 + 0x0002)
      00B2F6 12 48 B1         [24] 1687 	lcall	_ak820_outline_0058
                                   1688 ;	quantum/vial.c:436: AK820_ACTION_EXEC(dummy_event);
      00B2F9 90 0C 84         [24] 1689 	mov	dptr,#_vial_keycode_up_dummy_event_30000_664
                                   1690 ;	quantum/vial.c:438: }
      00B2FC 02 70 94         [24] 1691 	ljmp	_ak820_action_exec
                                   1692 ;------------------------------------------------------------
                                   1693 ;Allocation info for local variables in function 'vial_keycode_tap'
                                   1694 ;------------------------------------------------------------
                                   1695 ;keycode       Allocated with name '_vial_keycode_tap_keycode_10000_665'
                                   1696 ;i             Allocated with name '_vial_keycode_tap_i_30000_668'
                                   1697 ;------------------------------------------------------------
                                   1698 ;	quantum/vial.c:440: void vial_keycode_tap(uint16_t keycode) {
                                   1699 ;	-----------------------------------------
                                   1700 ;	 function vial_keycode_tap
                                   1701 ;	-----------------------------------------
      00B2FF                       1702 _vial_keycode_tap:
      00B2FF 12 38 88         [24] 1703 	lcall	_ak820_outline_0108
      00B302 90 0C 8A         [24] 1704 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B305 12 38 8D         [24] 1705 	lcall	_ak820_outline_0109
                                   1706 ;	quantum/vial.c:441: vial_keycode_down(keycode);
      00B308 90 0C 8A         [24] 1707 	mov	dptr,#_vial_keycode_tap_keycode_10000_665
      00B30B 12 37 F4         [24] 1708 	lcall	_ak820_outline_0005
      00B30E C0 07            [24] 1709 	push	ar7
      00B310 C0 06            [24] 1710 	push	ar6
      00B312 12 B2 34         [24] 1711 	lcall	_vial_keycode_down
      00B315 D0 06            [24] 1712 	pop	ar6
      00B317 D0 07            [24] 1713 	pop	ar7
                                   1714 ;	quantum/vial.c:443: vial_keycode_up(keycode);
      00B319 12 38 92         [24] 1715 	lcall	_ak820_outline_0119
                                   1716 ;	quantum/vial.c:444: }
      00B31C 02 B2 9A         [24] 1717 	ljmp	_vial_keycode_up
                                   1718 ;------------------------------------------------------------
                                   1719 ;Allocation info for local variables in function 'process_record_vial'
                                   1720 ;------------------------------------------------------------
                                   1721 ;record        Allocated with name '_process_record_vial_PARM_2'
                                   1722 ;keycode       Allocated with name '_process_record_vial_keycode_10000_670'
                                   1723 ;------------------------------------------------------------
                                   1724 ;	quantum/vial.c:654: bool process_record_vial(uint16_t keycode, keyrecord_t *record) {
                                   1725 ;	-----------------------------------------
                                   1726 	.area CSEG    (CODE)
                                   1727 	.area CONST   (CODE)
                                   1728 	.area CONST   (CODE)
      00BE83                       1729 _keyboard_definition:
      00BE83 FD                    1730 	.db #0xfd	; 253
      00BE84 37                    1731 	.db #0x37	; 55	'7'
      00BE85 7A                    1732 	.db #0x7a	; 122	'z'
      00BE86 58                    1733 	.db #0x58	; 88	'X'
      00BE87 5A                    1734 	.db #0x5a	; 90	'Z'
      00BE88 00                    1735 	.db #0x00	; 0
      00BE89 00                    1736 	.db #0x00	; 0
      00BE8A 04                    1737 	.db #0x04	; 4
      00BE8B E6                    1738 	.db #0xe6	; 230
      00BE8C D6                    1739 	.db #0xd6	; 214
      00BE8D B4                    1740 	.db #0xb4	; 180
      00BE8E 46                    1741 	.db #0x46	; 70	'F'
      00BE8F 02                    1742 	.db #0x02	; 2
      00BE90 00                    1743 	.db #0x00	; 0
      00BE91 21                    1744 	.db #0x21	; 33
      00BE92 01                    1745 	.db #0x01	; 1
      00BE93 00                    1746 	.db #0x00	; 0
      00BE94 00                    1747 	.db #0x00	; 0
      00BE95 00                    1748 	.db #0x00	; 0
      00BE96 00                    1749 	.db #0x00	; 0
      00BE97 37                    1750 	.db #0x37	; 55	'7'
      00BE98 27                    1751 	.db #0x27	; 39
      00BE99 97                    1752 	.db #0x97	; 151
      00BE9A D6                    1753 	.db #0xd6	; 214
      00BE9B E0                    1754 	.db #0xe0	; 224
      00BE9C 03                    1755 	.db #0x03	; 3
      00BE9D CB                    1756 	.db #0xcb	; 203
      00BE9E 01                    1757 	.db #0x01	; 1
      00BE9F 3C                    1758 	.db #0x3c	; 60
      00BEA0 00                    1759 	.db #0x00	; 0
      00BEA1 00                    1760 	.db #0x00	; 0
      00BEA2 3D                    1761 	.db #0x3d	; 61
      00BEA3 88                    1762 	.db #0x88	; 136
      00BEA4 CD                    1763 	.db #0xcd	; 205
      00BEA5 A5                    1764 	.db #0xa5	; 165
      00BEA6 AA                    1765 	.db #0xaa	; 170
      00BEA7 E5                    1766 	.db #0xe5	; 229
      00BEA8 A8                    1767 	.db #0xa8	; 168
      00BEA9 76                    1768 	.db #0x76	; 118	'v'
      00BEAA F6                    1769 	.db #0xf6	; 246
      00BEAB 43                    1770 	.db #0x43	; 67	'C'
      00BEAC 0E                    1771 	.db #0x0e	; 14
      00BEAD D2                    1772 	.db #0xd2	; 210
      00BEAE 90                    1773 	.db #0x90	; 144
      00BEAF 7D                    1774 	.db #0x7d	; 125
      00BEB0 94                    1775 	.db #0x94	; 148
      00BEB1 79                    1776 	.db #0x79	; 121	'y'
      00BEB2 78                    1777 	.db #0x78	; 120	'x'
      00BEB3 EF                    1778 	.db #0xef	; 239
      00BEB4 49                    1779 	.db #0x49	; 73	'I'
      00BEB5 3E                    1780 	.db #0x3e	; 62
      00BEB6 EF                    1781 	.db #0xef	; 239
      00BEB7 FD                    1782 	.db #0xfd	; 253
      00BEB8 8F                    1783 	.db #0x8f	; 143
      00BEB9 EF                    1784 	.db #0xef	; 239
      00BEBA 00                    1785 	.db #0x00	; 0
      00BEBB C6                    1786 	.db #0xc6	; 198
      00BEBC D1                    1787 	.db #0xd1	; 209
      00BEBD DB                    1788 	.db #0xdb	; 219
      00BEBE FB                    1789 	.db #0xfb	; 251
      00BEBF EB                    1790 	.db #0xeb	; 235
      00BEC0 DE                    1791 	.db #0xde	; 222
      00BEC1 66                    1792 	.db #0x66	; 102	'f'
      00BEC2 63                    1793 	.db #0x63	; 99	'c'
      00BEC3 0C                    1794 	.db #0x0c	; 12
      00BEC4 92                    1795 	.db #0x92	; 146
      00BEC5 7B                    1796 	.db #0x7b	; 123
      00BEC6 F9                    1797 	.db #0xf9	; 249
      00BEC7 D4                    1798 	.db #0xd4	; 212
      00BEC8 7A                    1799 	.db #0x7a	; 122	'z'
      00BEC9 4F                    1800 	.db #0x4f	; 79	'O'
      00BECA 83                    1801 	.db #0x83	; 131
      00BECB 4B                    1802 	.db #0x4b	; 75	'K'
      00BECC 86                    1803 	.db #0x86	; 134
      00BECD 0E                    1804 	.db #0x0e	; 14
      00BECE 6A                    1805 	.db #0x6a	; 106	'j'
      00BECF F2                    1806 	.db #0xf2	; 242
      00BED0 22                    1807 	.db #0x22	; 34
      00BED1 22                    1808 	.db #0x22	; 34
      00BED2 0B                    1809 	.db #0x0b	; 11
      00BED3 03                    1810 	.db #0x03	; 3
      00BED4 BA                    1811 	.db #0xba	; 186
      00BED5 67                    1812 	.db #0x67	; 103	'g'
      00BED6 9B                    1813 	.db #0x9b	; 155
      00BED7 7A                    1814 	.db #0x7a	; 122	'z'
      00BED8 E1                    1815 	.db #0xe1	; 225
      00BED9 BC                    1816 	.db #0xbc	; 188
      00BEDA 37                    1817 	.db #0x37	; 55	'7'
      00BEDB 26                    1818 	.db #0x26	; 38
      00BEDC 46                    1819 	.db #0x46	; 70	'F'
      00BEDD 78                    1820 	.db #0x78	; 120	'x'
      00BEDE 05                    1821 	.db #0x05	; 5
      00BEDF 0D                    1822 	.db #0x0d	; 13
      00BEE0 95                    1823 	.db #0x95	; 149
      00BEE1 02                    1824 	.db #0x02	; 2
      00BEE2 E4                    1825 	.db #0xe4	; 228
      00BEE3 18                    1826 	.db #0x18	; 24
      00BEE4 CA                    1827 	.db #0xca	; 202
      00BEE5 33                    1828 	.db #0x33	; 51	'3'
      00BEE6 EA                    1829 	.db #0xea	; 234
      00BEE7 24                    1830 	.db #0x24	; 36
      00BEE8 C8                    1831 	.db #0xc8	; 200
      00BEE9 81                    1832 	.db #0x81	; 129
      00BEEA 4E                    1833 	.db #0x4e	; 78	'N'
      00BEEB 47                    1834 	.db #0x47	; 71	'G'
      00BEEC A8                    1835 	.db #0xa8	; 168
      00BEED 44                    1836 	.db #0x44	; 68	'D'
      00BEEE DD                    1837 	.db #0xdd	; 221
      00BEEF 91                    1838 	.db #0x91	; 145
      00BEF0 6D                    1839 	.db #0x6d	; 109	'm'
      00BEF1 69                    1840 	.db #0x69	; 105	'i'
      00BEF2 DB                    1841 	.db #0xdb	; 219
      00BEF3 4F                    1842 	.db #0x4f	; 79	'O'
      00BEF4 3A                    1843 	.db #0x3a	; 58
      00BEF5 43                    1844 	.db #0x43	; 67	'C'
      00BEF6 9D                    1845 	.db #0x9d	; 157
      00BEF7 26                    1846 	.db #0x26	; 38
      00BEF8 49                    1847 	.db #0x49	; 73	'I'
      00BEF9 4C                    1848 	.db #0x4c	; 76	'L'
      00BEFA EF                    1849 	.db #0xef	; 239
      00BEFB 2B                    1850 	.db #0x2b	; 43
      00BEFC D8                    1851 	.db #0xd8	; 216
      00BEFD 55                    1852 	.db #0x55	; 85	'U'
      00BEFE 95                    1853 	.db #0x95	; 149
      00BEFF 70                    1854 	.db #0x70	; 112	'p'
      00BF00 B1                    1855 	.db #0xb1	; 177
      00BF01 CC                    1856 	.db #0xcc	; 204
      00BF02 CF                    1857 	.db #0xcf	; 207
      00BF03 13                    1858 	.db #0x13	; 19
      00BF04 32                    1859 	.db #0x32	; 50	'2'
      00BF05 6A                    1860 	.db #0x6a	; 106	'j'
      00BF06 A1                    1861 	.db #0xa1	; 161
      00BF07 FF                    1862 	.db #0xff	; 255
      00BF08 99                    1863 	.db #0x99	; 153
      00BF09 61                    1864 	.db #0x61	; 97	'a'
      00BF0A 95                    1865 	.db #0x95	; 149
      00BF0B B1                    1866 	.db #0xb1	; 177
      00BF0C 89                    1867 	.db #0x89	; 137
      00BF0D 9B                    1868 	.db #0x9b	; 155
      00BF0E 11                    1869 	.db #0x11	; 17
      00BF0F D9                    1870 	.db #0xd9	; 217
      00BF10 35                    1871 	.db #0x35	; 53	'5'
      00BF11 78                    1872 	.db #0x78	; 120	'x'
      00BF12 ED                    1873 	.db #0xed	; 237
      00BF13 CD                    1874 	.db #0xcd	; 205
      00BF14 94                    1875 	.db #0x94	; 148
      00BF15 6E                    1876 	.db #0x6e	; 110	'n'
      00BF16 60                    1877 	.db #0x60	; 96
      00BF17 8E                    1878 	.db #0x8e	; 142
      00BF18 63                    1879 	.db #0x63	; 99	'c'
      00BF19 8B                    1880 	.db #0x8b	; 139
      00BF1A FF                    1881 	.db #0xff	; 255
      00BF1B 4E                    1882 	.db #0x4e	; 78	'N'
      00BF1C 20                    1883 	.db #0x20	; 32
      00BF1D 7A                    1884 	.db #0x7a	; 122	'z'
      00BF1E B5                    1885 	.db #0xb5	; 181
      00BF1F 87                    1886 	.db #0x87	; 135
      00BF20 C2                    1887 	.db #0xc2	; 194
      00BF21 35                    1888 	.db #0x35	; 53	'5'
      00BF22 A4                    1889 	.db #0xa4	; 164
      00BF23 6D                    1890 	.db #0x6d	; 109	'm'
      00BF24 18                    1891 	.db #0x18	; 24
      00BF25 C1                    1892 	.db #0xc1	; 193
      00BF26 A3                    1893 	.db #0xa3	; 163
      00BF27 DB                    1894 	.db #0xdb	; 219
      00BF28 53                    1895 	.db #0x53	; 83	'S'
      00BF29 1D                    1896 	.db #0x1d	; 29
      00BF2A EC                    1897 	.db #0xec	; 236
      00BF2B F0                    1898 	.db #0xf0	; 240
      00BF2C BF                    1899 	.db #0xbf	; 191
      00BF2D 4A                    1900 	.db #0x4a	; 74	'J'
      00BF2E 4C                    1901 	.db #0x4c	; 76	'L'
      00BF2F 4A                    1902 	.db #0x4a	; 74	'J'
      00BF30 C4                    1903 	.db #0xc4	; 196
      00BF31 AA                    1904 	.db #0xaa	; 170
      00BF32 37                    1905 	.db #0x37	; 55	'7'
      00BF33 19                    1906 	.db #0x19	; 25
      00BF34 34                    1907 	.db #0x34	; 52	'4'
      00BF35 3F                    1908 	.db #0x3f	; 63
      00BF36 A1                    1909 	.db #0xa1	; 161
      00BF37 D3                    1910 	.db #0xd3	; 211
      00BF38 1A                    1911 	.db #0x1a	; 26
      00BF39 5C                    1912 	.db #0x5c	; 92
      00BF3A 03                    1913 	.db #0x03	; 3
      00BF3B 4D                    1914 	.db #0x4d	; 77	'M'
      00BF3C BC                    1915 	.db #0xbc	; 188
      00BF3D 10                    1916 	.db #0x10	; 16
      00BF3E 2E                    1917 	.db #0x2e	; 46
      00BF3F 80                    1918 	.db #0x80	; 128
      00BF40 F7                    1919 	.db #0xf7	; 247
      00BF41 D6                    1920 	.db #0xd6	; 214
      00BF42 82                    1921 	.db #0x82	; 130
      00BF43 24                    1922 	.db #0x24	; 36
      00BF44 4C                    1923 	.db #0x4c	; 76	'L'
      00BF45 87                    1924 	.db #0x87	; 135
      00BF46 B9                    1925 	.db #0xb9	; 185
      00BF47 F8                    1926 	.db #0xf8	; 248
      00BF48 BE                    1927 	.db #0xbe	; 190
      00BF49 67                    1928 	.db #0x67	; 103	'g'
      00BF4A 96                    1929 	.db #0x96	; 150
      00BF4B 89                    1930 	.db #0x89	; 137
      00BF4C 30                    1931 	.db #0x30	; 48	'0'
      00BF4D C8                    1932 	.db #0xc8	; 200
      00BF4E 8D                    1933 	.db #0x8d	; 141
      00BF4F 2C                    1934 	.db #0x2c	; 44
      00BF50 F5                    1935 	.db #0xf5	; 245
      00BF51 06                    1936 	.db #0x06	; 6
      00BF52 05                    1937 	.db #0x05	; 5
      00BF53 7C                    1938 	.db #0x7c	; 124
      00BF54 48                    1939 	.db #0x48	; 72	'H'
      00BF55 1B                    1940 	.db #0x1b	; 27
      00BF56 76                    1941 	.db #0x76	; 118	'v'
      00BF57 AA                    1942 	.db #0xaa	; 170
      00BF58 3D                    1943 	.db #0x3d	; 61
      00BF59 28                    1944 	.db #0x28	; 40
      00BF5A FC                    1945 	.db #0xfc	; 252
      00BF5B 80                    1946 	.db #0x80	; 128
      00BF5C 75                    1947 	.db #0x75	; 117	'u'
      00BF5D EB                    1948 	.db #0xeb	; 235
      00BF5E 78                    1949 	.db #0x78	; 120	'x'
      00BF5F D0                    1950 	.db #0xd0	; 208
      00BF60 8A                    1951 	.db #0x8a	; 138
      00BF61 8F                    1952 	.db #0x8f	; 143
      00BF62 27                    1953 	.db #0x27	; 39
      00BF63 F7                    1954 	.db #0xf7	; 247
      00BF64 F2                    1955 	.db #0xf2	; 242
      00BF65 EB                    1956 	.db #0xeb	; 235
      00BF66 58                    1957 	.db #0x58	; 88	'X'
      00BF67 37                    1958 	.db #0x37	; 55	'7'
      00BF68 3C                    1959 	.db #0x3c	; 60
      00BF69 2B                    1960 	.db #0x2b	; 43
      00BF6A 6F                    1961 	.db #0x6f	; 111	'o'
      00BF6B 0E                    1962 	.db #0x0e	; 14
      00BF6C C7                    1963 	.db #0xc7	; 199
      00BF6D E2                    1964 	.db #0xe2	; 226
      00BF6E A0                    1965 	.db #0xa0	; 160
      00BF6F 97                    1966 	.db #0x97	; 151
      00BF70 EE                    1967 	.db #0xee	; 238
      00BF71 FD                    1968 	.db #0xfd	; 253
      00BF72 9F                    1969 	.db #0x9f	; 159
      00BF73 45                    1970 	.db #0x45	; 69	'E'
      00BF74 17                    1971 	.db #0x17	; 23
      00BF75 94                    1972 	.db #0x94	; 148
      00BF76 E6                    1973 	.db #0xe6	; 230
      00BF77 E7                    1974 	.db #0xe7	; 231
      00BF78 FA                    1975 	.db #0xfa	; 250
      00BF79 4C                    1976 	.db #0x4c	; 76	'L'
      00BF7A 7A                    1977 	.db #0x7a	; 122	'z'
      00BF7B D6                    1978 	.db #0xd6	; 214
      00BF7C 7A                    1979 	.db #0x7a	; 122	'z'
      00BF7D 7B                    1980 	.db #0x7b	; 123
      00BF7E ED                    1981 	.db #0xed	; 237
      00BF7F 10                    1982 	.db #0x10	; 16
      00BF80 C5                    1983 	.db #0xc5	; 197
      00BF81 BC                    1984 	.db #0xbc	; 188
      00BF82 E3                    1985 	.db #0xe3	; 227
      00BF83 A9                    1986 	.db #0xa9	; 169
      00BF84 1F                    1987 	.db #0x1f	; 31
      00BF85 CF                    1988 	.db #0xcf	; 207
      00BF86 C4                    1989 	.db #0xc4	; 196
      00BF87 9D                    1990 	.db #0x9d	; 157
      00BF88 DC                    1991 	.db #0xdc	; 220
      00BF89 45                    1992 	.db #0x45	; 69	'E'
      00BF8A 2A                    1993 	.db #0x2a	; 42
      00BF8B 69                    1994 	.db #0x69	; 105	'i'
      00BF8C 57                    1995 	.db #0x57	; 87	'W'
      00BF8D 8F                    1996 	.db #0x8f	; 143
      00BF8E EC                    1997 	.db #0xec	; 236
      00BF8F 85                    1998 	.db #0x85	; 133
      00BF90 6C                    1999 	.db #0x6c	; 108	'l'
      00BF91 43                    2000 	.db #0x43	; 67	'C'
      00BF92 1C                    2001 	.db #0x1c	; 28
      00BF93 BA                    2002 	.db #0xba	; 186
      00BF94 89                    2003 	.db #0x89	; 137
      00BF95 68                    2004 	.db #0x68	; 104	'h'
      00BF96 4A                    2005 	.db #0x4a	; 74	'J'
      00BF97 1C                    2006 	.db #0x1c	; 28
      00BF98 91                    2007 	.db #0x91	; 145
      00BF99 3F                    2008 	.db #0x3f	; 63
      00BF9A D1                    2009 	.db #0xd1	; 209
      00BF9B B3                    2010 	.db #0xb3	; 179
      00BF9C 96                    2011 	.db #0x96	; 150
      00BF9D 1D                    2012 	.db #0x1d	; 29
      00BF9E 7C                    2013 	.db #0x7c	; 124
      00BF9F 14                    2014 	.db #0x14	; 20
      00BFA0 77                    2015 	.db #0x77	; 119	'w'
      00BFA1 9C                    2016 	.db #0x9c	; 156
      00BFA2 74                    2017 	.db #0x74	; 116	't'
      00BFA3 36                    2018 	.db #0x36	; 54	'6'
      00BFA4 FF                    2019 	.db #0xff	; 255
      00BFA5 2C                    2020 	.db #0x2c	; 44
      00BFA6 66                    2021 	.db #0x66	; 102	'f'
      00BFA7 AF                    2022 	.db #0xaf	; 175
      00BFA8 0F                    2023 	.db #0x0f	; 15
      00BFA9 3C                    2024 	.db #0x3c	; 60
      00BFAA A2                    2025 	.db #0xa2	; 162
      00BFAB 23                    2026 	.db #0x23	; 35
      00BFAC 85                    2027 	.db #0x85	; 133
      00BFAD 05                    2028 	.db #0x05	; 5
      00BFAE 87                    2029 	.db #0x87	; 135
      00BFAF DA                    2030 	.db #0xda	; 218
      00BFB0 61                    2031 	.db #0x61	; 97	'a'
      00BFB1 5E                    2032 	.db #0x5e	; 94
      00BFB2 42                    2033 	.db #0x42	; 66	'B'
      00BFB3 54                    2034 	.db #0x54	; 84	'T'
      00BFB4 60                    2035 	.db #0x60	; 96
      00BFB5 23                    2036 	.db #0x23	; 35
      00BFB6 CA                    2037 	.db #0xca	; 202
      00BFB7 BC                    2038 	.db #0xbc	; 188
      00BFB8 B3                    2039 	.db #0xb3	; 179
      00BFB9 18                    2040 	.db #0x18	; 24
      00BFBA 1D                    2041 	.db #0x1d	; 29
      00BFBB F8                    2042 	.db #0xf8	; 248
      00BFBC 0A                    2043 	.db #0x0a	; 10
      00BFBD 55                    2044 	.db #0x55	; 85	'U'
      00BFBE CD                    2045 	.db #0xcd	; 205
      00BFBF A3                    2046 	.db #0xa3	; 163
      00BFC0 DE                    2047 	.db #0xde	; 222
      00BFC1 FF                    2048 	.db #0xff	; 255
      00BFC2 B2                    2049 	.db #0xb2	; 178
      00BFC3 2A                    2050 	.db #0x2a	; 42
      00BFC4 35                    2051 	.db #0x35	; 53	'5'
      00BFC5 00                    2052 	.db #0x00	; 0
      00BFC6 D6                    2053 	.db #0xd6	; 214
      00BFC7 7B                    2054 	.db #0x7b	; 123
      00BFC8 E8                    2055 	.db #0xe8	; 232
      00BFC9 F2                    2056 	.db #0xf2	; 242
      00BFCA 1A                    2057 	.db #0x1a	; 26
      00BFCB BC                    2058 	.db #0xbc	; 188
      00BFCC F5                    2059 	.db #0xf5	; 245
      00BFCD 7E                    2060 	.db #0x7e	; 126
      00BFCE 48                    2061 	.db #0x48	; 72	'H'
      00BFCF 72                    2062 	.db #0x72	; 114	'r'
      00BFD0 E0                    2063 	.db #0xe0	; 224
      00BFD1 E4                    2064 	.db #0xe4	; 228
      00BFD2 E0                    2065 	.db #0xe0	; 224
      00BFD3 27                    2066 	.db #0x27	; 39
      00BFD4 87                    2067 	.db #0x87	; 135
      00BFD5 9A                    2068 	.db #0x9a	; 154
      00BFD6 51                    2069 	.db #0x51	; 81	'Q'
      00BFD7 D4                    2070 	.db #0xd4	; 212
      00BFD8 DD                    2071 	.db #0xdd	; 221
      00BFD9 C3                    2072 	.db #0xc3	; 195
      00BFDA AA                    2073 	.db #0xaa	; 170
      00BFDB 49                    2074 	.db #0x49	; 73	'I'
      00BFDC 5A                    2075 	.db #0x5a	; 90	'Z'
      00BFDD 2A                    2076 	.db #0x2a	; 42
      00BFDE 00                    2077 	.db #0x00	; 0
      00BFDF A0                    2078 	.db #0xa0	; 160
      00BFE0 8C                    2079 	.db #0x8c	; 140
      00BFE1 FF                    2080 	.db #0xff	; 255
      00BFE2 74                    2081 	.db #0x74	; 116	't'
      00BFE3 BF                    2082 	.db #0xbf	; 191
      00BFE4 EC                    2083 	.db #0xec	; 236
      00BFE5 1D                    2084 	.db #0x1d	; 29
      00BFE6 F1                    2085 	.db #0xf1	; 241
      00BFE7 00                    2086 	.db #0x00	; 0
      00BFE8 01                    2087 	.db #0x01	; 1
      00BFE9 D8                    2088 	.db #0xd8	; 216
      00BFEA 02                    2089 	.db #0x02	; 2
      00BFEB CC                    2090 	.db #0xcc	; 204
      00BFEC 07                    2091 	.db #0x07	; 7
      00BFED 00                    2092 	.db #0x00	; 0
      00BFEE 00                    2093 	.db #0x00	; 0
      00BFEF C4                    2094 	.db #0xc4	; 196
      00BFF0 5E                    2095 	.db #0x5e	; 94
      00BFF1 2C                    2096 	.db #0x2c	; 44
      00BFF2 7E                    2097 	.db #0x7e	; 126
      00BFF3 B1                    2098 	.db #0xb1	; 177
      00BFF4 C4                    2099 	.db #0xc4	; 196
      00BFF5 67                    2100 	.db #0x67	; 103	'g'
      00BFF6 FB                    2101 	.db #0xfb	; 251
      00BFF7 02                    2102 	.db #0x02	; 2
      00BFF8 00                    2103 	.db #0x00	; 0
      00BFF9 00                    2104 	.db #0x00	; 0
      00BFFA 00                    2105 	.db #0x00	; 0
      00BFFB 00                    2106 	.db #0x00	; 0
      00BFFC 04                    2107 	.db #0x04	; 4
      00BFFD 59                    2108 	.db #0x59	; 89	'Y'
      00BFFE 5A                    2109 	.db #0x5a	; 90	'Z'
                                   2110 	.area CSEG    (CODE)
                                   2111 	.area CONST   (CODE)
      00BFFF                       2112 _vial_handle_cmd_keyboard_uid_40000_623:
      00BFFF 04                    2113 	.db #0x04	; 4
      00C000 70                    2114 	.db #0x70	; 112	'p'
      00C001 FF                    2115 	.db #0xff	; 255
      00C002 90                    2116 	.db #0x90	; 144
      00C003 01                    2117 	.db #0x01	; 1
      00C004 B9                    2118 	.db #0xb9	; 185
      00C005 15                    2119 	.db #0x15	; 21
      00C006 D3                    2120 	.db #0xd3	; 211
                                   2121 	.area CSEG    (CODE)
                                   2122 	.area XINIT   (CODE)
      00C235                       2123 __xinit__vial_unlocked:
      00C235 00                    2124 	.db #0x00	;  0
      00C236                       2125 __xinit__vial_unlock_in_progress:
      00C236 00                    2126 	.db #0x00	;  0
      00C237                       2127 __xinit__vial_unlock_counter:
      00C237 00                    2128 	.db #0x00	; 0
      00C238                       2129 __xinit__vial_unlock_combo_rows:
      00C238 00                    2130 	.db #0x00	; 0
      00C239 00                    2131 	.db #0x00	; 0
      00C23A                       2132 __xinit__vial_unlock_combo_cols:
      00C23A 00                    2133 	.db #0x00	; 0
      00C23B 05                    2134 	.db #0x05	; 5
                                   2135 	.area CABS    (ABS,CODE)
                                   2136 
                                   2137 ; Experimental exact instruction outlining.
                                   2138 	.globl _ak820_outline_0005
                                   2139 	.globl _ak820_outline_0006
                                   2140 	.globl _ak820_outline_0008
                                   2141 	.globl _ak820_outline_0011
                                   2142 	.globl _ak820_outline_0017
                                   2143 	.globl _ak820_outline_0018
                                   2144 	.globl _ak820_outline_0021
                                   2145 	.globl _ak820_outline_0022
                                   2146 	.globl _ak820_outline_0024
                                   2147 	.globl _ak820_outline_0031
                                   2148 	.globl _ak820_outline_0032
                                   2149 	.globl _ak820_outline_0033
                                   2150 	.globl _ak820_outline_0036
                                   2151 	.globl _ak820_outline_0037
                                   2152 	.globl _ak820_outline_0051
                                   2153 	.globl _ak820_outline_0054
                                   2154 	.globl _ak820_outline_0055
                                   2155 	.globl _ak820_outline_0058
                                   2156 	.globl _ak820_outline_0071
                                   2157 	.globl _ak820_outline_0074
                                   2158 	.globl _ak820_outline_0083
                                   2159 	.globl _ak820_outline_0092
                                   2160 	.globl _ak820_outline_0100
                                   2161 	.globl _ak820_outline_0104
                                   2162 	.globl _ak820_outline_0108
                                   2163 	.globl _ak820_outline_0109
                                   2164 	.globl _ak820_outline_0119
                                   2165 	.globl _ak820_outline_0123
                                   2166 	.globl _ak820_outline_0124
                                   2167 	.globl _ak820_outline_0126
                                   2168 	.globl _ak820_outline_0127
                                   2169 	.globl _ak820_outline_0134
                                   2170 	.globl _ak820_outline_0135
                                   2171 	.globl _ak820_outline_0139
                                   2172 	.globl _ak820_outline_0143
                                   2173 	.globl _ak820_outline_0157
                                   2174 	.globl _ak820_outline_0183
                                   2175 	.globl _ak820_outline_0188
                                   2176 
                                   2177 	.area CSEG (CODE)
                                   2178 ; function ak820_outline_0024
      00B31F                       2179 _ak820_outline_0024:
      00B31F E0               [24] 2180 	movx	a,@dptr
      00B320 FE               [12] 2181 	mov	r6,a
      00B321 A3               [24] 2182 	inc	dptr
      00B322 E0               [24] 2183 	movx	a,@dptr
      00B323 FF               [12] 2184 	mov	r7,a
      00B324 90 0C 78         [24] 2185 	mov	dptr,#_g_vial_magic_keycode_override
      00B327 EE               [12] 2186 	mov	a,r6
      00B328 F0               [24] 2187 	movx	@dptr,a
      00B329 EF               [12] 2188 	mov	a,r7
      00B32A A3               [24] 2189 	inc	dptr
      00B32B F0               [24] 2190 	movx	@dptr,a
      00B32C 8E 04            [24] 2191 	mov	ar4,r6
      00B32E 8F 05            [24] 2192 	mov	ar5,r7
      00B330 C3               [12] 2193 	clr	c
      00B331 74 FF            [12] 2194 	mov	a,#0xff
      00B333 9C               [12] 2195 	subb	a,r4
      00B334 74 1F            [12] 2196 	mov	a,#0x1f
      00B336 9D               [12] 2197 	subb	a,r5
      00B337 22               [24] 2198 	ret
                                   2199 
                                   2200 	.area CSEG (CODE)
                                   2201 ; function ak820_outline_0074
      00B338                       2202 _ak820_outline_0074:
      00B338 A3               [24] 2203 	inc	dptr
      00B339 F0               [24] 2204 	movx	@dptr,a
      00B33A E4               [12] 2205 	clr	a
      00B33B A3               [24] 2206 	inc	dptr
      00B33C F0               [24] 2207 	movx	@dptr,a
      00B33D 90 0D A3         [24] 2208 	mov	dptr,#___memcpy_PARM_3
      00B340 74 0A            [12] 2209 	mov	a,#0x0a
      00B342 F0               [24] 2210 	movx	@dptr,a
      00B343 E4               [12] 2211 	clr	a
      00B344 A3               [24] 2212 	inc	dptr
      00B345 F0               [24] 2213 	movx	@dptr,a
      00B346 22               [24] 2214 	ret
                                   2215 
                                   2216 	.area CSEG (CODE)
                                   2217 ; function ak820_outline_0126
      00B347                       2218 _ak820_outline_0126:
      00B347 24 25            [12] 2219 	add	a,#_vial_unlock_combo_cols
      00B349 F5 82            [12] 2220 	mov	dpl,a
      00B34B E4               [12] 2221 	clr	a
      00B34C 34 0E            [12] 2222 	addc	a,#(_vial_unlock_combo_cols>>8)
      00B34E F5 83            [12] 2223 	mov	dph,a
      00B350 E0               [24] 2224 	movx	a,@dptr
      00B351 22               [24] 2225 	ret
                                   2226 
                                   2227 	.area CSEG (CODE)
                                   2228 ; function ak820_outline_0127
      00B352                       2229 _ak820_outline_0127:
      00B352 24 23            [12] 2230 	add	a,#_vial_unlock_combo_rows
      00B354 F5 82            [12] 2231 	mov	dpl,a
      00B356 E4               [12] 2232 	clr	a
      00B357 34 0E            [12] 2233 	addc	a,#(_vial_unlock_combo_rows>>8)
      00B359 F5 83            [12] 2234 	mov	dph,a
      00B35B E0               [24] 2235 	movx	a,@dptr
      00B35C 22               [24] 2236 	ret
