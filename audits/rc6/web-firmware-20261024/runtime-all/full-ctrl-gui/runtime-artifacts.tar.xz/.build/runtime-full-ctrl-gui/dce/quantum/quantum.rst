                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _ak820_gui_process
                                     22 	.globl _mcu_reset
                                     23 	.globl _bootloader_jump
                                     24 	.globl _ak820_resolve_key
                                     25 	.globl _default_layer_set
                                     26 	.globl _clear_keyboard
                                     27 	.globl _unregister_weak_mods
                                     28 	.globl _register_weak_mods
                                     29 	.globl _unregister_mods
                                     30 	.globl _register_mods
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _eeconfig_disable
                                     34 	.globl _rgb_matrix_set_suspend_state
                                     35 	.globl _rgb_matrix_task
                                     36 	.globl _mDelaymS
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _process_record_quantum_helper_PARM_2
                                    281 	.globl _get_record_keycode_PARM_2
                                    282 	.globl _post_process_record_user_PARM_2
                                    283 	.globl _post_process_record_kb_PARM_2
                                    284 	.globl _process_record_user_PARM_2
                                    285 	.globl _process_record_kb_PARM_2
                                    286 	.globl _pre_process_record_user_PARM_2
                                    287 	.globl _pre_process_record_kb_PARM_2
                                    288 	.globl _register_code16
                                    289 	.globl _unregister_code16
                                    290 	.globl _pre_process_record_kb
                                    291 	.globl _pre_process_record_user
                                    292 	.globl _process_action_kb
                                    293 	.globl _process_record_kb
                                    294 	.globl _process_record_user
                                    295 	.globl _post_process_record_kb
                                    296 	.globl _post_process_record_user
                                    297 	.globl _reset_keyboard
                                    298 	.globl _soft_reset_keyboard
                                    299 	.globl _get_record_keycode
                                    300 	.globl _pre_process_record_quantum
                                    301 	.globl _post_process_record_quantum
                                    302 	.globl _process_record_quantum
                                    303 	.globl _process_record_quantum_helper
                                    304 	.globl _shutdown_user
                                    305 ;--------------------------------------------------------
                                    306 ; special function registers
                                    307 ;--------------------------------------------------------
                                    308 	.area RSEG    (ABS,DATA)
      000000                        309 	.org 0x0000
                           0000D0   310 _PSW	=	0x00d0
                           0000E0   311 _ACC	=	0x00e0
                           0000F0   312 _B	=	0x00f0
                           0000FD   313 _A_INV	=	0x00fd
                           000081   314 _SP	=	0x0081
                           000082   315 _DPL	=	0x0082
                           000083   316 _DPH	=	0x0083
                           0000A1   317 _SAFE_MOD	=	0x00a1
                           0000B1   318 _GLOBAL_CFG	=	0x00b1
                           000087   319 _PCON	=	0x0087
                           0000BA   320 _POWER_CFG	=	0x00ba
                           0000B9   321 _CLOCK_CFG	=	0x00b9
                           0000A9   322 _WAKE_CTRL	=	0x00a9
                           0000FE   323 _RESET_KEEP	=	0x00fe
                           0000FF   324 _WDOG_COUNT	=	0x00ff
                           0000A8   325 _IE	=	0x00a8
                           0000B8   326 _IP	=	0x00b8
                           0000E8   327 _IE_EX	=	0x00e8
                           0000E9   328 _IP_EX	=	0x00e9
                           0000B2   329 _GPIO_IE	=	0x00b2
                           008584   330 _ROM_ADDR	=	0x8584
                           000084   331 _ROM_ADDR_L	=	0x0084
                           000085   332 _ROM_ADDR_H	=	0x0085
                           008F8E   333 _ROM_DATA_HI	=	0x8f8e
                           00008E   334 _ROM_DATA_HL	=	0x008e
                           00008F   335 _ROM_DATA_HH	=	0x008f
                           000086   336 _ROM_CTRL	=	0x0086
                           000080   337 _P0	=	0x0080
                           0000C4   338 _P0_MOD_OC	=	0x00c4
                           0000C5   339 _P0_DIR_PU	=	0x00c5
                           000090   340 _P1	=	0x0090
                           000092   341 _P1_MOD_OC	=	0x0092
                           000093   342 _P1_DIR_PU	=	0x0093
                           0000A0   343 _P2	=	0x00a0
                           000094   344 _P2_MOD_OC	=	0x0094
                           000095   345 _P2_DIR_PU	=	0x0095
                           0000B0   346 _P3	=	0x00b0
                           000096   347 _P3_MOD_OC	=	0x0096
                           000097   348 _P3_DIR_PU	=	0x0097
                           0000C0   349 _P4	=	0x00c0
                           0000C2   350 _P4_MOD_OC	=	0x00c2
                           0000C3   351 _P4_DIR_PU	=	0x00c3
                           0000C1   352 _P4_LED_KEY	=	0x00c1
                           0000AA   353 _P5_IN	=	0x00aa
                           0000AB   354 _P5_OUT_PU	=	0x00ab
                           0000AC   355 _P5_DIR	=	0x00ac
                           0000AD   356 _P6_IN	=	0x00ad
                           0000AE   357 _P6_OUT_PU	=	0x00ae
                           0000AF   358 _P6_DIR	=	0x00af
                           0000F1   359 _P7	=	0x00f1
                           0000A2   360 _XBUS_AUX	=	0x00a2
                           000088   361 _TCON	=	0x0088
                           000089   362 _TMOD	=	0x0089
                           00008A   363 _TL0	=	0x008a
                           00008B   364 _TL1	=	0x008b
                           00008C   365 _TH0	=	0x008c
                           00008D   366 _TH1	=	0x008d
                           000098   367 _SCON	=	0x0098
                           000099   368 _SBUF	=	0x0099
                           0000C8   369 _T2CON	=	0x00c8
                           0000C9   370 _T2MOD	=	0x00c9
                           00CBCA   371 _RCAP2	=	0xcbca
                           0000CA   372 _RCAP2L	=	0x00ca
                           0000CB   373 _RCAP2H	=	0x00cb
                           00CDCC   374 _T2COUNT	=	0xcdcc
                           0000CC   375 _TL2	=	0x00cc
                           0000CD   376 _TH2	=	0x00cd
                           00CFCE   377 _T2CAP1	=	0xcfce
                           0000CE   378 _T2CAP1L	=	0x00ce
                           0000CF   379 _T2CAP1H	=	0x00cf
                           0000F8   380 _SPI0_STAT	=	0x00f8
                           0000F9   381 _SPI0_DATA	=	0x00f9
                           0000FA   382 _SPI0_CTRL	=	0x00fa
                           0000FB   383 _SPI0_CK_SE	=	0x00fb
                           0000FC   384 _SPI0_SETUP	=	0x00fc
                           0000BC   385 _SCON1	=	0x00bc
                           0000BD   386 _SBUF1	=	0x00bd
                           0000BE   387 _SBAUD1	=	0x00be
                           0000BF   388 _SIF1	=	0x00bf
                           0000B4   389 _SPI1_STAT	=	0x00b4
                           0000B5   390 _SPI1_DATA	=	0x00b5
                           0000B6   391 _SPI1_CTRL	=	0x00b6
                           0000B7   392 _SPI1_CK_SE	=	0x00b7
                           0000F3   393 _ADC_CTRL	=	0x00f3
                           00F5F4   394 _ADC_DAT	=	0xf5f4
                           0000F4   395 _ADC_DAT_L	=	0x00f4
                           0000F5   396 _ADC_DAT_H	=	0x00f5
                           0000F6   397 _ADC_CHAN	=	0x00f6
                           0000A6   398 _LED_COMMON	=	0x00a6
                           0000A7   399 _LED_PWM_OE	=	0x00a7
                           00C7C6   400 _LED_DMA	=	0xc7c6
                           0000C6   401 _LED_DMA_L	=	0x00c6
                           0000C7   402 _LED_DMA_H	=	0x00c7
                           0000F7   403 _LED_STATUS	=	0x00f7
                           0000B3   404 _I2CX_INT	=	0x00b3
                           0000BB   405 _I2CS_INT_ST	=	0x00bb
                                    406 ;--------------------------------------------------------
                                    407 ; special function bits
                                    408 ;--------------------------------------------------------
                                    409 	.area RSEG    (ABS,DATA)
      000000                        410 	.org 0x0000
                           0000D7   411 _CY	=	0x00d7
                           0000D6   412 _AC	=	0x00d6
                           0000D5   413 _F0	=	0x00d5
                           0000D4   414 _RS1	=	0x00d4
                           0000D3   415 _RS0	=	0x00d3
                           0000D2   416 _OV	=	0x00d2
                           0000D1   417 _F1	=	0x00d1
                           0000D0   418 _P	=	0x00d0
                           0000AF   419 _EA	=	0x00af
                           0000AE   420 _E_DIS	=	0x00ae
                           0000AD   421 _ET2	=	0x00ad
                           0000AC   422 _ES	=	0x00ac
                           0000AB   423 _ET1	=	0x00ab
                           0000AA   424 _EX1	=	0x00aa
                           0000A9   425 _ET0	=	0x00a9
                           0000A8   426 _EX0	=	0x00a8
                           0000BF   427 _PH_FLAG	=	0x00bf
                           0000BE   428 _PL_FLAG	=	0x00be
                           0000BD   429 _PT2	=	0x00bd
                           0000BC   430 _PS	=	0x00bc
                           0000BB   431 _PT1	=	0x00bb
                           0000BA   432 _PX1	=	0x00ba
                           0000B9   433 _PT0	=	0x00b9
                           0000B8   434 _PX0	=	0x00b8
                           0000EF   435 _IE_WDOG	=	0x00ef
                           0000EE   436 _IE_GPIO	=	0x00ee
                           0000ED   437 _IE_PWM_I2C	=	0x00ed
                           0000EC   438 _IE_UART1	=	0x00ec
                           0000EB   439 _IE_ADC	=	0x00eb
                           0000E9   440 _IE_USB	=	0x00e9
                           0000E8   441 _IE_SPI0	=	0x00e8
                           000087   442 _P0_7	=	0x0087
                           000086   443 _P0_6	=	0x0086
                           000085   444 _P0_5	=	0x0085
                           000084   445 _P0_4	=	0x0084
                           000083   446 _P0_3	=	0x0083
                           000082   447 _P0_2	=	0x0082
                           000081   448 _P0_1	=	0x0081
                           000080   449 _P0_0	=	0x0080
                           000081   450 _SDA0	=	0x0081
                           000080   451 _SCL0	=	0x0080
                           000083   452 _TXD_	=	0x0083
                           000082   453 _RXD_	=	0x0082
                           000085   454 _AIN13	=	0x0085
                           000084   455 _AIN12	=	0x0084
                           000083   456 _AIN11	=	0x0083
                           000082   457 _AIN10	=	0x0082
                           000081   458 _AIN9	=	0x0081
                           000080   459 _AIN8	=	0x0080
                           000097   460 _P1_7	=	0x0097
                           000096   461 _P1_6	=	0x0096
                           000095   462 _P1_5	=	0x0095
                           000094   463 _P1_4	=	0x0094
                           000093   464 _P1_3	=	0x0093
                           000092   465 _P1_2	=	0x0092
                           000091   466 _P1_1	=	0x0091
                           000090   467 _P1_0	=	0x0090
                           000097   468 _TXD1_	=	0x0097
                           000096   469 _RXD1_	=	0x0096
                           000097   470 _SCK	=	0x0097
                           000096   471 _MISO	=	0x0096
                           000095   472 _MOSI	=	0x0095
                           000094   473 _SCS	=	0x0094
                           000092   474 _INT0_	=	0x0092
                           000091   475 _T2EX	=	0x0091
                           000091   476 _CAP2	=	0x0091
                           000090   477 _T2	=	0x0090
                           000090   478 _CAP1	=	0x0090
                           000097   479 _AIN7	=	0x0097
                           000096   480 _AIN6	=	0x0096
                           000095   481 _AIN5	=	0x0095
                           000094   482 _AIN4	=	0x0094
                           000093   483 _AIN3	=	0x0093
                           000092   484 _AIN2	=	0x0092
                           000091   485 _AIN1	=	0x0091
                           000090   486 _AIN0	=	0x0090
                           0000A7   487 _P2_7	=	0x00a7
                           0000A6   488 _P2_6	=	0x00a6
                           0000A5   489 _P2_5	=	0x00a5
                           0000A4   490 _P2_4	=	0x00a4
                           0000A3   491 _P2_3	=	0x00a3
                           0000A2   492 _P2_2	=	0x00a2
                           0000A1   493 _P2_1	=	0x00a1
                           0000A0   494 _P2_0	=	0x00a0
                           0000A7   495 _TXD1	=	0x00a7
                           0000A6   496 _RXD1	=	0x00a6
                           0000A5   497 _T2EX_	=	0x00a5
                           0000A5   498 _CAP2_	=	0x00a5
                           0000A4   499 _T2_	=	0x00a4
                           0000A4   500 _CAP1_	=	0x00a4
                           0000B7   501 _P3_7	=	0x00b7
                           0000B6   502 _P3_6	=	0x00b6
                           0000B5   503 _P3_5	=	0x00b5
                           0000B4   504 _P3_4	=	0x00b4
                           0000B3   505 _P3_3	=	0x00b3
                           0000B2   506 _P3_2	=	0x00b2
                           0000B1   507 _P3_1	=	0x00b1
                           0000B0   508 _P3_0	=	0x00b0
                           0000B7   509 _SCK1	=	0x00b7
                           0000B6   510 _MISO1	=	0x00b6
                           0000B5   511 _MOSI1	=	0x00b5
                           0000B5   512 _T1	=	0x00b5
                           0000B4   513 _T0	=	0x00b4
                           0000B3   514 _INT1	=	0x00b3
                           0000B2   515 _INT0	=	0x00b2
                           0000B1   516 _TXD	=	0x00b1
                           0000B0   517 _RXD	=	0x00b0
                           0000C6   518 _P4_6	=	0x00c6
                           0000C5   519 _P4_5	=	0x00c5
                           0000C4   520 _P4_4	=	0x00c4
                           0000C3   521 _P4_3	=	0x00c3
                           0000C2   522 _P4_2	=	0x00c2
                           0000C1   523 _P4_1	=	0x00c1
                           0000C0   524 _P4_0	=	0x00c0
                           00008F   525 _TF1	=	0x008f
                           00008E   526 _TR1	=	0x008e
                           00008D   527 _TF0	=	0x008d
                           00008C   528 _TR0	=	0x008c
                           00008B   529 _IE1	=	0x008b
                           00008A   530 _IT1	=	0x008a
                           000089   531 _IE0	=	0x0089
                           000088   532 _IT0	=	0x0088
                           00009F   533 _SM0	=	0x009f
                           00009E   534 _SM1	=	0x009e
                           00009D   535 _SM2	=	0x009d
                           00009C   536 _REN	=	0x009c
                           00009B   537 _TB8	=	0x009b
                           00009A   538 _RB8	=	0x009a
                           000099   539 _TI	=	0x0099
                           000098   540 _RI	=	0x0098
                           0000CF   541 _TF2	=	0x00cf
                           0000CF   542 _CAP1F	=	0x00cf
                           0000CE   543 _EXF2	=	0x00ce
                           0000CD   544 _RCLK	=	0x00cd
                           0000CC   545 _TCLK	=	0x00cc
                           0000CB   546 _EXEN2	=	0x00cb
                           0000CA   547 _TR2	=	0x00ca
                           0000C9   548 _C_T2	=	0x00c9
                           0000C8   549 _CP_RL2	=	0x00c8
                           0000FF   550 _S0_FST_ACT	=	0x00ff
                           0000FE   551 _S0_IF_OV	=	0x00fe
                           0000FD   552 _S0_IF_FIRST	=	0x00fd
                           0000FC   553 _S0_IF_BYTE	=	0x00fc
                           0000FB   554 _S0_FREE	=	0x00fb
                           0000FA   555 _S0_T_FIFO	=	0x00fa
                           0000F8   556 _S0_R_FIFO	=	0x00f8
                           0000F7   557 _ADC_START	=	0x00f7
                                    558 ;--------------------------------------------------------
                                    559 ; overlayable register banks
                                    560 ;--------------------------------------------------------
                                    561 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        562 	.ds 8
                                    563 ;--------------------------------------------------------
                                    564 ; internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area DSEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; overlayable items in internal ram
                                    569 ;--------------------------------------------------------
                                    570 ;--------------------------------------------------------
                                    571 ; indirectly addressable internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area ISEG    (DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; absolute internal ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area IABS    (ABS,DATA)
                                    578 	.area IABS    (ABS,DATA)
                                    579 ;--------------------------------------------------------
                                    580 ; bit data
                                    581 ;--------------------------------------------------------
                                    582 	.area BSEG    (BIT)
      000028                        583 _get_record_keycode_sloc0_1_0:
      000028                        584 	.ds 1
      000029                        585 _pre_process_record_quantum_sloc0_1_0:
      000029                        586 	.ds 1
      00002A                        587 _process_ak820_nkro_sloc0_1_0:
      00002A                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; paged external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area PSEG    (PAG,XDATA)
                                    593 ;--------------------------------------------------------
                                    594 ; uninitialized external ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area XSEG    (XDATA)
      000BD9                        597 _extract_mod_bits_code_10000_600:
      000BD9                        598 	.ds 2
      000BDB                        599 _register_code16_code_10000_606:
      000BDB                        600 	.ds 2
      000BDD                        601 _unregister_code16_code_10000_611:
      000BDD                        602 	.ds 2
      000BDF                        603 _pre_process_record_kb_PARM_2:
      000BDF                        604 	.ds 3
      000BE2                        605 _pre_process_record_kb_keycode_10000_625:
      000BE2                        606 	.ds 2
      000BE4                        607 _pre_process_record_user_PARM_2:
      000BE4                        608 	.ds 3
      000BE7                        609 _process_record_kb_PARM_2:
      000BE7                        610 	.ds 3
      000BEA                        611 _process_record_kb_keycode_10000_631:
      000BEA                        612 	.ds 2
      000BEC                        613 _process_record_user_PARM_2:
      000BEC                        614 	.ds 3
      000BEF                        615 _post_process_record_kb_PARM_2:
      000BEF                        616 	.ds 3
      000BF2                        617 _post_process_record_kb_keycode_10000_635:
      000BF2                        618 	.ds 2
      000BF4                        619 _post_process_record_user_PARM_2:
      000BF4                        620 	.ds 3
      000BF7                        621 _get_record_keycode_PARM_2:
      000BF7                        622 	.ds 1
      000BF8                        623 _get_record_keycode_record_argument_10000_649:
      000BF8                        624 	.ds 3
      000BFB                        625 _pre_process_record_quantum_record_argument_10000_655:
      000BFB                        626 	.ds 3
      000BFE                        627 _post_process_record_quantum_record_10000_657:
      000BFE                        628 	.ds 3
      000C01                        629 _process_record_quantum_record_10000_659:
      000C01                        630 	.ds 3
      000C04                        631 _process_ak820_nkro_PARM_2:
      000C04                        632 	.ds 3
      000C07                        633 _process_ak820_nkro_keycode_10000_661:
      000C07                        634 	.ds 2
      000C09                        635 _process_record_quantum_helper_PARM_2:
      000C09                        636 	.ds 3
      000C0C                        637 _process_record_quantum_helper_keycode_10000_666:
      000C0C                        638 	.ds 2
      000C0E                        639 _get_u8_str_last_num_10000_692:
      000C0E                        640 	.ds 1
      000C0F                        641 _get_u16_str_last_num_10000_696:
      000C0F                        642 	.ds 2
                                    643 ;--------------------------------------------------------
                                    644 ; absolute external ram data
                                    645 ;--------------------------------------------------------
                                    646 	.area XABS    (ABS,XDATA)
                                    647 ;--------------------------------------------------------
                                    648 ; initialized external ram data
                                    649 ;--------------------------------------------------------
                                    650 	.area XISEG   (XDATA)
                                    651 	.area HOME    (CODE)
                                    652 	.area GSINIT0 (CODE)
                                    653 	.area GSINIT1 (CODE)
                                    654 	.area GSINIT2 (CODE)
                                    655 	.area GSINIT3 (CODE)
                                    656 	.area GSINIT4 (CODE)
                                    657 	.area GSINIT5 (CODE)
                                    658 	.area GSINIT  (CODE)
                                    659 	.area GSFINAL (CODE)
                                    660 	.area CSEG    (CODE)
                                    661 ;--------------------------------------------------------
                                    662 ; global & static initialisations
                                    663 ;--------------------------------------------------------
                                    664 	.area HOME    (CODE)
                                    665 	.area GSINIT  (CODE)
                                    666 	.area GSFINAL (CODE)
                                    667 	.area GSINIT  (CODE)
                                    668 ;------------------------------------------------------------
                                    669 ;Allocation info for local variables in function 'get_u8_str'
                                    670 ;------------------------------------------------------------
                                    671 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    672 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_691'
                                    673 ;buf           Allocated with name '_get_u8_str_buf_10000_692'
                                    674 ;last_num      Allocated with name '_get_u8_str_last_num_10000_692'
                                    675 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_692'
                                    676 ;------------------------------------------------------------
                                    677 ;	quantum/quantum.c:750: static uint8_t last_num = 0xFF;
      0030F3 90 0C 0E         [24]  678 	mov	dptr,#_get_u8_str_last_num_10000_692
      0030F6 74 FF            [12]  679 	mov	a,#0xff
      0030F8 F0               [24]  680 	movx	@dptr,a
                                    681 ;------------------------------------------------------------
                                    682 ;Allocation info for local variables in function 'get_u16_str'
                                    683 ;------------------------------------------------------------
                                    684 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    685 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_695'
                                    686 ;buf           Allocated with name '_get_u16_str_buf_10000_696'
                                    687 ;last_num      Allocated with name '_get_u16_str_last_num_10000_696'
                                    688 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_696'
                                    689 ;------------------------------------------------------------
                                    690 ;	quantum/quantum.c:770: static uint16_t last_num = 0xFF;
      0030F9 90 0C 0F         [24]  691 	mov	dptr,#_get_u16_str_last_num_10000_696
      0030FC 74 FF            [12]  692 	mov	a,#0xff
      0030FE F0               [24]  693 	movx	@dptr,a
      0030FF E4               [12]  694 	clr	a
      003100 A3               [24]  695 	inc	dptr
      003101 F0               [24]  696 	movx	@dptr,a
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    708 ;------------------------------------------------------------
                                    709 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    710 ;------------------------------------------------------------
                                    711 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function extract_mod_bits
                                    722 ;	-----------------------------------------
      009DB8                        723 _extract_mod_bits:
      009DB8 12 38 88         [24]  724 	lcall	_ak820_outline_0108
      009DBB 90 0B D9         [24]  725 	mov	dptr,#_extract_mod_bits_code_10000_600
      009DBE 12 38 8D         [24]  726 	lcall	_ak820_outline_0109
                                    727 ;	quantum/quantum.c:107: uint8_t mods = (uint8_t)(code >> 8);
      009DC1 90 0B D9         [24]  728 	mov	dptr,#_extract_mod_bits_code_10000_600
      009DC4 E0               [24]  729 	movx	a,@dptr
      009DC5 A3               [24]  730 	inc	dptr
      009DC6 E0               [24]  731 	movx	a,@dptr
                                    732 ;	quantum/quantum.c:108: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009DC7 FF               [12]  733 	mov	r7,a
      009DC8 60 05            [24]  734 	jz	00101$
      009DCA EF               [12]  735 	mov	a,r7
      009DCB 24 E0            [12]  736 	add	a,#0xff - 0x1f
      009DCD 50 04            [24]  737 	jnc	00102$
                                    738 ;	free result
      009DCF                        739 00101$:
      009DCF 75 82 00         [24]  740 	mov	dpl, #0x00
      009DD2 22               [24]  741 	ret
      009DD3                        742 00102$:
                                    743 ;	quantum/quantum.c:109: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009DD3 EF               [12]  744 	mov	a,r7
      009DD4 30 E4 07         [24]  745 	jnb	acc.4,00106$
      009DD7 EF               [12]  746 	mov	a,r7
      009DD8 C4               [12]  747 	swap	a
      009DD9 54 F0            [12]  748 	anl	a,#0xf0
      009DDB FE               [12]  749 	mov	r6,a
      009DDC 80 02            [24]  750 	sjmp	00107$
      009DDE                        751 00106$:
      009DDE 8F 06            [24]  752 	mov	ar6,r7
      009DE0                        753 00107$:
      009DE0 8E 82            [24]  754 	mov	dpl, r6
                                    755 ;	quantum/quantum.c:137: }
      009DE2 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'do_code16'
                                    759 ;------------------------------------------------------------
                                    760 ;f             Allocated with name '_do_code16_PARM_2'
                                    761 ;code          Allocated with name '_do_code16_code_10000_603'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/quantum.c:139: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function register_code16
                                    766 ;	-----------------------------------------
      009DE3                        767 _register_code16:
      009DE3 12 38 88         [24]  768 	lcall	_ak820_outline_0108
      009DE6 90 0B DB         [24]  769 	mov	dptr,#_register_code16_code_10000_606
      009DE9 12 38 8D         [24]  770 	lcall	_ak820_outline_0109
                                    771 ;	quantum/quantum.c:145: uint8_t mods = extract_mod_bits(code);
      009DEC 90 0B DB         [24]  772 	mov	dptr,#_register_code16_code_10000_606
      009DEF 12 37 F4         [24]  773 	lcall	_ak820_outline_0005
      009DF2 C0 07            [24]  774 	push	ar7
      009DF4 C0 06            [24]  775 	push	ar6
      009DF6 12 9D B8         [24]  776 	lcall	_extract_mod_bits
      009DF9 AD 82            [24]  777 	mov	r5, dpl
      009DFB D0 06            [24]  778 	pop	ar6
      009DFD D0 07            [24]  779 	pop	ar7
                                    780 ;	quantum/quantum.c:146: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009DFF 12 9B F1         [24]  781 	lcall	_ak820_outline_0120
      009E02 40 07            [24]  782 	jc	00105$
      009E04 74 E7            [12]  783 	mov	a,#0xe7
      009E06 9E               [12]  784 	subb	a,r6
      009E07 E4               [12]  785 	clr	a
      009E08 9F               [12]  786 	subb	a,r7
      009E09 50 08            [24]  787 	jnc	00101$
                                    788 ;	free result
      009E0B                        789 00105$:
      009E0B 90 0B DB         [24]  790 	mov	dptr,#_register_code16_code_10000_606
      009E0E 12 6D 86         [24]  791 	lcall	_ak820_outline_0040
      009E11 70 07            [24]  792 	jnz	00102$
      009E13                        793 00101$:
                                    794 ;	quantum/quantum.c:147: register_mods(mods);
      009E13 8D 82            [24]  795 	mov	dpl, r5
      009E15 12 76 2F         [24]  796 	lcall	_register_mods
      009E18 80 05            [24]  797 	sjmp	00103$
      009E1A                        798 00102$:
                                    799 ;	quantum/quantum.c:149: register_weak_mods(mods);
      009E1A 8D 82            [24]  800 	mov	dpl, r5
      009E1C 12 76 57         [24]  801 	lcall	_register_weak_mods
      009E1F                        802 00103$:
                                    803 ;	quantum/quantum.c:151: register_code(code);
      009E1F 90 0B DB         [24]  804 	mov	dptr,#_register_code16_code_10000_606
      009E22 E0               [24]  805 	movx	a,@dptr
      009E23 F5 82            [12]  806 	mov	dpl,a
                                    807 ;	quantum/quantum.c:161: }
      009E25 02 75 0C         [24]  808 	ljmp	_register_code
                                    809 ;------------------------------------------------------------
                                    810 ;Allocation info for local variables in function 'unregister_code16'
                                    811 ;------------------------------------------------------------
                                    812 ;code          Allocated with name '_unregister_code16_code_10000_611'
                                    813 ;mods          Allocated with name '_unregister_code16_mods_10000_612'
                                    814 ;------------------------------------------------------------
                                    815 ;	quantum/quantum.c:163: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    816 ;	-----------------------------------------
                                    817 ;	 function unregister_code16
                                    818 ;	-----------------------------------------
      009E28                        819 _unregister_code16:
      009E28 12 38 88         [24]  820 	lcall	_ak820_outline_0108
      009E2B 90 0B DD         [24]  821 	mov	dptr,#_unregister_code16_code_10000_611
      009E2E 12 38 8D         [24]  822 	lcall	_ak820_outline_0109
                                    823 ;	quantum/quantum.c:165: uint8_t mods = extract_mod_bits(code);
      009E31 90 0B DD         [24]  824 	mov	dptr,#_unregister_code16_code_10000_611
      009E34 12 37 F4         [24]  825 	lcall	_ak820_outline_0005
      009E37 C0 07            [24]  826 	push	ar7
      009E39 C0 06            [24]  827 	push	ar6
      009E3B 12 9D B8         [24]  828 	lcall	_extract_mod_bits
      009E3E AD 82            [24]  829 	mov	r5, dpl
      009E40 D0 06            [24]  830 	pop	ar6
                                    831 ;	quantum/quantum.c:166: unregister_code(code);
      009E42 8E 04            [24]  832 	mov	ar4,r6
      009E44 8C 82            [24]  833 	mov	dpl, r4
      009E46 C0 06            [24]  834 	push	ar6
      009E48 C0 05            [24]  835 	push	ar5
      009E4A 12 75 79         [24]  836 	lcall	_unregister_code
      009E4D D0 05            [24]  837 	pop	ar5
      009E4F D0 06            [24]  838 	pop	ar6
      009E51 D0 07            [24]  839 	pop	ar7
                                    840 ;	quantum/quantum.c:167: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009E53 12 9B F1         [24]  841 	lcall	_ak820_outline_0120
      009E56 40 07            [24]  842 	jc	00105$
      009E58 74 E7            [12]  843 	mov	a,#0xe7
      009E5A 9E               [12]  844 	subb	a,r6
      009E5B E4               [12]  845 	clr	a
      009E5C 9F               [12]  846 	subb	a,r7
      009E5D 50 08            [24]  847 	jnc	00101$
                                    848 ;	free result
      009E5F                        849 00105$:
      009E5F 90 0B DD         [24]  850 	mov	dptr,#_unregister_code16_code_10000_611
      009E62 12 6D 86         [24]  851 	lcall	_ak820_outline_0040
      009E65 70 05            [24]  852 	jnz	00102$
      009E67                        853 00101$:
                                    854 ;	quantum/quantum.c:168: unregister_mods(mods);
      009E67 8D 82            [24]  855 	mov	dpl, r5
      009E69 02 76 43         [24]  856 	ljmp	_unregister_mods
      009E6C                        857 00102$:
                                    858 ;	quantum/quantum.c:170: unregister_weak_mods(mods);
      009E6C 8D 82            [24]  859 	mov	dpl, r5
                                    860 ;	quantum/quantum.c:181: }
      009E6E 02 76 6B         [24]  861 	ljmp	_unregister_weak_mods
                                    862 ;------------------------------------------------------------
                                    863 ;Allocation info for local variables in function 'tap_code16_delay'
                                    864 ;------------------------------------------------------------
                                    865 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    866 ;code          Allocated with name '_tap_code16_delay_code_10000_616'
                                    867 ;i             Allocated with name '_tap_code16_delay_i_20000_618'
                                    868 ;i             Allocated with name '_tap_code16_delay_i_50000_621'
                                    869 ;------------------------------------------------------------
                                    870 ;	quantum/quantum.c:188: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    871 ;	-----------------------------------------
                                    872 ;	 function pre_process_record_kb
                                    873 ;	-----------------------------------------
      009E71                        874 _pre_process_record_kb:
      009E71 12 38 88         [24]  875 	lcall	_ak820_outline_0108
      009E74 90 0B E2         [24]  876 	mov	dptr,#_pre_process_record_kb_keycode_10000_625
      009E77 12 38 8D         [24]  877 	lcall	_ak820_outline_0109
                                    878 ;	quantum/quantum.c:205: return pre_process_record_user(keycode, record);
      009E7A 90 0B E2         [24]  879 	mov	dptr,#_pre_process_record_kb_keycode_10000_625
      009E7D 12 38 41         [24]  880 	lcall	_ak820_outline_0051
      009E80 90 0B DF         [24]  881 	mov	dptr,#_pre_process_record_kb_PARM_2
      009E83 12 9B E8         [24]  882 	lcall	_ak820_outline_0025
      009E86 90 0B E4         [24]  883 	mov	dptr,#_pre_process_record_user_PARM_2
      009E89 12 A2 4A         [24]  884 	lcall	_ak820_outline_0010
                                    885 ;	quantum/quantum.c:206: }
      009E8C 02 9E 8F         [24]  886 	ljmp	_pre_process_record_user
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'pre_process_record_user'
                                    889 ;------------------------------------------------------------
                                    890 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    891 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_627'
                                    892 ;------------------------------------------------------------
                                    893 ;	quantum/quantum.c:208: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    894 ;	-----------------------------------------
                                    895 ;	 function pre_process_record_user
                                    896 ;	-----------------------------------------
      009E8F                        897 _pre_process_record_user:
                                    898 ;	quantum/quantum.c:209: return true;
      009E8F 75 82 01         [24]  899 	mov	dpl, #0x01
                                    900 ;	quantum/quantum.c:210: }
      009E92 22               [24]  901 	ret
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'process_action_kb'
                                    904 ;------------------------------------------------------------
                                    905 ;record        Allocated with name '_process_action_kb_record_10000_629'
                                    906 ;------------------------------------------------------------
                                    907 ;	quantum/quantum.c:212: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    908 ;	-----------------------------------------
                                    909 ;	 function process_action_kb
                                    910 ;	-----------------------------------------
      009E93                        911 _process_action_kb:
                                    912 ;	quantum/quantum.c:213: return true;
      009E93 75 82 01         [24]  913 	mov	dpl, #0x01
                                    914 ;	quantum/quantum.c:214: }
      009E96 22               [24]  915 	ret
                                    916 ;------------------------------------------------------------
                                    917 ;Allocation info for local variables in function 'process_record_kb'
                                    918 ;------------------------------------------------------------
                                    919 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    920 ;keycode       Allocated with name '_process_record_kb_keycode_10000_631'
                                    921 ;------------------------------------------------------------
                                    922 ;	quantum/quantum.c:216: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function process_record_kb
                                    925 ;	-----------------------------------------
      009E97                        926 _process_record_kb:
      009E97 12 38 88         [24]  927 	lcall	_ak820_outline_0108
      009E9A 90 0B EA         [24]  928 	mov	dptr,#_process_record_kb_keycode_10000_631
      009E9D 12 38 8D         [24]  929 	lcall	_ak820_outline_0109
                                    930 ;	quantum/quantum.c:217: return process_record_user(keycode, record);
      009EA0 90 0B EA         [24]  931 	mov	dptr,#_process_record_kb_keycode_10000_631
      009EA3 12 38 41         [24]  932 	lcall	_ak820_outline_0051
      009EA6 90 0B E7         [24]  933 	mov	dptr,#_process_record_kb_PARM_2
      009EA9 12 9B E8         [24]  934 	lcall	_ak820_outline_0025
      009EAC 90 0B EC         [24]  935 	mov	dptr,#_process_record_user_PARM_2
      009EAF 12 A2 4A         [24]  936 	lcall	_ak820_outline_0010
                                    937 ;	quantum/quantum.c:218: }
      009EB2 02 9E B5         [24]  938 	ljmp	_process_record_user
                                    939 ;------------------------------------------------------------
                                    940 ;Allocation info for local variables in function 'process_record_user'
                                    941 ;------------------------------------------------------------
                                    942 ;record        Allocated with name '_process_record_user_PARM_2'
                                    943 ;keycode       Allocated with name '_process_record_user_keycode_10000_633'
                                    944 ;------------------------------------------------------------
                                    945 ;	quantum/quantum.c:220: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function process_record_user
                                    948 ;	-----------------------------------------
      009EB5                        949 _process_record_user:
                                    950 ;	quantum/quantum.c:221: return true;
      009EB5 75 82 01         [24]  951 	mov	dpl, #0x01
                                    952 ;	quantum/quantum.c:222: }
      009EB8 22               [24]  953 	ret
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'post_process_record_kb'
                                    956 ;------------------------------------------------------------
                                    957 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    958 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_635'
                                    959 ;------------------------------------------------------------
                                    960 ;	quantum/quantum.c:224: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function post_process_record_kb
                                    963 ;	-----------------------------------------
      009EB9                        964 _post_process_record_kb:
      009EB9 12 38 88         [24]  965 	lcall	_ak820_outline_0108
      009EBC 90 0B F2         [24]  966 	mov	dptr,#_post_process_record_kb_keycode_10000_635
      009EBF 12 38 8D         [24]  967 	lcall	_ak820_outline_0109
                                    968 ;	quantum/quantum.c:225: post_process_record_user(keycode, record);
      009EC2 90 0B F2         [24]  969 	mov	dptr,#_post_process_record_kb_keycode_10000_635
      009EC5 12 38 41         [24]  970 	lcall	_ak820_outline_0051
      009EC8 90 0B EF         [24]  971 	mov	dptr,#_post_process_record_kb_PARM_2
      009ECB 12 9B E8         [24]  972 	lcall	_ak820_outline_0025
      009ECE 90 0B F4         [24]  973 	mov	dptr,#_post_process_record_user_PARM_2
      009ED1 12 A2 4A         [24]  974 	lcall	_ak820_outline_0010
                                    975 ;	quantum/quantum.c:226: }
      009ED4 02 9E D7         [24]  976 	ljmp	_post_process_record_user
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'post_process_record_user'
                                    979 ;------------------------------------------------------------
                                    980 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    981 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_637'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/quantum.c:228: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    984 ;	-----------------------------------------
                                    985 ;	 function post_process_record_user
                                    986 ;	-----------------------------------------
      009ED7                        987 _post_process_record_user:
      009ED7 22               [24]  988 	ret
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'shutdown_quantum'
                                    991 ;------------------------------------------------------------
                                    992 ;i             Allocated with name '_shutdown_quantum_i_30000_643'
                                    993 ;------------------------------------------------------------
                                    994 ;	quantum/quantum.c:230: void shutdown_quantum(void) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function shutdown_quantum
                                    997 ;	-----------------------------------------
      009ED8                        998 _shutdown_quantum:
                                    999 ;	quantum/quantum.c:231: clear_keyboard();
      009ED8 12 76 7F         [24] 1000 	lcall	_clear_keyboard
                                   1001 ;	quantum/quantum.c:246: shutdown_user();
      009EDB 12 A2 3C         [24] 1002 	lcall	_shutdown_user
                                   1003 ;	quantum/quantum.c:247: wait_ms(250);
      009EDE 7F FA            [12] 1004 	mov	r7,#0xfa
      009EE0                       1005 00106$:
      009EE0 EF               [12] 1006 	mov	a,r7
      009EE1 60 09            [24] 1007 	jz	00108$
      009EE3 90 00 01         [24] 1008 	mov	dptr,#0x0001
      009EE6 12 58 F2         [24] 1009 	lcall	_mDelaymS
      009EE9 1F               [12] 1010 	dec	r7
      009EEA 80 F4            [24] 1011 	sjmp	00106$
      009EEC                       1012 00108$:
                                   1013 ;	quantum/quantum.c:252: }
      009EEC 22               [24] 1014 	ret
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'reset_keyboard'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/quantum.c:254: void reset_keyboard(void) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function reset_keyboard
                                   1021 ;	-----------------------------------------
      009EED                       1022 _reset_keyboard:
                                   1023 ;	quantum/quantum.c:255: shutdown_quantum();
      009EED 12 9E D8         [24] 1024 	lcall	_shutdown_quantum
                                   1025 ;	quantum/quantum.c:256: bootloader_jump();
                                   1026 ;	quantum/quantum.c:257: }
      009EF0 02 34 0E         [24] 1027 	ljmp	_bootloader_jump
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	quantum/quantum.c:259: void soft_reset_keyboard(void) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function soft_reset_keyboard
                                   1034 ;	-----------------------------------------
      009EF3                       1035 _soft_reset_keyboard:
                                   1036 ;	quantum/quantum.c:260: shutdown_quantum();
      009EF3 12 9E D8         [24] 1037 	lcall	_shutdown_quantum
                                   1038 ;	quantum/quantum.c:261: mcu_reset();
                                   1039 ;	quantum/quantum.c:262: }
      009EF6 02 34 01         [24] 1040 	ljmp	_mcu_reset
                                   1041 ;------------------------------------------------------------
                                   1042 ;Allocation info for local variables in function 'get_record_keycode'
                                   1043 ;------------------------------------------------------------
                                   1044 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1045 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_649'
                                   1046 ;record        Allocated with name '_get_record_keycode_record_10000_650'
                                   1047 ;------------------------------------------------------------
                                   1048 ;	quantum/quantum.c:265: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1049 ;	-----------------------------------------
                                   1050 ;	 function get_record_keycode
                                   1051 ;	-----------------------------------------
      009EF9                       1052 _get_record_keycode:
      009EF9 12 43 15         [24] 1053 	lcall	_ak820_outline_0037
      009EFC 90 0B F8         [24] 1054 	mov	dptr,#_get_record_keycode_record_argument_10000_649
      009EFF 12 38 29         [24] 1055 	lcall	_ak820_outline_0017
                                   1056 ;	quantum/quantum.c:267: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009F02 90 0B F8         [24] 1057 	mov	dptr,#_get_record_keycode_record_argument_10000_649
      009F05 12 37 FE         [24] 1058 	lcall	_ak820_outline_0007
                                   1059 ;	quantum/quantum.c:272: if (record->keycode) {
      009F08 4C               [12] 1060 	orl	a,r4
      009F09 60 04            [24] 1061 	jz	00102$
                                   1062 ;	quantum/quantum.c:273: return record->keycode;
      009F0B 12 38 97         [24] 1063 	lcall	_ak820_outline_0124
      009F0E 22               [24] 1064 	ret
      009F0F                       1065 00102$:
                                   1066 ;	quantum/quantum.c:277: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      009F0F 12 76 DD         [24] 1067 	lcall	_ak820_outline_0020
      009F12 7A 00            [12] 1068 	mov	r2,#0x00
      009F14 12 43 62         [24] 1069 	lcall	_ak820_outline_0142
      009F17 12 38 12         [24] 1070 	lcall	_ak820_outline_0009
      009F1A 60 06            [24] 1071 	jz	00105$
      009F1C 90 0B F7         [24] 1072 	mov	dptr,#_get_record_keycode_PARM_2
      009F1F E0               [24] 1073 	movx	a,@dptr
      009F20 70 04            [24] 1074 	jnz	00106$
      009F22                       1075 00105$:
                                   1076 ;	assignBit
      009F22 C2 28            [12] 1077 	clr	_get_record_keycode_sloc0_1_0
      009F24 80 02            [24] 1078 	sjmp	00107$
      009F26                       1079 00106$:
                                   1080 ;	assignBit
      009F26 D2 28            [12] 1081 	setb	_get_record_keycode_sloc0_1_0
      009F28                       1082 00107$:
      009F28 90 09 69         [24] 1083 	mov	dptr,#_ak820_resolve_key_PARM_2
      009F2B A2 28            [12] 1084 	mov	c,_get_record_keycode_sloc0_1_0
      009F2D E4               [12] 1085 	clr	a
      009F2E 33               [12] 1086 	rlc	a
      009F2F F0               [24] 1087 	movx	@dptr,a
      009F30 8D 82            [24] 1088 	mov	dpl, r5
      009F32 8C 83            [24] 1089 	mov	dph, r4
                                   1090 ;	quantum/quantum.c:281: }
      009F34 02 7A 84         [24] 1091 	ljmp	_ak820_resolve_key
                                   1092 ;------------------------------------------------------------
                                   1093 ;Allocation info for local variables in function 'get_event_keycode'
                                   1094 ;------------------------------------------------------------
                                   1095 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1096 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_653'
                                   1097 ;------------------------------------------------------------
                                   1098 ;	quantum/quantum.c:289: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1099 ;	-----------------------------------------
                                   1100 ;	 function pre_process_record_quantum
                                   1101 ;	-----------------------------------------
      009F37                       1102 _pre_process_record_quantum:
      009F37 12 43 15         [24] 1103 	lcall	_ak820_outline_0037
      009F3A 90 0B FB         [24] 1104 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_655
      009F3D 12 38 29         [24] 1105 	lcall	_ak820_outline_0017
                                   1106 ;	quantum/quantum.c:322: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009F40 90 0B FB         [24] 1107 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_655
      009F43 12 38 41         [24] 1108 	lcall	_ak820_outline_0051
                                   1109 ;	quantum/quantum.c:326: uint16_t keycode = get_record_keycode(record, true);
      009F46 8E 03            [24] 1110 	mov	ar3,r6
      009F48 8F 04            [24] 1111 	mov	ar4,r7
      009F4A 7D 00            [12] 1112 	mov	r5,#0x00
      009F4C 90 0B F7         [24] 1113 	mov	dptr,#_get_record_keycode_PARM_2
      009F4F 74 01            [12] 1114 	mov	a,#0x01
      009F51 F0               [24] 1115 	movx	@dptr,a
      009F52 12 33 FC         [24] 1116 	lcall	_ak820_outline_0123
      009F55 8D F0            [24] 1117 	mov	b, r5
      009F57 C0 07            [24] 1118 	push	ar7
      009F59 C0 06            [24] 1119 	push	ar6
      009F5B 12 9E F9         [24] 1120 	lcall	_get_record_keycode
      009F5E 12 43 68         [24] 1121 	lcall	_ak820_outline_0149
      009F61 D0 06            [24] 1122 	pop	ar6
      009F63 D0 07            [24] 1123 	pop	ar7
                                   1124 ;	quantum/quantum.c:328: record->keycode = keycode;
      009F65 74 07            [12] 1125 	mov	a,#0x07
      009F67 12 38 31         [24] 1126 	lcall	_ak820_outline_0021
      009F6A 12 38 5E         [24] 1127 	lcall	_ak820_outline_0072
                                   1128 ;	quantum/quantum.c:338: return pre_process_record_kb(keycode, record) &&
      009F6D 90 0B DF         [24] 1129 	mov	dptr,#_pre_process_record_kb_PARM_2
      009F70 12 A2 3D         [24] 1130 	lcall	_ak820_outline_0002
      009F73 C0 07            [24] 1131 	push	ar7
      009F75 C0 06            [24] 1132 	push	ar6
      009F77 12 9E 71         [24] 1133 	lcall	_pre_process_record_kb
      009F7A E5 82            [12] 1134 	mov	a, dpl
      009F7C D0 06            [24] 1135 	pop	ar6
      009F7E D0 07            [24] 1136 	pop	ar7
      009F80 60 0A            [24] 1137 	jz	00103$
                                   1138 ;	quantum/quantum.c:341: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      009F82 12 38 92         [24] 1139 	lcall	_ak820_outline_0119
      009F85 12 36 3B         [24] 1140 	lcall	_ak820_combo_process
      009F88 E5 82            [12] 1141 	mov	a, dpl
      009F8A 70 04            [24] 1142 	jnz	00104$
                                   1143 ;	quantum/quantum.c:346: true;
      009F8C                       1144 00103$:
                                   1145 ;	assignBit
      009F8C C2 29            [12] 1146 	clr	_pre_process_record_quantum_sloc0_1_0
      009F8E 80 02            [24] 1147 	sjmp	00105$
      009F90                       1148 00104$:
                                   1149 ;	assignBit
      009F90 D2 29            [12] 1150 	setb	_pre_process_record_quantum_sloc0_1_0
      009F92                       1151 00105$:
      009F92 A2 29            [12] 1152 	mov	c,_pre_process_record_quantum_sloc0_1_0
      009F94 12 38 B1         [24] 1153 	lcall	_ak820_outline_0156
                                   1154 ;	quantum/quantum.c:347: }
      009F97 22               [24] 1155 	ret
                                   1156 ;------------------------------------------------------------
                                   1157 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1158 ;------------------------------------------------------------
                                   1159 ;record        Allocated with name '_post_process_record_quantum_record_10000_657'
                                   1160 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_658'
                                   1161 ;------------------------------------------------------------
                                   1162 ;	quantum/quantum.c:350: void post_process_record_quantum(keyrecord_t *record) {
                                   1163 ;	-----------------------------------------
                                   1164 ;	 function post_process_record_quantum
                                   1165 ;	-----------------------------------------
      009F98                       1166 _post_process_record_quantum:
      009F98 12 43 15         [24] 1167 	lcall	_ak820_outline_0037
      009F9B 90 0B FE         [24] 1168 	mov	dptr,#_post_process_record_quantum_record_10000_657
      009F9E 12 38 29         [24] 1169 	lcall	_ak820_outline_0017
                                   1170 ;	quantum/quantum.c:351: uint16_t keycode = get_record_keycode(record, false);
      009FA1 90 0B FE         [24] 1171 	mov	dptr,#_post_process_record_quantum_record_10000_657
      009FA4 12 4F 1E         [24] 1172 	lcall	_ak820_outline_0012
      009FA7 90 0B F7         [24] 1173 	mov	dptr,#_get_record_keycode_PARM_2
      009FAA E4               [12] 1174 	clr	a
      009FAB 12 4F 27         [24] 1175 	lcall	_ak820_outline_0034
      009FAE 12 9E F9         [24] 1176 	lcall	_get_record_keycode
      009FB1 12 43 57         [24] 1177 	lcall	_ak820_outline_0134
                                   1178 ;	quantum/quantum.c:352: post_process_record_kb(keycode, record);
      009FB4 90 0B FE         [24] 1179 	mov	dptr,#_post_process_record_quantum_record_10000_657
      009FB7 12 9B E8         [24] 1180 	lcall	_ak820_outline_0025
      009FBA 90 0B EF         [24] 1181 	mov	dptr,#_post_process_record_kb_PARM_2
      009FBD 12 A2 4A         [24] 1182 	lcall	_ak820_outline_0010
                                   1183 ;	quantum/quantum.c:353: }
      009FC0 02 9E B9         [24] 1184 	ljmp	_post_process_record_kb
                                   1185 ;------------------------------------------------------------
                                   1186 ;Allocation info for local variables in function 'process_record_quantum'
                                   1187 ;------------------------------------------------------------
                                   1188 ;record        Allocated with name '_process_record_quantum_record_10000_659'
                                   1189 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_660'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	quantum/quantum.c:355: bool process_record_quantum(keyrecord_t *record) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function process_record_quantum
                                   1194 ;	-----------------------------------------
      009FC3                       1195 _process_record_quantum:
      009FC3 12 43 15         [24] 1196 	lcall	_ak820_outline_0037
      009FC6 90 0C 01         [24] 1197 	mov	dptr,#_process_record_quantum_record_10000_659
      009FC9 12 38 29         [24] 1198 	lcall	_ak820_outline_0017
                                   1199 ;	quantum/quantum.c:357: uint16_t keycode = get_record_keycode(record, false);
      009FCC 90 0C 01         [24] 1200 	mov	dptr,#_process_record_quantum_record_10000_659
      009FCF 12 4F 1E         [24] 1201 	lcall	_ak820_outline_0012
      009FD2 90 0B F7         [24] 1202 	mov	dptr,#_get_record_keycode_PARM_2
      009FD5 E4               [12] 1203 	clr	a
      009FD6 12 4F 27         [24] 1204 	lcall	_ak820_outline_0034
      009FD9 12 9E F9         [24] 1205 	lcall	_get_record_keycode
      009FDC 12 43 57         [24] 1206 	lcall	_ak820_outline_0134
                                   1207 ;	quantum/quantum.c:361: return process_record_quantum_helper(keycode, record);
      009FDF 90 0C 01         [24] 1208 	mov	dptr,#_process_record_quantum_record_10000_659
      009FE2 12 9B E8         [24] 1209 	lcall	_ak820_outline_0025
      009FE5 90 0C 09         [24] 1210 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009FE8 12 A2 4A         [24] 1211 	lcall	_ak820_outline_0010
                                   1212 ;	quantum/quantum.c:362: }
      009FEB 02 A0 59         [24] 1213 	ljmp	_process_record_quantum_helper
                                   1214 ;------------------------------------------------------------
                                   1215 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1216 ;------------------------------------------------------------
                                   1217 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1218 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_661'
                                   1219 ;record        Allocated with name '_process_ak820_nkro_record_10000_662'
                                   1220 ;------------------------------------------------------------
                                   1221 ;	quantum/quantum.c:369: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1222 ;	-----------------------------------------
                                   1223 ;	 function process_ak820_nkro
                                   1224 ;	-----------------------------------------
      009FEE                       1225 _process_ak820_nkro:
      009FEE 12 38 88         [24] 1226 	lcall	_ak820_outline_0108
      009FF1 90 0C 07         [24] 1227 	mov	dptr,#_process_ak820_nkro_keycode_10000_661
      009FF4 12 38 8D         [24] 1228 	lcall	_ak820_outline_0109
                                   1229 ;	quantum/quantum.c:371: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009FF7 90 0C 04         [24] 1230 	mov	dptr,#_process_ak820_nkro_PARM_2
      009FFA 12 38 41         [24] 1231 	lcall	_ak820_outline_0051
                                   1232 ;	quantum/quantum.c:375: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      009FFD 90 0C 07         [24] 1233 	mov	dptr,#_process_ak820_nkro_keycode_10000_661
      00A000 12 38 58         [24] 1234 	lcall	_ak820_outline_0059
      00A003 C3               [12] 1235 	clr	c
      00A004 EC               [12] 1236 	mov	a,r4
      00A005 94 11            [12] 1237 	subb	a,#0x11
      00A007 ED               [12] 1238 	mov	a,r5
      00A008 94 70            [12] 1239 	subb	a,#0x70
      00A00A 40 08            [24] 1240 	jc	00101$
      00A00C 74 13            [12] 1241 	mov	a,#0x13
      00A00E 9C               [12] 1242 	subb	a,r4
      00A00F 74 70            [12] 1243 	mov	a,#0x70
      00A011 9D               [12] 1244 	subb	a,r5
      00A012 50 04            [24] 1245 	jnc	00102$
                                   1246 ;	free result
      00A014                       1247 00101$:
      00A014 75 82 01         [24] 1248 	mov	dpl, #0x01
      00A017 22               [24] 1249 	ret
      00A018                       1250 00102$:
                                   1251 ;	quantum/quantum.c:376: if (record->event.pressed) {
      00A018 12 38 12         [24] 1252 	lcall	_ak820_outline_0009
      00A01B 60 38            [24] 1253 	jz	00105$
                                   1254 ;	quantum/quantum.c:377: clear_keyboard();
      00A01D C0 05            [24] 1255 	push	ar5
      00A01F C0 04            [24] 1256 	push	ar4
      00A021 12 76 7F         [24] 1257 	lcall	_clear_keyboard
      00A024 D0 04            [24] 1258 	pop	ar4
      00A026 D0 05            [24] 1259 	pop	ar5
                                   1260 ;	quantum/quantum.c:378: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A028 BC 13 14         [24] 1261 	cjne	r4,#0x13,00108$
      00A02B BD 70 11         [24] 1262 	cjne	r5,#0x70,00108$
      00A02E 90 0A BE         [24] 1263 	mov	dptr,#_keymap_config
      00A031 E0               [24] 1264 	movx	a,@dptr
      00A032 23               [12] 1265 	rl	a
      00A033 54 01            [12] 1266 	anl	a,#0x01
      00A035 B4 01 00         [24] 1267 	cjne	a,#0x01,00136$
      00A038                       1268 00136$:
      00A038 92 2A            [24] 1269 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A03A E4               [12] 1270 	clr	a
      00A03B 33               [12] 1271 	rlc	a
      00A03C FF               [12] 1272 	mov	r7,a
      00A03D 80 09            [24] 1273 	sjmp	00109$
      00A03F                       1274 00108$:
      00A03F E4               [12] 1275 	clr	a
      00A040 BC 11 04         [24] 1276 	cjne	r4,#0x11,00137$
      00A043 BD 70 01         [24] 1277 	cjne	r5,#0x70,00137$
      00A046 04               [12] 1278 	inc	a
      00A047                       1279 00137$:
      00A047 FF               [12] 1280 	mov	r7,a
      00A048                       1281 00109$:
                                   1282 ;	assignBit
      00A048 EF               [12] 1283 	mov	a,r7
      00A049 24 FF            [12] 1284 	add	a,#0xff
      00A04B E4               [12] 1285 	clr	a
      00A04C 33               [12] 1286 	rlc	a
      00A04D 90 0A BE         [24] 1287 	mov	dptr,#_keymap_config
      00A050 13               [12] 1288 	rrc	a
      00A051 E0               [24] 1289 	movx	a,@dptr
      00A052 92 E7            [24] 1290 	mov	acc.7,c
      00A054 F0               [24] 1291 	movx	@dptr,a
      00A055                       1292 00105$:
                                   1293 ;	quantum/quantum.c:380: return false;
      00A055 75 82 00         [24] 1294 	mov	dpl, #0x00
                                   1295 ;	quantum/quantum.c:381: }
      00A058 22               [24] 1296 	ret
                                   1297 ;------------------------------------------------------------
                                   1298 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1299 ;------------------------------------------------------------
                                   1300 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1301 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_666'
                                   1302 ;record        Allocated with name '_process_record_quantum_helper_record_10000_667'
                                   1303 ;------------------------------------------------------------
                                   1304 ;	quantum/quantum.c:384: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1305 ;	-----------------------------------------
                                   1306 ;	 function process_record_quantum_helper
                                   1307 ;	-----------------------------------------
      00A059                       1308 _process_record_quantum_helper:
      00A059 12 38 88         [24] 1309 	lcall	_ak820_outline_0108
      00A05C 90 0C 0C         [24] 1310 	mov	dptr,#_process_record_quantum_helper_keycode_10000_666
      00A05F 12 38 8D         [24] 1311 	lcall	_ak820_outline_0109
                                   1312 ;	quantum/quantum.c:386: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A062 90 0C 09         [24] 1313 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A065 12 38 41         [24] 1314 	lcall	_ak820_outline_0051
                                   1315 ;	quantum/quantum.c:426: ak820_gui_process(keycode, record->event.pressed) &&
      00A068 90 0C 0C         [24] 1316 	mov	dptr,#_process_record_quantum_helper_keycode_10000_666
      00A06B 12 38 58         [24] 1317 	lcall	_ak820_outline_0059
      00A06E 74 05            [12] 1318 	mov	a,#0x05
      00A070 12 48 93         [24] 1319 	lcall	_ak820_outline_0032
      00A073 90 09 6F         [24] 1320 	mov	dptr,#_ak820_gui_process_PARM_2
      00A076 12 38 76         [24] 1321 	lcall	_ak820_outline_0100
      00A079 C0 07            [24] 1322 	push	ar7
      00A07B C0 06            [24] 1323 	push	ar6
      00A07D C0 05            [24] 1324 	push	ar5
      00A07F C0 04            [24] 1325 	push	ar4
      00A081 C0 03            [24] 1326 	push	ar3
      00A083 C0 02            [24] 1327 	push	ar2
      00A085 12 7B 63         [24] 1328 	lcall	_ak820_gui_process
      00A088 E5 82            [12] 1329 	mov	a, dpl
      00A08A D0 02            [24] 1330 	pop	ar2
      00A08C D0 03            [24] 1331 	pop	ar3
      00A08E D0 04            [24] 1332 	pop	ar4
      00A090 D0 05            [24] 1333 	pop	ar5
      00A092 D0 06            [24] 1334 	pop	ar6
      00A094 D0 07            [24] 1335 	pop	ar7
      00A096 70 03            [24] 1336 	jnz	00212$
      00A098 02 A1 FA         [24] 1337 	ljmp	00101$
      00A09B                       1338 00212$:
                                   1339 ;	quantum/quantum.c:429: process_ak820_nkro(keycode, record) &&
      00A09B 90 0C 04         [24] 1340 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A09E 12 A2 3D         [24] 1341 	lcall	_ak820_outline_0002
      00A0A1 C0 07            [24] 1342 	push	ar7
      00A0A3 C0 06            [24] 1343 	push	ar6
      00A0A5 C0 05            [24] 1344 	push	ar5
      00A0A7 C0 04            [24] 1345 	push	ar4
      00A0A9 C0 03            [24] 1346 	push	ar3
      00A0AB C0 02            [24] 1347 	push	ar2
      00A0AD 12 9F EE         [24] 1348 	lcall	_process_ak820_nkro
      00A0B0 E5 82            [12] 1349 	mov	a, dpl
      00A0B2 D0 02            [24] 1350 	pop	ar2
      00A0B4 D0 03            [24] 1351 	pop	ar3
      00A0B6 D0 04            [24] 1352 	pop	ar4
      00A0B8 D0 05            [24] 1353 	pop	ar5
      00A0BA D0 06            [24] 1354 	pop	ar6
      00A0BC D0 07            [24] 1355 	pop	ar7
      00A0BE 70 03            [24] 1356 	jnz	00213$
      00A0C0 02 A1 FA         [24] 1357 	ljmp	00101$
      00A0C3                       1358 00213$:
                                   1359 ;	quantum/quantum.c:440: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A0C3 90 0B C2         [24] 1360 	mov	dptr,#_process_last_key_PARM_2
      00A0C6 12 A2 3D         [24] 1361 	lcall	_ak820_outline_0002
      00A0C9 C0 07            [24] 1362 	push	ar7
      00A0CB C0 06            [24] 1363 	push	ar6
      00A0CD C0 05            [24] 1364 	push	ar5
      00A0CF C0 04            [24] 1365 	push	ar4
      00A0D1 C0 03            [24] 1366 	push	ar3
      00A0D3 C0 02            [24] 1367 	push	ar2
      00A0D5 12 9B 21         [24] 1368 	lcall	_process_last_key
      00A0D8 E5 82            [12] 1369 	mov	a, dpl
      00A0DA D0 02            [24] 1370 	pop	ar2
      00A0DC D0 03            [24] 1371 	pop	ar3
      00A0DE D0 04            [24] 1372 	pop	ar4
      00A0E0 D0 05            [24] 1373 	pop	ar5
      00A0E2 D0 06            [24] 1374 	pop	ar6
      00A0E4 D0 07            [24] 1375 	pop	ar7
      00A0E6 70 03            [24] 1376 	jnz	00214$
      00A0E8 02 A1 FA         [24] 1377 	ljmp	00101$
      00A0EB                       1378 00214$:
      00A0EB 90 0B C8         [24] 1379 	mov	dptr,#_process_repeat_key_PARM_2
      00A0EE 12 A2 3D         [24] 1380 	lcall	_ak820_outline_0002
      00A0F1 C0 07            [24] 1381 	push	ar7
      00A0F3 C0 06            [24] 1382 	push	ar6
      00A0F5 C0 05            [24] 1383 	push	ar5
      00A0F7 C0 04            [24] 1384 	push	ar4
      00A0F9 C0 03            [24] 1385 	push	ar3
      00A0FB C0 02            [24] 1386 	push	ar2
      00A0FD 12 9B 9F         [24] 1387 	lcall	_process_repeat_key
      00A100 E5 82            [12] 1388 	mov	a, dpl
      00A102 D0 02            [24] 1389 	pop	ar2
      00A104 D0 03            [24] 1390 	pop	ar3
      00A106 D0 04            [24] 1391 	pop	ar4
      00A108 D0 05            [24] 1392 	pop	ar5
      00A10A D0 06            [24] 1393 	pop	ar6
      00A10C D0 07            [24] 1394 	pop	ar7
      00A10E 70 03            [24] 1395 	jnz	00215$
      00A110 02 A1 FA         [24] 1396 	ljmp	00101$
      00A113                       1397 00215$:
                                   1398 ;	quantum/quantum.c:449: process_record_via(keycode, record) &&
      00A113 90 0C 49         [24] 1399 	mov	dptr,#_process_record_via_PARM_2
      00A116 12 A2 3D         [24] 1400 	lcall	_ak820_outline_0002
      00A119 C0 07            [24] 1401 	push	ar7
      00A11B C0 06            [24] 1402 	push	ar6
      00A11D C0 05            [24] 1403 	push	ar5
      00A11F C0 04            [24] 1404 	push	ar4
      00A121 C0 03            [24] 1405 	push	ar3
      00A123 C0 02            [24] 1406 	push	ar2
      00A125 12 A7 4E         [24] 1407 	lcall	_process_record_via
      00A128 E5 82            [12] 1408 	mov	a, dpl
      00A12A D0 02            [24] 1409 	pop	ar2
      00A12C D0 03            [24] 1410 	pop	ar3
      00A12E D0 04            [24] 1411 	pop	ar4
      00A130 D0 05            [24] 1412 	pop	ar5
      00A132 D0 06            [24] 1413 	pop	ar6
      00A134 D0 07            [24] 1414 	pop	ar7
      00A136 70 03            [24] 1415 	jnz	00216$
      00A138 02 A1 FA         [24] 1416 	ljmp	00101$
      00A13B                       1417 00216$:
                                   1418 ;	quantum/quantum.c:459: process_record_kb(keycode, record) &&
      00A13B 90 0B E7         [24] 1419 	mov	dptr,#_process_record_kb_PARM_2
      00A13E 12 A2 3D         [24] 1420 	lcall	_ak820_outline_0002
      00A141 C0 07            [24] 1421 	push	ar7
      00A143 C0 06            [24] 1422 	push	ar6
      00A145 C0 05            [24] 1423 	push	ar5
      00A147 C0 04            [24] 1424 	push	ar4
      00A149 C0 03            [24] 1425 	push	ar3
      00A14B C0 02            [24] 1426 	push	ar2
      00A14D 12 9E 97         [24] 1427 	lcall	_process_record_kb
      00A150 E5 82            [12] 1428 	mov	a, dpl
      00A152 D0 02            [24] 1429 	pop	ar2
      00A154 D0 03            [24] 1430 	pop	ar3
      00A156 D0 04            [24] 1431 	pop	ar4
      00A158 D0 05            [24] 1432 	pop	ar5
      00A15A D0 06            [24] 1433 	pop	ar6
      00A15C D0 07            [24] 1434 	pop	ar7
      00A15E 70 03            [24] 1435 	jnz	00217$
      00A160 02 A1 FA         [24] 1436 	ljmp	00101$
      00A163                       1437 00217$:
                                   1438 ;	quantum/quantum.c:482: process_caps_word(keycode, record) &&
      00A163 90 0B AA         [24] 1439 	mov	dptr,#_process_caps_word_PARM_2
      00A166 12 A2 3D         [24] 1440 	lcall	_ak820_outline_0002
      00A169 C0 07            [24] 1441 	push	ar7
      00A16B C0 06            [24] 1442 	push	ar6
      00A16D C0 05            [24] 1443 	push	ar5
      00A16F C0 04            [24] 1444 	push	ar4
      00A171 C0 03            [24] 1445 	push	ar3
      00A173 C0 02            [24] 1446 	push	ar2
      00A175 12 98 A9         [24] 1447 	lcall	_process_caps_word
      00A178 E5 82            [12] 1448 	mov	a, dpl
      00A17A D0 02            [24] 1449 	pop	ar2
      00A17C D0 03            [24] 1450 	pop	ar3
      00A17E D0 04            [24] 1451 	pop	ar4
      00A180 D0 05            [24] 1452 	pop	ar5
      00A182 D0 06            [24] 1453 	pop	ar6
      00A184 D0 07            [24] 1454 	pop	ar7
      00A186 70 03            [24] 1455 	jnz	00218$
      00A188 02 A1 FA         [24] 1456 	ljmp	00101$
      00A18B                       1457 00218$:
                                   1458 ;	quantum/quantum.c:509: process_grave_esc(keycode, record) &&
      00A18B 90 0B AF         [24] 1459 	mov	dptr,#_process_grave_esc_PARM_2
      00A18E 12 A2 3D         [24] 1460 	lcall	_ak820_outline_0002
      00A191 C0 07            [24] 1461 	push	ar7
      00A193 C0 06            [24] 1462 	push	ar6
      00A195 C0 05            [24] 1463 	push	ar5
      00A197 C0 04            [24] 1464 	push	ar4
      00A199 C0 03            [24] 1465 	push	ar3
      00A19B C0 02            [24] 1466 	push	ar2
      00A19D 12 99 BC         [24] 1467 	lcall	_process_grave_esc
      00A1A0 E5 82            [12] 1468 	mov	a, dpl
      00A1A2 D0 02            [24] 1469 	pop	ar2
      00A1A4 D0 03            [24] 1470 	pop	ar3
      00A1A6 D0 04            [24] 1471 	pop	ar4
      00A1A8 D0 05            [24] 1472 	pop	ar5
      00A1AA D0 06            [24] 1473 	pop	ar6
      00A1AC D0 07            [24] 1474 	pop	ar7
      00A1AE 60 4A            [24] 1475 	jz	00101$
                                   1476 ;	quantum/quantum.c:512: process_rgb(keycode, record) &&
      00A1B0 90 0B CD         [24] 1477 	mov	dptr,#_process_rgb_PARM_2
      00A1B3 12 A2 3D         [24] 1478 	lcall	_ak820_outline_0002
      00A1B6 C0 07            [24] 1479 	push	ar7
      00A1B8 C0 06            [24] 1480 	push	ar6
      00A1BA C0 05            [24] 1481 	push	ar5
      00A1BC C0 04            [24] 1482 	push	ar4
      00A1BE C0 03            [24] 1483 	push	ar3
      00A1C0 C0 02            [24] 1484 	push	ar2
      00A1C2 12 9B F9         [24] 1485 	lcall	_process_rgb
      00A1C5 E5 82            [12] 1486 	mov	a, dpl
      00A1C7 D0 02            [24] 1487 	pop	ar2
      00A1C9 D0 03            [24] 1488 	pop	ar3
      00A1CB D0 04            [24] 1489 	pop	ar4
      00A1CD D0 05            [24] 1490 	pop	ar5
      00A1CF D0 06            [24] 1491 	pop	ar6
      00A1D1 D0 07            [24] 1492 	pop	ar7
      00A1D3 60 25            [24] 1493 	jz	00101$
                                   1494 ;	quantum/quantum.c:524: process_tri_layer(keycode, record) &&
      00A1D5 90 0B D3         [24] 1495 	mov	dptr,#_process_tri_layer_PARM_2
      00A1D8 12 A2 3D         [24] 1496 	lcall	_ak820_outline_0002
      00A1DB C0 07            [24] 1497 	push	ar7
      00A1DD C0 06            [24] 1498 	push	ar6
      00A1DF C0 05            [24] 1499 	push	ar5
      00A1E1 C0 04            [24] 1500 	push	ar4
      00A1E3 C0 03            [24] 1501 	push	ar3
      00A1E5 C0 02            [24] 1502 	push	ar2
      00A1E7 12 9C AA         [24] 1503 	lcall	_process_tri_layer
      00A1EA E5 82            [12] 1504 	mov	a, dpl
      00A1EC D0 02            [24] 1505 	pop	ar2
      00A1EE D0 03            [24] 1506 	pop	ar3
      00A1F0 D0 04            [24] 1507 	pop	ar4
      00A1F2 D0 05            [24] 1508 	pop	ar5
      00A1F4 D0 06            [24] 1509 	pop	ar6
      00A1F6 D0 07            [24] 1510 	pop	ar7
      00A1F8 70 04            [24] 1511 	jnz	00102$
                                   1512 ;	quantum/quantum.c:526: true)) {
      00A1FA                       1513 00101$:
                                   1514 ;	quantum/quantum.c:527: return false;
      00A1FA 75 82 00         [24] 1515 	mov	dpl, #0x00
      00A1FD 22               [24] 1516 	ret
      00A1FE                       1517 00102$:
                                   1518 ;	quantum/quantum.c:530: if (record->event.pressed) {
      00A1FE 12 38 AC         [24] 1519 	lcall	_ak820_outline_0143
      00A201 E0               [24] 1520 	movx	a,@dptr
      00A202 60 30            [24] 1521 	jz	00118$
                                   1522 ;	quantum/quantum.c:531: switch (keycode) {
      00A204 BC 00 05         [24] 1523 	cjne	r4,#0x00,00223$
      00A207 BD 7C 02         [24] 1524 	cjne	r5,#0x7c,00223$
      00A20A 80 10            [24] 1525 	sjmp	00113$
      00A20C                       1526 00223$:
      00A20C BC 01 05         [24] 1527 	cjne	r4,#0x01,00224$
      00A20F BD 7C 02         [24] 1528 	cjne	r5,#0x7c,00224$
      00A212 80 0F            [24] 1529 	sjmp	00114$
      00A214                       1530 00224$:
                                   1531 ;	quantum/quantum.c:533: case QK_BOOTLOADER:
      00A214 BC 03 1D         [24] 1532 	cjne	r4,#0x03,00118$
      00A217 BD 7C 1A         [24] 1533 	cjne	r5,#0x7c,00118$
      00A21A 80 0E            [24] 1534 	sjmp	00115$
      00A21C                       1535 00113$:
                                   1536 ;	quantum/quantum.c:534: reset_keyboard();
      00A21C 12 9E ED         [24] 1537 	lcall	_reset_keyboard
                                   1538 ;	quantum/quantum.c:535: return false;
      00A21F 75 82 00         [24] 1539 	mov	dpl, #0x00
                                   1540 ;	quantum/quantum.c:536: case QK_REBOOT:
      00A222 22               [24] 1541 	ret
      00A223                       1542 00114$:
                                   1543 ;	quantum/quantum.c:537: soft_reset_keyboard();
      00A223 12 9E F3         [24] 1544 	lcall	_soft_reset_keyboard
                                   1545 ;	quantum/quantum.c:538: return false;
      00A226 75 82 00         [24] 1546 	mov	dpl, #0x00
                                   1547 ;	quantum/quantum.c:550: case QK_CLEAR_EEPROM:
      00A229 22               [24] 1548 	ret
      00A22A                       1549 00115$:
                                   1550 ;	quantum/quantum.c:557: eeconfig_disable();
      00A22A 12 90 12         [24] 1551 	lcall	_eeconfig_disable
                                   1552 ;	quantum/quantum.c:558: soft_reset_keyboard();
      00A22D 12 9E F3         [24] 1553 	lcall	_soft_reset_keyboard
                                   1554 ;	quantum/quantum.c:560: return false;
      00A230 75 82 00         [24] 1555 	mov	dpl, #0x00
                                   1556 ;	quantum/quantum.c:615: }
      00A233 22               [24] 1557 	ret
      00A234                       1558 00118$:
                                   1559 ;	quantum/quantum.c:618: return process_action_kb(record);
      00A234 7D 00            [12] 1560 	mov	r5,#0x00
      00A236 12 6F A4         [24] 1561 	lcall	_ak820_outline_0064
                                   1562 ;	quantum/quantum.c:619: }
      00A239 02 9E 93         [24] 1563 	ljmp	_process_action_kb
                                   1564 ;------------------------------------------------------------
                                   1565 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1566 ;------------------------------------------------------------
                                   1567 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_674'
                                   1568 ;------------------------------------------------------------
                                   1569 ;	quantum/quantum.c:621: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1570 ;	-----------------------------------------
                                   1571 ;	 function shutdown_user
                                   1572 ;	-----------------------------------------
      00A23C                       1573 _shutdown_user:
      00A23C 22               [24] 1574 	ret
                                   1575 ;------------------------------------------------------------
                                   1576 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1577 ;------------------------------------------------------------
                                   1578 ;	quantum/quantum.c:637: void suspend_power_down_quantum(void) {
                                   1579 ;	-----------------------------------------
                                   1580 	.area CSEG    (CODE)
                                   1581 	.area CONST   (CODE)
                                   1582 	.area XINIT   (CODE)
                                   1583 	.area CABS    (ABS,CODE)
                                   1584 
                                   1585 ; Experimental exact instruction outlining.
                                   1586 	.globl _ak820_outline_0002
                                   1587 	.globl _ak820_outline_0005
                                   1588 	.globl _ak820_outline_0007
                                   1589 	.globl _ak820_outline_0009
                                   1590 	.globl _ak820_outline_0010
                                   1591 	.globl _ak820_outline_0012
                                   1592 	.globl _ak820_outline_0017
                                   1593 	.globl _ak820_outline_0020
                                   1594 	.globl _ak820_outline_0021
                                   1595 	.globl _ak820_outline_0025
                                   1596 	.globl _ak820_outline_0032
                                   1597 	.globl _ak820_outline_0034
                                   1598 	.globl _ak820_outline_0037
                                   1599 	.globl _ak820_outline_0040
                                   1600 	.globl _ak820_outline_0051
                                   1601 	.globl _ak820_outline_0059
                                   1602 	.globl _ak820_outline_0064
                                   1603 	.globl _ak820_outline_0072
                                   1604 	.globl _ak820_outline_0100
                                   1605 	.globl _ak820_outline_0108
                                   1606 	.globl _ak820_outline_0109
                                   1607 	.globl _ak820_outline_0119
                                   1608 	.globl _ak820_outline_0120
                                   1609 	.globl _ak820_outline_0123
                                   1610 	.globl _ak820_outline_0124
                                   1611 	.globl _ak820_outline_0134
                                   1612 	.globl _ak820_outline_0142
                                   1613 	.globl _ak820_outline_0143
                                   1614 	.globl _ak820_outline_0149
                                   1615 	.globl _ak820_outline_0156
                                   1616 
                                   1617 	.area CSEG (CODE)
                                   1618 ; function ak820_outline_0002
      00A23D                       1619 _ak820_outline_0002:
      00A23D EE               [12] 1620 	mov	a,r6
      00A23E F0               [24] 1621 	movx	@dptr,a
      00A23F EF               [12] 1622 	mov	a,r7
      00A240 A3               [24] 1623 	inc	dptr
      00A241 F0               [24] 1624 	movx	@dptr,a
      00A242 E4               [12] 1625 	clr	a
      00A243 A3               [24] 1626 	inc	dptr
      00A244 F0               [24] 1627 	movx	@dptr,a
      00A245 8C 82            [24] 1628 	mov	dpl,r4
      00A247 8D 83            [24] 1629 	mov	dph,r5
      00A249 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0010
      00A24A                       1634 _ak820_outline_0010:
      00A24A EB               [12] 1635 	mov	a,r3
      00A24B F0               [24] 1636 	movx	@dptr,a
      00A24C EC               [12] 1637 	mov	a,r4
      00A24D A3               [24] 1638 	inc	dptr
      00A24E F0               [24] 1639 	movx	@dptr,a
      00A24F ED               [12] 1640 	mov	a,r5
      00A250 A3               [24] 1641 	inc	dptr
      00A251 F0               [24] 1642 	movx	@dptr,a
      00A252 8E 82            [24] 1643 	mov	dpl,r6
      00A254 8F 83            [24] 1644 	mov	dph,r7
      00A256 22               [24] 1645 	ret
