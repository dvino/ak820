                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _post_process_record_quantum
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000027                        588 _process_action_sloc0_1_0:
      000027                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      00001F                        606 _process_action_sloc1_1_0:
      00001F                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      00080E                        616 _tp_buttons::
      00080E                        617 	.ds 2
      000810                        618 _action_exec_PARM_1:
      000810                        619 	.ds 6
      000816                        620 _action_exec_record_10001_625:
      000816                        621 	.ds 9
      00081F                        622 _ak820_action_exec_event_10000_629:
      00081F                        623 	.ds 2
      000821                        624 _ak820_action_exec_snapshot_10000_630:
      000821                        625 	.ds 6
      000827                        626 _process_record_record_10000_633:
      000827                        627 	.ds 3
      00082A                        628 _process_record_handler_record_argument_10000_641:
      00082A                        629 	.ds 3
      00082D                        630 _process_record_handler_action_10000_642:
      00082D                        631 	.ds 2
      00082F                        632 _process_action_PARM_2:
      00082F                        633 	.ds 2
      000831                        634 _process_action_record_argument_10000_653:
      000831                        635 	.ds 3
      000834                        636 _process_action_on_40000_676:
      000834                        637 	.ds 1
      000835                        638 _register_code_code_10000_710:
      000835                        639 	.ds 1
      000836                        640 _unregister_code_code_10000_724:
      000836                        641 	.ds 1
      000837                        642 _tap_code_delay_PARM_2:
      000837                        643 	.ds 2
      000839                        644 _tap_code_delay_code_10000_737:
      000839                        645 	.ds 1
      00083A                        646 _tap_code_code_10000_744:
      00083A                        647 	.ds 1
      00083B                        648 _register_mods_mods_10000_746:
      00083B                        649 	.ds 1
      00083C                        650 _unregister_mods_mods_10000_750:
      00083C                        651 	.ds 1
      00083D                        652 _register_weak_mods_mods_10000_754:
      00083D                        653 	.ds 1
      00083E                        654 _unregister_weak_mods_mods_10000_758:
      00083E                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DC0                        664 _disable_action_cache::
      000DC0                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      00702C                        709 _action_exec:
                                    710 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      00702C 90 08 12         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00702F 12 37 F4         [24]  712 	lcall	_ak820_outline_0005
      007032 12 36 04         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      007035 90 08 10         [24]  715 	mov	dptr,#_action_exec_PARM_1
      007038 12 44 4E         [24]  716 	lcall	_ak820_tapping_before
      00703B E5 82            [12]  717 	mov	a, dpl
      00703D 70 01            [24]  718 	jnz	00102$
      00703F 22               [24]  719 	ret
      007040                        720 00102$:
                                    721 ;	quantum/action.c:116: if (event.pressed) {
      007040 90 08 15         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007043 E0               [24]  723 	movx	a,@dptr
      007044 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:118: clear_weak_mods();
      007046 12 81 54         [24]  726 	lcall	_clear_weak_mods
      007049                        727 00104$:
                                    728 ;	quantum/action.c:130: record.event = event;
      007049 90 0D A0         [24]  729 	mov	dptr,#___memcpy_PARM_2
      00704C 74 10            [12]  730 	mov	a,#_action_exec_PARM_1
      00704E F0               [24]  731 	movx	@dptr,a
      00704F 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      007051 12 38 70         [24]  733 	lcall	_ak820_outline_0092
      007054 12 76 FC         [24]  734 	lcall	_ak820_outline_0070
      007057 90 08 16         [24]  735 	mov	dptr,#_action_exec_record_10001_625
      00705A F5 F0            [12]  736 	mov	b,a
      00705C 12 B9 05         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:132: record.tap.count = 0;
      00705F 90 08 1C         [24]  739 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      007062 E0               [24]  740 	movx	a,@dptr
      007063 54 0F            [12]  741 	anl	a,#0x0f
      007065 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:137: record.keycode = 0;
      007066 90 08 1D         [24]  744 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      007069 12 4F 71         [24]  745 	lcall	_ak820_outline_0183
                                    746 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00706C 90 08 1A         [24]  747 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      00706F E0               [24]  748 	movx	a,@dptr
      007070 60 0D            [24]  749 	jz	00107$
      007072 90 08 16         [24]  750 	mov	dptr,#_action_exec_record_10001_625
      007075 75 F0 00         [24]  751 	mov	b, #0x00
      007078 12 9F 37         [24]  752 	lcall	_pre_process_record_quantum
      00707B E5 82            [12]  753 	mov	a, dpl
      00707D 60 14            [24]  754 	jz	00110$
      00707F                        755 00107$:
                                    756 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      00707F 90 08 16         [24]  757 	mov	dptr,#_action_exec_record_10001_625
      007082 12 45 2D         [24]  758 	lcall	_ak820_tapping_process
      007085 E5 82            [12]  759 	mov	a, dpl
      007087 70 01            [24]  760 	jnz	00106$
      007089 22               [24]  761 	ret
      00708A                        762 00106$:
                                    763 ;	quantum/action.c:175: process_record(&record);
      00708A 90 08 16         [24]  764 	mov	dptr,#_action_exec_record_10001_625
      00708D 75 F0 00         [24]  765 	mov	b, #0x00
                                    766 ;	quantum/action.c:190: }
      007090 02 70 D0         [24]  767 	ljmp	_process_record
      007093                        768 00110$:
      007093 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'ak820_action_exec'
                                    772 ;------------------------------------------------------------
                                    773 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    774 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    775 ;------------------------------------------------------------
                                    776 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_action_exec
                                    779 ;	-----------------------------------------
      007094                        780 _ak820_action_exec:
      007094 12 38 88         [24]  781 	lcall	_ak820_outline_0108
      007097 90 08 1F         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_629
      00709A 12 38 8D         [24]  783 	lcall	_ak820_outline_0109
                                    784 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      00709D 90 08 1F         [24]  785 	mov	dptr,#_ak820_action_exec_event_10000_629
      0070A0 12 38 6A         [24]  786 	lcall	_ak820_outline_0084
      0070A3 7F 00            [12]  787 	mov	r7,#0x00
      0070A5 90 0D A0         [24]  788 	mov	dptr,#___memcpy_PARM_2
      0070A8 ED               [12]  789 	mov	a,r5
      0070A9 12 38 29         [24]  790 	lcall	_ak820_outline_0017
      0070AC 12 76 FC         [24]  791 	lcall	_ak820_outline_0070
      0070AF 90 08 21         [24]  792 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      0070B2 F5 F0            [12]  793 	mov	b,a
      0070B4 12 B9 05         [24]  794 	lcall	___memcpy
                                    795 ;	quantum/action.c:197: action_exec(snapshot);
      0070B7 90 0D A0         [24]  796 	mov	dptr,#___memcpy_PARM_2
      0070BA 74 21            [12]  797 	mov	a,#_ak820_action_exec_snapshot_10000_630
      0070BC F0               [24]  798 	movx	@dptr,a
      0070BD 74 08            [12]  799 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      0070BF 12 38 70         [24]  800 	lcall	_ak820_outline_0092
      0070C2 12 76 FC         [24]  801 	lcall	_ak820_outline_0070
      0070C5 90 08 10         [24]  802 	mov	dptr,#_action_exec_PARM_1
      0070C8 F5 F0            [12]  803 	mov	b,a
      0070CA 12 B9 05         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:198: }
      0070CD 02 70 2C         [24]  806 	ljmp	_action_exec
                                    807 ;------------------------------------------------------------
                                    808 ;Allocation info for local variables in function 'process_record_nocache'
                                    809 ;------------------------------------------------------------
                                    810 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    811 ;------------------------------------------------------------
                                    812 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    813 ;	-----------------------------------------
                                    814 ;	 function process_record
                                    815 ;	-----------------------------------------
      0070D0                        816 _process_record:
      0070D0 12 43 15         [24]  817 	lcall	_ak820_outline_0037
      0070D3 90 08 27         [24]  818 	mov	dptr,#_process_record_record_10000_633
      0070D6 12 38 29         [24]  819 	lcall	_ak820_outline_0017
                                    820 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      0070D9 90 08 27         [24]  821 	mov	dptr,#_process_record_record_10000_633
      0070DC 12 4F 1E         [24]  822 	lcall	_ak820_outline_0012
      0070DF 74 04            [12]  823 	mov	a,#0x04
      0070E1 12 76 CF         [24]  824 	lcall	_ak820_outline_0014
      0070E4 12 B9 DE         [24]  825 	lcall	__gptrget
      0070E7 70 01            [24]  826 	jnz	00102$
                                    827 ;	quantum/action.c:338: return;
      0070E9 22               [24]  828 	ret
      0070EA                        829 00102$:
                                    830 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0070EA 8D 02            [24]  831 	mov	ar2,r5
      0070EC 8E 03            [24]  832 	mov	ar3,r6
      0070EE 8F 04            [24]  833 	mov	ar4,r7
      0070F0 90 0D A0         [24]  834 	mov	dptr,#___memcpy_PARM_2
      0070F3 EA               [12]  835 	mov	a,r2
      0070F4 12 77 43         [24]  836 	lcall	_ak820_outline_0188
      0070F7 EC               [12]  837 	mov	a,r4
      0070F8 A3               [24]  838 	inc	dptr
      0070F9 F0               [24]  839 	movx	@dptr,a
      0070FA 90 0D A3         [24]  840 	mov	dptr,#___memcpy_PARM_3
      0070FD 12 4F 63         [24]  841 	lcall	_ak820_outline_0111
      007100 90 06 24         [24]  842 	mov	dptr,#_ak820_tapping_source_PARM_1
      007103 F5 F0            [12]  843 	mov	b,a
      007105 C0 07            [24]  844 	push	ar7
      007107 C0 06            [24]  845 	push	ar6
      007109 C0 05            [24]  846 	push	ar5
      00710B 12 B9 05         [24]  847 	lcall	___memcpy
      00710E 12 43 88         [24]  848 	lcall	_ak820_tapping_source
      007111 AC 82            [24]  849 	mov	r4, dpl
      007113 D0 05            [24]  850 	pop	ar5
      007115 D0 06            [24]  851 	pop	ar6
      007117 D0 07            [24]  852 	pop	ar7
                                    853 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      007119 74 05            [12]  854 	mov	a,#0x05
      00711B 12 76 C1         [24]  855 	lcall	_ak820_outline_0013
      00711E 12 B9 DE         [24]  856 	lcall	__gptrget
      007121 FB               [12]  857 	mov	r3,a
                                    858 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      007122 12 77 28         [24]  859 	lcall	_ak820_outline_0146
      007125 90 0B F7         [24]  860 	mov	dptr,#_get_record_keycode_PARM_2
      007128 74 01            [12]  861 	mov	a,#0x01
      00712A 12 4F 27         [24]  862 	lcall	_ak820_outline_0034
      00712D C0 04            [24]  863 	push	ar4
      00712F C0 03            [24]  864 	push	ar3
      007131 C0 02            [24]  865 	push	ar2
      007133 C0 01            [24]  866 	push	ar1
      007135 C0 00            [24]  867 	push	ar0
      007137 12 9E F9         [24]  868 	lcall	_get_record_keycode
      00713A 12 43 57         [24]  869 	lcall	_ak820_outline_0134
      00713D D0 00            [24]  870 	pop	ar0
      00713F D0 01            [24]  871 	pop	ar1
      007141 D0 02            [24]  872 	pop	ar2
      007143 D0 03            [24]  873 	pop	ar3
      007145 D0 04            [24]  874 	pop	ar4
      007147 12 48 E7         [24]  875 	lcall	_ak820_outline_0113
      00714A EE               [12]  876 	mov	a,r6
      00714B 12 B9 A3         [24]  877 	lcall	__gptrput
      00714E A3               [24]  878 	inc	dptr
      00714F EF               [12]  879 	mov	a,r7
      007150 12 B9 A3         [24]  880 	lcall	__gptrput
                                    881 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007153 90 08 27         [24]  882 	mov	dptr,#_process_record_record_10000_633
      007156 12 4F 1E         [24]  883 	lcall	_ak820_outline_0012
      007159 12 77 28         [24]  884 	lcall	_ak820_outline_0146
      00715C 12 48 E7         [24]  885 	lcall	_ak820_outline_0113
      00715F 12 B9 DE         [24]  886 	lcall	__gptrget
      007162 F8               [12]  887 	mov	r0,a
      007163 A3               [24]  888 	inc	dptr
      007164 12 B9 DE         [24]  889 	lcall	__gptrget
      007167 F9               [12]  890 	mov	r1,a
      007168 90 06 34         [24]  891 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00716B EC               [12]  892 	mov	a,r4
      00716C F0               [24]  893 	movx	@dptr,a
      00716D 90 06 35         [24]  894 	mov	dptr,#_ak820_oneshot_process_PARM_3
      007170 EB               [12]  895 	mov	a,r3
      007171 F0               [24]  896 	movx	@dptr,a
      007172 12 38 B6         [24]  897 	lcall	_ak820_outline_0157
      007175 C0 07            [24]  898 	push	ar7
      007177 C0 06            [24]  899 	push	ar6
      007179 C0 05            [24]  900 	push	ar5
      00717B C0 04            [24]  901 	push	ar4
      00717D C0 03            [24]  902 	push	ar3
      00717F 12 46 E6         [24]  903 	lcall	_ak820_oneshot_process
      007182 E5 82            [12]  904 	mov	a, dpl
      007184 D0 03            [24]  905 	pop	ar3
      007186 D0 04            [24]  906 	pop	ar4
      007188 D0 05            [24]  907 	pop	ar5
      00718A D0 06            [24]  908 	pop	ar6
      00718C D0 07            [24]  909 	pop	ar7
      00718E 70 01            [24]  910 	jnz	00104$
      007190 22               [24]  911 	ret
      007191                        912 00104$:
                                    913 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      007191 12 6D 8E         [24]  914 	lcall	_ak820_outline_0057
      007194 C0 04            [24]  915 	push	ar4
      007196 C0 03            [24]  916 	push	ar3
      007198 12 9F C3         [24]  917 	lcall	_process_record_quantum
      00719B E5 82            [12]  918 	mov	a, dpl
      00719D D0 03            [24]  919 	pop	ar3
      00719F D0 04            [24]  920 	pop	ar4
      0071A1 70 0A            [24]  921 	jnz	00106$
                                    922 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0071A3 90 05 9C         [24]  923 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0071A6 EB               [12]  924 	mov	a,r3
      0071A7 F0               [24]  925 	movx	@dptr,a
      0071A8 8C 82            [24]  926 	mov	dpl, r4
                                    927 ;	quantum/action.c:360: return;
      0071AA 02 2E BB         [24]  928 	ljmp	_ak820_oneshot_post
      0071AD                        929 00106$:
                                    930 ;	quantum/action.c:366: process_record_handler(record);
      0071AD 90 08 27         [24]  931 	mov	dptr,#_process_record_record_10000_633
      0071B0 12 4E F8         [24]  932 	lcall	_ak820_outline_0001
      0071B3 C0 04            [24]  933 	push	ar4
      0071B5 C0 03            [24]  934 	push	ar3
      0071B7 12 71 D1         [24]  935 	lcall	_process_record_handler
                                    936 ;	quantum/action.c:370: post_process_record_quantum(record);
      0071BA 90 08 27         [24]  937 	mov	dptr,#_process_record_record_10000_633
      0071BD 12 4E F8         [24]  938 	lcall	_ak820_outline_0001
      0071C0 12 9F 98         [24]  939 	lcall	_post_process_record_quantum
      0071C3 D0 03            [24]  940 	pop	ar3
      0071C5 D0 04            [24]  941 	pop	ar4
                                    942 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0071C7 90 05 9C         [24]  943 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0071CA EB               [12]  944 	mov	a,r3
      0071CB F0               [24]  945 	movx	@dptr,a
      0071CC 8C 82            [24]  946 	mov	dpl, r4
                                    947 ;	quantum/action.c:374: }
      0071CE 02 2E BB         [24]  948 	ljmp	_ak820_oneshot_post
                                    949 ;------------------------------------------------------------
                                    950 ;Allocation info for local variables in function 'process_record_handler'
                                    951 ;------------------------------------------------------------
                                    952 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    953 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    954 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function process_record_handler
                                    959 ;	-----------------------------------------
      0071D1                        960 _process_record_handler:
      0071D1 12 43 15         [24]  961 	lcall	_ak820_outline_0037
      0071D4 90 08 2A         [24]  962 	mov	dptr,#_process_record_handler_record_argument_10000_641
      0071D7 12 38 29         [24]  963 	lcall	_ak820_outline_0017
                                    964 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0071DA 90 08 2A         [24]  965 	mov	dptr,#_process_record_handler_record_argument_10000_641
      0071DD 12 37 FE         [24]  966 	lcall	_ak820_outline_0007
                                    967 ;	quantum/action.c:387: if (record->keycode) {
      0071E0 4C               [12]  968 	orl	a,r4
      0071E1 60 19            [24]  969 	jz	00102$
                                    970 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      0071E3 12 38 97         [24]  971 	lcall	_ak820_outline_0124
      0071E6 C0 07            [24]  972 	push	ar7
      0071E8 C0 06            [24]  973 	push	ar6
      0071EA 12 95 35         [24]  974 	lcall	_action_for_keycode
      0071ED 12 43 68         [24]  975 	lcall	_ak820_outline_0149
      0071F0 D0 06            [24]  976 	pop	ar6
      0071F2 D0 07            [24]  977 	pop	ar7
      0071F4 90 08 2D         [24]  978 	mov	dptr,#_process_record_handler_action_10000_642
      0071F7 12 38 5E         [24]  979 	lcall	_ak820_outline_0072
      0071FA 80 2B            [24]  980 	sjmp	00104$
      0071FC                        981 00102$:
                                    982 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0071FC 12 76 DD         [24]  983 	lcall	_ak820_outline_0020
      0071FF 7A 00            [12]  984 	mov	r2,#0x00
      007201 12 43 62         [24]  985 	lcall	_ak820_outline_0142
      007204 12 43 03         [24]  986 	lcall	_ak820_outline_0011
      007207 E0               [24]  987 	movx	a,@dptr
      007208 90 09 69         [24]  988 	mov	dptr,#_ak820_resolve_key_PARM_2
      00720B F0               [24]  989 	movx	@dptr,a
      00720C 8D 82            [24]  990 	mov	dpl, r5
      00720E 8C 83            [24]  991 	mov	dph, r4
      007210 C0 07            [24]  992 	push	ar7
      007212 C0 06            [24]  993 	push	ar6
      007214 12 7A 84         [24]  994 	lcall	_ak820_resolve_key
      007217 12 95 35         [24]  995 	lcall	_action_for_keycode
      00721A 12 43 68         [24]  996 	lcall	_ak820_outline_0149
      00721D D0 06            [24]  997 	pop	ar6
      00721F D0 07            [24]  998 	pop	ar7
      007221 90 08 2D         [24]  999 	mov	dptr,#_process_record_handler_action_10000_642
      007224 12 38 5E         [24] 1000 	lcall	_ak820_outline_0072
                                   1001 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      007227                       1002 00104$:
                                   1003 ;	quantum/action.c:411: process_action(record, action);
      007227 7D 00            [12] 1004 	mov	r5,#0x00
      007229 90 0D A0         [24] 1005 	mov	dptr,#___memcpy_PARM_2
      00722C 74 2D            [12] 1006 	mov	a,#_process_record_handler_action_10000_642
      00722E F0               [24] 1007 	movx	@dptr,a
      00722F 74 08            [12] 1008 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      007231 12 38 70         [24] 1009 	lcall	_ak820_outline_0092
      007234 90 0D A3         [24] 1010 	mov	dptr,#___memcpy_PARM_3
      007237 12 4F 63         [24] 1011 	lcall	_ak820_outline_0111
      00723A 90 08 2F         [24] 1012 	mov	dptr,#_process_action_PARM_2
      00723D F5 F0            [12] 1013 	mov	b,a
      00723F C0 07            [24] 1014 	push	ar7
      007241 C0 06            [24] 1015 	push	ar6
      007243 C0 05            [24] 1016 	push	ar5
      007245 12 B9 05         [24] 1017 	lcall	___memcpy
      007248 D0 05            [24] 1018 	pop	ar5
      00724A D0 06            [24] 1019 	pop	ar6
      00724C D0 07            [24] 1020 	pop	ar7
      00724E 12 6F A4         [24] 1021 	lcall	_ak820_outline_0064
                                   1022 ;	quantum/action.c:412: }
      007251 02 72 54         [24] 1023 	ljmp	_process_action
                                   1024 ;------------------------------------------------------------
                                   1025 ;Allocation info for local variables in function 'register_mouse'
                                   1026 ;------------------------------------------------------------
                                   1027 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1028 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function process_action
                                   1033 ;	-----------------------------------------
      007254                       1034 _process_action:
      007254 12 43 15         [24] 1035 	lcall	_ak820_outline_0037
      007257 90 08 31         [24] 1036 	mov	dptr,#_process_action_record_argument_10000_653
      00725A 12 38 29         [24] 1037 	lcall	_ak820_outline_0017
                                   1038 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00725D 90 08 31         [24] 1039 	mov	dptr,#_process_action_record_argument_10000_653
      007260 12 37 F4         [24] 1040 	lcall	_ak820_outline_0005
                                   1041 ;	quantum/action.c:483: pressed = record->event.pressed;
      007263 A3               [24] 1042 	inc	dptr
      007264 A3               [24] 1043 	inc	dptr
      007265 A3               [24] 1044 	inc	dptr
      007266 A3               [24] 1045 	inc	dptr
      007267 A3               [24] 1046 	inc	dptr
      007268 E0               [24] 1047 	movx	a,@dptr
      007269 F5 27            [12] 1048 	mov	_process_action_sloc0_1_0,a
                                   1049 ;	quantum/action.c:507: switch (action.kind.id) {
      00726B 90 08 30         [24] 1050 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00726E E0               [24] 1051 	movx	a,@dptr
      00726F C4               [12] 1052 	swap	a
      007270 54 0F            [12] 1053 	anl	a,#0x0f
      007272 FD               [12] 1054 	mov  r5,a
      007273 24 F4            [12] 1055 	add	a,#0xff - 0x0b
      007275 50 03            [24] 1056 	jnc	00434$
      007277 02 74 F5         [24] 1057 	ljmp	00181$
      00727A                       1058 00434$:
                                   1059 ;	free result
      00727A ED               [12] 1060 	mov	a,r5
      00727B 24 0A            [12] 1061 	add	a,#(00435$-3-.)
      00727D 83               [24] 1062 	movc	a,@a+pc
      00727E F5 82            [12] 1063 	mov	dpl,a
      007280 ED               [12] 1064 	mov	a,r5
      007281 24 10            [12] 1065 	add	a,#(00436$-3-.)
      007283 83               [24] 1066 	movc	a,@a+pc
      007284 F5 83            [12] 1067 	mov	dph,a
      007286 E4               [12] 1068 	clr	a
      007287 73               [24] 1069 	jmp	@a+dptr
      007288                       1070 00435$:
      007288 A0                    1071 	.db	00102$
      007289 A0                    1072 	.db	00102$
      00728A F5                    1073 	.db	00181$
      00728B F5                    1074 	.db	00181$
      00728C 2A                    1075 	.db	00123$
      00728D F5                    1076 	.db	00181$
      00728E F5                    1077 	.db	00181$
      00728F F5                    1078 	.db	00181$
      007290 8A                    1079 	.db	00131$
      007291 5C                    1080 	.db	00147$
      007292 82                    1081 	.db	00152$
      007293 82                    1082 	.db	00152$
      007294                       1083 00436$:
      007294 72                    1084 	.db	00102$>>8
      007295 72                    1085 	.db	00102$>>8
      007296 74                    1086 	.db	00181$>>8
      007297 74                    1087 	.db	00181$>>8
      007298 73                    1088 	.db	00123$>>8
      007299 74                    1089 	.db	00181$>>8
      00729A 74                    1090 	.db	00181$>>8
      00729B 74                    1091 	.db	00181$>>8
      00729C 73                    1092 	.db	00131$>>8
      00729D 74                    1093 	.db	00147$>>8
      00729E 74                    1094 	.db	00152$>>8
      00729F 74                    1095 	.db	00152$>>8
                                   1096 ;	quantum/action.c:510: case ACT_RMODS: {
      0072A0                       1097 00102$:
                                   1098 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0072A0 90 08 30         [24] 1099 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0072A3 E0               [24] 1100 	movx	a,@dptr
      0072A4 54 F0            [12] 1101 	anl	a,#0xf0
      0072A6 70 06            [24] 1102 	jnz	00194$
      0072A8 12 77 16         [24] 1103 	lcall	_ak820_outline_0114
      0072AB FD               [12] 1104 	mov	r5,a
      0072AC 80 07            [24] 1105 	sjmp	00195$
      0072AE                       1106 00194$:
      0072AE 12 77 16         [24] 1107 	lcall	_ak820_outline_0114
      0072B1 C4               [12] 1108 	swap	a
      0072B2 54 F0            [12] 1109 	anl	a,#0xf0
      0072B4 FD               [12] 1110 	mov	r5,a
      0072B5                       1111 00195$:
                                   1112 ;	quantum/action.c:513: if (pressed) {
      0072B5 E5 27            [12] 1113 	mov	a,_process_action_sloc0_1_0
      0072B7 60 35            [24] 1114 	jz	00119$
                                   1115 ;	quantum/action.c:514: if (mods) {
      0072B9 ED               [12] 1116 	mov	a,r5
      0072BA 60 29            [24] 1117 	jz	00110$
                                   1118 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0072BC 12 77 32         [24] 1119 	lcall	_ak820_outline_0159
      0072BF FC               [12] 1120 	mov	r4,a
      0072C0 BC E0 00         [24] 1121 	cjne	r4,#0xe0,00440$
      0072C3                       1122 00440$:
      0072C3 40 07            [24] 1123 	jc	00108$
      0072C5 12 77 32         [24] 1124 	lcall	_ak820_outline_0159
      0072C8 24 18            [12] 1125 	add	a,#0xff - 0xe7
      0072CA 50 0A            [24] 1126 	jnc	00104$
                                   1127 ;	free result
      0072CC                       1128 00108$:
      0072CC 7B 2F            [12] 1129 	mov	r3,#_process_action_PARM_2
      0072CE 7C 08            [12] 1130 	mov	r4,#(_process_action_PARM_2 >> 8)
      0072D0 12 33 FC         [24] 1131 	lcall	_ak820_outline_0123
      0072D3 E0               [24] 1132 	movx	a,@dptr
      0072D4 70 07            [24] 1133 	jnz	00105$
      0072D6                       1134 00104$:
                                   1135 ;	quantum/action.c:519: add_owned_mods(mods);
      0072D6 8D 82            [24] 1136 	mov	dpl, r5
      0072D8 12 7D 2B         [24] 1137 	lcall	_add_owned_mods
      0072DB 80 05            [24] 1138 	sjmp	00106$
      0072DD                       1139 00105$:
                                   1140 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      0072DD 8D 82            [24] 1141 	mov	dpl, r5
      0072DF 12 7D 4A         [24] 1142 	lcall	_add_owned_weak_mods
      0072E2                       1143 00106$:
                                   1144 ;	quantum/action.c:523: send_keyboard_report();
      0072E2 12 80 67         [24] 1145 	lcall	_send_keyboard_report
      0072E5                       1146 00110$:
                                   1147 ;	quantum/action.c:525: register_code(action.key.code);
      0072E5 12 77 06         [24] 1148 	lcall	_ak820_outline_0077
      0072E8 12 75 0C         [24] 1149 	lcall	_register_code
      0072EB 02 74 F5         [24] 1150 	ljmp	00181$
      0072EE                       1151 00119$:
                                   1152 ;	quantum/action.c:527: unregister_code(action.key.code);
      0072EE 12 77 06         [24] 1153 	lcall	_ak820_outline_0077
      0072F1 C0 05            [24] 1154 	push	ar5
      0072F3 12 75 79         [24] 1155 	lcall	_unregister_code
      0072F6 D0 05            [24] 1156 	pop	ar5
                                   1157 ;	quantum/action.c:528: if (mods) {
      0072F8 ED               [12] 1158 	mov	a,r5
      0072F9 70 03            [24] 1159 	jnz	00444$
      0072FB 02 74 F5         [24] 1160 	ljmp	00181$
      0072FE                       1161 00444$:
                                   1162 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0072FE 12 77 32         [24] 1163 	lcall	_ak820_outline_0159
      007301 FC               [12] 1164 	mov	r4,a
      007302 BC E0 00         [24] 1165 	cjne	r4,#0xe0,00445$
      007305                       1166 00445$:
      007305 40 07            [24] 1167 	jc	00115$
      007307 12 77 32         [24] 1168 	lcall	_ak820_outline_0159
      00730A 24 18            [12] 1169 	add	a,#0xff - 0xe7
      00730C 50 0A            [24] 1170 	jnc	00111$
                                   1171 ;	free result
      00730E                       1172 00115$:
      00730E 7B 2F            [12] 1173 	mov	r3,#_process_action_PARM_2
      007310 7C 08            [12] 1174 	mov	r4,#(_process_action_PARM_2 >> 8)
      007312 12 33 FC         [24] 1175 	lcall	_ak820_outline_0123
      007315 E0               [24] 1176 	movx	a,@dptr
      007316 70 07            [24] 1177 	jnz	00112$
      007318                       1178 00111$:
                                   1179 ;	quantum/action.c:530: del_owned_mods(mods);
      007318 8D 82            [24] 1180 	mov	dpl, r5
      00731A 12 7D 3B         [24] 1181 	lcall	_del_owned_mods
      00731D 80 05            [24] 1182 	sjmp	00113$
      00731F                       1183 00112$:
                                   1184 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      00731F 8D 82            [24] 1185 	mov	dpl, r5
      007321 12 7D 5A         [24] 1186 	lcall	_del_owned_weak_mods
      007324                       1187 00113$:
                                   1188 ;	quantum/action.c:534: send_keyboard_report();
      007324 12 80 67         [24] 1189 	lcall	_send_keyboard_report
                                   1190 ;	quantum/action.c:537: } break;
      007327 02 74 F5         [24] 1191 	ljmp	00181$
                                   1192 ;	quantum/action.c:614: case ACT_USAGE:
      00732A                       1193 00123$:
                                   1194 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      00732A 74 07            [12] 1195 	mov	a,#0x07
      00732C 12 38 31         [24] 1196 	lcall	_ak820_outline_0021
      00732F 12 48 55         [24] 1197 	lcall	_ak820_outline_0008
      007332 C3               [12] 1198 	clr	c
      007333 EC               [12] 1199 	mov	a,r4
      007334 94 A5            [12] 1200 	subb	a,#0xa5
      007336 ED               [12] 1201 	mov	a,r5
      007337 94 00            [12] 1202 	subb	a,#0x00
      007339 40 15            [24] 1203 	jc	00125$
      00733B 74 C2            [12] 1204 	mov	a,#0xc2
      00733D 9C               [12] 1205 	subb	a,r4
      00733E E4               [12] 1206 	clr	a
      00733F 9D               [12] 1207 	subb	a,r5
      007340 40 0E            [24] 1208 	jc	00125$
                                   1209 ;	free result
                                   1210 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      007342 90 0A 93         [24] 1211 	mov	dptr,#_owned_usage_key_PARM_2
      007345 E5 27            [12] 1212 	mov	a,_process_action_sloc0_1_0
      007347 F0               [24] 1213 	movx	@dptr,a
      007348 8E 82            [24] 1214 	mov	dpl, r6
      00734A 12 7F 12         [24] 1215 	lcall	_owned_usage_key
                                   1216 ;	quantum/action.c:622: break;
      00734D 02 74 F5         [24] 1217 	ljmp	00181$
      007350                       1218 00125$:
                                   1219 ;	quantum/action.c:625: switch (action.usage.page) {
      007350 12 77 0D         [24] 1220 	lcall	_ak820_outline_0088
      007353 FF               [12] 1221 	mov	r7,a
      007354 60 08            [24] 1222 	jz	00127$
      007356 BF 01 02         [24] 1223 	cjne	r7,#0x01,00452$
      007359 80 19            [24] 1224 	sjmp	00128$
      00735B                       1225 00452$:
      00735B 02 74 F5         [24] 1226 	ljmp	00181$
                                   1227 ;	quantum/action.c:626: case PAGE_SYSTEM:
      00735E                       1228 00127$:
                                   1229 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      00735E E5 27            [12] 1230 	mov	a,_process_action_sloc0_1_0
      007360 60 05            [24] 1231 	jz	00196$
      007362 12 77 1D         [24] 1232 	lcall	_ak820_outline_0130
      007365 80 04            [24] 1233 	sjmp	00197$
      007367                       1234 00196$:
      007367 7E 00            [12] 1235 	mov	r6,#0x00
      007369 7F 00            [12] 1236 	mov	r7,#0x00
      00736B                       1237 00197$:
      00736B 12 38 92         [24] 1238 	lcall	_ak820_outline_0119
      00736E 12 6D 18         [24] 1239 	lcall	_host_system_send
                                   1240 ;	quantum/action.c:628: break;
      007371 02 74 F5         [24] 1241 	ljmp	00181$
                                   1242 ;	quantum/action.c:629: case PAGE_CONSUMER:
      007374                       1243 00128$:
                                   1244 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      007374 E5 27            [12] 1245 	mov	a,_process_action_sloc0_1_0
      007376 60 05            [24] 1246 	jz	00198$
      007378 12 77 1D         [24] 1247 	lcall	_ak820_outline_0130
      00737B 80 04            [24] 1248 	sjmp	00199$
      00737D                       1249 00198$:
      00737D 7E 00            [12] 1250 	mov	r6,#0x00
      00737F 7F 00            [12] 1251 	mov	r7,#0x00
      007381                       1252 00199$:
      007381 12 38 92         [24] 1253 	lcall	_ak820_outline_0119
      007384 12 6D 48         [24] 1254 	lcall	_host_consumer_send
                                   1255 ;	quantum/action.c:633: break;
      007387 02 74 F5         [24] 1256 	ljmp	00181$
                                   1257 ;	quantum/action.c:640: case ACT_LAYER: {
      00738A                       1258 00131$:
                                   1259 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      00738A 90 08 30         [24] 1260 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00738D E0               [24] 1261 	movx	a,@dptr
      00738E 54 03            [12] 1262 	anl	a,#0x03
      007390 90 08 34         [24] 1263 	mov	dptr,#_process_action_on_40000_676
      007393 F0               [24] 1264 	movx	@dptr,a
                                   1265 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007394 E0               [24] 1266 	movx	a,@dptr
      007395 FF               [12] 1267 	mov	r7,a
      007396 60 11            [24] 1268 	jz	00200$
      007398 E5 27            [12] 1269 	mov	a,_process_action_sloc0_1_0
      00739A 60 07            [24] 1270 	jz	00202$
      00739C 8F 06            [24] 1271 	mov	ar6,r7
      00739E 53 06 01         [24] 1272 	anl	ar6,#0x01
      0073A1 80 10            [24] 1273 	sjmp	00201$
      0073A3                       1274 00202$:
      0073A3 74 02            [12] 1275 	mov	a,#0x02
      0073A5 5F               [12] 1276 	anl	a,r7
      0073A6 FE               [12] 1277 	mov	r6,a
      0073A7 80 0A            [24] 1278 	sjmp	00201$
      0073A9                       1279 00200$:
      0073A9 E5 27            [12] 1280 	mov	a,_process_action_sloc0_1_0
      0073AB B4 01 00         [24] 1281 	cjne	a,#0x01,00457$
      0073AE                       1282 00457$:
      0073AE 92 1F            [24] 1283 	mov  _process_action_sloc1_1_0,c
      0073B0 E4               [12] 1284 	clr	a
      0073B1 33               [12] 1285 	rlc	a
      0073B2 FE               [12] 1286 	mov	r6,a
      0073B3                       1287 00201$:
      0073B3 EE               [12] 1288 	mov	a,r6
      0073B4 70 03            [24] 1289 	jnz	00458$
      0073B6 02 74 F5         [24] 1290 	ljmp	00181$
      0073B9                       1291 00458$:
                                   1292 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      0073B9 12 77 32         [24] 1293 	lcall	_ak820_outline_0159
      0073BC C4               [12] 1294 	swap	a
      0073BD 03               [12] 1295 	rr	a
      0073BE 54 07            [12] 1296 	anl	a,#0x07
      0073C0 25 E0            [12] 1297 	add	a,acc
      0073C2 25 E0            [12] 1298 	add	a,acc
      0073C4 FF               [12] 1299 	mov	r7,a
                                   1300 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0073C5 12 77 32         [24] 1301 	lcall	_ak820_outline_0159
      0073C8 54 0F            [12] 1302 	anl	a,#0x0f
      0073CA FE               [12] 1303 	mov	r6,a
      0073CB 8F F0            [24] 1304 	mov	b,r7
      0073CD 05 F0            [12] 1305 	inc	b
      0073CF EE               [12] 1306 	mov	a,r6
      0073D0 80 02            [24] 1307 	sjmp	00460$
      0073D2                       1308 00459$:
      0073D2 25 E0            [12] 1309 	add	a,acc
      0073D4                       1310 00460$:
      0073D4 D5 F0 FB         [24] 1311 	djnz	b,00459$
      0073D7 FE               [12] 1312 	mov	r6,a
                                   1313 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0073D8 12 77 32         [24] 1314 	lcall	_ak820_outline_0159
      0073DB 30 E4 11         [24] 1315 	jnb	acc.4,00204$
      0073DE 8F F0            [24] 1316 	mov	b,r7
      0073E0 05 F0            [12] 1317 	inc	b
      0073E2 74 0F            [12] 1318 	mov	a,#0x0f
      0073E4 80 02            [24] 1319 	sjmp	00463$
      0073E6                       1320 00462$:
      0073E6 25 E0            [12] 1321 	add	a,acc
      0073E8                       1322 00463$:
      0073E8 D5 F0 FB         [24] 1323 	djnz	b,00462$
      0073EB F4               [12] 1324 	cpl	a
      0073EC FF               [12] 1325 	mov	r7,a
      0073ED 80 02            [24] 1326 	sjmp	00205$
      0073EF                       1327 00204$:
      0073EF 7F 00            [12] 1328 	mov	r7,#0x00
      0073F1                       1329 00205$:
                                   1330 ;	quantum/action.c:648: bits |= mask;
      0073F1 EE               [12] 1331 	mov	a,r6
      0073F2 42 07            [12] 1332 	orl	ar7,a
                                   1333 ;	quantum/action.c:649: if (!on) {
      0073F4 90 08 34         [24] 1334 	mov	dptr,#_process_action_on_40000_676
      0073F7 E0               [24] 1335 	movx	a,@dptr
      0073F8 70 31            [24] 1336 	jnz	00143$
                                   1337 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      0073FA 12 77 0D         [24] 1338 	lcall	_ak820_outline_0088
      0073FD FE               [12] 1339 	mov	r6,a
      0073FE 2E               [12] 1340 	add	a,r6
                                   1341 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      0073FF 90 74 03         [24] 1342 	mov	dptr,#00465$
      007402 73               [24] 1343 	jmp	@a+dptr
      007403                       1344 00465$:
      007403 80 06            [24] 1345 	sjmp	00132$
      007405 80 0C            [24] 1346 	sjmp	00133$
      007407 80 12            [24] 1347 	sjmp	00134$
      007409 80 18            [24] 1348 	sjmp	00135$
      00740B                       1349 00132$:
      00740B 8F 82            [24] 1350 	mov	dpl, r7
      00740D 12 77 92         [24] 1351 	lcall	_default_layer_and
      007410 02 74 F5         [24] 1352 	ljmp	00181$
                                   1353 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      007413                       1354 00133$:
      007413 8F 82            [24] 1355 	mov	dpl, r7
      007415 12 77 81         [24] 1356 	lcall	_default_layer_or
      007418 02 74 F5         [24] 1357 	ljmp	00181$
                                   1358 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      00741B                       1359 00134$:
      00741B 8F 82            [24] 1360 	mov	dpl, r7
      00741D 12 77 A8         [24] 1361 	lcall	_default_layer_xor
      007420 02 74 F5         [24] 1362 	ljmp	00181$
                                   1363 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      007423                       1364 00135$:
      007423 8F 82            [24] 1365 	mov	dpl, r7
      007425 12 77 76         [24] 1366 	lcall	_default_layer_set
                                   1367 ;	quantum/action.c:655: }
      007428 02 74 F5         [24] 1368 	ljmp	00181$
      00742B                       1369 00143$:
                                   1370 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      00742B 12 77 0D         [24] 1371 	lcall	_ak820_outline_0088
      00742E FE               [12] 1372 	mov	r6,a
      00742F 2E               [12] 1373 	add	a,r6
                                   1374 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      007430 90 74 34         [24] 1375 	mov	dptr,#00466$
      007433 73               [24] 1376 	jmp	@a+dptr
      007434                       1377 00466$:
      007434 80 06            [24] 1378 	sjmp	00137$
      007436 80 0C            [24] 1379 	sjmp	00138$
      007438 80 12            [24] 1380 	sjmp	00139$
      00743A 80 18            [24] 1381 	sjmp	00140$
      00743C                       1382 00137$:
      00743C 8F 82            [24] 1383 	mov	dpl, r7
      00743E 12 79 2C         [24] 1384 	lcall	_layer_and
      007441 02 74 F5         [24] 1385 	ljmp	00181$
                                   1386 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      007444                       1387 00138$:
      007444 8F 82            [24] 1388 	mov	dpl, r7
      007446 12 79 1B         [24] 1389 	lcall	_layer_or
      007449 02 74 F5         [24] 1390 	ljmp	00181$
                                   1391 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      00744C                       1392 00139$:
      00744C 8F 82            [24] 1393 	mov	dpl, r7
      00744E 12 79 42         [24] 1394 	lcall	_layer_xor
      007451 02 74 F5         [24] 1395 	ljmp	00181$
                                   1396 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      007454                       1397 00140$:
      007454 8F 82            [24] 1398 	mov	dpl, r7
      007456 12 78 B8         [24] 1399 	lcall	_layer_state_set
                                   1400 ;	quantum/action.c:665: break;
      007459 02 74 F5         [24] 1401 	ljmp	00181$
                                   1402 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      00745C                       1403 00147$:
                                   1404 ;	quantum/action.c:668: if (pressed) {
      00745C E5 27            [12] 1405 	mov	a,_process_action_sloc0_1_0
      00745E 60 11            [24] 1406 	jz	00149$
                                   1407 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      007460 12 77 16         [24] 1408 	lcall	_ak820_outline_0114
      007463 F5 82            [12] 1409 	mov	dpl,a
      007465 12 78 18         [24] 1410 	lcall	_layer_hold_on
                                   1411 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      007468 12 77 06         [24] 1412 	lcall	_ak820_outline_0077
      00746B 12 76 2F         [24] 1413 	lcall	_register_mods
      00746E 02 74 F5         [24] 1414 	ljmp	00181$
      007471                       1415 00149$:
                                   1416 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      007471 12 77 06         [24] 1417 	lcall	_ak820_outline_0077
      007474 12 76 43         [24] 1418 	lcall	_unregister_mods
                                   1419 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      007477 12 77 16         [24] 1420 	lcall	_ak820_outline_0114
      00747A F5 82            [12] 1421 	mov	dpl,a
      00747C 12 78 50         [24] 1422 	lcall	_layer_hold_off
                                   1423 ;	quantum/action.c:675: break;
      00747F 02 74 F5         [24] 1424 	ljmp	00181$
                                   1425 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      007482                       1426 00152$:
                                   1427 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      007482 12 77 32         [24] 1428 	lcall	_ak820_outline_0159
      007485 FF               [12] 1429 	mov	r7,a
      007486 BF F1 02         [24] 1430 	cjne	r7,#0xf1,00468$
      007489 80 0A            [24] 1431 	sjmp	00154$
      00748B                       1432 00468$:
      00748B BF F2 02         [24] 1433 	cjne	r7,#0xf2,00469$
      00748E 80 19            [24] 1434 	sjmp	00155$
      007490                       1435 00469$:
                                   1436 ;	quantum/action.c:694: momentary_layer_action:
      007490 BF F3 3B         [24] 1437 	cjne	r7,#0xf3,00160$
      007493 80 28            [24] 1438 	sjmp	00156$
      007495                       1439 00154$:
                                   1440 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007495 E5 27            [12] 1441 	mov	a,_process_action_sloc0_1_0
      007497 60 08            [24] 1442 	jz	00206$
      007499 12 76 EC         [24] 1443 	lcall	_ak820_outline_0042
      00749C 12 78 18         [24] 1444 	lcall	_layer_hold_on
      00749F 80 54            [24] 1445 	sjmp	00181$
      0074A1                       1446 00206$:
      0074A1 12 76 EC         [24] 1447 	lcall	_ak820_outline_0042
      0074A4 12 78 50         [24] 1448 	lcall	_layer_hold_off
                                   1449 ;	quantum/action.c:696: break;
                                   1450 ;	quantum/action.c:697: case OP_OFF_ON:
      0074A7 80 4C            [24] 1451 	sjmp	00181$
      0074A9                       1452 00155$:
                                   1453 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0074A9 E5 27            [12] 1454 	mov	a,_process_action_sloc0_1_0
      0074AB 60 08            [24] 1455 	jz	00208$
      0074AD 12 76 EC         [24] 1456 	lcall	_ak820_outline_0042
      0074B0 12 78 FD         [24] 1457 	lcall	_layer_off
      0074B3 80 40            [24] 1458 	sjmp	00181$
      0074B5                       1459 00208$:
      0074B5 12 76 EC         [24] 1460 	lcall	_ak820_outline_0042
      0074B8 12 78 E2         [24] 1461 	lcall	_layer_on
                                   1462 ;	quantum/action.c:699: break;
                                   1463 ;	quantum/action.c:700: case OP_SET_CLEAR:
      0074BB 80 38            [24] 1464 	sjmp	00181$
      0074BD                       1465 00156$:
                                   1466 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0074BD E5 27            [12] 1467 	mov	a,_process_action_sloc0_1_0
      0074BF 60 08            [24] 1468 	jz	00210$
      0074C1 12 76 EC         [24] 1469 	lcall	_ak820_outline_0042
      0074C4 12 78 CC         [24] 1470 	lcall	_layer_move
      0074C7 80 2C            [24] 1471 	sjmp	00181$
      0074C9                       1472 00210$:
      0074C9 12 78 C6         [24] 1473 	lcall	_layer_clear
                                   1474 ;	quantum/action.c:702: break;
                                   1475 ;	quantum/action.c:748: default:
      0074CC 80 27            [24] 1476 	sjmp	00181$
      0074CE                       1477 00160$:
                                   1478 ;	quantum/action.c:755: if (pressed) {
      0074CE E5 27            [12] 1479 	mov	a,_process_action_sloc0_1_0
      0074D0 60 08            [24] 1480 	jz	00163$
                                   1481 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      0074D2 12 77 06         [24] 1482 	lcall	_ak820_outline_0077
      0074D5 12 75 0C         [24] 1483 	lcall	_register_code
                                   1484 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0074D8 80 1B            [24] 1485 	sjmp	00181$
      0074DA                       1486 00163$:
                                   1487 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      0074DA 12 77 32         [24] 1488 	lcall	_ak820_outline_0159
      0074DD FF               [12] 1489 	mov	r7,a
      0074DE BF 39 0E         [24] 1490 	cjne	r7,#0x39,00175$
                                   1491 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      0074E1 7F 50            [12] 1492 	mov	r7,#0x50
      0074E3                       1493 00187$:
      0074E3 EF               [12] 1494 	mov	a,r7
      0074E4 60 09            [24] 1495 	jz	00175$
      0074E6 90 00 01         [24] 1496 	mov	dptr,#0x0001
      0074E9 12 58 F2         [24] 1497 	lcall	_mDelaymS
      0074EC 1F               [12] 1498 	dec	r7
                                   1499 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      0074ED 80 F4            [24] 1500 	sjmp	00187$
      0074EF                       1501 00175$:
                                   1502 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      0074EF 12 77 06         [24] 1503 	lcall	_ak820_outline_0077
      0074F2 12 75 79         [24] 1504 	lcall	_unregister_code
                                   1505 ;	quantum/action.c:848: }
      0074F5                       1506 00181$:
                                   1507 ;	quantum/action.c:869: switch (action.kind.id) {
      0074F5 90 08 30         [24] 1508 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074F8 E0               [24] 1509 	movx	a,@dptr
      0074F9 C4               [12] 1510 	swap	a
      0074FA 54 0F            [12] 1511 	anl	a,#0x0f
      0074FC FF               [12] 1512 	mov	r7,a
      0074FD BF 08 02         [24] 1513 	cjne	r7,#0x08,00478$
      007500 80 03            [24] 1514 	sjmp	00183$
      007502                       1515 00478$:
      007502 BF 09 06         [24] 1516 	cjne	r7,#0x09,00192$
                                   1517 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      007505                       1518 00183$:
                                   1519 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      007505 12 6C 7D         [24] 1520 	lcall	_host_keyboard_leds
                                   1521 ;	quantum/action.c:880: }
                                   1522 ;	quantum/action.c:933: }
      007508 02 97 EA         [24] 1523 	ljmp	_led_set
      00750B                       1524 00192$:
      00750B 22               [24] 1525 	ret
                                   1526 ;------------------------------------------------------------
                                   1527 ;Allocation info for local variables in function 'register_code'
                                   1528 ;------------------------------------------------------------
                                   1529 ;code          Allocated with name '_register_code_code_10000_710'
                                   1530 ;------------------------------------------------------------
                                   1531 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1532 ;	-----------------------------------------
                                   1533 ;	 function register_code
                                   1534 ;	-----------------------------------------
      00750C                       1535 _register_code:
      00750C E5 82            [12] 1536 	mov	a,dpl
      00750E 90 08 35         [24] 1537 	mov	dptr,#_register_code_code_10000_710
      007511 F0               [24] 1538 	movx	@dptr,a
                                   1539 ;	quantum/action.c:940: if (code == KC_NO) {
      007512 E0               [24] 1540 	movx	a,@dptr
      007513 FF               [12] 1541 	mov	r7,a
      007514 70 01            [24] 1542 	jnz	00123$
                                   1543 ;	quantum/action.c:941: return;
      007516 22               [24] 1544 	ret
      007517                       1545 00123$:
                                   1546 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      007517 BF 04 00         [24] 1547 	cjne	r7,#0x04,00186$
      00751A                       1548 00186$:
      00751A 40 12            [24] 1549 	jc	00119$
      00751C EF               [12] 1550 	mov	a,r7
      00751D 24 5B            [12] 1551 	add	a,#0xff - 0xa4
      00751F 40 0D            [24] 1552 	jc	00119$
                                   1553 ;	free result
                                   1554 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      007521 8F 82            [24] 1555 	mov	dpl, r7
      007523 12 7D CF         [24] 1556 	lcall	_add_owned_key
      007526 E5 82            [12] 1557 	mov	a, dpl
      007528 70 01            [24] 1558 	jnz	00104$
      00752A 22               [24] 1559 	ret
      00752B                       1560 00104$:
                                   1561 ;	quantum/action.c:995: send_keyboard_report();
      00752B 02 80 67         [24] 1562 	ljmp	_send_keyboard_report
      00752E                       1563 00119$:
                                   1564 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      00752E 12 77 37         [24] 1565 	lcall	_ak820_outline_0167
      007531 BF E0 00         [24] 1566 	cjne	r7,#0xe0,00190$
      007534                       1567 00190$:
      007534 40 1A            [24] 1568 	jc	00115$
      007536 EF               [12] 1569 	mov	a,r7
      007537 24 18            [12] 1570 	add	a,#0xff - 0xe7
      007539 40 15            [24] 1571 	jc	00115$
                                   1572 ;	free result
                                   1573 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      00753B 74 07            [12] 1574 	mov	a,#0x07
      00753D 5F               [12] 1575 	anl	a,r7
      00753E 12 76 F5         [24] 1576 	lcall	_ak820_outline_0061
      007541 80 02            [24] 1577 	sjmp	00194$
      007543                       1578 00193$:
      007543 25 E0            [12] 1579 	add	a,acc
      007545                       1580 00194$:
      007545 D5 F0 FB         [24] 1581 	djnz	b,00193$
      007548 F5 82            [12] 1582 	mov	dpl,a
      00754A 12 7D 2B         [24] 1583 	lcall	_add_owned_mods
                                   1584 ;	quantum/action.c:998: send_keyboard_report();
      00754D 02 80 67         [24] 1585 	ljmp	_send_keyboard_report
      007550                       1586 00115$:
                                   1587 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007550 12 77 37         [24] 1588 	lcall	_ak820_outline_0167
      007553 BF A5 00         [24] 1589 	cjne	r7,#0xa5,00195$
      007556                       1590 00195$:
      007556 40 05            [24] 1591 	jc	00113$
      007558 EF               [12] 1592 	mov	a,r7
      007559 24 58            [12] 1593 	add	a,#0xff - 0xa7
      00755B 50 0D            [24] 1594 	jnc	00108$
                                   1595 ;	free result
      00755D                       1596 00113$:
      00755D 12 77 37         [24] 1597 	lcall	_ak820_outline_0167
      007560 BF A8 00         [24] 1598 	cjne	r7,#0xa8,00198$
      007563                       1599 00198$:
      007563 40 13            [24] 1600 	jc	00125$
      007565 EF               [12] 1601 	mov	a,r7
      007566 24 3D            [12] 1602 	add	a,#0xff - 0xc2
      007568 40 0E            [24] 1603 	jc	00125$
                                   1604 ;	free result
      00756A                       1605 00108$:
                                   1606 ;	quantum/action.c:1003: owned_usage_key(code, true);
      00756A 12 77 37         [24] 1607 	lcall	_ak820_outline_0167
      00756D 90 0A 93         [24] 1608 	mov	dptr,#_owned_usage_key_PARM_2
      007570 74 01            [12] 1609 	mov	a,#0x01
      007572 F0               [24] 1610 	movx	@dptr,a
      007573 8F 82            [24] 1611 	mov	dpl, r7
                                   1612 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1613 ;	quantum/action.c:1013: }
      007575 02 7F 12         [24] 1614 	ljmp	_owned_usage_key
      007578                       1615 00125$:
      007578 22               [24] 1616 	ret
                                   1617 ;------------------------------------------------------------
                                   1618 ;Allocation info for local variables in function 'unregister_code'
                                   1619 ;------------------------------------------------------------
                                   1620 ;code          Allocated with name '_unregister_code_code_10000_724'
                                   1621 ;------------------------------------------------------------
                                   1622 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1623 ;	-----------------------------------------
                                   1624 ;	 function unregister_code
                                   1625 ;	-----------------------------------------
      007579                       1626 _unregister_code:
      007579 E5 82            [12] 1627 	mov	a,dpl
      00757B 90 08 36         [24] 1628 	mov	dptr,#_unregister_code_code_10000_724
      00757E F0               [24] 1629 	movx	@dptr,a
                                   1630 ;	quantum/action.c:1020: if (code == KC_NO) {
      00757F E0               [24] 1631 	movx	a,@dptr
      007580 FF               [12] 1632 	mov	r7,a
      007581 70 01            [24] 1633 	jnz	00121$
                                   1634 ;	quantum/action.c:1021: return;
      007583 22               [24] 1635 	ret
      007584                       1636 00121$:
                                   1637 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      007584 BF 04 00         [24] 1638 	cjne	r7,#0x04,00184$
      007587                       1639 00184$:
      007587 40 12            [24] 1640 	jc	00117$
      007589 EF               [12] 1641 	mov	a,r7
      00758A 24 5B            [12] 1642 	add	a,#0xff - 0xa4
      00758C 40 0D            [24] 1643 	jc	00117$
                                   1644 ;	free result
                                   1645 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      00758E 8F 82            [24] 1646 	mov	dpl, r7
      007590 12 7E 49         [24] 1647 	lcall	_del_owned_key
      007593 E5 82            [12] 1648 	mov	a, dpl
      007595 70 01            [24] 1649 	jnz	00102$
      007597 22               [24] 1650 	ret
      007598                       1651 00102$:
                                   1652 ;	quantum/action.c:1062: send_keyboard_report();
      007598 02 80 67         [24] 1653 	ljmp	_send_keyboard_report
      00759B                       1654 00117$:
                                   1655 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      00759B 12 77 3D         [24] 1656 	lcall	_ak820_outline_0168
      00759E BF E0 00         [24] 1657 	cjne	r7,#0xe0,00188$
      0075A1                       1658 00188$:
      0075A1 40 1A            [24] 1659 	jc	00113$
      0075A3 EF               [12] 1660 	mov	a,r7
      0075A4 24 18            [12] 1661 	add	a,#0xff - 0xe7
      0075A6 40 15            [24] 1662 	jc	00113$
                                   1663 ;	free result
                                   1664 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      0075A8 74 07            [12] 1665 	mov	a,#0x07
      0075AA 5F               [12] 1666 	anl	a,r7
      0075AB 12 76 F5         [24] 1667 	lcall	_ak820_outline_0061
      0075AE 80 02            [24] 1668 	sjmp	00192$
      0075B0                       1669 00191$:
      0075B0 25 E0            [12] 1670 	add	a,acc
      0075B2                       1671 00192$:
      0075B2 D5 F0 FB         [24] 1672 	djnz	b,00191$
      0075B5 F5 82            [12] 1673 	mov	dpl,a
      0075B7 12 7D 3B         [24] 1674 	lcall	_del_owned_mods
                                   1675 ;	quantum/action.c:1065: send_keyboard_report();
      0075BA 02 80 67         [24] 1676 	ljmp	_send_keyboard_report
      0075BD                       1677 00113$:
                                   1678 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0075BD 12 77 3D         [24] 1679 	lcall	_ak820_outline_0168
      0075C0 BF A5 00         [24] 1680 	cjne	r7,#0xa5,00193$
      0075C3                       1681 00193$:
      0075C3 40 05            [24] 1682 	jc	00111$
      0075C5 EF               [12] 1683 	mov	a,r7
      0075C6 24 58            [12] 1684 	add	a,#0xff - 0xa7
      0075C8 50 0D            [24] 1685 	jnc	00106$
                                   1686 ;	free result
      0075CA                       1687 00111$:
      0075CA 12 77 3D         [24] 1688 	lcall	_ak820_outline_0168
      0075CD BF A8 00         [24] 1689 	cjne	r7,#0xa8,00196$
      0075D0                       1690 00196$:
      0075D0 40 12            [24] 1691 	jc	00123$
      0075D2 EF               [12] 1692 	mov	a,r7
      0075D3 24 3D            [12] 1693 	add	a,#0xff - 0xc2
      0075D5 40 0D            [24] 1694 	jc	00123$
                                   1695 ;	free result
      0075D7                       1696 00106$:
                                   1697 ;	quantum/action.c:1070: owned_usage_key(code, false);
      0075D7 12 77 3D         [24] 1698 	lcall	_ak820_outline_0168
      0075DA 90 0A 93         [24] 1699 	mov	dptr,#_owned_usage_key_PARM_2
      0075DD E4               [12] 1700 	clr	a
      0075DE F0               [24] 1701 	movx	@dptr,a
      0075DF 8F 82            [24] 1702 	mov	dpl, r7
                                   1703 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1704 ;	quantum/action.c:1080: }
      0075E1 02 7F 12         [24] 1705 	ljmp	_owned_usage_key
      0075E4                       1706 00123$:
      0075E4 22               [24] 1707 	ret
                                   1708 ;------------------------------------------------------------
                                   1709 ;Allocation info for local variables in function 'tap_code_delay'
                                   1710 ;------------------------------------------------------------
                                   1711 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1712 ;code          Allocated with name '_tap_code_delay_code_10000_737'
                                   1713 ;i             Allocated with name '_tap_code_delay_i_20000_739'
                                   1714 ;i             Allocated with name '_tap_code_delay_i_50000_742'
                                   1715 ;------------------------------------------------------------
                                   1716 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1717 ;	-----------------------------------------
                                   1718 ;	 function tap_code_delay
                                   1719 ;	-----------------------------------------
      0075E5                       1720 _tap_code_delay:
      0075E5 E5 82            [12] 1721 	mov	a,dpl
      0075E7 90 08 39         [24] 1722 	mov	dptr,#_tap_code_delay_code_10000_737
      0075EA F0               [24] 1723 	movx	@dptr,a
                                   1724 ;	quantum/action.c:1088: register_code(code);
      0075EB E0               [24] 1725 	movx	a,@dptr
      0075EC FF               [12] 1726 	mov	r7,a
      0075ED F5 82            [12] 1727 	mov	dpl,a
      0075EF C0 07            [24] 1728 	push	ar7
      0075F1 12 75 0C         [24] 1729 	lcall	_register_code
      0075F4 D0 07            [24] 1730 	pop	ar7
                                   1731 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      0075F6 90 08 37         [24] 1732 	mov	dptr,#_tap_code_delay_PARM_2
      0075F9 12 38 6A         [24] 1733 	lcall	_ak820_outline_0084
      0075FC                       1734 00110$:
      0075FC ED               [12] 1735 	mov	a,r5
      0075FD 4E               [12] 1736 	orl	a,r6
      0075FE 60 0D            [24] 1737 	jz	00105$
                                   1738 ;	quantum/action.c:1090: wait_ms(1);
      007600 90 00 01         [24] 1739 	mov	dptr,#0x0001
      007603 12 58 F2         [24] 1740 	lcall	_mDelaymS
                                   1741 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007606 1D               [12] 1742 	dec	r5
      007607 BD FF 01         [24] 1743 	cjne	r5,#0xff,00141$
      00760A 1E               [12] 1744 	dec	r6
      00760B                       1745 00141$:
      00760B 80 EF            [24] 1746 	sjmp	00110$
      00760D                       1747 00105$:
                                   1748 ;	quantum/action.c:1092: unregister_code(code);
      00760D 8F 82            [24] 1749 	mov	dpl, r7
                                   1750 ;	quantum/action.c:1093: }
      00760F 02 75 79         [24] 1751 	ljmp	_unregister_code
                                   1752 ;------------------------------------------------------------
                                   1753 ;Allocation info for local variables in function 'tap_code'
                                   1754 ;------------------------------------------------------------
                                   1755 ;code          Allocated with name '_tap_code_code_10000_744'
                                   1756 ;------------------------------------------------------------
                                   1757 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1758 ;	-----------------------------------------
                                   1759 ;	 function tap_code
                                   1760 ;	-----------------------------------------
      007612                       1761 _tap_code:
      007612 E5 82            [12] 1762 	mov	a,dpl
      007614 90 08 3A         [24] 1763 	mov	dptr,#_tap_code_code_10000_744
      007617 F0               [24] 1764 	movx	@dptr,a
                                   1765 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007618 E0               [24] 1766 	movx	a,@dptr
      007619 FF               [12] 1767 	mov	r7,a
      00761A BF 39 04         [24] 1768 	cjne	r7,#0x39,00103$
      00761D 7E 50            [12] 1769 	mov	r6,#0x50
      00761F 80 02            [24] 1770 	sjmp	00104$
      007621                       1771 00103$:
      007621 7E 00            [12] 1772 	mov	r6,#0x00
      007623                       1773 00104$:
      007623 90 08 37         [24] 1774 	mov	dptr,#_tap_code_delay_PARM_2
      007626 EE               [12] 1775 	mov	a,r6
      007627 12 38 A1         [24] 1776 	lcall	_ak820_outline_0135
      00762A 8F 82            [24] 1777 	mov	dpl, r7
                                   1778 ;	quantum/action.c:1101: }
      00762C 02 75 E5         [24] 1779 	ljmp	_tap_code_delay
                                   1780 ;------------------------------------------------------------
                                   1781 ;Allocation info for local variables in function 'register_mods'
                                   1782 ;------------------------------------------------------------
                                   1783 ;mods          Allocated with name '_register_mods_mods_10000_746'
                                   1784 ;------------------------------------------------------------
                                   1785 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1786 ;	-----------------------------------------
                                   1787 ;	 function register_mods
                                   1788 ;	-----------------------------------------
      00762F                       1789 _register_mods:
      00762F E5 82            [12] 1790 	mov	a,dpl
      007631 90 08 3B         [24] 1791 	mov	dptr,#_register_mods_mods_10000_746
      007634 F0               [24] 1792 	movx	@dptr,a
                                   1793 ;	quantum/action.c:1108: if (mods) {
      007635 E0               [24] 1794 	movx	a,@dptr
      007636 FF               [12] 1795 	mov	r7,a
      007637 E0               [24] 1796 	movx	a,@dptr
      007638 60 08            [24] 1797 	jz	00103$
                                   1798 ;	quantum/action.c:1109: add_owned_mods(mods);
      00763A 8F 82            [24] 1799 	mov	dpl, r7
      00763C 12 7D 2B         [24] 1800 	lcall	_add_owned_mods
                                   1801 ;	quantum/action.c:1110: send_keyboard_report();
                                   1802 ;	quantum/action.c:1112: }
      00763F 02 80 67         [24] 1803 	ljmp	_send_keyboard_report
      007642                       1804 00103$:
      007642 22               [24] 1805 	ret
                                   1806 ;------------------------------------------------------------
                                   1807 ;Allocation info for local variables in function 'unregister_mods'
                                   1808 ;------------------------------------------------------------
                                   1809 ;mods          Allocated with name '_unregister_mods_mods_10000_750'
                                   1810 ;------------------------------------------------------------
                                   1811 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1812 ;	-----------------------------------------
                                   1813 ;	 function unregister_mods
                                   1814 ;	-----------------------------------------
      007643                       1815 _unregister_mods:
      007643 E5 82            [12] 1816 	mov	a,dpl
      007645 90 08 3C         [24] 1817 	mov	dptr,#_unregister_mods_mods_10000_750
      007648 F0               [24] 1818 	movx	@dptr,a
                                   1819 ;	quantum/action.c:1119: if (mods) {
      007649 E0               [24] 1820 	movx	a,@dptr
      00764A FF               [12] 1821 	mov	r7,a
      00764B E0               [24] 1822 	movx	a,@dptr
      00764C 60 08            [24] 1823 	jz	00103$
                                   1824 ;	quantum/action.c:1120: del_owned_mods(mods);
      00764E 8F 82            [24] 1825 	mov	dpl, r7
      007650 12 7D 3B         [24] 1826 	lcall	_del_owned_mods
                                   1827 ;	quantum/action.c:1121: send_keyboard_report();
                                   1828 ;	quantum/action.c:1123: }
      007653 02 80 67         [24] 1829 	ljmp	_send_keyboard_report
      007656                       1830 00103$:
      007656 22               [24] 1831 	ret
                                   1832 ;------------------------------------------------------------
                                   1833 ;Allocation info for local variables in function 'register_weak_mods'
                                   1834 ;------------------------------------------------------------
                                   1835 ;mods          Allocated with name '_register_weak_mods_mods_10000_754'
                                   1836 ;------------------------------------------------------------
                                   1837 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1838 ;	-----------------------------------------
                                   1839 ;	 function register_weak_mods
                                   1840 ;	-----------------------------------------
      007657                       1841 _register_weak_mods:
      007657 E5 82            [12] 1842 	mov	a,dpl
      007659 90 08 3D         [24] 1843 	mov	dptr,#_register_weak_mods_mods_10000_754
      00765C F0               [24] 1844 	movx	@dptr,a
                                   1845 ;	quantum/action.c:1130: if (mods) {
      00765D E0               [24] 1846 	movx	a,@dptr
      00765E FF               [12] 1847 	mov	r7,a
      00765F E0               [24] 1848 	movx	a,@dptr
      007660 60 08            [24] 1849 	jz	00103$
                                   1850 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      007662 8F 82            [24] 1851 	mov	dpl, r7
      007664 12 7D 4A         [24] 1852 	lcall	_add_owned_weak_mods
                                   1853 ;	quantum/action.c:1132: send_keyboard_report();
                                   1854 ;	quantum/action.c:1134: }
      007667 02 80 67         [24] 1855 	ljmp	_send_keyboard_report
      00766A                       1856 00103$:
      00766A 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1860 ;------------------------------------------------------------
                                   1861 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_758'
                                   1862 ;------------------------------------------------------------
                                   1863 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1864 ;	-----------------------------------------
                                   1865 ;	 function unregister_weak_mods
                                   1866 ;	-----------------------------------------
      00766B                       1867 _unregister_weak_mods:
      00766B E5 82            [12] 1868 	mov	a,dpl
      00766D 90 08 3E         [24] 1869 	mov	dptr,#_unregister_weak_mods_mods_10000_758
      007670 F0               [24] 1870 	movx	@dptr,a
                                   1871 ;	quantum/action.c:1141: if (mods) {
      007671 E0               [24] 1872 	movx	a,@dptr
      007672 FF               [12] 1873 	mov	r7,a
      007673 E0               [24] 1874 	movx	a,@dptr
      007674 60 08            [24] 1875 	jz	00103$
                                   1876 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      007676 8F 82            [24] 1877 	mov	dpl, r7
      007678 12 7D 5A         [24] 1878 	lcall	_del_owned_weak_mods
                                   1879 ;	quantum/action.c:1143: send_keyboard_report();
                                   1880 ;	quantum/action.c:1145: }
      00767B 02 80 67         [24] 1881 	ljmp	_send_keyboard_report
      00767E                       1882 00103$:
      00767E 22               [24] 1883 	ret
                                   1884 ;------------------------------------------------------------
                                   1885 ;Allocation info for local variables in function 'clear_keyboard'
                                   1886 ;------------------------------------------------------------
                                   1887 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   1888 ;	-----------------------------------------
                                   1889 ;	 function clear_keyboard
                                   1890 ;	-----------------------------------------
      00767F                       1891 _clear_keyboard:
                                   1892 ;	quantum/action.c:1152: clear_mods();
      00767F 12 81 1F         [24] 1893 	lcall	_clear_mods
                                   1894 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   1895 ;	quantum/action.c:1154: }
      007682 02 76 85         [24] 1896 	ljmp	_clear_keyboard_but_mods
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function clear_keyboard_but_mods
                                   1903 ;	-----------------------------------------
      007685                       1904 _clear_keyboard_but_mods:
                                   1905 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007685 90 0D C5         [24] 1906 	mov	dptr,#_actual_keyboard_report
      007688 12 6F 45         [24] 1907 	lcall	_clear_keys_from_report
                                   1908 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   1909 ;	quantum/action.c:1163: }
      00768B 02 76 8E         [24] 1910 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1911 ;------------------------------------------------------------
                                   1912 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1913 ;------------------------------------------------------------
                                   1914 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   1915 ;	-----------------------------------------
                                   1916 ;	 function clear_keyboard_but_mods_and_keys
                                   1917 ;	-----------------------------------------
      00768E                       1918 _clear_keyboard_but_mods_and_keys:
                                   1919 ;	quantum/action.c:1171: ak820_tapping_cancel();
      00768E 12 46 BE         [24] 1920 	lcall	_ak820_tapping_cancel
                                   1921 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      007691 12 2E F0         [24] 1922 	lcall	_ak820_oneshot_cancel
                                   1923 ;	quantum/action.c:1185: ak820_combo_cancel();
      007694 12 35 70         [24] 1924 	lcall	_ak820_combo_cancel
                                   1925 ;	quantum/action.c:1188: repeat_key_cancel();
      007697 12 A2 57         [24] 1926 	lcall	_repeat_key_cancel
                                   1927 ;	quantum/action.c:1190: clear_owned_mods();
      00769A 12 7D 6A         [24] 1928 	lcall	_clear_owned_mods
                                   1929 ;	quantum/action.c:1191: clear_owned_keys();
      00769D 12 7D A2         [24] 1930 	lcall	_clear_owned_keys
                                   1931 ;	quantum/action.c:1192: clear_owned_usages();
      0076A0 12 7E DA         [24] 1932 	lcall	_clear_owned_usages
                                   1933 ;	quantum/action.c:1193: layer_hold_clear();
      0076A3 12 78 89         [24] 1934 	lcall	_layer_hold_clear
                                   1935 ;	quantum/action.c:1195: clear_macro_tri_layer();
      0076A6 12 9C 9F         [24] 1936 	lcall	_clear_macro_tri_layer
                                   1937 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0076A9 90 0D C5         [24] 1938 	mov	dptr,#_actual_keyboard_report
      0076AC 12 6F 45         [24] 1939 	lcall	_clear_keys_from_report
                                   1940 ;	quantum/action.c:1200: host_system_send(0);
      0076AF 90 00 00         [24] 1941 	mov	dptr,#0x0000
      0076B2 12 6D 18         [24] 1942 	lcall	_host_system_send
                                   1943 ;	quantum/action.c:1201: host_consumer_send(0);
      0076B5 90 00 00         [24] 1944 	mov	dptr,#0x0000
      0076B8 12 6D 48         [24] 1945 	lcall	_host_consumer_send
                                   1946 ;	quantum/action.c:1203: clear_weak_mods();
      0076BB 12 81 54         [24] 1947 	lcall	_clear_weak_mods
                                   1948 ;	quantum/action.c:1204: send_keyboard_report();
                                   1949 ;	quantum/action.c:1212: }
      0076BE 02 80 67         [24] 1950 	ljmp	_send_keyboard_report
                                   1951 ;------------------------------------------------------------
                                   1952 ;Allocation info for local variables in function 'is_tap_record'
                                   1953 ;------------------------------------------------------------
                                   1954 ;record        Allocated with name '_is_tap_record_record_10000_774'
                                   1955 ;action        Allocated with name '_is_tap_record_action_10001_778'
                                   1956 ;------------------------------------------------------------
                                   1957 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   1958 ;	-----------------------------------------
                                   1959 	.area CSEG    (CODE)
                                   1960 	.area CONST   (CODE)
                                   1961 	.area XINIT   (CODE)
      00C1D5                       1962 __xinit__disable_action_cache:
      00C1D5 00                    1963 	.db #0x00	;  0
                                   1964 	.area CABS    (ABS,CODE)
                                   1965 
                                   1966 ; Experimental exact instruction outlining.
                                   1967 	.globl _ak820_outline_0001
                                   1968 	.globl _ak820_outline_0005
                                   1969 	.globl _ak820_outline_0007
                                   1970 	.globl _ak820_outline_0008
                                   1971 	.globl _ak820_outline_0011
                                   1972 	.globl _ak820_outline_0012
                                   1973 	.globl _ak820_outline_0013
                                   1974 	.globl _ak820_outline_0014
                                   1975 	.globl _ak820_outline_0017
                                   1976 	.globl _ak820_outline_0020
                                   1977 	.globl _ak820_outline_0021
                                   1978 	.globl _ak820_outline_0034
                                   1979 	.globl _ak820_outline_0037
                                   1980 	.globl _ak820_outline_0042
                                   1981 	.globl _ak820_outline_0057
                                   1982 	.globl _ak820_outline_0061
                                   1983 	.globl _ak820_outline_0064
                                   1984 	.globl _ak820_outline_0070
                                   1985 	.globl _ak820_outline_0072
                                   1986 	.globl _ak820_outline_0077
                                   1987 	.globl _ak820_outline_0084
                                   1988 	.globl _ak820_outline_0088
                                   1989 	.globl _ak820_outline_0092
                                   1990 	.globl _ak820_outline_0108
                                   1991 	.globl _ak820_outline_0109
                                   1992 	.globl _ak820_outline_0111
                                   1993 	.globl _ak820_outline_0113
                                   1994 	.globl _ak820_outline_0114
                                   1995 	.globl _ak820_outline_0119
                                   1996 	.globl _ak820_outline_0123
                                   1997 	.globl _ak820_outline_0124
                                   1998 	.globl _ak820_outline_0130
                                   1999 	.globl _ak820_outline_0134
                                   2000 	.globl _ak820_outline_0135
                                   2001 	.globl _ak820_outline_0142
                                   2002 	.globl _ak820_outline_0146
                                   2003 	.globl _ak820_outline_0149
                                   2004 	.globl _ak820_outline_0157
                                   2005 	.globl _ak820_outline_0159
                                   2006 	.globl _ak820_outline_0167
                                   2007 	.globl _ak820_outline_0168
                                   2008 	.globl _ak820_outline_0183
                                   2009 	.globl _ak820_outline_0188
                                   2010 
                                   2011 	.area CSEG (CODE)
                                   2012 ; function ak820_outline_0013
      0076C1                       2013 _ak820_outline_0013:
      0076C1 2D               [12] 2014 	add	a,r5
      0076C2 F9               [12] 2015 	mov	r1,a
      0076C3 E4               [12] 2016 	clr	a
      0076C4 3E               [12] 2017 	addc	a,r6
      0076C5 FA               [12] 2018 	mov	r2,a
      0076C6 8F 03            [24] 2019 	mov	ar3,r7
      0076C8 89 82            [24] 2020 	mov	dpl,r1
      0076CA 8A 83            [24] 2021 	mov	dph,r2
      0076CC 8B F0            [24] 2022 	mov	b,r3
      0076CE 22               [24] 2023 	ret
                                   2024 
                                   2025 	.area CSEG (CODE)
                                   2026 ; function ak820_outline_0014
      0076CF                       2027 _ak820_outline_0014:
      0076CF 2D               [12] 2028 	add	a,r5
      0076D0 FA               [12] 2029 	mov	r2,a
      0076D1 E4               [12] 2030 	clr	a
      0076D2 3E               [12] 2031 	addc	a,r6
      0076D3 FB               [12] 2032 	mov	r3,a
      0076D4 8F 04            [24] 2033 	mov	ar4,r7
      0076D6 8A 82            [24] 2034 	mov	dpl,r2
      0076D8 8B 83            [24] 2035 	mov	dph,r3
      0076DA 8C F0            [24] 2036 	mov	b,r4
      0076DC 22               [24] 2037 	ret
                                   2038 
                                   2039 	.area CSEG (CODE)
                                   2040 ; function ak820_outline_0020
      0076DD                       2041 _ak820_outline_0020:
      0076DD 8E 82            [24] 2042 	mov	dpl,r6
      0076DF 8F 83            [24] 2043 	mov	dph,r7
      0076E1 A3               [24] 2044 	inc	dptr
      0076E2 E0               [24] 2045 	movx	a,@dptr
      0076E3 FC               [12] 2046 	mov	r4,a
      0076E4 7D 00            [12] 2047 	mov	r5,#0x00
      0076E6 8E 82            [24] 2048 	mov	dpl,r6
      0076E8 8F 83            [24] 2049 	mov	dph,r7
      0076EA E0               [24] 2050 	movx	a,@dptr
      0076EB 22               [24] 2051 	ret
                                   2052 
                                   2053 	.area CSEG (CODE)
                                   2054 ; function ak820_outline_0042
      0076EC                       2055 _ak820_outline_0042:
      0076EC 90 08 30         [24] 2056 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0076EF E0               [24] 2057 	movx	a,@dptr
      0076F0 54 1F            [12] 2058 	anl	a,#0x1f
      0076F2 F5 82            [12] 2059 	mov	dpl,a
      0076F4 22               [24] 2060 	ret
                                   2061 
                                   2062 	.area CSEG (CODE)
                                   2063 ; function ak820_outline_0061
      0076F5                       2064 _ak820_outline_0061:
      0076F5 F5 F0            [12] 2065 	mov	b,a
      0076F7 05 F0            [12] 2066 	inc	b
      0076F9 74 01            [12] 2067 	mov	a,#0x01
      0076FB 22               [24] 2068 	ret
                                   2069 
                                   2070 	.area CSEG (CODE)
                                   2071 ; function ak820_outline_0070
      0076FC                       2072 _ak820_outline_0070:
      0076FC 90 0D A3         [24] 2073 	mov	dptr,#___memcpy_PARM_3
      0076FF 74 06            [12] 2074 	mov	a,#0x06
      007701 F0               [24] 2075 	movx	@dptr,a
      007702 E4               [12] 2076 	clr	a
      007703 A3               [24] 2077 	inc	dptr
      007704 F0               [24] 2078 	movx	@dptr,a
      007705 22               [24] 2079 	ret
                                   2080 
                                   2081 	.area CSEG (CODE)
                                   2082 ; function ak820_outline_0077
      007706                       2083 _ak820_outline_0077:
      007706 90 08 2F         [24] 2084 	mov	dptr,#_process_action_PARM_2
      007709 E0               [24] 2085 	movx	a,@dptr
      00770A F5 82            [12] 2086 	mov	dpl,a
      00770C 22               [24] 2087 	ret
                                   2088 
                                   2089 	.area CSEG (CODE)
                                   2090 ; function ak820_outline_0088
      00770D                       2091 _ak820_outline_0088:
      00770D 90 08 30         [24] 2092 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007710 E0               [24] 2093 	movx	a,@dptr
      007711 03               [12] 2094 	rr	a
      007712 03               [12] 2095 	rr	a
      007713 54 03            [12] 2096 	anl	a,#0x03
      007715 22               [24] 2097 	ret
                                   2098 
                                   2099 	.area CSEG (CODE)
                                   2100 ; function ak820_outline_0114
      007716                       2101 _ak820_outline_0114:
      007716 90 08 30         [24] 2102 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007719 E0               [24] 2103 	movx	a,@dptr
      00771A 54 0F            [12] 2104 	anl	a,#0x0f
      00771C 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0130
      00771D                       2109 _ak820_outline_0130:
      00771D 90 08 2F         [24] 2110 	mov	dptr,#_process_action_PARM_2
      007720 E0               [24] 2111 	movx	a,@dptr
      007721 FE               [12] 2112 	mov	r6,a
      007722 A3               [24] 2113 	inc	dptr
      007723 E0               [24] 2114 	movx	a,@dptr
      007724 54 03            [12] 2115 	anl	a,#0x03
      007726 FF               [12] 2116 	mov	r7,a
      007727 22               [24] 2117 	ret
                                   2118 
                                   2119 	.area CSEG (CODE)
                                   2120 ; function ak820_outline_0146
      007728                       2121 _ak820_outline_0146:
      007728 74 07            [12] 2122 	mov	a,#0x07
      00772A 2D               [12] 2123 	add	a,r5
      00772B F8               [12] 2124 	mov	r0,a
      00772C E4               [12] 2125 	clr	a
      00772D 3E               [12] 2126 	addc	a,r6
      00772E F9               [12] 2127 	mov	r1,a
      00772F 8F 02            [24] 2128 	mov	ar2,r7
      007731 22               [24] 2129 	ret
                                   2130 
                                   2131 	.area CSEG (CODE)
                                   2132 ; function ak820_outline_0159
      007732                       2133 _ak820_outline_0159:
      007732 90 08 2F         [24] 2134 	mov	dptr,#_process_action_PARM_2
      007735 E0               [24] 2135 	movx	a,@dptr
      007736 22               [24] 2136 	ret
                                   2137 
                                   2138 	.area CSEG (CODE)
                                   2139 ; function ak820_outline_0167
      007737                       2140 _ak820_outline_0167:
      007737 90 08 35         [24] 2141 	mov	dptr,#_register_code_code_10000_710
      00773A E0               [24] 2142 	movx	a,@dptr
      00773B FF               [12] 2143 	mov	r7,a
      00773C 22               [24] 2144 	ret
                                   2145 
                                   2146 	.area CSEG (CODE)
                                   2147 ; function ak820_outline_0168
      00773D                       2148 _ak820_outline_0168:
      00773D 90 08 36         [24] 2149 	mov	dptr,#_unregister_code_code_10000_724
      007740 E0               [24] 2150 	movx	a,@dptr
      007741 FF               [12] 2151 	mov	r7,a
      007742 22               [24] 2152 	ret
                                   2153 
                                   2154 	.area CSEG (CODE)
                                   2155 ; function ak820_outline_0188
      007743                       2156 _ak820_outline_0188:
      007743 F0               [24] 2157 	movx	@dptr,a
      007744 EB               [12] 2158 	mov	a,r3
      007745 A3               [24] 2159 	inc	dptr
      007746 F0               [24] 2160 	movx	@dptr,a
      007747 22               [24] 2161 	ret
