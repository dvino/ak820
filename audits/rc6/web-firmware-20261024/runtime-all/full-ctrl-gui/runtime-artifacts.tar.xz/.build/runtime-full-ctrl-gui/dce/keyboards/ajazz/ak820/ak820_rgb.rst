                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000015                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000011                        595 _suspended:
      000011                        596 	.ds 1
      000012                        597 _dirty:
      000012                        598 	.ds 1
      000013                        599 _rendering:
      000013                        600 	.ds 1
      000014                        601 _rgb_matrix_task_sloc0_1_0:
      000014                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      0006AB                        611 _rgb_matrix_config::
      0006AB                        612 	.ds 8
      0006B3                        613 _changed_at:
      0006B3                        614 	.ds 2
      0006B5                        615 _frame_at:
      0006B5                        616 	.ds 2
      0006B7                        617 _phase:
      0006B7                        618 	.ds 2
      0006B9                        619 _led_index:
      0006B9                        620 	.ds 1
      0006BA                        621 _frame_mode:
      0006BA                        622 	.ds 1
      0006BB                        623 _frame_hue:
      0006BB                        624 	.ds 1
      0006BC                        625 _frame_sat:
      0006BC                        626 	.ds 1
      0006BD                        627 _frame_val:
      0006BD                        628 	.ds 1
      0006BE                        629 _frame_flags:
      0006BE                        630 	.ds 1
      0006BF                        631 _frame_phase:
      0006BF                        632 	.ds 1
      0006C0                        633 _reactive_age:
      0006C0                        634 	.ds 82
      000712                        635 _reactive_at:
      000712                        636 	.ds 2
      000714                        637 _add_sat_PARM_2:
      000714                        638 	.ds 1
      000715                        639 _add_sat_x_10000_266:
      000715                        640 	.ds 1
      000716                        641 _sub_sat_PARM_2:
      000716                        642 	.ds 1
      000717                        643 _sub_sat_x_10000_268:
      000717                        644 	.ds 1
      000718                        645 _rgb_matrix_set_color_PARM_2:
      000718                        646 	.ds 1
      000719                        647 _rgb_matrix_set_color_PARM_3:
      000719                        648 	.ds 1
      00071A                        649 _rgb_matrix_set_color_PARM_4:
      00071A                        650 	.ds 1
      00071B                        651 _rgb_matrix_set_color_index_10000_284:
      00071B                        652 	.ds 2
      00071D                        653 _rgb_matrix_set_color_all_PARM_2:
      00071D                        654 	.ds 1
      00071E                        655 _rgb_matrix_set_color_all_PARM_3:
      00071E                        656 	.ds 1
      00071F                        657 _rgb_matrix_set_color_all_r_10000_287:
      00071F                        658 	.ds 1
      000720                        659 _sine8_theta_10000_289:
      000720                        660 	.ds 1
      000721                        661 _sine8_offset_10000_290:
      000721                        662 	.ds 1
      000722                        663 _sine8_fraction_10000_290:
      000722                        664 	.ds 1
      000723                        665 _breathing_cie_value_10000_293:
      000723                        666 	.ds 1
      000724                        667 _rgb_matrix_task_end_10000_298:
      000724                        668 	.ds 1
      000725                        669 _rgb_matrix_task_hsv_10000_298:
      000725                        670 	.ds 3
      000728                        671 _rgb_matrix_task_rgb_10000_298:
      000728                        672 	.ds 3
      00072B                        673 _process_rgb_matrix_PARM_2:
      00072B                        674 	.ds 1
      00072C                        675 _process_rgb_matrix_PARM_3:
      00072C                        676 	.ds 1
      00072D                        677 _process_rgb_matrix_row_10000_319:
      00072D                        678 	.ds 1
      00072E                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      00072E                        680 	.ds 1
      00072F                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      00072F                        682 	.ds 1
      000730                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000730                        684 	.ds 1
      000731                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000731                        686 	.ds 1
      000732                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      000732                        688 	.ds 2
      000734                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      000734                        690 	.ds 1
      000735                        691 _rgb_matrix_mode_mode_10000_411:
      000735                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      004F76                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      004F76 12 57 62         [24]  746 	lcall	_ak820_outline_0180
      004F79 74 52            [12]  747 	mov	a,#0x52
      004F7B 12 38 A1         [24]  748 	lcall	_ak820_outline_0135
      004F7E 90 06 C0         [24]  749 	mov	dptr,#_reactive_age
      004F81 F5 F0            [12]  750 	mov	b,a
      004F83 12 B9 7B         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      004F86 12 49 6B         [24]  753 	lcall	_timer_read
      004F89 12 38 A6         [24]  754 	lcall	_ak820_outline_0138
      004F8C 90 07 12         [24]  755 	mov	dptr,#_reactive_at
      004F8F 12 57 49         [24]  756 	lcall	_ak820_outline_0169
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      004F92 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      004F93                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      004F93 90 07 12         [24]  772 	mov	dptr,#_reactive_at
      004F96 12 37 F4         [24]  773 	lcall	_ak820_outline_0005
      004F99 12 49 6E         [24]  774 	lcall	_timer_elapsed
      004F9C AE 82            [24]  775 	mov	r6, dpl
      004F9E E5 83            [12]  776 	mov	a,dph
      004FA0 C4               [12]  777 	swap	a
      004FA1 CE               [12]  778 	xch	a,r6
      004FA2 C4               [12]  779 	swap	a
      004FA3 54 0F            [12]  780 	anl	a,#0x0f
      004FA5 6E               [12]  781 	xrl	a,r6
      004FA6 CE               [12]  782 	xch	a,r6
      004FA7 54 0F            [12]  783 	anl	a,#0x0f
      004FA9 CE               [12]  784 	xch	a,r6
      004FAA 6E               [12]  785 	xrl	a,r6
      004FAB CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      004FAC FF               [12]  788 	mov	r7,a
      004FAD 4E               [12]  789 	orl	a,r6
      004FAE 70 01            [24]  790 	jnz	00102$
      004FB0 22               [24]  791 	ret
      004FB1                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      004FB1 8E 04            [24]  794 	mov	ar4,r6
      004FB3 EF               [12]  795 	mov	a,r7
      004FB4 C4               [12]  796 	swap	a
      004FB5 54 F0            [12]  797 	anl	a,#0xf0
      004FB7 CC               [12]  798 	xch	a,r4
      004FB8 C4               [12]  799 	swap	a
      004FB9 CC               [12]  800 	xch	a,r4
      004FBA 6C               [12]  801 	xrl	a,r4
      004FBB CC               [12]  802 	xch	a,r4
      004FBC 54 F0            [12]  803 	anl	a,#0xf0
      004FBE CC               [12]  804 	xch	a,r4
      004FBF 6C               [12]  805 	xrl	a,r4
      004FC0 FD               [12]  806 	mov	r5,a
      004FC1 90 07 12         [24]  807 	mov	dptr,#_reactive_at
      004FC4 12 43 45         [24]  808 	lcall	_ak820_outline_0103
      004FC7 90 07 12         [24]  809 	mov	dptr,#_reactive_at
      004FCA EC               [12]  810 	mov	a,r4
      004FCB 2A               [12]  811 	add	a, r2
      004FCC F0               [24]  812 	movx	@dptr,a
      004FCD ED               [12]  813 	mov	a,r5
      004FCE 3B               [12]  814 	addc	a, r3
      004FCF A3               [24]  815 	inc	dptr
      004FD0 F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      004FD1 8E 04            [24]  818 	mov	ar4,r6
      004FD3 8F 05            [24]  819 	mov	ar5,r7
      004FD5 C3               [12]  820 	clr	c
      004FD6 74 FF            [12]  821 	mov	a,#0xff
      004FD8 9C               [12]  822 	subb	a,r4
      004FD9 E4               [12]  823 	clr	a
      004FDA 9D               [12]  824 	subb	a,r5
      004FDB 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      004FDD 7D FF            [12]  827 	mov	r5,#0xff
      004FDF 80 02            [24]  828 	sjmp	00109$
      004FE1                        829 00108$:
      004FE1 8E 05            [24]  830 	mov	ar5,r6
      004FE3                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      004FE3 7F 00            [12]  833 	mov	r7,#0x00
      004FE5                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      004FE5 EF               [12]  836 	mov	a,r7
      004FE6 24 C0            [12]  837 	add	a, #_reactive_age
      004FE8 FC               [12]  838 	mov	r4,a
      004FE9 E4               [12]  839 	clr	a
      004FEA 34 06            [12]  840 	addc	a, #(_reactive_age >> 8)
      004FEC FE               [12]  841 	mov	r6,a
      004FED 8C 82            [24]  842 	mov	dpl,r4
      004FEF 8E 83            [24]  843 	mov	dph,r6
      004FF1 E0               [24]  844 	movx	a,@dptr
      004FF2 FB               [12]  845 	mov	r3,a
      004FF3 C3               [12]  846 	clr	c
      004FF4 ED               [12]  847 	mov	a,r5
      004FF5 9B               [12]  848 	subb	a,r3
      004FF6 40 04            [24]  849 	jc	00110$
      004FF8 7B 00            [12]  850 	mov	r3,#0x00
      004FFA 80 08            [24]  851 	sjmp	00111$
      004FFC                        852 00110$:
      004FFC 8C 82            [24]  853 	mov	dpl,r4
      004FFE 8E 83            [24]  854 	mov	dph,r6
      005000 E0               [24]  855 	movx	a,@dptr
      005001 C3               [12]  856 	clr	c
      005002 9D               [12]  857 	subb	a,r5
      005003 FB               [12]  858 	mov	r3,a
      005004                        859 00111$:
      005004 8C 82            [24]  860 	mov	dpl,r4
      005006 8E 83            [24]  861 	mov	dph,r6
      005008 EB               [12]  862 	mov	a,r3
      005009 F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      00500A 0F               [12]  865 	inc	r7
      00500B BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      00500E                        867 00144$:
      00500E 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      005010 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      005011                        881 _add_sat:
      005011 E5 82            [12]  882 	mov	a,dpl
      005013 90 07 15         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      005016 F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      005017 90 07 14         [24]  886 	mov	dptr,#_add_sat_PARM_2
      00501A E0               [24]  887 	movx	a,@dptr
      00501B FF               [12]  888 	mov	r7,a
      00501C FE               [12]  889 	mov	r6,a
      00501D 74 FF            [12]  890 	mov	a,#0xff
      00501F C3               [12]  891 	clr	c
      005020 9E               [12]  892 	subb	a,r6
      005021 FE               [12]  893 	mov	r6,a
      005022 90 07 15         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      005025 E0               [24]  895 	movx	a,@dptr
      005026 FD               [12]  896 	mov	r5,a
      005027 C3               [12]  897 	clr	c
      005028 EE               [12]  898 	mov	a,r6
      005029 9D               [12]  899 	subb	a,r5
      00502A 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      00502C 7E FF            [12]  902 	mov	r6,#0xff
      00502E 80 03            [24]  903 	sjmp	00104$
      005030                        904 00103$:
      005030 EF               [12]  905 	mov	a,r7
      005031 2D               [12]  906 	add	a, r5
      005032 FE               [12]  907 	mov	r6,a
      005033                        908 00104$:
      005033 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      005035 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      005036                        922 _sub_sat:
      005036 E5 82            [12]  923 	mov	a,dpl
      005038 90 07 17         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      00503B F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      00503C E0               [24]  927 	movx	a,@dptr
      00503D FF               [12]  928 	mov	r7,a
      00503E 90 07 16         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      005041 E0               [24]  930 	movx	a,@dptr
      005042 FE               [12]  931 	mov	r6,a
      005043 C3               [12]  932 	clr	c
      005044 EF               [12]  933 	mov	a,r7
      005045 9E               [12]  934 	subb	a,r6
      005046 50 04            [24]  935 	jnc	00103$
      005048 7D 00            [12]  936 	mov	r5,#0x00
      00504A 80 04            [24]  937 	sjmp	00104$
      00504C                        938 00103$:
      00504C EF               [12]  939 	mov	a,r7
      00504D C3               [12]  940 	clr	c
      00504E 9E               [12]  941 	subb	a,r6
      00504F FD               [12]  942 	mov	r5,a
      005050                        943 00104$:
      005050 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      005052 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      005053                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      005053 D2 12            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      005055 12 49 6B         [24]  959 	lcall	_timer_read
      005058 12 38 A6         [24]  960 	lcall	_ak820_outline_0138
      00505B 90 06 B3         [24]  961 	mov	dptr,#_changed_at
      00505E 12 57 49         [24]  962 	lcall	_ak820_outline_0169
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      005061 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      005062                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      005062 90 06 B2         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      005065 E4               [12]  978 	clr	a
      005066 F0               [24]  979 	movx	@dptr,a
      005067 90 06 B1         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      00506A F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      00506B 90 05 95         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00506E 12 57 2C         [24]  984 	lcall	_ak820_outline_0085
      005071 90 05 98         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      005074 12 57 13         [24]  986 	lcall	_ak820_outline_0069
      005077 12 42 20         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      00507A C2 12            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      00507C 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      00507D                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      00507D 12 57 62         [24] 1002 	lcall	_ak820_outline_0180
      005080 12 57 13         [24] 1003 	lcall	_ak820_outline_0069
      005083 F5 F0            [12] 1004 	mov	b,a
      005085 12 B9 7B         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      005088 12 57 3C         [24] 1007 	lcall	_ak820_outline_0116
      00508B 44 01            [12] 1008 	orl	a,#0x01
      00508D F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      00508E 12 57 0C         [24] 1011 	lcall	_ak820_outline_0065
      005091 44 04            [12] 1012 	orl	a,#0x04
      005093 F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      005094 90 06 AC         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005097 E4               [12] 1016 	clr	a
      005098 F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      005099 90 06 AD         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00509C 14               [12] 1020 	dec	a
      00509D F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      00509E 90 06 AE         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0050A1 74 50            [12] 1024 	mov	a,#0x50
      0050A3 F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      0050A4 90 06 AF         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0050A7 74 60            [12] 1028 	mov	a,#0x60
      0050A9 F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      0050AA 90 06 B0         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      0050AD 74 FF            [12] 1032 	mov	a,#0xff
      0050AF F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      0050B0 02 50 62         [24] 1036 	ljmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      0050B3                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      0050B3 90 05 85         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0050B6 12 57 2C         [24] 1047 	lcall	_ak820_outline_0085
      0050B9 90 05 88         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0050BC 12 57 13         [24] 1049 	lcall	_ak820_outline_0069
      0050BF 12 40 B1         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      0050C2 12 57 3C         [24] 1052 	lcall	_ak820_outline_0116
      0050C5 60 11            [24] 1053 	jz	00101$
      0050C7 12 56 ED         [24] 1054 	lcall	_ak820_outline_0019
      0050CA C3               [12] 1055 	clr	c
      0050CB 64 80            [12] 1056 	xrl	a,#0x80
      0050CD 94 87            [12] 1057 	subb	a,#0x87
      0050CF 50 07            [24] 1058 	jnc	00101$
      0050D1 12 57 0C         [24] 1059 	lcall	_ak820_outline_0065
      0050D4 24 FE            [12] 1060 	add	a,#0xff - 0x01
      0050D6 50 03            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      0050D8                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      0050D8 12 50 7D         [24] 1065 	lcall	_eeconfig_update_rgb_matrix_default
      0050DB                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      0050DB 90 06 AE         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0050DE E0               [24] 1069 	movx	a,@dptr
      0050DF 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      0050E1 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      0050E3 90 06 AE         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0050E6 74 A0            [12] 1075 	mov	a,#0xa0
      0050E8 F0               [24] 1076 	movx	@dptr,a
      0050E9                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      0050E9 C2 12            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      0050EB C2 13            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      0050ED 02 4F 76         [24] 1086 	ljmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      0050F0                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      0050F0 12 50 B3         [24] 1096 	lcall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      0050F3 12 49 6B         [24] 1098 	lcall	_timer_read
      0050F6 12 43 57         [24] 1099 	lcall	_ak820_outline_0134
      0050F9 EE               [12] 1100 	mov	a,r6
      0050FA 24 F0            [12] 1101 	add	a,#0xf0
      0050FC FE               [12] 1102 	mov	r6,a
      0050FD EF               [12] 1103 	mov	a,r7
      0050FE 34 FF            [12] 1104 	addc	a,#0xff
      005100 FF               [12] 1105 	mov	r7,a
      005101 90 06 B5         [24] 1106 	mov	dptr,#_frame_at
      005104 12 48 B1         [24] 1107 	lcall	_ak820_outline_0058
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      005107 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      005108                       1122 _rgb_matrix_set_color:
      005108 12 38 88         [24] 1123 	lcall	_ak820_outline_0108
      00510B 90 07 1B         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      00510E 12 38 8D         [24] 1125 	lcall	_ak820_outline_0109
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      005111 90 07 1B         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      005114 12 38 41         [24] 1128 	lcall	_ak820_outline_0051
      005117 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      00511A C3               [12] 1130 	clr	c
      00511B EE               [12] 1131 	mov	a,r6
      00511C 94 52            [12] 1132 	subb	a,#0x52
      00511E EF               [12] 1133 	mov	a,r7
      00511F 64 80            [12] 1134 	xrl	a,#0x80
      005121 94 80            [12] 1135 	subb	a,#0x80
      005123 50 23            [24] 1136 	jnc	00104$
      005125 90 07 18         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005128 E0               [24] 1138 	movx	a,@dptr
      005129 FF               [12] 1139 	mov	r7,a
      00512A 90 07 19         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00512D E0               [24] 1141 	movx	a,@dptr
      00512E FD               [12] 1142 	mov	r5,a
      00512F 90 07 1A         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005132 E0               [24] 1144 	movx	a,@dptr
      005133 FC               [12] 1145 	mov	r4,a
      005134 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      005137 EF               [12] 1147 	mov	a,r7
      005138 F0               [24] 1148 	movx	@dptr,a
      005139 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      00513C ED               [12] 1150 	mov	a,r5
      00513D F0               [24] 1151 	movx	@dptr,a
      00513E 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      005141 EC               [12] 1153 	mov	a,r4
      005142 F0               [24] 1154 	movx	@dptr,a
      005143 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      005145 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      005148                       1158 00104$:
      005148 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      005149                       1171 _rgb_matrix_set_color_all:
      005149 E5 82            [12] 1172 	mov	a,dpl
      00514B 90 07 1F         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      00514E F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      00514F E0               [24] 1176 	movx	a,@dptr
      005150 FF               [12] 1177 	mov	r7,a
      005151 90 07 1D         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      005154 E0               [24] 1179 	movx	a,@dptr
      005155 FE               [12] 1180 	mov	r6,a
      005156 90 07 1E         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      005159 E0               [24] 1182 	movx	a,@dptr
      00515A FD               [12] 1183 	mov	r5,a
      00515B 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      00515E EE               [12] 1185 	mov	a,r6
      00515F F0               [24] 1186 	movx	@dptr,a
      005160 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      005163 ED               [12] 1188 	mov	a,r5
      005164 F0               [24] 1189 	movx	@dptr,a
      005165 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      005167 02 33 B9         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      00516A                       1206 _sine8:
      00516A E5 82            [12] 1207 	mov	a,dpl
      00516C 90 07 20         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      00516F F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      005170 E0               [24] 1211 	movx	a,@dptr
      005171 FF               [12] 1212 	mov	r7,a
      005172 90 07 21         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      005175 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      005176 EF               [12] 1216 	mov	a,r7
      005177 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      00517A 90 07 21         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      00517D 74 FF            [12] 1219 	mov	a,#0xff
      00517F C3               [12] 1220 	clr	c
      005180 9F               [12] 1221 	subb	a,r7
      005181 F0               [24] 1222 	movx	@dptr,a
      005182                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      005182 90 07 21         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      005185 E0               [24] 1226 	movx	a,@dptr
      005186 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      005189 F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      00518A 90 07 21         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      00518D E0               [24] 1231 	movx	a,@dptr
      00518E 54 0F            [12] 1232 	anl	a,#0x0f
      005190 FF               [12] 1233 	mov	r7,a
      005191 90 07 22         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      005194 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      005195 90 07 20         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      005198 E0               [24] 1238 	movx	a,@dptr
      005199 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      00519C 90 07 22         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      00519F EF               [12] 1241 	mov	a,r7
      0051A0 04               [12] 1242 	inc	a
      0051A1 F0               [24] 1243 	movx	@dptr,a
      0051A2                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      0051A2 90 07 21         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      0051A5 E0               [24] 1247 	movx	a,@dptr
      0051A6 C4               [12] 1248 	swap	a
      0051A7 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      0051A9 25 E0            [12] 1251 	add	a,acc
      0051AB FF               [12] 1252 	mov	r7,a
      0051AC 90 BA 60         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      0051AF 93               [24] 1254 	movc	a,@a+dptr
      0051B0 FE               [12] 1255 	mov	r6,a
      0051B1 0F               [12] 1256 	inc	r7
      0051B2 EF               [12] 1257 	mov	a,r7
      0051B3 90 BA 60         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      0051B6 93               [24] 1259 	movc	a,@a+dptr
      0051B7 FF               [12] 1260 	mov	r7,a
      0051B8 90 07 22         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      0051BB E0               [24] 1262 	movx	a,@dptr
      0051BC 8F F0            [24] 1263 	mov	b,r7
      0051BE A4               [48] 1264 	mul	ab
      0051BF FF               [12] 1265 	mov	r7,a
      0051C0 E5 F0            [12] 1266 	mov	a,b
      0051C2 C4               [12] 1267 	swap	a
      0051C3 CF               [12] 1268 	xch	a,r7
      0051C4 C4               [12] 1269 	swap	a
      0051C5 54 0F            [12] 1270 	anl	a,#0x0f
      0051C7 6F               [12] 1271 	xrl	a,r7
      0051C8 CF               [12] 1272 	xch	a,r7
      0051C9 54 0F            [12] 1273 	anl	a,#0x0f
      0051CB CF               [12] 1274 	xch	a,r7
      0051CC 6F               [12] 1275 	xrl	a,r7
      0051CD CF               [12] 1276 	xch	a,r7
      0051CE EF               [12] 1277 	mov	a,r7
      0051CF 2E               [12] 1278 	add	a, r6
      0051D0 FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      0051D1 90 07 20         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      0051D4 E0               [24] 1282 	movx	a,@dptr
      0051D5 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      0051D8 8F 06            [24] 1284 	mov	ar6,r7
      0051DA 74 80            [12] 1285 	mov	a,#0x80
      0051DC C3               [12] 1286 	clr	c
      0051DD 9E               [12] 1287 	subb	a,r6
      0051DE FE               [12] 1288 	mov	r6,a
      0051DF 80 04            [24] 1289 	sjmp	00108$
      0051E1                       1290 00107$:
      0051E1 74 80            [12] 1291 	mov	a,#0x80
      0051E3 2F               [12] 1292 	add	a, r7
      0051E4 FE               [12] 1293 	mov	r6,a
      0051E5                       1294 00108$:
      0051E5 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      0051E7 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      0051E8                       1312 _breathing_cie:
      0051E8 E5 82            [12] 1313 	mov	a,dpl
      0051EA 90 07 23         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      0051ED F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      0051EE E0               [24] 1317 	movx	a,@dptr
      0051EF FF               [12] 1318 	mov	r7,a
      0051F0 12 57 54         [24] 1319 	lcall	_ak820_outline_0171
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      0051F3 FE               [12] 1321 	mov	r6,a
      0051F4 90 BD 6C         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      0051F7 93               [24] 1323 	movc	a,@a+dptr
      0051F8 FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      0051F9 BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      0051FC 8D 82            [24] 1327 	mov	dpl, r5
      0051FE 22               [24] 1328 	ret
      0051FF                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      0051FF EE               [12] 1331 	mov	a,r6
      005200 04               [12] 1332 	inc	a
      005201 90 BD 6C         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      005204 93               [24] 1334 	movc	a,@a+dptr
      005205 C3               [12] 1335 	clr	c
      005206 9D               [12] 1336 	subb	a,r5
      005207 FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      005208 74 07            [12] 1339 	mov	a,#0x07
      00520A 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      00520B F5 F0            [12] 1342 	mov	b,a
      00520D EE               [12] 1343 	mov	a,r6
      00520E A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      00520F 12 57 54         [24] 1346 	lcall	_ak820_outline_0171
      005212 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      005213 F5 82            [12] 1349 	mov	dpl,a
      005215 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      005216                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      005216 12 4F 93         [24] 1367 	lcall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      005219 30 12 18         [24] 1369 	jnb	_dirty,00102$
      00521C 90 06 B3         [24] 1370 	mov	dptr,#_changed_at
      00521F 12 37 F4         [24] 1371 	lcall	_ak820_outline_0005
      005222 12 49 6E         [24] 1372 	lcall	_timer_elapsed
      005225 12 43 57         [24] 1373 	lcall	_ak820_outline_0134
      005228 C3               [12] 1374 	clr	c
      005229 EE               [12] 1375 	mov	a,r6
      00522A 94 E8            [12] 1376 	subb	a,#0xe8
      00522C EF               [12] 1377 	mov	a,r7
      00522D 94 03            [12] 1378 	subb	a,#0x03
      00522F 40 03            [24] 1379 	jc	00102$
      005231 12 50 62         [24] 1380 	lcall	_eeconfig_update_rgb_matrix
      005234                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      005234 30 13 03         [24] 1383 	jnb	_rendering,00254$
      005237 02 52 EF         [24] 1384 	ljmp	00109$
      00523A                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      00523A 90 06 B5         [24] 1387 	mov	dptr,#_frame_at
      00523D 12 37 F4         [24] 1388 	lcall	_ak820_outline_0005
      005240 12 49 6E         [24] 1389 	lcall	_timer_elapsed
      005243 12 43 57         [24] 1390 	lcall	_ak820_outline_0134
      005246 C3               [12] 1391 	clr	c
      005247 EE               [12] 1392 	mov	a,r6
      005248 94 10            [12] 1393 	subb	a,#0x10
      00524A EF               [12] 1394 	mov	a,r7
      00524B 94 00            [12] 1395 	subb	a,#0x00
      00524D 50 01            [24] 1396 	jnc	00105$
      00524F 22               [24] 1397 	ret
      005250                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      005250 12 49 6B         [24] 1400 	lcall	_timer_read
      005253 12 38 A6         [24] 1401 	lcall	_ak820_outline_0138
      005256 90 06 B5         [24] 1402 	mov	dptr,#_frame_at
      005259 12 57 49         [24] 1403 	lcall	_ak820_outline_0169
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      00525C 90 06 AF         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00525F E0               [24] 1406 	movx	a,@dptr
      005260 FF               [12] 1407 	mov	r7,a
      005261 7E 00            [12] 1408 	mov	r6,#0x00
      005263 74 20            [12] 1409 	mov	a,#0x20
      005265 2F               [12] 1410 	add	a, r7
      005266 FF               [12] 1411 	mov	r7,a
      005267 E4               [12] 1412 	clr	a
      005268 3E               [12] 1413 	addc	a, r6
      005269 FE               [12] 1414 	mov	r6,a
      00526A 90 06 B7         [24] 1415 	mov	dptr,#_phase
      00526D 12 38 58         [24] 1416 	lcall	_ak820_outline_0059
      005270 EF               [12] 1417 	mov	a,r7
      005271 2C               [12] 1418 	add	a, r4
      005272 FF               [12] 1419 	mov	r7,a
      005273 EE               [12] 1420 	mov	a,r6
      005274 3D               [12] 1421 	addc	a, r5
      005275 FE               [12] 1422 	mov	r6,a
      005276 90 06 B7         [24] 1423 	mov	dptr,#_phase
      005279 EF               [12] 1424 	mov	a,r7
      00527A F0               [24] 1425 	movx	@dptr,a
      00527B EE               [12] 1426 	mov	a,r6
      00527C A3               [24] 1427 	inc	dptr
      00527D F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      00527E 90 06 B7         [24] 1430 	mov	dptr,#_phase
      005281 E0               [24] 1431 	movx	a,@dptr
      005282 A3               [24] 1432 	inc	dptr
      005283 E0               [24] 1433 	movx	a,@dptr
      005284 FF               [12] 1434 	mov	r7,a
      005285 90 06 BF         [24] 1435 	mov	dptr,#_frame_phase
      005288 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      005289 20 11 05         [24] 1438 	jb	_suspended,00135$
      00528C 12 57 0C         [24] 1439 	lcall	_ak820_outline_0065
      00528F 70 04            [24] 1440 	jnz	00132$
      005291                       1441 00135$:
      005291 7E 00            [12] 1442 	mov	r6,#0x00
      005293 80 04            [24] 1443 	sjmp	00133$
      005295                       1444 00132$:
      005295 12 56 ED         [24] 1445 	lcall	_ak820_outline_0019
      005298 FE               [12] 1446 	mov	r6,a
      005299                       1447 00133$:
      005299 90 06 BA         [24] 1448 	mov	dptr,#_frame_mode
      00529C EE               [12] 1449 	mov	a,r6
      00529D F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      00529E 90 06 AC         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0052A1 E0               [24] 1453 	movx	a,@dptr
      0052A2 90 06 BB         [24] 1454 	mov	dptr,#_frame_hue
      0052A5 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      0052A6 90 06 AD         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0052A9 E0               [24] 1458 	movx	a,@dptr
      0052AA 90 06 BC         [24] 1459 	mov	dptr,#_frame_sat
      0052AD F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      0052AE 90 06 AE         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0052B1 E0               [24] 1463 	movx	a,@dptr
      0052B2 FD               [12] 1464 	mov	r5,a
      0052B3 90 06 BD         [24] 1465 	mov	dptr,#_frame_val
      0052B6 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      0052B7 90 06 B0         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      0052BA E0               [24] 1469 	movx	a,@dptr
      0052BB 90 06 BE         [24] 1470 	mov	dptr,#_frame_flags
      0052BE F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      0052BF BE 02 26         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      0052C2 EF               [12] 1475 	mov	a,r7
      0052C3 24 C0            [12] 1476 	add	a,#0xc0
      0052C5 F5 82            [12] 1477 	mov	dpl,a
      0052C7 C0 05            [24] 1478 	push	ar5
      0052C9 12 51 6A         [24] 1479 	lcall	_sine8
      0052CC AF 82            [24] 1480 	mov	r7, dpl
      0052CE D0 05            [24] 1481 	pop	ar5
      0052D0 8D F0            [24] 1482 	mov	b,r5
      0052D2 EF               [12] 1483 	mov	a,r7
      0052D3 A4               [48] 1484 	mul	ab
      0052D4 AE F0            [24] 1485 	mov	r6,b
      0052D6 8E 05            [24] 1486 	mov	ar5,r6
      0052D8 90 06 BD         [24] 1487 	mov	dptr,#_frame_val
      0052DB ED               [12] 1488 	mov	a,r5
      0052DC F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      0052DD 8D 82            [24] 1491 	mov	dpl, r5
      0052DF 12 51 E8         [24] 1492 	lcall	_breathing_cie
      0052E2 E5 82            [12] 1493 	mov	a, dpl
      0052E4 90 06 BD         [24] 1494 	mov	dptr,#_frame_val
      0052E7 F0               [24] 1495 	movx	@dptr,a
      0052E8                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      0052E8 90 06 B9         [24] 1498 	mov	dptr,#_led_index
      0052EB E4               [12] 1499 	clr	a
      0052EC F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      0052ED D2 13            [12] 1503 	setb	_rendering
      0052EF                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      0052EF 12 57 6B         [24] 1506 	lcall	_ak820_outline_0187
      0052F2 24 08            [12] 1507 	add	a,#0x08
      0052F4 FF               [12] 1508 	mov	r7,a
      0052F5 90 07 24         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0052F8 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      0052F9 EF               [12] 1512 	mov	a,r7
      0052FA 24 AD            [12] 1513 	add	a,#0xff - 0x52
      0052FC 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      0052FE 90 07 24         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      005301 74 52            [12] 1517 	mov	a,#0x52
      005303 F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      005304                       1520 00125$:
      005304 12 57 6B         [24] 1521 	lcall	_ak820_outline_0187
      005307 FF               [12] 1522 	mov	r7,a
      005308 90 07 24         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      00530B E0               [24] 1524 	movx	a,@dptr
      00530C FE               [12] 1525 	mov	r6,a
      00530D C3               [12] 1526 	clr	c
      00530E EF               [12] 1527 	mov	a,r7
      00530F 9E               [12] 1528 	subb	a,r6
      005310 40 03            [24] 1529 	jc	00261$
      005312 02 54 75         [24] 1530 	ljmp	00127$
      005315                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      005315 12 57 43         [24] 1533 	lcall	_ak820_outline_0140
      005318 E0               [24] 1534 	movx	a,@dptr
      005319 60 07            [24] 1535 	jz	00121$
      00531B 90 06 BE         [24] 1536 	mov	dptr,#_frame_flags
      00531E E0               [24] 1537 	movx	a,@dptr
      00531F 20 E2 1B         [24] 1538 	jb	acc.2,00122$
      005322                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      005322 12 57 6B         [24] 1541 	lcall	_ak820_outline_0187
      005325 FC               [12] 1542 	mov	r4,a
      005326 7D 00            [12] 1543 	mov	r5,#0x00
      005328 90 07 18         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      00532B E4               [12] 1545 	clr	a
      00532C F0               [24] 1546 	movx	@dptr,a
      00532D 90 07 19         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      005330 F0               [24] 1548 	movx	@dptr,a
      005331 90 07 1A         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005334 12 38 76         [24] 1550 	lcall	_ak820_outline_0100
      005337 12 51 08         [24] 1551 	lcall	_rgb_matrix_set_color
      00533A 02 54 6C         [24] 1552 	ljmp	00123$
      00533D                       1553 00122$:
                                   1554 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      00533D BE 05 21         [24] 1555 	cjne	r6,#0x05,00119$
                                   1556 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      005340 EF               [12] 1557 	mov	a,r7
      005341 75 F0 03         [24] 1558 	mov	b,#0x03
      005344 A4               [48] 1559 	mul	ab
      005345 24 8C            [12] 1560 	add	a, #_g_direct_mode_colors
      005347 FD               [12] 1561 	mov	r5,a
      005348 74 0C            [12] 1562 	mov	a,#(_g_direct_mode_colors >> 8)
      00534A 35 F0            [12] 1563 	addc	a, b
      00534C FE               [12] 1564 	mov	r6,a
      00534D 90 0D A0         [24] 1565 	mov	dptr,#___memcpy_PARM_2
      005350 ED               [12] 1566 	mov	a,r5
      005351 F0               [24] 1567 	movx	@dptr,a
      005352 EE               [12] 1568 	mov	a,r6
      005353 12 57 1D         [24] 1569 	lcall	_ak820_outline_0073
      005356 90 07 25         [24] 1570 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005359 F5 F0            [12] 1571 	mov	b,a
      00535B 12 B9 05         [24] 1572 	lcall	___memcpy
      00535E 02 54 10         [24] 1573 	ljmp	00120$
      005361                       1574 00119$:
                                   1575 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      005361 90 06 BB         [24] 1576 	mov	dptr,#_frame_hue
      005364 E0               [24] 1577 	movx	a,@dptr
      005365 90 07 25         [24] 1578 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005368 F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      005369 90 06 BC         [24] 1581 	mov	dptr,#_frame_sat
      00536C E0               [24] 1582 	movx	a,@dptr
      00536D 90 07 26         [24] 1583 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      005370 F0               [24] 1584 	movx	@dptr,a
                                   1585 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      005371 90 06 BD         [24] 1586 	mov	dptr,#_frame_val
      005374 E0               [24] 1587 	movx	a,@dptr
      005375 90 07 27         [24] 1588 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005378 F0               [24] 1589 	movx	@dptr,a
                                   1590 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      005379 12 57 43         [24] 1591 	lcall	_ak820_outline_0140
      00537C BE 03 0E         [24] 1592 	cjne	r6,#0x03,00113$
      00537F 90 07 25         [24] 1593 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005382 E0               [24] 1594 	movx	a,@dptr
      005383 FE               [12] 1595 	mov	r6,a
      005384 90 06 BF         [24] 1596 	mov	dptr,#_frame_phase
      005387 E0               [24] 1597 	movx	a,@dptr
      005388 2E               [12] 1598 	add	a, r6
      005389 90 07 25         [24] 1599 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00538C F0               [24] 1600 	movx	@dptr,a
      00538D                       1601 00113$:
                                   1602 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      00538D 12 57 43         [24] 1603 	lcall	_ak820_outline_0140
      005390 BE 04 23         [24] 1604 	cjne	r6,#0x04,00115$
      005393 90 07 25         [24] 1605 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005396 E0               [24] 1606 	movx	a,@dptr
      005397 FE               [12] 1607 	mov	r6,a
      005398 12 57 6B         [24] 1608 	lcall	_ak820_outline_0187
      00539B 75 F0 02         [24] 1609 	mov	b,#0x02
      00539E A4               [48] 1610 	mul	ab
      00539F 24 C8            [12] 1611 	add	a, #_ak820_led_points
      0053A1 F5 82            [12] 1612 	mov	dpl,a
      0053A3 74 BC            [12] 1613 	mov	a,#(_ak820_led_points >> 8)
      0053A5 12 57 35         [24] 1614 	lcall	_ak820_outline_0110
      0053A8 FD               [12] 1615 	mov	r5,a
      0053A9 90 06 BF         [24] 1616 	mov	dptr,#_frame_phase
      0053AC E0               [24] 1617 	movx	a,@dptr
      0053AD FC               [12] 1618 	mov	r4,a
      0053AE ED               [12] 1619 	mov	a,r5
      0053AF C3               [12] 1620 	clr	c
      0053B0 9C               [12] 1621 	subb	a,r4
      0053B1 2E               [12] 1622 	add	a, r6
      0053B2 90 07 25         [24] 1623 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      0053B5 F0               [24] 1624 	movx	@dptr,a
      0053B6                       1625 00115$:
                                   1626 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      0053B6 12 57 43         [24] 1627 	lcall	_ak820_outline_0140
      0053B9 BE 06 54         [24] 1628 	cjne	r6,#0x06,00120$
                                   1629 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      0053BC 12 57 59         [24] 1630 	lcall	_ak820_outline_0174
      0053BF FE               [12] 1631 	mov	r6,a
      0053C0 74 07            [12] 1632 	mov	a,#0x07
      0053C2 C3               [12] 1633 	clr	c
      0053C3 9E               [12] 1634 	subb	a,r6
      0053C4 FE               [12] 1635 	mov	r6,a
                                   1636 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      0053C5 8E F0            [24] 1637 	mov	b,r6
      0053C7 05 F0            [12] 1638 	inc	b
      0053C9 74 01            [12] 1639 	mov	a,#0x01
      0053CB 80 02            [24] 1640 	sjmp	00273$
      0053CD                       1641 00272$:
      0053CD 25 E0            [12] 1642 	add	a,acc
      0053CF                       1643 00273$:
      0053CF D5 F0 FB         [24] 1644 	djnz	b,00272$
      0053D2 FD               [12] 1645 	mov	r5,a
                                   1646 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      0053D3 12 57 6B         [24] 1647 	lcall	_ak820_outline_0187
      0053D6 24 C0            [12] 1648 	add	a, #_reactive_age
      0053D8 F5 82            [12] 1649 	mov	dpl,a
      0053DA E4               [12] 1650 	clr	a
      0053DB 34 06            [12] 1651 	addc	a, #(_reactive_age >> 8)
      0053DD F5 83            [12] 1652 	mov	dph,a
      0053DF E0               [24] 1653 	movx	a,@dptr
                                   1654 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      0053E0 FC               [12] 1655 	mov	r4,a
      0053E1 C3               [12] 1656 	clr	c
      0053E2 9D               [12] 1657 	subb	a,r5
      0053E3 40 07            [24] 1658 	jc	00137$
      0053E5 90 06 BD         [24] 1659 	mov	dptr,#_frame_val
      0053E8 E0               [24] 1660 	movx	a,@dptr
      0053E9 FB               [12] 1661 	mov	r3,a
      0053EA 80 1F            [24] 1662 	sjmp	00138$
      0053EC                       1663 00137$:
      0053EC 90 06 BD         [24] 1664 	mov	dptr,#_frame_val
      0053EF E0               [24] 1665 	movx	a,@dptr
      0053F0 F5 F0            [12] 1666 	mov	b, a
      0053F2 EC               [12] 1667 	mov	a,r4
      0053F3 A4               [48] 1668 	mul	ab
      0053F4 FC               [12] 1669 	mov	r4,a
      0053F5 AA F0            [24] 1670 	mov	r2,b
      0053F7 8E F0            [24] 1671 	mov	b,r6
      0053F9 05 F0            [12] 1672 	inc	b
      0053FB AB 04            [24] 1673 	mov	r3,ar4
      0053FD AD 02            [24] 1674 	mov	r5,ar2
      0053FF 80 07            [24] 1675 	sjmp	00276$
      005401                       1676 00275$:
      005401 C3               [12] 1677 	clr	c
      005402 ED               [12] 1678 	mov	a,r5
      005403 13               [12] 1679 	rrc	a
      005404 FD               [12] 1680 	mov	r5,a
      005405 EB               [12] 1681 	mov	a,r3
      005406 13               [12] 1682 	rrc	a
      005407 FB               [12] 1683 	mov	r3,a
      005408                       1684 00276$:
      005408 D5 F0 F6         [24] 1685 	djnz	b,00275$
      00540B                       1686 00138$:
      00540B 90 07 27         [24] 1687 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      00540E EB               [12] 1688 	mov	a,r3
      00540F F0               [24] 1689 	movx	@dptr,a
      005410                       1690 00120$:
                                   1691 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      005410 12 57 43         [24] 1692 	lcall	_ak820_outline_0140
      005413 BE 02 03         [24] 1693 	cjne	r6,#0x02,00277$
      005416 D3               [12] 1694 	setb	c
      005417 80 01            [24] 1695 	sjmp	00278$
      005419                       1696 00277$:
      005419 C3               [12] 1697 	clr	c
      00541A                       1698 00278$:
      00541A B3               [12] 1699 	cpl	c
      00541B 92 14            [24] 1700 	mov	_rgb_matrix_task_sloc0_1_0,c
      00541D 90 0D A0         [24] 1701 	mov	dptr,#___memcpy_PARM_2
      005420 74 25            [12] 1702 	mov	a,#_rgb_matrix_task_hsv_10000_298
      005422 F0               [24] 1703 	movx	@dptr,a
      005423 74 07            [12] 1704 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      005425 12 57 1D         [24] 1705 	lcall	_ak820_outline_0073
      005428 90 0A C3         [24] 1706 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      00542B F5 F0            [12] 1707 	mov	b,a
      00542D 12 B9 05         [24] 1708 	lcall	___memcpy
      005430 90 0A C6         [24] 1709 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      005433 74 28            [12] 1710 	mov	a,#_rgb_matrix_task_rgb_10000_298
      005435 F0               [24] 1711 	movx	@dptr,a
      005436 74 07            [12] 1712 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      005438 A3               [24] 1713 	inc	dptr
      005439 F0               [24] 1714 	movx	@dptr,a
      00543A A2 14            [12] 1715 	mov	c,_rgb_matrix_task_sloc0_1_0
      00543C 12 38 B1         [24] 1716 	lcall	_ak820_outline_0156
      00543F 12 82 23         [24] 1717 	lcall	_hsv_to_rgb_into
                                   1718 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      005442 12 57 6B         [24] 1719 	lcall	_ak820_outline_0187
      005445 FD               [12] 1720 	mov	r5,a
      005446 7E 00            [12] 1721 	mov	r6,#0x00
      005448 90 07 29         [24] 1722 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      00544B E0               [24] 1723 	movx	a,@dptr
      00544C FC               [12] 1724 	mov	r4,a
      00544D 90 07 28         [24] 1725 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      005450 E0               [24] 1726 	movx	a,@dptr
      005451 FB               [12] 1727 	mov	r3,a
      005452 90 07 2A         [24] 1728 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      005455 E0               [24] 1729 	movx	a,@dptr
      005456 FA               [12] 1730 	mov	r2,a
      005457 90 07 18         [24] 1731 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      00545A EC               [12] 1732 	mov	a,r4
      00545B F0               [24] 1733 	movx	@dptr,a
      00545C 90 07 19         [24] 1734 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      00545F EB               [12] 1735 	mov	a,r3
      005460 F0               [24] 1736 	movx	@dptr,a
      005461 90 07 1A         [24] 1737 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      005464 EA               [12] 1738 	mov	a,r2
      005465 F0               [24] 1739 	movx	@dptr,a
      005466 12 38 9C         [24] 1740 	lcall	_ak820_outline_0133
      005469 12 51 08         [24] 1741 	lcall	_rgb_matrix_set_color
      00546C                       1742 00123$:
                                   1743 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      00546C 12 57 6B         [24] 1744 	lcall	_ak820_outline_0187
      00546F 24 01            [12] 1745 	add	a, #0x01
      005471 F0               [24] 1746 	movx	@dptr,a
      005472 02 53 04         [24] 1747 	ljmp	00125$
      005475                       1748 00127$:
                                   1749 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      005475 BF 52 02         [24] 1750 	cjne	r7,#0x52,00130$
                                   1751 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1752 ;	assignBit
      005478 C2 13            [12] 1753 	clr	_rendering
      00547A                       1754 00130$:
                                   1755 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      00547A 22               [24] 1756 	ret
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1759 ;------------------------------------------------------------
                                   1760 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1761 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1762 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1763 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1764 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1765 ;------------------------------------------------------------
                                   1766 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1767 ;	-----------------------------------------
                                   1768 ;	 function process_rgb_matrix
                                   1769 ;	-----------------------------------------
      00547B                       1770 _process_rgb_matrix:
      00547B E5 82            [12] 1771 	mov	a,dpl
      00547D 90 07 2D         [24] 1772 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005480 F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      005481 90 07 2C         [24] 1775 	mov	dptr,#_process_rgb_matrix_PARM_3
      005484 E0               [24] 1776 	movx	a,@dptr
      005485 60 23            [24] 1777 	jz	00101$
      005487 20 11 20         [24] 1778 	jb	_suspended,00101$
      00548A 12 57 0C         [24] 1779 	lcall	_ak820_outline_0065
      00548D 60 1B            [24] 1780 	jz	00101$
                                   1781 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      00548F 12 56 ED         [24] 1782 	lcall	_ak820_outline_0019
      005492 FF               [12] 1783 	mov	r7,a
      005493 BF 06 14         [24] 1784 	cjne	r7,#0x06,00101$
      005496 90 07 2D         [24] 1785 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005499 E0               [24] 1786 	movx	a,@dptr
      00549A FF               [12] 1787 	mov	r7,a
      00549B BF 10 00         [24] 1788 	cjne	r7,#0x10,00169$
      00549E                       1789 00169$:
      00549E 50 0A            [24] 1790 	jnc	00101$
      0054A0 90 07 2B         [24] 1791 	mov	dptr,#_process_rgb_matrix_PARM_2
      0054A3 E0               [24] 1792 	movx	a,@dptr
      0054A4 FE               [12] 1793 	mov	r6,a
      0054A5 BE 08 00         [24] 1794 	cjne	r6,#0x08,00171$
      0054A8                       1795 00171$:
      0054A8 40 01            [24] 1796 	jc	00102$
      0054AA                       1797 00101$:
      0054AA 22               [24] 1798 	ret
      0054AB                       1799 00102$:
                                   1800 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      0054AB C0 07            [24] 1801 	push	ar7
      0054AD C0 06            [24] 1802 	push	ar6
      0054AF 12 4F 93         [24] 1803 	lcall	_age_reactive
      0054B2 D0 06            [24] 1804 	pop	ar6
      0054B4 D0 07            [24] 1805 	pop	ar7
                                   1806 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      0054B6 EF               [12] 1807 	mov	a,r7
      0054B7 12 38 C6         [24] 1808 	lcall	_ak820_outline_0189
      0054BA 2E               [12] 1809 	add	a,r6
      0054BB FF               [12] 1810 	mov	r7,a
                                   1811 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0054BC 7E 00            [12] 1812 	mov	r6,#0x00
      0054BE                       1813 00111$:
                                   1814 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      0054BE EE               [12] 1815 	mov	a,r6
      0054BF 90 BA 0E         [24] 1816 	mov	dptr,#_ak820_rgb_slots
      0054C2 93               [24] 1817 	movc	a,@a+dptr
      0054C3 B5 07 29         [24] 1818 	cjne	a,ar7,00112$
                                   1819 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      0054C6 EE               [12] 1820 	mov	a,r6
      0054C7 24 C0            [12] 1821 	add	a, #_reactive_age
      0054C9 FC               [12] 1822 	mov	r4,a
      0054CA E4               [12] 1823 	clr	a
      0054CB 34 06            [12] 1824 	addc	a, #(_reactive_age >> 8)
      0054CD FD               [12] 1825 	mov	r5,a
      0054CE 12 57 59         [24] 1826 	lcall	_ak820_outline_0174
      0054D1 F5 F0            [12] 1827 	mov	b, a
      0054D3 05 F0            [12] 1828 	inc	b
      0054D5 7B 80            [12] 1829 	mov	r3,#0x80
      0054D7 E4               [12] 1830 	clr	a
      0054D8 FA               [12] 1831 	mov	r2,a
      0054D9 33               [12] 1832 	rlc	a
      0054DA 92 D2            [24] 1833 	mov	ov,c
      0054DC 80 08            [24] 1834 	sjmp	00176$
      0054DE                       1835 00175$:
      0054DE A2 D2            [12] 1836 	mov	c,ov
      0054E0 EA               [12] 1837 	mov	a,r2
      0054E1 13               [12] 1838 	rrc	a
      0054E2 FA               [12] 1839 	mov	r2,a
      0054E3 EB               [12] 1840 	mov	a,r3
      0054E4 13               [12] 1841 	rrc	a
      0054E5 FB               [12] 1842 	mov	r3,a
      0054E6                       1843 00176$:
      0054E6 D5 F0 F5         [24] 1844 	djnz	b,00175$
      0054E9 12 38 97         [24] 1845 	lcall	_ak820_outline_0124
      0054EC EB               [12] 1846 	mov	a,r3
      0054ED F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      0054EE 22               [24] 1849 	ret
      0054EF                       1850 00112$:
                                   1851 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      0054EF 0E               [12] 1852 	inc	r6
      0054F0 BE 52 00         [24] 1853 	cjne	r6,#0x52,00177$
      0054F3                       1854 00177$:
      0054F3 40 C9            [24] 1855 	jc	00111$
                                   1856 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      0054F5 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1860 ;------------------------------------------------------------
                                   1861 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1862 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1865 ;	-----------------------------------------
                                   1866 ;	 function rgb_matrix_set_suspend_state
                                   1867 ;	-----------------------------------------
      0054F6                       1868 _rgb_matrix_set_suspend_state:
      0054F6 E5 82            [12] 1869 	mov	a,dpl
      0054F8 90 07 2E         [24] 1870 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      0054FB F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      0054FC E0               [24] 1873 	movx	a,@dptr
                                   1874 ;	assignBit
      0054FD F5 15            [12] 1875 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      0054FF 13               [12] 1876 	rrc	a
      005500 92 11            [24] 1877 	mov	_suspended,c
                                   1878 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1879 ;	assignBit
      005502 C2 13            [12] 1880 	clr	_rendering
                                   1881 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      005504 12 4F 76         [24] 1882 	lcall	_clear_reactive
                                   1883 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      005507 E5 15            [12] 1884 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      005509 60 0F            [24] 1885 	jz	00103$
                                   1886 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      00550B 90 07 1D         [24] 1887 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      00550E E4               [12] 1888 	clr	a
      00550F F0               [24] 1889 	movx	@dptr,a
      005510 90 07 1E         [24] 1890 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      005513 F0               [24] 1891 	movx	@dptr,a
      005514 75 82 00         [24] 1892 	mov	dpl, #0x00
                                   1893 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      005517 02 51 49         [24] 1894 	ljmp	_rgb_matrix_set_color_all
      00551A                       1895 00103$:
      00551A 22               [24] 1896 	ret
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function rgb_matrix_is_enabled
                                   1903 ;	-----------------------------------------
      00551B                       1904 _rgb_matrix_is_enabled:
      00551B 12 57 0C         [24] 1905 	lcall	_ak820_outline_0065
      00551E F5 82            [12] 1906 	mov	dpl,a
      005520 22               [24] 1907 	ret
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1910 ;------------------------------------------------------------
                                   1911 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1912 ;	-----------------------------------------
                                   1913 ;	 function rgb_matrix_get_mode
                                   1914 ;	-----------------------------------------
      005521                       1915 _rgb_matrix_get_mode:
      005521 12 56 ED         [24] 1916 	lcall	_ak820_outline_0019
      005524 F5 82            [12] 1917 	mov	dpl,a
      005526 22               [24] 1918 	ret
                                   1919 ;------------------------------------------------------------
                                   1920 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function rgb_matrix_get_hue
                                   1925 ;	-----------------------------------------
      005527                       1926 _rgb_matrix_get_hue:
      005527 90 06 AC         [24] 1927 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00552A E0               [24] 1928 	movx	a,@dptr
      00552B F5 82            [12] 1929 	mov	dpl,a
      00552D 22               [24] 1930 	ret
                                   1931 ;------------------------------------------------------------
                                   1932 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1933 ;------------------------------------------------------------
                                   1934 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1935 ;	-----------------------------------------
                                   1936 ;	 function rgb_matrix_get_sat
                                   1937 ;	-----------------------------------------
      00552E                       1938 _rgb_matrix_get_sat:
      00552E 90 06 AD         [24] 1939 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005531 E0               [24] 1940 	movx	a,@dptr
      005532 F5 82            [12] 1941 	mov	dpl,a
      005534 22               [24] 1942 	ret
                                   1943 ;------------------------------------------------------------
                                   1944 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1945 ;------------------------------------------------------------
                                   1946 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1947 ;	-----------------------------------------
                                   1948 ;	 function rgb_matrix_get_val
                                   1949 ;	-----------------------------------------
      005535                       1950 _rgb_matrix_get_val:
      005535 90 06 AE         [24] 1951 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005538 E0               [24] 1952 	movx	a,@dptr
      005539 F5 82            [12] 1953 	mov	dpl,a
      00553B 22               [24] 1954 	ret
                                   1955 ;------------------------------------------------------------
                                   1956 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1957 ;------------------------------------------------------------
                                   1958 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1959 ;	-----------------------------------------
                                   1960 ;	 function rgb_matrix_get_speed
                                   1961 ;	-----------------------------------------
      00553C                       1962 _rgb_matrix_get_speed:
      00553C 90 06 AF         [24] 1963 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00553F E0               [24] 1964 	movx	a,@dptr
      005540 F5 82            [12] 1965 	mov	dpl,a
      005542 22               [24] 1966 	ret
                                   1967 ;------------------------------------------------------------
                                   1968 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1969 ;------------------------------------------------------------
                                   1970 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1971 ;	-----------------------------------------
                                   1972 ;	 function rgb_matrix_toggle_noeeprom
                                   1973 ;	-----------------------------------------
      005543                       1974 _rgb_matrix_toggle_noeeprom:
      005543 12 57 0C         [24] 1975 	lcall	_ak820_outline_0065
      005546 FF               [12] 1976 	mov	r7,a
      005547 63 07 01         [24] 1977 	xrl	ar7,#0x01
      00554A 90 06 AB         [24] 1978 	mov	dptr,#_rgb_matrix_config
      00554D EF               [12] 1979 	mov	a,r7
      00554E 54 03            [12] 1980 	anl	a,#0x03
      005550 F5 F0            [12] 1981 	mov	b,a
      005552 E0               [24] 1982 	movx	a,@dptr
      005553 54 FC            [12] 1983 	anl	a,#0xfc
      005555 45 F0            [12] 1984 	orl	a,b
      005557 F0               [24] 1985 	movx	@dptr,a
                                   1986 ;	assignBit
      005558 C2 13            [12] 1987 	clr	_rendering
      00555A 02 4F 76         [24] 1988 	ljmp	_clear_reactive
                                   1989 ;------------------------------------------------------------
                                   1990 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1991 ;------------------------------------------------------------
                                   1992 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   1993 ;	-----------------------------------------
                                   1994 ;	 function rgb_matrix_enable_noeeprom
                                   1995 ;	-----------------------------------------
      00555D                       1996 _rgb_matrix_enable_noeeprom:
      00555D 12 57 0C         [24] 1997 	lcall	_ak820_outline_0065
      005560 70 03            [24] 1998 	jnz	00102$
      005562 12 4F 76         [24] 1999 	lcall	_clear_reactive
      005565                       2000 00102$:
      005565 12 57 3C         [24] 2001 	lcall	_ak820_outline_0116
      005568 44 01            [12] 2002 	orl	a,#0x01
      00556A F0               [24] 2003 	movx	@dptr,a
                                   2004 ;	assignBit
      00556B C2 13            [12] 2005 	clr	_rendering
      00556D 22               [24] 2006 	ret
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2009 ;------------------------------------------------------------
                                   2010 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2011 ;	-----------------------------------------
                                   2012 ;	 function rgb_matrix_disable_noeeprom
                                   2013 ;	-----------------------------------------
      00556E                       2014 _rgb_matrix_disable_noeeprom:
      00556E 12 57 3C         [24] 2015 	lcall	_ak820_outline_0116
      005571 F0               [24] 2016 	movx	@dptr,a
                                   2017 ;	assignBit
      005572 C2 13            [12] 2018 	clr	_rendering
      005574 02 4F 76         [24] 2019 	ljmp	_clear_reactive
                                   2020 ;------------------------------------------------------------
                                   2021 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2022 ;------------------------------------------------------------
                                   2023 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2024 ;------------------------------------------------------------
                                   2025 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2026 ;	-----------------------------------------
                                   2027 ;	 function rgb_matrix_mode_noeeprom
                                   2028 ;	-----------------------------------------
      005577                       2029 _rgb_matrix_mode_noeeprom:
      005577 E5 82            [12] 2030 	mov	a,dpl
      005579 90 07 2F         [24] 2031 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      00557C F0               [24] 2032 	movx	@dptr,a
                                   2033 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      00557D E0               [24] 2034 	movx	a,@dptr
      00557E FF               [12] 2035 	mov	r7,a
      00557F 60 05            [24] 2036 	jz	00101$
      005581 BF 07 00         [24] 2037 	cjne	r7,#0x07,00123$
      005584                       2038 00123$:
      005584 40 01            [24] 2039 	jc	00102$
      005586                       2040 00101$:
      005586 22               [24] 2041 	ret
      005587                       2042 00102$:
                                   2043 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      005587 12 56 ED         [24] 2044 	lcall	_ak820_outline_0019
      00558A FE               [12] 2045 	mov	r6,a
      00558B EF               [12] 2046 	mov	a,r7
      00558C B5 06 02         [24] 2047 	cjne	a,ar6,00125$
      00558F 80 03            [24] 2048 	sjmp	00105$
      005591                       2049 00125$:
      005591 12 4F 76         [24] 2050 	lcall	_clear_reactive
      005594                       2051 00105$:
                                   2052 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      005594 90 07 2F         [24] 2053 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005597 E0               [24] 2054 	movx	a,@dptr
      005598 90 06 AB         [24] 2055 	mov	dptr,#_rgb_matrix_config
      00559B 25 E0            [12] 2056 	add	a,acc
      00559D 25 E0            [12] 2057 	add	a,acc
      00559F 54 FC            [12] 2058 	anl	a,#0xfc
      0055A1 F5 F0            [12] 2059 	mov	b,a
      0055A3 E0               [24] 2060 	movx	a,@dptr
      0055A4 54 03            [12] 2061 	anl	a,#0x03
      0055A6 45 F0            [12] 2062 	orl	a,b
      0055A8 F0               [24] 2063 	movx	@dptr,a
                                   2064 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2065 ;	assignBit
      0055A9 C2 13            [12] 2066 	clr	_rendering
                                   2067 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      0055AB 22               [24] 2068 	ret
                                   2069 ;------------------------------------------------------------
                                   2070 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2071 ;------------------------------------------------------------
                                   2072 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2073 ;	-----------------------------------------
                                   2074 ;	 function rgb_matrix_step_noeeprom
                                   2075 ;	-----------------------------------------
      0055AC                       2076 _rgb_matrix_step_noeeprom:
                                   2077 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      0055AC 12 56 ED         [24] 2078 	lcall	_ak820_outline_0019
      0055AF FF               [12] 2079 	mov	r7,a
      0055B0 0F               [12] 2080 	inc	r7
      0055B1 BF 07 00         [24] 2081 	cjne	r7,#0x07,00112$
      0055B4                       2082 00112$:
      0055B4 40 04            [24] 2083 	jc	00103$
      0055B6 7F 01            [12] 2084 	mov	r7,#0x01
      0055B8 80 07            [24] 2085 	sjmp	00104$
      0055BA                       2086 00103$:
      0055BA 12 56 ED         [24] 2087 	lcall	_ak820_outline_0019
      0055BD FE               [12] 2088 	mov	r6,a
      0055BE 0E               [12] 2089 	inc	r6
      0055BF 8E 07            [24] 2090 	mov	ar7,r6
      0055C1                       2091 00104$:
      0055C1 8F 82            [24] 2092 	mov	dpl, r7
                                   2093 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      0055C3 02 55 77         [24] 2094 	ljmp	_rgb_matrix_mode_noeeprom
                                   2095 ;------------------------------------------------------------
                                   2096 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2097 ;------------------------------------------------------------
                                   2098 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2099 ;	-----------------------------------------
                                   2100 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2101 ;	-----------------------------------------
      0055C6                       2102 _rgb_matrix_step_reverse_noeeprom:
                                   2103 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      0055C6 12 56 ED         [24] 2104 	lcall	_ak820_outline_0019
      0055C9 24 FE            [12] 2105 	add	a,#0xff - 0x01
      0055CB 40 04            [24] 2106 	jc	00103$
                                   2107 ;	free result
      0055CD 7F 06            [12] 2108 	mov	r7,#0x06
      0055CF 80 05            [24] 2109 	sjmp	00104$
      0055D1                       2110 00103$:
      0055D1 12 56 ED         [24] 2111 	lcall	_ak820_outline_0019
      0055D4 14               [12] 2112 	dec	a
      0055D5 FF               [12] 2113 	mov	r7,a
      0055D6                       2114 00104$:
      0055D6 8F 82            [24] 2115 	mov	dpl, r7
                                   2116 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      0055D8 02 55 77         [24] 2117 	ljmp	_rgb_matrix_mode_noeeprom
                                   2118 ;------------------------------------------------------------
                                   2119 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2120 ;------------------------------------------------------------
                                   2121 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2122 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2123 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2124 ;------------------------------------------------------------
                                   2125 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2126 ;	-----------------------------------------
                                   2127 ;	 function rgb_matrix_sethsv_noeeprom
                                   2128 ;	-----------------------------------------
      0055DB                       2129 _rgb_matrix_sethsv_noeeprom:
      0055DB 12 38 88         [24] 2130 	lcall	_ak820_outline_0108
      0055DE 90 07 32         [24] 2131 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      0055E1 12 38 8D         [24] 2132 	lcall	_ak820_outline_0109
                                   2133 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      0055E4 90 07 32         [24] 2134 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      0055E7 E0               [24] 2135 	movx	a,@dptr
      0055E8 90 06 AC         [24] 2136 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055EB F0               [24] 2137 	movx	@dptr,a
                                   2138 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      0055EC 90 07 30         [24] 2139 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      0055EF E0               [24] 2140 	movx	a,@dptr
      0055F0 FF               [12] 2141 	mov	r7,a
      0055F1 90 06 AD         [24] 2142 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0055F4 F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      0055F5 90 07 31         [24] 2145 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      0055F8 E0               [24] 2146 	movx	a,@dptr
      0055F9 FF               [12] 2147 	mov  r7,a
      0055FA 24 5F            [12] 2148 	add	a,#0xff - 0xa0
      0055FC 50 04            [24] 2149 	jnc	00103$
                                   2150 ;	free result
      0055FE 7E A0            [12] 2151 	mov	r6,#0xa0
      005600 80 02            [24] 2152 	sjmp	00104$
      005602                       2153 00103$:
      005602 8F 06            [24] 2154 	mov	ar6,r7
      005604                       2155 00104$:
      005604 90 06 AE         [24] 2156 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005607 EE               [12] 2157 	mov	a,r6
      005608 F0               [24] 2158 	movx	@dptr,a
                                   2159 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      005609 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2163 ;------------------------------------------------------------
                                   2164 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2165 ;------------------------------------------------------------
                                   2166 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2167 ;	-----------------------------------------
                                   2168 ;	 function rgb_matrix_set_speed_noeeprom
                                   2169 ;	-----------------------------------------
      00560A                       2170 _rgb_matrix_set_speed_noeeprom:
      00560A E5 82            [12] 2171 	mov	a,dpl
      00560C 90 07 34         [24] 2172 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      00560F F0               [24] 2173 	movx	@dptr,a
      005610 E0               [24] 2174 	movx	a,@dptr
      005611 90 06 AF         [24] 2175 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005614 F0               [24] 2176 	movx	@dptr,a
      005615 22               [24] 2177 	ret
                                   2178 ;------------------------------------------------------------
                                   2179 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2180 ;------------------------------------------------------------
                                   2181 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2182 ;------------------------------------------------------------
                                   2183 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2184 ;	-----------------------------------------
                                   2185 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2186 ;	-----------------------------------------
      005616                       2187 _rgb_matrix_increase_hue_noeeprom:
      005616 90 06 AC         [24] 2188 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005619 E0               [24] 2189 	movx	a,@dptr
      00561A 24 08            [12] 2190 	add	a,#0x08
      00561C 90 06 AC         [24] 2191 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00561F F0               [24] 2192 	movx	@dptr,a
      005620 22               [24] 2193 	ret
                                   2194 ;------------------------------------------------------------
                                   2195 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2196 ;------------------------------------------------------------
                                   2197 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2198 ;	-----------------------------------------
                                   2199 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2200 ;	-----------------------------------------
      005621                       2201 _rgb_matrix_decrease_hue_noeeprom:
      005621 90 06 AC         [24] 2202 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      005624 E0               [24] 2203 	movx	a,@dptr
      005625 24 F8            [12] 2204 	add	a,#0xf8
      005627 90 06 AC         [24] 2205 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00562A F0               [24] 2206 	movx	@dptr,a
      00562B 22               [24] 2207 	ret
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2210 ;------------------------------------------------------------
                                   2211 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2212 ;	-----------------------------------------
                                   2213 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2214 ;	-----------------------------------------
      00562C                       2215 _rgb_matrix_increase_sat_noeeprom:
      00562C 90 06 AD         [24] 2216 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00562F 12 56 F6         [24] 2217 	lcall	_ak820_outline_0048
      005632 12 50 11         [24] 2218 	lcall	_add_sat
      005635 AF 82            [24] 2219 	mov	r7, dpl
      005637 90 06 AD         [24] 2220 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00563A EF               [12] 2221 	mov	a,r7
      00563B F0               [24] 2222 	movx	@dptr,a
      00563C 22               [24] 2223 	ret
                                   2224 ;------------------------------------------------------------
                                   2225 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2226 ;------------------------------------------------------------
                                   2227 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2228 ;	-----------------------------------------
                                   2229 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2230 ;	-----------------------------------------
      00563D                       2231 _rgb_matrix_decrease_sat_noeeprom:
      00563D 90 06 AD         [24] 2232 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005640 12 57 01         [24] 2233 	lcall	_ak820_outline_0049
      005643 12 50 36         [24] 2234 	lcall	_sub_sat
      005646 AF 82            [24] 2235 	mov	r7, dpl
      005648 90 06 AD         [24] 2236 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00564B EF               [12] 2237 	mov	a,r7
      00564C F0               [24] 2238 	movx	@dptr,a
      00564D 22               [24] 2239 	ret
                                   2240 ;------------------------------------------------------------
                                   2241 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2242 ;------------------------------------------------------------
                                   2243 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2244 ;------------------------------------------------------------
                                   2245 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2246 ;	-----------------------------------------
                                   2247 ;	 function rgb_matrix_increase_val_noeeprom
                                   2248 ;	-----------------------------------------
      00564E                       2249 _rgb_matrix_increase_val_noeeprom:
                                   2250 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      00564E 90 06 AE         [24] 2251 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005651 12 56 F6         [24] 2252 	lcall	_ak820_outline_0048
      005654 12 50 11         [24] 2253 	lcall	_add_sat
                                   2254 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005657 E5 82            [12] 2255 	mov	a,dpl
      005659 FF               [12] 2256 	mov	r7,a
      00565A 24 5F            [12] 2257 	add	a,#0xff - 0xa0
      00565C 50 04            [24] 2258 	jnc	00103$
                                   2259 ;	free result
      00565E 7E A0            [12] 2260 	mov	r6,#0xa0
      005660 80 02            [24] 2261 	sjmp	00104$
      005662                       2262 00103$:
      005662 8F 06            [24] 2263 	mov	ar6,r7
      005664                       2264 00104$:
      005664 90 06 AE         [24] 2265 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005667 EE               [12] 2266 	mov	a,r6
      005668 F0               [24] 2267 	movx	@dptr,a
                                   2268 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      005669 22               [24] 2269 	ret
                                   2270 ;------------------------------------------------------------
                                   2271 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2272 ;------------------------------------------------------------
                                   2273 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2274 ;	-----------------------------------------
                                   2275 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2276 ;	-----------------------------------------
      00566A                       2277 _rgb_matrix_decrease_val_noeeprom:
      00566A 90 06 AE         [24] 2278 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00566D 12 57 01         [24] 2279 	lcall	_ak820_outline_0049
      005670 12 50 36         [24] 2280 	lcall	_sub_sat
      005673 AF 82            [24] 2281 	mov	r7, dpl
      005675 90 06 AE         [24] 2282 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005678 EF               [12] 2283 	mov	a,r7
      005679 F0               [24] 2284 	movx	@dptr,a
      00567A 22               [24] 2285 	ret
                                   2286 ;------------------------------------------------------------
                                   2287 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2288 ;------------------------------------------------------------
                                   2289 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2290 ;	-----------------------------------------
                                   2291 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2292 ;	-----------------------------------------
      00567B                       2293 _rgb_matrix_increase_speed_noeeprom:
      00567B 90 06 AF         [24] 2294 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00567E 12 56 F6         [24] 2295 	lcall	_ak820_outline_0048
      005681 12 50 11         [24] 2296 	lcall	_add_sat
      005684 AF 82            [24] 2297 	mov	r7, dpl
      005686 90 06 AF         [24] 2298 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005689 EF               [12] 2299 	mov	a,r7
      00568A F0               [24] 2300 	movx	@dptr,a
      00568B 22               [24] 2301 	ret
                                   2302 ;------------------------------------------------------------
                                   2303 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2304 ;------------------------------------------------------------
                                   2305 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2306 ;	-----------------------------------------
                                   2307 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2308 ;	-----------------------------------------
      00568C                       2309 _rgb_matrix_decrease_speed_noeeprom:
      00568C 90 06 AF         [24] 2310 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00568F 12 57 01         [24] 2311 	lcall	_ak820_outline_0049
      005692 12 50 36         [24] 2312 	lcall	_sub_sat
      005695 AF 82            [24] 2313 	mov	r7, dpl
      005697 90 06 AF         [24] 2314 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00569A EF               [12] 2315 	mov	a,r7
      00569B F0               [24] 2316 	movx	@dptr,a
      00569C 22               [24] 2317 	ret
                                   2318 ;------------------------------------------------------------
                                   2319 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2320 ;------------------------------------------------------------
                                   2321 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2322 ;	-----------------------------------------
                                   2323 ;	 function rgb_matrix_toggle
                                   2324 ;	-----------------------------------------
      00569D                       2325 _rgb_matrix_toggle:
      00569D 12 55 43         [24] 2326 	lcall	_rgb_matrix_toggle_noeeprom
      0056A0 02 50 53         [24] 2327 	ljmp	_mark_dirty
                                   2328 ;------------------------------------------------------------
                                   2329 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2330 ;------------------------------------------------------------
                                   2331 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2332 ;	-----------------------------------------
                                   2333 ;	 function rgb_matrix_step
                                   2334 ;	-----------------------------------------
      0056A3                       2335 _rgb_matrix_step:
      0056A3 12 55 AC         [24] 2336 	lcall	_rgb_matrix_step_noeeprom
      0056A6 02 50 53         [24] 2337 	ljmp	_mark_dirty
                                   2338 ;------------------------------------------------------------
                                   2339 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2340 ;------------------------------------------------------------
                                   2341 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2342 ;	-----------------------------------------
                                   2343 ;	 function rgb_matrix_step_reverse
                                   2344 ;	-----------------------------------------
      0056A9                       2345 _rgb_matrix_step_reverse:
      0056A9 12 55 C6         [24] 2346 	lcall	_rgb_matrix_step_reverse_noeeprom
      0056AC 02 50 53         [24] 2347 	ljmp	_mark_dirty
                                   2348 ;------------------------------------------------------------
                                   2349 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2350 ;------------------------------------------------------------
                                   2351 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2352 ;	-----------------------------------------
                                   2353 ;	 function rgb_matrix_increase_hue
                                   2354 ;	-----------------------------------------
      0056AF                       2355 _rgb_matrix_increase_hue:
      0056AF 12 56 16         [24] 2356 	lcall	_rgb_matrix_increase_hue_noeeprom
      0056B2 02 50 53         [24] 2357 	ljmp	_mark_dirty
                                   2358 ;------------------------------------------------------------
                                   2359 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2360 ;------------------------------------------------------------
                                   2361 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2362 ;	-----------------------------------------
                                   2363 ;	 function rgb_matrix_decrease_hue
                                   2364 ;	-----------------------------------------
      0056B5                       2365 _rgb_matrix_decrease_hue:
      0056B5 12 56 21         [24] 2366 	lcall	_rgb_matrix_decrease_hue_noeeprom
      0056B8 02 50 53         [24] 2367 	ljmp	_mark_dirty
                                   2368 ;------------------------------------------------------------
                                   2369 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2370 ;------------------------------------------------------------
                                   2371 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2372 ;	-----------------------------------------
                                   2373 ;	 function rgb_matrix_increase_sat
                                   2374 ;	-----------------------------------------
      0056BB                       2375 _rgb_matrix_increase_sat:
      0056BB 12 56 2C         [24] 2376 	lcall	_rgb_matrix_increase_sat_noeeprom
      0056BE 02 50 53         [24] 2377 	ljmp	_mark_dirty
                                   2378 ;------------------------------------------------------------
                                   2379 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2380 ;------------------------------------------------------------
                                   2381 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2382 ;	-----------------------------------------
                                   2383 ;	 function rgb_matrix_decrease_sat
                                   2384 ;	-----------------------------------------
      0056C1                       2385 _rgb_matrix_decrease_sat:
      0056C1 12 56 3D         [24] 2386 	lcall	_rgb_matrix_decrease_sat_noeeprom
      0056C4 02 50 53         [24] 2387 	ljmp	_mark_dirty
                                   2388 ;------------------------------------------------------------
                                   2389 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2390 ;------------------------------------------------------------
                                   2391 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2392 ;	-----------------------------------------
                                   2393 ;	 function rgb_matrix_increase_val
                                   2394 ;	-----------------------------------------
      0056C7                       2395 _rgb_matrix_increase_val:
      0056C7 12 56 4E         [24] 2396 	lcall	_rgb_matrix_increase_val_noeeprom
      0056CA 02 50 53         [24] 2397 	ljmp	_mark_dirty
                                   2398 ;------------------------------------------------------------
                                   2399 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2400 ;------------------------------------------------------------
                                   2401 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2402 ;	-----------------------------------------
                                   2403 ;	 function rgb_matrix_decrease_val
                                   2404 ;	-----------------------------------------
      0056CD                       2405 _rgb_matrix_decrease_val:
      0056CD 12 56 6A         [24] 2406 	lcall	_rgb_matrix_decrease_val_noeeprom
      0056D0 02 50 53         [24] 2407 	ljmp	_mark_dirty
                                   2408 ;------------------------------------------------------------
                                   2409 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2410 ;------------------------------------------------------------
                                   2411 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2412 ;	-----------------------------------------
                                   2413 ;	 function rgb_matrix_increase_speed
                                   2414 ;	-----------------------------------------
      0056D3                       2415 _rgb_matrix_increase_speed:
      0056D3 12 56 7B         [24] 2416 	lcall	_rgb_matrix_increase_speed_noeeprom
      0056D6 02 50 53         [24] 2417 	ljmp	_mark_dirty
                                   2418 ;------------------------------------------------------------
                                   2419 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2420 ;------------------------------------------------------------
                                   2421 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2422 ;	-----------------------------------------
                                   2423 ;	 function rgb_matrix_decrease_speed
                                   2424 ;	-----------------------------------------
      0056D9                       2425 _rgb_matrix_decrease_speed:
      0056D9 12 56 8C         [24] 2426 	lcall	_rgb_matrix_decrease_speed_noeeprom
      0056DC 02 50 53         [24] 2427 	ljmp	_mark_dirty
                                   2428 ;------------------------------------------------------------
                                   2429 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2430 ;------------------------------------------------------------
                                   2431 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2432 ;------------------------------------------------------------
                                   2433 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2434 ;	-----------------------------------------
                                   2435 ;	 function rgb_matrix_mode
                                   2436 ;	-----------------------------------------
      0056DF                       2437 _rgb_matrix_mode:
      0056DF E5 82            [12] 2438 	mov	a,dpl
      0056E1 90 07 35         [24] 2439 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      0056E4 12 57 4F         [24] 2440 	lcall	_ak820_outline_0170
      0056E7 12 55 77         [24] 2441 	lcall	_rgb_matrix_mode_noeeprom
      0056EA 02 50 53         [24] 2442 	ljmp	_mark_dirty
                                   2443 ;------------------------------------------------------------
                                   2444 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2445 ;------------------------------------------------------------
                                   2446 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2447 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2448 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2449 ;------------------------------------------------------------
                                   2450 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2451 ;	-----------------------------------------
                                   2452 	.area CSEG    (CODE)
                                   2453 	.area CONST   (CODE)
                                   2454 	.area CONST   (CODE)
      00BA60                       2455 _sine8_coefficients_10000_290:
      00BA60 00                    2456 	.db #0x00	; 0
      00BA61 31                    2457 	.db #0x31	; 49	'1'
      00BA62 31                    2458 	.db #0x31	; 49	'1'
      00BA63 29                    2459 	.db #0x29	; 41
      00BA64 5A                    2460 	.db #0x5a	; 90	'Z'
      00BA65 1B                    2461 	.db #0x1b	; 27
      00BA66 75                    2462 	.db #0x75	; 117	'u'
      00BA67 0A                    2463 	.db #0x0a	; 10
                                   2464 	.area CSEG    (CODE)
                                   2465 	.area XINIT   (CODE)
                                   2466 	.area CABS    (ABS,CODE)
                                   2467 
                                   2468 ; Experimental exact instruction outlining.
                                   2469 	.globl _ak820_outline_0005
                                   2470 	.globl _ak820_outline_0019
                                   2471 	.globl _ak820_outline_0048
                                   2472 	.globl _ak820_outline_0049
                                   2473 	.globl _ak820_outline_0051
                                   2474 	.globl _ak820_outline_0058
                                   2475 	.globl _ak820_outline_0059
                                   2476 	.globl _ak820_outline_0065
                                   2477 	.globl _ak820_outline_0069
                                   2478 	.globl _ak820_outline_0073
                                   2479 	.globl _ak820_outline_0085
                                   2480 	.globl _ak820_outline_0100
                                   2481 	.globl _ak820_outline_0103
                                   2482 	.globl _ak820_outline_0108
                                   2483 	.globl _ak820_outline_0109
                                   2484 	.globl _ak820_outline_0110
                                   2485 	.globl _ak820_outline_0116
                                   2486 	.globl _ak820_outline_0124
                                   2487 	.globl _ak820_outline_0133
                                   2488 	.globl _ak820_outline_0134
                                   2489 	.globl _ak820_outline_0135
                                   2490 	.globl _ak820_outline_0138
                                   2491 	.globl _ak820_outline_0140
                                   2492 	.globl _ak820_outline_0156
                                   2493 	.globl _ak820_outline_0169
                                   2494 	.globl _ak820_outline_0170
                                   2495 	.globl _ak820_outline_0171
                                   2496 	.globl _ak820_outline_0174
                                   2497 	.globl _ak820_outline_0180
                                   2498 	.globl _ak820_outline_0187
                                   2499 	.globl _ak820_outline_0189
                                   2500 
                                   2501 	.area CSEG (CODE)
                                   2502 ; function ak820_outline_0019
      0056ED                       2503 _ak820_outline_0019:
      0056ED 90 06 AB         [24] 2504 	mov	dptr,#_rgb_matrix_config
      0056F0 E0               [24] 2505 	movx	a,@dptr
      0056F1 03               [12] 2506 	rr	a
      0056F2 03               [12] 2507 	rr	a
      0056F3 54 3F            [12] 2508 	anl	a,#0x3f
      0056F5 22               [24] 2509 	ret
                                   2510 
                                   2511 	.area CSEG (CODE)
                                   2512 ; function ak820_outline_0048
      0056F6                       2513 _ak820_outline_0048:
      0056F6 E0               [24] 2514 	movx	a,@dptr
      0056F7 FF               [12] 2515 	mov	r7,a
      0056F8 90 07 14         [24] 2516 	mov	dptr,#_add_sat_PARM_2
      0056FB 74 10            [12] 2517 	mov	a,#0x10
      0056FD F0               [24] 2518 	movx	@dptr,a
      0056FE 8F 82            [24] 2519 	mov	dpl,r7
      005700 22               [24] 2520 	ret
                                   2521 
                                   2522 	.area CSEG (CODE)
                                   2523 ; function ak820_outline_0049
      005701                       2524 _ak820_outline_0049:
      005701 E0               [24] 2525 	movx	a,@dptr
      005702 FF               [12] 2526 	mov	r7,a
      005703 90 07 16         [24] 2527 	mov	dptr,#_sub_sat_PARM_2
      005706 74 10            [12] 2528 	mov	a,#0x10
      005708 F0               [24] 2529 	movx	@dptr,a
      005709 8F 82            [24] 2530 	mov	dpl,r7
      00570B 22               [24] 2531 	ret
                                   2532 
                                   2533 	.area CSEG (CODE)
                                   2534 ; function ak820_outline_0065
      00570C                       2535 _ak820_outline_0065:
      00570C 90 06 AB         [24] 2536 	mov	dptr,#_rgb_matrix_config
      00570F E0               [24] 2537 	movx	a,@dptr
      005710 54 03            [12] 2538 	anl	a,#0x03
      005712 22               [24] 2539 	ret
                                   2540 
                                   2541 	.area CSEG (CODE)
                                   2542 ; function ak820_outline_0069
      005713                       2543 _ak820_outline_0069:
      005713 74 08            [12] 2544 	mov	a,#0x08
      005715 F0               [24] 2545 	movx	@dptr,a
      005716 E4               [12] 2546 	clr	a
      005717 A3               [24] 2547 	inc	dptr
      005718 F0               [24] 2548 	movx	@dptr,a
      005719 90 06 AB         [24] 2549 	mov	dptr,#_rgb_matrix_config
      00571C 22               [24] 2550 	ret
                                   2551 
                                   2552 	.area CSEG (CODE)
                                   2553 ; function ak820_outline_0073
      00571D                       2554 _ak820_outline_0073:
      00571D A3               [24] 2555 	inc	dptr
      00571E F0               [24] 2556 	movx	@dptr,a
      00571F E4               [12] 2557 	clr	a
      005720 A3               [24] 2558 	inc	dptr
      005721 F0               [24] 2559 	movx	@dptr,a
      005722 90 0D A3         [24] 2560 	mov	dptr,#___memcpy_PARM_3
      005725 74 03            [12] 2561 	mov	a,#0x03
      005727 F0               [24] 2562 	movx	@dptr,a
      005728 E4               [12] 2563 	clr	a
      005729 A3               [24] 2564 	inc	dptr
      00572A F0               [24] 2565 	movx	@dptr,a
      00572B 22               [24] 2566 	ret
                                   2567 
                                   2568 	.area CSEG (CODE)
                                   2569 ; function ak820_outline_0085
      00572C                       2570 _ak820_outline_0085:
      00572C 74 18            [12] 2571 	mov	a,#0x18
      00572E F0               [24] 2572 	movx	@dptr,a
      00572F E4               [12] 2573 	clr	a
      005730 A3               [24] 2574 	inc	dptr
      005731 F0               [24] 2575 	movx	@dptr,a
      005732 A3               [24] 2576 	inc	dptr
      005733 F0               [24] 2577 	movx	@dptr,a
      005734 22               [24] 2578 	ret
                                   2579 
                                   2580 	.area CSEG (CODE)
                                   2581 ; function ak820_outline_0110
      005735                       2582 _ak820_outline_0110:
      005735 35 F0            [12] 2583 	addc	a,b
      005737 F5 83            [12] 2584 	mov	dph,a
      005739 E4               [12] 2585 	clr	a
      00573A 93               [24] 2586 	movc	a,@a+dptr
      00573B 22               [24] 2587 	ret
                                   2588 
                                   2589 	.area CSEG (CODE)
                                   2590 ; function ak820_outline_0116
      00573C                       2591 _ak820_outline_0116:
      00573C 90 06 AB         [24] 2592 	mov	dptr,#_rgb_matrix_config
      00573F E0               [24] 2593 	movx	a,@dptr
      005740 54 FC            [12] 2594 	anl	a,#0xfc
      005742 22               [24] 2595 	ret
                                   2596 
                                   2597 	.area CSEG (CODE)
                                   2598 ; function ak820_outline_0140
      005743                       2599 _ak820_outline_0140:
      005743 90 06 BA         [24] 2600 	mov	dptr,#_frame_mode
      005746 E0               [24] 2601 	movx	a,@dptr
      005747 FE               [12] 2602 	mov	r6,a
      005748 22               [24] 2603 	ret
                                   2604 
                                   2605 	.area CSEG (CODE)
                                   2606 ; function ak820_outline_0169
      005749                       2607 _ak820_outline_0169:
      005749 F0               [24] 2608 	movx	@dptr,a
      00574A E5 F0            [12] 2609 	mov	a,b
      00574C A3               [24] 2610 	inc	dptr
      00574D F0               [24] 2611 	movx	@dptr,a
      00574E 22               [24] 2612 	ret
                                   2613 
                                   2614 	.area CSEG (CODE)
                                   2615 ; function ak820_outline_0170
      00574F                       2616 _ak820_outline_0170:
      00574F F0               [24] 2617 	movx	@dptr,a
      005750 E0               [24] 2618 	movx	a,@dptr
      005751 F5 82            [12] 2619 	mov	dpl,a
      005753 22               [24] 2620 	ret
                                   2621 
                                   2622 	.area CSEG (CODE)
                                   2623 ; function ak820_outline_0171
      005754                       2624 _ak820_outline_0171:
      005754 C4               [12] 2625 	swap	a
      005755 23               [12] 2626 	rl	a
      005756 54 1F            [12] 2627 	anl	a,#0x1f
      005758 22               [24] 2628 	ret
                                   2629 
                                   2630 	.area CSEG (CODE)
                                   2631 ; function ak820_outline_0174
      005759                       2632 _ak820_outline_0174:
      005759 90 06 AF         [24] 2633 	mov	dptr,#(_rgb_matrix_config+0x0004)
      00575C E0               [24] 2634 	movx	a,@dptr
      00575D 23               [12] 2635 	rl	a
      00575E 23               [12] 2636 	rl	a
      00575F 54 03            [12] 2637 	anl	a,#0x03
      005761 22               [24] 2638 	ret
                                   2639 
                                   2640 	.area CSEG (CODE)
                                   2641 ; function ak820_outline_0180
      005762                       2642 _ak820_outline_0180:
      005762 90 0D A8         [24] 2643 	mov	dptr,#_memset_PARM_2
      005765 E4               [12] 2644 	clr	a
      005766 F0               [24] 2645 	movx	@dptr,a
      005767 90 0D A9         [24] 2646 	mov	dptr,#_memset_PARM_3
      00576A 22               [24] 2647 	ret
                                   2648 
                                   2649 	.area CSEG (CODE)
                                   2650 ; function ak820_outline_0187
      00576B                       2651 _ak820_outline_0187:
      00576B 90 06 B9         [24] 2652 	mov	dptr,#_led_index
      00576E E0               [24] 2653 	movx	a,@dptr
      00576F 22               [24] 2654 	ret
