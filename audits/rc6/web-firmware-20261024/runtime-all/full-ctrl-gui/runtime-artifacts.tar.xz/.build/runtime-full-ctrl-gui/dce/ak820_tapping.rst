                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000E                        552 _ak820_tapping_before_sloc0_1_0:
      00000E                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      00059E                        562 _source_state:
      00059E                        563 	.ds 130
      000620                        564 _pending_time:
      000620                        565 	.ds 2
      000622                        566 _pending_code:
      000622                        567 	.ds 2
      000624                        568 _ak820_tapping_source_PARM_1:
      000624                        569 	.ds 2
      000626                        570 _hold_PARM_2:
      000626                        571 	.ds 1
      000627                        572 _hold_code_10000_602:
      000627                        573 	.ds 2
      000629                        574 _hold_mods_30000_605:
      000629                        575 	.ds 1
      00062A                        576 _commit_pending_id_10000_611:
      00062A                        577 	.ds 1
      00062B                        578 _ak820_tapping_before_event_10000_612:
      00062B                        579 	.ds 2
      00062D                        580 _ak820_tapping_process_record_10000_623:
      00062D                        581 	.ds 2
      00062F                        582 _ak820_tapping_process_code_10000_624:
      00062F                        583 	.ds 2
      000631                        584 _ak820_tapping_process_sc_mods_10000_624:
      000631                        585 	.ds 1
      000632                        586 _ak820_oneshot_mods::
      000632                        587 	.ds 1
      000633                        588 _ak820_oneshot_consumed::
      000633                        589 	.ds 1
      000634                        590 _ak820_oneshot_process_PARM_2:
      000634                        591 	.ds 1
      000635                        592 _ak820_oneshot_process_PARM_3:
      000635                        593 	.ds 1
      000636                        594 _ak820_oneshot_process_code_10000_649:
      000636                        595 	.ds 2
      000638                        596 _ak820_oneshot_process_mods_10000_650:
      000638                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000DB0                        606 _pending:
      000DB0                        607 	.ds 1
      000DB1                        608 _ak820_oneshot_target::
      000DB1                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      004388                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      004388 90 06 25         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      00438B E0               [24]  656 	movx	a,@dptr
      00438C FF               [12]  657 	mov	r7,a
      00438D BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      004390                        659 00147$:
      004390 50 14            [24]  660 	jnc	00102$
      004392 90 06 24         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      004395 E0               [24]  662 	movx	a,@dptr
      004396 FE               [12]  663 	mov	r6,a
      004397 BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      00439A                        665 00149$:
      00439A 50 0A            [24]  666 	jnc	00102$
      00439C 8F 05            [24]  667 	mov	ar5,r7
      00439E ED               [12]  668 	mov	a,r5
      00439F 12 38 C6         [24]  669 	lcall	_ak820_outline_0189
      0043A2 2E               [12]  670 	add	a,r6
      0043A3 F5 82            [12]  671 	mov	dpl,a
      0043A5 22               [24]  672 	ret
      0043A6                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      0043A6 90 06 24         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      0043A9 E0               [24]  676 	movx	a,@dptr
      0043AA FE               [12]  677 	mov	r6,a
      0043AB BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      0043AE                        679 00151$:
      0043AE 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      0043B0 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      0043B3 75 82 80         [24]  683 	mov	dpl, #0x80
      0043B6 22               [24]  684 	ret
      0043B7                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      0043B7 BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      0043BA 75 82 81         [24]  688 	mov	dpl, #0x81
      0043BD 22               [24]  689 	ret
      0043BE                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      0043BE 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      0043C1 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_602'
                                    700 ;mods          Allocated with name '_hold_mods_30000_605'
                                    701 ;layer         Allocated with name '_hold_layer_30000_608'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      0043C2                        707 _hold:
      0043C2 12 38 88         [24]  708 	lcall	_ak820_outline_0108
      0043C5 90 06 27         [24]  709 	mov	dptr,#_hold_code_10000_602
      0043C8 12 38 8D         [24]  710 	lcall	_ak820_outline_0109
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      0043CB 90 06 27         [24]  712 	mov	dptr,#_hold_code_10000_602
      0043CE 12 48 55         [24]  713 	lcall	_ak820_outline_0008
      0043D1 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      0043D3 2D               [12]  715 	add	a,r5
      0043D4 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      0043D6 8F 05            [24]  718 	mov	ar5,r7
      0043D8 53 05 1F         [24]  719 	anl	ar5,#0x1f
      0043DB 90 06 29         [24]  720 	mov	dptr,#_hold_mods_30000_605
      0043DE ED               [12]  721 	mov	a,r5
      0043DF F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      0043E0 ED               [12]  724 	mov	a,r5
      0043E1 30 E4 08         [24]  725 	jnb	acc.4,00102$
      0043E4 ED               [12]  726 	mov	a,r5
      0043E5 C4               [12]  727 	swap	a
      0043E6 54 F0            [12]  728 	anl	a,#0xf0
      0043E8 90 06 29         [24]  729 	mov	dptr,#_hold_mods_30000_605
      0043EB F0               [24]  730 	movx	@dptr,a
      0043EC                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      0043EC 90 06 26         [24]  733 	mov	dptr,#_hold_PARM_2
      0043EF E0               [24]  734 	movx	a,@dptr
      0043F0 60 09            [24]  735 	jz	00104$
      0043F2 90 06 29         [24]  736 	mov	dptr,#_hold_mods_30000_605
      0043F5 E0               [24]  737 	movx	a,@dptr
      0043F6 F5 82            [12]  738 	mov	dpl,a
      0043F8 02 76 2F         [24]  739 	ljmp	_register_mods
      0043FB                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      0043FB 90 06 29         [24]  742 	mov	dptr,#_hold_mods_30000_605
      0043FE E0               [24]  743 	movx	a,@dptr
      0043FF F5 82            [12]  744 	mov	dpl,a
      004401 02 76 43         [24]  745 	ljmp	_unregister_mods
      004404                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004404 8F 06            [24]  748 	mov	ar6,r7
      004406 74 0F            [12]  749 	mov	a,#0x0f
      004408 5E               [12]  750 	anl	a,r6
      004409 FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      00440A 90 06 26         [24]  753 	mov	dptr,#_hold_PARM_2
      00440D E0               [24]  754 	movx	a,@dptr
      00440E 60 05            [24]  755 	jz	00107$
      004410 8F 82            [24]  756 	mov	dpl, r7
      004412 02 78 18         [24]  757 	ljmp	_layer_hold_on
      004415                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      004415 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      004417 02 78 50         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_611'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      00441A                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      00441A 90 0D B0         [24]  774 	mov	dptr,#_pending
      00441D E0               [24]  775 	movx	a,@dptr
      00441E 90 06 2A         [24]  776 	mov	dptr,#_commit_pending_id_10000_611
      004421 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      004422 12 48 EE         [24]  779 	lcall	_ak820_outline_0154
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      004425 90 06 2A         [24]  781 	mov	dptr,#_commit_pending_id_10000_611
      004428 E0               [24]  782 	movx	a,@dptr
      004429 24 9E            [12]  783 	add	a,#_source_state
      00442B FF               [12]  784 	mov	r7,a
      00442C E4               [12]  785 	clr	a
      00442D 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      00442F FE               [12]  787 	mov	r6,a
      004430 12 43 6D         [24]  788 	lcall	_ak820_outline_0158
      004433 E0               [24]  789 	movx	a,@dptr
      004434 FD               [12]  790 	mov	r5,a
      004435 43 05 04         [24]  791 	orl	ar5,#0x04
      004438 12 43 6D         [24]  792 	lcall	_ak820_outline_0158
      00443B ED               [12]  793 	mov	a,r5
      00443C F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      00443D 90 06 22         [24]  796 	mov	dptr,#_pending_code
      004440 12 38 41         [24]  797 	lcall	_ak820_outline_0051
      004443 90 06 26         [24]  798 	mov	dptr,#_hold_PARM_2
      004446 74 01            [12]  799 	mov	a,#0x01
      004448 12 43 39         [24]  800 	lcall	_ak820_outline_0071
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      00444B 02 43 C2         [24]  802 	ljmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_612'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_613'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      00444E                        813 _ak820_tapping_before:
      00444E 12 38 88         [24]  814 	lcall	_ak820_outline_0108
      004451 90 06 2B         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004454 12 38 8D         [24]  816 	lcall	_ak820_outline_0109
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      004457 90 06 2B         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_612
      00445A 12 48 55         [24]  819 	lcall	_ak820_outline_0008
      00445D 12 48 6B         [24]  820 	lcall	_ak820_outline_0023
      004460 C0 07            [24]  821 	push	ar7
      004462 C0 06            [24]  822 	push	ar6
      004464 12 B9 05         [24]  823 	lcall	___memcpy
      004467 12 43 88         [24]  824 	lcall	_ak820_tapping_source
      00446A AD 82            [24]  825 	mov	r5, dpl
      00446C D0 06            [24]  826 	pop	ar6
      00446E D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      004470 90 0E 21         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      004473 E0               [24]  830 	movx	a,@dptr
      004474 60 1E            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      004476 12 48 DA         [24]  833 	lcall	_ak820_outline_0097
      004479 60 15            [24]  834 	jz	00102$
      00447B BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      00447E 80 10            [24]  836 	sjmp	00102$
      004480                        837 00218$:
      004480 12 48 5F         [24]  838 	lcall	_ak820_outline_0015
      004483 E0               [24]  839 	movx	a,@dptr
      004484 70 0A            [24]  840 	jnz	00102$
      004486 ED               [12]  841 	mov	a,r5
      004487 12 48 85         [24]  842 	lcall	_ak820_outline_0026
      00448A 53 02 FD         [24]  843 	anl	ar2,#0xfd
      00448D 12 48 D3         [24]  844 	lcall	_ak820_outline_0094
      004490                        845 00102$:
                                    846 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      004490 75 82 00         [24]  847 	mov	dpl, #0x00
      004493 22               [24]  848 	ret
      004494                        849 00106$:
                                    850 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      004494 90 0D B0         [24]  851 	mov	dptr,#_pending
      004497 E0               [24]  852 	movx	a,@dptr
      004498 FC               [12]  853 	mov	r4,a
      004499 BC FF 02         [24]  854 	cjne	r4,#0xff,00220$
      00449C 80 3B            [24]  855 	sjmp	00108$
      00449E                        856 00220$:
      00449E 12 38 39         [24]  857 	lcall	_ak820_outline_0036
      0044A1 FA               [12]  858 	mov	r2,a
      0044A2 A3               [24]  859 	inc	dptr
      0044A3 E0               [24]  860 	movx	a,@dptr
      0044A4 FB               [12]  861 	mov	r3,a
      0044A5 90 06 20         [24]  862 	mov	dptr,#_pending_time
      0044A8 12 38 7C         [24]  863 	lcall	_ak820_outline_0102
      0044AB EA               [12]  864 	mov	a,r2
      0044AC C3               [12]  865 	clr	c
      0044AD 98               [12]  866 	subb	a,r0
      0044AE FA               [12]  867 	mov	r2,a
      0044AF EB               [12]  868 	mov	a,r3
      0044B0 99               [12]  869 	subb	a,r1
      0044B1 FB               [12]  870 	mov	r3,a
      0044B2 C3               [12]  871 	clr	c
      0044B3 EA               [12]  872 	mov	a,r2
      0044B4 94 C8            [12]  873 	subb	a,#0xc8
      0044B6 EB               [12]  874 	mov	a,r3
      0044B7 94 00            [12]  875 	subb	a,#0x00
      0044B9 50 17            [24]  876 	jnc	00107$
                                    877 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      0044BB 74 04            [12]  878 	mov	a,#0x04
      0044BD 12 48 93         [24]  879 	lcall	_ak820_outline_0032
      0044C0 60 17            [24]  880 	jz	00108$
      0044C2 12 38 12         [24]  881 	lcall	_ak820_outline_0009
      0044C5 60 12            [24]  882 	jz	00108$
      0044C7 BD FF 02         [24]  883 	cjne	r5,#0xff,00224$
      0044CA 80 06            [24]  884 	sjmp	00107$
      0044CC                        885 00224$:
      0044CC ED               [12]  886 	mov	a,r5
      0044CD B5 04 02         [24]  887 	cjne	a,ar4,00225$
      0044D0 80 07            [24]  888 	sjmp	00108$
      0044D2                        889 00225$:
      0044D2                        890 00107$:
      0044D2 C0 05            [24]  891 	push	ar5
      0044D4 12 44 1A         [24]  892 	lcall	_commit_pending
      0044D7 D0 05            [24]  893 	pop	ar5
      0044D9                        894 00108$:
                                    895 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      0044D9 90 06 2B         [24]  896 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0044DC 12 38 41         [24]  897 	lcall	_ak820_outline_0051
      0044DF 12 48 DA         [24]  898 	lcall	_ak820_outline_0097
      0044E2 60 03            [24]  899 	jz	00114$
      0044E4 BD FF 04         [24]  900 	cjne	r5,#0xff,00115$
      0044E7                        901 00114$:
      0044E7 75 82 01         [24]  902 	mov	dpl, #0x01
      0044EA 22               [24]  903 	ret
      0044EB                        904 00115$:
                                    905 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      0044EB ED               [12]  906 	mov	a,r5
      0044EC 12 48 C5         [24]  907 	lcall	_ak820_outline_0078
      0044EF 30 E1 13         [24]  908 	jnb	acc.1,00120$
                                    909 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0044F2 74 05            [12]  910 	mov	a,#0x05
      0044F4 2E               [12]  911 	add	a, r6
      0044F5 12 38 1F         [24]  912 	lcall	_ak820_outline_0016
      0044F8 70 07            [24]  913 	jnz	00118$
      0044FA 74 FD            [12]  914 	mov	a,#0xfd
      0044FC 5B               [12]  915 	anl	a,r3
      0044FD 12 38 97         [24]  916 	lcall	_ak820_outline_0124
      004500 F0               [24]  917 	movx	@dptr,a
      004501                        918 00118$:
                                    919 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      004501 75 82 00         [24]  920 	mov	dpl, #0x00
      004504 22               [24]  921 	ret
      004505                        922 00120$:
                                    923 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004505 12 43 03         [24]  924 	lcall	_ak820_outline_0011
      004508 E0               [24]  925 	movx	a,@dptr
      004509 FF               [12]  926 	mov	r7,a
      00450A 8B 06            [24]  927 	mov	ar6,r3
      00450C 53 06 01         [24]  928 	anl	ar6,#0x01
      00450F EE               [12]  929 	mov	a,r6
      004510 B4 01 00         [24]  930 	cjne	a,#0x01,00231$
      004513                        931 00231$:
      004513 B3               [12]  932 	cpl	c
      004514 92 0E            [24]  933 	mov	_ak820_tapping_before_sloc0_1_0,c
      004516 8F F0            [24]  934 	mov	b,r7
      004518 E4               [12]  935 	clr	a
      004519 33               [12]  936 	rlc	a
      00451A B5 F0 04         [24]  937 	cjne	a,b,00122$
      00451D 75 82 00         [24]  938 	mov	dpl, #0x00
      004520 22               [24]  939 	ret
      004521                        940 00122$:
                                    941 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      004521 63 03 01         [24]  942 	xrl	ar3,#0x01
      004524 12 38 97         [24]  943 	lcall	_ak820_outline_0124
      004527 EB               [12]  944 	mov	a,r3
      004528 F0               [24]  945 	movx	@dptr,a
                                    946 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      004529 75 82 01         [24]  947 	mov	dpl, #0x01
                                    948 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      00452C 22               [24]  949 	ret
                                    950 ;------------------------------------------------------------
                                    951 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    952 ;------------------------------------------------------------
                                    953 ;record        Allocated with name '_ak820_tapping_process_record_10000_623'
                                    954 ;id            Allocated with name '_ak820_tapping_process_id_10000_624'
                                    955 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_624'
                                    956 ;code          Allocated with name '_ak820_tapping_process_code_10000_624'
                                    957 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_624'
                                    958 ;------------------------------------------------------------
                                    959 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    960 ;	-----------------------------------------
                                    961 ;	 function ak820_tapping_process
                                    962 ;	-----------------------------------------
      00452D                        963 _ak820_tapping_process:
      00452D 12 38 88         [24]  964 	lcall	_ak820_outline_0108
      004530 90 06 2D         [24]  965 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004533 12 38 8D         [24]  966 	lcall	_ak820_outline_0109
                                    967 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: uint8_t sc_mods = 0;
      004536 90 06 31         [24]  968 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004539 E4               [12]  969 	clr	a
      00453A F0               [24]  970 	movx	@dptr,a
                                    971 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      00453B 90 06 2D         [24]  972 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00453E 12 38 41         [24]  973 	lcall	_ak820_outline_0051
      004541 74 04            [12]  974 	mov	a,#0x04
      004543 12 48 9E         [24]  975 	lcall	_ak820_outline_0033
      004546 70 04            [24]  976 	jnz	00102$
      004548 75 82 01         [24]  977 	mov	dpl, #0x01
      00454B 22               [24]  978 	ret
      00454C                        979 00102$:
                                    980 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      00454C 8E 04            [24]  981 	mov	ar4,r6
      00454E 8F 05            [24]  982 	mov	ar5,r7
      004550 12 48 6B         [24]  983 	lcall	_ak820_outline_0023
      004553 C0 07            [24]  984 	push	ar7
      004555 C0 06            [24]  985 	push	ar6
      004557 12 B9 05         [24]  986 	lcall	___memcpy
      00455A 12 43 88         [24]  987 	lcall	_ak820_tapping_source
      00455D AD 82            [24]  988 	mov	r5, dpl
      00455F D0 06            [24]  989 	pop	ar6
      004561 D0 07            [24]  990 	pop	ar7
                                    991 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      004563 BD FF 04         [24]  992 	cjne	r5,#0xff,00104$
      004566 75 82 01         [24]  993 	mov	dpl, #0x01
      004569 22               [24]  994 	ret
      00456A                        995 00104$:
                                    996 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      00456A 74 07            [12]  997 	mov	a,#0x07
      00456C 12 38 31         [24]  998 	lcall	_ak820_outline_0021
      00456F 12 38 41         [24]  999 	lcall	_ak820_outline_0051
      004572 90 06 2F         [24] 1000 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004575 12 48 B1         [24] 1001 	lcall	_ak820_outline_0058
                                   1002 ;	keyboards/ajazz/ak820/ak820_tapping.c:90: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      004578 BE 1A 15         [24] 1003 	cjne	r6,#0x1a,00111$
      00457B BF 7C 12         [24] 1004 	cjne	r7,#0x7c,00111$
      00457E 90 06 2F         [24] 1005 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004581 74 26            [12] 1006 	mov	a,#0x26
      004583 F0               [24] 1007 	movx	@dptr,a
      004584 74 22            [12] 1008 	mov	a,#0x22
      004586 A3               [24] 1009 	inc	dptr
      004587 F0               [24] 1010 	movx	@dptr,a
      004588 90 06 31         [24] 1011 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00458B 74 02            [12] 1012 	mov	a,#0x02
      00458D F0               [24] 1013 	movx	@dptr,a
      00458E 80 28            [24] 1014 	sjmp	00112$
      004590                       1015 00111$:
                                   1016 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      004590 BE 1B 15         [24] 1017 	cjne	r6,#0x1b,00108$
      004593 BF 7C 12         [24] 1018 	cjne	r7,#0x7c,00108$
      004596 90 06 2F         [24] 1019 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004599 74 27            [12] 1020 	mov	a,#0x27
      00459B F0               [24] 1021 	movx	@dptr,a
      00459C 74 32            [12] 1022 	mov	a,#0x32
      00459E A3               [24] 1023 	inc	dptr
      00459F F0               [24] 1024 	movx	@dptr,a
      0045A0 90 06 31         [24] 1025 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0045A3 74 20            [12] 1026 	mov	a,#0x20
      0045A5 F0               [24] 1027 	movx	@dptr,a
      0045A6 80 10            [24] 1028 	sjmp	00112$
      0045A8                       1029 00108$:
                                   1030 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      0045A8 BE 1E 0D         [24] 1031 	cjne	r6,#0x1e,00112$
      0045AB BF 7C 0A         [24] 1032 	cjne	r7,#0x7c,00112$
      0045AE 90 06 2F         [24] 1033 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0045B1 74 28            [12] 1034 	mov	a,#0x28
      0045B3 F0               [24] 1035 	movx	@dptr,a
      0045B4 74 32            [12] 1036 	mov	a,#0x32
      0045B6 A3               [24] 1037 	inc	dptr
      0045B7 F0               [24] 1038 	movx	@dptr,a
      0045B8                       1039 00112$:
                                   1040 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      0045B8 90 06 2F         [24] 1041 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0045BB E0               [24] 1042 	movx	a,@dptr
      0045BC A3               [24] 1043 	inc	dptr
      0045BD E0               [24] 1044 	movx	a,@dptr
      0045BE FF               [12] 1045 	mov	r7,a
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      0045BF BF 20 00         [24] 1047 	cjne	r7,#0x20,00242$
      0045C2                       1048 00242$:
      0045C2 40 05            [24] 1049 	jc	00113$
      0045C4 BF 50 00         [24] 1050 	cjne	r7,#0x50,00244$
      0045C7                       1051 00244$:
      0045C7 40 04            [24] 1052 	jc	00114$
      0045C9                       1053 00113$:
      0045C9 75 82 01         [24] 1054 	mov	dpl, #0x01
      0045CC 22               [24] 1055 	ret
      0045CD                       1056 00114$:
                                   1057 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      0045CD BF 40 00         [24] 1058 	cjne	r7,#0x40,00246$
      0045D0                       1059 00246$:
      0045D0 40 0C            [24] 1060 	jc	00117$
      0045D2 53 07 0F         [24] 1061 	anl	ar7,#0x0f
      0045D5 BF 06 00         [24] 1062 	cjne	r7,#0x06,00248$
      0045D8                       1063 00248$:
      0045D8 40 04            [24] 1064 	jc	00117$
      0045DA 75 82 00         [24] 1065 	mov	dpl, #0x00
      0045DD 22               [24] 1066 	ret
      0045DE                       1067 00117$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      0045DE 90 06 2D         [24] 1069 	mov	dptr,#_ak820_tapping_process_record_10000_623
      0045E1 12 38 41         [24] 1070 	lcall	_ak820_outline_0051
      0045E4 12 48 5F         [24] 1071 	lcall	_ak820_outline_0015
      0045E7 E0               [24] 1072 	movx	a,@dptr
      0045E8 60 1F            [24] 1073 	jz	00131$
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      0045EA 90 0D B0         [24] 1075 	mov	dptr,#_pending
      0045ED ED               [12] 1076 	mov	a,r5
      0045EE 12 43 0D         [24] 1077 	lcall	_ak820_outline_0031
                                   1078 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      0045F1 12 38 41         [24] 1079 	lcall	_ak820_outline_0051
      0045F4 90 06 20         [24] 1080 	mov	dptr,#_pending_time
      0045F7 12 48 B1         [24] 1081 	lcall	_ak820_outline_0058
                                   1082 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      0045FA 90 06 2F         [24] 1083 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0045FD 12 38 41         [24] 1084 	lcall	_ak820_outline_0051
      004600 90 06 22         [24] 1085 	mov	dptr,#_pending_code
      004603 12 48 B1         [24] 1086 	lcall	_ak820_outline_0058
      004606 02 46 BA         [24] 1087 	ljmp	00132$
      004609                       1088 00131$:
                                   1089 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      004609 90 0D B0         [24] 1090 	mov	dptr,#_pending
      00460C E0               [24] 1091 	movx	a,@dptr
      00460D FF               [12] 1092 	mov	r7,a
      00460E ED               [12] 1093 	mov	a,r5
      00460F B5 07 02         [24] 1094 	cjne	a,ar7,00251$
      004612 80 03            [24] 1095 	sjmp	00252$
      004614                       1096 00251$:
      004614 02 46 92         [24] 1097 	ljmp	00128$
      004617                       1098 00252$:
                                   1099 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      004617 12 48 EE         [24] 1100 	lcall	_ak820_outline_0154
                                   1101 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: if (sc_mods) add_owned_mods(sc_mods);
      00461A 90 06 31         [24] 1102 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00461D E0               [24] 1103 	movx	a,@dptr
      00461E FF               [12] 1104 	mov	r7,a
      00461F E0               [24] 1105 	movx	a,@dptr
      004620 60 05            [24] 1106 	jz	00120$
      004622 8F 82            [24] 1107 	mov	dpl, r7
      004624 12 7D 2B         [24] 1108 	lcall	_add_owned_mods
      004627                       1109 00120$:
                                   1110 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      004627 90 06 2D         [24] 1111 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00462A 12 38 41         [24] 1112 	lcall	_ak820_outline_0051
      00462D 74 07            [12] 1113 	mov	a,#0x07
      00462F 2E               [12] 1114 	add	a, r6
      004630 FB               [12] 1115 	mov	r3,a
      004631 E4               [12] 1116 	clr	a
      004632 3F               [12] 1117 	addc	a, r7
      004633 FC               [12] 1118 	mov	r4,a
      004634 90 06 2F         [24] 1119 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004637 E0               [24] 1120 	movx	a,@dptr
      004638 F9               [12] 1121 	mov	r1,a
      004639 7A 00            [12] 1122 	mov	r2,#0x00
      00463B 12 33 FC         [24] 1123 	lcall	_ak820_outline_0123
      00463E E9               [12] 1124 	mov	a,r1
      00463F F0               [24] 1125 	movx	@dptr,a
      004640 EA               [12] 1126 	mov	a,r2
      004641 A3               [24] 1127 	inc	dptr
      004642 F0               [24] 1128 	movx	@dptr,a
                                   1129 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      004643 C3               [12] 1130 	clr	c
      004644 04               [12] 1131 	inc	a
      004645 99               [12] 1132 	subb	a,r1
      004646 50 38            [24] 1133 	jnc	00122$
                                   1134 ;	free result
                                   1135 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      004648 74 06            [12] 1136 	mov	a,#0x06
      00464A 12 38 31         [24] 1137 	lcall	_ak820_outline_0021
      00464D E0               [24] 1138 	movx	a,@dptr
      00464E 54 0F            [12] 1139 	anl	a,#0x0f
      004650 44 10            [12] 1140 	orl	a,#0x10
      004652 F0               [24] 1141 	movx	@dptr,a
                                   1142 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      004653 12 48 5F         [24] 1143 	lcall	_ak820_outline_0015
      004656 74 01            [12] 1144 	mov	a,#0x01
      004658 F0               [24] 1145 	movx	@dptr,a
                                   1146 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      004659 12 48 BE         [24] 1147 	lcall	_ak820_outline_0076
      00465C 12 48 E7         [24] 1148 	lcall	_ak820_outline_0113
      00465F C0 07            [24] 1149 	push	ar7
      004661 C0 06            [24] 1150 	push	ar6
      004663 C0 04            [24] 1151 	push	ar4
      004665 C0 03            [24] 1152 	push	ar3
      004667 12 70 D0         [24] 1153 	lcall	_process_record
      00466A D0 03            [24] 1154 	pop	ar3
      00466C D0 04            [24] 1155 	pop	ar4
      00466E D0 06            [24] 1156 	pop	ar6
      004670 D0 07            [24] 1157 	pop	ar7
                                   1158 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      004672 12 33 FC         [24] 1159 	lcall	_ak820_outline_0123
      004675 E4               [12] 1160 	clr	a
      004676 F0               [24] 1161 	movx	@dptr,a
                                   1162 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      004677 FC               [12] 1163 	mov	r4,a
      004678 12 38 92         [24] 1164 	lcall	_ak820_outline_0119
      00467B 8C F0            [24] 1165 	mov	b, r4
      00467D 12 70 D0         [24] 1166 	lcall	_process_record
      004680                       1167 00122$:
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: if (sc_mods) {
      004680 90 06 31         [24] 1169 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004683 E0               [24] 1170 	movx	a,@dptr
      004684 FF               [12] 1171 	mov	r7,a
      004685 E0               [24] 1172 	movx	a,@dptr
      004686 60 32            [24] 1173 	jz	00132$
                                   1174 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: del_owned_mods(sc_mods);
      004688 8F 82            [24] 1175 	mov	dpl, r7
      00468A 12 7D 3B         [24] 1176 	lcall	_del_owned_mods
                                   1177 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: send_keyboard_report();
      00468D 12 80 67         [24] 1178 	lcall	_send_keyboard_report
      004690 80 28            [24] 1179 	sjmp	00132$
      004692                       1180 00128$:
                                   1181 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      004692 ED               [12] 1182 	mov	a,r5
      004693 24 9E            [12] 1183 	add	a, #_source_state
      004695 FE               [12] 1184 	mov	r6,a
      004696 E4               [12] 1185 	clr	a
      004697 34 05            [12] 1186 	addc	a, #(_source_state >> 8)
      004699 FF               [12] 1187 	mov	r7,a
      00469A 12 38 92         [24] 1188 	lcall	_ak820_outline_0119
      00469D E0               [24] 1189 	movx	a,@dptr
      00469E FD               [12] 1190 	mov	r5,a
      00469F 30 E2 18         [24] 1191 	jnb	acc.2,00132$
                                   1192 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      0046A2 53 05 FB         [24] 1193 	anl	ar5,#0xfb
      0046A5 12 38 92         [24] 1194 	lcall	_ak820_outline_0119
      0046A8 ED               [12] 1195 	mov	a,r5
      0046A9 F0               [24] 1196 	movx	@dptr,a
                                   1197 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      0046AA 90 06 2F         [24] 1198 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0046AD 12 38 41         [24] 1199 	lcall	_ak820_outline_0051
      0046B0 90 06 26         [24] 1200 	mov	dptr,#_hold_PARM_2
      0046B3 E4               [12] 1201 	clr	a
      0046B4 12 43 39         [24] 1202 	lcall	_ak820_outline_0071
      0046B7 12 43 C2         [24] 1203 	lcall	_hold
      0046BA                       1204 00132$:
                                   1205 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      0046BA 75 82 00         [24] 1206 	mov	dpl, #0x00
                                   1207 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      0046BD 22               [24] 1208 	ret
                                   1209 ;------------------------------------------------------------
                                   1210 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1211 ;------------------------------------------------------------
                                   1212 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_647'
                                   1213 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_648'
                                   1214 ;------------------------------------------------------------
                                   1215 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1216 ;	-----------------------------------------
                                   1217 ;	 function ak820_tapping_cancel
                                   1218 ;	-----------------------------------------
      0046BE                       1219 _ak820_tapping_cancel:
                                   1220 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      0046BE 12 48 EE         [24] 1221 	lcall	_ak820_outline_0154
                                   1222 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      0046C1 7F 00            [12] 1223 	mov	r7,#0x00
      0046C3                       1224 00103$:
      0046C3 BF 82 00         [24] 1225 	cjne	r7,#0x82,00122$
      0046C6                       1226 00122$:
      0046C6 50 1D            [24] 1227 	jnc	00105$
                                   1228 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      0046C8 EF               [12] 1229 	mov	a,r7
      0046C9 24 9E            [12] 1230 	add	a, #_source_state
      0046CB FD               [12] 1231 	mov	r5,a
      0046CC E4               [12] 1232 	clr	a
      0046CD 34 05            [12] 1233 	addc	a, #(_source_state >> 8)
      0046CF 12 48 A9         [24] 1234 	lcall	_ak820_outline_0056
                                   1235 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      0046D2 74 02            [12] 1236 	mov	a,#0x02
      0046D4 5C               [12] 1237 	anl	a,r4
      0046D5 FB               [12] 1238 	mov	r3,a
      0046D6 53 04 01         [24] 1239 	anl	ar4,#0x01
      0046D9 EC               [12] 1240 	mov	a,r4
      0046DA 2C               [12] 1241 	add	a,r4
      0046DB 42 03            [12] 1242 	orl	ar3,a
      0046DD 12 38 9C         [24] 1243 	lcall	_ak820_outline_0133
      0046E0 EB               [12] 1244 	mov	a,r3
      0046E1 F0               [24] 1245 	movx	@dptr,a
                                   1246 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      0046E2 0F               [12] 1247 	inc	r7
      0046E3 80 DE            [24] 1248 	sjmp	00103$
      0046E5                       1249 00105$:
                                   1250 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      0046E5 22               [24] 1251 	ret
                                   1252 ;------------------------------------------------------------
                                   1253 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1254 ;------------------------------------------------------------
                                   1255 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1256 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1257 ;code          Allocated with name '_ak820_oneshot_process_code_10000_649'
                                   1258 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_650'
                                   1259 ;i             Allocated with name '_ak820_oneshot_process_i_40000_666'
                                   1260 ;------------------------------------------------------------
                                   1261 ;	keyboards/ajazz/ak820/ak820_tapping.c:143: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1262 ;	-----------------------------------------
                                   1263 ;	 function ak820_oneshot_process
                                   1264 ;	-----------------------------------------
      0046E6                       1265 _ak820_oneshot_process:
      0046E6 12 38 88         [24] 1266 	lcall	_ak820_outline_0108
      0046E9 90 06 36         [24] 1267 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      0046EC 12 38 8D         [24] 1268 	lcall	_ak820_outline_0109
                                   1269 ;	keyboards/ajazz/ak820/ak820_tapping.c:145: if (id == NONE || get_repeat_key_count()) return true;
      0046EF 90 06 34         [24] 1270 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0046F2 E0               [24] 1271 	movx	a,@dptr
      0046F3 FF               [12] 1272 	mov	r7,a
      0046F4 BF FF 02         [24] 1273 	cjne	r7,#0xff,00283$
      0046F7 80 0B            [24] 1274 	sjmp	00101$
      0046F9                       1275 00283$:
      0046F9 C0 07            [24] 1276 	push	ar7
      0046FB 12 A2 EB         [24] 1277 	lcall	_get_repeat_key_count
      0046FE E5 82            [12] 1278 	mov	a, dpl
      004700 D0 07            [24] 1279 	pop	ar7
      004702 60 04            [24] 1280 	jz	00102$
      004704                       1281 00101$:
      004704 75 82 01         [24] 1282 	mov	dpl, #0x01
      004707 22               [24] 1283 	ret
      004708                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_tapping.c:148: if (code >= QK_MAGIC_GUI_ON && code <= QK_MAGIC_TOGGLE_GUI) return true;
      004708 90 06 36         [24] 1286 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      00470B 12 38 6A         [24] 1287 	lcall	_ak820_outline_0084
      00470E C3               [12] 1288 	clr	c
      00470F ED               [12] 1289 	mov	a,r5
      004710 94 09            [12] 1290 	subb	a,#0x09
      004712 EE               [12] 1291 	mov	a,r6
      004713 94 70            [12] 1292 	subb	a,#0x70
      004715 40 0C            [24] 1293 	jc	00105$
      004717 74 0B            [12] 1294 	mov	a,#0x0b
      004719 9D               [12] 1295 	subb	a,r5
      00471A 74 70            [12] 1296 	mov	a,#0x70
      00471C 9E               [12] 1297 	subb	a,r6
      00471D 40 04            [24] 1298 	jc	00105$
                                   1299 ;	free result
      00471F 75 82 01         [24] 1300 	mov	dpl, #0x01
      004722 22               [24] 1301 	ret
      004723                       1302 00105$:
                                   1303 ;	keyboards/ajazz/ak820/ak820_tapping.c:152: if (code == QK_MAGIC_SWAP_CTL_GUI || code == QK_MAGIC_UNSWAP_CTL_GUI || code == QK_MAGIC_TOGGLE_CTL_GUI) return true;
      004723 90 06 36         [24] 1304 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004726 12 38 82         [24] 1305 	lcall	_ak820_outline_0104
      004729 8B 01            [24] 1306 	mov	ar1,r3
      00472B 8C 02            [24] 1307 	mov	ar2,r4
      00472D B9 1B 05         [24] 1308 	cjne	r1,#0x1b,00287$
      004730 BA 70 02         [24] 1309 	cjne	r2,#0x70,00287$
      004733 80 0E            [24] 1310 	sjmp	00107$
      004735                       1311 00287$:
      004735 B9 1C 05         [24] 1312 	cjne	r1,#0x1c,00288$
      004738 BA 70 02         [24] 1313 	cjne	r2,#0x70,00288$
      00473B 80 06            [24] 1314 	sjmp	00107$
      00473D                       1315 00288$:
      00473D B9 1D 07         [24] 1316 	cjne	r1,#0x1d,00108$
      004740 BA 70 04         [24] 1317 	cjne	r2,#0x70,00108$
      004743                       1318 00107$:
      004743 75 82 01         [24] 1319 	mov	dpl, #0x01
      004746 22               [24] 1320 	ret
      004747                       1321 00108$:
                                   1322 ;	keyboards/ajazz/ak820/ak820_tapping.c:158: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004747 8C 01            [24] 1323 	mov	ar1,r4
      004749 B9 52 02         [24] 1324 	cjne	r1,#0x52,00291$
      00474C 80 03            [24] 1325 	sjmp	00292$
      00474E                       1326 00291$:
      00474E 02 47 F5         [24] 1327 	ljmp	00123$
      004751                       1328 00292$:
      004751 8B 02            [24] 1329 	mov	ar2,r3
      004753 53 02 E0         [24] 1330 	anl	ar2,#0xe0
      004756 BA A0 02         [24] 1331 	cjne	r2,#0xa0,00293$
      004759 80 03            [24] 1332 	sjmp	00294$
      00475B                       1333 00293$:
      00475B 02 47 F5         [24] 1334 	ljmp	00123$
      00475E                       1335 00294$:
                                   1336 ;	keyboards/ajazz/ak820/ak820_tapping.c:159: mods = code & 15;
      00475E 8B 02            [24] 1337 	mov	ar2,r3
      004760 53 02 0F         [24] 1338 	anl	ar2,#0x0f
      004763 90 06 38         [24] 1339 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004766 EA               [12] 1340 	mov	a,r2
      004767 F0               [24] 1341 	movx	@dptr,a
                                   1342 ;	keyboards/ajazz/ak820/ak820_tapping.c:160: if (code & 16) mods <<= 4;
      004768 EB               [12] 1343 	mov	a,r3
      004769 30 E4 08         [24] 1344 	jnb	acc.4,00112$
      00476C EA               [12] 1345 	mov	a,r2
      00476D C4               [12] 1346 	swap	a
      00476E 54 F0            [12] 1347 	anl	a,#0xf0
      004770 90 06 38         [24] 1348 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004773 F0               [24] 1349 	movx	@dptr,a
      004774                       1350 00112$:
                                   1351 ;	keyboards/ajazz/ak820/ak820_tapping.c:161: if (pressed) {
      004774 90 06 35         [24] 1352 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004777 E0               [24] 1353 	movx	a,@dptr
      004778 60 2E            [24] 1354 	jz	00120$
                                   1355 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: source_state[id] |= SOURCE_ONESHOT;
      00477A EF               [12] 1356 	mov	a,r7
      00477B 12 48 85         [24] 1357 	lcall	_ak820_outline_0026
      00477E 43 02 08         [24] 1358 	orl	ar2,#0x08
      004781 12 48 D3         [24] 1359 	lcall	_ak820_outline_0094
                                   1360 ;	keyboards/ajazz/ak820/ak820_tapping.c:163: source_state[id] &= ~SOURCE_ONESHOT_USED;
      004784 53 02 EF         [24] 1361 	anl	ar2,#0xef
      004787 12 48 D3         [24] 1362 	lcall	_ak820_outline_0094
                                   1363 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      00478A 90 0D B1         [24] 1364 	mov	dptr,#_ak820_oneshot_target
      00478D E0               [24] 1365 	movx	a,@dptr
      00478E FA               [12] 1366 	mov	r2,a
      00478F BA FF 02         [24] 1367 	cjne	r2,#0xff,00297$
      004792 80 09            [24] 1368 	sjmp	00114$
      004794                       1369 00297$:
      004794 12 48 B7         [24] 1370 	lcall	_ak820_outline_0063
      004797 43 02 10         [24] 1371 	orl	ar2,#0x10
      00479A 12 48 D3         [24] 1372 	lcall	_ak820_outline_0094
      00479D                       1373 00114$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: register_mods(mods);
      00479D 90 06 38         [24] 1375 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0047A0 E0               [24] 1376 	movx	a,@dptr
      0047A1 F5 82            [12] 1377 	mov	dpl,a
      0047A3 12 76 2F         [24] 1378 	lcall	_register_mods
      0047A6 80 49            [24] 1379 	sjmp	00121$
      0047A8                       1380 00120$:
                                   1381 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: } else if (source_state[id] & SOURCE_ONESHOT) {
      0047A8 EF               [12] 1382 	mov	a,r7
      0047A9 12 48 85         [24] 1383 	lcall	_ak820_outline_0026
      0047AC 30 E3 42         [24] 1384 	jnb	acc.3,00121$
                                   1385 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      0047AF EA               [12] 1386 	mov	a,r2
      0047B0 20 E4 24         [24] 1387 	jb	acc.4,00116$
                                   1388 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: add_owned_mods(mods & ~ak820_oneshot_mods);
      0047B3 90 06 32         [24] 1389 	mov	dptr,#_ak820_oneshot_mods
      0047B6 E0               [24] 1390 	movx	a,@dptr
      0047B7 F4               [12] 1391 	cpl	a
      0047B8 FA               [12] 1392 	mov	r2,a
      0047B9 90 06 38         [24] 1393 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0047BC E0               [24] 1394 	movx	a,@dptr
      0047BD F9               [12] 1395 	mov	r1,a
      0047BE 52 02            [12] 1396 	anl	ar2,a
      0047C0 8A 82            [24] 1397 	mov	dpl, r2
      0047C2 C0 04            [24] 1398 	push	ar4
      0047C4 C0 03            [24] 1399 	push	ar3
      0047C6 C0 01            [24] 1400 	push	ar1
      0047C8 12 7D 2B         [24] 1401 	lcall	_add_owned_mods
      0047CB D0 01            [24] 1402 	pop	ar1
      0047CD D0 03            [24] 1403 	pop	ar3
      0047CF D0 04            [24] 1404 	pop	ar4
                                   1405 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: ak820_oneshot_mods |= mods;
      0047D1 90 06 32         [24] 1406 	mov	dptr,#_ak820_oneshot_mods
      0047D4 E0               [24] 1407 	movx	a,@dptr
      0047D5 49               [12] 1408 	orl	a,r1
      0047D6 F0               [24] 1409 	movx	@dptr,a
      0047D7                       1410 00116$:
                                   1411 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: unregister_mods(mods);
      0047D7 90 06 38         [24] 1412 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0047DA E0               [24] 1413 	movx	a,@dptr
      0047DB F5 82            [12] 1414 	mov	dpl,a
      0047DD C0 04            [24] 1415 	push	ar4
      0047DF C0 03            [24] 1416 	push	ar3
      0047E1 12 76 43         [24] 1417 	lcall	_unregister_mods
      0047E4 D0 03            [24] 1418 	pop	ar3
      0047E6 D0 04            [24] 1419 	pop	ar4
                                   1420 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      0047E8 12 48 B7         [24] 1421 	lcall	_ak820_outline_0063
      0047EB 53 02 E7         [24] 1422 	anl	ar2,#0xe7
      0047EE 12 48 D3         [24] 1423 	lcall	_ak820_outline_0094
      0047F1                       1424 00121$:
                                   1425 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: return false;
      0047F1 75 82 00         [24] 1426 	mov	dpl, #0x00
      0047F4 22               [24] 1427 	ret
      0047F5                       1428 00123$:
                                   1429 ;	keyboards/ajazz/ak820/ak820_tapping.c:176: if (pressed && code > KC_TRANSPARENT &&
      0047F5 90 06 35         [24] 1430 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0047F8 E0               [24] 1431 	movx	a,@dptr
      0047F9 60 56            [24] 1432 	jz	00131$
      0047FB C3               [12] 1433 	clr	c
      0047FC 74 01            [12] 1434 	mov	a,#0x01
      0047FE 9D               [12] 1435 	subb	a,r5
      0047FF E4               [12] 1436 	clr	a
      004800 9E               [12] 1437 	subb	a,r6
      004801 50 4E            [24] 1438 	jnc	00131$
                                   1439 ;	free result
                                   1440 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004803 C3               [12] 1441 	clr	c
      004804 ED               [12] 1442 	mov	a,r5
      004805 94 E0            [12] 1443 	subb	a,#0xe0
      004807 EE               [12] 1444 	mov	a,r6
      004808 94 00            [12] 1445 	subb	a,#0x00
      00480A 40 07            [24] 1446 	jc	00136$
      00480C 74 E7            [12] 1447 	mov	a,#0xe7
      00480E 9D               [12] 1448 	subb	a,r5
      00480F E4               [12] 1449 	clr	a
      004810 9E               [12] 1450 	subb	a,r6
      004811 50 3E            [24] 1451 	jnc	00131$
                                   1452 ;	free result
      004813                       1453 00136$:
                                   1454 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004813 74 AE            [12] 1455 	mov	a,#0x100 - 0x52
      004815 2E               [12] 1456 	add	a,r6
      004816 50 09            [24] 1457 	jnc	00180$
      004818 C3               [12] 1458 	clr	c
      004819 74 DF            [12] 1459 	mov	a,#0xdf
      00481B 9D               [12] 1460 	subb	a,r5
      00481C 74 52            [12] 1461 	mov	a,#0x52
      00481E 9E               [12] 1462 	subb	a,r6
      00481F 50 30            [24] 1463 	jnc	00131$
                                   1464 ;	free result
                                   1465 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: for (uint8_t i = 0; i < SOURCES; ++i)
      004821                       1466 00180$:
      004821 7E 00            [12] 1467 	mov	r6,#0x00
      004823                       1468 00138$:
      004823 BE 82 00         [24] 1469 	cjne	r6,#0x82,00306$
      004826                       1470 00306$:
      004826 50 12            [24] 1471 	jnc	00127$
                                   1472 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004828 EE               [12] 1473 	mov	a,r6
      004829 12 48 C5         [24] 1474 	lcall	_ak820_outline_0078
      00482C 30 E3 08         [24] 1475 	jnb	acc.3,00139$
      00482F 43 03 10         [24] 1476 	orl	ar3,#0x10
      004832 12 38 97         [24] 1477 	lcall	_ak820_outline_0124
      004835 EB               [12] 1478 	mov	a,r3
      004836 F0               [24] 1479 	movx	@dptr,a
      004837                       1480 00139$:
                                   1481 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: for (uint8_t i = 0; i < SOURCES; ++i)
      004837 0E               [12] 1482 	inc	r6
      004838 80 E9            [24] 1483 	sjmp	00138$
      00483A                       1484 00127$:
                                   1485 ;	keyboards/ajazz/ak820/ak820_tapping.c:181: if (ak820_oneshot_mods) {
      00483A 90 06 32         [24] 1486 	mov	dptr,#_ak820_oneshot_mods
      00483D E0               [24] 1487 	movx	a,@dptr
      00483E FE               [12] 1488 	mov	r6,a
      00483F E0               [24] 1489 	movx	a,@dptr
      004840 60 0F            [24] 1490 	jz	00131$
                                   1491 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: ak820_oneshot_consumed = ak820_oneshot_mods;
      004842 90 06 33         [24] 1492 	mov	dptr,#_ak820_oneshot_consumed
      004845 EE               [12] 1493 	mov	a,r6
      004846 F0               [24] 1494 	movx	@dptr,a
                                   1495 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: ak820_oneshot_target = id;
      004847 90 0D B1         [24] 1496 	mov	dptr,#_ak820_oneshot_target
      00484A EF               [12] 1497 	mov	a,r7
      00484B F0               [24] 1498 	movx	@dptr,a
                                   1499 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: ak820_oneshot_mods = 0;
      00484C 90 06 32         [24] 1500 	mov	dptr,#_ak820_oneshot_mods
      00484F E4               [12] 1501 	clr	a
      004850 F0               [24] 1502 	movx	@dptr,a
      004851                       1503 00131$:
                                   1504 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: return true;
      004851 75 82 01         [24] 1505 	mov	dpl, #0x01
                                   1506 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: }
      004854 22               [24] 1507 	ret
                                   1508 	.area CSEG    (CODE)
                                   1509 	.area CONST   (CODE)
                                   1510 	.area XINIT   (CODE)
      00C1C5                       1511 __xinit__pending:
      00C1C5 FF                    1512 	.db #0xff	; 255
      00C1C6                       1513 __xinit__ak820_oneshot_target:
      00C1C6 FF                    1514 	.db #0xff	; 255
                                   1515 	.area CABS    (ABS,CODE)
                                   1516 
                                   1517 ; Experimental exact instruction outlining.
                                   1518 	.globl _ak820_outline_0008
                                   1519 	.globl _ak820_outline_0009
                                   1520 	.globl _ak820_outline_0011
                                   1521 	.globl _ak820_outline_0015
                                   1522 	.globl _ak820_outline_0016
                                   1523 	.globl _ak820_outline_0021
                                   1524 	.globl _ak820_outline_0023
                                   1525 	.globl _ak820_outline_0026
                                   1526 	.globl _ak820_outline_0031
                                   1527 	.globl _ak820_outline_0032
                                   1528 	.globl _ak820_outline_0033
                                   1529 	.globl _ak820_outline_0036
                                   1530 	.globl _ak820_outline_0051
                                   1531 	.globl _ak820_outline_0056
                                   1532 	.globl _ak820_outline_0058
                                   1533 	.globl _ak820_outline_0063
                                   1534 	.globl _ak820_outline_0071
                                   1535 	.globl _ak820_outline_0076
                                   1536 	.globl _ak820_outline_0078
                                   1537 	.globl _ak820_outline_0084
                                   1538 	.globl _ak820_outline_0094
                                   1539 	.globl _ak820_outline_0097
                                   1540 	.globl _ak820_outline_0102
                                   1541 	.globl _ak820_outline_0104
                                   1542 	.globl _ak820_outline_0108
                                   1543 	.globl _ak820_outline_0109
                                   1544 	.globl _ak820_outline_0113
                                   1545 	.globl _ak820_outline_0119
                                   1546 	.globl _ak820_outline_0123
                                   1547 	.globl _ak820_outline_0124
                                   1548 	.globl _ak820_outline_0133
                                   1549 	.globl _ak820_outline_0154
                                   1550 	.globl _ak820_outline_0158
                                   1551 	.globl _ak820_outline_0189
                                   1552 
                                   1553 	.area CSEG (CODE)
                                   1554 ; function ak820_outline_0008
      004855                       1555 _ak820_outline_0008:
      004855 E0               [24] 1556 	movx	a,@dptr
      004856 FE               [12] 1557 	mov	r6,a
      004857 A3               [24] 1558 	inc	dptr
      004858 E0               [24] 1559 	movx	a,@dptr
      004859 FF               [12] 1560 	mov	r7,a
      00485A 8E 04            [24] 1561 	mov	ar4,r6
      00485C 8F 05            [24] 1562 	mov	ar5,r7
      00485E 22               [24] 1563 	ret
                                   1564 
                                   1565 	.area CSEG (CODE)
                                   1566 ; function ak820_outline_0015
      00485F                       1567 _ak820_outline_0015:
      00485F 74 05            [12] 1568 	mov	a,#0x05
      004861 2E               [12] 1569 	add	a,r6
      004862 FB               [12] 1570 	mov	r3,a
      004863 E4               [12] 1571 	clr	a
      004864 3F               [12] 1572 	addc	a,r7
      004865 FC               [12] 1573 	mov	r4,a
      004866 8B 82            [24] 1574 	mov	dpl,r3
      004868 8C 83            [24] 1575 	mov	dph,r4
      00486A 22               [24] 1576 	ret
                                   1577 
                                   1578 	.area CSEG (CODE)
                                   1579 ; function ak820_outline_0023
      00486B                       1580 _ak820_outline_0023:
      00486B 90 0D A0         [24] 1581 	mov	dptr,#___memcpy_PARM_2
      00486E EC               [12] 1582 	mov	a,r4
      00486F F0               [24] 1583 	movx	@dptr,a
      004870 ED               [12] 1584 	mov	a,r5
      004871 A3               [24] 1585 	inc	dptr
      004872 F0               [24] 1586 	movx	@dptr,a
      004873 E4               [12] 1587 	clr	a
      004874 A3               [24] 1588 	inc	dptr
      004875 F0               [24] 1589 	movx	@dptr,a
      004876 90 0D A3         [24] 1590 	mov	dptr,#___memcpy_PARM_3
      004879 74 02            [12] 1591 	mov	a,#0x02
      00487B F0               [24] 1592 	movx	@dptr,a
      00487C E4               [12] 1593 	clr	a
      00487D A3               [24] 1594 	inc	dptr
      00487E F0               [24] 1595 	movx	@dptr,a
      00487F 90 06 24         [24] 1596 	mov	dptr,#_ak820_tapping_source_PARM_1
      004882 F5 F0            [12] 1597 	mov	b,a
      004884 22               [24] 1598 	ret
                                   1599 
                                   1600 	.area CSEG (CODE)
                                   1601 ; function ak820_outline_0026
      004885                       1602 _ak820_outline_0026:
      004885 24 9E            [12] 1603 	add	a,#_source_state
      004887 FB               [12] 1604 	mov	r3,a
      004888 E4               [12] 1605 	clr	a
      004889 34 05            [12] 1606 	addc	a,#(_source_state>>8)
      00488B FC               [12] 1607 	mov	r4,a
      00488C 8B 82            [24] 1608 	mov	dpl,r3
      00488E 8C 83            [24] 1609 	mov	dph,r4
      004890 E0               [24] 1610 	movx	a,@dptr
      004891 FA               [12] 1611 	mov	r2,a
      004892 22               [24] 1612 	ret
                                   1613 
                                   1614 	.area CSEG (CODE)
                                   1615 ; function ak820_outline_0032
      004893                       1616 _ak820_outline_0032:
      004893 2E               [12] 1617 	add	a,r6
      004894 FA               [12] 1618 	mov	r2,a
      004895 E4               [12] 1619 	clr	a
      004896 3F               [12] 1620 	addc	a,r7
      004897 FB               [12] 1621 	mov	r3,a
      004898 8A 82            [24] 1622 	mov	dpl,r2
      00489A 8B 83            [24] 1623 	mov	dph,r3
      00489C E0               [24] 1624 	movx	a,@dptr
      00489D 22               [24] 1625 	ret
                                   1626 
                                   1627 	.area CSEG (CODE)
                                   1628 ; function ak820_outline_0033
      00489E                       1629 _ak820_outline_0033:
      00489E 2E               [12] 1630 	add	a,r6
      00489F FC               [12] 1631 	mov	r4,a
      0048A0 E4               [12] 1632 	clr	a
      0048A1 3F               [12] 1633 	addc	a,r7
      0048A2 FD               [12] 1634 	mov	r5,a
      0048A3 8C 82            [24] 1635 	mov	dpl,r4
      0048A5 8D 83            [24] 1636 	mov	dph,r5
      0048A7 E0               [24] 1637 	movx	a,@dptr
      0048A8 22               [24] 1638 	ret
                                   1639 
                                   1640 	.area CSEG (CODE)
                                   1641 ; function ak820_outline_0056
      0048A9                       1642 _ak820_outline_0056:
      0048A9 FE               [12] 1643 	mov	r6,a
      0048AA 8D 82            [24] 1644 	mov	dpl,r5
      0048AC 8E 83            [24] 1645 	mov	dph,r6
      0048AE E0               [24] 1646 	movx	a,@dptr
      0048AF FC               [12] 1647 	mov	r4,a
      0048B0 22               [24] 1648 	ret
                                   1649 
                                   1650 	.area CSEG (CODE)
                                   1651 ; function ak820_outline_0058
      0048B1                       1652 _ak820_outline_0058:
      0048B1 EE               [12] 1653 	mov	a,r6
      0048B2 F0               [24] 1654 	movx	@dptr,a
      0048B3 EF               [12] 1655 	mov	a,r7
      0048B4 A3               [24] 1656 	inc	dptr
      0048B5 F0               [24] 1657 	movx	@dptr,a
      0048B6 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0063
      0048B7                       1662 _ak820_outline_0063:
      0048B7 8B 82            [24] 1663 	mov	dpl,r3
      0048B9 8C 83            [24] 1664 	mov	dph,r4
      0048BB E0               [24] 1665 	movx	a,@dptr
      0048BC FA               [12] 1666 	mov	r2,a
      0048BD 22               [24] 1667 	ret
                                   1668 
                                   1669 	.area CSEG (CODE)
                                   1670 ; function ak820_outline_0076
      0048BE                       1671 _ak820_outline_0076:
      0048BE 8E 00            [24] 1672 	mov	ar0,r6
      0048C0 8F 01            [24] 1673 	mov	ar1,r7
      0048C2 7A 00            [12] 1674 	mov	r2,#0x00
      0048C4 22               [24] 1675 	ret
                                   1676 
                                   1677 	.area CSEG (CODE)
                                   1678 ; function ak820_outline_0078
      0048C5                       1679 _ak820_outline_0078:
      0048C5 24 9E            [12] 1680 	add	a,#_source_state
      0048C7 FC               [12] 1681 	mov	r4,a
      0048C8 E4               [12] 1682 	clr	a
      0048C9 34 05            [12] 1683 	addc	a,#(_source_state>>8)
      0048CB FD               [12] 1684 	mov	r5,a
      0048CC 8C 82            [24] 1685 	mov	dpl,r4
      0048CE 8D 83            [24] 1686 	mov	dph,r5
      0048D0 E0               [24] 1687 	movx	a,@dptr
      0048D1 FB               [12] 1688 	mov	r3,a
      0048D2 22               [24] 1689 	ret
                                   1690 
                                   1691 	.area CSEG (CODE)
                                   1692 ; function ak820_outline_0094
      0048D3                       1693 _ak820_outline_0094:
      0048D3 8B 82            [24] 1694 	mov	dpl,r3
      0048D5 8C 83            [24] 1695 	mov	dph,r4
      0048D7 EA               [12] 1696 	mov	a,r2
      0048D8 F0               [24] 1697 	movx	@dptr,a
      0048D9 22               [24] 1698 	ret
                                   1699 
                                   1700 	.area CSEG (CODE)
                                   1701 ; function ak820_outline_0097
      0048DA                       1702 _ak820_outline_0097:
      0048DA 74 04            [12] 1703 	mov	a,#0x04
      0048DC 2E               [12] 1704 	add	a,r6
      0048DD FB               [12] 1705 	mov	r3,a
      0048DE E4               [12] 1706 	clr	a
      0048DF 3F               [12] 1707 	addc	a,r7
      0048E0 FC               [12] 1708 	mov	r4,a
      0048E1 8B 82            [24] 1709 	mov	dpl,r3
      0048E3 8C 83            [24] 1710 	mov	dph,r4
      0048E5 E0               [24] 1711 	movx	a,@dptr
      0048E6 22               [24] 1712 	ret
                                   1713 
                                   1714 	.area CSEG (CODE)
                                   1715 ; function ak820_outline_0113
      0048E7                       1716 _ak820_outline_0113:
      0048E7 88 82            [24] 1717 	mov	dpl,r0
      0048E9 89 83            [24] 1718 	mov	dph,r1
      0048EB 8A F0            [24] 1719 	mov	b,r2
      0048ED 22               [24] 1720 	ret
                                   1721 
                                   1722 	.area CSEG (CODE)
                                   1723 ; function ak820_outline_0154
      0048EE                       1724 _ak820_outline_0154:
      0048EE 90 0D B0         [24] 1725 	mov	dptr,#_pending
      0048F1 74 FF            [12] 1726 	mov	a,#0xff
      0048F3 F0               [24] 1727 	movx	@dptr,a
      0048F4 22               [24] 1728 	ret
