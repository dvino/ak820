                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tapping
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _del_owned_mods
                                     13 	.globl _add_owned_mods
                                     14 	.globl _send_keyboard_report
                                     15 	.globl _layer_hold_off
                                     16 	.globl _layer_hold_on
                                     17 	.globl _unregister_mods
                                     18 	.globl _register_mods
                                     19 	.globl _process_record
                                     20 	.globl _ADC_START
                                     21 	.globl _S0_R_FIFO
                                     22 	.globl _S0_T_FIFO
                                     23 	.globl _S0_FREE
                                     24 	.globl _S0_IF_BYTE
                                     25 	.globl _S0_IF_FIRST
                                     26 	.globl _S0_IF_OV
                                     27 	.globl _S0_FST_ACT
                                     28 	.globl _CP_RL2
                                     29 	.globl _C_T2
                                     30 	.globl _TR2
                                     31 	.globl _EXEN2
                                     32 	.globl _TCLK
                                     33 	.globl _RCLK
                                     34 	.globl _EXF2
                                     35 	.globl _CAP1F
                                     36 	.globl _TF2
                                     37 	.globl _RI
                                     38 	.globl _TI
                                     39 	.globl _RB8
                                     40 	.globl _TB8
                                     41 	.globl _REN
                                     42 	.globl _SM2
                                     43 	.globl _SM1
                                     44 	.globl _SM0
                                     45 	.globl _IT0
                                     46 	.globl _IE0
                                     47 	.globl _IT1
                                     48 	.globl _IE1
                                     49 	.globl _TR0
                                     50 	.globl _TF0
                                     51 	.globl _TR1
                                     52 	.globl _TF1
                                     53 	.globl _P4_0
                                     54 	.globl _P4_1
                                     55 	.globl _P4_2
                                     56 	.globl _P4_3
                                     57 	.globl _P4_4
                                     58 	.globl _P4_5
                                     59 	.globl _P4_6
                                     60 	.globl _RXD
                                     61 	.globl _TXD
                                     62 	.globl _INT0
                                     63 	.globl _INT1
                                     64 	.globl _T0
                                     65 	.globl _T1
                                     66 	.globl _MOSI1
                                     67 	.globl _MISO1
                                     68 	.globl _SCK1
                                     69 	.globl _P3_0
                                     70 	.globl _P3_1
                                     71 	.globl _P3_2
                                     72 	.globl _P3_3
                                     73 	.globl _P3_4
                                     74 	.globl _P3_5
                                     75 	.globl _P3_6
                                     76 	.globl _P3_7
                                     77 	.globl _CAP1_
                                     78 	.globl _T2_
                                     79 	.globl _CAP2_
                                     80 	.globl _T2EX_
                                     81 	.globl _RXD1
                                     82 	.globl _TXD1
                                     83 	.globl _P2_0
                                     84 	.globl _P2_1
                                     85 	.globl _P2_2
                                     86 	.globl _P2_3
                                     87 	.globl _P2_4
                                     88 	.globl _P2_5
                                     89 	.globl _P2_6
                                     90 	.globl _P2_7
                                     91 	.globl _AIN0
                                     92 	.globl _AIN1
                                     93 	.globl _AIN2
                                     94 	.globl _AIN3
                                     95 	.globl _AIN4
                                     96 	.globl _AIN5
                                     97 	.globl _AIN6
                                     98 	.globl _AIN7
                                     99 	.globl _CAP1
                                    100 	.globl _T2
                                    101 	.globl _CAP2
                                    102 	.globl _T2EX
                                    103 	.globl _INT0_
                                    104 	.globl _SCS
                                    105 	.globl _MOSI
                                    106 	.globl _MISO
                                    107 	.globl _SCK
                                    108 	.globl _RXD1_
                                    109 	.globl _TXD1_
                                    110 	.globl _P1_0
                                    111 	.globl _P1_1
                                    112 	.globl _P1_2
                                    113 	.globl _P1_3
                                    114 	.globl _P1_4
                                    115 	.globl _P1_5
                                    116 	.globl _P1_6
                                    117 	.globl _P1_7
                                    118 	.globl _AIN8
                                    119 	.globl _AIN9
                                    120 	.globl _AIN10
                                    121 	.globl _AIN11
                                    122 	.globl _AIN12
                                    123 	.globl _AIN13
                                    124 	.globl _RXD_
                                    125 	.globl _TXD_
                                    126 	.globl _SCL0
                                    127 	.globl _SDA0
                                    128 	.globl _P0_0
                                    129 	.globl _P0_1
                                    130 	.globl _P0_2
                                    131 	.globl _P0_3
                                    132 	.globl _P0_4
                                    133 	.globl _P0_5
                                    134 	.globl _P0_6
                                    135 	.globl _P0_7
                                    136 	.globl _IE_SPI0
                                    137 	.globl _IE_USB
                                    138 	.globl _IE_ADC
                                    139 	.globl _IE_UART1
                                    140 	.globl _IE_PWM_I2C
                                    141 	.globl _IE_GPIO
                                    142 	.globl _IE_WDOG
                                    143 	.globl _PX0
                                    144 	.globl _PT0
                                    145 	.globl _PX1
                                    146 	.globl _PT1
                                    147 	.globl _PS
                                    148 	.globl _PT2
                                    149 	.globl _PL_FLAG
                                    150 	.globl _PH_FLAG
                                    151 	.globl _EX0
                                    152 	.globl _ET0
                                    153 	.globl _EX1
                                    154 	.globl _ET1
                                    155 	.globl _ES
                                    156 	.globl _ET2
                                    157 	.globl _E_DIS
                                    158 	.globl _EA
                                    159 	.globl _P
                                    160 	.globl _F1
                                    161 	.globl _OV
                                    162 	.globl _RS0
                                    163 	.globl _RS1
                                    164 	.globl _F0
                                    165 	.globl _AC
                                    166 	.globl _CY
                                    167 	.globl _I2CS_INT_ST
                                    168 	.globl _I2CX_INT
                                    169 	.globl _LED_STATUS
                                    170 	.globl _LED_DMA_H
                                    171 	.globl _LED_DMA_L
                                    172 	.globl _LED_DMA
                                    173 	.globl _LED_PWM_OE
                                    174 	.globl _LED_COMMON
                                    175 	.globl _ADC_CHAN
                                    176 	.globl _ADC_DAT_H
                                    177 	.globl _ADC_DAT_L
                                    178 	.globl _ADC_DAT
                                    179 	.globl _ADC_CTRL
                                    180 	.globl _SPI1_CK_SE
                                    181 	.globl _SPI1_CTRL
                                    182 	.globl _SPI1_DATA
                                    183 	.globl _SPI1_STAT
                                    184 	.globl _SIF1
                                    185 	.globl _SBAUD1
                                    186 	.globl _SBUF1
                                    187 	.globl _SCON1
                                    188 	.globl _SPI0_SETUP
                                    189 	.globl _SPI0_CK_SE
                                    190 	.globl _SPI0_CTRL
                                    191 	.globl _SPI0_DATA
                                    192 	.globl _SPI0_STAT
                                    193 	.globl _T2CAP1H
                                    194 	.globl _T2CAP1L
                                    195 	.globl _T2CAP1
                                    196 	.globl _TH2
                                    197 	.globl _TL2
                                    198 	.globl _T2COUNT
                                    199 	.globl _RCAP2H
                                    200 	.globl _RCAP2L
                                    201 	.globl _RCAP2
                                    202 	.globl _T2MOD
                                    203 	.globl _T2CON
                                    204 	.globl _SBUF
                                    205 	.globl _SCON
                                    206 	.globl _TH1
                                    207 	.globl _TH0
                                    208 	.globl _TL1
                                    209 	.globl _TL0
                                    210 	.globl _TMOD
                                    211 	.globl _TCON
                                    212 	.globl _XBUS_AUX
                                    213 	.globl _P7
                                    214 	.globl _P6_DIR
                                    215 	.globl _P6_OUT_PU
                                    216 	.globl _P6_IN
                                    217 	.globl _P5_DIR
                                    218 	.globl _P5_OUT_PU
                                    219 	.globl _P5_IN
                                    220 	.globl _P4_LED_KEY
                                    221 	.globl _P4_DIR_PU
                                    222 	.globl _P4_MOD_OC
                                    223 	.globl _P4
                                    224 	.globl _P3_DIR_PU
                                    225 	.globl _P3_MOD_OC
                                    226 	.globl _P3
                                    227 	.globl _P2_DIR_PU
                                    228 	.globl _P2_MOD_OC
                                    229 	.globl _P2
                                    230 	.globl _P1_DIR_PU
                                    231 	.globl _P1_MOD_OC
                                    232 	.globl _P1
                                    233 	.globl _P0_DIR_PU
                                    234 	.globl _P0_MOD_OC
                                    235 	.globl _P0
                                    236 	.globl _ROM_CTRL
                                    237 	.globl _ROM_DATA_HH
                                    238 	.globl _ROM_DATA_HL
                                    239 	.globl _ROM_DATA_HI
                                    240 	.globl _ROM_ADDR_H
                                    241 	.globl _ROM_ADDR_L
                                    242 	.globl _ROM_ADDR
                                    243 	.globl _GPIO_IE
                                    244 	.globl _IP_EX
                                    245 	.globl _IE_EX
                                    246 	.globl _IP
                                    247 	.globl _IE
                                    248 	.globl _WDOG_COUNT
                                    249 	.globl _RESET_KEEP
                                    250 	.globl _WAKE_CTRL
                                    251 	.globl _CLOCK_CFG
                                    252 	.globl _POWER_CFG
                                    253 	.globl _PCON
                                    254 	.globl _GLOBAL_CFG
                                    255 	.globl _SAFE_MOD
                                    256 	.globl _DPH
                                    257 	.globl _DPL
                                    258 	.globl _SP
                                    259 	.globl _A_INV
                                    260 	.globl _B
                                    261 	.globl _ACC
                                    262 	.globl _PSW
                                    263 	.globl _ak820_oneshot_target
                                    264 	.globl _ak820_oneshot_process_PARM_3
                                    265 	.globl _ak820_oneshot_process_PARM_2
                                    266 	.globl _ak820_oneshot_consumed
                                    267 	.globl _ak820_oneshot_mods
                                    268 	.globl _ak820_tapping_source_PARM_1
                                    269 	.globl _ak820_tapping_source
                                    270 	.globl _ak820_tapping_before
                                    271 	.globl _ak820_tapping_process
                                    272 	.globl _ak820_tapping_cancel
                                    273 	.globl _ak820_oneshot_process
                                    274 ;--------------------------------------------------------
                                    275 ; special function registers
                                    276 ;--------------------------------------------------------
                                    277 	.area RSEG    (ABS,DATA)
      000000                        278 	.org 0x0000
                           0000D0   279 _PSW	=	0x00d0
                           0000E0   280 _ACC	=	0x00e0
                           0000F0   281 _B	=	0x00f0
                           0000FD   282 _A_INV	=	0x00fd
                           000081   283 _SP	=	0x0081
                           000082   284 _DPL	=	0x0082
                           000083   285 _DPH	=	0x0083
                           0000A1   286 _SAFE_MOD	=	0x00a1
                           0000B1   287 _GLOBAL_CFG	=	0x00b1
                           000087   288 _PCON	=	0x0087
                           0000BA   289 _POWER_CFG	=	0x00ba
                           0000B9   290 _CLOCK_CFG	=	0x00b9
                           0000A9   291 _WAKE_CTRL	=	0x00a9
                           0000FE   292 _RESET_KEEP	=	0x00fe
                           0000FF   293 _WDOG_COUNT	=	0x00ff
                           0000A8   294 _IE	=	0x00a8
                           0000B8   295 _IP	=	0x00b8
                           0000E8   296 _IE_EX	=	0x00e8
                           0000E9   297 _IP_EX	=	0x00e9
                           0000B2   298 _GPIO_IE	=	0x00b2
                           008584   299 _ROM_ADDR	=	0x8584
                           000084   300 _ROM_ADDR_L	=	0x0084
                           000085   301 _ROM_ADDR_H	=	0x0085
                           008F8E   302 _ROM_DATA_HI	=	0x8f8e
                           00008E   303 _ROM_DATA_HL	=	0x008e
                           00008F   304 _ROM_DATA_HH	=	0x008f
                           000086   305 _ROM_CTRL	=	0x0086
                           000080   306 _P0	=	0x0080
                           0000C4   307 _P0_MOD_OC	=	0x00c4
                           0000C5   308 _P0_DIR_PU	=	0x00c5
                           000090   309 _P1	=	0x0090
                           000092   310 _P1_MOD_OC	=	0x0092
                           000093   311 _P1_DIR_PU	=	0x0093
                           0000A0   312 _P2	=	0x00a0
                           000094   313 _P2_MOD_OC	=	0x0094
                           000095   314 _P2_DIR_PU	=	0x0095
                           0000B0   315 _P3	=	0x00b0
                           000096   316 _P3_MOD_OC	=	0x0096
                           000097   317 _P3_DIR_PU	=	0x0097
                           0000C0   318 _P4	=	0x00c0
                           0000C2   319 _P4_MOD_OC	=	0x00c2
                           0000C3   320 _P4_DIR_PU	=	0x00c3
                           0000C1   321 _P4_LED_KEY	=	0x00c1
                           0000AA   322 _P5_IN	=	0x00aa
                           0000AB   323 _P5_OUT_PU	=	0x00ab
                           0000AC   324 _P5_DIR	=	0x00ac
                           0000AD   325 _P6_IN	=	0x00ad
                           0000AE   326 _P6_OUT_PU	=	0x00ae
                           0000AF   327 _P6_DIR	=	0x00af
                           0000F1   328 _P7	=	0x00f1
                           0000A2   329 _XBUS_AUX	=	0x00a2
                           000088   330 _TCON	=	0x0088
                           000089   331 _TMOD	=	0x0089
                           00008A   332 _TL0	=	0x008a
                           00008B   333 _TL1	=	0x008b
                           00008C   334 _TH0	=	0x008c
                           00008D   335 _TH1	=	0x008d
                           000098   336 _SCON	=	0x0098
                           000099   337 _SBUF	=	0x0099
                           0000C8   338 _T2CON	=	0x00c8
                           0000C9   339 _T2MOD	=	0x00c9
                           00CBCA   340 _RCAP2	=	0xcbca
                           0000CA   341 _RCAP2L	=	0x00ca
                           0000CB   342 _RCAP2H	=	0x00cb
                           00CDCC   343 _T2COUNT	=	0xcdcc
                           0000CC   344 _TL2	=	0x00cc
                           0000CD   345 _TH2	=	0x00cd
                           00CFCE   346 _T2CAP1	=	0xcfce
                           0000CE   347 _T2CAP1L	=	0x00ce
                           0000CF   348 _T2CAP1H	=	0x00cf
                           0000F8   349 _SPI0_STAT	=	0x00f8
                           0000F9   350 _SPI0_DATA	=	0x00f9
                           0000FA   351 _SPI0_CTRL	=	0x00fa
                           0000FB   352 _SPI0_CK_SE	=	0x00fb
                           0000FC   353 _SPI0_SETUP	=	0x00fc
                           0000BC   354 _SCON1	=	0x00bc
                           0000BD   355 _SBUF1	=	0x00bd
                           0000BE   356 _SBAUD1	=	0x00be
                           0000BF   357 _SIF1	=	0x00bf
                           0000B4   358 _SPI1_STAT	=	0x00b4
                           0000B5   359 _SPI1_DATA	=	0x00b5
                           0000B6   360 _SPI1_CTRL	=	0x00b6
                           0000B7   361 _SPI1_CK_SE	=	0x00b7
                           0000F3   362 _ADC_CTRL	=	0x00f3
                           00F5F4   363 _ADC_DAT	=	0xf5f4
                           0000F4   364 _ADC_DAT_L	=	0x00f4
                           0000F5   365 _ADC_DAT_H	=	0x00f5
                           0000F6   366 _ADC_CHAN	=	0x00f6
                           0000A6   367 _LED_COMMON	=	0x00a6
                           0000A7   368 _LED_PWM_OE	=	0x00a7
                           00C7C6   369 _LED_DMA	=	0xc7c6
                           0000C6   370 _LED_DMA_L	=	0x00c6
                           0000C7   371 _LED_DMA_H	=	0x00c7
                           0000F7   372 _LED_STATUS	=	0x00f7
                           0000B3   373 _I2CX_INT	=	0x00b3
                           0000BB   374 _I2CS_INT_ST	=	0x00bb
                                    375 ;--------------------------------------------------------
                                    376 ; special function bits
                                    377 ;--------------------------------------------------------
                                    378 	.area RSEG    (ABS,DATA)
      000000                        379 	.org 0x0000
                           0000D7   380 _CY	=	0x00d7
                           0000D6   381 _AC	=	0x00d6
                           0000D5   382 _F0	=	0x00d5
                           0000D4   383 _RS1	=	0x00d4
                           0000D3   384 _RS0	=	0x00d3
                           0000D2   385 _OV	=	0x00d2
                           0000D1   386 _F1	=	0x00d1
                           0000D0   387 _P	=	0x00d0
                           0000AF   388 _EA	=	0x00af
                           0000AE   389 _E_DIS	=	0x00ae
                           0000AD   390 _ET2	=	0x00ad
                           0000AC   391 _ES	=	0x00ac
                           0000AB   392 _ET1	=	0x00ab
                           0000AA   393 _EX1	=	0x00aa
                           0000A9   394 _ET0	=	0x00a9
                           0000A8   395 _EX0	=	0x00a8
                           0000BF   396 _PH_FLAG	=	0x00bf
                           0000BE   397 _PL_FLAG	=	0x00be
                           0000BD   398 _PT2	=	0x00bd
                           0000BC   399 _PS	=	0x00bc
                           0000BB   400 _PT1	=	0x00bb
                           0000BA   401 _PX1	=	0x00ba
                           0000B9   402 _PT0	=	0x00b9
                           0000B8   403 _PX0	=	0x00b8
                           0000EF   404 _IE_WDOG	=	0x00ef
                           0000EE   405 _IE_GPIO	=	0x00ee
                           0000ED   406 _IE_PWM_I2C	=	0x00ed
                           0000EC   407 _IE_UART1	=	0x00ec
                           0000EB   408 _IE_ADC	=	0x00eb
                           0000E9   409 _IE_USB	=	0x00e9
                           0000E8   410 _IE_SPI0	=	0x00e8
                           000087   411 _P0_7	=	0x0087
                           000086   412 _P0_6	=	0x0086
                           000085   413 _P0_5	=	0x0085
                           000084   414 _P0_4	=	0x0084
                           000083   415 _P0_3	=	0x0083
                           000082   416 _P0_2	=	0x0082
                           000081   417 _P0_1	=	0x0081
                           000080   418 _P0_0	=	0x0080
                           000081   419 _SDA0	=	0x0081
                           000080   420 _SCL0	=	0x0080
                           000083   421 _TXD_	=	0x0083
                           000082   422 _RXD_	=	0x0082
                           000085   423 _AIN13	=	0x0085
                           000084   424 _AIN12	=	0x0084
                           000083   425 _AIN11	=	0x0083
                           000082   426 _AIN10	=	0x0082
                           000081   427 _AIN9	=	0x0081
                           000080   428 _AIN8	=	0x0080
                           000097   429 _P1_7	=	0x0097
                           000096   430 _P1_6	=	0x0096
                           000095   431 _P1_5	=	0x0095
                           000094   432 _P1_4	=	0x0094
                           000093   433 _P1_3	=	0x0093
                           000092   434 _P1_2	=	0x0092
                           000091   435 _P1_1	=	0x0091
                           000090   436 _P1_0	=	0x0090
                           000097   437 _TXD1_	=	0x0097
                           000096   438 _RXD1_	=	0x0096
                           000097   439 _SCK	=	0x0097
                           000096   440 _MISO	=	0x0096
                           000095   441 _MOSI	=	0x0095
                           000094   442 _SCS	=	0x0094
                           000092   443 _INT0_	=	0x0092
                           000091   444 _T2EX	=	0x0091
                           000091   445 _CAP2	=	0x0091
                           000090   446 _T2	=	0x0090
                           000090   447 _CAP1	=	0x0090
                           000097   448 _AIN7	=	0x0097
                           000096   449 _AIN6	=	0x0096
                           000095   450 _AIN5	=	0x0095
                           000094   451 _AIN4	=	0x0094
                           000093   452 _AIN3	=	0x0093
                           000092   453 _AIN2	=	0x0092
                           000091   454 _AIN1	=	0x0091
                           000090   455 _AIN0	=	0x0090
                           0000A7   456 _P2_7	=	0x00a7
                           0000A6   457 _P2_6	=	0x00a6
                           0000A5   458 _P2_5	=	0x00a5
                           0000A4   459 _P2_4	=	0x00a4
                           0000A3   460 _P2_3	=	0x00a3
                           0000A2   461 _P2_2	=	0x00a2
                           0000A1   462 _P2_1	=	0x00a1
                           0000A0   463 _P2_0	=	0x00a0
                           0000A7   464 _TXD1	=	0x00a7
                           0000A6   465 _RXD1	=	0x00a6
                           0000A5   466 _T2EX_	=	0x00a5
                           0000A5   467 _CAP2_	=	0x00a5
                           0000A4   468 _T2_	=	0x00a4
                           0000A4   469 _CAP1_	=	0x00a4
                           0000B7   470 _P3_7	=	0x00b7
                           0000B6   471 _P3_6	=	0x00b6
                           0000B5   472 _P3_5	=	0x00b5
                           0000B4   473 _P3_4	=	0x00b4
                           0000B3   474 _P3_3	=	0x00b3
                           0000B2   475 _P3_2	=	0x00b2
                           0000B1   476 _P3_1	=	0x00b1
                           0000B0   477 _P3_0	=	0x00b0
                           0000B7   478 _SCK1	=	0x00b7
                           0000B6   479 _MISO1	=	0x00b6
                           0000B5   480 _MOSI1	=	0x00b5
                           0000B5   481 _T1	=	0x00b5
                           0000B4   482 _T0	=	0x00b4
                           0000B3   483 _INT1	=	0x00b3
                           0000B2   484 _INT0	=	0x00b2
                           0000B1   485 _TXD	=	0x00b1
                           0000B0   486 _RXD	=	0x00b0
                           0000C6   487 _P4_6	=	0x00c6
                           0000C5   488 _P4_5	=	0x00c5
                           0000C4   489 _P4_4	=	0x00c4
                           0000C3   490 _P4_3	=	0x00c3
                           0000C2   491 _P4_2	=	0x00c2
                           0000C1   492 _P4_1	=	0x00c1
                           0000C0   493 _P4_0	=	0x00c0
                           00008F   494 _TF1	=	0x008f
                           00008E   495 _TR1	=	0x008e
                           00008D   496 _TF0	=	0x008d
                           00008C   497 _TR0	=	0x008c
                           00008B   498 _IE1	=	0x008b
                           00008A   499 _IT1	=	0x008a
                           000089   500 _IE0	=	0x0089
                           000088   501 _IT0	=	0x0088
                           00009F   502 _SM0	=	0x009f
                           00009E   503 _SM1	=	0x009e
                           00009D   504 _SM2	=	0x009d
                           00009C   505 _REN	=	0x009c
                           00009B   506 _TB8	=	0x009b
                           00009A   507 _RB8	=	0x009a
                           000099   508 _TI	=	0x0099
                           000098   509 _RI	=	0x0098
                           0000CF   510 _TF2	=	0x00cf
                           0000CF   511 _CAP1F	=	0x00cf
                           0000CE   512 _EXF2	=	0x00ce
                           0000CD   513 _RCLK	=	0x00cd
                           0000CC   514 _TCLK	=	0x00cc
                           0000CB   515 _EXEN2	=	0x00cb
                           0000CA   516 _TR2	=	0x00ca
                           0000C9   517 _C_T2	=	0x00c9
                           0000C8   518 _CP_RL2	=	0x00c8
                           0000FF   519 _S0_FST_ACT	=	0x00ff
                           0000FE   520 _S0_IF_OV	=	0x00fe
                           0000FD   521 _S0_IF_FIRST	=	0x00fd
                           0000FC   522 _S0_IF_BYTE	=	0x00fc
                           0000FB   523 _S0_FREE	=	0x00fb
                           0000FA   524 _S0_T_FIFO	=	0x00fa
                           0000F8   525 _S0_R_FIFO	=	0x00f8
                           0000F7   526 _ADC_START	=	0x00f7
                                    527 ;--------------------------------------------------------
                                    528 ; overlayable register banks
                                    529 ;--------------------------------------------------------
                                    530 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        531 	.ds 8
                                    532 ;--------------------------------------------------------
                                    533 ; internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area DSEG    (DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; overlayable items in internal ram
                                    538 ;--------------------------------------------------------
                                    539 ;--------------------------------------------------------
                                    540 ; indirectly addressable internal ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area ISEG    (DATA)
                                    543 ;--------------------------------------------------------
                                    544 ; absolute internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area IABS    (ABS,DATA)
                                    547 	.area IABS    (ABS,DATA)
                                    548 ;--------------------------------------------------------
                                    549 ; bit data
                                    550 ;--------------------------------------------------------
                                    551 	.area BSEG    (BIT)
      00000E                        552 _ak820_tapping_before_sloc0_1_0:
      00000E                        553 	.ds 1
                                    554 ;--------------------------------------------------------
                                    555 ; paged external ram data
                                    556 ;--------------------------------------------------------
                                    557 	.area PSEG    (PAG,XDATA)
                                    558 ;--------------------------------------------------------
                                    559 ; uninitialized external ram data
                                    560 ;--------------------------------------------------------
                                    561 	.area XSEG    (XDATA)
      00059E                        562 _source_state:
      00059E                        563 	.ds 130
      000620                        564 _pending_time:
      000620                        565 	.ds 2
      000622                        566 _pending_code:
      000622                        567 	.ds 2
      000624                        568 _ak820_tapping_source_PARM_1:
      000624                        569 	.ds 2
      000626                        570 _hold_PARM_2:
      000626                        571 	.ds 1
      000627                        572 _hold_code_10000_602:
      000627                        573 	.ds 2
      000629                        574 _hold_mods_30000_605:
      000629                        575 	.ds 1
      00062A                        576 _commit_pending_id_10000_611:
      00062A                        577 	.ds 1
      00062B                        578 _ak820_tapping_before_event_10000_612:
      00062B                        579 	.ds 2
      00062D                        580 _ak820_tapping_process_record_10000_623:
      00062D                        581 	.ds 2
      00062F                        582 _ak820_tapping_process_code_10000_624:
      00062F                        583 	.ds 2
      000631                        584 _ak820_tapping_process_sc_mods_10000_624:
      000631                        585 	.ds 1
      000632                        586 _ak820_oneshot_mods::
      000632                        587 	.ds 1
      000633                        588 _ak820_oneshot_consumed::
      000633                        589 	.ds 1
      000634                        590 _ak820_oneshot_process_PARM_2:
      000634                        591 	.ds 1
      000635                        592 _ak820_oneshot_process_PARM_3:
      000635                        593 	.ds 1
      000636                        594 _ak820_oneshot_process_code_10000_649:
      000636                        595 	.ds 2
      000638                        596 _ak820_oneshot_process_mods_10000_650:
      000638                        597 	.ds 1
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
      000DB0                        606 _pending:
      000DB0                        607 	.ds 1
      000DB1                        608 _ak820_oneshot_target::
      000DB1                        609 	.ds 1
                                    610 	.area HOME    (CODE)
                                    611 	.area GSINIT0 (CODE)
                                    612 	.area GSINIT1 (CODE)
                                    613 	.area GSINIT2 (CODE)
                                    614 	.area GSINIT3 (CODE)
                                    615 	.area GSINIT4 (CODE)
                                    616 	.area GSINIT5 (CODE)
                                    617 	.area GSINIT  (CODE)
                                    618 	.area GSFINAL (CODE)
                                    619 	.area CSEG    (CODE)
                                    620 ;--------------------------------------------------------
                                    621 ; global & static initialisations
                                    622 ;--------------------------------------------------------
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT  (CODE)
                                    625 	.area GSFINAL (CODE)
                                    626 	.area GSINIT  (CODE)
                                    627 ;--------------------------------------------------------
                                    628 ; Home
                                    629 ;--------------------------------------------------------
                                    630 	.area HOME    (CODE)
                                    631 	.area HOME    (CODE)
                                    632 ;--------------------------------------------------------
                                    633 ; code
                                    634 ;--------------------------------------------------------
                                    635 	.area CSEG    (CODE)
                                    636 ;------------------------------------------------------------
                                    637 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    638 ;------------------------------------------------------------
                                    639 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    640 ;------------------------------------------------------------
                                    641 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    642 ;	-----------------------------------------
                           000007   643 	ar7 = 0x07
                           000006   644 	ar6 = 0x06
                           000005   645 	ar5 = 0x05
                           000004   646 	ar4 = 0x04
                           000003   647 	ar3 = 0x03
                           000002   648 	ar2 = 0x02
                           000001   649 	ar1 = 0x01
                           000000   650 	ar0 = 0x00
                                    651 ;	 function ak820_tapping_source
                                    652 ;	-----------------------------------------
      0043EC                        653 _ak820_tapping_source:
                                    654 ;	keyboards/ajazz/ak820/ak820_tapping.c:34: if (key.row < MATRIX_ROWS && key.col < MATRIX_COLS) return key.row * MATRIX_COLS + key.col;
      0043EC 90 06 25         [24]  655 	mov	dptr,#(_ak820_tapping_source_PARM_1 + 0x0001)
      0043EF E0               [24]  656 	movx	a,@dptr
      0043F0 FF               [12]  657 	mov	r7,a
      0043F1 BF 10 00         [24]  658 	cjne	r7,#0x10,00147$
      0043F4                        659 00147$:
      0043F4 50 14            [24]  660 	jnc	00102$
      0043F6 90 06 24         [24]  661 	mov	dptr,#_ak820_tapping_source_PARM_1
      0043F9 E0               [24]  662 	movx	a,@dptr
      0043FA FE               [12]  663 	mov	r6,a
      0043FB BE 08 00         [24]  664 	cjne	r6,#0x08,00149$
      0043FE                        665 00149$:
      0043FE 50 0A            [24]  666 	jnc	00102$
      004400 8F 05            [24]  667 	mov	ar5,r7
      004402 ED               [12]  668 	mov	a,r5
      004403 12 38 C6         [24]  669 	lcall	_ak820_outline_0190
      004406 2E               [12]  670 	add	a,r6
      004407 F5 82            [12]  671 	mov	dpl,a
      004409 22               [24]  672 	ret
      00440A                        673 00102$:
                                    674 ;	keyboards/ajazz/ak820/ak820_tapping.c:35: if (key.col < NUM_ENCODERS) {
      00440A 90 06 24         [24]  675 	mov	dptr,#_ak820_tapping_source_PARM_1
      00440D E0               [24]  676 	movx	a,@dptr
      00440E FE               [12]  677 	mov	r6,a
      00440F BE 01 00         [24]  678 	cjne	r6,#0x01,00151$
      004412                        679 00151$:
      004412 50 0E            [24]  680 	jnc	00109$
                                    681 ;	keyboards/ajazz/ak820/ak820_tapping.c:36: if (key.row == KEYLOC_ENCODER_CW) return MATRIX_ROWS * MATRIX_COLS + key.col;
      004414 BF FD 04         [24]  682 	cjne	r7,#0xfd,00105$
      004417 75 82 80         [24]  683 	mov	dpl, #0x80
      00441A 22               [24]  684 	ret
      00441B                        685 00105$:
                                    686 ;	keyboards/ajazz/ak820/ak820_tapping.c:37: if (key.row == KEYLOC_ENCODER_CCW) return MATRIX_ROWS * MATRIX_COLS + NUM_ENCODERS + key.col;
      00441B BF FC 04         [24]  687 	cjne	r7,#0xfc,00109$
      00441E 75 82 81         [24]  688 	mov	dpl, #0x81
      004421 22               [24]  689 	ret
      004422                        690 00109$:
                                    691 ;	keyboards/ajazz/ak820/ak820_tapping.c:39: return NONE;
      004422 75 82 FF         [24]  692 	mov	dpl, #0xff
                                    693 ;	keyboards/ajazz/ak820/ak820_tapping.c:40: }
      004425 22               [24]  694 	ret
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'hold'
                                    697 ;------------------------------------------------------------
                                    698 ;pressed       Allocated with name '_hold_PARM_2'
                                    699 ;code          Allocated with name '_hold_code_10000_602'
                                    700 ;mods          Allocated with name '_hold_mods_30000_605'
                                    701 ;layer         Allocated with name '_hold_layer_30000_608'
                                    702 ;------------------------------------------------------------
                                    703 ;	keyboards/ajazz/ak820/ak820_tapping.c:41: static void hold(uint16_t code, bool pressed) {
                                    704 ;	-----------------------------------------
                                    705 ;	 function hold
                                    706 ;	-----------------------------------------
      004426                        707 _hold:
      004426 12 38 82         [24]  708 	lcall	_ak820_outline_0107
      004429 90 06 27         [24]  709 	mov	dptr,#_hold_code_10000_602
      00442C 12 38 87         [24]  710 	lcall	_ak820_outline_0108
                                    711 ;	keyboards/ajazz/ak820/ak820_tapping.c:42: if (code < QK_LAYER_TAP) {
      00442F 90 06 27         [24]  712 	mov	dptr,#_hold_code_10000_602
      004432 12 48 A3         [24]  713 	lcall	_ak820_outline_0008
      004435 74 C0            [12]  714 	mov	a,#0x100 - 0x40
      004437 2D               [12]  715 	add	a,r5
      004438 40 2E            [24]  716 	jc	00110$
                                    717 ;	keyboards/ajazz/ak820/ak820_tapping.c:43: uint8_t mods = (code >> 8) & 31;
      00443A 8F 05            [24]  718 	mov	ar5,r7
      00443C 53 05 1F         [24]  719 	anl	ar5,#0x1f
      00443F 90 06 29         [24]  720 	mov	dptr,#_hold_mods_30000_605
      004442 ED               [12]  721 	mov	a,r5
      004443 F0               [24]  722 	movx	@dptr,a
                                    723 ;	keyboards/ajazz/ak820/ak820_tapping.c:44: if (mods & 16) mods <<= 4;
      004444 ED               [12]  724 	mov	a,r5
      004445 30 E4 08         [24]  725 	jnb	acc.4,00102$
      004448 ED               [12]  726 	mov	a,r5
      004449 C4               [12]  727 	swap	a
      00444A 54 F0            [12]  728 	anl	a,#0xf0
      00444C 90 06 29         [24]  729 	mov	dptr,#_hold_mods_30000_605
      00444F F0               [24]  730 	movx	@dptr,a
      004450                        731 00102$:
                                    732 ;	keyboards/ajazz/ak820/ak820_tapping.c:45: if (pressed) register_mods(mods);
      004450 90 06 26         [24]  733 	mov	dptr,#_hold_PARM_2
      004453 E0               [24]  734 	movx	a,@dptr
      004454 60 09            [24]  735 	jz	00104$
      004456 90 06 29         [24]  736 	mov	dptr,#_hold_mods_30000_605
      004459 E0               [24]  737 	movx	a,@dptr
      00445A F5 82            [12]  738 	mov	dpl,a
      00445C 02 76 76         [24]  739 	ljmp	_register_mods
      00445F                        740 00104$:
                                    741 ;	keyboards/ajazz/ak820/ak820_tapping.c:46: else unregister_mods(mods);
      00445F 90 06 29         [24]  742 	mov	dptr,#_hold_mods_30000_605
      004462 E0               [24]  743 	movx	a,@dptr
      004463 F5 82            [12]  744 	mov	dpl,a
      004465 02 76 8A         [24]  745 	ljmp	_unregister_mods
      004468                        746 00110$:
                                    747 ;	keyboards/ajazz/ak820/ak820_tapping.c:48: uint8_t layer = (code >> 8) & 15;
      004468 8F 06            [24]  748 	mov	ar6,r7
      00446A 74 0F            [12]  749 	mov	a,#0x0f
      00446C 5E               [12]  750 	anl	a,r6
      00446D FF               [12]  751 	mov	r7,a
                                    752 ;	keyboards/ajazz/ak820/ak820_tapping.c:49: if (pressed) layer_hold_on(layer);
      00446E 90 06 26         [24]  753 	mov	dptr,#_hold_PARM_2
      004471 E0               [24]  754 	movx	a,@dptr
      004472 60 05            [24]  755 	jz	00107$
      004474 8F 82            [24]  756 	mov	dpl, r7
      004476 02 78 5F         [24]  757 	ljmp	_layer_hold_on
      004479                        758 00107$:
                                    759 ;	keyboards/ajazz/ak820/ak820_tapping.c:50: else layer_hold_off(layer);
      004479 8F 82            [24]  760 	mov	dpl, r7
                                    761 ;	keyboards/ajazz/ak820/ak820_tapping.c:52: }
      00447B 02 78 97         [24]  762 	ljmp	_layer_hold_off
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'commit_pending'
                                    765 ;------------------------------------------------------------
                                    766 ;id            Allocated with name '_commit_pending_id_10000_611'
                                    767 ;------------------------------------------------------------
                                    768 ;	keyboards/ajazz/ak820/ak820_tapping.c:53: static void commit_pending(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function commit_pending
                                    771 ;	-----------------------------------------
      00447E                        772 _commit_pending:
                                    773 ;	keyboards/ajazz/ak820/ak820_tapping.c:54: uint8_t id = pending;
      00447E 90 0D B0         [24]  774 	mov	dptr,#_pending
      004481 E0               [24]  775 	movx	a,@dptr
      004482 90 06 2A         [24]  776 	mov	dptr,#_commit_pending_id_10000_611
      004485 F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_tapping.c:55: pending = NONE; /* A report callback cannot resurrect the decision. */
      004486 12 49 36         [24]  779 	lcall	_ak820_outline_0154
                                    780 ;	keyboards/ajazz/ak820/ak820_tapping.c:56: source_state[id] |= SOURCE_HELD;
      004489 90 06 2A         [24]  781 	mov	dptr,#_commit_pending_id_10000_611
      00448C E0               [24]  782 	movx	a,@dptr
      00448D 24 9E            [12]  783 	add	a,#_source_state
      00448F FF               [12]  784 	mov	r7,a
      004490 E4               [12]  785 	clr	a
      004491 34 05            [12]  786 	addc	a, #(_source_state >> 8)
      004493 FE               [12]  787 	mov	r6,a
      004494 12 43 D1         [24]  788 	lcall	_ak820_outline_0158
      004497 E0               [24]  789 	movx	a,@dptr
      004498 FD               [12]  790 	mov	r5,a
      004499 43 05 04         [24]  791 	orl	ar5,#0x04
      00449C 12 43 D1         [24]  792 	lcall	_ak820_outline_0158
      00449F ED               [12]  793 	mov	a,r5
      0044A0 F0               [24]  794 	movx	@dptr,a
                                    795 ;	keyboards/ajazz/ak820/ak820_tapping.c:57: hold(pending_code, true);
      0044A1 90 06 22         [24]  796 	mov	dptr,#_pending_code
      0044A4 12 38 41         [24]  797 	lcall	_ak820_outline_0051
      0044A7 90 06 26         [24]  798 	mov	dptr,#_hold_PARM_2
      0044AA 74 01            [12]  799 	mov	a,#0x01
      0044AC 12 43 9D         [24]  800 	lcall	_ak820_outline_0071
                                    801 ;	keyboards/ajazz/ak820/ak820_tapping.c:58: }
      0044AF 02 44 26         [24]  802 	ljmp	_hold
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'ak820_tapping_before'
                                    805 ;------------------------------------------------------------
                                    806 ;event         Allocated with name '_ak820_tapping_before_event_10000_612'
                                    807 ;id            Allocated with name '_ak820_tapping_before_id_10000_613'
                                    808 ;------------------------------------------------------------
                                    809 ;	keyboards/ajazz/ak820/ak820_tapping.c:59: bool ak820_tapping_before(const keyevent_t AK820_STATE_MEM *event) {
                                    810 ;	-----------------------------------------
                                    811 ;	 function ak820_tapping_before
                                    812 ;	-----------------------------------------
      0044B2                        813 _ak820_tapping_before:
      0044B2 12 38 82         [24]  814 	lcall	_ak820_outline_0107
      0044B5 90 06 2B         [24]  815 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0044B8 12 38 87         [24]  816 	lcall	_ak820_outline_0108
                                    817 ;	keyboards/ajazz/ak820/ak820_tapping.c:60: uint8_t id = ak820_tapping_source(event->key);
      0044BB 90 06 2B         [24]  818 	mov	dptr,#_ak820_tapping_before_event_10000_612
      0044BE 12 48 A3         [24]  819 	lcall	_ak820_outline_0008
      0044C1 12 48 C8         [24]  820 	lcall	_ak820_outline_0024
      0044C4 C0 07            [24]  821 	push	ar7
      0044C6 C0 06            [24]  822 	push	ar6
      0044C8 12 B8 F6         [24]  823 	lcall	___memcpy
      0044CB 12 43 EC         [24]  824 	lcall	_ak820_tapping_source
      0044CE AD 82            [24]  825 	mov	r5, dpl
      0044D0 D0 06            [24]  826 	pop	ar6
      0044D2 D0 07            [24]  827 	pop	ar7
                                    828 ;	keyboards/ajazz/ak820/ak820_tapping.c:62: if (vial_unlock_in_progress) {
      0044D4 90 0E 21         [24]  829 	mov	dptr,#_vial_unlock_in_progress
      0044D7 E0               [24]  830 	movx	a,@dptr
      0044D8 60 26            [24]  831 	jz	00106$
                                    832 ;	keyboards/ajazz/ak820/ak820_tapping.c:63: if (IS_EVENT(*event) && id != NONE && !event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      0044DA 12 49 22         [24]  833 	lcall	_ak820_outline_0097
      0044DD 60 1D            [24]  834 	jz	00102$
      0044DF BD FF 02         [24]  835 	cjne	r5,#0xff,00218$
      0044E2 80 18            [24]  836 	sjmp	00102$
      0044E4                        837 00218$:
      0044E4 12 48 AD         [24]  838 	lcall	_ak820_outline_0015
      0044E7 E0               [24]  839 	movx	a,@dptr
      0044E8 70 12            [24]  840 	jnz	00102$
      0044EA ED               [12]  841 	mov	a,r5
      0044EB 24 9E            [12]  842 	add	a, #_source_state
      0044ED FB               [12]  843 	mov	r3,a
      0044EE E4               [12]  844 	clr	a
      0044EF 34 05            [12]  845 	addc	a, #(_source_state >> 8)
      0044F1 12 48 F8         [24]  846 	lcall	_ak820_outline_0055
      0044F4 53 02 FD         [24]  847 	anl	ar2,#0xfd
      0044F7 12 33 FC         [24]  848 	lcall	_ak820_outline_0123
      0044FA EA               [12]  849 	mov	a,r2
      0044FB F0               [24]  850 	movx	@dptr,a
      0044FC                        851 00102$:
                                    852 ;	keyboards/ajazz/ak820/ak820_tapping.c:64: return false;
      0044FC 75 82 00         [24]  853 	mov	dpl, #0x00
      0044FF 22               [24]  854 	ret
      004500                        855 00106$:
                                    856 ;	keyboards/ajazz/ak820/ak820_tapping.c:67: if (pending != NONE && ((uint16_t)(event->time - pending_time) >= 200 ||
      004500 90 0D B0         [24]  857 	mov	dptr,#_pending
      004503 E0               [24]  858 	movx	a,@dptr
      004504 FC               [12]  859 	mov	r4,a
      004505 BC FF 02         [24]  860 	cjne	r4,#0xff,00220$
      004508 80 3B            [24]  861 	sjmp	00108$
      00450A                        862 00220$:
      00450A 12 38 39         [24]  863 	lcall	_ak820_outline_0036
      00450D FA               [12]  864 	mov	r2,a
      00450E A3               [24]  865 	inc	dptr
      00450F E0               [24]  866 	movx	a,@dptr
      004510 FB               [12]  867 	mov	r3,a
      004511 90 06 20         [24]  868 	mov	dptr,#_pending_time
      004514 12 38 7C         [24]  869 	lcall	_ak820_outline_0102
      004517 EA               [12]  870 	mov	a,r2
      004518 C3               [12]  871 	clr	c
      004519 98               [12]  872 	subb	a,r0
      00451A FA               [12]  873 	mov	r2,a
      00451B EB               [12]  874 	mov	a,r3
      00451C 99               [12]  875 	subb	a,r1
      00451D FB               [12]  876 	mov	r3,a
      00451E C3               [12]  877 	clr	c
      00451F EA               [12]  878 	mov	a,r2
      004520 94 C8            [12]  879 	subb	a,#0xc8
      004522 EB               [12]  880 	mov	a,r3
      004523 94 00            [12]  881 	subb	a,#0x00
      004525 50 17            [24]  882 	jnc	00107$
                                    883 ;	keyboards/ajazz/ak820/ak820_tapping.c:68: (IS_EVENT(*event) && event->pressed && (id == NONE || id != pending)))) commit_pending();
      004527 74 04            [12]  884 	mov	a,#0x04
      004529 12 48 E2         [24]  885 	lcall	_ak820_outline_0032
      00452C 60 17            [24]  886 	jz	00108$
      00452E 12 38 12         [24]  887 	lcall	_ak820_outline_0009
      004531 60 12            [24]  888 	jz	00108$
      004533 BD FF 02         [24]  889 	cjne	r5,#0xff,00224$
      004536 80 06            [24]  890 	sjmp	00107$
      004538                        891 00224$:
      004538 ED               [12]  892 	mov	a,r5
      004539 B5 04 02         [24]  893 	cjne	a,ar4,00225$
      00453C 80 07            [24]  894 	sjmp	00108$
      00453E                        895 00225$:
      00453E                        896 00107$:
      00453E C0 05            [24]  897 	push	ar5
      004540 12 44 7E         [24]  898 	lcall	_commit_pending
      004543 D0 05            [24]  899 	pop	ar5
      004545                        900 00108$:
                                    901 ;	keyboards/ajazz/ak820/ak820_tapping.c:69: if (IS_NOEVENT(*event) || id == NONE) return true;
      004545 90 06 2B         [24]  902 	mov	dptr,#_ak820_tapping_before_event_10000_612
      004548 12 38 41         [24]  903 	lcall	_ak820_outline_0051
      00454B 12 49 22         [24]  904 	lcall	_ak820_outline_0097
      00454E 60 03            [24]  905 	jz	00114$
      004550 BD FF 04         [24]  906 	cjne	r5,#0xff,00115$
      004553                        907 00114$:
      004553 75 82 01         [24]  908 	mov	dpl, #0x01
      004556 22               [24]  909 	ret
      004557                        910 00115$:
                                    911 ;	keyboards/ajazz/ak820/ak820_tapping.c:70: if ((source_state[id] & SOURCE_BLOCKED)) {
      004557 ED               [12]  912 	mov	a,r5
      004558 12 49 14         [24]  913 	lcall	_ak820_outline_0080
      00455B 30 E1 13         [24]  914 	jnb	acc.1,00120$
                                    915 ;	keyboards/ajazz/ak820/ak820_tapping.c:71: if (!event->pressed) source_state[id] &= ~SOURCE_BLOCKED;
      00455E 74 05            [12]  916 	mov	a,#0x05
      004560 2E               [12]  917 	add	a, r6
      004561 12 38 1F         [24]  918 	lcall	_ak820_outline_0016
      004564 70 07            [24]  919 	jnz	00118$
      004566 74 FD            [12]  920 	mov	a,#0xfd
      004568 5B               [12]  921 	anl	a,r3
      004569 12 38 97         [24]  922 	lcall	_ak820_outline_0124
      00456C F0               [24]  923 	movx	@dptr,a
      00456D                        924 00118$:
                                    925 ;	keyboards/ajazz/ak820/ak820_tapping.c:72: return false;
      00456D 75 82 00         [24]  926 	mov	dpl, #0x00
      004570 22               [24]  927 	ret
      004571                        928 00120$:
                                    929 ;	keyboards/ajazz/ak820/ak820_tapping.c:75: if (event->pressed == ((source_state[id] & SOURCE_ACTIVE) != 0)) return false;
      004571 12 43 60         [24]  930 	lcall	_ak820_outline_0011
      004574 E0               [24]  931 	movx	a,@dptr
      004575 FF               [12]  932 	mov	r7,a
      004576 8B 06            [24]  933 	mov	ar6,r3
      004578 53 06 01         [24]  934 	anl	ar6,#0x01
      00457B EE               [12]  935 	mov	a,r6
      00457C B4 01 00         [24]  936 	cjne	a,#0x01,00231$
      00457F                        937 00231$:
      00457F B3               [12]  938 	cpl	c
      004580 92 0E            [24]  939 	mov	_ak820_tapping_before_sloc0_1_0,c
      004582 8F F0            [24]  940 	mov	b,r7
      004584 E4               [12]  941 	clr	a
      004585 33               [12]  942 	rlc	a
      004586 B5 F0 04         [24]  943 	cjne	a,b,00122$
      004589 75 82 00         [24]  944 	mov	dpl, #0x00
      00458C 22               [24]  945 	ret
      00458D                        946 00122$:
                                    947 ;	keyboards/ajazz/ak820/ak820_tapping.c:76: source_state[id] ^= SOURCE_ACTIVE;
      00458D 63 03 01         [24]  948 	xrl	ar3,#0x01
      004590 12 38 97         [24]  949 	lcall	_ak820_outline_0124
      004593 EB               [12]  950 	mov	a,r3
      004594 F0               [24]  951 	movx	@dptr,a
                                    952 ;	keyboards/ajazz/ak820/ak820_tapping.c:77: return true;
      004595 75 82 01         [24]  953 	mov	dpl, #0x01
                                    954 ;	keyboards/ajazz/ak820/ak820_tapping.c:78: }
      004598 22               [24]  955 	ret
                                    956 ;------------------------------------------------------------
                                    957 ;Allocation info for local variables in function 'ak820_tapping_process'
                                    958 ;------------------------------------------------------------
                                    959 ;record        Allocated with name '_ak820_tapping_process_record_10000_623'
                                    960 ;id            Allocated with name '_ak820_tapping_process_id_10000_624'
                                    961 ;kind          Allocated with name '_ak820_tapping_process_kind_10000_624'
                                    962 ;code          Allocated with name '_ak820_tapping_process_code_10000_624'
                                    963 ;sc_mods       Allocated with name '_ak820_tapping_process_sc_mods_10000_624'
                                    964 ;------------------------------------------------------------
                                    965 ;	keyboards/ajazz/ak820/ak820_tapping.c:79: bool ak820_tapping_process(keyrecord_t AK820_STATE_MEM *record) {
                                    966 ;	-----------------------------------------
                                    967 ;	 function ak820_tapping_process
                                    968 ;	-----------------------------------------
      004599                        969 _ak820_tapping_process:
      004599 12 38 82         [24]  970 	lcall	_ak820_outline_0107
      00459C 90 06 2D         [24]  971 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00459F 12 38 87         [24]  972 	lcall	_ak820_outline_0108
                                    973 ;	keyboards/ajazz/ak820/ak820_tapping.c:83: uint8_t sc_mods = 0;
      0045A2 90 06 31         [24]  974 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0045A5 E4               [12]  975 	clr	a
      0045A6 F0               [24]  976 	movx	@dptr,a
                                    977 ;	keyboards/ajazz/ak820/ak820_tapping.c:85: if (IS_NOEVENT(record->event)) return true;
      0045A7 90 06 2D         [24]  978 	mov	dptr,#_ak820_tapping_process_record_10000_623
      0045AA 12 38 41         [24]  979 	lcall	_ak820_outline_0051
      0045AD 74 04            [12]  980 	mov	a,#0x04
      0045AF 12 48 ED         [24]  981 	lcall	_ak820_outline_0033
      0045B2 70 04            [24]  982 	jnz	00102$
      0045B4 75 82 01         [24]  983 	mov	dpl, #0x01
      0045B7 22               [24]  984 	ret
      0045B8                        985 00102$:
                                    986 ;	keyboards/ajazz/ak820/ak820_tapping.c:86: id = ak820_tapping_source(record->event.key);
      0045B8 8E 04            [24]  987 	mov	ar4,r6
      0045BA 8F 05            [24]  988 	mov	ar5,r7
      0045BC 12 48 C8         [24]  989 	lcall	_ak820_outline_0024
      0045BF C0 07            [24]  990 	push	ar7
      0045C1 C0 06            [24]  991 	push	ar6
      0045C3 12 B8 F6         [24]  992 	lcall	___memcpy
      0045C6 12 43 EC         [24]  993 	lcall	_ak820_tapping_source
      0045C9 AD 82            [24]  994 	mov	r5, dpl
      0045CB D0 06            [24]  995 	pop	ar6
      0045CD D0 07            [24]  996 	pop	ar7
                                    997 ;	keyboards/ajazz/ak820/ak820_tapping.c:87: if (id == NONE) return true;
      0045CF BD FF 04         [24]  998 	cjne	r5,#0xff,00104$
      0045D2 75 82 01         [24]  999 	mov	dpl, #0x01
      0045D5 22               [24] 1000 	ret
      0045D6                       1001 00104$:
                                   1002 ;	keyboards/ajazz/ak820/ak820_tapping.c:88: code = record->keycode;
      0045D6 74 07            [12] 1003 	mov	a,#0x07
      0045D8 12 38 31         [24] 1004 	lcall	_ak820_outline_0022
      0045DB 12 38 41         [24] 1005 	lcall	_ak820_outline_0051
      0045DE 90 06 2F         [24] 1006 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0045E1 12 49 00         [24] 1007 	lcall	_ak820_outline_0058
                                   1008 ;	keyboards/ajazz/ak820/ak820_tapping.c:90: if (code == SC_LSPO) { code = MT(MOD_LSFT, KC_9); sc_mods = MOD_BIT(KC_LEFT_SHIFT); }
      0045E4 BE 1A 15         [24] 1009 	cjne	r6,#0x1a,00111$
      0045E7 BF 7C 12         [24] 1010 	cjne	r7,#0x7c,00111$
      0045EA 90 06 2F         [24] 1011 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0045ED 74 26            [12] 1012 	mov	a,#0x26
      0045EF F0               [24] 1013 	movx	@dptr,a
      0045F0 74 22            [12] 1014 	mov	a,#0x22
      0045F2 A3               [24] 1015 	inc	dptr
      0045F3 F0               [24] 1016 	movx	@dptr,a
      0045F4 90 06 31         [24] 1017 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0045F7 74 02            [12] 1018 	mov	a,#0x02
      0045F9 F0               [24] 1019 	movx	@dptr,a
      0045FA 80 28            [24] 1020 	sjmp	00112$
      0045FC                       1021 00111$:
                                   1022 ;	keyboards/ajazz/ak820/ak820_tapping.c:91: else if (code == SC_RSPC) { code = MT(MOD_RSFT, KC_0); sc_mods = MOD_BIT(KC_RIGHT_SHIFT); }
      0045FC BE 1B 15         [24] 1023 	cjne	r6,#0x1b,00108$
      0045FF BF 7C 12         [24] 1024 	cjne	r7,#0x7c,00108$
      004602 90 06 2F         [24] 1025 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004605 74 27            [12] 1026 	mov	a,#0x27
      004607 F0               [24] 1027 	movx	@dptr,a
      004608 74 32            [12] 1028 	mov	a,#0x32
      00460A A3               [24] 1029 	inc	dptr
      00460B F0               [24] 1030 	movx	@dptr,a
      00460C 90 06 31         [24] 1031 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      00460F 74 20            [12] 1032 	mov	a,#0x20
      004611 F0               [24] 1033 	movx	@dptr,a
      004612 80 10            [24] 1034 	sjmp	00112$
      004614                       1035 00108$:
                                   1036 ;	keyboards/ajazz/ak820/ak820_tapping.c:92: else if (code == SC_SENT) code = MT(MOD_RSFT, KC_ENTER);
      004614 BE 1E 0D         [24] 1037 	cjne	r6,#0x1e,00112$
      004617 BF 7C 0A         [24] 1038 	cjne	r7,#0x7c,00112$
      00461A 90 06 2F         [24] 1039 	mov	dptr,#_ak820_tapping_process_code_10000_624
      00461D 74 28            [12] 1040 	mov	a,#0x28
      00461F F0               [24] 1041 	movx	@dptr,a
      004620 74 32            [12] 1042 	mov	a,#0x32
      004622 A3               [24] 1043 	inc	dptr
      004623 F0               [24] 1044 	movx	@dptr,a
      004624                       1045 00112$:
                                   1046 ;	keyboards/ajazz/ak820/ak820_tapping.c:94: kind = code >> 8;
      004624 90 06 2F         [24] 1047 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004627 E0               [24] 1048 	movx	a,@dptr
      004628 A3               [24] 1049 	inc	dptr
      004629 E0               [24] 1050 	movx	a,@dptr
      00462A FF               [12] 1051 	mov	r7,a
                                   1052 ;	keyboards/ajazz/ak820/ak820_tapping.c:95: if (kind < 0x20 || kind >= 0x50) return true;
      00462B BF 20 00         [24] 1053 	cjne	r7,#0x20,00242$
      00462E                       1054 00242$:
      00462E 40 05            [24] 1055 	jc	00113$
      004630 BF 50 00         [24] 1056 	cjne	r7,#0x50,00244$
      004633                       1057 00244$:
      004633 40 04            [24] 1058 	jc	00114$
      004635                       1059 00113$:
      004635 75 82 01         [24] 1060 	mov	dpl, #0x01
      004638 22               [24] 1061 	ret
      004639                       1062 00114$:
                                   1063 ;	keyboards/ajazz/ak820/ak820_tapping.c:96: if (kind >= 0x40 && (kind & 15) >= MAX_LAYER) return false;
      004639 BF 40 00         [24] 1064 	cjne	r7,#0x40,00246$
      00463C                       1065 00246$:
      00463C 40 0C            [24] 1066 	jc	00117$
      00463E 53 07 0F         [24] 1067 	anl	ar7,#0x0f
      004641 BF 06 00         [24] 1068 	cjne	r7,#0x06,00248$
      004644                       1069 00248$:
      004644 40 04            [24] 1070 	jc	00117$
      004646 75 82 00         [24] 1071 	mov	dpl, #0x00
      004649 22               [24] 1072 	ret
      00464A                       1073 00117$:
                                   1074 ;	keyboards/ajazz/ak820/ak820_tapping.c:97: if (record->event.pressed) {
      00464A 90 06 2D         [24] 1075 	mov	dptr,#_ak820_tapping_process_record_10000_623
      00464D 12 38 41         [24] 1076 	lcall	_ak820_outline_0051
      004650 12 48 AD         [24] 1077 	lcall	_ak820_outline_0015
      004653 E0               [24] 1078 	movx	a,@dptr
      004654 60 1F            [24] 1079 	jz	00131$
                                   1080 ;	keyboards/ajazz/ak820/ak820_tapping.c:98: pending = id;
      004656 90 0D B0         [24] 1081 	mov	dptr,#_pending
      004659 ED               [12] 1082 	mov	a,r5
      00465A 12 43 6A         [24] 1083 	lcall	_ak820_outline_0031
                                   1084 ;	keyboards/ajazz/ak820/ak820_tapping.c:99: pending_time = record->event.time;
      00465D 12 38 41         [24] 1085 	lcall	_ak820_outline_0051
      004660 90 06 20         [24] 1086 	mov	dptr,#_pending_time
      004663 12 49 00         [24] 1087 	lcall	_ak820_outline_0058
                                   1088 ;	keyboards/ajazz/ak820/ak820_tapping.c:100: pending_code = code;
      004666 90 06 2F         [24] 1089 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004669 12 38 41         [24] 1090 	lcall	_ak820_outline_0051
      00466C 90 06 22         [24] 1091 	mov	dptr,#_pending_code
      00466F 12 49 00         [24] 1092 	lcall	_ak820_outline_0058
      004672 02 47 26         [24] 1093 	ljmp	00132$
      004675                       1094 00131$:
                                   1095 ;	keyboards/ajazz/ak820/ak820_tapping.c:101: } else if (id == pending) {
      004675 90 0D B0         [24] 1096 	mov	dptr,#_pending
      004678 E0               [24] 1097 	movx	a,@dptr
      004679 FF               [12] 1098 	mov	r7,a
      00467A ED               [12] 1099 	mov	a,r5
      00467B B5 07 02         [24] 1100 	cjne	a,ar7,00251$
      00467E 80 03            [24] 1101 	sjmp	00252$
      004680                       1102 00251$:
      004680 02 46 FE         [24] 1103 	ljmp	00128$
      004683                       1104 00252$:
                                   1105 ;	keyboards/ajazz/ak820/ak820_tapping.c:102: pending = NONE;
      004683 12 49 36         [24] 1106 	lcall	_ak820_outline_0154
                                   1107 ;	keyboards/ajazz/ak820/ak820_tapping.c:104: if (sc_mods) add_owned_mods(sc_mods);
      004686 90 06 31         [24] 1108 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      004689 E0               [24] 1109 	movx	a,@dptr
      00468A FF               [12] 1110 	mov	r7,a
      00468B E0               [24] 1111 	movx	a,@dptr
      00468C 60 05            [24] 1112 	jz	00120$
      00468E 8F 82            [24] 1113 	mov	dpl, r7
      004690 12 7D 35         [24] 1114 	lcall	_add_owned_mods
      004693                       1115 00120$:
                                   1116 ;	keyboards/ajazz/ak820/ak820_tapping.c:108: record->keycode = (uint8_t)code;
      004693 90 06 2D         [24] 1117 	mov	dptr,#_ak820_tapping_process_record_10000_623
      004696 12 38 41         [24] 1118 	lcall	_ak820_outline_0051
      004699 74 07            [12] 1119 	mov	a,#0x07
      00469B 2E               [12] 1120 	add	a, r6
      00469C FB               [12] 1121 	mov	r3,a
      00469D E4               [12] 1122 	clr	a
      00469E 3F               [12] 1123 	addc	a, r7
      00469F FC               [12] 1124 	mov	r4,a
      0046A0 90 06 2F         [24] 1125 	mov	dptr,#_ak820_tapping_process_code_10000_624
      0046A3 E0               [24] 1126 	movx	a,@dptr
      0046A4 F9               [12] 1127 	mov	r1,a
      0046A5 7A 00            [12] 1128 	mov	r2,#0x00
      0046A7 12 33 FC         [24] 1129 	lcall	_ak820_outline_0123
      0046AA E9               [12] 1130 	mov	a,r1
      0046AB F0               [24] 1131 	movx	@dptr,a
      0046AC EA               [12] 1132 	mov	a,r2
      0046AD A3               [24] 1133 	inc	dptr
      0046AE F0               [24] 1134 	movx	@dptr,a
                                   1135 ;	keyboards/ajazz/ak820/ak820_tapping.c:109: if (record->keycode > KC_TRANSPARENT) {
      0046AF C3               [12] 1136 	clr	c
      0046B0 04               [12] 1137 	inc	a
      0046B1 99               [12] 1138 	subb	a,r1
      0046B2 50 38            [24] 1139 	jnc	00122$
                                   1140 ;	free result
                                   1141 ;	keyboards/ajazz/ak820/ak820_tapping.c:110: record->tap.count = 1;
      0046B4 74 06            [12] 1142 	mov	a,#0x06
      0046B6 12 38 31         [24] 1143 	lcall	_ak820_outline_0022
      0046B9 E0               [24] 1144 	movx	a,@dptr
      0046BA 54 0F            [12] 1145 	anl	a,#0x0f
      0046BC 44 10            [12] 1146 	orl	a,#0x10
      0046BE F0               [24] 1147 	movx	@dptr,a
                                   1148 ;	keyboards/ajazz/ak820/ak820_tapping.c:111: record->event.pressed = true;
      0046BF 12 48 AD         [24] 1149 	lcall	_ak820_outline_0015
      0046C2 74 01            [12] 1150 	mov	a,#0x01
      0046C4 F0               [24] 1151 	movx	@dptr,a
                                   1152 ;	keyboards/ajazz/ak820/ak820_tapping.c:112: process_record(record);
      0046C5 12 49 06         [24] 1153 	lcall	_ak820_outline_0076
      0046C8 12 49 2F         [24] 1154 	lcall	_ak820_outline_0112
      0046CB C0 07            [24] 1155 	push	ar7
      0046CD C0 06            [24] 1156 	push	ar6
      0046CF C0 04            [24] 1157 	push	ar4
      0046D1 C0 03            [24] 1158 	push	ar3
      0046D3 12 71 17         [24] 1159 	lcall	_process_record
      0046D6 D0 03            [24] 1160 	pop	ar3
      0046D8 D0 04            [24] 1161 	pop	ar4
      0046DA D0 06            [24] 1162 	pop	ar6
      0046DC D0 07            [24] 1163 	pop	ar7
                                   1164 ;	keyboards/ajazz/ak820/ak820_tapping.c:113: record->event.pressed = false;
      0046DE 12 33 FC         [24] 1165 	lcall	_ak820_outline_0123
      0046E1 E4               [12] 1166 	clr	a
      0046E2 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	keyboards/ajazz/ak820/ak820_tapping.c:114: process_record(record);
      0046E3 FC               [12] 1169 	mov	r4,a
      0046E4 12 38 8C         [24] 1170 	lcall	_ak820_outline_0118
      0046E7 8C F0            [24] 1171 	mov	b, r4
      0046E9 12 71 17         [24] 1172 	lcall	_process_record
      0046EC                       1173 00122$:
                                   1174 ;	keyboards/ajazz/ak820/ak820_tapping.c:117: if (sc_mods) {
      0046EC 90 06 31         [24] 1175 	mov	dptr,#_ak820_tapping_process_sc_mods_10000_624
      0046EF E0               [24] 1176 	movx	a,@dptr
      0046F0 FF               [12] 1177 	mov	r7,a
      0046F1 E0               [24] 1178 	movx	a,@dptr
      0046F2 60 32            [24] 1179 	jz	00132$
                                   1180 ;	keyboards/ajazz/ak820/ak820_tapping.c:118: del_owned_mods(sc_mods);
      0046F4 8F 82            [24] 1181 	mov	dpl, r7
      0046F6 12 7D 45         [24] 1182 	lcall	_del_owned_mods
                                   1183 ;	keyboards/ajazz/ak820/ak820_tapping.c:119: send_keyboard_report();
      0046F9 12 80 6F         [24] 1184 	lcall	_send_keyboard_report
      0046FC 80 28            [24] 1185 	sjmp	00132$
      0046FE                       1186 00128$:
                                   1187 ;	keyboards/ajazz/ak820/ak820_tapping.c:122: } else if ((source_state[id] & SOURCE_HELD)) {
      0046FE ED               [12] 1188 	mov	a,r5
      0046FF 24 9E            [12] 1189 	add	a, #_source_state
      004701 FE               [12] 1190 	mov	r6,a
      004702 E4               [12] 1191 	clr	a
      004703 34 05            [12] 1192 	addc	a, #(_source_state >> 8)
      004705 FF               [12] 1193 	mov	r7,a
      004706 12 38 8C         [24] 1194 	lcall	_ak820_outline_0118
      004709 E0               [24] 1195 	movx	a,@dptr
      00470A FD               [12] 1196 	mov	r5,a
      00470B 30 E2 18         [24] 1197 	jnb	acc.2,00132$
                                   1198 ;	keyboards/ajazz/ak820/ak820_tapping.c:123: source_state[id] &= ~SOURCE_HELD;
      00470E 53 05 FB         [24] 1199 	anl	ar5,#0xfb
      004711 12 38 8C         [24] 1200 	lcall	_ak820_outline_0118
      004714 ED               [12] 1201 	mov	a,r5
      004715 F0               [24] 1202 	movx	@dptr,a
                                   1203 ;	keyboards/ajazz/ak820/ak820_tapping.c:124: hold(code, false);
      004716 90 06 2F         [24] 1204 	mov	dptr,#_ak820_tapping_process_code_10000_624
      004719 12 38 41         [24] 1205 	lcall	_ak820_outline_0051
      00471C 90 06 26         [24] 1206 	mov	dptr,#_hold_PARM_2
      00471F E4               [12] 1207 	clr	a
      004720 12 43 9D         [24] 1208 	lcall	_ak820_outline_0071
      004723 12 44 26         [24] 1209 	lcall	_hold
      004726                       1210 00132$:
                                   1211 ;	keyboards/ajazz/ak820/ak820_tapping.c:126: return false;
      004726 75 82 00         [24] 1212 	mov	dpl, #0x00
                                   1213 ;	keyboards/ajazz/ak820/ak820_tapping.c:127: }
      004729 22               [24] 1214 	ret
                                   1215 ;------------------------------------------------------------
                                   1216 ;Allocation info for local variables in function 'ak820_tapping_cancel'
                                   1217 ;------------------------------------------------------------
                                   1218 ;i             Allocated with name '_ak820_tapping_cancel_i_20000_647'
                                   1219 ;state         Allocated with name '_ak820_tapping_cancel_state_30000_648'
                                   1220 ;------------------------------------------------------------
                                   1221 ;	keyboards/ajazz/ak820/ak820_tapping.c:128: void ak820_tapping_cancel(void) {
                                   1222 ;	-----------------------------------------
                                   1223 ;	 function ak820_tapping_cancel
                                   1224 ;	-----------------------------------------
      00472A                       1225 _ak820_tapping_cancel:
                                   1226 ;	keyboards/ajazz/ak820/ak820_tapping.c:129: pending = NONE;
      00472A 12 49 36         [24] 1227 	lcall	_ak820_outline_0154
                                   1228 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      00472D 7F 00            [12] 1229 	mov	r7,#0x00
      00472F                       1230 00103$:
      00472F BF 82 00         [24] 1231 	cjne	r7,#0x82,00122$
      004732                       1232 00122$:
      004732 50 16            [24] 1233 	jnc	00105$
                                   1234 ;	keyboards/ajazz/ak820/ak820_tapping.c:131: uint8_t state = source_state[i];
      004734 12 48 B9         [24] 1235 	lcall	_ak820_outline_0020
                                   1236 ;	keyboards/ajazz/ak820/ak820_tapping.c:132: source_state[i] = (state & SOURCE_BLOCKED) | ((state & SOURCE_ACTIVE) << 1);
      004737 74 02            [12] 1237 	mov	a,#0x02
      004739 5C               [12] 1238 	anl	a,r4
      00473A FB               [12] 1239 	mov	r3,a
      00473B 53 04 01         [24] 1240 	anl	ar4,#0x01
      00473E EC               [12] 1241 	mov	a,r4
      00473F 2C               [12] 1242 	add	a,r4
      004740 42 03            [12] 1243 	orl	ar3,a
      004742 12 38 A1         [24] 1244 	lcall	_ak820_outline_0135
      004745 EB               [12] 1245 	mov	a,r3
      004746 F0               [24] 1246 	movx	@dptr,a
                                   1247 ;	keyboards/ajazz/ak820/ak820_tapping.c:130: for (uint8_t i = 0; i < SOURCES; ++i) {
      004747 0F               [12] 1248 	inc	r7
      004748 80 E5            [24] 1249 	sjmp	00103$
      00474A                       1250 00105$:
                                   1251 ;	keyboards/ajazz/ak820/ak820_tapping.c:134: }
      00474A 22               [24] 1252 	ret
                                   1253 ;------------------------------------------------------------
                                   1254 ;Allocation info for local variables in function 'ak820_oneshot_process'
                                   1255 ;------------------------------------------------------------
                                   1256 ;id            Allocated with name '_ak820_oneshot_process_PARM_2'
                                   1257 ;pressed       Allocated with name '_ak820_oneshot_process_PARM_3'
                                   1258 ;code          Allocated with name '_ak820_oneshot_process_code_10000_649'
                                   1259 ;mods          Allocated with name '_ak820_oneshot_process_mods_10000_650'
                                   1260 ;i             Allocated with name '_ak820_oneshot_process_i_40000_665'
                                   1261 ;------------------------------------------------------------
                                   1262 ;	keyboards/ajazz/ak820/ak820_tapping.c:143: bool ak820_oneshot_process(uint16_t code, uint8_t id, bool pressed) {
                                   1263 ;	-----------------------------------------
                                   1264 ;	 function ak820_oneshot_process
                                   1265 ;	-----------------------------------------
      00474B                       1266 _ak820_oneshot_process:
      00474B 12 38 82         [24] 1267 	lcall	_ak820_outline_0107
      00474E 90 06 36         [24] 1268 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004751 12 38 87         [24] 1269 	lcall	_ak820_outline_0108
                                   1270 ;	keyboards/ajazz/ak820/ak820_tapping.c:145: if (id == NONE || get_repeat_key_count()) return true;
      004754 90 06 34         [24] 1271 	mov	dptr,#_ak820_oneshot_process_PARM_2
      004757 E0               [24] 1272 	movx	a,@dptr
      004758 FF               [12] 1273 	mov	r7,a
      004759 BF FF 02         [24] 1274 	cjne	r7,#0xff,00266$
      00475C 80 0B            [24] 1275 	sjmp	00101$
      00475E                       1276 00266$:
      00475E C0 07            [24] 1277 	push	ar7
      004760 12 A2 DB         [24] 1278 	lcall	_get_repeat_key_count
      004763 E5 82            [12] 1279 	mov	a, dpl
      004765 D0 07            [24] 1280 	pop	ar7
      004767 60 04            [24] 1281 	jz	00102$
      004769                       1282 00101$:
      004769 75 82 01         [24] 1283 	mov	dpl, #0x01
      00476C 22               [24] 1284 	ret
      00476D                       1285 00102$:
                                   1286 ;	keyboards/ajazz/ak820/ak820_tapping.c:156: if (code == QK_MAGIC_SWAP_ALT_GUI || code == QK_MAGIC_UNSWAP_ALT_GUI || code == QK_MAGIC_TOGGLE_ALT_GUI) return true;
      00476D 90 06 36         [24] 1287 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004770 12 38 64         [24] 1288 	lcall	_ak820_outline_0079
      004773 8D 03            [24] 1289 	mov	ar3,r5
      004775 8E 04            [24] 1290 	mov	ar4,r6
      004777 BB 14 05         [24] 1291 	cjne	r3,#0x14,00268$
      00477A BC 70 02         [24] 1292 	cjne	r4,#0x70,00268$
      00477D 80 0E            [24] 1293 	sjmp	00104$
      00477F                       1294 00268$:
      00477F BB 15 05         [24] 1295 	cjne	r3,#0x15,00269$
      004782 BC 70 02         [24] 1296 	cjne	r4,#0x70,00269$
      004785 80 06            [24] 1297 	sjmp	00104$
      004787                       1298 00269$:
      004787 BB 16 07         [24] 1299 	cjne	r3,#0x16,00105$
      00478A BC 70 04         [24] 1300 	cjne	r4,#0x70,00105$
      00478D                       1301 00104$:
      00478D 75 82 01         [24] 1302 	mov	dpl, #0x01
      004790 22               [24] 1303 	ret
      004791                       1304 00105$:
                                   1305 ;	keyboards/ajazz/ak820/ak820_tapping.c:158: if ((code >> 8) == 0x52 && ((uint8_t)code & 0xe0) == 0xa0) {
      004791 8E 03            [24] 1306 	mov	ar3,r6
      004793 BB 52 02         [24] 1307 	cjne	r3,#0x52,00272$
      004796 80 03            [24] 1308 	sjmp	00273$
      004798                       1309 00272$:
      004798 02 48 3D         [24] 1310 	ljmp	00120$
      00479B                       1311 00273$:
      00479B 8D 04            [24] 1312 	mov	ar4,r5
      00479D 53 04 E0         [24] 1313 	anl	ar4,#0xe0
      0047A0 BC A0 02         [24] 1314 	cjne	r4,#0xa0,00274$
      0047A3 80 03            [24] 1315 	sjmp	00275$
      0047A5                       1316 00274$:
      0047A5 02 48 3D         [24] 1317 	ljmp	00120$
      0047A8                       1318 00275$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_tapping.c:159: mods = code & 15;
      0047A8 8D 04            [24] 1320 	mov	ar4,r5
      0047AA 53 04 0F         [24] 1321 	anl	ar4,#0x0f
      0047AD 90 06 38         [24] 1322 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0047B0 EC               [12] 1323 	mov	a,r4
      0047B1 F0               [24] 1324 	movx	@dptr,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_tapping.c:160: if (code & 16) mods <<= 4;
      0047B2 ED               [12] 1326 	mov	a,r5
      0047B3 30 E4 08         [24] 1327 	jnb	acc.4,00109$
      0047B6 EC               [12] 1328 	mov	a,r4
      0047B7 C4               [12] 1329 	swap	a
      0047B8 54 F0            [12] 1330 	anl	a,#0xf0
      0047BA 90 06 38         [24] 1331 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0047BD F0               [24] 1332 	movx	@dptr,a
      0047BE                       1333 00109$:
                                   1334 ;	keyboards/ajazz/ak820/ak820_tapping.c:161: if (pressed) {
      0047BE 90 06 35         [24] 1335 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0047C1 E0               [24] 1336 	movx	a,@dptr
      0047C2 60 2D            [24] 1337 	jz	00117$
                                   1338 ;	keyboards/ajazz/ak820/ak820_tapping.c:162: source_state[id] |= SOURCE_ONESHOT;
      0047C4 12 48 B9         [24] 1339 	lcall	_ak820_outline_0020
      0047C7 43 04 08         [24] 1340 	orl	ar4,#0x08
      0047CA 12 43 96         [24] 1341 	lcall	_ak820_outline_0063
                                   1342 ;	keyboards/ajazz/ak820/ak820_tapping.c:163: source_state[id] &= ~SOURCE_ONESHOT_USED;
      0047CD 53 04 EF         [24] 1343 	anl	ar4,#0xef
      0047D0 12 43 96         [24] 1344 	lcall	_ak820_outline_0063
                                   1345 ;	keyboards/ajazz/ak820/ak820_tapping.c:164: if (ak820_oneshot_target != NONE) source_state[id] |= SOURCE_ONESHOT_USED;
      0047D3 90 0D B1         [24] 1346 	mov	dptr,#_ak820_oneshot_target
      0047D6 E0               [24] 1347 	movx	a,@dptr
      0047D7 FC               [12] 1348 	mov	r4,a
      0047D8 BC FF 02         [24] 1349 	cjne	r4,#0xff,00278$
      0047DB 80 09            [24] 1350 	sjmp	00111$
      0047DD                       1351 00278$:
      0047DD 12 49 0D         [24] 1352 	lcall	_ak820_outline_0077
      0047E0 43 04 10         [24] 1353 	orl	ar4,#0x10
      0047E3 12 43 96         [24] 1354 	lcall	_ak820_outline_0063
      0047E6                       1355 00111$:
                                   1356 ;	keyboards/ajazz/ak820/ak820_tapping.c:165: register_mods(mods);
      0047E6 90 06 38         [24] 1357 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      0047E9 E0               [24] 1358 	movx	a,@dptr
      0047EA F5 82            [12] 1359 	mov	dpl,a
      0047EC 12 76 76         [24] 1360 	lcall	_register_mods
      0047EF 80 48            [24] 1361 	sjmp	00118$
      0047F1                       1362 00117$:
                                   1363 ;	keyboards/ajazz/ak820/ak820_tapping.c:166: } else if (source_state[id] & SOURCE_ONESHOT) {
      0047F1 12 48 B9         [24] 1364 	lcall	_ak820_outline_0020
      0047F4 30 E3 42         [24] 1365 	jnb	acc.3,00118$
                                   1366 ;	keyboards/ajazz/ak820/ak820_tapping.c:167: if (!(source_state[id] & SOURCE_ONESHOT_USED)) {
      0047F7 EC               [12] 1367 	mov	a,r4
      0047F8 20 E4 24         [24] 1368 	jb	acc.4,00113$
                                   1369 ;	keyboards/ajazz/ak820/ak820_tapping.c:168: add_owned_mods(mods & ~ak820_oneshot_mods);
      0047FB 90 06 32         [24] 1370 	mov	dptr,#_ak820_oneshot_mods
      0047FE E0               [24] 1371 	movx	a,@dptr
      0047FF F4               [12] 1372 	cpl	a
      004800 FC               [12] 1373 	mov	r4,a
      004801 90 06 38         [24] 1374 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004804 E0               [24] 1375 	movx	a,@dptr
      004805 FB               [12] 1376 	mov	r3,a
      004806 52 04            [12] 1377 	anl	ar4,a
      004808 8C 82            [24] 1378 	mov	dpl, r4
      00480A C0 06            [24] 1379 	push	ar6
      00480C C0 05            [24] 1380 	push	ar5
      00480E C0 03            [24] 1381 	push	ar3
      004810 12 7D 35         [24] 1382 	lcall	_add_owned_mods
      004813 D0 03            [24] 1383 	pop	ar3
      004815 D0 05            [24] 1384 	pop	ar5
      004817 D0 06            [24] 1385 	pop	ar6
                                   1386 ;	keyboards/ajazz/ak820/ak820_tapping.c:169: ak820_oneshot_mods |= mods;
      004819 90 06 32         [24] 1387 	mov	dptr,#_ak820_oneshot_mods
      00481C E0               [24] 1388 	movx	a,@dptr
      00481D 4B               [12] 1389 	orl	a,r3
      00481E F0               [24] 1390 	movx	@dptr,a
      00481F                       1391 00113$:
                                   1392 ;	keyboards/ajazz/ak820/ak820_tapping.c:171: unregister_mods(mods);
      00481F 90 06 38         [24] 1393 	mov	dptr,#_ak820_oneshot_process_mods_10000_650
      004822 E0               [24] 1394 	movx	a,@dptr
      004823 F5 82            [12] 1395 	mov	dpl,a
      004825 C0 06            [24] 1396 	push	ar6
      004827 C0 05            [24] 1397 	push	ar5
      004829 12 76 8A         [24] 1398 	lcall	_unregister_mods
      00482C D0 05            [24] 1399 	pop	ar5
      00482E D0 06            [24] 1400 	pop	ar6
                                   1401 ;	keyboards/ajazz/ak820/ak820_tapping.c:172: source_state[id] &= ~(SOURCE_ONESHOT | SOURCE_ONESHOT_USED);
      004830 12 49 0D         [24] 1402 	lcall	_ak820_outline_0077
      004833 53 04 E7         [24] 1403 	anl	ar4,#0xe7
      004836 12 43 96         [24] 1404 	lcall	_ak820_outline_0063
      004839                       1405 00118$:
                                   1406 ;	keyboards/ajazz/ak820/ak820_tapping.c:174: return false;
      004839 75 82 00         [24] 1407 	mov	dpl, #0x00
      00483C 22               [24] 1408 	ret
      00483D                       1409 00120$:
                                   1410 ;	keyboards/ajazz/ak820/ak820_tapping.c:176: if (pressed && code > KC_TRANSPARENT &&
      00483D 90 06 35         [24] 1411 	mov	dptr,#_ak820_oneshot_process_PARM_3
      004840 E0               [24] 1412 	movx	a,@dptr
      004841 60 5C            [24] 1413 	jz	00128$
      004843 90 06 36         [24] 1414 	mov	dptr,#_ak820_oneshot_process_code_10000_649
      004846 12 38 64         [24] 1415 	lcall	_ak820_outline_0079
      004849 C3               [12] 1416 	clr	c
      00484A 74 01            [12] 1417 	mov	a,#0x01
      00484C 9D               [12] 1418 	subb	a,r5
      00484D E4               [12] 1419 	clr	a
      00484E 9E               [12] 1420 	subb	a,r6
      00484F 50 4E            [24] 1421 	jnc	00128$
                                   1422 ;	free result
                                   1423 ;	keyboards/ajazz/ak820/ak820_tapping.c:177: !(code >= KC_LCTL && code <= KC_RGUI) &&
      004851 C3               [12] 1424 	clr	c
      004852 ED               [12] 1425 	mov	a,r5
      004853 94 E0            [12] 1426 	subb	a,#0xe0
      004855 EE               [12] 1427 	mov	a,r6
      004856 94 00            [12] 1428 	subb	a,#0x00
      004858 40 07            [24] 1429 	jc	00133$
      00485A 74 E7            [12] 1430 	mov	a,#0xe7
      00485C 9D               [12] 1431 	subb	a,r5
      00485D E4               [12] 1432 	clr	a
      00485E 9E               [12] 1433 	subb	a,r6
      00485F 50 3E            [24] 1434 	jnc	00128$
                                   1435 ;	free result
      004861                       1436 00133$:
                                   1437 ;	keyboards/ajazz/ak820/ak820_tapping.c:178: !(code >= QK_TO && code <= QK_LAYER_TAP_TOGGLE_MAX)) {
      004861 74 AE            [12] 1438 	mov	a,#0x100 - 0x52
      004863 2E               [12] 1439 	add	a,r6
      004864 50 09            [24] 1440 	jnc	00173$
      004866 C3               [12] 1441 	clr	c
      004867 74 DF            [12] 1442 	mov	a,#0xdf
      004869 9D               [12] 1443 	subb	a,r5
      00486A 74 52            [12] 1444 	mov	a,#0x52
      00486C 9E               [12] 1445 	subb	a,r6
      00486D 50 30            [24] 1446 	jnc	00128$
                                   1447 ;	free result
                                   1448 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: for (uint8_t i = 0; i < SOURCES; ++i)
      00486F                       1449 00173$:
      00486F 7E 00            [12] 1450 	mov	r6,#0x00
      004871                       1451 00135$:
      004871 BE 82 00         [24] 1452 	cjne	r6,#0x82,00287$
      004874                       1453 00287$:
      004874 50 12            [24] 1454 	jnc	00124$
                                   1455 ;	keyboards/ajazz/ak820/ak820_tapping.c:180: if (source_state[i] & SOURCE_ONESHOT) source_state[i] |= SOURCE_ONESHOT_USED;
      004876 EE               [12] 1456 	mov	a,r6
      004877 12 49 14         [24] 1457 	lcall	_ak820_outline_0080
      00487A 30 E3 08         [24] 1458 	jnb	acc.3,00136$
      00487D 43 03 10         [24] 1459 	orl	ar3,#0x10
      004880 12 38 97         [24] 1460 	lcall	_ak820_outline_0124
      004883 EB               [12] 1461 	mov	a,r3
      004884 F0               [24] 1462 	movx	@dptr,a
      004885                       1463 00136$:
                                   1464 ;	keyboards/ajazz/ak820/ak820_tapping.c:179: for (uint8_t i = 0; i < SOURCES; ++i)
      004885 0E               [12] 1465 	inc	r6
      004886 80 E9            [24] 1466 	sjmp	00135$
      004888                       1467 00124$:
                                   1468 ;	keyboards/ajazz/ak820/ak820_tapping.c:181: if (ak820_oneshot_mods) {
      004888 90 06 32         [24] 1469 	mov	dptr,#_ak820_oneshot_mods
      00488B E0               [24] 1470 	movx	a,@dptr
      00488C FE               [12] 1471 	mov	r6,a
      00488D E0               [24] 1472 	movx	a,@dptr
      00488E 60 0F            [24] 1473 	jz	00128$
                                   1474 ;	keyboards/ajazz/ak820/ak820_tapping.c:182: ak820_oneshot_consumed = ak820_oneshot_mods;
      004890 90 06 33         [24] 1475 	mov	dptr,#_ak820_oneshot_consumed
      004893 EE               [12] 1476 	mov	a,r6
      004894 F0               [24] 1477 	movx	@dptr,a
                                   1478 ;	keyboards/ajazz/ak820/ak820_tapping.c:183: ak820_oneshot_target = id;
      004895 90 0D B1         [24] 1479 	mov	dptr,#_ak820_oneshot_target
      004898 EF               [12] 1480 	mov	a,r7
      004899 F0               [24] 1481 	movx	@dptr,a
                                   1482 ;	keyboards/ajazz/ak820/ak820_tapping.c:184: ak820_oneshot_mods = 0;
      00489A 90 06 32         [24] 1483 	mov	dptr,#_ak820_oneshot_mods
      00489D E4               [12] 1484 	clr	a
      00489E F0               [24] 1485 	movx	@dptr,a
      00489F                       1486 00128$:
                                   1487 ;	keyboards/ajazz/ak820/ak820_tapping.c:187: return true;
      00489F 75 82 01         [24] 1488 	mov	dpl, #0x01
                                   1489 ;	keyboards/ajazz/ak820/ak820_tapping.c:188: }
      0048A2 22               [24] 1490 	ret
                                   1491 	.area CSEG    (CODE)
                                   1492 	.area CONST   (CODE)
                                   1493 	.area XINIT   (CODE)
      00C1B6                       1494 __xinit__pending:
      00C1B6 FF                    1495 	.db #0xff	; 255
      00C1B7                       1496 __xinit__ak820_oneshot_target:
      00C1B7 FF                    1497 	.db #0xff	; 255
                                   1498 	.area CABS    (ABS,CODE)
                                   1499 
                                   1500 ; Experimental exact instruction outlining.
                                   1501 	.globl _ak820_outline_0008
                                   1502 	.globl _ak820_outline_0009
                                   1503 	.globl _ak820_outline_0011
                                   1504 	.globl _ak820_outline_0015
                                   1505 	.globl _ak820_outline_0016
                                   1506 	.globl _ak820_outline_0020
                                   1507 	.globl _ak820_outline_0022
                                   1508 	.globl _ak820_outline_0024
                                   1509 	.globl _ak820_outline_0031
                                   1510 	.globl _ak820_outline_0032
                                   1511 	.globl _ak820_outline_0033
                                   1512 	.globl _ak820_outline_0036
                                   1513 	.globl _ak820_outline_0051
                                   1514 	.globl _ak820_outline_0055
                                   1515 	.globl _ak820_outline_0058
                                   1516 	.globl _ak820_outline_0063
                                   1517 	.globl _ak820_outline_0071
                                   1518 	.globl _ak820_outline_0076
                                   1519 	.globl _ak820_outline_0077
                                   1520 	.globl _ak820_outline_0079
                                   1521 	.globl _ak820_outline_0080
                                   1522 	.globl _ak820_outline_0097
                                   1523 	.globl _ak820_outline_0102
                                   1524 	.globl _ak820_outline_0107
                                   1525 	.globl _ak820_outline_0108
                                   1526 	.globl _ak820_outline_0112
                                   1527 	.globl _ak820_outline_0118
                                   1528 	.globl _ak820_outline_0123
                                   1529 	.globl _ak820_outline_0124
                                   1530 	.globl _ak820_outline_0135
                                   1531 	.globl _ak820_outline_0154
                                   1532 	.globl _ak820_outline_0158
                                   1533 	.globl _ak820_outline_0190
                                   1534 
                                   1535 	.area CSEG (CODE)
                                   1536 ; function ak820_outline_0008
      0048A3                       1537 _ak820_outline_0008:
      0048A3 E0               [24] 1538 	movx	a,@dptr
      0048A4 FE               [12] 1539 	mov	r6,a
      0048A5 A3               [24] 1540 	inc	dptr
      0048A6 E0               [24] 1541 	movx	a,@dptr
      0048A7 FF               [12] 1542 	mov	r7,a
      0048A8 8E 04            [24] 1543 	mov	ar4,r6
      0048AA 8F 05            [24] 1544 	mov	ar5,r7
      0048AC 22               [24] 1545 	ret
                                   1546 
                                   1547 	.area CSEG (CODE)
                                   1548 ; function ak820_outline_0015
      0048AD                       1549 _ak820_outline_0015:
      0048AD 74 05            [12] 1550 	mov	a,#0x05
      0048AF 2E               [12] 1551 	add	a,r6
      0048B0 FB               [12] 1552 	mov	r3,a
      0048B1 E4               [12] 1553 	clr	a
      0048B2 3F               [12] 1554 	addc	a,r7
      0048B3 FC               [12] 1555 	mov	r4,a
      0048B4 8B 82            [24] 1556 	mov	dpl,r3
      0048B6 8C 83            [24] 1557 	mov	dph,r4
      0048B8 22               [24] 1558 	ret
                                   1559 
                                   1560 	.area CSEG (CODE)
                                   1561 ; function ak820_outline_0020
      0048B9                       1562 _ak820_outline_0020:
      0048B9 EF               [12] 1563 	mov	a,r7
      0048BA 24 9E            [12] 1564 	add	a,#_source_state
      0048BC FD               [12] 1565 	mov	r5,a
      0048BD E4               [12] 1566 	clr	a
      0048BE 34 05            [12] 1567 	addc	a,#(_source_state>>8)
      0048C0 FE               [12] 1568 	mov	r6,a
      0048C1 8D 82            [24] 1569 	mov	dpl,r5
      0048C3 8E 83            [24] 1570 	mov	dph,r6
      0048C5 E0               [24] 1571 	movx	a,@dptr
      0048C6 FC               [12] 1572 	mov	r4,a
      0048C7 22               [24] 1573 	ret
                                   1574 
                                   1575 	.area CSEG (CODE)
                                   1576 ; function ak820_outline_0024
      0048C8                       1577 _ak820_outline_0024:
      0048C8 90 0D A0         [24] 1578 	mov	dptr,#___memcpy_PARM_2
      0048CB EC               [12] 1579 	mov	a,r4
      0048CC F0               [24] 1580 	movx	@dptr,a
      0048CD ED               [12] 1581 	mov	a,r5
      0048CE A3               [24] 1582 	inc	dptr
      0048CF F0               [24] 1583 	movx	@dptr,a
      0048D0 E4               [12] 1584 	clr	a
      0048D1 A3               [24] 1585 	inc	dptr
      0048D2 F0               [24] 1586 	movx	@dptr,a
      0048D3 90 0D A3         [24] 1587 	mov	dptr,#___memcpy_PARM_3
      0048D6 74 02            [12] 1588 	mov	a,#0x02
      0048D8 F0               [24] 1589 	movx	@dptr,a
      0048D9 E4               [12] 1590 	clr	a
      0048DA A3               [24] 1591 	inc	dptr
      0048DB F0               [24] 1592 	movx	@dptr,a
      0048DC 90 06 24         [24] 1593 	mov	dptr,#_ak820_tapping_source_PARM_1
      0048DF F5 F0            [12] 1594 	mov	b,a
      0048E1 22               [24] 1595 	ret
                                   1596 
                                   1597 	.area CSEG (CODE)
                                   1598 ; function ak820_outline_0032
      0048E2                       1599 _ak820_outline_0032:
      0048E2 2E               [12] 1600 	add	a,r6
      0048E3 FA               [12] 1601 	mov	r2,a
      0048E4 E4               [12] 1602 	clr	a
      0048E5 3F               [12] 1603 	addc	a,r7
      0048E6 FB               [12] 1604 	mov	r3,a
      0048E7 8A 82            [24] 1605 	mov	dpl,r2
      0048E9 8B 83            [24] 1606 	mov	dph,r3
      0048EB E0               [24] 1607 	movx	a,@dptr
      0048EC 22               [24] 1608 	ret
                                   1609 
                                   1610 	.area CSEG (CODE)
                                   1611 ; function ak820_outline_0033
      0048ED                       1612 _ak820_outline_0033:
      0048ED 2E               [12] 1613 	add	a,r6
      0048EE FC               [12] 1614 	mov	r4,a
      0048EF E4               [12] 1615 	clr	a
      0048F0 3F               [12] 1616 	addc	a,r7
      0048F1 FD               [12] 1617 	mov	r5,a
      0048F2 8C 82            [24] 1618 	mov	dpl,r4
      0048F4 8D 83            [24] 1619 	mov	dph,r5
      0048F6 E0               [24] 1620 	movx	a,@dptr
      0048F7 22               [24] 1621 	ret
                                   1622 
                                   1623 	.area CSEG (CODE)
                                   1624 ; function ak820_outline_0055
      0048F8                       1625 _ak820_outline_0055:
      0048F8 FC               [12] 1626 	mov	r4,a
      0048F9 8B 82            [24] 1627 	mov	dpl,r3
      0048FB 8C 83            [24] 1628 	mov	dph,r4
      0048FD E0               [24] 1629 	movx	a,@dptr
      0048FE FA               [12] 1630 	mov	r2,a
      0048FF 22               [24] 1631 	ret
                                   1632 
                                   1633 	.area CSEG (CODE)
                                   1634 ; function ak820_outline_0058
      004900                       1635 _ak820_outline_0058:
      004900 EE               [12] 1636 	mov	a,r6
      004901 F0               [24] 1637 	movx	@dptr,a
      004902 EF               [12] 1638 	mov	a,r7
      004903 A3               [24] 1639 	inc	dptr
      004904 F0               [24] 1640 	movx	@dptr,a
      004905 22               [24] 1641 	ret
                                   1642 
                                   1643 	.area CSEG (CODE)
                                   1644 ; function ak820_outline_0076
      004906                       1645 _ak820_outline_0076:
      004906 8E 00            [24] 1646 	mov	ar0,r6
      004908 8F 01            [24] 1647 	mov	ar1,r7
      00490A 7A 00            [12] 1648 	mov	r2,#0x00
      00490C 22               [24] 1649 	ret
                                   1650 
                                   1651 	.area CSEG (CODE)
                                   1652 ; function ak820_outline_0077
      00490D                       1653 _ak820_outline_0077:
      00490D 8D 82            [24] 1654 	mov	dpl,r5
      00490F 8E 83            [24] 1655 	mov	dph,r6
      004911 E0               [24] 1656 	movx	a,@dptr
      004912 FC               [12] 1657 	mov	r4,a
      004913 22               [24] 1658 	ret
                                   1659 
                                   1660 	.area CSEG (CODE)
                                   1661 ; function ak820_outline_0080
      004914                       1662 _ak820_outline_0080:
      004914 24 9E            [12] 1663 	add	a,#_source_state
      004916 FC               [12] 1664 	mov	r4,a
      004917 E4               [12] 1665 	clr	a
      004918 34 05            [12] 1666 	addc	a,#(_source_state>>8)
      00491A FD               [12] 1667 	mov	r5,a
      00491B 8C 82            [24] 1668 	mov	dpl,r4
      00491D 8D 83            [24] 1669 	mov	dph,r5
      00491F E0               [24] 1670 	movx	a,@dptr
      004920 FB               [12] 1671 	mov	r3,a
      004921 22               [24] 1672 	ret
                                   1673 
                                   1674 	.area CSEG (CODE)
                                   1675 ; function ak820_outline_0097
      004922                       1676 _ak820_outline_0097:
      004922 74 04            [12] 1677 	mov	a,#0x04
      004924 2E               [12] 1678 	add	a,r6
      004925 FB               [12] 1679 	mov	r3,a
      004926 E4               [12] 1680 	clr	a
      004927 3F               [12] 1681 	addc	a,r7
      004928 FC               [12] 1682 	mov	r4,a
      004929 8B 82            [24] 1683 	mov	dpl,r3
      00492B 8C 83            [24] 1684 	mov	dph,r4
      00492D E0               [24] 1685 	movx	a,@dptr
      00492E 22               [24] 1686 	ret
                                   1687 
                                   1688 	.area CSEG (CODE)
                                   1689 ; function ak820_outline_0112
      00492F                       1690 _ak820_outline_0112:
      00492F 88 82            [24] 1691 	mov	dpl,r0
      004931 89 83            [24] 1692 	mov	dph,r1
      004933 8A F0            [24] 1693 	mov	b,r2
      004935 22               [24] 1694 	ret
                                   1695 
                                   1696 	.area CSEG (CODE)
                                   1697 ; function ak820_outline_0154
      004936                       1698 _ak820_outline_0154:
      004936 90 0D B0         [24] 1699 	mov	dptr,#_pending
      004939 74 FF            [12] 1700 	mov	a,#0xff
      00493B F0               [24] 1701 	movx	@dptr,a
      00493C 22               [24] 1702 	ret
