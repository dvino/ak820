                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00067F                         85 _eeprom_read_word_addr_10000_91:
      00067F                         86 	.ds 3
      000682                         87 _eeprom_read_word_ret_10000_92:
      000682                         88 	.ds 2
      000684                         89 _eeprom_read_dword_addr_10000_93:
      000684                         90 	.ds 3
      000687                         91 _eeprom_read_dword_ret_10000_94:
      000687                         92 	.ds 4
      00068B                         93 _eeprom_write_byte_PARM_2:
      00068B                         94 	.ds 1
      00068C                         95 _eeprom_write_byte_addr_10000_95:
      00068C                         96 	.ds 3
      00068F                         97 _eeprom_write_word_PARM_2:
      00068F                         98 	.ds 2
      000691                         99 _eeprom_write_word_addr_10000_97:
      000691                        100 	.ds 3
      000694                        101 _eeprom_write_dword_PARM_2:
      000694                        102 	.ds 4
      000698                        103 _eeprom_write_dword_addr_10000_99:
      000698                        104 	.ds 3
      00069B                        105 _eeprom_update_byte_PARM_2:
      00069B                        106 	.ds 1
      00069C                        107 _eeprom_update_byte_addr_10000_107:
      00069C                        108 	.ds 3
      00069F                        109 _eeprom_update_word_PARM_2:
      00069F                        110 	.ds 2
      0006A1                        111 _eeprom_update_word_addr_10000_111:
      0006A1                        112 	.ds 3
      0006A4                        113 _eeprom_update_dword_PARM_2:
      0006A4                        114 	.ds 4
      0006A8                        115 _eeprom_update_dword_addr_10000_115:
      0006A8                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004DAE                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004DAE 12 43 72         [24]  170 	lcall	_ak820_outline_0037
      004DB1 90 06 7F         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004DB4 12 38 29         [24]  172 	lcall	_ak820_outline_0017
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004DB7 90 06 82         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004DBA 12 4F B9         [24]  175 	lcall	_ak820_outline_0182
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004DBD 90 06 7F         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004DC0 12 4F 66         [24]  178 	lcall	_ak820_outline_0012
      004DC3 90 05 85         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004DC6 ED               [12]  180 	mov	a,r5
      004DC7 12 38 29         [24]  181 	lcall	_ak820_outline_0017
      004DCA 90 05 88         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004DCD 12 4F AB         [24]  183 	lcall	_ak820_outline_0110
      004DD0 90 06 82         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004DD3 12 41 0E         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004DD6 90 06 82         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004DD9 12 4F A2         [24]  188 	lcall	_ak820_outline_0092
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004DDC 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004DDD                        201 _eeprom_read_dword:
      004DDD 12 43 72         [24]  202 	lcall	_ak820_outline_0037
      004DE0 90 06 84         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004DE3 12 38 29         [24]  204 	lcall	_ak820_outline_0017
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004DE6 90 06 87         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004DE9 12 4F 77         [24]  207 	lcall	_ak820_outline_0050
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004DEC 90 06 84         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004DEF 12 4F 66         [24]  210 	lcall	_ak820_outline_0012
      004DF2 90 05 85         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004DF5 ED               [12]  212 	mov	a,r5
      004DF6 12 38 29         [24]  213 	lcall	_ak820_outline_0017
      004DF9 90 05 88         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004DFC 74 04            [12]  215 	mov	a,#0x04
      004DFE 12 38 9C         [24]  216 	lcall	_ak820_outline_0134
      004E01 90 06 87         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E04 12 41 0E         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004E07 90 06 87         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004E0A 12 4F 80         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004E0D 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004E0E                        234 _eeprom_write_byte:
      004E0E 12 43 72         [24]  235 	lcall	_ak820_outline_0037
      004E11 90 06 8C         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004E14 12 38 29         [24]  237 	lcall	_ak820_outline_0017
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004E17 90 06 8C         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004E1A 12 4F 4F         [24]  240 	lcall	_ak820_outline_0004
      004E1D 74 01            [12]  241 	mov	a,#0x01
      004E1F 12 38 9C         [24]  242 	lcall	_ak820_outline_0134
      004E22 90 06 8B         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004E25 02 41 9A         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004E28                        256 _eeprom_write_word:
      004E28 12 43 72         [24]  257 	lcall	_ak820_outline_0037
      004E2B 90 06 91         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004E2E 12 38 29         [24]  259 	lcall	_ak820_outline_0017
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004E31 90 06 91         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004E34 12 4F 4F         [24]  262 	lcall	_ak820_outline_0004
      004E37 12 4F AB         [24]  263 	lcall	_ak820_outline_0110
      004E3A 90 06 8F         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      004E3D 02 41 9A         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      004E40                        277 _eeprom_write_dword:
      004E40 12 43 72         [24]  278 	lcall	_ak820_outline_0037
      004E43 90 06 98         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004E46 12 38 29         [24]  280 	lcall	_ak820_outline_0017
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      004E49 90 06 98         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      004E4C 12 4F 4F         [24]  283 	lcall	_ak820_outline_0004
      004E4F 74 04            [12]  284 	mov	a,#0x04
      004E51 12 38 9C         [24]  285 	lcall	_ak820_outline_0134
      004E54 90 06 94         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      004E57 02 41 9A         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      004E5A                        307 _eeprom_update_byte:
      004E5A C0 07            [24]  308 	push	ar7
      004E5C C0 06            [24]  309 	push	ar6
      004E5E C0 05            [24]  310 	push	ar5
      004E60 C0 04            [24]  311 	push	ar4
      004E62 12 43 72         [24]  312 	lcall	_ak820_outline_0037
      004E65 90 06 9C         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E68 12 38 29         [24]  314 	lcall	_ak820_outline_0017
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      004E6B 90 06 9C         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E6E 12 4F 40         [24]  317 	lcall	_ak820_outline_0001
      004E71 12 40 D3         [24]  318 	lcall	_eeprom_read_byte
      004E74 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      004E76 90 06 9B         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      004E79 E0               [24]  322 	movx	a,@dptr
      004E7A FE               [12]  323 	mov	r6,a
      004E7B EF               [12]  324 	mov	a,r7
      004E7C B5 06 02         [24]  325 	cjne	a,ar6,00112$
      004E7F 80 35            [24]  326 	sjmp	00103$
      004E81                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      004E81 90 06 9C         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      004E84 12 38 58         [24]  330 	lcall	_ak820_outline_0059
      004E87 A3               [24]  331 	inc	dptr
      004E88 E0               [24]  332 	movx	a,@dptr
      004E89 FF               [12]  333 	mov	r7,a
      004E8A 90 06 8B         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      004E8D EE               [12]  335 	mov	a,r6
      004E8E 12 38 76         [24]  336 	lcall	_ak820_outline_0100
      004E91 8F F0            [24]  337 	mov	b, r7
      004E93 C0 07            [24]  338 	push	ar7
      004E95 C0 06            [24]  339 	push	ar6
      004E97 C0 05            [24]  340 	push	ar5
      004E99 C0 04            [24]  341 	push	ar4
      004E9B C0 03            [24]  342 	push	ar3
      004E9D C0 02            [24]  343 	push	ar2
      004E9F C0 01            [24]  344 	push	ar1
      004EA1 C0 00            [24]  345 	push	ar0
      004EA3 12 4E 0E         [24]  346 	lcall	_eeprom_write_byte
      004EA6 D0 00            [24]  347 	pop	ar0
      004EA8 D0 01            [24]  348 	pop	ar1
      004EAA D0 02            [24]  349 	pop	ar2
      004EAC D0 03            [24]  350 	pop	ar3
      004EAE D0 04            [24]  351 	pop	ar4
      004EB0 D0 05            [24]  352 	pop	ar5
      004EB2 D0 06            [24]  353 	pop	ar6
      004EB4 D0 07            [24]  354 	pop	ar7
      004EB6                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      004EB6 D0 04            [24]  357 	pop	ar4
      004EB8 D0 05            [24]  358 	pop	ar5
      004EBA D0 06            [24]  359 	pop	ar6
      004EBC D0 07            [24]  360 	pop	ar7
      004EBE 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      004EBF                        373 _eeprom_update_word:
      004EBF 12 43 72         [24]  374 	lcall	_ak820_outline_0037
      004EC2 90 06 A1         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004EC5 12 38 29         [24]  376 	lcall	_ak820_outline_0017
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      004EC8 90 06 A1         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004ECB 12 4F 40         [24]  379 	lcall	_ak820_outline_0001
      004ECE 12 4D AE         [24]  380 	lcall	_eeprom_read_word
      004ED1 12 43 BB         [24]  381 	lcall	_ak820_outline_0133
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      004ED4 90 06 9F         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      004ED7 12 38 58         [24]  384 	lcall	_ak820_outline_0059
      004EDA EE               [12]  385 	mov	a,r6
      004EDB B5 04 05         [24]  386 	cjne	a,ar4,00112$
      004EDE EF               [12]  387 	mov	a,r7
      004EDF B5 05 01         [24]  388 	cjne	a,ar5,00112$
      004EE2 22               [24]  389 	ret
      004EE3                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      004EE3 90 06 A1         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      004EE6 E0               [24]  393 	movx	a,@dptr
      004EE7 FB               [12]  394 	mov	r3,a
      004EE8 A3               [24]  395 	inc	dptr
      004EE9 12 38 41         [24]  396 	lcall	_ak820_outline_0051
      004EEC 90 06 8F         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      004EEF 12 38 5E         [24]  398 	lcall	_ak820_outline_0072
      004EF2 8B 82            [24]  399 	mov	dpl, r3
      004EF4 8E 83            [24]  400 	mov	dph, r6
      004EF6 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      004EF8 02 4E 28         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      004EFB                        415 _eeprom_update_dword:
      004EFB 12 43 72         [24]  416 	lcall	_ak820_outline_0037
      004EFE 90 06 A8         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F01 12 38 29         [24]  418 	lcall	_ak820_outline_0017
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      004F04 90 06 A8         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F07 12 4F 40         [24]  421 	lcall	_ak820_outline_0001
      004F0A 12 4D DD         [24]  422 	lcall	_eeprom_read_dword
      004F0D 12 4F 91         [24]  423 	lcall	_ak820_outline_0056
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      004F10 90 06 A4         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      004F13 E0               [24]  426 	movx	a,@dptr
      004F14 F8               [12]  427 	mov	r0,a
      004F15 A3               [24]  428 	inc	dptr
      004F16 12 4F 99         [24]  429 	lcall	_ak820_outline_0091
      004F19 EC               [12]  430 	mov	a,r4
      004F1A B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      004F1D ED               [12]  432 	mov	a,r5
      004F1E B5 01 09         [24]  433 	cjne	a,ar1,00112$
      004F21 EE               [12]  434 	mov	a,r6
      004F22 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      004F25 EF               [12]  436 	mov	a,r7
      004F26 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      004F29 22               [24]  438 	ret
      004F2A                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      004F2A 90 06 A8         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      004F2D 12 4F 66         [24]  442 	lcall	_ak820_outline_0012
      004F30 90 06 94         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      004F33 E8               [12]  444 	mov	a,r0
      004F34 F0               [24]  445 	movx	@dptr,a
      004F35 E9               [12]  446 	mov	a,r1
      004F36 A3               [24]  447 	inc	dptr
      004F37 12 4F B2         [24]  448 	lcall	_ak820_outline_0155
      004F3A 12 4F 6F         [24]  449 	lcall	_ak820_outline_0034
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      004F3D 02 4E 40         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0012
                                    461 	.globl _ak820_outline_0017
                                    462 	.globl _ak820_outline_0034
                                    463 	.globl _ak820_outline_0037
                                    464 	.globl _ak820_outline_0050
                                    465 	.globl _ak820_outline_0051
                                    466 	.globl _ak820_outline_0054
                                    467 	.globl _ak820_outline_0056
                                    468 	.globl _ak820_outline_0059
                                    469 	.globl _ak820_outline_0072
                                    470 	.globl _ak820_outline_0091
                                    471 	.globl _ak820_outline_0092
                                    472 	.globl _ak820_outline_0100
                                    473 	.globl _ak820_outline_0110
                                    474 	.globl _ak820_outline_0133
                                    475 	.globl _ak820_outline_0134
                                    476 	.globl _ak820_outline_0155
                                    477 	.globl _ak820_outline_0182
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      004F40                        481 _ak820_outline_0001:
      004F40 E0               [24]  482 	movx	a,@dptr
      004F41 FD               [12]  483 	mov	r5,a
      004F42 A3               [24]  484 	inc	dptr
      004F43 E0               [24]  485 	movx	a,@dptr
      004F44 FE               [12]  486 	mov	r6,a
      004F45 A3               [24]  487 	inc	dptr
      004F46 E0               [24]  488 	movx	a,@dptr
      004F47 FF               [12]  489 	mov	r7,a
      004F48 8D 82            [24]  490 	mov	dpl,r5
      004F4A 8E 83            [24]  491 	mov	dph,r6
      004F4C 8F F0            [24]  492 	mov	b,r7
      004F4E 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      004F4F                        497 _ak820_outline_0004:
      004F4F E0               [24]  498 	movx	a,@dptr
      004F50 FD               [12]  499 	mov	r5,a
      004F51 A3               [24]  500 	inc	dptr
      004F52 E0               [24]  501 	movx	a,@dptr
      004F53 FE               [12]  502 	mov	r6,a
      004F54 A3               [24]  503 	inc	dptr
      004F55 E0               [24]  504 	movx	a,@dptr
      004F56 FF               [12]  505 	mov	r7,a
      004F57 90 05 8E         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004F5A ED               [12]  507 	mov	a,r5
      004F5B F0               [24]  508 	movx	@dptr,a
      004F5C EE               [12]  509 	mov	a,r6
      004F5D A3               [24]  510 	inc	dptr
      004F5E F0               [24]  511 	movx	@dptr,a
      004F5F EF               [12]  512 	mov	a,r7
      004F60 A3               [24]  513 	inc	dptr
      004F61 F0               [24]  514 	movx	@dptr,a
      004F62 90 05 91         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004F65 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0012
      004F66                        520 _ak820_outline_0012:
      004F66 E0               [24]  521 	movx	a,@dptr
      004F67 FD               [12]  522 	mov	r5,a
      004F68 A3               [24]  523 	inc	dptr
      004F69 E0               [24]  524 	movx	a,@dptr
      004F6A FE               [12]  525 	mov	r6,a
      004F6B A3               [24]  526 	inc	dptr
      004F6C E0               [24]  527 	movx	a,@dptr
      004F6D FF               [12]  528 	mov	r7,a
      004F6E 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0034
      004F6F                        533 _ak820_outline_0034:
      004F6F F0               [24]  534 	movx	@dptr,a
      004F70 8D 82            [24]  535 	mov	dpl,r5
      004F72 8E 83            [24]  536 	mov	dph,r6
      004F74 8F F0            [24]  537 	mov	b,r7
      004F76 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0050
      004F77                        542 _ak820_outline_0050:
      004F77 E4               [12]  543 	clr	a
      004F78 F0               [24]  544 	movx	@dptr,a
      004F79 A3               [24]  545 	inc	dptr
      004F7A F0               [24]  546 	movx	@dptr,a
      004F7B A3               [24]  547 	inc	dptr
      004F7C F0               [24]  548 	movx	@dptr,a
      004F7D A3               [24]  549 	inc	dptr
      004F7E F0               [24]  550 	movx	@dptr,a
      004F7F 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0054
      004F80                        555 _ak820_outline_0054:
      004F80 E0               [24]  556 	movx	a,@dptr
      004F81 FC               [12]  557 	mov	r4,a
      004F82 A3               [24]  558 	inc	dptr
      004F83 E0               [24]  559 	movx	a,@dptr
      004F84 FD               [12]  560 	mov	r5,a
      004F85 A3               [24]  561 	inc	dptr
      004F86 E0               [24]  562 	movx	a,@dptr
      004F87 FE               [12]  563 	mov	r6,a
      004F88 A3               [24]  564 	inc	dptr
      004F89 E0               [24]  565 	movx	a,@dptr
      004F8A 8C 82            [24]  566 	mov	dpl,r4
      004F8C 8D 83            [24]  567 	mov	dph,r5
      004F8E 8E F0            [24]  568 	mov	b,r6
      004F90 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0056
      004F91                        573 _ak820_outline_0056:
      004F91 AC 82            [24]  574 	mov	r4,dpl
      004F93 AD 83            [24]  575 	mov	r5,dph
      004F95 AE F0            [24]  576 	mov	r6,b
      004F97 FF               [12]  577 	mov	r7,a
      004F98 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0091
      004F99                        582 _ak820_outline_0091:
      004F99 E0               [24]  583 	movx	a,@dptr
      004F9A F9               [12]  584 	mov	r1,a
      004F9B A3               [24]  585 	inc	dptr
      004F9C E0               [24]  586 	movx	a,@dptr
      004F9D FA               [12]  587 	mov	r2,a
      004F9E A3               [24]  588 	inc	dptr
      004F9F E0               [24]  589 	movx	a,@dptr
      004FA0 FB               [12]  590 	mov	r3,a
      004FA1 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0092
      004FA2                        595 _ak820_outline_0092:
      004FA2 E0               [24]  596 	movx	a,@dptr
      004FA3 FE               [12]  597 	mov	r6,a
      004FA4 A3               [24]  598 	inc	dptr
      004FA5 E0               [24]  599 	movx	a,@dptr
      004FA6 8E 82            [24]  600 	mov	dpl,r6
      004FA8 F5 83            [12]  601 	mov	dph,a
      004FAA 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0110
      004FAB                        606 _ak820_outline_0110:
      004FAB 74 02            [12]  607 	mov	a,#0x02
      004FAD F0               [24]  608 	movx	@dptr,a
      004FAE E4               [12]  609 	clr	a
      004FAF A3               [24]  610 	inc	dptr
      004FB0 F0               [24]  611 	movx	@dptr,a
      004FB1 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0155
      004FB2                        616 _ak820_outline_0155:
      004FB2 F0               [24]  617 	movx	@dptr,a
      004FB3 EA               [12]  618 	mov	a,r2
      004FB4 A3               [24]  619 	inc	dptr
      004FB5 F0               [24]  620 	movx	@dptr,a
      004FB6 EB               [12]  621 	mov	a,r3
      004FB7 A3               [24]  622 	inc	dptr
      004FB8 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0182
      004FB9                        627 _ak820_outline_0182:
      004FB9 E4               [12]  628 	clr	a
      004FBA F0               [24]  629 	movx	@dptr,a
      004FBB A3               [24]  630 	inc	dptr
      004FBC F0               [24]  631 	movx	@dptr,a
      004FBD 22               [24]  632 	ret
