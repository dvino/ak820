                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_layer
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_macro_change
                                     12 	.globl _ak820_tri_layer_derived
                                     13 	.globl _ak820_keycode_at
                                     14 	.globl _action_for_keycode
                                     15 	.globl _ADC_START
                                     16 	.globl _S0_R_FIFO
                                     17 	.globl _S0_T_FIFO
                                     18 	.globl _S0_FREE
                                     19 	.globl _S0_IF_BYTE
                                     20 	.globl _S0_IF_FIRST
                                     21 	.globl _S0_IF_OV
                                     22 	.globl _S0_FST_ACT
                                     23 	.globl _CP_RL2
                                     24 	.globl _C_T2
                                     25 	.globl _TR2
                                     26 	.globl _EXEN2
                                     27 	.globl _TCLK
                                     28 	.globl _RCLK
                                     29 	.globl _EXF2
                                     30 	.globl _CAP1F
                                     31 	.globl _TF2
                                     32 	.globl _RI
                                     33 	.globl _TI
                                     34 	.globl _RB8
                                     35 	.globl _TB8
                                     36 	.globl _REN
                                     37 	.globl _SM2
                                     38 	.globl _SM1
                                     39 	.globl _SM0
                                     40 	.globl _IT0
                                     41 	.globl _IE0
                                     42 	.globl _IT1
                                     43 	.globl _IE1
                                     44 	.globl _TR0
                                     45 	.globl _TF0
                                     46 	.globl _TR1
                                     47 	.globl _TF1
                                     48 	.globl _P4_0
                                     49 	.globl _P4_1
                                     50 	.globl _P4_2
                                     51 	.globl _P4_3
                                     52 	.globl _P4_4
                                     53 	.globl _P4_5
                                     54 	.globl _P4_6
                                     55 	.globl _RXD
                                     56 	.globl _TXD
                                     57 	.globl _INT0
                                     58 	.globl _INT1
                                     59 	.globl _T0
                                     60 	.globl _T1
                                     61 	.globl _MOSI1
                                     62 	.globl _MISO1
                                     63 	.globl _SCK1
                                     64 	.globl _P3_0
                                     65 	.globl _P3_1
                                     66 	.globl _P3_2
                                     67 	.globl _P3_3
                                     68 	.globl _P3_4
                                     69 	.globl _P3_5
                                     70 	.globl _P3_6
                                     71 	.globl _P3_7
                                     72 	.globl _CAP1_
                                     73 	.globl _T2_
                                     74 	.globl _CAP2_
                                     75 	.globl _T2EX_
                                     76 	.globl _RXD1
                                     77 	.globl _TXD1
                                     78 	.globl _P2_0
                                     79 	.globl _P2_1
                                     80 	.globl _P2_2
                                     81 	.globl _P2_3
                                     82 	.globl _P2_4
                                     83 	.globl _P2_5
                                     84 	.globl _P2_6
                                     85 	.globl _P2_7
                                     86 	.globl _AIN0
                                     87 	.globl _AIN1
                                     88 	.globl _AIN2
                                     89 	.globl _AIN3
                                     90 	.globl _AIN4
                                     91 	.globl _AIN5
                                     92 	.globl _AIN6
                                     93 	.globl _AIN7
                                     94 	.globl _CAP1
                                     95 	.globl _T2
                                     96 	.globl _CAP2
                                     97 	.globl _T2EX
                                     98 	.globl _INT0_
                                     99 	.globl _SCS
                                    100 	.globl _MOSI
                                    101 	.globl _MISO
                                    102 	.globl _SCK
                                    103 	.globl _RXD1_
                                    104 	.globl _TXD1_
                                    105 	.globl _P1_0
                                    106 	.globl _P1_1
                                    107 	.globl _P1_2
                                    108 	.globl _P1_3
                                    109 	.globl _P1_4
                                    110 	.globl _P1_5
                                    111 	.globl _P1_6
                                    112 	.globl _P1_7
                                    113 	.globl _AIN8
                                    114 	.globl _AIN9
                                    115 	.globl _AIN10
                                    116 	.globl _AIN11
                                    117 	.globl _AIN12
                                    118 	.globl _AIN13
                                    119 	.globl _RXD_
                                    120 	.globl _TXD_
                                    121 	.globl _SCL0
                                    122 	.globl _SDA0
                                    123 	.globl _P0_0
                                    124 	.globl _P0_1
                                    125 	.globl _P0_2
                                    126 	.globl _P0_3
                                    127 	.globl _P0_4
                                    128 	.globl _P0_5
                                    129 	.globl _P0_6
                                    130 	.globl _P0_7
                                    131 	.globl _IE_SPI0
                                    132 	.globl _IE_USB
                                    133 	.globl _IE_ADC
                                    134 	.globl _IE_UART1
                                    135 	.globl _IE_PWM_I2C
                                    136 	.globl _IE_GPIO
                                    137 	.globl _IE_WDOG
                                    138 	.globl _PX0
                                    139 	.globl _PT0
                                    140 	.globl _PX1
                                    141 	.globl _PT1
                                    142 	.globl _PS
                                    143 	.globl _PT2
                                    144 	.globl _PL_FLAG
                                    145 	.globl _PH_FLAG
                                    146 	.globl _EX0
                                    147 	.globl _ET0
                                    148 	.globl _EX1
                                    149 	.globl _ET1
                                    150 	.globl _ES
                                    151 	.globl _ET2
                                    152 	.globl _E_DIS
                                    153 	.globl _EA
                                    154 	.globl _P
                                    155 	.globl _F1
                                    156 	.globl _OV
                                    157 	.globl _RS0
                                    158 	.globl _RS1
                                    159 	.globl _F0
                                    160 	.globl _AC
                                    161 	.globl _CY
                                    162 	.globl _I2CS_INT_ST
                                    163 	.globl _I2CX_INT
                                    164 	.globl _LED_STATUS
                                    165 	.globl _LED_DMA_H
                                    166 	.globl _LED_DMA_L
                                    167 	.globl _LED_DMA
                                    168 	.globl _LED_PWM_OE
                                    169 	.globl _LED_COMMON
                                    170 	.globl _ADC_CHAN
                                    171 	.globl _ADC_DAT_H
                                    172 	.globl _ADC_DAT_L
                                    173 	.globl _ADC_DAT
                                    174 	.globl _ADC_CTRL
                                    175 	.globl _SPI1_CK_SE
                                    176 	.globl _SPI1_CTRL
                                    177 	.globl _SPI1_DATA
                                    178 	.globl _SPI1_STAT
                                    179 	.globl _SIF1
                                    180 	.globl _SBAUD1
                                    181 	.globl _SBUF1
                                    182 	.globl _SCON1
                                    183 	.globl _SPI0_SETUP
                                    184 	.globl _SPI0_CK_SE
                                    185 	.globl _SPI0_CTRL
                                    186 	.globl _SPI0_DATA
                                    187 	.globl _SPI0_STAT
                                    188 	.globl _T2CAP1H
                                    189 	.globl _T2CAP1L
                                    190 	.globl _T2CAP1
                                    191 	.globl _TH2
                                    192 	.globl _TL2
                                    193 	.globl _T2COUNT
                                    194 	.globl _RCAP2H
                                    195 	.globl _RCAP2L
                                    196 	.globl _RCAP2
                                    197 	.globl _T2MOD
                                    198 	.globl _T2CON
                                    199 	.globl _SBUF
                                    200 	.globl _SCON
                                    201 	.globl _TH1
                                    202 	.globl _TH0
                                    203 	.globl _TL1
                                    204 	.globl _TL0
                                    205 	.globl _TMOD
                                    206 	.globl _TCON
                                    207 	.globl _XBUS_AUX
                                    208 	.globl _P7
                                    209 	.globl _P6_DIR
                                    210 	.globl _P6_OUT_PU
                                    211 	.globl _P6_IN
                                    212 	.globl _P5_DIR
                                    213 	.globl _P5_OUT_PU
                                    214 	.globl _P5_IN
                                    215 	.globl _P4_LED_KEY
                                    216 	.globl _P4_DIR_PU
                                    217 	.globl _P4_MOD_OC
                                    218 	.globl _P4
                                    219 	.globl _P3_DIR_PU
                                    220 	.globl _P3_MOD_OC
                                    221 	.globl _P3
                                    222 	.globl _P2_DIR_PU
                                    223 	.globl _P2_MOD_OC
                                    224 	.globl _P2
                                    225 	.globl _P1_DIR_PU
                                    226 	.globl _P1_MOD_OC
                                    227 	.globl _P1
                                    228 	.globl _P0_DIR_PU
                                    229 	.globl _P0_MOD_OC
                                    230 	.globl _P0
                                    231 	.globl _ROM_CTRL
                                    232 	.globl _ROM_DATA_HH
                                    233 	.globl _ROM_DATA_HL
                                    234 	.globl _ROM_DATA_HI
                                    235 	.globl _ROM_ADDR_H
                                    236 	.globl _ROM_ADDR_L
                                    237 	.globl _ROM_ADDR
                                    238 	.globl _GPIO_IE
                                    239 	.globl _IP_EX
                                    240 	.globl _IE_EX
                                    241 	.globl _IP
                                    242 	.globl _IE
                                    243 	.globl _WDOG_COUNT
                                    244 	.globl _RESET_KEEP
                                    245 	.globl _WAKE_CTRL
                                    246 	.globl _CLOCK_CFG
                                    247 	.globl _POWER_CFG
                                    248 	.globl _PCON
                                    249 	.globl _GLOBAL_CFG
                                    250 	.globl _SAFE_MOD
                                    251 	.globl _DPH
                                    252 	.globl _DPL
                                    253 	.globl _SP
                                    254 	.globl _A_INV
                                    255 	.globl _B
                                    256 	.globl _ACC
                                    257 	.globl _PSW
                                    258 	.globl _layer_state
                                    259 	.globl _default_layer_state
                                    260 	.globl _ak820_resolve_key_PARM_2
                                    261 	.globl _ak820_cache_layer_PARM_2
                                    262 	.globl _ak820_cache_keycode_PARM_2
                                    263 	.globl _default_layer_state_set_user
                                    264 	.globl _default_layer_state_set_kb
                                    265 	.globl _default_layer_set
                                    266 	.globl _default_layer_or
                                    267 	.globl _default_layer_and
                                    268 	.globl _default_layer_xor
                                    269 	.globl _ak820_layer_refresh
                                    270 	.globl _layer_hold_on
                                    271 	.globl _layer_hold_off
                                    272 	.globl _layer_hold_clear
                                    273 	.globl _layer_state_set_user
                                    274 	.globl _layer_state_set_kb
                                    275 	.globl _layer_state_set
                                    276 	.globl _layer_clear
                                    277 	.globl _layer_move
                                    278 	.globl _layer_on
                                    279 	.globl _layer_off
                                    280 	.globl _layer_or
                                    281 	.globl _layer_and
                                    282 	.globl _layer_xor
                                    283 	.globl _ak820_cache_keycode
                                    284 	.globl _ak820_cache_layer
                                    285 	.globl _ak820_cached_key
                                    286 	.globl _ak820_resolve_key
                                    287 	.globl _ak820_layer_for_key
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
                                    550 ;--------------------------------------------------------
                                    551 ; overlayable items in internal ram
                                    552 ;--------------------------------------------------------
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
                                    566 ;--------------------------------------------------------
                                    567 ; paged external ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area PSEG    (PAG,XDATA)
                                    570 ;--------------------------------------------------------
                                    571 ; uninitialized external ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area XSEG    (XDATA)
      00083F                        574 _default_layer_state_set_user_state_10000_318:
      00083F                        575 	.ds 1
      000840                        576 _default_layer_state_set_kb_state_10000_320:
      000840                        577 	.ds 1
      000841                        578 _default_layer_state_set_state_10000_322:
      000841                        579 	.ds 1
      000842                        580 _default_layer_set_state_10000_327:
      000842                        581 	.ds 1
      000843                        582 _default_layer_or_state_10000_329:
      000843                        583 	.ds 1
      000844                        584 _default_layer_and_state_10000_331:
      000844                        585 	.ds 1
      000845                        586 _default_layer_xor_state_10000_333:
      000845                        587 	.ds 1
      000846                        588 _persistent_layers:
      000846                        589 	.ds 1
      000847                        590 _layer_refs:
      000847                        591 	.ds 6
      00084D                        592 _macro_layers:
      00084D                        593 	.ds 1
      00084E                        594 _ak820_layer_refresh_state_10000_336:
      00084E                        595 	.ds 1
      00084F                        596 _layer_hold_on_layer_10000_339:
      00084F                        597 	.ds 1
      000850                        598 _layer_hold_off_layer_10000_343:
      000850                        599 	.ds 1
      000851                        600 _layer_state_set_user_state_10000_350:
      000851                        601 	.ds 1
      000852                        602 _layer_state_set_kb_state_10000_352:
      000852                        603 	.ds 1
      000853                        604 _layer_state_set_state_10000_354:
      000853                        605 	.ds 1
      000854                        606 _layer_move_layer_10000_367:
      000854                        607 	.ds 1
      000855                        608 _layer_on_layer_10000_369:
      000855                        609 	.ds 1
      000856                        610 _layer_off_layer_10000_371:
      000856                        611 	.ds 1
      000857                        612 _layer_or_state_10000_375:
      000857                        613 	.ds 1
      000858                        614 _layer_and_state_10000_377:
      000858                        615 	.ds 1
      000859                        616 _layer_xor_state_10000_379:
      000859                        617 	.ds 1
      00085A                        618 _source_keycodes_cache:
      00085A                        619 	.ds 256
      00095A                        620 _encoder_source_keycodes_cache:
      00095A                        621 	.ds 4
      00095E                        622 _source_keycode_cache_slot_position_10000_381:
      00095E                        623 	.ds 2
      000960                        624 _ak820_cache_keycode_PARM_2:
      000960                        625 	.ds 2
      000962                        626 _ak820_cache_keycode_position_10000_387:
      000962                        627 	.ds 2
      000964                        628 _ak820_cache_layer_PARM_2:
      000964                        629 	.ds 1
      000965                        630 _ak820_cache_layer_position_10000_390:
      000965                        631 	.ds 2
      000967                        632 _ak820_cached_key_position_10000_393:
      000967                        633 	.ds 2
      000969                        634 _ak820_resolve_key_PARM_2:
      000969                        635 	.ds 1
      00096A                        636 _ak820_resolve_key_position_10000_404:
      00096A                        637 	.ds 2
      00096C                        638 _ak820_layer_for_key_position_10000_411:
      00096C                        639 	.ds 2
      00096E                        640 _ak820_layer_for_key_layers_10000_412:
      00096E                        641 	.ds 1
                                    642 ;--------------------------------------------------------
                                    643 ; absolute external ram data
                                    644 ;--------------------------------------------------------
                                    645 	.area XABS    (ABS,XDATA)
                                    646 ;--------------------------------------------------------
                                    647 ; initialized external ram data
                                    648 ;--------------------------------------------------------
                                    649 	.area XISEG   (XDATA)
      000DC1                        650 _default_layer_state::
      000DC1                        651 	.ds 1
      000DC2                        652 _layer_state::
      000DC2                        653 	.ds 1
                                    654 	.area HOME    (CODE)
                                    655 	.area GSINIT0 (CODE)
                                    656 	.area GSINIT1 (CODE)
                                    657 	.area GSINIT2 (CODE)
                                    658 	.area GSINIT3 (CODE)
                                    659 	.area GSINIT4 (CODE)
                                    660 	.area GSINIT5 (CODE)
                                    661 	.area GSINIT  (CODE)
                                    662 	.area GSFINAL (CODE)
                                    663 	.area CSEG    (CODE)
                                    664 ;--------------------------------------------------------
                                    665 ; global & static initialisations
                                    666 ;--------------------------------------------------------
                                    667 	.area HOME    (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area GSINIT  (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; Home
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area HOME    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; code
                                    678 ;--------------------------------------------------------
                                    679 	.area CSEG    (CODE)
                                    680 ;------------------------------------------------------------
                                    681 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    682 ;------------------------------------------------------------
                                    683 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_190'
                                    684 ;------------------------------------------------------------
                                    685 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    686 ;	-----------------------------------------
                           000007   687 	ar7 = 0x07
                           000006   688 	ar6 = 0x06
                           000005   689 	ar5 = 0x05
                           000004   690 	ar4 = 0x04
                           000003   691 	ar3 = 0x03
                           000002   692 	ar2 = 0x02
                           000001   693 	ar1 = 0x01
                           000000   694 	ar0 = 0x00
                                    695 ;	 function default_layer_state_set_user
                                    696 ;	-----------------------------------------
      00778F                        697 _default_layer_state_set_user:
      00778F E5 82            [12]  698 	mov	a,dpl
      007791 90 08 3F         [24]  699 	mov	dptr,#_default_layer_state_set_user_state_10000_318
      007794 12 57 97         [24]  700 	lcall	_ak820_outline_0170
                                    701 ;	quantum/action_layer.c:32: return state;
                                    702 ;	quantum/action_layer.c:33: }
      007797 22               [24]  703 	ret
                                    704 ;------------------------------------------------------------
                                    705 ;Allocation info for local variables in function 'default_layer_state_set_kb'
                                    706 ;------------------------------------------------------------
                                    707 ;state         Allocated with name '_default_layer_state_set_kb_state_10000_320'
                                    708 ;------------------------------------------------------------
                                    709 ;	quantum/action_layer.c:39: __attribute__((weak)) layer_state_t default_layer_state_set_kb(layer_state_t state) {
                                    710 ;	-----------------------------------------
                                    711 ;	 function default_layer_state_set_kb
                                    712 ;	-----------------------------------------
      007798                        713 _default_layer_state_set_kb:
      007798 E5 82            [12]  714 	mov	a,dpl
      00779A 90 08 40         [24]  715 	mov	dptr,#_default_layer_state_set_kb_state_10000_320
      00779D 12 57 97         [24]  716 	lcall	_ak820_outline_0170
                                    717 ;	quantum/action_layer.c:40: return default_layer_state_set_user(state);
                                    718 ;	quantum/action_layer.c:41: }
      0077A0 02 77 8F         [24]  719 	ljmp	_default_layer_state_set_user
                                    720 ;------------------------------------------------------------
                                    721 ;Allocation info for local variables in function 'default_layer_state_set'
                                    722 ;------------------------------------------------------------
                                    723 ;state         Allocated with name '_default_layer_state_set_state_10000_322'
                                    724 ;------------------------------------------------------------
                                    725 ;	quantum/action_layer.c:47: static void default_layer_state_set(layer_state_t state) {
                                    726 ;	-----------------------------------------
                                    727 ;	 function default_layer_state_set
                                    728 ;	-----------------------------------------
      0077A3                        729 _default_layer_state_set:
      0077A3 E5 82            [12]  730 	mov	a,dpl
      0077A5 90 08 41         [24]  731 	mov	dptr,#_default_layer_state_set_state_10000_322
      0077A8 12 57 97         [24]  732 	lcall	_ak820_outline_0170
                                    733 ;	quantum/action_layer.c:48: state = default_layer_state_set_kb(state);
      0077AB 12 77 98         [24]  734 	lcall	_default_layer_state_set_kb
      0077AE AF 82            [24]  735 	mov	r7, dpl
      0077B0 90 08 41         [24]  736 	mov	dptr,#_default_layer_state_set_state_10000_322
      0077B3 EF               [12]  737 	mov	a,r7
      0077B4 F0               [24]  738 	movx	@dptr,a
                                    739 ;	quantum/action_layer.c:52: default_layer_state = state;
      0077B5 90 0D C1         [24]  740 	mov	dptr,#_default_layer_state
      0077B8 EF               [12]  741 	mov	a,r7
      0077B9 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action_layer.c:54: ak820_layer_refresh();
                                    744 ;	quantum/action_layer.c:57: ac_dprintf("\n");
                                    745 ;	quantum/action_layer.c:63: }
      0077BA 02 78 02         [24]  746 	ljmp	_ak820_layer_refresh
                                    747 ;------------------------------------------------------------
                                    748 ;Allocation info for local variables in function 'default_layer_set'
                                    749 ;------------------------------------------------------------
                                    750 ;state         Allocated with name '_default_layer_set_state_10000_327'
                                    751 ;------------------------------------------------------------
                                    752 ;	quantum/action_layer.c:79: void default_layer_set(layer_state_t state) {
                                    753 ;	-----------------------------------------
                                    754 ;	 function default_layer_set
                                    755 ;	-----------------------------------------
      0077BD                        756 _default_layer_set:
      0077BD E5 82            [12]  757 	mov	a,dpl
      0077BF 90 08 42         [24]  758 	mov	dptr,#_default_layer_set_state_10000_327
      0077C2 12 57 97         [24]  759 	lcall	_ak820_outline_0170
                                    760 ;	quantum/action_layer.c:80: default_layer_state_set(state);
                                    761 ;	quantum/action_layer.c:81: }
      0077C5 02 77 A3         [24]  762 	ljmp	_default_layer_state_set
                                    763 ;------------------------------------------------------------
                                    764 ;Allocation info for local variables in function 'default_layer_or'
                                    765 ;------------------------------------------------------------
                                    766 ;state         Allocated with name '_default_layer_or_state_10000_329'
                                    767 ;------------------------------------------------------------
                                    768 ;	quantum/action_layer.c:88: void default_layer_or(layer_state_t state) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function default_layer_or
                                    771 ;	-----------------------------------------
      0077C8                        772 _default_layer_or:
      0077C8 E5 82            [12]  773 	mov	a,dpl
      0077CA 90 08 43         [24]  774 	mov	dptr,#_default_layer_or_state_10000_329
      0077CD F0               [24]  775 	movx	@dptr,a
                                    776 ;	quantum/action_layer.c:89: default_layer_state_set(default_layer_state | state);
      0077CE E0               [24]  777 	movx	a,@dptr
      0077CF FF               [12]  778 	mov	r7,a
      0077D0 90 0D C1         [24]  779 	mov	dptr,#_default_layer_state
      0077D3 12 7B 95         [24]  780 	lcall	_ak820_outline_0141
                                    781 ;	quantum/action_layer.c:90: }
      0077D6 02 77 A3         [24]  782 	ljmp	_default_layer_state_set
                                    783 ;------------------------------------------------------------
                                    784 ;Allocation info for local variables in function 'default_layer_and'
                                    785 ;------------------------------------------------------------
                                    786 ;state         Allocated with name '_default_layer_and_state_10000_331'
                                    787 ;------------------------------------------------------------
                                    788 ;	quantum/action_layer.c:95: void default_layer_and(layer_state_t state) {
                                    789 ;	-----------------------------------------
                                    790 ;	 function default_layer_and
                                    791 ;	-----------------------------------------
      0077D9                        792 _default_layer_and:
      0077D9 E5 82            [12]  793 	mov	a,dpl
      0077DB 90 08 44         [24]  794 	mov	dptr,#_default_layer_and_state_10000_331
      0077DE F0               [24]  795 	movx	@dptr,a
                                    796 ;	quantum/action_layer.c:96: default_layer_state_set(default_layer_state & state);
      0077DF 90 0D C1         [24]  797 	mov	dptr,#_default_layer_state
      0077E2 E0               [24]  798 	movx	a,@dptr
      0077E3 FF               [12]  799 	mov	r7,a
      0077E4 90 08 44         [24]  800 	mov	dptr,#_default_layer_and_state_10000_331
      0077E7 E0               [24]  801 	movx	a,@dptr
      0077E8 52 07            [12]  802 	anl	ar7,a
      0077EA 8F 82            [24]  803 	mov	dpl, r7
                                    804 ;	quantum/action_layer.c:97: }
      0077EC 02 77 A3         [24]  805 	ljmp	_default_layer_state_set
                                    806 ;------------------------------------------------------------
                                    807 ;Allocation info for local variables in function 'default_layer_xor'
                                    808 ;------------------------------------------------------------
                                    809 ;state         Allocated with name '_default_layer_xor_state_10000_333'
                                    810 ;------------------------------------------------------------
                                    811 ;	quantum/action_layer.c:102: void default_layer_xor(layer_state_t state) {
                                    812 ;	-----------------------------------------
                                    813 ;	 function default_layer_xor
                                    814 ;	-----------------------------------------
      0077EF                        815 _default_layer_xor:
      0077EF E5 82            [12]  816 	mov	a,dpl
      0077F1 90 08 45         [24]  817 	mov	dptr,#_default_layer_xor_state_10000_333
      0077F4 F0               [24]  818 	movx	@dptr,a
                                    819 ;	quantum/action_layer.c:103: default_layer_state_set(default_layer_state ^ state);
      0077F5 E0               [24]  820 	movx	a,@dptr
      0077F6 FF               [12]  821 	mov	r7,a
      0077F7 90 0D C1         [24]  822 	mov	dptr,#_default_layer_state
      0077FA E0               [24]  823 	movx	a,@dptr
      0077FB 62 07            [12]  824 	xrl	ar7,a
      0077FD 8F 82            [24]  825 	mov	dpl, r7
                                    826 ;	quantum/action_layer.c:104: }
      0077FF 02 77 A3         [24]  827 	ljmp	_default_layer_state_set
                                    828 ;------------------------------------------------------------
                                    829 ;Allocation info for local variables in function 'ak820_layer_refresh'
                                    830 ;------------------------------------------------------------
                                    831 ;state         Allocated with name '_ak820_layer_refresh_state_10000_336'
                                    832 ;i             Allocated with name '_ak820_layer_refresh_i_20000_337'
                                    833 ;------------------------------------------------------------
                                    834 ;	quantum/action_layer.c:114: void ak820_layer_refresh(void) {
                                    835 ;	-----------------------------------------
                                    836 ;	 function ak820_layer_refresh
                                    837 ;	-----------------------------------------
      007802                        838 _ak820_layer_refresh:
                                    839 ;	quantum/action_layer.c:115: layer_state_t state = persistent_layers;
      007802 90 08 46         [24]  840 	mov	dptr,#_persistent_layers
      007805 E0               [24]  841 	movx	a,@dptr
      007806 90 08 4E         [24]  842 	mov	dptr,#_ak820_layer_refresh_state_10000_336
      007809 F0               [24]  843 	movx	@dptr,a
                                    844 ;	quantum/action_layer.c:116: for (uint8_t i = 0; i < MAX_LAYER; ++i) if (layer_refs[i]) state |= (layer_state_t)1 << i;
      00780A 7F 00            [12]  845 	mov	r7,#0x00
      00780C                        846 00105$:
      00780C BF 06 00         [24]  847 	cjne	r7,#0x06,00131$
      00780F                        848 00131$:
      00780F 50 25            [24]  849 	jnc	00103$
      007811 EF               [12]  850 	mov	a,r7
      007812 24 47            [12]  851 	add	a, #_layer_refs
      007814 FD               [12]  852 	mov	r5,a
      007815 E4               [12]  853 	clr	a
      007816 34 08            [12]  854 	addc	a, #(_layer_refs >> 8)
      007818 FE               [12]  855 	mov	r6,a
      007819 12 38 A1         [24]  856 	lcall	_ak820_outline_0135
      00781C E0               [24]  857 	movx	a,@dptr
      00781D 60 14            [24]  858 	jz	00106$
      00781F 8F F0            [24]  859 	mov	b,r7
      007821 05 F0            [12]  860 	inc	b
      007823 74 01            [12]  861 	mov	a,#0x01
      007825 80 02            [24]  862 	sjmp	00135$
      007827                        863 00134$:
      007827 25 E0            [12]  864 	add	a,acc
      007829                        865 00135$:
      007829 D5 F0 FB         [24]  866 	djnz	b,00134$
      00782C FE               [12]  867 	mov	r6,a
      00782D 90 08 4E         [24]  868 	mov	dptr,#_ak820_layer_refresh_state_10000_336
      007830 E0               [24]  869 	movx	a,@dptr
      007831 4E               [12]  870 	orl	a,r6
      007832 F0               [24]  871 	movx	@dptr,a
      007833                        872 00106$:
      007833 0F               [12]  873 	inc	r7
      007834 80 D6            [24]  874 	sjmp	00105$
      007836                        875 00103$:
                                    876 ;	quantum/action_layer.c:118: state |= ak820_tri_layer_derived(state | default_layer_state);
      007836 90 0D C1         [24]  877 	mov	dptr,#_default_layer_state
      007839 E0               [24]  878 	movx	a,@dptr
      00783A FF               [12]  879 	mov	r7,a
      00783B 90 08 4E         [24]  880 	mov	dptr,#_ak820_layer_refresh_state_10000_336
      00783E E0               [24]  881 	movx	a,@dptr
      00783F FE               [12]  882 	mov	r6,a
      007840 42 07            [12]  883 	orl	ar7,a
      007842 8F 82            [24]  884 	mov	dpl, r7
      007844 C0 06            [24]  885 	push	ar6
      007846 12 A6 2C         [24]  886 	lcall	_ak820_tri_layer_derived
      007849 AF 82            [24]  887 	mov	r7, dpl
      00784B D0 06            [24]  888 	pop	ar6
      00784D 90 08 4E         [24]  889 	mov	dptr,#_ak820_layer_refresh_state_10000_336
      007850 EF               [12]  890 	mov	a,r7
      007851 4E               [12]  891 	orl	a,r6
      007852 12 57 97         [24]  892 	lcall	_ak820_outline_0170
                                    893 ;	quantum/action_layer.c:120: layer_state = layer_state_set_kb(state);
      007855 12 78 F4         [24]  894 	lcall	_layer_state_set_kb
      007858 E5 82            [12]  895 	mov	a, dpl
      00785A 90 0D C2         [24]  896 	mov	dptr,#_layer_state
      00785D F0               [24]  897 	movx	@dptr,a
                                    898 ;	quantum/action_layer.c:121: }
      00785E 22               [24]  899 	ret
                                    900 ;------------------------------------------------------------
                                    901 ;Allocation info for local variables in function 'layer_hold_on'
                                    902 ;------------------------------------------------------------
                                    903 ;layer         Allocated with name '_layer_hold_on_layer_10000_339'
                                    904 ;------------------------------------------------------------
                                    905 ;	quantum/action_layer.c:122: void layer_hold_on(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, true)) { ++layer_refs[layer]; ak820_layer_refresh(); } }
                                    906 ;	-----------------------------------------
                                    907 ;	 function layer_hold_on
                                    908 ;	-----------------------------------------
      00785F                        909 _layer_hold_on:
      00785F E5 82            [12]  910 	mov	a,dpl
      007861 90 08 4F         [24]  911 	mov	dptr,#_layer_hold_on_layer_10000_339
      007864 F0               [24]  912 	movx	@dptr,a
      007865 E0               [24]  913 	movx	a,@dptr
      007866 FF               [12]  914 	mov	r7,a
      007867 BF 06 00         [24]  915 	cjne	r7,#0x06,00120$
      00786A                        916 00120$:
      00786A 50 2A            [24]  917 	jnc	00104$
      00786C 12 7B A1         [24]  918 	lcall	_ak820_outline_0176
      00786F 74 01            [12]  919 	mov	a,#0x01
      007871 F0               [24]  920 	movx	@dptr,a
      007872 90 08 4D         [24]  921 	mov	dptr,#_macro_layers
      007875 C0 07            [24]  922 	push	ar7
      007877 12 7B FA         [24]  923 	lcall	_ak820_macro_change
      00787A E5 82            [12]  924 	mov	a, dpl
      00787C D0 07            [24]  925 	pop	ar7
      00787E 60 16            [24]  926 	jz	00104$
      007880 EF               [12]  927 	mov	a,r7
      007881 24 47            [12]  928 	add	a, #_layer_refs
      007883 FF               [12]  929 	mov	r7,a
      007884 E4               [12]  930 	clr	a
      007885 34 08            [12]  931 	addc	a, #(_layer_refs >> 8)
      007887 FE               [12]  932 	mov	r6,a
      007888 12 43 D1         [24]  933 	lcall	_ak820_outline_0158
      00788B E0               [24]  934 	movx	a,@dptr
      00788C FD               [12]  935 	mov	r5,a
      00788D 0D               [12]  936 	inc	r5
      00788E 12 43 D1         [24]  937 	lcall	_ak820_outline_0158
      007891 ED               [12]  938 	mov	a,r5
      007892 F0               [24]  939 	movx	@dptr,a
      007893 02 78 02         [24]  940 	ljmp	_ak820_layer_refresh
      007896                        941 00104$:
      007896 22               [24]  942 	ret
                                    943 ;------------------------------------------------------------
                                    944 ;Allocation info for local variables in function 'layer_hold_off'
                                    945 ;------------------------------------------------------------
                                    946 ;layer         Allocated with name '_layer_hold_off_layer_10000_343'
                                    947 ;------------------------------------------------------------
                                    948 ;	quantum/action_layer.c:123: void layer_hold_off(uint8_t layer) { if (layer < MAX_LAYER && ak820_macro_change(&macro_layers, layer, false) && layer_refs[layer]) { --layer_refs[layer]; ak820_layer_refresh(); } }
                                    949 ;	-----------------------------------------
                                    950 ;	 function layer_hold_off
                                    951 ;	-----------------------------------------
      007897                        952 _layer_hold_off:
      007897 E5 82            [12]  953 	mov	a,dpl
      007899 90 08 50         [24]  954 	mov	dptr,#_layer_hold_off_layer_10000_343
      00789C F0               [24]  955 	movx	@dptr,a
      00789D E0               [24]  956 	movx	a,@dptr
      00789E FF               [12]  957 	mov	r7,a
      00789F BF 06 00         [24]  958 	cjne	r7,#0x06,00128$
      0078A2                        959 00128$:
      0078A2 50 2B            [24]  960 	jnc	00105$
      0078A4 12 7B A1         [24]  961 	lcall	_ak820_outline_0176
      0078A7 E4               [12]  962 	clr	a
      0078A8 F0               [24]  963 	movx	@dptr,a
      0078A9 90 08 4D         [24]  964 	mov	dptr,#_macro_layers
      0078AC C0 07            [24]  965 	push	ar7
      0078AE 12 7B FA         [24]  966 	lcall	_ak820_macro_change
      0078B1 E5 82            [12]  967 	mov	a, dpl
      0078B3 D0 07            [24]  968 	pop	ar7
      0078B5 60 18            [24]  969 	jz	00105$
      0078B7 EF               [12]  970 	mov	a,r7
      0078B8 24 47            [12]  971 	add	a, #_layer_refs
      0078BA FE               [12]  972 	mov	r6,a
      0078BB E4               [12]  973 	clr	a
      0078BC 34 08            [12]  974 	addc	a, #(_layer_refs >> 8)
      0078BE FF               [12]  975 	mov	r7,a
      0078BF 12 38 8C         [24]  976 	lcall	_ak820_outline_0118
      0078C2 E0               [24]  977 	movx	a,@dptr
      0078C3 FD               [12]  978 	mov	r5,a
      0078C4 60 09            [24]  979 	jz	00105$
      0078C6 1D               [12]  980 	dec	r5
      0078C7 12 38 8C         [24]  981 	lcall	_ak820_outline_0118
      0078CA ED               [12]  982 	mov	a,r5
      0078CB F0               [24]  983 	movx	@dptr,a
      0078CC 02 78 02         [24]  984 	ljmp	_ak820_layer_refresh
      0078CF                        985 00105$:
      0078CF 22               [24]  986 	ret
                                    987 ;------------------------------------------------------------
                                    988 ;Allocation info for local variables in function 'layer_hold_clear'
                                    989 ;------------------------------------------------------------
                                    990 ;i             Allocated with name '_layer_hold_clear_i_20000_349'
                                    991 ;------------------------------------------------------------
                                    992 ;	quantum/action_layer.c:124: void layer_hold_clear(void) { macro_layers = 0; for (uint8_t i = 0; i < MAX_LAYER; ++i) layer_refs[i] = 0; ak820_layer_refresh(); }
                                    993 ;	-----------------------------------------
                                    994 ;	 function layer_hold_clear
                                    995 ;	-----------------------------------------
      0078D0                        996 _layer_hold_clear:
      0078D0 90 08 4D         [24]  997 	mov	dptr,#_macro_layers
      0078D3 E4               [12]  998 	clr	a
      0078D4 F0               [24]  999 	movx	@dptr,a
      0078D5 FF               [12] 1000 	mov	r7,a
      0078D6                       1001 00103$:
      0078D6 BF 06 00         [24] 1002 	cjne	r7,#0x06,00122$
      0078D9                       1003 00122$:
      0078D9 50 0D            [24] 1004 	jnc	00101$
      0078DB EF               [12] 1005 	mov	a,r7
      0078DC 24 47            [12] 1006 	add	a, #_layer_refs
      0078DE F5 82            [12] 1007 	mov	dpl,a
      0078E0 E4               [12] 1008 	clr	a
      0078E1 34 08            [12] 1009 	addc	a, #(_layer_refs >> 8)
      0078E3 12 7B 9B         [24] 1010 	lcall	_ak820_outline_0163
      0078E6 80 EE            [24] 1011 	sjmp	00103$
      0078E8                       1012 00101$:
      0078E8 02 78 02         [24] 1013 	ljmp	_ak820_layer_refresh
                                   1014 ;------------------------------------------------------------
                                   1015 ;Allocation info for local variables in function 'layer_state_set_user'
                                   1016 ;------------------------------------------------------------
                                   1017 ;state         Allocated with name '_layer_state_set_user_state_10000_350'
                                   1018 ;------------------------------------------------------------
                                   1019 ;	quantum/action_layer.c:131: __attribute__((weak)) layer_state_t layer_state_set_user(layer_state_t state) {
                                   1020 ;	-----------------------------------------
                                   1021 ;	 function layer_state_set_user
                                   1022 ;	-----------------------------------------
      0078EB                       1023 _layer_state_set_user:
      0078EB E5 82            [12] 1024 	mov	a,dpl
      0078ED 90 08 51         [24] 1025 	mov	dptr,#_layer_state_set_user_state_10000_350
      0078F0 12 57 97         [24] 1026 	lcall	_ak820_outline_0170
                                   1027 ;	quantum/action_layer.c:132: return state;
                                   1028 ;	quantum/action_layer.c:133: }
      0078F3 22               [24] 1029 	ret
                                   1030 ;------------------------------------------------------------
                                   1031 ;Allocation info for local variables in function 'layer_state_set_kb'
                                   1032 ;------------------------------------------------------------
                                   1033 ;state         Allocated with name '_layer_state_set_kb_state_10000_352'
                                   1034 ;------------------------------------------------------------
                                   1035 ;	quantum/action_layer.c:139: __attribute__((weak)) layer_state_t layer_state_set_kb(layer_state_t state) {
                                   1036 ;	-----------------------------------------
                                   1037 ;	 function layer_state_set_kb
                                   1038 ;	-----------------------------------------
      0078F4                       1039 _layer_state_set_kb:
      0078F4 E5 82            [12] 1040 	mov	a,dpl
      0078F6 90 08 52         [24] 1041 	mov	dptr,#_layer_state_set_kb_state_10000_352
      0078F9 12 57 97         [24] 1042 	lcall	_ak820_outline_0170
                                   1043 ;	quantum/action_layer.c:140: return layer_state_set_user(state);
                                   1044 ;	quantum/action_layer.c:141: }
      0078FC 02 78 EB         [24] 1045 	ljmp	_layer_state_set_user
                                   1046 ;------------------------------------------------------------
                                   1047 ;Allocation info for local variables in function 'layer_state_set'
                                   1048 ;------------------------------------------------------------
                                   1049 ;state         Allocated with name '_layer_state_set_state_10000_354'
                                   1050 ;------------------------------------------------------------
                                   1051 ;	quantum/action_layer.c:147: void layer_state_set(layer_state_t state) {
                                   1052 ;	-----------------------------------------
                                   1053 ;	 function layer_state_set
                                   1054 ;	-----------------------------------------
      0078FF                       1055 _layer_state_set:
      0078FF E5 82            [12] 1056 	mov	a,dpl
      007901 90 08 53         [24] 1057 	mov	dptr,#_layer_state_set_state_10000_354
      007904 F0               [24] 1058 	movx	@dptr,a
                                   1059 ;	quantum/action_layer.c:149: persistent_layers = state;
      007905 E0               [24] 1060 	movx	a,@dptr
      007906 90 08 46         [24] 1061 	mov	dptr,#_persistent_layers
      007909 F0               [24] 1062 	movx	@dptr,a
                                   1063 ;	quantum/action_layer.c:150: ak820_layer_refresh();
                                   1064 ;	quantum/action_layer.c:151: return;
                                   1065 ;	quantum/action_layer.c:159: ac_dprintf("\n");
                                   1066 ;	quantum/action_layer.c:165: }
      00790A 02 78 02         [24] 1067 	ljmp	_ak820_layer_refresh
                                   1068 ;------------------------------------------------------------
                                   1069 ;Allocation info for local variables in function 'layer_clear'
                                   1070 ;------------------------------------------------------------
                                   1071 ;	quantum/action_layer.c:171: void layer_clear(void) {
                                   1072 ;	-----------------------------------------
                                   1073 ;	 function layer_clear
                                   1074 ;	-----------------------------------------
      00790D                       1075 _layer_clear:
                                   1076 ;	quantum/action_layer.c:172: layer_state_set(0);
      00790D 75 82 00         [24] 1077 	mov	dpl, #0x00
                                   1078 ;	quantum/action_layer.c:173: }
      007910 02 78 FF         [24] 1079 	ljmp	_layer_state_set
                                   1080 ;------------------------------------------------------------
                                   1081 ;Allocation info for local variables in function 'layer_state_is'
                                   1082 ;------------------------------------------------------------
                                   1083 ;layer         Allocated with name '_layer_state_is_layer_10000_361'
                                   1084 ;------------------------------------------------------------
                                   1085 ;	quantum/action_layer.c:179: bool layer_state_is(uint8_t layer) {
                                   1086 ;	-----------------------------------------
                                   1087 ;	 function layer_move
                                   1088 ;	-----------------------------------------
      007913                       1089 _layer_move:
      007913 E5 82            [12] 1090 	mov	a,dpl
      007915 90 08 54         [24] 1091 	mov	dptr,#_layer_move_layer_10000_367
      007918 F0               [24] 1092 	movx	@dptr,a
                                   1093 ;	quantum/action_layer.c:199: layer_state_set((layer_state_t)1 << layer);
      007919 E0               [24] 1094 	movx	a,@dptr
      00791A 12 77 3C         [24] 1095 	lcall	_ak820_outline_0061
      00791D 80 02            [24] 1096 	sjmp	00104$
      00791F                       1097 00103$:
      00791F 25 E0            [12] 1098 	add	a,acc
      007921                       1099 00104$:
      007921 D5 F0 FB         [24] 1100 	djnz	b,00103$
      007924 F5 82            [12] 1101 	mov	dpl,a
                                   1102 ;	quantum/action_layer.c:200: }
      007926 02 78 FF         [24] 1103 	ljmp	_layer_state_set
                                   1104 ;------------------------------------------------------------
                                   1105 ;Allocation info for local variables in function 'layer_on'
                                   1106 ;------------------------------------------------------------
                                   1107 ;layer         Allocated with name '_layer_on_layer_10000_369'
                                   1108 ;------------------------------------------------------------
                                   1109 ;	quantum/action_layer.c:206: void layer_on(uint8_t layer) {
                                   1110 ;	-----------------------------------------
                                   1111 ;	 function layer_on
                                   1112 ;	-----------------------------------------
      007929                       1113 _layer_on:
      007929 E5 82            [12] 1114 	mov	a,dpl
      00792B 90 08 55         [24] 1115 	mov	dptr,#_layer_on_layer_10000_369
      00792E F0               [24] 1116 	movx	@dptr,a
                                   1117 ;	quantum/action_layer.c:213: ((layer_state_t)1 << layer));
      00792F E0               [24] 1118 	movx	a,@dptr
      007930 12 77 3C         [24] 1119 	lcall	_ak820_outline_0061
      007933 80 02            [24] 1120 	sjmp	00104$
      007935                       1121 00103$:
      007935 25 E0            [12] 1122 	add	a,acc
      007937                       1123 00104$:
      007937 D5 F0 FB         [24] 1124 	djnz	b,00103$
      00793A FF               [12] 1125 	mov	r7,a
      00793B 90 08 46         [24] 1126 	mov	dptr,#_persistent_layers
      00793E 12 7B 95         [24] 1127 	lcall	_ak820_outline_0141
                                   1128 ;	quantum/action_layer.c:214: }
      007941 02 78 FF         [24] 1129 	ljmp	_layer_state_set
                                   1130 ;------------------------------------------------------------
                                   1131 ;Allocation info for local variables in function 'layer_off'
                                   1132 ;------------------------------------------------------------
                                   1133 ;layer         Allocated with name '_layer_off_layer_10000_371'
                                   1134 ;------------------------------------------------------------
                                   1135 ;	quantum/action_layer.c:220: void layer_off(uint8_t layer) {
                                   1136 ;	-----------------------------------------
                                   1137 ;	 function layer_off
                                   1138 ;	-----------------------------------------
      007944                       1139 _layer_off:
      007944 E5 82            [12] 1140 	mov	a,dpl
      007946 90 08 56         [24] 1141 	mov	dptr,#_layer_off_layer_10000_371
      007949 F0               [24] 1142 	movx	@dptr,a
                                   1143 ;	quantum/action_layer.c:227: ~((layer_state_t)1 << layer));
      00794A E0               [24] 1144 	movx	a,@dptr
      00794B 12 77 3C         [24] 1145 	lcall	_ak820_outline_0061
      00794E 80 02            [24] 1146 	sjmp	00104$
      007950                       1147 00103$:
      007950 25 E0            [12] 1148 	add	a,acc
      007952                       1149 00104$:
      007952 D5 F0 FB         [24] 1150 	djnz	b,00103$
      007955 F4               [12] 1151 	cpl	a
      007956 FF               [12] 1152 	mov	r7,a
      007957 90 08 46         [24] 1153 	mov	dptr,#_persistent_layers
      00795A E0               [24] 1154 	movx	a,@dptr
      00795B 52 07            [12] 1155 	anl	ar7,a
      00795D 8F 82            [24] 1156 	mov	dpl, r7
                                   1157 ;	quantum/action_layer.c:228: }
      00795F 02 78 FF         [24] 1158 	ljmp	_layer_state_set
                                   1159 ;------------------------------------------------------------
                                   1160 ;Allocation info for local variables in function 'layer_invert'
                                   1161 ;------------------------------------------------------------
                                   1162 ;layer         Allocated with name '_layer_invert_layer_10000_373'
                                   1163 ;------------------------------------------------------------
                                   1164 ;	quantum/action_layer.c:234: void layer_invert(uint8_t layer) {
                                   1165 ;	-----------------------------------------
                                   1166 ;	 function layer_or
                                   1167 ;	-----------------------------------------
      007962                       1168 _layer_or:
      007962 E5 82            [12] 1169 	mov	a,dpl
      007964 90 08 57         [24] 1170 	mov	dptr,#_layer_or_state_10000_375
      007967 F0               [24] 1171 	movx	@dptr,a
                                   1172 ;	quantum/action_layer.c:255: state);
      007968 E0               [24] 1173 	movx	a,@dptr
      007969 FF               [12] 1174 	mov	r7,a
      00796A 90 08 46         [24] 1175 	mov	dptr,#_persistent_layers
      00796D 12 7B 95         [24] 1176 	lcall	_ak820_outline_0141
                                   1177 ;	quantum/action_layer.c:256: }
      007970 02 78 FF         [24] 1178 	ljmp	_layer_state_set
                                   1179 ;------------------------------------------------------------
                                   1180 ;Allocation info for local variables in function 'layer_and'
                                   1181 ;------------------------------------------------------------
                                   1182 ;state         Allocated with name '_layer_and_state_10000_377'
                                   1183 ;------------------------------------------------------------
                                   1184 ;	quantum/action_layer.c:261: void layer_and(layer_state_t state) {
                                   1185 ;	-----------------------------------------
                                   1186 ;	 function layer_and
                                   1187 ;	-----------------------------------------
      007973                       1188 _layer_and:
      007973 E5 82            [12] 1189 	mov	a,dpl
      007975 90 08 58         [24] 1190 	mov	dptr,#_layer_and_state_10000_377
      007978 F0               [24] 1191 	movx	@dptr,a
                                   1192 ;	quantum/action_layer.c:268: state);
      007979 90 08 46         [24] 1193 	mov	dptr,#_persistent_layers
      00797C E0               [24] 1194 	movx	a,@dptr
      00797D FF               [12] 1195 	mov	r7,a
      00797E 90 08 58         [24] 1196 	mov	dptr,#_layer_and_state_10000_377
      007981 E0               [24] 1197 	movx	a,@dptr
      007982 52 07            [12] 1198 	anl	ar7,a
      007984 8F 82            [24] 1199 	mov	dpl, r7
                                   1200 ;	quantum/action_layer.c:269: }
      007986 02 78 FF         [24] 1201 	ljmp	_layer_state_set
                                   1202 ;------------------------------------------------------------
                                   1203 ;Allocation info for local variables in function 'layer_xor'
                                   1204 ;------------------------------------------------------------
                                   1205 ;state         Allocated with name '_layer_xor_state_10000_379'
                                   1206 ;------------------------------------------------------------
                                   1207 ;	quantum/action_layer.c:274: void layer_xor(layer_state_t state) {
                                   1208 ;	-----------------------------------------
                                   1209 ;	 function layer_xor
                                   1210 ;	-----------------------------------------
      007989                       1211 _layer_xor:
      007989 E5 82            [12] 1212 	mov	a,dpl
      00798B 90 08 59         [24] 1213 	mov	dptr,#_layer_xor_state_10000_379
      00798E F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	quantum/action_layer.c:281: state);
      00798F E0               [24] 1216 	movx	a,@dptr
      007990 FF               [12] 1217 	mov	r7,a
      007991 90 08 46         [24] 1218 	mov	dptr,#_persistent_layers
      007994 E0               [24] 1219 	movx	a,@dptr
      007995 62 07            [12] 1220 	xrl	ar7,a
      007997 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	quantum/action_layer.c:282: }
      007999 02 78 FF         [24] 1223 	ljmp	_layer_state_set
                                   1224 ;------------------------------------------------------------
                                   1225 ;Allocation info for local variables in function 'source_keycode_cache_slot'
                                   1226 ;------------------------------------------------------------
                                   1227 ;position      Allocated with name '_source_keycode_cache_slot_position_10000_381'
                                   1228 ;row           Allocated with name '_source_keycode_cache_slot_row_10000_382'
                                   1229 ;col           Allocated with name '_source_keycode_cache_slot_col_10000_382'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/action_layer.c:324: static uint16_t SOURCE_CACHE_MEM *source_keycode_cache_slot(uint16_t position) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function source_keycode_cache_slot
                                   1234 ;	-----------------------------------------
      00799C                       1235 _source_keycode_cache_slot:
      00799C 12 38 82         [24] 1236 	lcall	_ak820_outline_0107
      00799F 90 09 5E         [24] 1237 	mov	dptr,#_source_keycode_cache_slot_position_10000_381
      0079A2 12 38 87         [24] 1238 	lcall	_ak820_outline_0108
                                   1239 ;	quantum/action_layer.c:325: uint8_t row = position >> 8, col = position;
      0079A5 90 09 5E         [24] 1240 	mov	dptr,#_source_keycode_cache_slot_position_10000_381
      0079A8 E0               [24] 1241 	movx	a,@dptr
      0079A9 FE               [12] 1242 	mov	r6,a
      0079AA A3               [24] 1243 	inc	dptr
      0079AB E0               [24] 1244 	movx	a,@dptr
      0079AC FD               [12] 1245 	mov	r5,a
                                   1246 ;	quantum/action_layer.c:326: if (row < MATRIX_ROWS && col < MATRIX_COLS) {
      0079AD BD 10 00         [24] 1247 	cjne	r5,#0x10,00147$
      0079B0                       1248 00147$:
      0079B0 50 21            [24] 1249 	jnc	00102$
      0079B2 BE 08 00         [24] 1250 	cjne	r6,#0x08,00149$
      0079B5                       1251 00149$:
      0079B5 50 1C            [24] 1252 	jnc	00102$
                                   1253 ;	quantum/action_layer.c:327: return &source_keycodes_cache[(uint8_t)(row * MATRIX_COLS + col)];
      0079B7 8D 07            [24] 1254 	mov	ar7,r5
      0079B9 EF               [12] 1255 	mov	a,r7
      0079BA 12 38 C6         [24] 1256 	lcall	_ak820_outline_0190
      0079BD FF               [12] 1257 	mov	r7,a
      0079BE 8E 04            [24] 1258 	mov	ar4,r6
      0079C0 EC               [12] 1259 	mov	a,r4
      0079C1 2F               [12] 1260 	add	a, r7
      0079C2 75 F0 02         [24] 1261 	mov	b,#0x02
      0079C5 A4               [48] 1262 	mul	ab
      0079C6 24 5A            [12] 1263 	add	a, #_source_keycodes_cache
      0079C8 FC               [12] 1264 	mov	r4,a
      0079C9 74 08            [12] 1265 	mov	a,#(_source_keycodes_cache >> 8)
      0079CB 35 F0            [12] 1266 	addc	a, b
      0079CD FF               [12] 1267 	mov	r7,a
      0079CE 8C 82            [24] 1268 	mov	dpl, r4
      0079D0 8F 83            [24] 1269 	mov	dph, r7
      0079D2 22               [24] 1270 	ret
      0079D3                       1271 00102$:
                                   1272 ;	quantum/action_layer.c:330: if ((row == KEYLOC_ENCODER_CW || row == KEYLOC_ENCODER_CCW) && col < NUM_ENCODERS) {
      0079D3 BD FD 02         [24] 1273 	cjne	r5,#0xfd,00151$
      0079D6 80 03            [24] 1274 	sjmp	00107$
      0079D8                       1275 00151$:
      0079D8 BD FC 2E         [24] 1276 	cjne	r5,#0xfc,00105$
      0079DB                       1277 00107$:
      0079DB BE 01 00         [24] 1278 	cjne	r6,#0x01,00154$
      0079DE                       1279 00154$:
      0079DE 50 29            [24] 1280 	jnc	00105$
                                   1281 ;	quantum/action_layer.c:331: return &encoder_source_keycodes_cache[col + (row == KEYLOC_ENCODER_CCW ? NUM_ENCODERS : 0)];
      0079E0 BD FC 04         [24] 1282 	cjne	r5,#0xfc,00110$
      0079E3 7F 01            [12] 1283 	mov	r7,#0x01
      0079E5 80 02            [24] 1284 	sjmp	00111$
      0079E7                       1285 00110$:
      0079E7 7F 00            [12] 1286 	mov	r7,#0x00
      0079E9                       1287 00111$:
      0079E9 C2 D5            [12] 1288 	clr	F0
      0079EB 75 F0 02         [24] 1289 	mov	b,#0x02
      0079EE EF               [12] 1290 	mov	a,r7
      0079EF 30 E7 04         [24] 1291 	jnb	acc.7,00158$
      0079F2 B2 D5            [12] 1292 	cpl	F0
      0079F4 F4               [12] 1293 	cpl	a
      0079F5 04               [12] 1294 	inc	a
      0079F6                       1295 00158$:
      0079F6 A4               [48] 1296 	mul	ab
      0079F7 30 D5 03         [24] 1297 	jnb	F0,00159$
      0079FA 12 6F F2         [24] 1298 	lcall	_ak820_outline_0129
      0079FD                       1299 00159$:
      0079FD 24 5A            [12] 1300 	add	a, #_encoder_source_keycodes_cache
      0079FF FE               [12] 1301 	mov	r6,a
      007A00 74 09            [12] 1302 	mov	a,#(_encoder_source_keycodes_cache >> 8)
      007A02 35 F0            [12] 1303 	addc	a, b
      007A04 FF               [12] 1304 	mov	r7,a
      007A05 12 38 8C         [24] 1305 	lcall	_ak820_outline_0118
      007A08 22               [24] 1306 	ret
      007A09                       1307 00105$:
                                   1308 ;	quantum/action_layer.c:334: return 0;
      007A09 90 00 00         [24] 1309 	mov	dptr,#0x0000
                                   1310 ;	quantum/action_layer.c:335: }
      007A0C 22               [24] 1311 	ret
                                   1312 ;------------------------------------------------------------
                                   1313 ;Allocation info for local variables in function 'ak820_cache_keycode'
                                   1314 ;------------------------------------------------------------
                                   1315 ;keycode       Allocated with name '_ak820_cache_keycode_PARM_2'
                                   1316 ;position      Allocated with name '_ak820_cache_keycode_position_10000_387'
                                   1317 ;slot          Allocated with name '_ak820_cache_keycode_slot_10000_388'
                                   1318 ;------------------------------------------------------------
                                   1319 ;	quantum/action_layer.c:339: bool ak820_cache_keycode(uint16_t position, uint16_t keycode) {
                                   1320 ;	-----------------------------------------
                                   1321 ;	 function ak820_cache_keycode
                                   1322 ;	-----------------------------------------
      007A0D                       1323 _ak820_cache_keycode:
      007A0D 12 38 82         [24] 1324 	lcall	_ak820_outline_0107
      007A10 90 09 62         [24] 1325 	mov	dptr,#_ak820_cache_keycode_position_10000_387
      007A13 12 38 87         [24] 1326 	lcall	_ak820_outline_0108
                                   1327 ;	quantum/action_layer.c:340: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007A16 90 09 62         [24] 1328 	mov	dptr,#_ak820_cache_keycode_position_10000_387
      007A19 12 37 F4         [24] 1329 	lcall	_ak820_outline_0005
      007A1C 12 79 9C         [24] 1330 	lcall	_source_keycode_cache_slot
      007A1F 12 43 BB         [24] 1331 	lcall	_ak820_outline_0133
                                   1332 ;	quantum/action_layer.c:341: if (!slot) return false;
      007A22 EE               [12] 1333 	mov	a,r6
      007A23 4F               [12] 1334 	orl	a,r7
      007A24 70 03            [24] 1335 	jnz	00102$
      007A26 F5 82            [12] 1336 	mov	dpl,a
      007A28 22               [24] 1337 	ret
      007A29                       1338 00102$:
                                   1339 ;	quantum/action_layer.c:342: *slot = keycode;
      007A29 90 09 60         [24] 1340 	mov	dptr,#_ak820_cache_keycode_PARM_2
      007A2C 12 38 58         [24] 1341 	lcall	_ak820_outline_0059
      007A2F 12 38 8C         [24] 1342 	lcall	_ak820_outline_0118
      007A32 12 38 5E         [24] 1343 	lcall	_ak820_outline_0072
                                   1344 ;	quantum/action_layer.c:343: return true;
      007A35 75 82 01         [24] 1345 	mov	dpl, #0x01
                                   1346 ;	quantum/action_layer.c:344: }
      007A38 22               [24] 1347 	ret
                                   1348 ;------------------------------------------------------------
                                   1349 ;Allocation info for local variables in function 'ak820_cache_layer'
                                   1350 ;------------------------------------------------------------
                                   1351 ;layer         Allocated with name '_ak820_cache_layer_PARM_2'
                                   1352 ;position      Allocated with name '_ak820_cache_layer_position_10000_390'
                                   1353 ;slot          Allocated with name '_ak820_cache_layer_slot_10000_391'
                                   1354 ;------------------------------------------------------------
                                   1355 ;	quantum/action_layer.c:346: void ak820_cache_layer(uint16_t position, uint8_t layer) {
                                   1356 ;	-----------------------------------------
                                   1357 ;	 function ak820_cache_layer
                                   1358 ;	-----------------------------------------
      007A39                       1359 _ak820_cache_layer:
      007A39 12 38 82         [24] 1360 	lcall	_ak820_outline_0107
      007A3C 90 09 65         [24] 1361 	mov	dptr,#_ak820_cache_layer_position_10000_390
      007A3F 12 38 87         [24] 1362 	lcall	_ak820_outline_0108
                                   1363 ;	quantum/action_layer.c:347: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007A42 90 09 65         [24] 1364 	mov	dptr,#_ak820_cache_layer_position_10000_390
      007A45 12 37 F4         [24] 1365 	lcall	_ak820_outline_0005
      007A48 C0 07            [24] 1366 	push	ar7
      007A4A C0 06            [24] 1367 	push	ar6
      007A4C 12 79 9C         [24] 1368 	lcall	_source_keycode_cache_slot
      007A4F 12 43 CC         [24] 1369 	lcall	_ak820_outline_0149
      007A52 D0 06            [24] 1370 	pop	ar6
      007A54 D0 07            [24] 1371 	pop	ar7
                                   1372 ;	quantum/action_layer.c:348: if (!slot) return;
      007A56 EC               [12] 1373 	mov	a,r4
      007A57 4D               [12] 1374 	orl	a,r5
      007A58 70 01            [24] 1375 	jnz	00102$
      007A5A 22               [24] 1376 	ret
      007A5B                       1377 00102$:
                                   1378 ;	quantum/action_layer.c:349: layer &= (1u << MAX_LAYER_BITS) - 1;
      007A5B 90 09 64         [24] 1379 	mov	dptr,#_ak820_cache_layer_PARM_2
      007A5E E0               [24] 1380 	movx	a,@dptr
      007A5F 53 E0 07         [24] 1381 	anl	acc,#0x07
      007A62 F0               [24] 1382 	movx	@dptr,a
                                   1383 ;	quantum/action_layer.c:361: *slot = ak820_keycode_at(layer, position);
      007A63 90 09 64         [24] 1384 	mov	dptr,#_ak820_cache_layer_PARM_2
      007A66 E0               [24] 1385 	movx	a,@dptr
      007A67 FB               [12] 1386 	mov	r3,a
      007A68 90 0B 98         [24] 1387 	mov	dptr,#_ak820_keycode_at_PARM_2
      007A6B 12 49 00         [24] 1388 	lcall	_ak820_outline_0058
      007A6E 8B 82            [24] 1389 	mov	dpl, r3
      007A70 C0 05            [24] 1390 	push	ar5
      007A72 C0 04            [24] 1391 	push	ar4
      007A74 12 96 89         [24] 1392 	lcall	_ak820_keycode_at
      007A77 12 43 BB         [24] 1393 	lcall	_ak820_outline_0133
      007A7A D0 04            [24] 1394 	pop	ar4
      007A7C D0 05            [24] 1395 	pop	ar5
      007A7E 12 38 97         [24] 1396 	lcall	_ak820_outline_0124
      007A81 12 49 00         [24] 1397 	lcall	_ak820_outline_0058
                                   1398 ;	quantum/action_layer.c:362: }
      007A84 22               [24] 1399 	ret
                                   1400 ;------------------------------------------------------------
                                   1401 ;Allocation info for local variables in function 'ak820_cached_key'
                                   1402 ;------------------------------------------------------------
                                   1403 ;position      Allocated with name '_ak820_cached_key_position_10000_393'
                                   1404 ;slot          Allocated with name '_ak820_cached_key_slot_10001_397'
                                   1405 ;------------------------------------------------------------
                                   1406 ;	quantum/action_layer.c:383: uint16_t ak820_cached_key(uint16_t position) {
                                   1407 ;	-----------------------------------------
                                   1408 ;	 function ak820_cached_key
                                   1409 ;	-----------------------------------------
      007A85                       1410 _ak820_cached_key:
      007A85 12 38 82         [24] 1411 	lcall	_ak820_outline_0107
      007A88 90 09 67         [24] 1412 	mov	dptr,#_ak820_cached_key_position_10000_393
      007A8B 12 38 87         [24] 1413 	lcall	_ak820_outline_0108
                                   1414 ;	quantum/action_layer.c:386: if (vial_unlock_in_progress) return KC_NO;
      007A8E 90 0E 21         [24] 1415 	mov	dptr,#_vial_unlock_in_progress
      007A91 E0               [24] 1416 	movx	a,@dptr
      007A92 60 04            [24] 1417 	jz	00102$
      007A94 90 00 00         [24] 1418 	mov	dptr,#0x0000
      007A97 22               [24] 1419 	ret
      007A98                       1420 00102$:
                                   1421 ;	quantum/action_layer.c:387: if (position == (((uint16_t)VIAL_MATRIX_MAGIC << 8) | VIAL_MATRIX_MAGIC)) return g_vial_magic_keycode_override;
      007A98 90 09 67         [24] 1422 	mov	dptr,#_ak820_cached_key_position_10000_393
      007A9B 12 38 41         [24] 1423 	lcall	_ak820_outline_0051
      007A9E BE F0 0D         [24] 1424 	cjne	r6,#0xf0,00104$
      007AA1 BF F0 0A         [24] 1425 	cjne	r7,#0xf0,00104$
      007AA4 90 0C 78         [24] 1426 	mov	dptr,#_g_vial_magic_keycode_override
      007AA7 12 38 58         [24] 1427 	lcall	_ak820_outline_0059
      007AAA 12 38 97         [24] 1428 	lcall	_ak820_outline_0124
      007AAD 22               [24] 1429 	ret
      007AAE                       1430 00104$:
                                   1431 ;	quantum/action_layer.c:389: uint16_t SOURCE_CACHE_MEM *slot = source_keycode_cache_slot(position);
      007AAE 12 38 8C         [24] 1432 	lcall	_ak820_outline_0118
      007AB1 12 79 9C         [24] 1433 	lcall	_source_keycode_cache_slot
      007AB4 12 43 BB         [24] 1434 	lcall	_ak820_outline_0133
                                   1435 ;	quantum/action_layer.c:390: return slot ? *slot : KC_NO;
      007AB7 EE               [12] 1436 	mov	a,r6
      007AB8 4F               [12] 1437 	orl	a,r7
      007AB9 60 08            [24] 1438 	jz	00107$
      007ABB 12 38 8C         [24] 1439 	lcall	_ak820_outline_0118
      007ABE 12 38 41         [24] 1440 	lcall	_ak820_outline_0051
      007AC1 80 04            [24] 1441 	sjmp	00108$
      007AC3                       1442 00107$:
      007AC3 7E 00            [12] 1443 	mov	r6,#0x00
      007AC5 7F 00            [12] 1444 	mov	r7,#0x00
      007AC7                       1445 00108$:
      007AC7 12 38 8C         [24] 1446 	lcall	_ak820_outline_0118
                                   1447 ;	quantum/action_layer.c:391: }
      007ACA 22               [24] 1448 	ret
                                   1449 ;------------------------------------------------------------
                                   1450 ;Allocation info for local variables in function 'update_source_keycode_cache'
                                   1451 ;------------------------------------------------------------
                                   1452 ;key           Allocated with name '_update_source_keycode_cache_PARM_1'
                                   1453 ;keycode       Allocated with name '_update_source_keycode_cache_keycode_10000_398'
                                   1454 ;------------------------------------------------------------
                                   1455 ;	quantum/action_layer.c:394: bool update_source_keycode_cache(keypos_t key, uint16_t keycode) {
                                   1456 ;	-----------------------------------------
                                   1457 ;	 function ak820_resolve_key
                                   1458 ;	-----------------------------------------
      007ACB                       1459 _ak820_resolve_key:
      007ACB 12 38 82         [24] 1460 	lcall	_ak820_outline_0107
      007ACE 90 09 6A         [24] 1461 	mov	dptr,#_ak820_resolve_key_position_10000_404
      007AD1 12 38 87         [24] 1462 	lcall	_ak820_outline_0108
                                   1463 ;	quantum/action_layer.c:493: if (disable_action_cache) {
      007AD4 90 0D C0         [24] 1464 	mov	dptr,#_disable_action_cache
      007AD7 E0               [24] 1465 	movx	a,@dptr
      007AD8 60 1E            [24] 1466 	jz	00102$
                                   1467 ;	quantum/action_layer.c:494: return ak820_keycode_at(ak820_layer_for_key(position), position);
      007ADA 90 09 6A         [24] 1468 	mov	dptr,#_ak820_resolve_key_position_10000_404
      007ADD 12 37 F4         [24] 1469 	lcall	_ak820_outline_0005
      007AE0 C0 07            [24] 1470 	push	ar7
      007AE2 C0 06            [24] 1471 	push	ar6
      007AE4 12 7B 23         [24] 1472 	lcall	_ak820_layer_for_key
      007AE7 AD 82            [24] 1473 	mov	r5, dpl
      007AE9 D0 06            [24] 1474 	pop	ar6
      007AEB D0 07            [24] 1475 	pop	ar7
      007AED 90 0B 98         [24] 1476 	mov	dptr,#_ak820_keycode_at_PARM_2
      007AF0 12 49 00         [24] 1477 	lcall	_ak820_outline_0058
      007AF3 8D 82            [24] 1478 	mov	dpl, r5
      007AF5 02 96 89         [24] 1479 	ljmp	_ak820_keycode_at
      007AF8                       1480 00102$:
                                   1481 ;	quantum/action_layer.c:496: if (cache_press) ak820_cache_layer(position, ak820_layer_for_key(position));
      007AF8 90 09 69         [24] 1482 	mov	dptr,#_ak820_resolve_key_PARM_2
      007AFB E0               [24] 1483 	movx	a,@dptr
      007AFC 60 1C            [24] 1484 	jz	00104$
      007AFE 90 09 6A         [24] 1485 	mov	dptr,#_ak820_resolve_key_position_10000_404
      007B01 12 37 F4         [24] 1486 	lcall	_ak820_outline_0005
      007B04 C0 07            [24] 1487 	push	ar7
      007B06 C0 06            [24] 1488 	push	ar6
      007B08 12 7B 23         [24] 1489 	lcall	_ak820_layer_for_key
      007B0B E5 82            [12] 1490 	mov	a, dpl
      007B0D D0 06            [24] 1491 	pop	ar6
      007B0F D0 07            [24] 1492 	pop	ar7
      007B11 90 09 64         [24] 1493 	mov	dptr,#_ak820_cache_layer_PARM_2
      007B14 12 43 9D         [24] 1494 	lcall	_ak820_outline_0071
      007B17 12 7A 39         [24] 1495 	lcall	_ak820_cache_layer
      007B1A                       1496 00104$:
                                   1497 ;	quantum/action_layer.c:497: return ak820_cached_key(position);
      007B1A 90 09 6A         [24] 1498 	mov	dptr,#_ak820_resolve_key_position_10000_404
      007B1D 12 37 F4         [24] 1499 	lcall	_ak820_outline_0005
                                   1500 ;	quantum/action_layer.c:498: }
      007B20 02 7A 85         [24] 1501 	ljmp	_ak820_cached_key
                                   1502 ;------------------------------------------------------------
                                   1503 ;Allocation info for local variables in function 'store_or_get_action'
                                   1504 ;------------------------------------------------------------
                                   1505 ;key           Allocated with name '_store_or_get_action_PARM_2'
                                   1506 ;pressed       Allocated with name '_store_or_get_action_pressed_10000_409'
                                   1507 ;------------------------------------------------------------
                                   1508 ;	quantum/action_layer.c:499: uint16_t store_or_get_action(bool pressed, keypos_t key) {
                                   1509 ;	-----------------------------------------
                                   1510 ;	 function ak820_layer_for_key
                                   1511 ;	-----------------------------------------
      007B23                       1512 _ak820_layer_for_key:
      007B23 12 38 82         [24] 1513 	lcall	_ak820_outline_0107
      007B26 90 09 6C         [24] 1514 	mov	dptr,#_ak820_layer_for_key_position_10000_411
      007B29 12 38 87         [24] 1515 	lcall	_ak820_outline_0108
                                   1516 ;	quantum/action_layer.c:539: layer_state_t layers = layer_state | default_layer_state;
      007B2C 90 0D C1         [24] 1517 	mov	dptr,#_default_layer_state
      007B2F E0               [24] 1518 	movx	a,@dptr
      007B30 FF               [12] 1519 	mov	r7,a
      007B31 90 0D C2         [24] 1520 	mov	dptr,#_layer_state
      007B34 E0               [24] 1521 	movx	a,@dptr
      007B35 90 09 6E         [24] 1522 	mov	dptr,#_ak820_layer_for_key_layers_10000_412
      007B38 4F               [12] 1523 	orl	a,r7
      007B39 F0               [24] 1524 	movx	@dptr,a
                                   1525 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007B3A 90 09 6C         [24] 1526 	mov	dptr,#_ak820_layer_for_key_position_10000_411
      007B3D 12 38 41         [24] 1527 	lcall	_ak820_outline_0051
      007B40 7D 05            [12] 1528 	mov	r5,#0x05
      007B42                       1529 00107$:
      007B42 ED               [12] 1530 	mov	a,r5
      007B43 20 E7 4B         [24] 1531 	jb	acc.7,00105$
                                   1532 ;	quantum/action_layer.c:542: if (layers & ((layer_state_t)1 << i)) {
      007B46 8D F0            [24] 1533 	mov	b,r5
      007B48 05 F0            [12] 1534 	inc	b
      007B4A 7B 01            [12] 1535 	mov	r3,#0x01
      007B4C 7C 00            [12] 1536 	mov	r4,#0x00
      007B4E 80 06            [24] 1537 	sjmp	00141$
      007B50                       1538 00140$:
      007B50 EB               [12] 1539 	mov	a,r3
      007B51 2B               [12] 1540 	add	a,r3
      007B52 FB               [12] 1541 	mov	r3,a
      007B53 EC               [12] 1542 	mov	a,r4
      007B54 33               [12] 1543 	rlc	a
      007B55 FC               [12] 1544 	mov	r4,a
      007B56                       1545 00141$:
      007B56 D5 F0 F7         [24] 1546 	djnz	b,00140$
      007B59 90 09 6E         [24] 1547 	mov	dptr,#_ak820_layer_for_key_layers_10000_412
      007B5C E0               [24] 1548 	movx	a,@dptr
      007B5D 7A 00            [12] 1549 	mov	r2,#0x00
      007B5F 52 03            [12] 1550 	anl	ar3,a
      007B61 EA               [12] 1551 	mov	a,r2
      007B62 52 04            [12] 1552 	anl	ar4,a
      007B64 EB               [12] 1553 	mov	a,r3
      007B65 4C               [12] 1554 	orl	a,r4
      007B66 60 26            [24] 1555 	jz	00108$
                                   1556 ;	quantum/action_layer.c:546: if (ak820_keycode_at(i, position) != KC_TRANSPARENT) {
      007B68 90 0B 98         [24] 1557 	mov	dptr,#_ak820_keycode_at_PARM_2
      007B6B 12 49 00         [24] 1558 	lcall	_ak820_outline_0058
      007B6E 8D 82            [24] 1559 	mov	dpl, r5
      007B70 C0 07            [24] 1560 	push	ar7
      007B72 C0 06            [24] 1561 	push	ar6
      007B74 C0 05            [24] 1562 	push	ar5
      007B76 12 96 89         [24] 1563 	lcall	_ak820_keycode_at
      007B79 AB 82            [24] 1564 	mov	r3, dpl
      007B7B AC 83            [24] 1565 	mov	r4, dph
      007B7D D0 05            [24] 1566 	pop	ar5
      007B7F D0 06            [24] 1567 	pop	ar6
      007B81 D0 07            [24] 1568 	pop	ar7
      007B83 BB 01 05         [24] 1569 	cjne	r3,#0x01,00143$
      007B86 BC 00 02         [24] 1570 	cjne	r4,#0x00,00143$
      007B89 80 03            [24] 1571 	sjmp	00108$
      007B8B                       1572 00143$:
                                   1573 ;	quantum/action_layer.c:555: return i;
      007B8B 8D 82            [24] 1574 	mov	dpl, r5
      007B8D 22               [24] 1575 	ret
      007B8E                       1576 00108$:
                                   1577 ;	quantum/action_layer.c:541: for (int8_t i = MAX_LAYER - 1; i >= 0; i--) {
      007B8E 1D               [12] 1578 	dec	r5
      007B8F 80 B1            [24] 1579 	sjmp	00107$
      007B91                       1580 00105$:
                                   1581 ;	quantum/action_layer.c:560: return 0;
      007B91 75 82 00         [24] 1582 	mov	dpl, #0x00
                                   1583 ;	quantum/action_layer.c:565: }
      007B94 22               [24] 1584 	ret
                                   1585 ;------------------------------------------------------------
                                   1586 ;Allocation info for local variables in function 'layer_switch_get_layer'
                                   1587 ;------------------------------------------------------------
                                   1588 ;key           Allocated with name '_layer_switch_get_layer_PARM_1'
                                   1589 ;------------------------------------------------------------
                                   1590 ;	quantum/action_layer.c:567: uint8_t layer_switch_get_layer(keypos_t key) {
                                   1591 ;	-----------------------------------------
                                   1592 	.area CSEG    (CODE)
                                   1593 	.area CONST   (CODE)
                                   1594 	.area XINIT   (CODE)
      00C1C7                       1595 __xinit__default_layer_state:
      00C1C7 00                    1596 	.db #0x00	; 0
      00C1C8                       1597 __xinit__layer_state:
      00C1C8 00                    1598 	.db #0x00	; 0
                                   1599 	.area CABS    (ABS,CODE)
                                   1600 
                                   1601 ; Experimental exact instruction outlining.
                                   1602 	.globl _ak820_outline_0005
                                   1603 	.globl _ak820_outline_0051
                                   1604 	.globl _ak820_outline_0058
                                   1605 	.globl _ak820_outline_0059
                                   1606 	.globl _ak820_outline_0061
                                   1607 	.globl _ak820_outline_0071
                                   1608 	.globl _ak820_outline_0072
                                   1609 	.globl _ak820_outline_0107
                                   1610 	.globl _ak820_outline_0108
                                   1611 	.globl _ak820_outline_0118
                                   1612 	.globl _ak820_outline_0124
                                   1613 	.globl _ak820_outline_0129
                                   1614 	.globl _ak820_outline_0133
                                   1615 	.globl _ak820_outline_0135
                                   1616 	.globl _ak820_outline_0141
                                   1617 	.globl _ak820_outline_0149
                                   1618 	.globl _ak820_outline_0158
                                   1619 	.globl _ak820_outline_0163
                                   1620 	.globl _ak820_outline_0170
                                   1621 	.globl _ak820_outline_0176
                                   1622 	.globl _ak820_outline_0190
                                   1623 
                                   1624 	.area CSEG (CODE)
                                   1625 ; function ak820_outline_0141
      007B95                       1626 _ak820_outline_0141:
      007B95 E0               [24] 1627 	movx	a,@dptr
      007B96 42 07            [12] 1628 	orl	ar7,a
      007B98 8F 82            [24] 1629 	mov	dpl,r7
      007B9A 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0163
      007B9B                       1634 _ak820_outline_0163:
      007B9B F5 83            [12] 1635 	mov	dph,a
      007B9D E4               [12] 1636 	clr	a
      007B9E F0               [24] 1637 	movx	@dptr,a
      007B9F 0F               [12] 1638 	inc	r7
      007BA0 22               [24] 1639 	ret
                                   1640 
                                   1641 	.area CSEG (CODE)
                                   1642 ; function ak820_outline_0176
      007BA1                       1643 _ak820_outline_0176:
      007BA1 90 09 88         [24] 1644 	mov	dptr,#_ak820_macro_change_PARM_2
      007BA4 EF               [12] 1645 	mov	a,r7
      007BA5 F0               [24] 1646 	movx	@dptr,a
      007BA6 90 09 89         [24] 1647 	mov	dptr,#_ak820_macro_change_PARM_3
      007BA9 22               [24] 1648 	ret
