                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_macro
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_update_byte
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_nvm_end
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_begin
                                     17 	.globl _ak820_nvm_ok
                                     18 	.globl _ak820_macro_write_PARM_3
                                     19 	.globl _ak820_macro_write_PARM_2
                                     20 	.globl _ak820_macro_init
                                     21 	.globl _ak820_macro_ready
                                     22 	.globl _ak820_macro_length
                                     23 	.globl _ak820_macro_write
                                     24 	.globl _ak820_macro_reset
                                     25 ;--------------------------------------------------------
                                     26 ; special function registers
                                     27 ;--------------------------------------------------------
                                     28 	.area RSEG    (ABS,DATA)
      000000                         29 	.org 0x0000
                                     30 ;--------------------------------------------------------
                                     31 ; special function bits
                                     32 ;--------------------------------------------------------
                                     33 	.area RSEG    (ABS,DATA)
      000000                         34 	.org 0x0000
                                     35 ;--------------------------------------------------------
                                     36 ; overlayable register banks
                                     37 ;--------------------------------------------------------
                                     38 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         39 	.ds 8
                                     40 ;--------------------------------------------------------
                                     41 ; internal ram data
                                     42 ;--------------------------------------------------------
                                     43 	.area DSEG    (DATA)
      00000A                         44 _ak820_macro_write_sloc0_1_0:
      00000A                         45 	.ds 2
                                     46 ;--------------------------------------------------------
                                     47 ; overlayable items in internal ram
                                     48 ;--------------------------------------------------------
                                     49 	.area	OSEG    (OVR,DATA)
      000054                         50 _parse_byte_sloc1_1_0:
      000054                         51 	.ds 2
                                     52 ;--------------------------------------------------------
                                     53 ; indirectly addressable internal ram data
                                     54 ;--------------------------------------------------------
                                     55 	.area ISEG    (DATA)
                                     56 ;--------------------------------------------------------
                                     57 ; absolute internal ram data
                                     58 ;--------------------------------------------------------
                                     59 	.area IABS    (ABS,DATA)
                                     60 	.area IABS    (ABS,DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; bit data
                                     63 ;--------------------------------------------------------
                                     64 	.area BSEG    (BIT)
      000006                         65 _uploading:
      000006                         66 	.ds 1
      000007                         67 _parse_byte_sloc0_1_0:
      000007                         68 	.ds 1
      000008                         69 _ak820_macro_ready_sloc0_1_0:
      000008                         70 	.ds 1
                                     71 ;--------------------------------------------------------
                                     72 ; paged external ram data
                                     73 ;--------------------------------------------------------
                                     74 	.area PSEG    (PAG,XDATA)
                                     75 ;--------------------------------------------------------
                                     76 ; uninitialized external ram data
                                     77 ;--------------------------------------------------------
                                     78 	.area XSEG    (XDATA)
      0004FD                         79 _parsed:
      0004FD                         80 	.ds 2
      0004FF                         81 _covered:
      0004FF                         82 	.ds 2
      000501                         83 _used_length:
      000501                         84 	.ds 2
      000503                         85 _macro_byte_offset_10000_67:
      000503                         86 	.ds 2
      000505                         87 _busy_write_value_10000_69:
      000505                         88 	.ds 1
      000506                         89 _commit_length_length_10000_71:
      000506                         90 	.ds 2
      000508                         91 _commit_length_metadata_10000_72:
      000508                         92 	.ds 3
      00050B                         93 _parse_byte_PARM_2:
      00050B                         94 	.ds 1
      00050C                         95 _parse_byte_state_10000_74:
      00050C                         96 	.ds 2
      00050E                         97 _matches_PARM_2:
      00050E                         98 	.ds 2
      000510                         99 _matches_PARM_3:
      000510                        100 	.ds 2
      000512                        101 _matches_offset_10000_89:
      000512                        102 	.ds 2
      000514                        103 _ak820_macro_write_PARM_2:
      000514                        104 	.ds 2
      000516                        105 _ak820_macro_write_PARM_3:
      000516                        106 	.ds 3
      000519                        107 _ak820_macro_write_offset_10000_99:
      000519                        108 	.ds 2
      00051B                        109 _ak820_macro_write_next_10000_100:
      00051B                        110 	.ds 2
                                    111 ;--------------------------------------------------------
                                    112 ; absolute external ram data
                                    113 ;--------------------------------------------------------
                                    114 	.area XABS    (ABS,XDATA)
                                    115 ;--------------------------------------------------------
                                    116 ; initialized external ram data
                                    117 ;--------------------------------------------------------
                                    118 	.area XISEG   (XDATA)
                                    119 	.area HOME    (CODE)
                                    120 	.area GSINIT0 (CODE)
                                    121 	.area GSINIT1 (CODE)
                                    122 	.area GSINIT2 (CODE)
                                    123 	.area GSINIT3 (CODE)
                                    124 	.area GSINIT4 (CODE)
                                    125 	.area GSINIT5 (CODE)
                                    126 	.area GSINIT  (CODE)
                                    127 	.area GSFINAL (CODE)
                                    128 	.area CSEG    (CODE)
                                    129 ;--------------------------------------------------------
                                    130 ; global & static initialisations
                                    131 ;--------------------------------------------------------
                                    132 	.area HOME    (CODE)
                                    133 	.area GSINIT  (CODE)
                                    134 	.area GSFINAL (CODE)
                                    135 	.area GSINIT  (CODE)
                                    136 ;--------------------------------------------------------
                                    137 ; Home
                                    138 ;--------------------------------------------------------
                                    139 	.area HOME    (CODE)
                                    140 	.area HOME    (CODE)
                                    141 ;--------------------------------------------------------
                                    142 ; code
                                    143 ;--------------------------------------------------------
                                    144 	.area AK820LOW(CODE)
                                    145 ;------------------------------------------------------------
                                    146 ;Allocation info for local variables in function 'macro_byte'
                                    147 ;------------------------------------------------------------
                                    148 ;offset        Allocated with name '_macro_byte_offset_10000_67'
                                    149 ;------------------------------------------------------------
                                    150 ;	keyboards/ajazz/ak820/ak820_macro.c:40: static uint8_t macro_byte(uint16_t offset) {
                                    151 ;	-----------------------------------------
                                    152 ;	 function macro_byte
                                    153 ;	-----------------------------------------
      0028A0                        154 _macro_byte:
                           000007   155 	ar7 = 0x07
                           000006   156 	ar6 = 0x06
                           000005   157 	ar5 = 0x05
                           000004   158 	ar4 = 0x04
                           000003   159 	ar3 = 0x03
                           000002   160 	ar2 = 0x02
                           000001   161 	ar1 = 0x01
                           000000   162 	ar0 = 0x00
      0028A0 AF 83            [24]  163 	mov	r7,dph
      0028A2 E5 82            [12]  164 	mov	a,dpl
      0028A4 90 05 03         [24]  165 	mov	dptr,#_macro_byte_offset_10000_67
      0028A7 F0               [24]  166 	movx	@dptr,a
      0028A8 EF               [12]  167 	mov	a,r7
      0028A9 A3               [24]  168 	inc	dptr
      0028AA F0               [24]  169 	movx	@dptr,a
                                    170 ;	keyboards/ajazz/ak820/ak820_macro.c:41: return eeprom_read_byte((const uint8_t *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + offset));
      0028AB 90 05 03         [24]  171 	mov	dptr,#_macro_byte_offset_10000_67
      0028AE E0               [24]  172 	movx	a,@dptr
      0028AF FE               [12]  173 	mov	r6,a
      0028B0 A3               [24]  174 	inc	dptr
      0028B1 E0               [24]  175 	movx	a,@dptr
      0028B2 24 08            [12]  176 	add	a,#0x08
      0028B4 FF               [12]  177 	mov	r7,a
      0028B5 7D 00            [12]  178 	mov	r5,#0x00
      0028B7 8E 82            [24]  179 	mov	dpl, r6
      0028B9 8F 83            [24]  180 	mov	dph, r7
      0028BB 8D F0            [24]  181 	mov	b, r5
                                    182 ;	keyboards/ajazz/ak820/ak820_macro.c:42: }
      0028BD 02 40 D3         [24]  183 	ljmp	_eeprom_read_byte
                                    184 ;------------------------------------------------------------
                                    185 ;Allocation info for local variables in function 'busy_write'
                                    186 ;------------------------------------------------------------
                                    187 ;value         Allocated with name '_busy_write_value_10000_69'
                                    188 ;------------------------------------------------------------
                                    189 ;	keyboards/ajazz/ak820/ak820_macro.c:44: static void busy_write(uint8_t value) {
                                    190 ;	-----------------------------------------
                                    191 ;	 function busy_write
                                    192 ;	-----------------------------------------
      0028C0                        193 _busy_write:
      0028C0 E5 82            [12]  194 	mov	a,dpl
      0028C2 90 05 05         [24]  195 	mov	dptr,#_busy_write_value_10000_69
      0028C5 F0               [24]  196 	movx	@dptr,a
                                    197 ;	keyboards/ajazz/ak820/ak820_macro.c:45: eeprom_update_byte((uint8_t *)(uintptr_t)AK820_MACRO_BUSY_ADDR, value);
      0028C6 E0               [24]  198 	movx	a,@dptr
      0028C7 90 06 9B         [24]  199 	mov	dptr,#_eeprom_update_byte_PARM_2
      0028CA F0               [24]  200 	movx	@dptr,a
      0028CB 90 07 F0         [24]  201 	mov	dptr,#0x07f0
      0028CE 75 F0 00         [24]  202 	mov	b, #0x00
      0028D1 12 4E 5A         [24]  203 	lcall	_eeprom_update_byte
                                    204 ;	keyboards/ajazz/ak820/ak820_macro.c:46: ak820_nvm_flush();
                                    205 ;	keyboards/ajazz/ak820/ak820_macro.c:47: }
      0028D4 02 3E 88         [24]  206 	ljmp	_ak820_nvm_flush
                                    207 ;------------------------------------------------------------
                                    208 ;Allocation info for local variables in function 'commit_length'
                                    209 ;------------------------------------------------------------
                                    210 ;length        Allocated with name '_commit_length_length_10000_71'
                                    211 ;metadata      Allocated with name '_commit_length_metadata_10000_72'
                                    212 ;------------------------------------------------------------
                                    213 ;	keyboards/ajazz/ak820/ak820_macro.c:49: static void commit_length(uint16_t length) {
                                    214 ;	-----------------------------------------
                                    215 ;	 function commit_length
                                    216 ;	-----------------------------------------
      0028D7                        217 _commit_length:
      0028D7 AF 83            [24]  218 	mov	r7,dph
      0028D9 E5 82            [12]  219 	mov	a,dpl
      0028DB 90 05 06         [24]  220 	mov	dptr,#_commit_length_length_10000_71
      0028DE F0               [24]  221 	movx	@dptr,a
      0028DF EF               [12]  222 	mov	a,r7
      0028E0 A3               [24]  223 	inc	dptr
      0028E1 F0               [24]  224 	movx	@dptr,a
                                    225 ;	keyboards/ajazz/ak820/ak820_macro.c:51: metadata[0] = 0;
      0028E2 90 05 08         [24]  226 	mov	dptr,#_commit_length_metadata_10000_72
      0028E5 E4               [12]  227 	clr	a
      0028E6 F0               [24]  228 	movx	@dptr,a
                                    229 ;	keyboards/ajazz/ak820/ak820_macro.c:52: metadata[1] = (uint8_t)length;
      0028E7 90 05 06         [24]  230 	mov	dptr,#_commit_length_length_10000_71
      0028EA E0               [24]  231 	movx	a,@dptr
      0028EB FE               [12]  232 	mov	r6,a
      0028EC A3               [24]  233 	inc	dptr
      0028ED E0               [24]  234 	movx	a,@dptr
      0028EE FF               [12]  235 	mov	r7,a
      0028EF 8E 05            [24]  236 	mov	ar5,r6
      0028F1 90 05 09         [24]  237 	mov	dptr,#(_commit_length_metadata_10000_72 + 0x0001)
      0028F4 ED               [12]  238 	mov	a,r5
      0028F5 F0               [24]  239 	movx	@dptr,a
                                    240 ;	keyboards/ajazz/ak820/ak820_macro.c:53: metadata[2] = (uint8_t)(length >> 8);
      0028F6 8F 05            [24]  241 	mov	ar5,r7
      0028F8 90 05 0A         [24]  242 	mov	dptr,#(_commit_length_metadata_10000_72 + 0x0002)
      0028FB ED               [12]  243 	mov	a,r5
      0028FC F0               [24]  244 	movx	@dptr,a
                                    245 ;	keyboards/ajazz/ak820/ak820_macro.c:54: ak820_eeprom_write_block_xdata(metadata, (void *)(uintptr_t)AK820_MACRO_BUSY_ADDR, sizeof(metadata));
      0028FD 90 05 8E         [24]  246 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      002900 74 F0            [12]  247 	mov	a,#0xf0
      002902 F0               [24]  248 	movx	@dptr,a
      002903 74 07            [12]  249 	mov	a,#0x07
      002905 A3               [24]  250 	inc	dptr
      002906 F0               [24]  251 	movx	@dptr,a
      002907 E4               [12]  252 	clr	a
      002908 A3               [24]  253 	inc	dptr
      002909 F0               [24]  254 	movx	@dptr,a
      00290A 90 05 91         [24]  255 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00290D 74 03            [12]  256 	mov	a,#0x03
      00290F F0               [24]  257 	movx	@dptr,a
      002910 E4               [12]  258 	clr	a
      002911 A3               [24]  259 	inc	dptr
      002912 F0               [24]  260 	movx	@dptr,a
      002913 90 05 08         [24]  261 	mov	dptr,#_commit_length_metadata_10000_72
      002916 C0 07            [24]  262 	push	ar7
      002918 C0 06            [24]  263 	push	ar6
      00291A 12 41 9A         [24]  264 	lcall	_ak820_eeprom_write_block_xdata
                                    265 ;	keyboards/ajazz/ak820/ak820_macro.c:55: ak820_nvm_flush();
      00291D 12 3E 88         [24]  266 	lcall	_ak820_nvm_flush
      002920 D0 06            [24]  267 	pop	ar6
      002922 D0 07            [24]  268 	pop	ar7
                                    269 ;	keyboards/ajazz/ak820/ak820_macro.c:56: if (ak820_nvm_ok()) used_length = length;
      002924 12 3E 79         [24]  270 	lcall	_ak820_nvm_ok
      002927 E5 82            [12]  271 	mov	a, dpl
      002929 60 08            [24]  272 	jz	00103$
      00292B 90 05 01         [24]  273 	mov	dptr,#_used_length
      00292E EE               [12]  274 	mov	a,r6
      00292F F0               [24]  275 	movx	@dptr,a
      002930 EF               [12]  276 	mov	a,r7
      002931 A3               [24]  277 	inc	dptr
      002932 F0               [24]  278 	movx	@dptr,a
      002933                        279 00103$:
                                    280 ;	keyboards/ajazz/ak820/ak820_macro.c:57: }
      002933 22               [24]  281 	ret
                                    282 ;------------------------------------------------------------
                                    283 ;Allocation info for local variables in function 'parse_byte'
                                    284 ;------------------------------------------------------------
                                    285 ;value         Allocated with name '_parse_byte_PARM_2'
                                    286 ;state         Allocated with name '_parse_byte_state_10000_74'
                                    287 ;sloc1         Allocated with name '_parse_byte_sloc1_1_0'
                                    288 ;------------------------------------------------------------
                                    289 ;	keyboards/ajazz/ak820/ak820_macro.c:61: static bool parse_byte(macro_parse_t AK820_XDATA *state, uint8_t value) {
                                    290 ;	-----------------------------------------
                                    291 ;	 function parse_byte
                                    292 ;	-----------------------------------------
      002934                        293 _parse_byte:
      002934 AF 83            [24]  294 	mov	r7,dph
      002936 E5 82            [12]  295 	mov	a,dpl
      002938 90 05 0C         [24]  296 	mov	dptr,#_parse_byte_state_10000_74
      00293B F0               [24]  297 	movx	@dptr,a
      00293C EF               [12]  298 	mov	a,r7
      00293D A3               [24]  299 	inc	dptr
      00293E F0               [24]  300 	movx	@dptr,a
                                    301 ;	keyboards/ajazz/ak820/ak820_macro.c:62: if (state->terminated == DYNAMIC_KEYMAP_MACRO_COUNT) return value == 0;
      00293F 90 05 0C         [24]  302 	mov	dptr,#_parse_byte_state_10000_74
      002942 E0               [24]  303 	movx	a,@dptr
      002943 FE               [12]  304 	mov	r6,a
      002944 A3               [24]  305 	inc	dptr
      002945 E0               [24]  306 	movx	a,@dptr
      002946 FF               [12]  307 	mov	r7,a
      002947 8E 04            [24]  308 	mov	ar4,r6
      002949 8F 05            [24]  309 	mov	ar5,r7
      00294B 8C 82            [24]  310 	mov	dpl,r4
      00294D 8D 83            [24]  311 	mov	dph,r5
      00294F E0               [24]  312 	movx	a,@dptr
      002950 FB               [12]  313 	mov	r3,a
      002951 BB 10 0E         [24]  314 	cjne	r3,#0x10,00102$
      002954 90 05 0B         [24]  315 	mov	dptr,#_parse_byte_PARM_2
      002957 E0               [24]  316 	movx	a,@dptr
      002958 B4 01 00         [24]  317 	cjne	a,#0x01,00191$
      00295B                        318 00191$:
      00295B 92 07            [24]  319 	mov  _parse_byte_sloc0_1_0,c
      00295D E4               [12]  320 	clr	a
      00295E 33               [12]  321 	rlc	a
      00295F F5 82            [12]  322 	mov	dpl, a
      002961 22               [24]  323 	ret
      002962                        324 00102$:
                                    325 ;	keyboards/ajazz/ak820/ak820_macro.c:63: if (state->arguments == 3) {
      002962 0E               [12]  326 	inc	r6
      002963 BE 00 01         [24]  327 	cjne	r6,#0x00,00192$
      002966 0F               [12]  328 	inc	r7
      002967                        329 00192$:
      002967 8E 82            [24]  330 	mov	dpl,r6
      002969 8F 83            [24]  331 	mov	dph,r7
      00296B E0               [24]  332 	movx	a,@dptr
      00296C FA               [12]  333 	mov	r2,a
      00296D BA 03 2C         [24]  334 	cjne	r2,#0x03,00120$
                                    335 ;	keyboards/ajazz/ak820/ak820_macro.c:64: if (value < 1 || value > 7) return false;
      002970 90 05 0B         [24]  336 	mov	dptr,#_parse_byte_PARM_2
      002973 E0               [24]  337 	movx	a,@dptr
      002974 F9               [12]  338 	mov	r1,a
      002975 B9 01 00         [24]  339 	cjne	r1,#0x01,00195$
      002978                        340 00195$:
      002978 40 05            [24]  341 	jc	00103$
      00297A E9               [12]  342 	mov	a,r1
      00297B 24 F8            [12]  343 	add	a,#0xff - 0x07
      00297D 50 04            [24]  344 	jnc	00104$
                                    345 ;	free result
      00297F                        346 00103$:
      00297F 75 82 00         [24]  347 	mov	dpl, #0x00
      002982 22               [24]  348 	ret
      002983                        349 00104$:
                                    350 ;	keyboards/ajazz/ak820/ak820_macro.c:65: state->arguments = value <= 3 ? 1 : 2;
      002983 8E 54            [24]  351 	mov	_parse_byte_sloc1_1_0,r6
      002985 8F 55            [24]  352 	mov	(_parse_byte_sloc1_1_0 + 1),r7
      002987 E9               [12]  353 	mov	a,r1
      002988 24 FC            [12]  354 	add	a,#0xff - 0x03
      00298A 40 04            [24]  355 	jc	00124$
                                    356 ;	free result
      00298C 79 01            [12]  357 	mov	r1,#0x01
      00298E 80 02            [24]  358 	sjmp	00125$
      002990                        359 00124$:
      002990 79 02            [12]  360 	mov	r1,#0x02
      002992                        361 00125$:
      002992 85 54 82         [24]  362 	mov	dpl,_parse_byte_sloc1_1_0
      002995 85 55 83         [24]  363 	mov	dph,(_parse_byte_sloc1_1_0 + 1)
      002998 E9               [12]  364 	mov	a,r1
      002999 F0               [24]  365 	movx	@dptr,a
      00299A 80 3A            [24]  366 	sjmp	00121$
      00299C                        367 00120$:
                                    368 ;	keyboards/ajazz/ak820/ak820_macro.c:66: } else if (state->arguments) {
      00299C EA               [12]  369 	mov	a,r2
      00299D 60 12            [24]  370 	jz	00117$
                                    371 ;	keyboards/ajazz/ak820/ak820_macro.c:67: if (!value) return false;
      00299F 90 05 0B         [24]  372 	mov	dptr,#_parse_byte_PARM_2
      0029A2 E0               [24]  373 	movx	a,@dptr
      0029A3 70 03            [24]  374 	jnz	00107$
      0029A5 F5 82            [12]  375 	mov	dpl,a
      0029A7 22               [24]  376 	ret
      0029A8                        377 00107$:
                                    378 ;	keyboards/ajazz/ak820/ak820_macro.c:68: --state->arguments;
      0029A8 1A               [12]  379 	dec	r2
      0029A9 8E 82            [24]  380 	mov	dpl,r6
      0029AB 8F 83            [24]  381 	mov	dph,r7
      0029AD EA               [12]  382 	mov	a,r2
      0029AE F0               [24]  383 	movx	@dptr,a
      0029AF 80 25            [24]  384 	sjmp	00121$
      0029B1                        385 00117$:
                                    386 ;	keyboards/ajazz/ak820/ak820_macro.c:69: } else if (!value) {
      0029B1 90 05 0B         [24]  387 	mov	dptr,#_parse_byte_PARM_2
      0029B4 E0               [24]  388 	movx	a,@dptr
      0029B5 FA               [12]  389 	mov	r2,a
      0029B6 70 09            [24]  390 	jnz	00114$
                                    391 ;	keyboards/ajazz/ak820/ak820_macro.c:70: ++state->terminated;
      0029B8 0B               [12]  392 	inc	r3
      0029B9 8C 82            [24]  393 	mov	dpl,r4
      0029BB 8D 83            [24]  394 	mov	dph,r5
      0029BD EB               [12]  395 	mov	a,r3
      0029BE F0               [24]  396 	movx	@dptr,a
      0029BF 80 15            [24]  397 	sjmp	00121$
      0029C1                        398 00114$:
                                    399 ;	keyboards/ajazz/ak820/ak820_macro.c:71: } else if (value == 1) {
      0029C1 BA 01 09         [24]  400 	cjne	r2,#0x01,00111$
                                    401 ;	keyboards/ajazz/ak820/ak820_macro.c:72: state->arguments = 3;
      0029C4 8E 82            [24]  402 	mov	dpl,r6
      0029C6 8F 83            [24]  403 	mov	dph,r7
      0029C8 74 03            [12]  404 	mov	a,#0x03
      0029CA F0               [24]  405 	movx	@dptr,a
      0029CB 80 09            [24]  406 	sjmp	00121$
      0029CD                        407 00111$:
                                    408 ;	keyboards/ajazz/ak820/ak820_macro.c:73: } else if (value >= 128) {
      0029CD BA 80 00         [24]  409 	cjne	r2,#0x80,00204$
      0029D0                        410 00204$:
      0029D0 40 04            [24]  411 	jc	00121$
                                    412 ;	keyboards/ajazz/ak820/ak820_macro.c:76: return false;
      0029D2 75 82 00         [24]  413 	mov	dpl, #0x00
      0029D5 22               [24]  414 	ret
      0029D6                        415 00121$:
                                    416 ;	keyboards/ajazz/ak820/ak820_macro.c:78: return true;
      0029D6 75 82 01         [24]  417 	mov	dpl, #0x01
                                    418 ;	keyboards/ajazz/ak820/ak820_macro.c:79: }
      0029D9 22               [24]  419 	ret
                                    420 ;------------------------------------------------------------
                                    421 ;Allocation info for local variables in function 'matches'
                                    422 ;------------------------------------------------------------
                                    423 ;size          Allocated with name '_matches_PARM_2'
                                    424 ;data          Allocated with name '_matches_PARM_3'
                                    425 ;offset        Allocated with name '_matches_offset_10000_89'
                                    426 ;value         Allocated with name '_matches_value_20000_91'
                                    427 ;------------------------------------------------------------
                                    428 ;	keyboards/ajazz/ak820/ak820_macro.c:81: static bool matches(uint16_t offset, uint16_t size, const uint8_t AK820_XDATA *data) {
                                    429 ;	-----------------------------------------
                                    430 ;	 function matches
                                    431 ;	-----------------------------------------
      0029DA                        432 _matches:
      0029DA AF 83            [24]  433 	mov	r7,dph
      0029DC E5 82            [12]  434 	mov	a,dpl
      0029DE 90 05 12         [24]  435 	mov	dptr,#_matches_offset_10000_89
      0029E1 F0               [24]  436 	movx	@dptr,a
      0029E2 EF               [12]  437 	mov	a,r7
      0029E3 A3               [24]  438 	inc	dptr
      0029E4 F0               [24]  439 	movx	@dptr,a
                                    440 ;	keyboards/ajazz/ak820/ak820_macro.c:82: while (size--) {
      0029E5 90 05 10         [24]  441 	mov	dptr,#_matches_PARM_3
      0029E8 E0               [24]  442 	movx	a,@dptr
      0029E9 FE               [12]  443 	mov	r6,a
      0029EA A3               [24]  444 	inc	dptr
      0029EB E0               [24]  445 	movx	a,@dptr
      0029EC FF               [12]  446 	mov	r7,a
      0029ED 90 05 12         [24]  447 	mov	dptr,#_matches_offset_10000_89
      0029F0 E0               [24]  448 	movx	a,@dptr
      0029F1 FC               [12]  449 	mov	r4,a
      0029F2 A3               [24]  450 	inc	dptr
      0029F3 E0               [24]  451 	movx	a,@dptr
      0029F4 FD               [12]  452 	mov	r5,a
      0029F5 90 05 0E         [24]  453 	mov	dptr,#_matches_PARM_2
      0029F8 E0               [24]  454 	movx	a,@dptr
      0029F9 FA               [12]  455 	mov	r2,a
      0029FA A3               [24]  456 	inc	dptr
      0029FB E0               [24]  457 	movx	a,@dptr
      0029FC FB               [12]  458 	mov	r3,a
      0029FD                        459 00103$:
      0029FD 8A 00            [24]  460 	mov	ar0,r2
      0029FF 8B 01            [24]  461 	mov	ar1,r3
      002A01 1A               [12]  462 	dec	r2
      002A02 BA FF 01         [24]  463 	cjne	r2,#0xff,00147$
      002A05 1B               [12]  464 	dec	r3
      002A06                        465 00147$:
      002A06 E8               [12]  466 	mov	a,r0
      002A07 49               [12]  467 	orl	a,r1
      002A08 60 5D            [24]  468 	jz	00105$
                                    469 ;	keyboards/ajazz/ak820/ak820_macro.c:83: uint8_t value = !uploading && offset >= used_length ? 0 : macro_byte(offset);
      002A0A 20 06 13         [24]  470 	jb	_uploading,00108$
      002A0D 90 05 01         [24]  471 	mov	dptr,#_used_length
      002A10 E0               [24]  472 	movx	a,@dptr
      002A11 F8               [12]  473 	mov	r0,a
      002A12 A3               [24]  474 	inc	dptr
      002A13 E0               [24]  475 	movx	a,@dptr
      002A14 F9               [12]  476 	mov	r1,a
      002A15 C3               [12]  477 	clr	c
      002A16 EC               [12]  478 	mov	a,r4
      002A17 98               [12]  479 	subb	a,r0
      002A18 ED               [12]  480 	mov	a,r5
      002A19 99               [12]  481 	subb	a,r1
      002A1A 40 04            [24]  482 	jc	00108$
      002A1C 79 00            [12]  483 	mov	r1,#0x00
      002A1E 80 23            [24]  484 	sjmp	00109$
      002A20                        485 00108$:
      002A20 8C 82            [24]  486 	mov	dpl, r4
      002A22 8D 83            [24]  487 	mov	dph, r5
      002A24 C0 07            [24]  488 	push	ar7
      002A26 C0 06            [24]  489 	push	ar6
      002A28 C0 05            [24]  490 	push	ar5
      002A2A C0 04            [24]  491 	push	ar4
      002A2C C0 03            [24]  492 	push	ar3
      002A2E C0 02            [24]  493 	push	ar2
      002A30 12 28 A0         [24]  494 	lcall	_macro_byte
      002A33 A8 82            [24]  495 	mov	r0, dpl
      002A35 D0 02            [24]  496 	pop	ar2
      002A37 D0 03            [24]  497 	pop	ar3
      002A39 D0 04            [24]  498 	pop	ar4
      002A3B D0 05            [24]  499 	pop	ar5
      002A3D D0 06            [24]  500 	pop	ar6
      002A3F D0 07            [24]  501 	pop	ar7
      002A41 88 01            [24]  502 	mov	ar1,r0
      002A43                        503 00109$:
                                    504 ;	keyboards/ajazz/ak820/ak820_macro.c:84: if (value != *data++) return false;
      002A43 8E 82            [24]  505 	mov	dpl,r6
      002A45 8F 83            [24]  506 	mov	dph,r7
      002A47 E0               [24]  507 	movx	a,@dptr
      002A48 F8               [12]  508 	mov	r0,a
      002A49 A3               [24]  509 	inc	dptr
      002A4A AE 82            [24]  510 	mov	r6,dpl
      002A4C AF 83            [24]  511 	mov	r7,dph
      002A4E E9               [12]  512 	mov	a,r1
      002A4F B5 00 02         [24]  513 	cjne	a,ar0,00151$
      002A52 80 04            [24]  514 	sjmp	00102$
      002A54                        515 00151$:
      002A54 75 82 00         [24]  516 	mov	dpl, #0x00
      002A57 22               [24]  517 	ret
      002A58                        518 00102$:
                                    519 ;	keyboards/ajazz/ak820/ak820_macro.c:85: ++offset;
      002A58 0C               [12]  520 	inc	r4
      002A59 BC 00 01         [24]  521 	cjne	r4,#0x00,00152$
      002A5C 0D               [12]  522 	inc	r5
      002A5D                        523 00152$:
      002A5D 90 05 12         [24]  524 	mov	dptr,#_matches_offset_10000_89
      002A60 EC               [12]  525 	mov	a,r4
      002A61 F0               [24]  526 	movx	@dptr,a
      002A62 ED               [12]  527 	mov	a,r5
      002A63 A3               [24]  528 	inc	dptr
      002A64 F0               [24]  529 	movx	@dptr,a
      002A65 80 96            [24]  530 	sjmp	00103$
      002A67                        531 00105$:
                                    532 ;	keyboards/ajazz/ak820/ak820_macro.c:87: return true;
      002A67 75 82 01         [24]  533 	mov	dpl, #0x01
                                    534 ;	keyboards/ajazz/ak820/ak820_macro.c:88: }
      002A6A 22               [24]  535 	ret
                                    536 ;------------------------------------------------------------
                                    537 ;Allocation info for local variables in function 'ak820_macro_init'
                                    538 ;------------------------------------------------------------
                                    539 ;	keyboards/ajazz/ak820/ak820_macro.c:90: void ak820_macro_init(void) {
                                    540 ;	-----------------------------------------
                                    541 ;	 function ak820_macro_init
                                    542 ;	-----------------------------------------
      002A6B                        543 _ak820_macro_init:
                                    544 ;	keyboards/ajazz/ak820/ak820_macro.c:91: covered = 0;
      002A6B 90 04 FF         [24]  545 	mov	dptr,#_covered
      002A6E E4               [12]  546 	clr	a
      002A6F F0               [24]  547 	movx	@dptr,a
      002A70 A3               [24]  548 	inc	dptr
      002A71 F0               [24]  549 	movx	@dptr,a
                                    550 ;	keyboards/ajazz/ak820/ak820_macro.c:92: uploading = false;
                                    551 ;	assignBit
      002A72 C2 06            [12]  552 	clr	_uploading
                                    553 ;	keyboards/ajazz/ak820/ak820_macro.c:93: parsed.terminated = parsed.arguments = 0;
      002A74 90 04 FE         [24]  554 	mov	dptr,#(_parsed + 0x0001)
      002A77 E4               [12]  555 	clr	a
      002A78 F0               [24]  556 	movx	@dptr,a
      002A79 90 04 FD         [24]  557 	mov	dptr,#_parsed
      002A7C F0               [24]  558 	movx	@dptr,a
                                    559 ;	keyboards/ajazz/ak820/ak820_macro.c:94: used_length = eeprom_read_byte((const uint8_t *)(uintptr_t)AK820_MACRO_LENGTH_ADDR);
      002A7D 90 07 F1         [24]  560 	mov	dptr,#0x07f1
      002A80 F5 F0            [12]  561 	mov	b,a
      002A82 12 40 D3         [24]  562 	lcall	_eeprom_read_byte
      002A85 AF 82            [24]  563 	mov	r7, dpl
      002A87 90 05 01         [24]  564 	mov	dptr,#_used_length
      002A8A EF               [12]  565 	mov	a,r7
      002A8B F0               [24]  566 	movx	@dptr,a
      002A8C E4               [12]  567 	clr	a
      002A8D A3               [24]  568 	inc	dptr
      002A8E F0               [24]  569 	movx	@dptr,a
                                    570 ;	keyboards/ajazz/ak820/ak820_macro.c:95: used_length |= (uint16_t)eeprom_read_byte((const uint8_t *)(uintptr_t)(AK820_MACRO_LENGTH_ADDR + 1)) << 8;
      002A8F 90 07 F2         [24]  571 	mov	dptr,#0x07f2
      002A92 F5 F0            [12]  572 	mov	b,a
      002A94 12 40 D3         [24]  573 	lcall	_eeprom_read_byte
      002A97 AE 82            [24]  574 	mov	r6,dpl
      002A99 7F 00            [12]  575 	mov	r7,#0x00
      002A9B 90 05 01         [24]  576 	mov	dptr,#_used_length
      002A9E E0               [24]  577 	movx	a,@dptr
      002A9F 4F               [12]  578 	orl	a,r7
      002AA0 F0               [24]  579 	movx	@dptr,a
      002AA1 A3               [24]  580 	inc	dptr
      002AA2 E0               [24]  581 	movx	a,@dptr
      002AA3 4E               [12]  582 	orl	a,r6
      002AA4 F0               [24]  583 	movx	@dptr,a
                                    584 ;	keyboards/ajazz/ak820/ak820_macro.c:96: }
      002AA5 22               [24]  585 	ret
                                    586 ;------------------------------------------------------------
                                    587 ;Allocation info for local variables in function 'ak820_macro_ready'
                                    588 ;------------------------------------------------------------
                                    589 ;	keyboards/ajazz/ak820/ak820_macro.c:98: bool ak820_macro_ready(void) {
                                    590 ;	-----------------------------------------
                                    591 ;	 function ak820_macro_ready
                                    592 ;	-----------------------------------------
      002AA6                        593 _ak820_macro_ready:
                                    594 ;	keyboards/ajazz/ak820/ak820_macro.c:99: return ak820_nvm_ok() && used_length >= DYNAMIC_KEYMAP_MACRO_COUNT &&
      002AA6 12 3E 79         [24]  595 	lcall	_ak820_nvm_ok
      002AA9 E5 82            [12]  596 	mov	a, dpl
      002AAB 60 25            [24]  597 	jz	00103$
      002AAD 90 05 01         [24]  598 	mov	dptr,#_used_length
      002AB0 E0               [24]  599 	movx	a,@dptr
      002AB1 FE               [12]  600 	mov	r6,a
      002AB2 A3               [24]  601 	inc	dptr
      002AB3 E0               [24]  602 	movx	a,@dptr
      002AB4 FF               [12]  603 	mov	r7,a
      002AB5 C3               [12]  604 	clr	c
      002AB6 EE               [12]  605 	mov	a,r6
      002AB7 94 10            [12]  606 	subb	a,#0x10
      002AB9 EF               [12]  607 	mov	a,r7
      002ABA 94 00            [12]  608 	subb	a,#0x00
                                    609 ;	keyboards/ajazz/ak820/ak820_macro.c:100: used_length <= DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE &&
      002ABC 40 14            [24]  610 	jc	00103$
      002ABE E4               [12]  611 	clr	a
      002ABF 9E               [12]  612 	subb	a,r6
      002AC0 74 20            [12]  613 	mov	a,#0x20
      002AC2 9F               [12]  614 	subb	a,r7
      002AC3 40 0D            [24]  615 	jc	00103$
                                    616 ;	free result
                                    617 ;	keyboards/ajazz/ak820/ak820_macro.c:101: eeprom_read_byte((const uint8_t *)(uintptr_t)AK820_MACRO_BUSY_ADDR) == 0;
      002AC5 90 07 F0         [24]  618 	mov	dptr,#0x07f0
      002AC8 75 F0 00         [24]  619 	mov	b, #0x00
      002ACB 12 40 D3         [24]  620 	lcall	_eeprom_read_byte
      002ACE E5 82            [12]  621 	mov	a, dpl
      002AD0 60 04            [24]  622 	jz	00104$
      002AD2                        623 00103$:
                                    624 ;	assignBit
      002AD2 C2 08            [12]  625 	clr	_ak820_macro_ready_sloc0_1_0
      002AD4 80 02            [24]  626 	sjmp	00105$
      002AD6                        627 00104$:
                                    628 ;	assignBit
      002AD6 D2 08            [12]  629 	setb	_ak820_macro_ready_sloc0_1_0
      002AD8                        630 00105$:
      002AD8 A2 08            [12]  631 	mov	c,_ak820_macro_ready_sloc0_1_0
      002ADA E4               [12]  632 	clr	a
      002ADB 33               [12]  633 	rlc	a
      002ADC F5 82            [12]  634 	mov	dpl, a
                                    635 ;	keyboards/ajazz/ak820/ak820_macro.c:102: }
      002ADE 22               [24]  636 	ret
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'ak820_macro_length'
                                    639 ;------------------------------------------------------------
                                    640 ;	keyboards/ajazz/ak820/ak820_macro.c:104: uint16_t ak820_macro_length(void) { return ak820_macro_ready() ? used_length : 0; }
                                    641 ;	-----------------------------------------
                                    642 ;	 function ak820_macro_length
                                    643 ;	-----------------------------------------
      002ADF                        644 _ak820_macro_length:
      002ADF 12 2A A6         [24]  645 	lcall	_ak820_macro_ready
      002AE2 E5 82            [12]  646 	mov	a, dpl
      002AE4 60 0A            [24]  647 	jz	00103$
      002AE6 90 05 01         [24]  648 	mov	dptr,#_used_length
      002AE9 E0               [24]  649 	movx	a,@dptr
      002AEA FE               [12]  650 	mov	r6,a
      002AEB A3               [24]  651 	inc	dptr
      002AEC E0               [24]  652 	movx	a,@dptr
      002AED FF               [12]  653 	mov	r7,a
      002AEE 80 04            [24]  654 	sjmp	00104$
      002AF0                        655 00103$:
      002AF0 7E 00            [12]  656 	mov	r6,#0x00
      002AF2 7F 00            [12]  657 	mov	r7,#0x00
      002AF4                        658 00104$:
      002AF4 8E 82            [24]  659 	mov	dpl, r6
      002AF6 8F 83            [24]  660 	mov	dph, r7
      002AF8 22               [24]  661 	ret
                                    662 ;------------------------------------------------------------
                                    663 ;Allocation info for local variables in function 'ak820_macro_write'
                                    664 ;------------------------------------------------------------
                                    665 ;sloc0         Allocated with name '_ak820_macro_write_sloc0_1_0'
                                    666 ;size          Allocated with name '_ak820_macro_write_PARM_2'
                                    667 ;packet        Allocated with name '_ak820_macro_write_PARM_3'
                                    668 ;offset        Allocated with name '_ak820_macro_write_offset_10000_99'
                                    669 ;data          Allocated with name '_ak820_macro_write_data_10000_100'
                                    670 ;next          Allocated with name '_ak820_macro_write_next_10000_100'
                                    671 ;i             Allocated with name '_ak820_macro_write_i_10000_100'
                                    672 ;end           Allocated with name '_ak820_macro_write_end_10000_100'
                                    673 ;complete      Allocated with name '_ak820_macro_write_complete_10000_100'
                                    674 ;------------------------------------------------------------
                                    675 ;	keyboards/ajazz/ak820/ak820_macro.c:106: bool ak820_macro_write(uint16_t offset, uint16_t size, const uint8_t *packet) {
                                    676 ;	-----------------------------------------
                                    677 ;	 function ak820_macro_write
                                    678 ;	-----------------------------------------
      002AF9                        679 _ak820_macro_write:
      002AF9 AF 83            [24]  680 	mov	r7,dph
      002AFB E5 82            [12]  681 	mov	a,dpl
      002AFD 90 05 19         [24]  682 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002B00 F0               [24]  683 	movx	@dptr,a
      002B01 EF               [12]  684 	mov	a,r7
      002B02 A3               [24]  685 	inc	dptr
      002B03 F0               [24]  686 	movx	@dptr,a
                                    687 ;	keyboards/ajazz/ak820/ak820_macro.c:109: const uint8_t AK820_XDATA *data = (const uint8_t AK820_XDATA *)packet;
      002B04 90 05 16         [24]  688 	mov	dptr,#_ak820_macro_write_PARM_3
      002B07 E0               [24]  689 	movx	a,@dptr
      002B08 FE               [12]  690 	mov	r6,a
      002B09 A3               [24]  691 	inc	dptr
      002B0A E0               [24]  692 	movx	a,@dptr
      002B0B FF               [12]  693 	mov	r7,a
                                    694 ;	keyboards/ajazz/ak820/ak820_macro.c:115: if (!ak820_nvm_ok() || !size || offset >= DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE ||
      002B0C 12 3E 79         [24]  695 	lcall	_ak820_nvm_ok
      002B0F E5 82            [12]  696 	mov	a, dpl
      002B11 60 2B            [24]  697 	jz	00101$
      002B13 90 05 14         [24]  698 	mov	dptr,#_ak820_macro_write_PARM_2
      002B16 E0               [24]  699 	movx	a,@dptr
      002B17 FC               [12]  700 	mov	r4,a
      002B18 A3               [24]  701 	inc	dptr
      002B19 E0               [24]  702 	movx	a,@dptr
      002B1A FD               [12]  703 	mov	r5,a
      002B1B 4C               [12]  704 	orl	a,r4
      002B1C 60 20            [24]  705 	jz	00101$
      002B1E 90 05 19         [24]  706 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002B21 E0               [24]  707 	movx	a,@dptr
      002B22 FA               [12]  708 	mov	r2,a
      002B23 A3               [24]  709 	inc	dptr
      002B24 E0               [24]  710 	movx	a,@dptr
      002B25 FB               [12]  711 	mov	r3,a
      002B26 8A 00            [24]  712 	mov	ar0,r2
      002B28 8B 01            [24]  713 	mov	ar1,r3
      002B2A 74 E0            [12]  714 	mov	a,#0x100 - 0x20
      002B2C 29               [12]  715 	add	a,r1
      002B2D 40 0F            [24]  716 	jc	00101$
                                    717 ;	keyboards/ajazz/ak820/ak820_macro.c:116: size > DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE - offset) return false;
      002B2F E4               [12]  718 	clr	a
      002B30 C3               [12]  719 	clr	c
      002B31 9A               [12]  720 	subb	a,r2
      002B32 F8               [12]  721 	mov	r0,a
      002B33 74 20            [12]  722 	mov	a,#0x20
      002B35 9B               [12]  723 	subb	a,r3
      002B36 F9               [12]  724 	mov	r1,a
      002B37 C3               [12]  725 	clr	c
      002B38 E8               [12]  726 	mov	a,r0
      002B39 9C               [12]  727 	subb	a,r4
      002B3A E9               [12]  728 	mov	a,r1
      002B3B 9D               [12]  729 	subb	a,r5
      002B3C 50 04            [24]  730 	jnc	00102$
                                    731 ;	free result
      002B3E                        732 00101$:
      002B3E 75 82 00         [24]  733 	mov	dpl, #0x00
      002B41 22               [24]  734 	ret
      002B42                        735 00102$:
                                    736 ;	keyboards/ajazz/ak820/ak820_macro.c:117: end = offset + size;
      002B42 EC               [12]  737 	mov	a,r4
      002B43 2A               [12]  738 	add	a, r2
      002B44 F8               [12]  739 	mov	r0,a
      002B45 ED               [12]  740 	mov	a,r5
      002B46 3B               [12]  741 	addc	a, r3
      002B47 F9               [12]  742 	mov	r1,a
                                    743 ;	keyboards/ajazz/ak820/ak820_macro.c:120: if (end <= covered && (uploading || offset || end == covered) && matches(offset, size, data)) return true;
      002B48 90 04 FF         [24]  744 	mov	dptr,#_covered
      002B4B E0               [24]  745 	movx	a,@dptr
      002B4C F5 0A            [12]  746 	mov	_ak820_macro_write_sloc0_1_0,a
      002B4E A3               [24]  747 	inc	dptr
      002B4F E0               [24]  748 	movx	a,@dptr
      002B50 F5 0B            [12]  749 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002B52 C3               [12]  750 	clr	c
      002B53 E5 0A            [12]  751 	mov	a,_ak820_macro_write_sloc0_1_0
      002B55 98               [12]  752 	subb	a,r0
      002B56 E5 0B            [12]  753 	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
      002B58 99               [12]  754 	subb	a,r1
      002B59 40 4E            [24]  755 	jc	00107$
                                    756 ;	free result
      002B5B 20 06 0C         [24]  757 	jb	_uploading,00111$
      002B5E EA               [12]  758 	mov	a,r2
      002B5F 4B               [12]  759 	orl	a,r3
      002B60 70 08            [24]  760 	jnz	00111$
      002B62 E8               [12]  761 	mov	a,r0
      002B63 B5 0A 43         [24]  762 	cjne	a,_ak820_macro_write_sloc0_1_0,00107$
      002B66 E9               [12]  763 	mov	a,r1
      002B67 B5 0B 3F         [24]  764 	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00107$
      002B6A                        765 00111$:
      002B6A 90 05 19         [24]  766 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002B6D E0               [24]  767 	movx	a,@dptr
      002B6E FA               [12]  768 	mov	r2,a
      002B6F A3               [24]  769 	inc	dptr
      002B70 E0               [24]  770 	movx	a,@dptr
      002B71 FB               [12]  771 	mov	r3,a
      002B72 90 05 0E         [24]  772 	mov	dptr,#_matches_PARM_2
      002B75 EC               [12]  773 	mov	a,r4
      002B76 F0               [24]  774 	movx	@dptr,a
      002B77 ED               [12]  775 	mov	a,r5
      002B78 A3               [24]  776 	inc	dptr
      002B79 F0               [24]  777 	movx	@dptr,a
      002B7A 90 05 10         [24]  778 	mov	dptr,#_matches_PARM_3
      002B7D EE               [12]  779 	mov	a,r6
      002B7E F0               [24]  780 	movx	@dptr,a
      002B7F EF               [12]  781 	mov	a,r7
      002B80 A3               [24]  782 	inc	dptr
      002B81 F0               [24]  783 	movx	@dptr,a
      002B82 8A 82            [24]  784 	mov	dpl, r2
      002B84 8B 83            [24]  785 	mov	dph, r3
      002B86 C0 07            [24]  786 	push	ar7
      002B88 C0 06            [24]  787 	push	ar6
      002B8A C0 05            [24]  788 	push	ar5
      002B8C C0 04            [24]  789 	push	ar4
      002B8E C0 01            [24]  790 	push	ar1
      002B90 C0 00            [24]  791 	push	ar0
      002B92 12 29 DA         [24]  792 	lcall	_matches
      002B95 E5 82            [12]  793 	mov	a, dpl
      002B97 D0 00            [24]  794 	pop	ar0
      002B99 D0 01            [24]  795 	pop	ar1
      002B9B D0 04            [24]  796 	pop	ar4
      002B9D D0 05            [24]  797 	pop	ar5
      002B9F D0 06            [24]  798 	pop	ar6
      002BA1 D0 07            [24]  799 	pop	ar7
      002BA3 60 04            [24]  800 	jz	00107$
      002BA5 75 82 01         [24]  801 	mov	dpl, #0x01
      002BA8 22               [24]  802 	ret
      002BA9                        803 00107$:
                                    804 ;	keyboards/ajazz/ak820/ak820_macro.c:122: if (!uploading) {
      002BA9 30 06 03         [24]  805 	jnb	_uploading,00371$
      002BAC 02 2C 47         [24]  806 	ljmp	00130$
      002BAF                        807 00371$:
                                    808 ;	keyboards/ajazz/ak820/ak820_macro.c:123: if (offset) {
      002BAF 90 05 19         [24]  809 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002BB2 E0               [24]  810 	movx	a,@dptr
      002BB3 FA               [12]  811 	mov	r2,a
      002BB4 A3               [24]  812 	inc	dptr
      002BB5 E0               [24]  813 	movx	a,@dptr
      002BB6 FB               [12]  814 	mov	r3,a
      002BB7 90 05 19         [24]  815 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002BBA E0               [24]  816 	movx	a,@dptr
      002BBB F5 F0            [12]  817 	mov	b,a
      002BBD A3               [24]  818 	inc	dptr
      002BBE E0               [24]  819 	movx	a,@dptr
      002BBF 45 F0            [12]  820 	orl	a,b
      002BC1 60 78            [24]  821 	jz	00120$
                                    822 ;	keyboards/ajazz/ak820/ak820_macro.c:127: if (!covered || offset != covered || !ak820_macro_ready()) return false;
      002BC3 90 04 FF         [24]  823 	mov	dptr,#_covered
      002BC6 E0               [24]  824 	movx	a,@dptr
      002BC7 F5 0A            [12]  825 	mov	_ak820_macro_write_sloc0_1_0,a
      002BC9 A3               [24]  826 	inc	dptr
      002BCA E0               [24]  827 	movx	a,@dptr
      002BCB F5 0B            [12]  828 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002BCD 90 04 FF         [24]  829 	mov	dptr,#_covered
      002BD0 E0               [24]  830 	movx	a,@dptr
      002BD1 F5 F0            [12]  831 	mov	b,a
      002BD3 A3               [24]  832 	inc	dptr
      002BD4 E0               [24]  833 	movx	a,@dptr
      002BD5 45 F0            [12]  834 	orl	a,b
      002BD7 60 27            [24]  835 	jz	00112$
      002BD9 EA               [12]  836 	mov	a,r2
      002BDA B5 0A 23         [24]  837 	cjne	a,_ak820_macro_write_sloc0_1_0,00112$
      002BDD EB               [12]  838 	mov	a,r3
      002BDE B5 0B 1F         [24]  839 	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00112$
      002BE1 C0 07            [24]  840 	push	ar7
      002BE3 C0 06            [24]  841 	push	ar6
      002BE5 C0 05            [24]  842 	push	ar5
      002BE7 C0 04            [24]  843 	push	ar4
      002BE9 C0 01            [24]  844 	push	ar1
      002BEB C0 00            [24]  845 	push	ar0
      002BED 12 2A A6         [24]  846 	lcall	_ak820_macro_ready
      002BF0 E5 82            [12]  847 	mov	a, dpl
      002BF2 D0 00            [24]  848 	pop	ar0
      002BF4 D0 01            [24]  849 	pop	ar1
      002BF6 D0 04            [24]  850 	pop	ar4
      002BF8 D0 05            [24]  851 	pop	ar5
      002BFA D0 06            [24]  852 	pop	ar6
      002BFC D0 07            [24]  853 	pop	ar7
      002BFE 70 04            [24]  854 	jnz	00200$
      002C00                        855 00112$:
      002C00 75 82 00         [24]  856 	mov	dpl, #0x00
      002C03 22               [24]  857 	ret
                                    858 ;	keyboards/ajazz/ak820/ak820_macro.c:128: for (i = 0; i < size; ++i) if (data[i]) return false;
      002C04                        859 00200$:
      002C04 7A 00            [12]  860 	mov	r2,#0x00
      002C06 7B 00            [12]  861 	mov	r3,#0x00
      002C08                        862 00148$:
      002C08 C3               [12]  863 	clr	c
      002C09 EA               [12]  864 	mov	a,r2
      002C0A 9C               [12]  865 	subb	a,r4
      002C0B EB               [12]  866 	mov	a,r3
      002C0C 9D               [12]  867 	subb	a,r5
      002C0D 50 20            [24]  868 	jnc	00118$
      002C0F C0 00            [24]  869 	push	ar0
      002C11 C0 01            [24]  870 	push	ar1
      002C13 EA               [12]  871 	mov	a,r2
      002C14 2E               [12]  872 	add	a, r6
      002C15 F8               [12]  873 	mov	r0,a
      002C16 EB               [12]  874 	mov	a,r3
      002C17 3F               [12]  875 	addc	a, r7
      002C18 F9               [12]  876 	mov	r1,a
      002C19 88 82            [24]  877 	mov	dpl,r0
      002C1B 89 83            [24]  878 	mov	dph,r1
      002C1D E0               [24]  879 	movx	a,@dptr
      002C1E D0 01            [24]  880 	pop	ar1
      002C20 D0 00            [24]  881 	pop	ar0
      002C22 60 04            [24]  882 	jz	00149$
      002C24 75 82 00         [24]  883 	mov	dpl, #0x00
      002C27 22               [24]  884 	ret
      002C28                        885 00149$:
      002C28 0A               [12]  886 	inc	r2
      002C29 BA 00 DC         [24]  887 	cjne	r2,#0x00,00148$
      002C2C 0B               [12]  888 	inc	r3
      002C2D 80 D9            [24]  889 	sjmp	00148$
      002C2F                        890 00118$:
                                    891 ;	keyboards/ajazz/ak820/ak820_macro.c:129: covered = end;
      002C2F 90 04 FF         [24]  892 	mov	dptr,#_covered
      002C32 E8               [12]  893 	mov	a,r0
      002C33 F0               [24]  894 	movx	@dptr,a
      002C34 E9               [12]  895 	mov	a,r1
      002C35 A3               [24]  896 	inc	dptr
      002C36 F0               [24]  897 	movx	@dptr,a
                                    898 ;	keyboards/ajazz/ak820/ak820_macro.c:130: return true;
      002C37 75 82 01         [24]  899 	mov	dpl, #0x01
      002C3A 22               [24]  900 	ret
      002C3B                        901 00120$:
                                    902 ;	keyboards/ajazz/ak820/ak820_macro.c:132: next.terminated = next.arguments = 0;
      002C3B 90 05 1C         [24]  903 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002C3E E4               [12]  904 	clr	a
      002C3F F0               [24]  905 	movx	@dptr,a
      002C40 90 05 1B         [24]  906 	mov	dptr,#_ak820_macro_write_next_10000_100
      002C43 F0               [24]  907 	movx	@dptr,a
      002C44 02 2C DC         [24]  908 	ljmp	00208$
      002C47                        909 00130$:
                                    910 ;	keyboards/ajazz/ak820/ak820_macro.c:134: if (offset > covered) return false; /* A hole is never old EEPROM data. */
      002C47 90 05 19         [24]  911 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002C4A E0               [24]  912 	movx	a,@dptr
      002C4B FA               [12]  913 	mov	r2,a
      002C4C A3               [24]  914 	inc	dptr
      002C4D E0               [24]  915 	movx	a,@dptr
      002C4E FB               [12]  916 	mov	r3,a
      002C4F 90 04 FF         [24]  917 	mov	dptr,#_covered
      002C52 E0               [24]  918 	movx	a,@dptr
      002C53 F5 0A            [12]  919 	mov	_ak820_macro_write_sloc0_1_0,a
      002C55 A3               [24]  920 	inc	dptr
      002C56 E0               [24]  921 	movx	a,@dptr
      002C57 F5 0B            [12]  922 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002C59 C3               [12]  923 	clr	c
      002C5A E5 0A            [12]  924 	mov	a,_ak820_macro_write_sloc0_1_0
      002C5C 9A               [12]  925 	subb	a,r2
      002C5D E5 0B            [12]  926 	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
      002C5F 9B               [12]  927 	subb	a,r3
      002C60 50 04            [24]  928 	jnc	00122$
                                    929 ;	free result
      002C62 75 82 00         [24]  930 	mov	dpl, #0x00
      002C65 22               [24]  931 	ret
      002C66                        932 00122$:
                                    933 ;	keyboards/ajazz/ak820/ak820_macro.c:135: if (offset == covered) {
      002C66 EA               [12]  934 	mov	a,r2
      002C67 B5 0A 16         [24]  935 	cjne	a,_ak820_macro_write_sloc0_1_0,00127$
      002C6A EB               [12]  936 	mov	a,r3
      002C6B B5 0B 12         [24]  937 	cjne	a,(_ak820_macro_write_sloc0_1_0 + 1),00127$
                                    938 ;	keyboards/ajazz/ak820/ak820_macro.c:136: next.terminated = parsed.terminated;
      002C6E 90 04 FD         [24]  939 	mov	dptr,#_parsed
      002C71 E0               [24]  940 	movx	a,@dptr
      002C72 90 05 1B         [24]  941 	mov	dptr,#_ak820_macro_write_next_10000_100
      002C75 F0               [24]  942 	movx	@dptr,a
                                    943 ;	keyboards/ajazz/ak820/ak820_macro.c:137: next.arguments = parsed.arguments;
      002C76 90 04 FE         [24]  944 	mov	dptr,#(_parsed + 0x0001)
      002C79 E0               [24]  945 	movx	a,@dptr
      002C7A 90 05 1C         [24]  946 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002C7D F0               [24]  947 	movx	@dptr,a
      002C7E 80 5C            [24]  948 	sjmp	00208$
      002C80                        949 00127$:
                                    950 ;	keyboards/ajazz/ak820/ak820_macro.c:142: next.terminated = next.arguments = 0;
      002C80 90 05 1C         [24]  951 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002C83 E4               [12]  952 	clr	a
      002C84 F0               [24]  953 	movx	@dptr,a
      002C85 90 05 1B         [24]  954 	mov	dptr,#_ak820_macro_write_next_10000_100
      002C88 F0               [24]  955 	movx	@dptr,a
                                    956 ;	keyboards/ajazz/ak820/ak820_macro.c:143: for (i = 0; i < offset; ++i) if (!parse_byte(&next, macro_byte(i))) return false;
      002C89 F5 0A            [12]  957 	mov	_ak820_macro_write_sloc0_1_0,a
      002C8B F5 0B            [12]  958 	mov	(_ak820_macro_write_sloc0_1_0 + 1),a
      002C8D                        959 00151$:
      002C8D C3               [12]  960 	clr	c
      002C8E E5 0A            [12]  961 	mov	a,_ak820_macro_write_sloc0_1_0
      002C90 9A               [12]  962 	subb	a,r2
      002C91 E5 0B            [12]  963 	mov	a,(_ak820_macro_write_sloc0_1_0 + 1)
      002C93 9B               [12]  964 	subb	a,r3
      002C94 50 46            [24]  965 	jnc	00208$
      002C96 85 0A 82         [24]  966 	mov	dpl, _ak820_macro_write_sloc0_1_0
      002C99 85 0B 83         [24]  967 	mov	dph, (_ak820_macro_write_sloc0_1_0 + 1)
      002C9C C0 07            [24]  968 	push	ar7
      002C9E C0 06            [24]  969 	push	ar6
      002CA0 C0 05            [24]  970 	push	ar5
      002CA2 C0 04            [24]  971 	push	ar4
      002CA4 C0 03            [24]  972 	push	ar3
      002CA6 C0 02            [24]  973 	push	ar2
      002CA8 C0 01            [24]  974 	push	ar1
      002CAA C0 00            [24]  975 	push	ar0
      002CAC 12 28 A0         [24]  976 	lcall	_macro_byte
      002CAF E5 82            [12]  977 	mov	a, dpl
      002CB1 90 05 0B         [24]  978 	mov	dptr,#_parse_byte_PARM_2
      002CB4 F0               [24]  979 	movx	@dptr,a
      002CB5 90 05 1B         [24]  980 	mov	dptr,#_ak820_macro_write_next_10000_100
      002CB8 12 29 34         [24]  981 	lcall	_parse_byte
      002CBB E5 82            [12]  982 	mov	a, dpl
      002CBD D0 00            [24]  983 	pop	ar0
      002CBF D0 01            [24]  984 	pop	ar1
      002CC1 D0 02            [24]  985 	pop	ar2
      002CC3 D0 03            [24]  986 	pop	ar3
      002CC5 D0 04            [24]  987 	pop	ar4
      002CC7 D0 05            [24]  988 	pop	ar5
      002CC9 D0 06            [24]  989 	pop	ar6
      002CCB D0 07            [24]  990 	pop	ar7
      002CCD 70 03            [24]  991 	jnz	00152$
      002CCF F5 82            [12]  992 	mov	dpl,a
      002CD1 22               [24]  993 	ret
      002CD2                        994 00152$:
      002CD2 05 0A            [12]  995 	inc	_ak820_macro_write_sloc0_1_0
      002CD4 E4               [12]  996 	clr	a
                                    997 ;	keyboards/ajazz/ak820/ak820_macro.c:146: for (i = 0; i < size; ++i) if (!parse_byte(&next, data[i])) return false;
      002CD5 B5 0A B5         [24]  998 	cjne	a,_ak820_macro_write_sloc0_1_0,00151$
      002CD8 05 0B            [12]  999 	inc	(_ak820_macro_write_sloc0_1_0 + 1)
      002CDA 80 B1            [24] 1000 	sjmp	00151$
      002CDC                       1001 00208$:
      002CDC 7A 00            [12] 1002 	mov	r2,#0x00
      002CDE 7B 00            [12] 1003 	mov	r3,#0x00
      002CE0                       1004 00154$:
      002CE0 C3               [12] 1005 	clr	c
      002CE1 EA               [12] 1006 	mov	a,r2
      002CE2 9C               [12] 1007 	subb	a,r4
      002CE3 EB               [12] 1008 	mov	a,r3
      002CE4 9D               [12] 1009 	subb	a,r5
      002CE5 50 4A            [24] 1010 	jnc	00134$
      002CE7 C0 00            [24] 1011 	push	ar0
      002CE9 C0 01            [24] 1012 	push	ar1
      002CEB EA               [12] 1013 	mov	a,r2
      002CEC 2E               [12] 1014 	add	a, r6
      002CED F5 82            [12] 1015 	mov	dpl,a
      002CEF EB               [12] 1016 	mov	a,r3
      002CF0 3F               [12] 1017 	addc	a, r7
      002CF1 F5 83            [12] 1018 	mov	dph,a
      002CF3 E0               [24] 1019 	movx	a,@dptr
      002CF4 F9               [12] 1020 	mov	r1,a
      002CF5 90 05 0B         [24] 1021 	mov	dptr,#_parse_byte_PARM_2
      002CF8 F0               [24] 1022 	movx	@dptr,a
      002CF9 90 05 1B         [24] 1023 	mov	dptr,#_ak820_macro_write_next_10000_100
      002CFC C0 07            [24] 1024 	push	ar7
      002CFE C0 06            [24] 1025 	push	ar6
      002D00 C0 05            [24] 1026 	push	ar5
      002D02 C0 04            [24] 1027 	push	ar4
      002D04 C0 03            [24] 1028 	push	ar3
      002D06 C0 02            [24] 1029 	push	ar2
      002D08 C0 01            [24] 1030 	push	ar1
      002D0A C0 00            [24] 1031 	push	ar0
      002D0C 12 29 34         [24] 1032 	lcall	_parse_byte
      002D0F E5 82            [12] 1033 	mov	a, dpl
      002D11 D0 00            [24] 1034 	pop	ar0
      002D13 D0 01            [24] 1035 	pop	ar1
      002D15 D0 02            [24] 1036 	pop	ar2
      002D17 D0 03            [24] 1037 	pop	ar3
      002D19 D0 04            [24] 1038 	pop	ar4
      002D1B D0 05            [24] 1039 	pop	ar5
      002D1D D0 06            [24] 1040 	pop	ar6
      002D1F D0 07            [24] 1041 	pop	ar7
      002D21 D0 01            [24] 1042 	pop	ar1
      002D23 D0 00            [24] 1043 	pop	ar0
      002D25 70 03            [24] 1044 	jnz	00155$
      002D27 F5 82            [12] 1045 	mov	dpl,a
      002D29 22               [24] 1046 	ret
      002D2A                       1047 00155$:
      002D2A 0A               [12] 1048 	inc	r2
      002D2B BA 00 B2         [24] 1049 	cjne	r2,#0x00,00154$
      002D2E 0B               [12] 1050 	inc	r3
      002D2F 80 AF            [24] 1051 	sjmp	00154$
      002D31                       1052 00134$:
                                   1053 ;	keyboards/ajazz/ak820/ak820_macro.c:147: complete = next.terminated == DYNAMIC_KEYMAP_MACRO_COUNT;
      002D31 90 05 1B         [24] 1054 	mov	dptr,#_ak820_macro_write_next_10000_100
      002D34 E0               [24] 1055 	movx	a,@dptr
      002D35 FB               [12] 1056 	mov	r3,a
      002D36 E4               [12] 1057 	clr	a
      002D37 BB 10 01         [24] 1058 	cjne	r3,#0x10,00389$
      002D3A 04               [12] 1059 	inc	a
      002D3B                       1060 00389$:
                                   1061 ;	keyboards/ajazz/ak820/ak820_macro.c:148: if (!complete && end == DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE) return false;
      002D3B F5 0A            [12] 1062 	mov	_ak820_macro_write_sloc0_1_0,a
      002D3D 70 0E            [24] 1063 	jnz	00136$
      002D3F 88 02            [24] 1064 	mov	ar2,r0
      002D41 89 03            [24] 1065 	mov	ar3,r1
      002D43 BA 00 07         [24] 1066 	cjne	r2,#0x00,00136$
      002D46 BB 20 04         [24] 1067 	cjne	r3,#0x20,00136$
      002D49 75 82 00         [24] 1068 	mov	dpl, #0x00
      002D4C 22               [24] 1069 	ret
      002D4D                       1070 00136$:
                                   1071 ;	keyboards/ajazz/ak820/ak820_macro.c:150: ak820_nvm_begin();
      002D4D C0 07            [24] 1072 	push	ar7
      002D4F C0 06            [24] 1073 	push	ar6
      002D51 C0 05            [24] 1074 	push	ar5
      002D53 C0 04            [24] 1075 	push	ar4
      002D55 C0 01            [24] 1076 	push	ar1
      002D57 C0 00            [24] 1077 	push	ar0
      002D59 12 3F DB         [24] 1078 	lcall	_ak820_nvm_begin
      002D5C D0 00            [24] 1079 	pop	ar0
      002D5E D0 01            [24] 1080 	pop	ar1
      002D60 D0 04            [24] 1081 	pop	ar4
      002D62 D0 05            [24] 1082 	pop	ar5
      002D64 D0 06            [24] 1083 	pop	ar6
      002D66 D0 07            [24] 1084 	pop	ar7
                                   1085 ;	keyboards/ajazz/ak820/ak820_macro.c:151: if (!uploading) {
      002D68 20 06 2C         [24] 1086 	jb	_uploading,00141$
                                   1087 ;	keyboards/ajazz/ak820/ak820_macro.c:153: busy_write(1);
      002D6B 75 82 01         [24] 1088 	mov	dpl, #0x01
      002D6E C0 07            [24] 1089 	push	ar7
      002D70 C0 06            [24] 1090 	push	ar6
      002D72 C0 05            [24] 1091 	push	ar5
      002D74 C0 04            [24] 1092 	push	ar4
      002D76 C0 01            [24] 1093 	push	ar1
      002D78 C0 00            [24] 1094 	push	ar0
      002D7A 12 28 C0         [24] 1095 	lcall	_busy_write
      002D7D D0 00            [24] 1096 	pop	ar0
      002D7F D0 01            [24] 1097 	pop	ar1
      002D81 D0 04            [24] 1098 	pop	ar4
      002D83 D0 05            [24] 1099 	pop	ar5
      002D85 D0 06            [24] 1100 	pop	ar6
      002D87 D0 07            [24] 1101 	pop	ar7
                                   1102 ;	keyboards/ajazz/ak820/ak820_macro.c:154: if (!ak820_nvm_ok()) { ak820_nvm_end(); return false; }
      002D89 12 3E 79         [24] 1103 	lcall	_ak820_nvm_ok
      002D8C E5 82            [12] 1104 	mov	a, dpl
      002D8E 70 07            [24] 1105 	jnz	00141$
      002D90 12 3F F0         [24] 1106 	lcall	_ak820_nvm_end
      002D93 75 82 00         [24] 1107 	mov	dpl, #0x00
      002D96 22               [24] 1108 	ret
      002D97                       1109 00141$:
                                   1110 ;	keyboards/ajazz/ak820/ak820_macro.c:156: ak820_eeprom_write_block_xdata(data, (void *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + offset), size);
      002D97 90 05 19         [24] 1111 	mov	dptr,#_ak820_macro_write_offset_10000_99
      002D9A E0               [24] 1112 	movx	a,@dptr
      002D9B FA               [12] 1113 	mov	r2,a
      002D9C A3               [24] 1114 	inc	dptr
      002D9D E0               [24] 1115 	movx	a,@dptr
      002D9E 24 08            [12] 1116 	add	a,#0x08
      002DA0 FB               [12] 1117 	mov	r3,a
      002DA1 90 05 8E         [24] 1118 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      002DA4 EA               [12] 1119 	mov	a,r2
      002DA5 F0               [24] 1120 	movx	@dptr,a
      002DA6 EB               [12] 1121 	mov	a,r3
      002DA7 A3               [24] 1122 	inc	dptr
      002DA8 F0               [24] 1123 	movx	@dptr,a
      002DA9 E4               [12] 1124 	clr	a
      002DAA A3               [24] 1125 	inc	dptr
      002DAB F0               [24] 1126 	movx	@dptr,a
      002DAC 90 05 91         [24] 1127 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      002DAF EC               [12] 1128 	mov	a,r4
      002DB0 F0               [24] 1129 	movx	@dptr,a
      002DB1 ED               [12] 1130 	mov	a,r5
      002DB2 A3               [24] 1131 	inc	dptr
      002DB3 F0               [24] 1132 	movx	@dptr,a
      002DB4 8E 82            [24] 1133 	mov	dpl, r6
      002DB6 8F 83            [24] 1134 	mov	dph, r7
      002DB8 C0 01            [24] 1135 	push	ar1
      002DBA C0 00            [24] 1136 	push	ar0
      002DBC 12 41 9A         [24] 1137 	lcall	_ak820_eeprom_write_block_xdata
                                   1138 ;	keyboards/ajazz/ak820/ak820_macro.c:157: ak820_nvm_flush();
      002DBF 12 3E 88         [24] 1139 	lcall	_ak820_nvm_flush
      002DC2 D0 00            [24] 1140 	pop	ar0
      002DC4 D0 01            [24] 1141 	pop	ar1
                                   1142 ;	keyboards/ajazz/ak820/ak820_macro.c:158: if (complete && ak820_nvm_ok()) commit_length(end);
      002DC6 E5 0A            [12] 1143 	mov	a,_ak820_macro_write_sloc0_1_0
      002DC8 60 16            [24] 1144 	jz	00143$
      002DCA 12 3E 79         [24] 1145 	lcall	_ak820_nvm_ok
      002DCD E5 82            [12] 1146 	mov	a, dpl
      002DCF 60 0F            [24] 1147 	jz	00143$
      002DD1 88 82            [24] 1148 	mov	dpl, r0
      002DD3 89 83            [24] 1149 	mov	dph, r1
      002DD5 C0 01            [24] 1150 	push	ar1
      002DD7 C0 00            [24] 1151 	push	ar0
      002DD9 12 28 D7         [24] 1152 	lcall	_commit_length
      002DDC D0 00            [24] 1153 	pop	ar0
      002DDE D0 01            [24] 1154 	pop	ar1
      002DE0                       1155 00143$:
                                   1156 ;	keyboards/ajazz/ak820/ak820_macro.c:159: ak820_nvm_end();
      002DE0 C0 01            [24] 1157 	push	ar1
      002DE2 C0 00            [24] 1158 	push	ar0
      002DE4 12 3F F0         [24] 1159 	lcall	_ak820_nvm_end
      002DE7 D0 00            [24] 1160 	pop	ar0
      002DE9 D0 01            [24] 1161 	pop	ar1
                                   1162 ;	keyboards/ajazz/ak820/ak820_macro.c:160: if (!ak820_nvm_ok()) return false;
      002DEB 12 3E 79         [24] 1163 	lcall	_ak820_nvm_ok
      002DEE E5 82            [12] 1164 	mov	a, dpl
      002DF0 70 03            [24] 1165 	jnz	00146$
      002DF2 F5 82            [12] 1166 	mov	dpl,a
      002DF4 22               [24] 1167 	ret
      002DF5                       1168 00146$:
                                   1169 ;	keyboards/ajazz/ak820/ak820_macro.c:161: covered = end;
      002DF5 90 04 FF         [24] 1170 	mov	dptr,#_covered
      002DF8 E8               [12] 1171 	mov	a,r0
      002DF9 F0               [24] 1172 	movx	@dptr,a
      002DFA E9               [12] 1173 	mov	a,r1
      002DFB A3               [24] 1174 	inc	dptr
      002DFC F0               [24] 1175 	movx	@dptr,a
                                   1176 ;	keyboards/ajazz/ak820/ak820_macro.c:162: parsed.terminated = next.terminated;
      002DFD 90 05 1B         [24] 1177 	mov	dptr,#_ak820_macro_write_next_10000_100
      002E00 E0               [24] 1178 	movx	a,@dptr
      002E01 90 04 FD         [24] 1179 	mov	dptr,#_parsed
      002E04 F0               [24] 1180 	movx	@dptr,a
                                   1181 ;	keyboards/ajazz/ak820/ak820_macro.c:163: parsed.arguments = next.arguments;
      002E05 90 05 1C         [24] 1182 	mov	dptr,#(_ak820_macro_write_next_10000_100 + 0x0001)
      002E08 E0               [24] 1183 	movx	a,@dptr
      002E09 90 04 FE         [24] 1184 	mov	dptr,#(_parsed + 0x0001)
      002E0C F0               [24] 1185 	movx	@dptr,a
                                   1186 ;	keyboards/ajazz/ak820/ak820_macro.c:164: uploading = !complete;
      002E0D E5 0A            [12] 1187 	mov	a,_ak820_macro_write_sloc0_1_0
      002E0F B4 01 00         [24] 1188 	cjne	a,#0x01,00399$
      002E12                       1189 00399$:
      002E12 92 06            [24] 1190 	mov	_uploading,c
                                   1191 ;	keyboards/ajazz/ak820/ak820_macro.c:165: return true;
      002E14 75 82 01         [24] 1192 	mov	dpl, #0x01
                                   1193 ;	keyboards/ajazz/ak820/ak820_macro.c:166: }
      002E17 22               [24] 1194 	ret
                                   1195 ;------------------------------------------------------------
                                   1196 ;Allocation info for local variables in function 'ak820_macro_reset'
                                   1197 ;------------------------------------------------------------
                                   1198 ;i             Allocated with name '_ak820_macro_reset_i_10000_127'
                                   1199 ;------------------------------------------------------------
                                   1200 ;	keyboards/ajazz/ak820/ak820_macro.c:168: bool ak820_macro_reset(void) {
                                   1201 ;	-----------------------------------------
                                   1202 ;	 function ak820_macro_reset
                                   1203 ;	-----------------------------------------
      002E18                       1204 _ak820_macro_reset:
                                   1205 ;	keyboards/ajazz/ak820/ak820_macro.c:170: ak820_nvm_begin();
      002E18 12 3F DB         [24] 1206 	lcall	_ak820_nvm_begin
                                   1207 ;	keyboards/ajazz/ak820/ak820_macro.c:171: busy_write(1);
      002E1B 75 82 01         [24] 1208 	mov	dpl, #0x01
      002E1E 12 28 C0         [24] 1209 	lcall	_busy_write
                                   1210 ;	keyboards/ajazz/ak820/ak820_macro.c:172: if (ak820_nvm_ok()) {
      002E21 12 3E 79         [24] 1211 	lcall	_ak820_nvm_ok
      002E24 E5 82            [12] 1212 	mov	a, dpl
      002E26 60 3E            [24] 1213 	jz	00105$
                                   1214 ;	keyboards/ajazz/ak820/ak820_macro.c:173: for (i = 0; i < DYNAMIC_KEYMAP_MACRO_COUNT; ++i)
      002E28 7E 00            [12] 1215 	mov	r6,#0x00
      002E2A 7F 00            [12] 1216 	mov	r7,#0x00
      002E2C                       1217 00106$:
                                   1218 ;	keyboards/ajazz/ak820/ak820_macro.c:174: eeprom_update_byte((uint8_t *)(uintptr_t)(DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + i), 0);
      002E2C 8E 04            [24] 1219 	mov	ar4,r6
      002E2E 8F 05            [24] 1220 	mov	ar5,r7
      002E30 74 08            [12] 1221 	mov	a,#0x08
      002E32 2D               [12] 1222 	add	a, r5
      002E33 FD               [12] 1223 	mov	r5,a
      002E34 7B 00            [12] 1224 	mov	r3,#0x00
      002E36 90 06 9B         [24] 1225 	mov	dptr,#_eeprom_update_byte_PARM_2
      002E39 E4               [12] 1226 	clr	a
      002E3A F0               [24] 1227 	movx	@dptr,a
      002E3B 8C 82            [24] 1228 	mov	dpl, r4
      002E3D 8D 83            [24] 1229 	mov	dph, r5
      002E3F 8B F0            [24] 1230 	mov	b, r3
      002E41 12 4E 5A         [24] 1231 	lcall	_eeprom_update_byte
                                   1232 ;	keyboards/ajazz/ak820/ak820_macro.c:173: for (i = 0; i < DYNAMIC_KEYMAP_MACRO_COUNT; ++i)
      002E44 0E               [12] 1233 	inc	r6
      002E45 BE 00 01         [24] 1234 	cjne	r6,#0x00,00140$
      002E48 0F               [12] 1235 	inc	r7
      002E49                       1236 00140$:
      002E49 8E 04            [24] 1237 	mov	ar4,r6
      002E4B 8F 05            [24] 1238 	mov	ar5,r7
      002E4D C3               [12] 1239 	clr	c
      002E4E EC               [12] 1240 	mov	a,r4
      002E4F 94 10            [12] 1241 	subb	a,#0x10
      002E51 ED               [12] 1242 	mov	a,r5
      002E52 94 00            [12] 1243 	subb	a,#0x00
      002E54 40 D6            [24] 1244 	jc	00106$
                                   1245 ;	keyboards/ajazz/ak820/ak820_macro.c:175: ak820_nvm_flush();
      002E56 12 3E 88         [24] 1246 	lcall	_ak820_nvm_flush
                                   1247 ;	keyboards/ajazz/ak820/ak820_macro.c:176: if (ak820_nvm_ok()) commit_length(DYNAMIC_KEYMAP_MACRO_COUNT);
      002E59 12 3E 79         [24] 1248 	lcall	_ak820_nvm_ok
      002E5C E5 82            [12] 1249 	mov	a, dpl
      002E5E 60 06            [24] 1250 	jz	00105$
      002E60 90 00 10         [24] 1251 	mov	dptr,#0x0010
      002E63 12 28 D7         [24] 1252 	lcall	_commit_length
      002E66                       1253 00105$:
                                   1254 ;	keyboards/ajazz/ak820/ak820_macro.c:178: ak820_nvm_end();
      002E66 12 3F F0         [24] 1255 	lcall	_ak820_nvm_end
                                   1256 ;	keyboards/ajazz/ak820/ak820_macro.c:179: ak820_macro_init();
      002E69 12 2A 6B         [24] 1257 	lcall	_ak820_macro_init
                                   1258 ;	keyboards/ajazz/ak820/ak820_macro.c:180: return ak820_nvm_ok();
                                   1259 ;	keyboards/ajazz/ak820/ak820_macro.c:181: }
      002E6C 02 3E 79         [24] 1260 	ljmp	_ak820_nvm_ok
                                   1261 	.area AK820LOW(CODE)
                                   1262 	.area CONST   (CODE)
                                   1263 	.area XINIT   (CODE)
                                   1264 	.area CABS    (ABS,CODE)
