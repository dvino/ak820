hardware_id.o: platforms/mcs51/hardware_id.c \
 keyboards/ajazz/ak820/config.h \
 .build/runtime-one-shot/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h platforms/hardware_id.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdint.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/string.h
