                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000058                        551 _change_owned_sloc1_1_0:
      000058                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000020                        566 _ak820_macro_change_sloc0_1_0:
      000020                        567 	.ds 1
      000021                        568 _change_owned_sloc0_1_0:
      000021                        569 	.ds 1
      000022                        570 _owned_usage_key_sloc0_1_0:
      000022                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      00096C                        580 _owned_mod_refs:
      00096C                        581 	.ds 8
      000974                        582 _owned_weak_refs:
      000974                        583 	.ds 8
      00097C                        584 _owned_mods:
      00097C                        585 	.ds 1
      00097D                        586 _owned_weak_mods:
      00097D                        587 	.ds 1
      00097E                        588 _macro_mods:
      00097E                        589 	.ds 2
      000980                        590 _ak820_macro_primitive::
      000980                        591 	.ds 1
      000981                        592 _ak820_macro_cancelled::
      000981                        593 	.ds 1
      000982                        594 _ak820_macro_change_PARM_2:
      000982                        595 	.ds 1
      000983                        596 _ak820_macro_change_PARM_3:
      000983                        597 	.ds 1
      000984                        598 _ak820_macro_change_bits_10000_293:
      000984                        599 	.ds 2
      000986                        600 _change_owned_PARM_2:
      000986                        601 	.ds 1
      000987                        602 _change_owned_mods_10000_298:
      000987                        603 	.ds 1
      000988                        604 _change_owned_result_10001_302:
      000988                        605 	.ds 1
      000989                        606 _change_owned_bit_20001_303:
      000989                        607 	.ds 1
      00098A                        608 _add_owned_mods_mods_10000_311:
      00098A                        609 	.ds 1
      00098B                        610 _del_owned_mods_mods_10000_313:
      00098B                        611 	.ds 1
      00098C                        612 _add_owned_weak_mods_mods_10000_315:
      00098C                        613 	.ds 1
      00098D                        614 _del_owned_weak_mods_mods_10000_317:
      00098D                        615 	.ds 1
      00098E                        616 _key_refs:
      00098E                        617 	.ds 165
      000A33                        618 _distinct_keys:
      000A33                        619 	.ds 1
      000A34                        620 _macro_keys:
      000A34                        621 	.ds 21
      000A49                        622 _add_owned_key_code_10000_326:
      000A49                        623 	.ds 1
      000A4A                        624 _del_owned_key_code_10000_341:
      000A4A                        625 	.ds 1
      000A4B                        626 _usage_refs:
      000A4B                        627 	.ds 30
      000A69                        628 _usage_order:
      000A69                        629 	.ds 30
      000A87                        630 _usage_lengths:
      000A87                        631 	.ds 2
      000A89                        632 _macro_usages:
      000A89                        633 	.ds 4
      000A8D                        634 _owned_usage_key_PARM_2:
      000A8D                        635 	.ds 1
      000A8E                        636 _owned_usage_key_code_10000_368:
      000A8E                        637 	.ds 1
      000A8F                        638 _owned_usage_key___200000085_20000_369:
      000A8F                        639 	.ds 2
      000A91                        640 _owned_usage_key_which_10000_369:
      000A91                        641 	.ds 1
      000A92                        642 _owned_usage_key_count_10000_369:
      000A92                        643 	.ds 1
      000A93                        644 _owned_usage_key_pos_30001_376:
      000A93                        645 	.ds 1
      000A94                        646 _owned_usage_key_key_40000_381:
      000A94                        647 	.ds 1
      000A95                        648 _send_keyboard_report_last_report_10001_388:
      000A95                        649 	.ds 32
      000AB5                        650 _send_keyboard_report_changed_10001_388:
      000AB5                        651 	.ds 1
      000AB6                        652 _add_weak_mods_mods_10000_406:
      000AB6                        653 	.ds 1
      000AB7                        654 _del_weak_mods_mods_10000_408:
      000AB7                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DB8                        664 _real_mods:
      000DB8                        665 	.ds 1
      000DB9                        666 _weak_mods:
      000DB9                        667 	.ds 1
      000DBA                        668 _actual_keyboard_report::
      000DBA                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007AB5                        713 _ak820_macro_change:
      007AB5 12 38 8D         [24]  714 	lcall	_ak820_outline_0108
      007AB8 90 09 84         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007ABB 12 38 88         [24]  716 	lcall	_ak820_outline_0107
                                    717 ;	quantum/action_util.c:96: if (!ak820_macro_primitive) return true;
      007ABE 90 09 80         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007AC1 E0               [24]  719 	movx	a,@dptr
      007AC2 70 04            [24]  720 	jnz	00102$
      007AC4 75 82 01         [24]  721 	mov	dpl, #0x01
      007AC7 22               [24]  722 	ret
      007AC8                        723 00102$:
                                    724 ;	quantum/action_util.c:97: uint8_t mask = 1u << (index & 7);
      007AC8 90 09 82         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007ACB E0               [24]  726 	movx	a,@dptr
      007ACC FF               [12]  727 	mov	r7,a
      007ACD 74 07            [12]  728 	mov	a,#0x07
      007ACF 5F               [12]  729 	anl	a,r7
      007AD0 12 76 47         [24]  730 	lcall	_ak820_outline_0061
      007AD3 80 02            [24]  731 	sjmp	00123$
      007AD5                        732 00122$:
      007AD5 25 E0            [12]  733 	add	a,acc
      007AD7                        734 00123$:
      007AD7 D5 F0 FB         [24]  735 	djnz	b,00122$
      007ADA FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:98: bits += index >> 3;
      007ADB EF               [12]  738 	mov	a,r7
      007ADC 12 56 BD         [24]  739 	lcall	_ak820_outline_0188
      007ADF FF               [12]  740 	mov	r7,a
      007AE0 90 09 84         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007AE3 12 38 58         [24]  742 	lcall	_ak820_outline_0059
      007AE6 90 09 84         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007AE9 EF               [12]  744 	mov	a,r7
      007AEA 2C               [12]  745 	add	a, r4
      007AEB F0               [24]  746 	movx	@dptr,a
      007AEC E4               [12]  747 	clr	a
      007AED 3D               [12]  748 	addc	a, r5
      007AEE A3               [24]  749 	inc	dptr
      007AEF F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:99: if (((*bits & mask) != 0) == pressed) return false;
      007AF0 90 09 84         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_293
      007AF3 E0               [24]  753 	movx	a,@dptr
      007AF4 FD               [12]  754 	mov	r5,a
      007AF5 A3               [24]  755 	inc	dptr
      007AF6 E0               [24]  756 	movx	a,@dptr
      007AF7 FF               [12]  757 	mov	r7,a
      007AF8 12 80 3A         [24]  758 	lcall	_ak820_outline_0189
      007AFB E0               [24]  759 	movx	a,@dptr
      007AFC FC               [12]  760 	mov	r4,a
      007AFD EE               [12]  761 	mov	a,r6
      007AFE 5C               [12]  762 	anl	a,r4
      007AFF B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007B02                        764 00124$:
      007B02 B3               [12]  765 	cpl	c
      007B03 92 20            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007B05 90 09 83         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007B08 E0               [24]  768 	movx	a,@dptr
      007B09 FB               [12]  769 	mov	r3,a
      007B0A A2 20            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007B0C E4               [12]  771 	clr	a
      007B0D 33               [12]  772 	rlc	a
      007B0E B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007B11 75 82 00         [24]  774 	mov	dpl, #0x00
      007B14 22               [24]  775 	ret
      007B15                        776 00104$:
                                    777 ;	quantum/action_util.c:100: *bits ^= mask;
      007B15 EC               [12]  778 	mov	a,r4
      007B16 62 06            [12]  779 	xrl	ar6,a
      007B18 12 80 3A         [24]  780 	lcall	_ak820_outline_0189
      007B1B EE               [12]  781 	mov	a,r6
      007B1C F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:101: return true;
      007B1D 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:102: }
      007B20 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_298'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_299'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_299'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_299'
                                    795 ;old           Allocated with name '_change_owned_old_30000_301'
                                    796 ;result        Allocated with name '_change_owned_result_10001_302'
                                    797 ;i             Allocated with name '_change_owned_i_20001_303'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_303'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:103: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007B21                        805 _change_owned:
      007B21 E5 82            [12]  806 	mov	a,dpl
      007B23 90 09 87         [24]  807 	mov	dptr,#_change_owned_mods_10000_298
      007B26 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:104: uint8_t kind = mode >> 1;
      007B27 90 09 86         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007B2A E0               [24]  811 	movx	a,@dptr
      007B2B FF               [12]  812 	mov	r7,a
      007B2C C3               [12]  813 	clr	c
      007B2D 13               [12]  814 	rrc	a
      007B2E FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:105: bool pressed = (mode & 1) != 0;
      007B2F 53 07 01         [24]  817 	anl	ar7,#0x01
      007B32 EF               [12]  818 	mov	a,r7
      007B33 B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007B36                        820 00205$:
      007B36 92 21            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007B38 B3               [12]  822 	cpl	c
      007B39 E4               [12]  823 	clr	a
      007B3A 33               [12]  824 	rlc	a
      007B3B F5 58            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:106: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007B3D EE               [12]  827 	mov	a,r6
      007B3E 60 06            [24]  828 	jz	00121$
      007B40 7D 74            [12]  829 	mov	r5,#_owned_weak_refs
      007B42 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007B44 80 04            [24]  831 	sjmp	00122$
      007B46                        832 00121$:
      007B46 7D 6C            [12]  833 	mov	r5,#_owned_mod_refs
      007B48 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007B4A                        835 00122$:
                                    836 ;	quantum/action_util.c:107: if (ak820_macro_primitive) {
      007B4A 90 09 80         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007B4D E0               [24]  838 	movx	a,@dptr
      007B4E 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:108: uint8_t old = macro_mods[kind];
      007B50 EE               [12]  841 	mov	a,r6
      007B51 24 7E            [12]  842 	add	a, #_macro_mods
      007B53 FB               [12]  843 	mov	r3,a
      007B54 E4               [12]  844 	clr	a
      007B55 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007B57 12 48 0F         [24]  846 	lcall	_ak820_outline_0055
                                    847 ;	quantum/action_util.c:109: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007B5A E5 58            [12]  848 	mov	a,_change_owned_sloc1_1_0
      007B5C 60 0A            [24]  849 	jz	00123$
      007B5E 90 09 87         [24]  850 	mov	dptr,#_change_owned_mods_10000_298
      007B61 E0               [24]  851 	movx	a,@dptr
      007B62 F9               [12]  852 	mov	r1,a
      007B63 EA               [12]  853 	mov	a,r2
      007B64 42 01            [12]  854 	orl	ar1,a
      007B66 80 07            [24]  855 	sjmp	00124$
      007B68                        856 00123$:
      007B68 90 09 87         [24]  857 	mov	dptr,#_change_owned_mods_10000_298
      007B6B E0               [24]  858 	movx	a,@dptr
      007B6C F4               [12]  859 	cpl	a
      007B6D 5A               [12]  860 	anl	a,r2
      007B6E F9               [12]  861 	mov	r1,a
      007B6F                        862 00124$:
      007B6F 12 33 FC         [24]  863 	lcall	_ak820_outline_0123
      007B72 E9               [12]  864 	mov	a,r1
      007B73 F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:110: mods &= pressed ? ~old : old;
      007B74 E5 58            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007B76 60 06            [24]  868 	jz	00125$
      007B78 74 FF            [12]  869 	mov	a,#0xff
      007B7A 6A               [12]  870 	xrl	a,r2
      007B7B FC               [12]  871 	mov	r4,a
      007B7C 80 02            [24]  872 	sjmp	00126$
      007B7E                        873 00125$:
      007B7E 8A 04            [24]  874 	mov	ar4,r2
      007B80                        875 00126$:
      007B80 90 09 87         [24]  876 	mov	dptr,#_change_owned_mods_10000_298
      007B83 E0               [24]  877 	movx	a,@dptr
      007B84 5C               [12]  878 	anl	a,r4
      007B85 F0               [24]  879 	movx	@dptr,a
      007B86                        880 00102$:
                                    881 ;	quantum/action_util.c:112: uint8_t result = 0;
      007B86 90 09 88         [24]  882 	mov	dptr,#_change_owned_result_10001_302
      007B89 E4               [12]  883 	clr	a
      007B8A F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:113: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007B8B 90 09 89         [24]  886 	mov	dptr,#_change_owned_bit_20001_303
      007B8E 04               [12]  887 	inc	a
      007B8F F0               [24]  888 	movx	@dptr,a
      007B90 90 09 87         [24]  889 	mov	dptr,#_change_owned_mods_10000_298
      007B93 E0               [24]  890 	movx	a,@dptr
      007B94 FC               [12]  891 	mov	r4,a
      007B95 7B 00            [12]  892 	mov	r3,#0x00
      007B97                        893 00117$:
      007B97 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007B9A                        895 00210$:
      007B9A 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:114: if (mods & bit) {
      007B9C 90 09 89         [24]  898 	mov	dptr,#_change_owned_bit_20001_303
      007B9F E0               [24]  899 	movx	a,@dptr
      007BA0 5C               [12]  900 	anl	a,r4
      007BA1 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:115: if (pressed) ++refs[i];
      007BA3 E5 58            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007BA5 60 0C            [24]  904 	jz	00106$
      007BA7 EB               [12]  905 	mov	a,r3
      007BA8 2D               [12]  906 	add	a, r5
      007BA9 12 38 1F         [24]  907 	lcall	_ak820_outline_0015
      007BAC F8               [12]  908 	mov	r0,a
      007BAD 08               [12]  909 	inc	r0
      007BAE 12 7F EE         [24]  910 	lcall	_ak820_outline_0062
      007BB1 80 0C            [24]  911 	sjmp	00109$
      007BB3                        912 00106$:
                                    913 ;	quantum/action_util.c:116: else if (refs[i]) --refs[i];
      007BB3 EB               [12]  914 	mov	a,r3
      007BB4 2D               [12]  915 	add	a, r5
      007BB5 12 38 1F         [24]  916 	lcall	_ak820_outline_0015
      007BB8 F8               [12]  917 	mov	r0,a
      007BB9 60 04            [24]  918 	jz	00109$
      007BBB 18               [12]  919 	dec	r0
      007BBC 12 7F EE         [24]  920 	lcall	_ak820_outline_0062
      007BBF                        921 00109$:
                                    922 ;	quantum/action_util.c:118: if (refs[i]) result |= bit;
      007BBF EB               [12]  923 	mov	a,r3
      007BC0 2D               [12]  924 	add	a, r5
      007BC1 12 38 1F         [24]  925 	lcall	_ak820_outline_0015
      007BC4 60 0B            [24]  926 	jz	00118$
      007BC6 90 09 89         [24]  927 	mov	dptr,#_change_owned_bit_20001_303
      007BC9 E0               [24]  928 	movx	a,@dptr
      007BCA FA               [12]  929 	mov	r2,a
      007BCB 90 09 88         [24]  930 	mov	dptr,#_change_owned_result_10001_302
      007BCE E0               [24]  931 	movx	a,@dptr
      007BCF 4A               [12]  932 	orl	a,r2
      007BD0 F0               [24]  933 	movx	@dptr,a
      007BD1                        934 00118$:
                                    935 ;	quantum/action_util.c:113: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007BD1 0B               [12]  936 	inc	r3
      007BD2 90 09 89         [24]  937 	mov	dptr,#_change_owned_bit_20001_303
      007BD5 E0               [24]  938 	movx	a,@dptr
      007BD6 25 E0            [12]  939 	add	a,acc
      007BD8 F0               [24]  940 	movx	@dptr,a
      007BD9 80 BC            [24]  941 	sjmp	00117$
      007BDB                        942 00112$:
                                    943 ;	quantum/action_util.c:120: if (kind) owned_weak_mods = result;
      007BDB EE               [12]  944 	mov	a,r6
      007BDC 60 09            [24]  945 	jz	00114$
      007BDE 90 09 88         [24]  946 	mov	dptr,#_change_owned_result_10001_302
      007BE1 E0               [24]  947 	movx	a,@dptr
      007BE2 90 09 7D         [24]  948 	mov	dptr,#_owned_weak_mods
      007BE5 F0               [24]  949 	movx	@dptr,a
      007BE6 22               [24]  950 	ret
      007BE7                        951 00114$:
                                    952 ;	quantum/action_util.c:121: else owned_mods = result;
      007BE7 90 09 88         [24]  953 	mov	dptr,#_change_owned_result_10001_302
      007BEA E0               [24]  954 	movx	a,@dptr
      007BEB 90 09 7C         [24]  955 	mov	dptr,#_owned_mods
      007BEE F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:122: }
      007BEF 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_311'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:123: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      007BF0                        968 _add_owned_mods:
      007BF0 E5 82            [12]  969 	mov	a,dpl
      007BF2 90 09 8A         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_311
      007BF5 12 80 0E         [24]  971 	lcall	_ak820_outline_0116
      007BF8 74 01            [12]  972 	mov	a,#0x01
      007BFA F0               [24]  973 	movx	@dptr,a
      007BFB 8F 82            [24]  974 	mov	dpl, r7
      007BFD 02 7B 21         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_313'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:124: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      007C00                        985 _del_owned_mods:
      007C00 E5 82            [12]  986 	mov	a,dpl
      007C02 90 09 8B         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_313
      007C05 12 80 0E         [24]  988 	lcall	_ak820_outline_0116
      007C08 E4               [12]  989 	clr	a
      007C09 F0               [24]  990 	movx	@dptr,a
      007C0A 8F 82            [24]  991 	mov	dpl, r7
      007C0C 02 7B 21         [24]  992 	ljmp	_change_owned
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    995 ;------------------------------------------------------------
                                    996 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_315'
                                    997 ;------------------------------------------------------------
                                    998 ;	quantum/action_util.c:125: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    999 ;	-----------------------------------------
                                   1000 ;	 function add_owned_weak_mods
                                   1001 ;	-----------------------------------------
      007C0F                       1002 _add_owned_weak_mods:
      007C0F E5 82            [12] 1003 	mov	a,dpl
      007C11 90 09 8C         [24] 1004 	mov	dptr,#_add_owned_weak_mods_mods_10000_315
      007C14 12 80 0E         [24] 1005 	lcall	_ak820_outline_0116
      007C17 74 03            [12] 1006 	mov	a,#0x03
      007C19 F0               [24] 1007 	movx	@dptr,a
      007C1A 8F 82            [24] 1008 	mov	dpl, r7
      007C1C 02 7B 21         [24] 1009 	ljmp	_change_owned
                                   1010 ;------------------------------------------------------------
                                   1011 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1012 ;------------------------------------------------------------
                                   1013 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_317'
                                   1014 ;------------------------------------------------------------
                                   1015 ;	quantum/action_util.c:126: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1016 ;	-----------------------------------------
                                   1017 ;	 function del_owned_weak_mods
                                   1018 ;	-----------------------------------------
      007C1F                       1019 _del_owned_weak_mods:
      007C1F E5 82            [12] 1020 	mov	a,dpl
      007C21 90 09 8D         [24] 1021 	mov	dptr,#_del_owned_weak_mods_mods_10000_317
      007C24 12 80 0E         [24] 1022 	lcall	_ak820_outline_0116
      007C27 74 02            [12] 1023 	mov	a,#0x02
      007C29 F0               [24] 1024 	movx	@dptr,a
      007C2A 8F 82            [24] 1025 	mov	dpl, r7
      007C2C 02 7B 21         [24] 1026 	ljmp	_change_owned
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1029 ;------------------------------------------------------------
                                   1030 ;i             Allocated with name '_clear_owned_mods_i_20000_321'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	quantum/action_util.c:127: void clear_owned_mods(void) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function clear_owned_mods
                                   1035 ;	-----------------------------------------
      007C2F                       1036 _clear_owned_mods:
                                   1037 ;	quantum/action_util.c:128: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007C2F 7F 00            [12] 1038 	mov	r7,#0x00
      007C31                       1039 00103$:
      007C31 BF 08 00         [24] 1040 	cjne	r7,#0x08,00122$
      007C34                       1041 00122$:
      007C34 50 1A            [24] 1042 	jnc	00101$
      007C36 EF               [12] 1043 	mov	a,r7
      007C37 24 6C            [12] 1044 	add	a, #_owned_mod_refs
      007C39 FD               [12] 1045 	mov	r5,a
      007C3A E4               [12] 1046 	clr	a
      007C3B 34 09            [12] 1047 	addc	a, #(_owned_mod_refs >> 8)
      007C3D FE               [12] 1048 	mov	r6,a
      007C3E EF               [12] 1049 	mov	a,r7
      007C3F 24 74            [12] 1050 	add	a, #_owned_weak_refs
      007C41 F5 82            [12] 1051 	mov	dpl,a
      007C43 E4               [12] 1052 	clr	a
      007C44 34 09            [12] 1053 	addc	a, #(_owned_weak_refs >> 8)
      007C46 F5 83            [12] 1054 	mov	dph,a
      007C48 E4               [12] 1055 	clr	a
      007C49 F0               [24] 1056 	movx	@dptr,a
      007C4A 12 80 15         [24] 1057 	lcall	_ak820_outline_0121
      007C4D 0F               [12] 1058 	inc	r7
      007C4E 80 E1            [24] 1059 	sjmp	00103$
      007C50                       1060 00101$:
                                   1061 ;	quantum/action_util.c:129: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007C50 90 09 7F         [24] 1062 	mov	dptr,#(_macro_mods + 0x0001)
      007C53 E4               [12] 1063 	clr	a
      007C54 F0               [24] 1064 	movx	@dptr,a
      007C55 90 09 7E         [24] 1065 	mov	dptr,#_macro_mods
      007C58 F0               [24] 1066 	movx	@dptr,a
      007C59 90 09 7D         [24] 1067 	mov	dptr,#_owned_weak_mods
      007C5C F0               [24] 1068 	movx	@dptr,a
      007C5D 90 09 7C         [24] 1069 	mov	dptr,#_owned_mods
      007C60 F0               [24] 1070 	movx	@dptr,a
                                   1071 ;	quantum/action_util.c:130: ak820_macro_cancelled = true;
      007C61 90 09 81         [24] 1072 	mov	dptr,#_ak820_macro_cancelled
      007C64 04               [12] 1073 	inc	a
      007C65 F0               [24] 1074 	movx	@dptr,a
                                   1075 ;	quantum/action_util.c:131: }
      007C66 22               [24] 1076 	ret
                                   1077 ;------------------------------------------------------------
                                   1078 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1079 ;------------------------------------------------------------
                                   1080 ;i             Allocated with name '_clear_owned_keys_i_20000_324'
                                   1081 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1082 ;------------------------------------------------------------
                                   1083 ;	quantum/action_util.c:137: void clear_owned_keys(void) {
                                   1084 ;	-----------------------------------------
                                   1085 ;	 function clear_owned_keys
                                   1086 ;	-----------------------------------------
      007C67                       1087 _clear_owned_keys:
                                   1088 ;	quantum/action_util.c:138: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007C67 7F 00            [12] 1089 	mov	r7,#0x00
      007C69                       1090 00104$:
      007C69 EF               [12] 1091 	mov	a,r7
      007C6A 24 5B            [12] 1092 	add	a,#0xff - 0xa4
      007C6C 40 0D            [24] 1093 	jc	00101$
                                   1094 ;	free result
      007C6E EF               [12] 1095 	mov	a,r7
      007C6F 24 8E            [12] 1096 	add	a, #_key_refs
      007C71 F5 82            [12] 1097 	mov	dpl,a
      007C73 E4               [12] 1098 	clr	a
      007C74 34 09            [12] 1099 	addc	a, #(_key_refs >> 8)
      007C76 12 7A A6         [24] 1100 	lcall	_ak820_outline_0163
      007C79 80 EE            [24] 1101 	sjmp	00104$
      007C7B                       1102 00101$:
                                   1103 ;	quantum/action_util.c:139: distinct_keys = 0;
      007C7B 90 0A 33         [24] 1104 	mov	dptr,#_distinct_keys
      007C7E E4               [12] 1105 	clr	a
      007C7F F0               [24] 1106 	movx	@dptr,a
                                   1107 ;	quantum/action_util.c:140: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007C80 FF               [12] 1108 	mov	r7,a
      007C81                       1109 00107$:
      007C81 BF 15 00         [24] 1110 	cjne	r7,#0x15,00142$
      007C84                       1111 00142$:
      007C84 50 0D            [24] 1112 	jnc	00109$
      007C86 EF               [12] 1113 	mov	a,r7
      007C87 24 34            [12] 1114 	add	a, #_macro_keys
      007C89 F5 82            [12] 1115 	mov	dpl,a
      007C8B E4               [12] 1116 	clr	a
      007C8C 34 0A            [12] 1117 	addc	a, #(_macro_keys >> 8)
      007C8E 12 7A A6         [24] 1118 	lcall	_ak820_outline_0163
      007C91 80 EE            [24] 1119 	sjmp	00107$
      007C93                       1120 00109$:
                                   1121 ;	quantum/action_util.c:141: }
      007C93 22               [24] 1122 	ret
                                   1123 ;------------------------------------------------------------
                                   1124 ;Allocation info for local variables in function 'add_owned_key'
                                   1125 ;------------------------------------------------------------
                                   1126 ;code          Allocated with name '_add_owned_key_code_10000_326'
                                   1127 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_335'
                                   1128 ;key           Allocated with name '_add_owned_key_key_50000_336'
                                   1129 ;i             Allocated with name '_add_owned_key_i_40000_334'
                                   1130 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_338'
                                   1131 ;key           Allocated with name '_add_owned_key_key_40000_339'
                                   1132 ;------------------------------------------------------------
                                   1133 ;	quantum/action_util.c:142: bool add_owned_key(uint8_t code) {
                                   1134 ;	-----------------------------------------
                                   1135 ;	 function add_owned_key
                                   1136 ;	-----------------------------------------
      007C94                       1137 _add_owned_key:
      007C94 E5 82            [12] 1138 	mov	a,dpl
      007C96 90 0A 49         [24] 1139 	mov	dptr,#_add_owned_key_code_10000_326
      007C99 12 80 26         [24] 1140 	lcall	_ak820_outline_0132
                                   1141 ;	quantum/action_util.c:143: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007C9C 74 01            [12] 1142 	mov	a,#0x01
      007C9E F0               [24] 1143 	movx	@dptr,a
      007C9F 90 0A 34         [24] 1144 	mov	dptr,#_macro_keys
      007CA2 C0 07            [24] 1145 	push	ar7
      007CA4 12 7A B5         [24] 1146 	lcall	_ak820_macro_change
      007CA7 E5 82            [12] 1147 	mov	a, dpl
      007CA9 D0 07            [24] 1148 	pop	ar7
      007CAB 70 03            [24] 1149 	jnz	00102$
      007CAD F5 82            [12] 1150 	mov	dpl,a
      007CAF 22               [24] 1151 	ret
      007CB0                       1152 00102$:
                                   1153 ;	quantum/action_util.c:144: if (key_refs[code]++) return false;
      007CB0 12 7F E0         [24] 1154 	lcall	_ak820_outline_0030
      007CB3 FC               [12] 1155 	mov	r4,a
      007CB4 04               [12] 1156 	inc	a
      007CB5 12 80 15         [24] 1157 	lcall	_ak820_outline_0121
      007CB8 EC               [12] 1158 	mov	a,r4
      007CB9 60 04            [24] 1159 	jz	00104$
      007CBB 75 82 00         [24] 1160 	mov	dpl, #0x00
      007CBE 22               [24] 1161 	ret
      007CBF                       1162 00104$:
                                   1163 ;	quantum/action_util.c:145: ++distinct_keys;
      007CBF 90 0A 33         [24] 1164 	mov	dptr,#_distinct_keys
      007CC2 E0               [24] 1165 	movx	a,@dptr
      007CC3 24 01            [12] 1166 	add	a, #0x01
      007CC5 F0               [24] 1167 	movx	@dptr,a
                                   1168 ;	quantum/action_util.c:147: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007CC6 90 0D A7         [24] 1169 	mov	dptr,#_keyboard_protocol
      007CC9 E0               [24] 1170 	movx	a,@dptr
      007CCA 60 11            [24] 1171 	jz	00106$
      007CCC 90 0A B8         [24] 1172 	mov	dptr,#_keymap_config
      007CCF E0               [24] 1173 	movx	a,@dptr
      007CD0 30 E7 0A         [24] 1174 	jnb	acc.7,00106$
                                   1175 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007CD3 12 80 31         [24] 1176 	lcall	_ak820_outline_0176
      007CD6 12 6E 28         [24] 1177 	lcall	_add_key_to_report
                                   1178 ;	quantum/action_util.c:147: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007CD9 75 82 01         [24] 1179 	mov	dpl, #0x01
      007CDC 22               [24] 1180 	ret
      007CDD                       1181 00106$:
                                   1182 ;	quantum/action_util.c:149: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007CDD 90 0A 33         [24] 1183 	mov	dptr,#_distinct_keys
      007CE0 E0               [24] 1184 	movx	a,@dptr
      007CE1 24 F9            [12] 1185 	add	a,#0xff - 0x06
      007CE3 50 17            [24] 1186 	jnc	00110$
                                   1187 ;	free result
                                   1188 ;	quantum/action_util.c:150: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007CE5 7F 00            [12] 1189 	mov	r7,#0x00
      007CE7                       1190 00115$:
      007CE7 BF 06 00         [24] 1191 	cjne	r7,#0x06,00174$
      007CEA                       1192 00174$:
      007CEA 50 1E            [24] 1193 	jnc	00111$
      007CEC EF               [12] 1194 	mov	a,r7
      007CED 24 BC            [12] 1195 	add	a, #(_actual_keyboard_report + 0x0002)
      007CEF F5 82            [12] 1196 	mov	dpl,a
      007CF1 E4               [12] 1197 	clr	a
      007CF2 34 0D            [12] 1198 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007CF4 F5 83            [12] 1199 	mov	dph,a
      007CF6 74 01            [12] 1200 	mov	a,#0x01
      007CF8 F0               [24] 1201 	movx	@dptr,a
      007CF9 0F               [12] 1202 	inc	r7
      007CFA 80 EB            [24] 1203 	sjmp	00115$
      007CFC                       1204 00110$:
                                   1205 ;	quantum/action_util.c:151: } else add_key(code);
      007CFC 90 0A 49         [24] 1206 	mov	dptr,#_add_owned_key_code_10000_326
      007CFF E0               [24] 1207 	movx	a,@dptr
                                   1208 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D00 90 07 FC         [24] 1209 	mov	dptr,#_add_key_to_report_PARM_2
      007D03 F0               [24] 1210 	movx	@dptr,a
      007D04 90 0D BA         [24] 1211 	mov	dptr,#_actual_keyboard_report
      007D07 12 6E 28         [24] 1212 	lcall	_add_key_to_report
                                   1213 ;	quantum/action_util.c:151: } else add_key(code);
      007D0A                       1214 00111$:
                                   1215 ;	quantum/action_util.c:152: return true;
      007D0A 75 82 01         [24] 1216 	mov	dpl, #0x01
                                   1217 ;	quantum/action_util.c:153: }
      007D0D 22               [24] 1218 	ret
                                   1219 ;------------------------------------------------------------
                                   1220 ;Allocation info for local variables in function 'del_owned_key'
                                   1221 ;------------------------------------------------------------
                                   1222 ;code          Allocated with name '_del_owned_key_code_10000_341'
                                   1223 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_352'
                                   1224 ;key           Allocated with name '_del_owned_key_key_50000_353'
                                   1225 ;key           Allocated with name '_del_owned_key_key_40000_350'
                                   1226 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_358'
                                   1227 ;key           Allocated with name '_del_owned_key_key_70000_359'
                                   1228 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_361'
                                   1229 ;key           Allocated with name '_del_owned_key_key_40000_362'
                                   1230 ;------------------------------------------------------------
                                   1231 ;	quantum/action_util.c:154: bool del_owned_key(uint8_t code) {
                                   1232 ;	-----------------------------------------
                                   1233 ;	 function del_owned_key
                                   1234 ;	-----------------------------------------
      007D0E                       1235 _del_owned_key:
      007D0E E5 82            [12] 1236 	mov	a,dpl
      007D10 90 0A 4A         [24] 1237 	mov	dptr,#_del_owned_key_code_10000_341
      007D13 12 80 26         [24] 1238 	lcall	_ak820_outline_0132
                                   1239 ;	quantum/action_util.c:155: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007D16 E4               [12] 1240 	clr	a
      007D17 F0               [24] 1241 	movx	@dptr,a
      007D18 90 0A 34         [24] 1242 	mov	dptr,#_macro_keys
      007D1B C0 07            [24] 1243 	push	ar7
      007D1D 12 7A B5         [24] 1244 	lcall	_ak820_macro_change
      007D20 E5 82            [12] 1245 	mov	a, dpl
      007D22 D0 07            [24] 1246 	pop	ar7
      007D24 70 03            [24] 1247 	jnz	00102$
      007D26 F5 82            [12] 1248 	mov	dpl,a
      007D28 22               [24] 1249 	ret
      007D29                       1250 00102$:
                                   1251 ;	quantum/action_util.c:156: if (!key_refs[code] || --key_refs[code]) return false;
      007D29 12 7F E0         [24] 1252 	lcall	_ak820_outline_0030
      007D2C FC               [12] 1253 	mov	r4,a
      007D2D 60 07            [24] 1254 	jz	00103$
      007D2F 1C               [12] 1255 	dec	r4
      007D30 12 43 37         [24] 1256 	lcall	_ak820_outline_0063
      007D33 EC               [12] 1257 	mov	a,r4
      007D34 60 04            [24] 1258 	jz	00104$
      007D36                       1259 00103$:
      007D36 75 82 00         [24] 1260 	mov	dpl, #0x00
      007D39 22               [24] 1261 	ret
      007D3A                       1262 00104$:
                                   1263 ;	quantum/action_util.c:157: --distinct_keys;
      007D3A 90 0A 33         [24] 1264 	mov	dptr,#_distinct_keys
      007D3D E0               [24] 1265 	movx	a,@dptr
      007D3E 14               [12] 1266 	dec	a
      007D3F F0               [24] 1267 	movx	@dptr,a
                                   1268 ;	quantum/action_util.c:159: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007D40 90 0D A7         [24] 1269 	mov	dptr,#_keyboard_protocol
      007D43 E0               [24] 1270 	movx	a,@dptr
      007D44 60 16            [24] 1271 	jz	00107$
      007D46 90 0A B8         [24] 1272 	mov	dptr,#_keymap_config
      007D49 E0               [24] 1273 	movx	a,@dptr
      007D4A 30 E7 0F         [24] 1274 	jnb	acc.7,00107$
                                   1275 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007D4D 90 07 FF         [24] 1276 	mov	dptr,#_del_key_from_report_PARM_2
      007D50 EF               [12] 1277 	mov	a,r7
      007D51 F0               [24] 1278 	movx	@dptr,a
      007D52 90 0D BA         [24] 1279 	mov	dptr,#_actual_keyboard_report
      007D55 12 6E 5E         [24] 1280 	lcall	_del_key_from_report
                                   1281 ;	quantum/action_util.c:159: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007D58 75 82 01         [24] 1282 	mov	dpl, #0x01
      007D5B 22               [24] 1283 	ret
      007D5C                       1284 00107$:
                                   1285 ;	quantum/action_util.c:161: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007D5C 90 0A 33         [24] 1286 	mov	dptr,#_distinct_keys
      007D5F E0               [24] 1287 	movx	a,@dptr
      007D60 FF               [12] 1288 	mov  r7,a
      007D61 24 F9            [12] 1289 	add	a,#0xff - 0x06
      007D63 50 04            [24] 1290 	jnc	00110$
                                   1291 ;	free result
      007D65 75 82 01         [24] 1292 	mov	dpl, #0x01
      007D68 22               [24] 1293 	ret
      007D69                       1294 00110$:
                                   1295 ;	quantum/action_util.c:162: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007D69 BF 06 1F         [24] 1296 	cjne	r7,#0x06,00115$
                                   1297 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007D6C 90 0D BA         [24] 1298 	mov	dptr,#_actual_keyboard_report
      007D6F 12 6E 94         [24] 1299 	lcall	_clear_keys_from_report
                                   1300 ;	quantum/action_util.c:165: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007D72 7F 04            [12] 1301 	mov	r7,#0x04
      007D74                       1302 00122$:
      007D74 EF               [12] 1303 	mov	a,r7
      007D75 24 5B            [12] 1304 	add	a,#0xff - 0xa4
      007D77 40 20            [24] 1305 	jc	00116$
                                   1306 ;	free result
      007D79 12 7F E0         [24] 1307 	lcall	_ak820_outline_0030
      007D7C 60 0A            [24] 1308 	jz	00123$
                                   1309 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007D7E 12 80 31         [24] 1310 	lcall	_ak820_outline_0176
      007D81 C0 07            [24] 1311 	push	ar7
      007D83 12 6E 28         [24] 1312 	lcall	_add_key_to_report
      007D86 D0 07            [24] 1313 	pop	ar7
                                   1314 ;	quantum/action_util.c:165: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007D88                       1315 00123$:
      007D88 0F               [12] 1316 	inc	r7
      007D89 80 E9            [24] 1317 	sjmp	00122$
      007D8B                       1318 00115$:
                                   1319 ;	quantum/action_util.c:166: } else del_key(code);
      007D8B 90 0A 4A         [24] 1320 	mov	dptr,#_del_owned_key_code_10000_341
      007D8E E0               [24] 1321 	movx	a,@dptr
                                   1322 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007D8F 90 07 FF         [24] 1323 	mov	dptr,#_del_key_from_report_PARM_2
      007D92 F0               [24] 1324 	movx	@dptr,a
      007D93 90 0D BA         [24] 1325 	mov	dptr,#_actual_keyboard_report
      007D96 12 6E 5E         [24] 1326 	lcall	_del_key_from_report
                                   1327 ;	quantum/action_util.c:166: } else del_key(code);
      007D99                       1328 00116$:
                                   1329 ;	quantum/action_util.c:167: return true;
      007D99 75 82 01         [24] 1330 	mov	dpl, #0x01
                                   1331 ;	quantum/action_util.c:168: }
      007D9C 22               [24] 1332 	ret
                                   1333 ;------------------------------------------------------------
                                   1334 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1335 ;------------------------------------------------------------
                                   1336 ;i             Allocated with name '_clear_owned_usages_i_20000_366'
                                   1337 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1338 ;------------------------------------------------------------
                                   1339 ;	quantum/action_util.c:178: void clear_owned_usages(void) {
                                   1340 ;	-----------------------------------------
                                   1341 ;	 function clear_owned_usages
                                   1342 ;	-----------------------------------------
      007D9D                       1343 _clear_owned_usages:
                                   1344 ;	quantum/action_util.c:179: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007D9D 7F 00            [12] 1345 	mov	r7,#0x00
      007D9F                       1346 00104$:
      007D9F BF 1E 00         [24] 1347 	cjne	r7,#0x1e,00141$
      007DA2                       1348 00141$:
      007DA2 50 14            [24] 1349 	jnc	00101$
      007DA4 EF               [12] 1350 	mov	a,r7
      007DA5 24 4B            [12] 1351 	add	a, #_usage_refs
      007DA7 FD               [12] 1352 	mov	r5,a
      007DA8 E4               [12] 1353 	clr	a
      007DA9 34 0A            [12] 1354 	addc	a, #(_usage_refs >> 8)
      007DAB FE               [12] 1355 	mov	r6,a
      007DAC EF               [12] 1356 	mov	a,r7
      007DAD 12 7F F5         [24] 1357 	lcall	_ak820_outline_0067
      007DB0 E4               [12] 1358 	clr	a
      007DB1 F0               [24] 1359 	movx	@dptr,a
      007DB2 12 80 15         [24] 1360 	lcall	_ak820_outline_0121
      007DB5 0F               [12] 1361 	inc	r7
      007DB6 80 E7            [24] 1362 	sjmp	00104$
      007DB8                       1363 00101$:
                                   1364 ;	quantum/action_util.c:180: usage_lengths[0] = usage_lengths[1] = 0;
      007DB8 90 0A 88         [24] 1365 	mov	dptr,#(_usage_lengths + 0x0001)
      007DBB E4               [12] 1366 	clr	a
      007DBC F0               [24] 1367 	movx	@dptr,a
      007DBD 90 0A 87         [24] 1368 	mov	dptr,#_usage_lengths
      007DC0 F0               [24] 1369 	movx	@dptr,a
                                   1370 ;	quantum/action_util.c:181: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007DC1 FF               [12] 1371 	mov	r7,a
      007DC2                       1372 00107$:
      007DC2 BF 04 00         [24] 1373 	cjne	r7,#0x04,00143$
      007DC5                       1374 00143$:
      007DC5 50 0D            [24] 1375 	jnc	00109$
      007DC7 EF               [12] 1376 	mov	a,r7
      007DC8 24 89            [12] 1377 	add	a, #_macro_usages
      007DCA F5 82            [12] 1378 	mov	dpl,a
      007DCC E4               [12] 1379 	clr	a
      007DCD 34 0A            [12] 1380 	addc	a, #(_macro_usages >> 8)
      007DCF 12 7A A6         [24] 1381 	lcall	_ak820_outline_0163
      007DD2 80 EE            [24] 1382 	sjmp	00107$
      007DD4                       1383 00109$:
                                   1384 ;	quantum/action_util.c:182: }
      007DD4 22               [24] 1385 	ret
                                   1386 ;------------------------------------------------------------
                                   1387 ;Allocation info for local variables in function 'owned_usage_key'
                                   1388 ;------------------------------------------------------------
                                   1389 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1390 ;code          Allocated with name '_owned_usage_key_code_10000_368'
                                   1391 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_369'
                                   1392 ;which         Allocated with name '_owned_usage_key_which_10000_369'
                                   1393 ;base          Allocated with name '_owned_usage_key_base_10000_369'
                                   1394 ;count         Allocated with name '_owned_usage_key_count_10000_369'
                                   1395 ;index         Allocated with name '_owned_usage_key_index_10000_369'
                                   1396 ;pos           Allocated with name '_owned_usage_key_pos_30001_376'
                                   1397 ;i             Allocated with name '_owned_usage_key_i_40001_377'
                                   1398 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_380'
                                   1399 ;key           Allocated with name '_owned_usage_key_key_40000_381'
                                   1400 ;------------------------------------------------------------
                                   1401 ;	quantum/action_util.c:183: void owned_usage_key(uint8_t code, bool pressed) {
                                   1402 ;	-----------------------------------------
                                   1403 ;	 function owned_usage_key
                                   1404 ;	-----------------------------------------
      007DD5                       1405 _owned_usage_key:
      007DD5 E5 82            [12] 1406 	mov	a,dpl
      007DD7 90 0A 8E         [24] 1407 	mov	dptr,#_owned_usage_key_code_10000_368
      007DDA F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/action_util.c:184: uint8_t which = code >= KC_AUDIO_MUTE;
      007DDB E0               [24] 1410 	movx	a,@dptr
      007DDC FF               [12] 1411 	mov	r7,a
      007DDD BF A8 00         [24] 1412 	cjne	r7,#0xa8,00244$
      007DE0                       1413 00244$:
      007DE0 B3               [12] 1414 	cpl	c
      007DE1 92 22            [24] 1415 	mov	_owned_usage_key_sloc0_1_0,c
      007DE3 E4               [12] 1416 	clr	a
      007DE4 33               [12] 1417 	rlc	a
      007DE5 FF               [12] 1418 	mov	r7,a
      007DE6 90 0A 91         [24] 1419 	mov	dptr,#_owned_usage_key_which_10000_369
      007DE9 F0               [24] 1420 	movx	@dptr,a
                                   1421 ;	quantum/action_util.c:185: uint8_t base = which ? SYSTEM_COUNT : 0;
      007DEA EF               [12] 1422 	mov	a,r7
      007DEB 60 02            [24] 1423 	jz	00129$
      007DED 74 03            [12] 1424 	mov	a,#0x03
      007DEF                       1425 00129$:
      007DEF FE               [12] 1426 	mov	r6,a
                                   1427 ;	quantum/action_util.c:186: uint8_t count = usage_lengths[which];
      007DF0 EF               [12] 1428 	mov	a,r7
      007DF1 24 87            [12] 1429 	add	a, #_usage_lengths
      007DF3 FD               [12] 1430 	mov	r5,a
      007DF4 E4               [12] 1431 	clr	a
      007DF5 34 0A            [12] 1432 	addc	a, #(_usage_lengths >> 8)
      007DF7 FF               [12] 1433 	mov	r7,a
      007DF8 12 80 3A         [24] 1434 	lcall	_ak820_outline_0189
      007DFB E0               [24] 1435 	movx	a,@dptr
      007DFC FC               [12] 1436 	mov	r4,a
                                   1437 ;	quantum/action_util.c:187: uint8_t index = code - KC_SYSTEM_POWER;
      007DFD 90 0A 8E         [24] 1438 	mov	dptr,#_owned_usage_key_code_10000_368
      007E00 E0               [24] 1439 	movx	a,@dptr
      007E01 24 5B            [12] 1440 	add	a,#0x5b
      007E03 FB               [12] 1441 	mov	r3,a
                                   1442 ;	quantum/action_util.c:188: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007E04 90 0A 8D         [24] 1443 	mov	dptr,#_owned_usage_key_PARM_2
      007E07 E0               [24] 1444 	movx	a,@dptr
      007E08 FA               [12] 1445 	mov	r2,a
      007E09 90 09 82         [24] 1446 	mov	dptr,#_ak820_macro_change_PARM_2
      007E0C EB               [12] 1447 	mov	a,r3
      007E0D F0               [24] 1448 	movx	@dptr,a
      007E0E 90 09 83         [24] 1449 	mov	dptr,#_ak820_macro_change_PARM_3
      007E11 EA               [12] 1450 	mov	a,r2
      007E12 F0               [24] 1451 	movx	@dptr,a
      007E13 90 0A 89         [24] 1452 	mov	dptr,#_macro_usages
      007E16 C0 07            [24] 1453 	push	ar7
      007E18 C0 06            [24] 1454 	push	ar6
      007E1A C0 05            [24] 1455 	push	ar5
      007E1C C0 04            [24] 1456 	push	ar4
      007E1E C0 03            [24] 1457 	push	ar3
      007E20 C0 02            [24] 1458 	push	ar2
      007E22 12 7A B5         [24] 1459 	lcall	_ak820_macro_change
      007E25 E5 82            [12] 1460 	mov	a, dpl
      007E27 D0 02            [24] 1461 	pop	ar2
      007E29 D0 03            [24] 1462 	pop	ar3
      007E2B D0 04            [24] 1463 	pop	ar4
      007E2D D0 05            [24] 1464 	pop	ar5
      007E2F D0 06            [24] 1465 	pop	ar6
      007E31 D0 07            [24] 1466 	pop	ar7
      007E33 70 01            [24] 1467 	jnz	00102$
      007E35 22               [24] 1468 	ret
      007E36                       1469 00102$:
                                   1470 ;	quantum/action_util.c:189: if (pressed) {
      007E36 EA               [12] 1471 	mov	a,r2
      007E37 60 1B            [24] 1472 	jz	00115$
                                   1473 ;	quantum/action_util.c:190: if (usage_refs[index]++) return;
      007E39 12 7F FF         [24] 1474 	lcall	_ak820_outline_0075
      007E3C 04               [12] 1475 	inc	a
      007E3D 12 6B A7         [24] 1476 	lcall	_ak820_outline_0139
      007E40 E8               [12] 1477 	mov	a,r0
      007E41 60 01            [24] 1478 	jz	00104$
      007E43 22               [24] 1479 	ret
      007E44                       1480 00104$:
                                   1481 ;	quantum/action_util.c:191: usage_order[base + count++] = index;
      007E44 90 0A 92         [24] 1482 	mov	dptr,#_owned_usage_key_count_10000_369
      007E47 EC               [12] 1483 	mov	a,r4
      007E48 04               [12] 1484 	inc	a
      007E49 F0               [24] 1485 	movx	@dptr,a
      007E4A EC               [12] 1486 	mov	a,r4
      007E4B 2E               [12] 1487 	add	a, r6
      007E4C 12 7F F5         [24] 1488 	lcall	_ak820_outline_0067
      007E4F EB               [12] 1489 	mov	a,r3
      007E50 F0               [24] 1490 	movx	@dptr,a
      007E51 02 7E B5         [24] 1491 	ljmp	00116$
      007E54                       1492 00115$:
                                   1493 ;	quantum/action_util.c:193: if (!usage_refs[index] || --usage_refs[index]) return;
      007E54 12 7F FF         [24] 1494 	lcall	_ak820_outline_0075
      007E57 60 07            [24] 1495 	jz	00105$
      007E59 18               [12] 1496 	dec	r0
      007E5A 12 7F EE         [24] 1497 	lcall	_ak820_outline_0062
      007E5D E8               [12] 1498 	mov	a,r0
      007E5E 60 01            [24] 1499 	jz	00106$
      007E60                       1500 00105$:
      007E60 22               [24] 1501 	ret
      007E61                       1502 00106$:
                                   1503 ;	quantum/action_util.c:195: while (usage_order[base + pos] != index) ++pos;
      007E61 7A 00            [12] 1504 	mov	r2,#0x00
      007E63                       1505 00108$:
      007E63 EA               [12] 1506 	mov	a,r2
      007E64 2E               [12] 1507 	add	a, r6
      007E65 12 7F F5         [24] 1508 	lcall	_ak820_outline_0067
      007E68 E0               [24] 1509 	movx	a,@dptr
      007E69 B5 03 02         [24] 1510 	cjne	a,ar3,00251$
      007E6C 80 03            [24] 1511 	sjmp	00167$
      007E6E                       1512 00251$:
      007E6E 0A               [12] 1513 	inc	r2
      007E6F 80 F2            [24] 1514 	sjmp	00108$
      007E71                       1515 00167$:
      007E71 90 0A 93         [24] 1516 	mov	dptr,#_owned_usage_key_pos_30001_376
      007E74 EA               [12] 1517 	mov	a,r2
      007E75 F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	quantum/action_util.c:196: --count;
      007E76 1C               [12] 1520 	dec	r4
      007E77 90 0A 92         [24] 1521 	mov	dptr,#_owned_usage_key_count_10000_369
      007E7A EC               [12] 1522 	mov	a,r4
      007E7B F0               [24] 1523 	movx	@dptr,a
                                   1524 ;	quantum/action_util.c:197: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007E7C 8A 03            [24] 1525 	mov	ar3,r2
      007E7E                       1526 00125$:
      007E7E C3               [12] 1527 	clr	c
      007E7F EB               [12] 1528 	mov	a,r3
      007E80 9C               [12] 1529 	subb	a,r4
      007E81 50 23            [24] 1530 	jnc	00111$
      007E83 C0 05            [24] 1531 	push	ar5
      007E85 C0 07            [24] 1532 	push	ar7
      007E87 EB               [12] 1533 	mov	a,r3
      007E88 2E               [12] 1534 	add	a, r6
      007E89 FA               [12] 1535 	mov	r2,a
      007E8A 24 69            [12] 1536 	add	a, #_usage_order
      007E8C F8               [12] 1537 	mov	r0,a
      007E8D E4               [12] 1538 	clr	a
      007E8E 34 0A            [12] 1539 	addc	a, #(_usage_order >> 8)
      007E90 F9               [12] 1540 	mov	r1,a
      007E91 0A               [12] 1541 	inc	r2
      007E92 EA               [12] 1542 	mov	a,r2
      007E93 33               [12] 1543 	rlc	a
      007E94 95 E0            [12] 1544 	subb	a,acc
      007E96 FF               [12] 1545 	mov	r7,a
      007E97 EA               [12] 1546 	mov	a,r2
      007E98 12 80 1B         [24] 1547 	lcall	_ak820_outline_0125
      007E9B 12 38 B1         [24] 1548 	lcall	_ak820_outline_0144
      007E9E F0               [24] 1549 	movx	@dptr,a
      007E9F 0B               [12] 1550 	inc	r3
      007EA0 D0 07            [24] 1551 	pop	ar7
      007EA2 D0 05            [24] 1552 	pop	ar5
      007EA4 80 D8            [24] 1553 	sjmp	00125$
      007EA6                       1554 00111$:
                                   1555 ;	quantum/action_util.c:198: usage_lengths[which] = count;
      007EA6 12 80 3A         [24] 1556 	lcall	_ak820_outline_0189
      007EA9 EC               [12] 1557 	mov	a,r4
      007EAA F0               [24] 1558 	movx	@dptr,a
                                   1559 ;	quantum/action_util.c:199: if (pos != count) return; /* A non-winning owner changed only storage. */
      007EAB 90 0A 93         [24] 1560 	mov	dptr,#_owned_usage_key_pos_30001_376
      007EAE E0               [24] 1561 	movx	a,@dptr
      007EAF B5 04 02         [24] 1562 	cjne	a,ar4,00253$
      007EB2 80 01            [24] 1563 	sjmp	00116$
      007EB4                       1564 00253$:
      007EB4 22               [24] 1565 	ret
      007EB5                       1566 00116$:
                                   1567 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      007EB5 90 0A 92         [24] 1568 	mov	dptr,#_owned_usage_key_count_10000_369
      007EB8 E0               [24] 1569 	movx	a,@dptr
      007EB9 FC               [12] 1570 	mov	r4,a
      007EBA 12 80 3A         [24] 1571 	lcall	_ak820_outline_0189
      007EBD F0               [24] 1572 	movx	@dptr,a
                                   1573 ;	quantum/action_util.c:202: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007EBE EC               [12] 1574 	mov	a,r4
      007EBF 60 15            [24] 1575 	jz	00131$
      007EC1 EC               [12] 1576 	mov	a,r4
      007EC2 2E               [12] 1577 	add	a, r6
      007EC3 FE               [12] 1578 	mov	r6,a
      007EC4 1E               [12] 1579 	dec	r6
      007EC5 EE               [12] 1580 	mov	a,r6
      007EC6 33               [12] 1581 	rlc	a
      007EC7 95 E0            [12] 1582 	subb	a,acc
      007EC9 FF               [12] 1583 	mov	r7,a
      007ECA EE               [12] 1584 	mov	a,r6
      007ECB 12 80 1B         [24] 1585 	lcall	_ak820_outline_0125
      007ECE 24 A5            [12] 1586 	add	a,#0xa5
      007ED0 FE               [12] 1587 	mov	r6,a
      007ED1 33               [12] 1588 	rlc	a
      007ED2 95 E0            [12] 1589 	subb	a,acc
      007ED4 80 02            [24] 1590 	sjmp	00132$
      007ED6                       1591 00131$:
      007ED6 7E 00            [12] 1592 	mov	r6,#0x00
      007ED8                       1593 00132$:
      007ED8 90 0A 8E         [24] 1594 	mov	dptr,#_owned_usage_key_code_10000_368
      007EDB EE               [12] 1595 	mov	a,r6
      007EDC F0               [24] 1596 	movx	@dptr,a
                                   1597 ;	quantum/action_util.c:203: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007EDD 90 0A 91         [24] 1598 	mov	dptr,#_owned_usage_key_which_10000_369
      007EE0 E0               [24] 1599 	movx	a,@dptr
      007EE1 60 18            [24] 1600 	jz	00118$
      007EE3 EE               [12] 1601 	mov	a,r6
      007EE4 60 0B            [24] 1602 	jz	00133$
      007EE6 8E 82            [24] 1603 	mov	dpl, r6
      007EE8 12 6C E7         [24] 1604 	lcall	_KEYCODE2CONSUMER
      007EEB AD 82            [24] 1605 	mov	r5, dpl
      007EED AF 83            [24] 1606 	mov	r7, dph
      007EEF 80 04            [24] 1607 	sjmp	00134$
      007EF1                       1608 00133$:
      007EF1 7D 00            [12] 1609 	mov	r5,#0x00
      007EF3 7F 00            [12] 1610 	mov	r7,#0x00
      007EF5                       1611 00134$:
      007EF5 12 80 3A         [24] 1612 	lcall	_ak820_outline_0189
      007EF8 02 6C 9A         [24] 1613 	ljmp	_host_consumer_send
      007EFB                       1614 00118$:
                                   1615 ;	quantum/action_util.c:204: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007EFB EE               [12] 1616 	mov	a,r6
      007EFC 60 22            [24] 1617 	jz	00135$
                                   1618 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007EFE BE A5 00         [24] 1619 	cjne	r6,#0xa5,00258$
      007F01                       1620 00258$:
      007F01 40 05            [24] 1621 	jc	00121$
      007F03 EE               [12] 1622 	mov	a,r6
      007F04 24 58            [12] 1623 	add	a,#0xff - 0xa7
      007F06 50 08            [24] 1624 	jnc	00122$
                                   1625 ;	free result
      007F08                       1626 00121$:
      007F08 90 0A 8F         [24] 1627 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F0B 12 4E C3         [24] 1628 	lcall	_ak820_outline_0183
      007F0E 80 09            [24] 1629 	sjmp	00123$
      007F10                       1630 00122$:
                                   1631 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007F10 74 DC            [12] 1632 	mov	a,#0xdc
      007F12 2E               [12] 1633 	add	a, r6
      007F13 90 0A 8F         [24] 1634 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F16 12 38 9C         [24] 1635 	lcall	_ak820_outline_0134
                                   1636 ;	quantum/action_util.c:204: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007F19                       1637 00123$:
      007F19 90 0A 8F         [24] 1638 	mov	dptr,#_owned_usage_key___200000085_20000_369
      007F1C E0               [24] 1639 	movx	a,@dptr
      007F1D FF               [12] 1640 	mov	r7,a
      007F1E 80 02            [24] 1641 	sjmp	00136$
      007F20                       1642 00135$:
      007F20 7F 00            [12] 1643 	mov	r7,#0x00
      007F22                       1644 00136$:
      007F22 7E 00            [12] 1645 	mov	r6,#0x00
      007F24 12 43 77         [24] 1646 	lcall	_ak820_outline_0158
                                   1647 ;	quantum/action_util.c:205: }
      007F27 02 6C 6A         [24] 1648 	ljmp	_host_system_send
                                   1649 ;------------------------------------------------------------
                                   1650 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1651 ;------------------------------------------------------------
                                   1652 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_388'
                                   1653 ;changed       Allocated with name '_send_keyboard_report_changed_10001_388'
                                   1654 ;dest          Allocated with name '_send_keyboard_report_dest_10001_388'
                                   1655 ;src           Allocated with name '_send_keyboard_report_src_10001_388'
                                   1656 ;i             Allocated with name '_send_keyboard_report_i_20001_389'
                                   1657 ;------------------------------------------------------------
                                   1658 ;	quantum/action_util.c:427: void send_keyboard_report(void) {
                                   1659 ;	-----------------------------------------
                                   1660 ;	 function send_keyboard_report
                                   1661 ;	-----------------------------------------
      007F2A                       1662 _send_keyboard_report:
                                   1663 ;	quantum/action_util.c:428: keyboard_report->mods = real_mods;
      007F2A 90 0D B8         [24] 1664 	mov	dptr,#_real_mods
      007F2D E0               [24] 1665 	movx	a,@dptr
      007F2E FF               [12] 1666 	mov	r7,a
      007F2F 90 0D BA         [24] 1667 	mov	dptr,#_actual_keyboard_report
      007F32 F0               [24] 1668 	movx	@dptr,a
                                   1669 ;	quantum/action_util.c:429: keyboard_report->mods |= weak_mods;
      007F33 90 0D B9         [24] 1670 	mov	dptr,#_weak_mods
      007F36 E0               [24] 1671 	movx	a,@dptr
      007F37 42 07            [12] 1672 	orl	ar7,a
      007F39 90 0D BA         [24] 1673 	mov	dptr,#_actual_keyboard_report
      007F3C EF               [12] 1674 	mov	a,r7
      007F3D F0               [24] 1675 	movx	@dptr,a
                                   1676 ;	quantum/action_util.c:431: keyboard_report->mods |= owned_mods | owned_weak_mods;
      007F3E 90 09 7D         [24] 1677 	mov	dptr,#_owned_weak_mods
      007F41 E0               [24] 1678 	movx	a,@dptr
      007F42 FE               [12] 1679 	mov	r6,a
      007F43 90 09 7C         [24] 1680 	mov	dptr,#_owned_mods
      007F46 E0               [24] 1681 	movx	a,@dptr
      007F47 4E               [12] 1682 	orl	a,r6
      007F48 42 07            [12] 1683 	orl	ar7,a
      007F4A 90 0D BA         [24] 1684 	mov	dptr,#_actual_keyboard_report
      007F4D EF               [12] 1685 	mov	a,r7
      007F4E F0               [24] 1686 	movx	@dptr,a
                                   1687 ;	quantum/action_util.c:479: bool changed = false;
      007F4F 90 0A B5         [24] 1688 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007F52 E4               [12] 1689 	clr	a
      007F53 F0               [24] 1690 	movx	@dptr,a
                                   1691 ;	quantum/action_util.c:481: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1692 ;	quantum/action_util.c:482: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1693 ;	quantum/action_util.c:487: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007F54 FF               [12] 1694 	mov	r7,a
      007F55                       1695 00107$:
      007F55 BF 20 00         [24] 1696 	cjne	r7,#0x20,00140$
      007F58                       1697 00140$:
      007F58 50 2B            [24] 1698 	jnc	00103$
                                   1699 ;	quantum/action_util.c:488: if (dest[i] != src[i]) {
      007F5A EF               [12] 1700 	mov	a,r7
      007F5B 24 95            [12] 1701 	add	a, #_send_keyboard_report_last_report_10001_388
      007F5D FD               [12] 1702 	mov	r5,a
      007F5E E4               [12] 1703 	clr	a
      007F5F 34 0A            [12] 1704 	addc	a, #(_send_keyboard_report_last_report_10001_388 >> 8)
      007F61 FE               [12] 1705 	mov	r6,a
      007F62 12 48 1D         [24] 1706 	lcall	_ak820_outline_0076
      007F65 EF               [12] 1707 	mov	a,r7
      007F66 24 BA            [12] 1708 	add	a, #_actual_keyboard_report
      007F68 F5 82            [12] 1709 	mov	dpl,a
      007F6A E4               [12] 1710 	clr	a
      007F6B 34 0D            [12] 1711 	addc	a, #(_actual_keyboard_report >> 8)
      007F6D F5 83            [12] 1712 	mov	dph,a
      007F6F E0               [24] 1713 	movx	a,@dptr
      007F70 FB               [12] 1714 	mov	r3,a
      007F71 EC               [12] 1715 	mov	a,r4
      007F72 B5 03 02         [24] 1716 	cjne	a,ar3,00142$
      007F75 80 0B            [24] 1717 	sjmp	00108$
      007F77                       1718 00142$:
                                   1719 ;	quantum/action_util.c:489: dest[i] = src[i];
      007F77 12 38 A1         [24] 1720 	lcall	_ak820_outline_0135
      007F7A EB               [12] 1721 	mov	a,r3
      007F7B F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action_util.c:490: changed = true;
      007F7C 90 0A B5         [24] 1724 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007F7F 74 01            [12] 1725 	mov	a,#0x01
      007F81 F0               [24] 1726 	movx	@dptr,a
      007F82                       1727 00108$:
                                   1728 ;	quantum/action_util.c:487: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      007F82 0F               [12] 1729 	inc	r7
      007F83 80 D0            [24] 1730 	sjmp	00107$
      007F85                       1731 00103$:
                                   1732 ;	quantum/action_util.c:493: if (changed) host_keyboard_send(keyboard_report);
      007F85 90 0A B5         [24] 1733 	mov	dptr,#_send_keyboard_report_changed_10001_388
      007F88 E0               [24] 1734 	movx	a,@dptr
      007F89 60 09            [24] 1735 	jz	00109$
      007F8B 90 0D BA         [24] 1736 	mov	dptr,#_actual_keyboard_report
      007F8E 75 F0 00         [24] 1737 	mov	b, #0x00
                                   1738 ;	quantum/action_util.c:501: }
      007F91 02 6B DF         [24] 1739 	ljmp	_host_keyboard_send
      007F94                       1740 00109$:
      007F94 22               [24] 1741 	ret
                                   1742 ;------------------------------------------------------------
                                   1743 ;Allocation info for local variables in function 'get_mods'
                                   1744 ;------------------------------------------------------------
                                   1745 ;	quantum/action_util.c:507: uint8_t get_mods(void) {
                                   1746 ;	-----------------------------------------
                                   1747 ;	 function get_mods
                                   1748 ;	-----------------------------------------
      007F95                       1749 _get_mods:
      007F95 C0 07            [24] 1750 	push	ar7
                                   1751 ;	quantum/action_util.c:512: ;
      007F97 90 09 7C         [24] 1752 	mov	dptr,#_owned_mods
      007F9A E0               [24] 1753 	movx	a,@dptr
      007F9B FF               [12] 1754 	mov	r7,a
      007F9C 90 0D B8         [24] 1755 	mov	dptr,#_real_mods
      007F9F 12 7A A0         [24] 1756 	lcall	_ak820_outline_0141
                                   1757 ;	quantum/action_util.c:513: }
      007FA2 D0 07            [24] 1758 	pop	ar7
      007FA4 22               [24] 1759 	ret
                                   1760 ;------------------------------------------------------------
                                   1761 ;Allocation info for local variables in function 'add_mods'
                                   1762 ;------------------------------------------------------------
                                   1763 ;mods          Allocated with name '_add_mods_mods_10000_396'
                                   1764 ;------------------------------------------------------------
                                   1765 ;	quantum/action_util.c:518: void add_mods(uint8_t mods) {
                                   1766 ;	-----------------------------------------
                                   1767 ;	 function clear_mods
                                   1768 ;	-----------------------------------------
      007FA5                       1769 _clear_mods:
                                   1770 ;	quantum/action_util.c:540: real_mods = 0;
      007FA5 90 0D B8         [24] 1771 	mov	dptr,#_real_mods
      007FA8 E4               [12] 1772 	clr	a
      007FA9 F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	quantum/action_util.c:541: }
      007FAA 22               [24] 1775 	ret
                                   1776 ;------------------------------------------------------------
                                   1777 ;Allocation info for local variables in function 'get_weak_mods'
                                   1778 ;------------------------------------------------------------
                                   1779 ;	quantum/action_util.c:547: uint8_t get_weak_mods(void) {
                                   1780 ;	-----------------------------------------
                                   1781 ;	 function get_weak_mods
                                   1782 ;	-----------------------------------------
      007FAB                       1783 _get_weak_mods:
      007FAB C0 07            [24] 1784 	push	ar7
                                   1785 ;	quantum/action_util.c:552: ;
      007FAD 90 09 7D         [24] 1786 	mov	dptr,#_owned_weak_mods
      007FB0 E0               [24] 1787 	movx	a,@dptr
      007FB1 FF               [12] 1788 	mov	r7,a
      007FB2 90 0D B9         [24] 1789 	mov	dptr,#_weak_mods
      007FB5 12 7A A0         [24] 1790 	lcall	_ak820_outline_0141
                                   1791 ;	quantum/action_util.c:553: }
      007FB8 D0 07            [24] 1792 	pop	ar7
      007FBA 22               [24] 1793 	ret
                                   1794 ;------------------------------------------------------------
                                   1795 ;Allocation info for local variables in function 'add_weak_mods'
                                   1796 ;------------------------------------------------------------
                                   1797 ;mods          Allocated with name '_add_weak_mods_mods_10000_406'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action_util.c:558: void add_weak_mods(uint8_t mods) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function add_weak_mods
                                   1802 ;	-----------------------------------------
      007FBB                       1803 _add_weak_mods:
      007FBB E5 82            [12] 1804 	mov	a,dpl
      007FBD 90 0A B6         [24] 1805 	mov	dptr,#_add_weak_mods_mods_10000_406
      007FC0 F0               [24] 1806 	movx	@dptr,a
                                   1807 ;	quantum/action_util.c:559: weak_mods |= mods;
      007FC1 E0               [24] 1808 	movx	a,@dptr
      007FC2 FF               [12] 1809 	mov	r7,a
      007FC3 90 0D B9         [24] 1810 	mov	dptr,#_weak_mods
      007FC6 E0               [24] 1811 	movx	a,@dptr
      007FC7 4F               [12] 1812 	orl	a,r7
      007FC8 F0               [24] 1813 	movx	@dptr,a
                                   1814 ;	quantum/action_util.c:560: }
      007FC9 22               [24] 1815 	ret
                                   1816 ;------------------------------------------------------------
                                   1817 ;Allocation info for local variables in function 'del_weak_mods'
                                   1818 ;------------------------------------------------------------
                                   1819 ;mods          Allocated with name '_del_weak_mods_mods_10000_408'
                                   1820 ;------------------------------------------------------------
                                   1821 ;	quantum/action_util.c:565: void del_weak_mods(uint8_t mods) {
                                   1822 ;	-----------------------------------------
                                   1823 ;	 function del_weak_mods
                                   1824 ;	-----------------------------------------
      007FCA                       1825 _del_weak_mods:
      007FCA E5 82            [12] 1826 	mov	a,dpl
      007FCC 90 0A B7         [24] 1827 	mov	dptr,#_del_weak_mods_mods_10000_408
      007FCF F0               [24] 1828 	movx	@dptr,a
                                   1829 ;	quantum/action_util.c:566: weak_mods &= ~mods;
      007FD0 E0               [24] 1830 	movx	a,@dptr
      007FD1 F4               [12] 1831 	cpl	a
      007FD2 FF               [12] 1832 	mov	r7,a
      007FD3 90 0D B9         [24] 1833 	mov	dptr,#_weak_mods
      007FD6 E0               [24] 1834 	movx	a,@dptr
      007FD7 5F               [12] 1835 	anl	a,r7
      007FD8 F0               [24] 1836 	movx	@dptr,a
                                   1837 ;	quantum/action_util.c:567: }
      007FD9 22               [24] 1838 	ret
                                   1839 ;------------------------------------------------------------
                                   1840 ;Allocation info for local variables in function 'set_weak_mods'
                                   1841 ;------------------------------------------------------------
                                   1842 ;mods          Allocated with name '_set_weak_mods_mods_10000_410'
                                   1843 ;------------------------------------------------------------
                                   1844 ;	quantum/action_util.c:572: void set_weak_mods(uint8_t mods) {
                                   1845 ;	-----------------------------------------
                                   1846 ;	 function clear_weak_mods
                                   1847 ;	-----------------------------------------
      007FDA                       1848 _clear_weak_mods:
                                   1849 ;	quantum/action_util.c:580: weak_mods = 0;
      007FDA 90 0D B9         [24] 1850 	mov	dptr,#_weak_mods
      007FDD E4               [12] 1851 	clr	a
      007FDE F0               [24] 1852 	movx	@dptr,a
                                   1853 ;	quantum/action_util.c:581: }
      007FDF 22               [24] 1854 	ret
                                   1855 ;------------------------------------------------------------
                                   1856 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1857 ;------------------------------------------------------------
                                   1858 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_414'
                                   1859 ;------------------------------------------------------------
                                   1860 ;	quantum/action_util.c:663: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1861 ;	-----------------------------------------
                                   1862 	.area CSEG    (CODE)
                                   1863 	.area CONST   (CODE)
                                   1864 	.area XINIT   (CODE)
      00BF61                       1865 __xinit__real_mods:
      00BF61 00                    1866 	.db #0x00	; 0
      00BF62                       1867 __xinit__weak_mods:
      00BF62 00                    1868 	.db #0x00	; 0
      00BF63                       1869 __xinit__actual_keyboard_report:
      00BF63 00                    1870 	.db #0x00	; 0
      00BF64 00                    1871 	.db #0x00	; 0
      00BF65 00                    1872 	.db #0x00	; 0
      00BF66 00                    1873 	.db #0x00	; 0
      00BF67 00                    1874 	.db #0x00	; 0
      00BF68 00                    1875 	.db #0x00	; 0
      00BF69 00                    1876 	.db #0x00	; 0
      00BF6A 00                    1877 	.db #0x00	; 0
      00BF6B 00                    1878 	.db 0x00
      00BF6C 00                    1879 	.db 0x00
      00BF6D 00                    1880 	.db 0x00
      00BF6E 00                    1881 	.db 0x00
      00BF6F 00                    1882 	.db 0x00
      00BF70 00                    1883 	.db 0x00
      00BF71 00                    1884 	.db 0x00
      00BF72 00                    1885 	.db 0x00
      00BF73 00                    1886 	.db 0x00
      00BF74 00                    1887 	.db 0x00
      00BF75 00                    1888 	.db 0x00
      00BF76 00                    1889 	.db 0x00
      00BF77 00                    1890 	.db 0x00
      00BF78 00                    1891 	.db 0x00
      00BF79 00                    1892 	.db 0x00
      00BF7A 00                    1893 	.db 0x00
      00BF7B 00                    1894 	.db 0x00
      00BF7C 00                    1895 	.db 0x00
      00BF7D 00                    1896 	.db 0x00
      00BF7E 00                    1897 	.db 0x00
      00BF7F 00                    1898 	.db 0x00
      00BF80 00                    1899 	.db 0x00
      00BF81 00                    1900 	.db 0x00
      00BF82 00                    1901 	.db 0x00
                                   1902 	.area CABS    (ABS,CODE)
                                   1903 
                                   1904 ; Experimental exact instruction outlining.
                                   1905 	.globl _ak820_outline_0015
                                   1906 	.globl _ak820_outline_0030
                                   1907 	.globl _ak820_outline_0055
                                   1908 	.globl _ak820_outline_0059
                                   1909 	.globl _ak820_outline_0061
                                   1910 	.globl _ak820_outline_0062
                                   1911 	.globl _ak820_outline_0063
                                   1912 	.globl _ak820_outline_0067
                                   1913 	.globl _ak820_outline_0075
                                   1914 	.globl _ak820_outline_0076
                                   1915 	.globl _ak820_outline_0107
                                   1916 	.globl _ak820_outline_0108
                                   1917 	.globl _ak820_outline_0116
                                   1918 	.globl _ak820_outline_0121
                                   1919 	.globl _ak820_outline_0123
                                   1920 	.globl _ak820_outline_0125
                                   1921 	.globl _ak820_outline_0132
                                   1922 	.globl _ak820_outline_0134
                                   1923 	.globl _ak820_outline_0135
                                   1924 	.globl _ak820_outline_0139
                                   1925 	.globl _ak820_outline_0141
                                   1926 	.globl _ak820_outline_0144
                                   1927 	.globl _ak820_outline_0158
                                   1928 	.globl _ak820_outline_0163
                                   1929 	.globl _ak820_outline_0176
                                   1930 	.globl _ak820_outline_0183
                                   1931 	.globl _ak820_outline_0188
                                   1932 	.globl _ak820_outline_0189
                                   1933 
                                   1934 	.area CSEG (CODE)
                                   1935 ; function ak820_outline_0030
      007FE0                       1936 _ak820_outline_0030:
      007FE0 EF               [12] 1937 	mov	a,r7
      007FE1 24 8E            [12] 1938 	add	a,#_key_refs
      007FE3 FD               [12] 1939 	mov	r5,a
      007FE4 E4               [12] 1940 	clr	a
      007FE5 34 09            [12] 1941 	addc	a,#(_key_refs>>8)
      007FE7 FE               [12] 1942 	mov	r6,a
      007FE8 8D 82            [24] 1943 	mov	dpl,r5
      007FEA 8E 83            [24] 1944 	mov	dph,r6
      007FEC E0               [24] 1945 	movx	a,@dptr
      007FED 22               [24] 1946 	ret
                                   1947 
                                   1948 	.area CSEG (CODE)
                                   1949 ; function ak820_outline_0062
      007FEE                       1950 _ak820_outline_0062:
      007FEE 89 82            [24] 1951 	mov	dpl,r1
      007FF0 8A 83            [24] 1952 	mov	dph,r2
      007FF2 E8               [12] 1953 	mov	a,r0
      007FF3 F0               [24] 1954 	movx	@dptr,a
      007FF4 22               [24] 1955 	ret
                                   1956 
                                   1957 	.area CSEG (CODE)
                                   1958 ; function ak820_outline_0067
      007FF5                       1959 _ak820_outline_0067:
      007FF5 24 69            [12] 1960 	add	a,#_usage_order
      007FF7 F5 82            [12] 1961 	mov	dpl,a
      007FF9 E4               [12] 1962 	clr	a
      007FFA 34 0A            [12] 1963 	addc	a,#(_usage_order>>8)
      007FFC F5 83            [12] 1964 	mov	dph,a
      007FFE 22               [24] 1965 	ret
                                   1966 
                                   1967 	.area CSEG (CODE)
                                   1968 ; function ak820_outline_0075
      007FFF                       1969 _ak820_outline_0075:
      007FFF EB               [12] 1970 	mov	a,r3
      008000 24 4B            [12] 1971 	add	a,#_usage_refs
      008002 F9               [12] 1972 	mov	r1,a
      008003 E4               [12] 1973 	clr	a
      008004 34 0A            [12] 1974 	addc	a,#(_usage_refs>>8)
      008006 FA               [12] 1975 	mov	r2,a
      008007 89 82            [24] 1976 	mov	dpl,r1
      008009 8A 83            [24] 1977 	mov	dph,r2
      00800B E0               [24] 1978 	movx	a,@dptr
      00800C F8               [12] 1979 	mov	r0,a
      00800D 22               [24] 1980 	ret
                                   1981 
                                   1982 	.area CSEG (CODE)
                                   1983 ; function ak820_outline_0116
      00800E                       1984 _ak820_outline_0116:
      00800E F0               [24] 1985 	movx	@dptr,a
      00800F E0               [24] 1986 	movx	a,@dptr
      008010 FF               [12] 1987 	mov	r7,a
      008011 90 09 86         [24] 1988 	mov	dptr,#_change_owned_PARM_2
      008014 22               [24] 1989 	ret
                                   1990 
                                   1991 	.area CSEG (CODE)
                                   1992 ; function ak820_outline_0121
      008015                       1993 _ak820_outline_0121:
      008015 8D 82            [24] 1994 	mov	dpl,r5
      008017 8E 83            [24] 1995 	mov	dph,r6
      008019 F0               [24] 1996 	movx	@dptr,a
      00801A 22               [24] 1997 	ret
                                   1998 
                                   1999 	.area CSEG (CODE)
                                   2000 ; function ak820_outline_0125
      00801B                       2001 _ak820_outline_0125:
      00801B 24 69            [12] 2002 	add	a,#_usage_order
      00801D F5 82            [12] 2003 	mov	dpl,a
      00801F EF               [12] 2004 	mov	a,r7
      008020 34 0A            [12] 2005 	addc	a,#(_usage_order>>8)
      008022 F5 83            [12] 2006 	mov	dph,a
      008024 E0               [24] 2007 	movx	a,@dptr
      008025 22               [24] 2008 	ret
                                   2009 
                                   2010 	.area CSEG (CODE)
                                   2011 ; function ak820_outline_0132
      008026                       2012 _ak820_outline_0132:
      008026 F0               [24] 2013 	movx	@dptr,a
      008027 E0               [24] 2014 	movx	a,@dptr
      008028 FF               [12] 2015 	mov	r7,a
      008029 90 09 82         [24] 2016 	mov	dptr,#_ak820_macro_change_PARM_2
      00802C F0               [24] 2017 	movx	@dptr,a
      00802D 90 09 83         [24] 2018 	mov	dptr,#_ak820_macro_change_PARM_3
      008030 22               [24] 2019 	ret
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0176
      008031                       2023 _ak820_outline_0176:
      008031 90 07 FC         [24] 2024 	mov	dptr,#_add_key_to_report_PARM_2
      008034 EF               [12] 2025 	mov	a,r7
      008035 F0               [24] 2026 	movx	@dptr,a
      008036 90 0D BA         [24] 2027 	mov	dptr,#_actual_keyboard_report
      008039 22               [24] 2028 	ret
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0189
      00803A                       2032 _ak820_outline_0189:
      00803A 8D 82            [24] 2033 	mov	dpl,r5
      00803C 8F 83            [24] 2034 	mov	dph,r7
      00803E 22               [24] 2035 	ret
