                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_gui_process
                                    269 	.globl _ak820_macro_change
                                    270 	.globl _add_owned_mods
                                    271 	.globl _del_owned_mods
                                    272 	.globl _add_owned_weak_mods
                                    273 	.globl _del_owned_weak_mods
                                    274 	.globl _clear_owned_mods
                                    275 	.globl _clear_owned_keys
                                    276 	.globl _add_owned_key
                                    277 	.globl _del_owned_key
                                    278 	.globl _clear_owned_usages
                                    279 	.globl _owned_usage_key
                                    280 	.globl _send_keyboard_report
                                    281 	.globl _get_mods
                                    282 	.globl _clear_mods
                                    283 	.globl _get_weak_mods
                                    284 	.globl _add_weak_mods
                                    285 	.globl _del_weak_mods
                                    286 	.globl _clear_weak_mods
                                    287 ;--------------------------------------------------------
                                    288 ; special function registers
                                    289 ;--------------------------------------------------------
                                    290 	.area RSEG    (ABS,DATA)
      000000                        291 	.org 0x0000
                           0000D0   292 _PSW	=	0x00d0
                           0000E0   293 _ACC	=	0x00e0
                           0000F0   294 _B	=	0x00f0
                           0000FD   295 _A_INV	=	0x00fd
                           000081   296 _SP	=	0x0081
                           000082   297 _DPL	=	0x0082
                           000083   298 _DPH	=	0x0083
                           0000A1   299 _SAFE_MOD	=	0x00a1
                           0000B1   300 _GLOBAL_CFG	=	0x00b1
                           000087   301 _PCON	=	0x0087
                           0000BA   302 _POWER_CFG	=	0x00ba
                           0000B9   303 _CLOCK_CFG	=	0x00b9
                           0000A9   304 _WAKE_CTRL	=	0x00a9
                           0000FE   305 _RESET_KEEP	=	0x00fe
                           0000FF   306 _WDOG_COUNT	=	0x00ff
                           0000A8   307 _IE	=	0x00a8
                           0000B8   308 _IP	=	0x00b8
                           0000E8   309 _IE_EX	=	0x00e8
                           0000E9   310 _IP_EX	=	0x00e9
                           0000B2   311 _GPIO_IE	=	0x00b2
                           008584   312 _ROM_ADDR	=	0x8584
                           000084   313 _ROM_ADDR_L	=	0x0084
                           000085   314 _ROM_ADDR_H	=	0x0085
                           008F8E   315 _ROM_DATA_HI	=	0x8f8e
                           00008E   316 _ROM_DATA_HL	=	0x008e
                           00008F   317 _ROM_DATA_HH	=	0x008f
                           000086   318 _ROM_CTRL	=	0x0086
                           000080   319 _P0	=	0x0080
                           0000C4   320 _P0_MOD_OC	=	0x00c4
                           0000C5   321 _P0_DIR_PU	=	0x00c5
                           000090   322 _P1	=	0x0090
                           000092   323 _P1_MOD_OC	=	0x0092
                           000093   324 _P1_DIR_PU	=	0x0093
                           0000A0   325 _P2	=	0x00a0
                           000094   326 _P2_MOD_OC	=	0x0094
                           000095   327 _P2_DIR_PU	=	0x0095
                           0000B0   328 _P3	=	0x00b0
                           000096   329 _P3_MOD_OC	=	0x0096
                           000097   330 _P3_DIR_PU	=	0x0097
                           0000C0   331 _P4	=	0x00c0
                           0000C2   332 _P4_MOD_OC	=	0x00c2
                           0000C3   333 _P4_DIR_PU	=	0x00c3
                           0000C1   334 _P4_LED_KEY	=	0x00c1
                           0000AA   335 _P5_IN	=	0x00aa
                           0000AB   336 _P5_OUT_PU	=	0x00ab
                           0000AC   337 _P5_DIR	=	0x00ac
                           0000AD   338 _P6_IN	=	0x00ad
                           0000AE   339 _P6_OUT_PU	=	0x00ae
                           0000AF   340 _P6_DIR	=	0x00af
                           0000F1   341 _P7	=	0x00f1
                           0000A2   342 _XBUS_AUX	=	0x00a2
                           000088   343 _TCON	=	0x0088
                           000089   344 _TMOD	=	0x0089
                           00008A   345 _TL0	=	0x008a
                           00008B   346 _TL1	=	0x008b
                           00008C   347 _TH0	=	0x008c
                           00008D   348 _TH1	=	0x008d
                           000098   349 _SCON	=	0x0098
                           000099   350 _SBUF	=	0x0099
                           0000C8   351 _T2CON	=	0x00c8
                           0000C9   352 _T2MOD	=	0x00c9
                           00CBCA   353 _RCAP2	=	0xcbca
                           0000CA   354 _RCAP2L	=	0x00ca
                           0000CB   355 _RCAP2H	=	0x00cb
                           00CDCC   356 _T2COUNT	=	0xcdcc
                           0000CC   357 _TL2	=	0x00cc
                           0000CD   358 _TH2	=	0x00cd
                           00CFCE   359 _T2CAP1	=	0xcfce
                           0000CE   360 _T2CAP1L	=	0x00ce
                           0000CF   361 _T2CAP1H	=	0x00cf
                           0000F8   362 _SPI0_STAT	=	0x00f8
                           0000F9   363 _SPI0_DATA	=	0x00f9
                           0000FA   364 _SPI0_CTRL	=	0x00fa
                           0000FB   365 _SPI0_CK_SE	=	0x00fb
                           0000FC   366 _SPI0_SETUP	=	0x00fc
                           0000BC   367 _SCON1	=	0x00bc
                           0000BD   368 _SBUF1	=	0x00bd
                           0000BE   369 _SBAUD1	=	0x00be
                           0000BF   370 _SIF1	=	0x00bf
                           0000B4   371 _SPI1_STAT	=	0x00b4
                           0000B5   372 _SPI1_DATA	=	0x00b5
                           0000B6   373 _SPI1_CTRL	=	0x00b6
                           0000B7   374 _SPI1_CK_SE	=	0x00b7
                           0000F3   375 _ADC_CTRL	=	0x00f3
                           00F5F4   376 _ADC_DAT	=	0xf5f4
                           0000F4   377 _ADC_DAT_L	=	0x00f4
                           0000F5   378 _ADC_DAT_H	=	0x00f5
                           0000F6   379 _ADC_CHAN	=	0x00f6
                           0000A6   380 _LED_COMMON	=	0x00a6
                           0000A7   381 _LED_PWM_OE	=	0x00a7
                           00C7C6   382 _LED_DMA	=	0xc7c6
                           0000C6   383 _LED_DMA_L	=	0x00c6
                           0000C7   384 _LED_DMA_H	=	0x00c7
                           0000F7   385 _LED_STATUS	=	0x00f7
                           0000B3   386 _I2CX_INT	=	0x00b3
                           0000BB   387 _I2CS_INT_ST	=	0x00bb
                                    388 ;--------------------------------------------------------
                                    389 ; special function bits
                                    390 ;--------------------------------------------------------
                                    391 	.area RSEG    (ABS,DATA)
      000000                        392 	.org 0x0000
                           0000D7   393 _CY	=	0x00d7
                           0000D6   394 _AC	=	0x00d6
                           0000D5   395 _F0	=	0x00d5
                           0000D4   396 _RS1	=	0x00d4
                           0000D3   397 _RS0	=	0x00d3
                           0000D2   398 _OV	=	0x00d2
                           0000D1   399 _F1	=	0x00d1
                           0000D0   400 _P	=	0x00d0
                           0000AF   401 _EA	=	0x00af
                           0000AE   402 _E_DIS	=	0x00ae
                           0000AD   403 _ET2	=	0x00ad
                           0000AC   404 _ES	=	0x00ac
                           0000AB   405 _ET1	=	0x00ab
                           0000AA   406 _EX1	=	0x00aa
                           0000A9   407 _ET0	=	0x00a9
                           0000A8   408 _EX0	=	0x00a8
                           0000BF   409 _PH_FLAG	=	0x00bf
                           0000BE   410 _PL_FLAG	=	0x00be
                           0000BD   411 _PT2	=	0x00bd
                           0000BC   412 _PS	=	0x00bc
                           0000BB   413 _PT1	=	0x00bb
                           0000BA   414 _PX1	=	0x00ba
                           0000B9   415 _PT0	=	0x00b9
                           0000B8   416 _PX0	=	0x00b8
                           0000EF   417 _IE_WDOG	=	0x00ef
                           0000EE   418 _IE_GPIO	=	0x00ee
                           0000ED   419 _IE_PWM_I2C	=	0x00ed
                           0000EC   420 _IE_UART1	=	0x00ec
                           0000EB   421 _IE_ADC	=	0x00eb
                           0000E9   422 _IE_USB	=	0x00e9
                           0000E8   423 _IE_SPI0	=	0x00e8
                           000087   424 _P0_7	=	0x0087
                           000086   425 _P0_6	=	0x0086
                           000085   426 _P0_5	=	0x0085
                           000084   427 _P0_4	=	0x0084
                           000083   428 _P0_3	=	0x0083
                           000082   429 _P0_2	=	0x0082
                           000081   430 _P0_1	=	0x0081
                           000080   431 _P0_0	=	0x0080
                           000081   432 _SDA0	=	0x0081
                           000080   433 _SCL0	=	0x0080
                           000083   434 _TXD_	=	0x0083
                           000082   435 _RXD_	=	0x0082
                           000085   436 _AIN13	=	0x0085
                           000084   437 _AIN12	=	0x0084
                           000083   438 _AIN11	=	0x0083
                           000082   439 _AIN10	=	0x0082
                           000081   440 _AIN9	=	0x0081
                           000080   441 _AIN8	=	0x0080
                           000097   442 _P1_7	=	0x0097
                           000096   443 _P1_6	=	0x0096
                           000095   444 _P1_5	=	0x0095
                           000094   445 _P1_4	=	0x0094
                           000093   446 _P1_3	=	0x0093
                           000092   447 _P1_2	=	0x0092
                           000091   448 _P1_1	=	0x0091
                           000090   449 _P1_0	=	0x0090
                           000097   450 _TXD1_	=	0x0097
                           000096   451 _RXD1_	=	0x0096
                           000097   452 _SCK	=	0x0097
                           000096   453 _MISO	=	0x0096
                           000095   454 _MOSI	=	0x0095
                           000094   455 _SCS	=	0x0094
                           000092   456 _INT0_	=	0x0092
                           000091   457 _T2EX	=	0x0091
                           000091   458 _CAP2	=	0x0091
                           000090   459 _T2	=	0x0090
                           000090   460 _CAP1	=	0x0090
                           000097   461 _AIN7	=	0x0097
                           000096   462 _AIN6	=	0x0096
                           000095   463 _AIN5	=	0x0095
                           000094   464 _AIN4	=	0x0094
                           000093   465 _AIN3	=	0x0093
                           000092   466 _AIN2	=	0x0092
                           000091   467 _AIN1	=	0x0091
                           000090   468 _AIN0	=	0x0090
                           0000A7   469 _P2_7	=	0x00a7
                           0000A6   470 _P2_6	=	0x00a6
                           0000A5   471 _P2_5	=	0x00a5
                           0000A4   472 _P2_4	=	0x00a4
                           0000A3   473 _P2_3	=	0x00a3
                           0000A2   474 _P2_2	=	0x00a2
                           0000A1   475 _P2_1	=	0x00a1
                           0000A0   476 _P2_0	=	0x00a0
                           0000A7   477 _TXD1	=	0x00a7
                           0000A6   478 _RXD1	=	0x00a6
                           0000A5   479 _T2EX_	=	0x00a5
                           0000A5   480 _CAP2_	=	0x00a5
                           0000A4   481 _T2_	=	0x00a4
                           0000A4   482 _CAP1_	=	0x00a4
                           0000B7   483 _P3_7	=	0x00b7
                           0000B6   484 _P3_6	=	0x00b6
                           0000B5   485 _P3_5	=	0x00b5
                           0000B4   486 _P3_4	=	0x00b4
                           0000B3   487 _P3_3	=	0x00b3
                           0000B2   488 _P3_2	=	0x00b2
                           0000B1   489 _P3_1	=	0x00b1
                           0000B0   490 _P3_0	=	0x00b0
                           0000B7   491 _SCK1	=	0x00b7
                           0000B6   492 _MISO1	=	0x00b6
                           0000B5   493 _MOSI1	=	0x00b5
                           0000B5   494 _T1	=	0x00b5
                           0000B4   495 _T0	=	0x00b4
                           0000B3   496 _INT1	=	0x00b3
                           0000B2   497 _INT0	=	0x00b2
                           0000B1   498 _TXD	=	0x00b1
                           0000B0   499 _RXD	=	0x00b0
                           0000C6   500 _P4_6	=	0x00c6
                           0000C5   501 _P4_5	=	0x00c5
                           0000C4   502 _P4_4	=	0x00c4
                           0000C3   503 _P4_3	=	0x00c3
                           0000C2   504 _P4_2	=	0x00c2
                           0000C1   505 _P4_1	=	0x00c1
                           0000C0   506 _P4_0	=	0x00c0
                           00008F   507 _TF1	=	0x008f
                           00008E   508 _TR1	=	0x008e
                           00008D   509 _TF0	=	0x008d
                           00008C   510 _TR0	=	0x008c
                           00008B   511 _IE1	=	0x008b
                           00008A   512 _IT1	=	0x008a
                           000089   513 _IE0	=	0x0089
                           000088   514 _IT0	=	0x0088
                           00009F   515 _SM0	=	0x009f
                           00009E   516 _SM1	=	0x009e
                           00009D   517 _SM2	=	0x009d
                           00009C   518 _REN	=	0x009c
                           00009B   519 _TB8	=	0x009b
                           00009A   520 _RB8	=	0x009a
                           000099   521 _TI	=	0x0099
                           000098   522 _RI	=	0x0098
                           0000CF   523 _TF2	=	0x00cf
                           0000CF   524 _CAP1F	=	0x00cf
                           0000CE   525 _EXF2	=	0x00ce
                           0000CD   526 _RCLK	=	0x00cd
                           0000CC   527 _TCLK	=	0x00cc
                           0000CB   528 _EXEN2	=	0x00cb
                           0000CA   529 _TR2	=	0x00ca
                           0000C9   530 _C_T2	=	0x00c9
                           0000C8   531 _CP_RL2	=	0x00c8
                           0000FF   532 _S0_FST_ACT	=	0x00ff
                           0000FE   533 _S0_IF_OV	=	0x00fe
                           0000FD   534 _S0_IF_FIRST	=	0x00fd
                           0000FC   535 _S0_IF_BYTE	=	0x00fc
                           0000FB   536 _S0_FREE	=	0x00fb
                           0000FA   537 _S0_T_FIFO	=	0x00fa
                           0000F8   538 _S0_R_FIFO	=	0x00f8
                           0000F7   539 _ADC_START	=	0x00f7
                                    540 ;--------------------------------------------------------
                                    541 ; overlayable register banks
                                    542 ;--------------------------------------------------------
                                    543 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        544 	.ds 8
                                    545 ;--------------------------------------------------------
                                    546 ; internal ram data
                                    547 ;--------------------------------------------------------
                                    548 	.area DSEG    (DATA)
                                    549 ;--------------------------------------------------------
                                    550 ; overlayable items in internal ram
                                    551 ;--------------------------------------------------------
                                    552 	.area	OSEG    (OVR,DATA)
      000054                        553 _change_owned_sloc1_1_0:
      000054                        554 	.ds 1
                                    555 ;--------------------------------------------------------
                                    556 ; indirectly addressable internal ram data
                                    557 ;--------------------------------------------------------
                                    558 	.area ISEG    (DATA)
                                    559 ;--------------------------------------------------------
                                    560 ; absolute internal ram data
                                    561 ;--------------------------------------------------------
                                    562 	.area IABS    (ABS,DATA)
                                    563 	.area IABS    (ABS,DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; bit data
                                    566 ;--------------------------------------------------------
                                    567 	.area BSEG    (BIT)
      000020                        568 _gui_disabled:
      000020                        569 	.ds 1
      000021                        570 _ak820_gui_process_sloc0_1_0:
      000021                        571 	.ds 1
      000022                        572 _ak820_macro_change_sloc0_1_0:
      000022                        573 	.ds 1
      000023                        574 _change_owned_sloc0_1_0:
      000023                        575 	.ds 1
      000024                        576 _owned_usage_key_sloc0_1_0:
      000024                        577 	.ds 1
                                    578 ;--------------------------------------------------------
                                    579 ; paged external ram data
                                    580 ;--------------------------------------------------------
                                    581 	.area PSEG    (PAG,XDATA)
                                    582 ;--------------------------------------------------------
                                    583 ; uninitialized external ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area XSEG    (XDATA)
      00096F                        586 _ak820_gui_process_PARM_2:
      00096F                        587 	.ds 1
      000970                        588 _ak820_gui_process_code_10000_294:
      000970                        589 	.ds 2
      000972                        590 _owned_mod_refs:
      000972                        591 	.ds 8
      00097A                        592 _owned_weak_refs:
      00097A                        593 	.ds 8
      000982                        594 _owned_mods:
      000982                        595 	.ds 1
      000983                        596 _owned_weak_mods:
      000983                        597 	.ds 1
      000984                        598 _macro_mods:
      000984                        599 	.ds 2
      000986                        600 _ak820_macro_primitive::
      000986                        601 	.ds 1
      000987                        602 _ak820_macro_cancelled::
      000987                        603 	.ds 1
      000988                        604 _ak820_macro_change_PARM_2:
      000988                        605 	.ds 1
      000989                        606 _ak820_macro_change_PARM_3:
      000989                        607 	.ds 1
      00098A                        608 _ak820_macro_change_bits_10000_299:
      00098A                        609 	.ds 2
      00098C                        610 _change_owned_PARM_2:
      00098C                        611 	.ds 1
      00098D                        612 _change_owned_mods_10000_304:
      00098D                        613 	.ds 1
      00098E                        614 _change_owned_result_10001_308:
      00098E                        615 	.ds 1
      00098F                        616 _change_owned_bit_20001_309:
      00098F                        617 	.ds 1
      000990                        618 _add_owned_mods_mods_10000_317:
      000990                        619 	.ds 1
      000991                        620 _del_owned_mods_mods_10000_319:
      000991                        621 	.ds 1
      000992                        622 _add_owned_weak_mods_mods_10000_321:
      000992                        623 	.ds 1
      000993                        624 _del_owned_weak_mods_mods_10000_323:
      000993                        625 	.ds 1
      000994                        626 _key_refs:
      000994                        627 	.ds 165
      000A39                        628 _distinct_keys:
      000A39                        629 	.ds 1
      000A3A                        630 _macro_keys:
      000A3A                        631 	.ds 21
      000A4F                        632 _add_owned_key_code_10000_332:
      000A4F                        633 	.ds 1
      000A50                        634 _del_owned_key_code_10000_347:
      000A50                        635 	.ds 1
      000A51                        636 _usage_refs:
      000A51                        637 	.ds 30
      000A6F                        638 _usage_order:
      000A6F                        639 	.ds 30
      000A8D                        640 _usage_lengths:
      000A8D                        641 	.ds 2
      000A8F                        642 _macro_usages:
      000A8F                        643 	.ds 4
      000A93                        644 _owned_usage_key_PARM_2:
      000A93                        645 	.ds 1
      000A94                        646 _owned_usage_key_code_10000_374:
      000A94                        647 	.ds 1
      000A95                        648 _owned_usage_key___200000085_20000_375:
      000A95                        649 	.ds 2
      000A97                        650 _owned_usage_key_which_10000_375:
      000A97                        651 	.ds 1
      000A98                        652 _owned_usage_key_count_10000_375:
      000A98                        653 	.ds 1
      000A99                        654 _owned_usage_key_pos_30001_382:
      000A99                        655 	.ds 1
      000A9A                        656 _owned_usage_key_key_40000_387:
      000A9A                        657 	.ds 1
      000A9B                        658 _send_keyboard_report_last_report_10001_395:
      000A9B                        659 	.ds 32
      000ABB                        660 _send_keyboard_report_changed_10001_395:
      000ABB                        661 	.ds 1
      000ABC                        662 _add_weak_mods_mods_10000_413:
      000ABC                        663 	.ds 1
      000ABD                        664 _del_weak_mods_mods_10000_415:
      000ABD                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000DC3                        674 _real_mods:
      000DC3                        675 	.ds 1
      000DC4                        676 _weak_mods:
      000DC4                        677 	.ds 1
      000DC5                        678 _actual_keyboard_report::
      000DC5                        679 	.ds 32
                                    680 	.area HOME    (CODE)
                                    681 	.area GSINIT0 (CODE)
                                    682 	.area GSINIT1 (CODE)
                                    683 	.area GSINIT2 (CODE)
                                    684 	.area GSINIT3 (CODE)
                                    685 	.area GSINIT4 (CODE)
                                    686 	.area GSINIT5 (CODE)
                                    687 	.area GSINIT  (CODE)
                                    688 	.area GSFINAL (CODE)
                                    689 	.area CSEG    (CODE)
                                    690 ;--------------------------------------------------------
                                    691 ; global & static initialisations
                                    692 ;--------------------------------------------------------
                                    693 	.area HOME    (CODE)
                                    694 	.area GSINIT  (CODE)
                                    695 	.area GSFINAL (CODE)
                                    696 	.area GSINIT  (CODE)
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    708 ;------------------------------------------------------------
                                    709 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    710 ;------------------------------------------------------------
                                    711 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function ak820_gui_process
                                    722 ;	-----------------------------------------
      007B45                        723 _ak820_gui_process:
      007B45 12 38 82         [24]  724 	lcall	_ak820_outline_0107
      007B48 90 09 70         [24]  725 	mov	dptr,#_ak820_gui_process_code_10000_294
      007B4B 12 38 87         [24]  726 	lcall	_ak820_outline_0108
                                    727 ;	quantum/action_util.c:77: if (code < QK_MAGIC_GUI_ON || code > QK_MAGIC_TOGGLE_GUI) return true;
      007B4E 90 09 70         [24]  728 	mov	dptr,#_ak820_gui_process_code_10000_294
      007B51 12 38 41         [24]  729 	lcall	_ak820_outline_0051
      007B54 C3               [12]  730 	clr	c
      007B55 EE               [12]  731 	mov	a,r6
      007B56 94 09            [12]  732 	subb	a,#0x09
      007B58 EF               [12]  733 	mov	a,r7
      007B59 94 70            [12]  734 	subb	a,#0x70
      007B5B 40 08            [24]  735 	jc	00101$
      007B5D 74 0B            [12]  736 	mov	a,#0x0b
      007B5F 9E               [12]  737 	subb	a,r6
      007B60 74 70            [12]  738 	mov	a,#0x70
      007B62 9F               [12]  739 	subb	a,r7
      007B63 50 04            [24]  740 	jnc	00102$
                                    741 ;	free result
      007B65                        742 00101$:
      007B65 75 82 01         [24]  743 	mov	dpl, #0x01
      007B68 22               [24]  744 	ret
      007B69                        745 00102$:
                                    746 ;	quantum/action_util.c:78: if (pressed) {
      007B69 90 09 6F         [24]  747 	mov	dptr,#_ak820_gui_process_PARM_2
      007B6C E0               [24]  748 	movx	a,@dptr
      007B6D 60 21            [24]  749 	jz	00105$
                                    750 ;	quantum/action_util.c:79: gui_disabled = code == QK_MAGIC_TOGGLE_GUI ? !gui_disabled : code == QK_MAGIC_GUI_OFF;
      007B6F BE 0B 0D         [24]  751 	cjne	r6,#0x0b,00108$
      007B72 BF 70 0A         [24]  752 	cjne	r7,#0x70,00108$
      007B75 A2 20            [12]  753 	mov	c,_gui_disabled
      007B77 B3               [12]  754 	cpl	c
      007B78 92 21            [24]  755 	mov  _ak820_gui_process_sloc0_1_0,c
      007B7A E4               [12]  756 	clr	a
      007B7B 33               [12]  757 	rlc	a
      007B7C FD               [12]  758 	mov	r5,a
      007B7D 80 09            [24]  759 	sjmp	00109$
      007B7F                        760 00108$:
      007B7F E4               [12]  761 	clr	a
      007B80 BE 0A 04         [24]  762 	cjne	r6,#0x0a,00136$
      007B83 BF 70 01         [24]  763 	cjne	r7,#0x70,00136$
      007B86 04               [12]  764 	inc	a
      007B87                        765 00136$:
      007B87 FD               [12]  766 	mov	r5,a
      007B88                        767 00109$:
                                    768 ;	assignBit
      007B88 ED               [12]  769 	mov	a,r5
      007B89 24 FF            [12]  770 	add	a,#0xff
      007B8B 92 20            [24]  771 	mov	_gui_disabled,c
                                    772 ;	quantum/action_util.c:80: send_keyboard_report();
      007B8D 12 80 0C         [24]  773 	lcall	_send_keyboard_report
      007B90                        774 00105$:
                                    775 ;	quantum/action_util.c:82: return false;
      007B90 75 82 00         [24]  776 	mov	dpl, #0x00
                                    777 ;	quantum/action_util.c:86: }
      007B93 22               [24]  778 	ret
                                    779 ;------------------------------------------------------------
                                    780 ;Allocation info for local variables in function 'ak820_macro_change'
                                    781 ;------------------------------------------------------------
                                    782 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    783 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    784 ;bits          Allocated with name '_ak820_macro_change_bits_10000_299'
                                    785 ;mask          Allocated with name '_ak820_macro_change_mask_10001_302'
                                    786 ;------------------------------------------------------------
                                    787 ;	quantum/action_util.c:95: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    788 ;	-----------------------------------------
                                    789 ;	 function ak820_macro_change
                                    790 ;	-----------------------------------------
      007B94                        791 _ak820_macro_change:
      007B94 12 38 82         [24]  792 	lcall	_ak820_outline_0107
      007B97 90 09 8A         [24]  793 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007B9A 12 38 87         [24]  794 	lcall	_ak820_outline_0108
                                    795 ;	quantum/action_util.c:96: if (!ak820_macro_primitive) return true;
      007B9D 90 09 86         [24]  796 	mov	dptr,#_ak820_macro_primitive
      007BA0 E0               [24]  797 	movx	a,@dptr
      007BA1 70 04            [24]  798 	jnz	00102$
      007BA3 75 82 01         [24]  799 	mov	dpl, #0x01
      007BA6 22               [24]  800 	ret
      007BA7                        801 00102$:
                                    802 ;	quantum/action_util.c:97: uint8_t mask = 1u << (index & 7);
      007BA7 90 09 88         [24]  803 	mov	dptr,#_ak820_macro_change_PARM_2
      007BAA E0               [24]  804 	movx	a,@dptr
      007BAB FF               [12]  805 	mov	r7,a
      007BAC 74 07            [12]  806 	mov	a,#0x07
      007BAE 5F               [12]  807 	anl	a,r7
      007BAF 12 76 D7         [24]  808 	lcall	_ak820_outline_0061
      007BB2 80 02            [24]  809 	sjmp	00123$
      007BB4                        810 00122$:
      007BB4 25 E0            [12]  811 	add	a,acc
      007BB6                        812 00123$:
      007BB6 D5 F0 FB         [24]  813 	djnz	b,00122$
      007BB9 FE               [12]  814 	mov	r6,a
                                    815 ;	quantum/action_util.c:98: bits += index >> 3;
      007BBA EF               [12]  816 	mov	a,r7
      007BBB 12 57 4D         [24]  817 	lcall	_ak820_outline_0188
      007BBE FF               [12]  818 	mov	r7,a
      007BBF 90 09 8A         [24]  819 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007BC2 12 38 58         [24]  820 	lcall	_ak820_outline_0059
      007BC5 90 09 8A         [24]  821 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007BC8 EF               [12]  822 	mov	a,r7
      007BC9 2C               [12]  823 	add	a, r4
      007BCA F0               [24]  824 	movx	@dptr,a
      007BCB E4               [12]  825 	clr	a
      007BCC 3D               [12]  826 	addc	a, r5
      007BCD A3               [24]  827 	inc	dptr
      007BCE F0               [24]  828 	movx	@dptr,a
                                    829 ;	quantum/action_util.c:99: if (((*bits & mask) != 0) == pressed) return false;
      007BCF 90 09 8A         [24]  830 	mov	dptr,#_ak820_macro_change_bits_10000_299
      007BD2 E0               [24]  831 	movx	a,@dptr
      007BD3 FD               [12]  832 	mov	r5,a
      007BD4 A3               [24]  833 	inc	dptr
      007BD5 E0               [24]  834 	movx	a,@dptr
      007BD6 FF               [12]  835 	mov	r7,a
      007BD7 12 81 25         [24]  836 	lcall	_ak820_outline_0189
      007BDA E0               [24]  837 	movx	a,@dptr
      007BDB FC               [12]  838 	mov	r4,a
      007BDC EE               [12]  839 	mov	a,r6
      007BDD 5C               [12]  840 	anl	a,r4
      007BDE B4 01 00         [24]  841 	cjne	a,#0x01,00124$
      007BE1                        842 00124$:
      007BE1 B3               [12]  843 	cpl	c
      007BE2 92 22            [24]  844 	mov	_ak820_macro_change_sloc0_1_0,c
      007BE4 90 09 89         [24]  845 	mov	dptr,#_ak820_macro_change_PARM_3
      007BE7 E0               [24]  846 	movx	a,@dptr
      007BE8 FB               [12]  847 	mov	r3,a
      007BE9 A2 22            [12]  848 	mov	c,_ak820_macro_change_sloc0_1_0
      007BEB E4               [12]  849 	clr	a
      007BEC 33               [12]  850 	rlc	a
      007BED B5 03 04         [24]  851 	cjne	a,ar3,00104$
      007BF0 75 82 00         [24]  852 	mov	dpl, #0x00
      007BF3 22               [24]  853 	ret
      007BF4                        854 00104$:
                                    855 ;	quantum/action_util.c:100: *bits ^= mask;
      007BF4 EC               [12]  856 	mov	a,r4
      007BF5 62 06            [12]  857 	xrl	ar6,a
      007BF7 12 81 25         [24]  858 	lcall	_ak820_outline_0189
      007BFA EE               [12]  859 	mov	a,r6
      007BFB F0               [24]  860 	movx	@dptr,a
                                    861 ;	quantum/action_util.c:101: return true;
      007BFC 75 82 01         [24]  862 	mov	dpl, #0x01
                                    863 ;	quantum/action_util.c:102: }
      007BFF 22               [24]  864 	ret
                                    865 ;------------------------------------------------------------
                                    866 ;Allocation info for local variables in function 'change_owned'
                                    867 ;------------------------------------------------------------
                                    868 ;mode          Allocated with name '_change_owned_PARM_2'
                                    869 ;mods          Allocated with name '_change_owned_mods_10000_304'
                                    870 ;kind          Allocated with name '_change_owned_kind_10000_305'
                                    871 ;pressed       Allocated with name '_change_owned_pressed_10000_305'
                                    872 ;refs          Allocated with name '_change_owned_refs_10000_305'
                                    873 ;old           Allocated with name '_change_owned_old_30000_307'
                                    874 ;result        Allocated with name '_change_owned_result_10001_308'
                                    875 ;i             Allocated with name '_change_owned_i_20001_309'
                                    876 ;bit           Allocated with name '_change_owned_bit_20001_309'
                                    877 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    878 ;------------------------------------------------------------
                                    879 ;	quantum/action_util.c:103: static void change_owned(uint8_t mods, uint8_t mode) {
                                    880 ;	-----------------------------------------
                                    881 ;	 function change_owned
                                    882 ;	-----------------------------------------
      007C00                        883 _change_owned:
      007C00 E5 82            [12]  884 	mov	a,dpl
      007C02 90 09 8D         [24]  885 	mov	dptr,#_change_owned_mods_10000_304
      007C05 F0               [24]  886 	movx	@dptr,a
                                    887 ;	quantum/action_util.c:104: uint8_t kind = mode >> 1;
      007C06 90 09 8C         [24]  888 	mov	dptr,#_change_owned_PARM_2
      007C09 E0               [24]  889 	movx	a,@dptr
      007C0A FF               [12]  890 	mov	r7,a
      007C0B C3               [12]  891 	clr	c
      007C0C 13               [12]  892 	rrc	a
      007C0D FE               [12]  893 	mov	r6,a
                                    894 ;	quantum/action_util.c:105: bool pressed = (mode & 1) != 0;
      007C0E 53 07 01         [24]  895 	anl	ar7,#0x01
      007C11 EF               [12]  896 	mov	a,r7
      007C12 B4 01 00         [24]  897 	cjne	a,#0x01,00205$
      007C15                        898 00205$:
      007C15 92 23            [24]  899 	mov  _change_owned_sloc0_1_0,c
      007C17 B3               [12]  900 	cpl	c
      007C18 E4               [12]  901 	clr	a
      007C19 33               [12]  902 	rlc	a
      007C1A F5 54            [12]  903 	mov	_change_owned_sloc1_1_0,a
                                    904 ;	quantum/action_util.c:106: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007C1C EE               [12]  905 	mov	a,r6
      007C1D 60 06            [24]  906 	jz	00121$
      007C1F 7D 7A            [12]  907 	mov	r5,#_owned_weak_refs
      007C21 7F 09            [12]  908 	mov	r7,#(_owned_weak_refs >> 8)
      007C23 80 04            [24]  909 	sjmp	00122$
      007C25                        910 00121$:
      007C25 7D 72            [12]  911 	mov	r5,#_owned_mod_refs
      007C27 7F 09            [12]  912 	mov	r7,#(_owned_mod_refs >> 8)
      007C29                        913 00122$:
                                    914 ;	quantum/action_util.c:107: if (ak820_macro_primitive) {
      007C29 90 09 86         [24]  915 	mov	dptr,#_ak820_macro_primitive
      007C2C E0               [24]  916 	movx	a,@dptr
      007C2D 60 37            [24]  917 	jz	00102$
                                    918 ;	quantum/action_util.c:108: uint8_t old = macro_mods[kind];
      007C2F EE               [12]  919 	mov	a,r6
      007C30 24 84            [12]  920 	add	a, #_macro_mods
      007C32 FB               [12]  921 	mov	r3,a
      007C33 E4               [12]  922 	clr	a
      007C34 34 09            [12]  923 	addc	a, #(_macro_mods >> 8)
      007C36 FC               [12]  924 	mov	r4,a
      007C37 12 48 99         [24]  925 	lcall	_ak820_outline_0063
                                    926 ;	quantum/action_util.c:109: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007C3A E5 54            [12]  927 	mov	a,_change_owned_sloc1_1_0
      007C3C 60 0A            [24]  928 	jz	00123$
      007C3E 90 09 8D         [24]  929 	mov	dptr,#_change_owned_mods_10000_304
      007C41 E0               [24]  930 	movx	a,@dptr
      007C42 F9               [12]  931 	mov	r1,a
      007C43 EA               [12]  932 	mov	a,r2
      007C44 42 01            [12]  933 	orl	ar1,a
      007C46 80 07            [24]  934 	sjmp	00124$
      007C48                        935 00123$:
      007C48 90 09 8D         [24]  936 	mov	dptr,#_change_owned_mods_10000_304
      007C4B E0               [24]  937 	movx	a,@dptr
      007C4C F4               [12]  938 	cpl	a
      007C4D 5A               [12]  939 	anl	a,r2
      007C4E F9               [12]  940 	mov	r1,a
      007C4F                        941 00124$:
      007C4F 12 33 FC         [24]  942 	lcall	_ak820_outline_0123
      007C52 E9               [12]  943 	mov	a,r1
      007C53 F0               [24]  944 	movx	@dptr,a
                                    945 ;	quantum/action_util.c:110: mods &= pressed ? ~old : old;
      007C54 E5 54            [12]  946 	mov	a,_change_owned_sloc1_1_0
      007C56 60 06            [24]  947 	jz	00125$
      007C58 74 FF            [12]  948 	mov	a,#0xff
      007C5A 6A               [12]  949 	xrl	a,r2
      007C5B FC               [12]  950 	mov	r4,a
      007C5C 80 02            [24]  951 	sjmp	00126$
      007C5E                        952 00125$:
      007C5E 8A 04            [24]  953 	mov	ar4,r2
      007C60                        954 00126$:
      007C60 90 09 8D         [24]  955 	mov	dptr,#_change_owned_mods_10000_304
      007C63 E0               [24]  956 	movx	a,@dptr
      007C64 5C               [12]  957 	anl	a,r4
      007C65 F0               [24]  958 	movx	@dptr,a
      007C66                        959 00102$:
                                    960 ;	quantum/action_util.c:112: uint8_t result = 0;
      007C66 90 09 8E         [24]  961 	mov	dptr,#_change_owned_result_10001_308
      007C69 E4               [12]  962 	clr	a
      007C6A F0               [24]  963 	movx	@dptr,a
                                    964 ;	quantum/action_util.c:113: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007C6B 90 09 8F         [24]  965 	mov	dptr,#_change_owned_bit_20001_309
      007C6E 04               [12]  966 	inc	a
      007C6F F0               [24]  967 	movx	@dptr,a
      007C70 90 09 8D         [24]  968 	mov	dptr,#_change_owned_mods_10000_304
      007C73 E0               [24]  969 	movx	a,@dptr
      007C74 FC               [12]  970 	mov	r4,a
      007C75 7B 00            [12]  971 	mov	r3,#0x00
      007C77                        972 00117$:
      007C77 BB 08 00         [24]  973 	cjne	r3,#0x08,00210$
      007C7A                        974 00210$:
      007C7A 50 3F            [24]  975 	jnc	00112$
                                    976 ;	quantum/action_util.c:114: if (mods & bit) {
      007C7C 90 09 8F         [24]  977 	mov	dptr,#_change_owned_bit_20001_309
      007C7F E0               [24]  978 	movx	a,@dptr
      007C80 5C               [12]  979 	anl	a,r4
      007C81 60 1C            [24]  980 	jz	00109$
                                    981 ;	quantum/action_util.c:115: if (pressed) ++refs[i];
      007C83 E5 54            [12]  982 	mov	a,_change_owned_sloc1_1_0
      007C85 60 0C            [24]  983 	jz	00106$
      007C87 EB               [12]  984 	mov	a,r3
      007C88 2D               [12]  985 	add	a, r5
      007C89 12 38 1F         [24]  986 	lcall	_ak820_outline_0016
      007C8C F8               [12]  987 	mov	r0,a
      007C8D 08               [12]  988 	inc	r0
      007C8E 12 80 D9         [24]  989 	lcall	_ak820_outline_0062
      007C91 80 0C            [24]  990 	sjmp	00109$
      007C93                        991 00106$:
                                    992 ;	quantum/action_util.c:116: else if (refs[i]) --refs[i];
      007C93 EB               [12]  993 	mov	a,r3
      007C94 2D               [12]  994 	add	a, r5
      007C95 12 38 1F         [24]  995 	lcall	_ak820_outline_0016
      007C98 F8               [12]  996 	mov	r0,a
      007C99 60 04            [24]  997 	jz	00109$
      007C9B 18               [12]  998 	dec	r0
      007C9C 12 80 D9         [24]  999 	lcall	_ak820_outline_0062
      007C9F                       1000 00109$:
                                   1001 ;	quantum/action_util.c:118: if (refs[i]) result |= bit;
      007C9F EB               [12] 1002 	mov	a,r3
      007CA0 2D               [12] 1003 	add	a, r5
      007CA1 12 38 1F         [24] 1004 	lcall	_ak820_outline_0016
      007CA4 60 0B            [24] 1005 	jz	00118$
      007CA6 90 09 8F         [24] 1006 	mov	dptr,#_change_owned_bit_20001_309
      007CA9 E0               [24] 1007 	movx	a,@dptr
      007CAA FA               [12] 1008 	mov	r2,a
      007CAB 90 09 8E         [24] 1009 	mov	dptr,#_change_owned_result_10001_308
      007CAE E0               [24] 1010 	movx	a,@dptr
      007CAF 4A               [12] 1011 	orl	a,r2
      007CB0 F0               [24] 1012 	movx	@dptr,a
      007CB1                       1013 00118$:
                                   1014 ;	quantum/action_util.c:113: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007CB1 0B               [12] 1015 	inc	r3
      007CB2 90 09 8F         [24] 1016 	mov	dptr,#_change_owned_bit_20001_309
      007CB5 E0               [24] 1017 	movx	a,@dptr
      007CB6 25 E0            [12] 1018 	add	a,acc
      007CB8 F0               [24] 1019 	movx	@dptr,a
      007CB9 80 BC            [24] 1020 	sjmp	00117$
      007CBB                       1021 00112$:
                                   1022 ;	quantum/action_util.c:120: if (kind) owned_weak_mods = result;
      007CBB EE               [12] 1023 	mov	a,r6
      007CBC 60 09            [24] 1024 	jz	00114$
      007CBE 90 09 8E         [24] 1025 	mov	dptr,#_change_owned_result_10001_308
      007CC1 E0               [24] 1026 	movx	a,@dptr
      007CC2 90 09 83         [24] 1027 	mov	dptr,#_owned_weak_mods
      007CC5 F0               [24] 1028 	movx	@dptr,a
      007CC6 22               [24] 1029 	ret
      007CC7                       1030 00114$:
                                   1031 ;	quantum/action_util.c:121: else owned_mods = result;
      007CC7 90 09 8E         [24] 1032 	mov	dptr,#_change_owned_result_10001_308
      007CCA E0               [24] 1033 	movx	a,@dptr
      007CCB 90 09 82         [24] 1034 	mov	dptr,#_owned_mods
      007CCE F0               [24] 1035 	movx	@dptr,a
                                   1036 ;	quantum/action_util.c:122: }
      007CCF 22               [24] 1037 	ret
                                   1038 ;------------------------------------------------------------
                                   1039 ;Allocation info for local variables in function 'add_owned_mods'
                                   1040 ;------------------------------------------------------------
                                   1041 ;mods          Allocated with name '_add_owned_mods_mods_10000_317'
                                   1042 ;------------------------------------------------------------
                                   1043 ;	quantum/action_util.c:123: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1044 ;	-----------------------------------------
                                   1045 ;	 function add_owned_mods
                                   1046 ;	-----------------------------------------
      007CD0                       1047 _add_owned_mods:
      007CD0 E5 82            [12] 1048 	mov	a,dpl
      007CD2 90 09 90         [24] 1049 	mov	dptr,#_add_owned_mods_mods_10000_317
      007CD5 12 80 F9         [24] 1050 	lcall	_ak820_outline_0117
      007CD8 74 01            [12] 1051 	mov	a,#0x01
      007CDA F0               [24] 1052 	movx	@dptr,a
      007CDB 8F 82            [24] 1053 	mov	dpl, r7
      007CDD 02 7C 00         [24] 1054 	ljmp	_change_owned
                                   1055 ;------------------------------------------------------------
                                   1056 ;Allocation info for local variables in function 'del_owned_mods'
                                   1057 ;------------------------------------------------------------
                                   1058 ;mods          Allocated with name '_del_owned_mods_mods_10000_319'
                                   1059 ;------------------------------------------------------------
                                   1060 ;	quantum/action_util.c:124: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1061 ;	-----------------------------------------
                                   1062 ;	 function del_owned_mods
                                   1063 ;	-----------------------------------------
      007CE0                       1064 _del_owned_mods:
      007CE0 E5 82            [12] 1065 	mov	a,dpl
      007CE2 90 09 91         [24] 1066 	mov	dptr,#_del_owned_mods_mods_10000_319
      007CE5 12 80 F9         [24] 1067 	lcall	_ak820_outline_0117
      007CE8 E4               [12] 1068 	clr	a
      007CE9 F0               [24] 1069 	movx	@dptr,a
      007CEA 8F 82            [24] 1070 	mov	dpl, r7
      007CEC 02 7C 00         [24] 1071 	ljmp	_change_owned
                                   1072 ;------------------------------------------------------------
                                   1073 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1074 ;------------------------------------------------------------
                                   1075 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_321'
                                   1076 ;------------------------------------------------------------
                                   1077 ;	quantum/action_util.c:125: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1078 ;	-----------------------------------------
                                   1079 ;	 function add_owned_weak_mods
                                   1080 ;	-----------------------------------------
      007CEF                       1081 _add_owned_weak_mods:
      007CEF E5 82            [12] 1082 	mov	a,dpl
      007CF1 90 09 92         [24] 1083 	mov	dptr,#_add_owned_weak_mods_mods_10000_321
      007CF4 12 80 F9         [24] 1084 	lcall	_ak820_outline_0117
      007CF7 74 03            [12] 1085 	mov	a,#0x03
      007CF9 F0               [24] 1086 	movx	@dptr,a
      007CFA 8F 82            [24] 1087 	mov	dpl, r7
      007CFC 02 7C 00         [24] 1088 	ljmp	_change_owned
                                   1089 ;------------------------------------------------------------
                                   1090 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1091 ;------------------------------------------------------------
                                   1092 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_323'
                                   1093 ;------------------------------------------------------------
                                   1094 ;	quantum/action_util.c:126: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1095 ;	-----------------------------------------
                                   1096 ;	 function del_owned_weak_mods
                                   1097 ;	-----------------------------------------
      007CFF                       1098 _del_owned_weak_mods:
      007CFF E5 82            [12] 1099 	mov	a,dpl
      007D01 90 09 93         [24] 1100 	mov	dptr,#_del_owned_weak_mods_mods_10000_323
      007D04 12 80 F9         [24] 1101 	lcall	_ak820_outline_0117
      007D07 74 02            [12] 1102 	mov	a,#0x02
      007D09 F0               [24] 1103 	movx	@dptr,a
      007D0A 8F 82            [24] 1104 	mov	dpl, r7
      007D0C 02 7C 00         [24] 1105 	ljmp	_change_owned
                                   1106 ;------------------------------------------------------------
                                   1107 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1108 ;------------------------------------------------------------
                                   1109 ;i             Allocated with name '_clear_owned_mods_i_20000_327'
                                   1110 ;------------------------------------------------------------
                                   1111 ;	quantum/action_util.c:127: void clear_owned_mods(void) {
                                   1112 ;	-----------------------------------------
                                   1113 ;	 function clear_owned_mods
                                   1114 ;	-----------------------------------------
      007D0F                       1115 _clear_owned_mods:
                                   1116 ;	quantum/action_util.c:128: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007D0F 7F 00            [12] 1117 	mov	r7,#0x00
      007D11                       1118 00103$:
      007D11 BF 08 00         [24] 1119 	cjne	r7,#0x08,00122$
      007D14                       1120 00122$:
      007D14 50 1A            [24] 1121 	jnc	00101$
      007D16 EF               [12] 1122 	mov	a,r7
      007D17 24 72            [12] 1123 	add	a, #_owned_mod_refs
      007D19 FD               [12] 1124 	mov	r5,a
      007D1A E4               [12] 1125 	clr	a
      007D1B 34 09            [12] 1126 	addc	a, #(_owned_mod_refs >> 8)
      007D1D FE               [12] 1127 	mov	r6,a
      007D1E EF               [12] 1128 	mov	a,r7
      007D1F 24 7A            [12] 1129 	add	a, #_owned_weak_refs
      007D21 F5 82            [12] 1130 	mov	dpl,a
      007D23 E4               [12] 1131 	clr	a
      007D24 34 09            [12] 1132 	addc	a, #(_owned_weak_refs >> 8)
      007D26 F5 83            [12] 1133 	mov	dph,a
      007D28 E4               [12] 1134 	clr	a
      007D29 F0               [24] 1135 	movx	@dptr,a
      007D2A 12 81 00         [24] 1136 	lcall	_ak820_outline_0121
      007D2D 0F               [12] 1137 	inc	r7
      007D2E 80 E1            [24] 1138 	sjmp	00103$
      007D30                       1139 00101$:
                                   1140 ;	quantum/action_util.c:129: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007D30 90 09 85         [24] 1141 	mov	dptr,#(_macro_mods + 0x0001)
      007D33 E4               [12] 1142 	clr	a
      007D34 F0               [24] 1143 	movx	@dptr,a
      007D35 90 09 84         [24] 1144 	mov	dptr,#_macro_mods
      007D38 F0               [24] 1145 	movx	@dptr,a
      007D39 90 09 83         [24] 1146 	mov	dptr,#_owned_weak_mods
      007D3C F0               [24] 1147 	movx	@dptr,a
      007D3D 90 09 82         [24] 1148 	mov	dptr,#_owned_mods
      007D40 F0               [24] 1149 	movx	@dptr,a
                                   1150 ;	quantum/action_util.c:130: ak820_macro_cancelled = true;
      007D41 90 09 87         [24] 1151 	mov	dptr,#_ak820_macro_cancelled
      007D44 04               [12] 1152 	inc	a
      007D45 F0               [24] 1153 	movx	@dptr,a
                                   1154 ;	quantum/action_util.c:131: }
      007D46 22               [24] 1155 	ret
                                   1156 ;------------------------------------------------------------
                                   1157 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1158 ;------------------------------------------------------------
                                   1159 ;i             Allocated with name '_clear_owned_keys_i_20000_330'
                                   1160 ;i             Allocated with name '_clear_owned_keys_i_20000_331'
                                   1161 ;------------------------------------------------------------
                                   1162 ;	quantum/action_util.c:137: void clear_owned_keys(void) {
                                   1163 ;	-----------------------------------------
                                   1164 ;	 function clear_owned_keys
                                   1165 ;	-----------------------------------------
      007D47                       1166 _clear_owned_keys:
                                   1167 ;	quantum/action_util.c:138: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007D47 7F 00            [12] 1168 	mov	r7,#0x00
      007D49                       1169 00104$:
      007D49 EF               [12] 1170 	mov	a,r7
      007D4A 24 5B            [12] 1171 	add	a,#0xff - 0xa4
      007D4C 40 0D            [24] 1172 	jc	00101$
                                   1173 ;	free result
      007D4E EF               [12] 1174 	mov	a,r7
      007D4F 24 94            [12] 1175 	add	a, #_key_refs
      007D51 F5 82            [12] 1176 	mov	dpl,a
      007D53 E4               [12] 1177 	clr	a
      007D54 34 09            [12] 1178 	addc	a, #(_key_refs >> 8)
      007D56 12 7B 36         [24] 1179 	lcall	_ak820_outline_0163
      007D59 80 EE            [24] 1180 	sjmp	00104$
      007D5B                       1181 00101$:
                                   1182 ;	quantum/action_util.c:139: distinct_keys = 0;
      007D5B 90 0A 39         [24] 1183 	mov	dptr,#_distinct_keys
      007D5E E4               [12] 1184 	clr	a
      007D5F F0               [24] 1185 	movx	@dptr,a
                                   1186 ;	quantum/action_util.c:140: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007D60 FF               [12] 1187 	mov	r7,a
      007D61                       1188 00107$:
      007D61 BF 15 00         [24] 1189 	cjne	r7,#0x15,00142$
      007D64                       1190 00142$:
      007D64 50 0D            [24] 1191 	jnc	00109$
      007D66 EF               [12] 1192 	mov	a,r7
      007D67 24 3A            [12] 1193 	add	a, #_macro_keys
      007D69 F5 82            [12] 1194 	mov	dpl,a
      007D6B E4               [12] 1195 	clr	a
      007D6C 34 0A            [12] 1196 	addc	a, #(_macro_keys >> 8)
      007D6E 12 7B 36         [24] 1197 	lcall	_ak820_outline_0163
      007D71 80 EE            [24] 1198 	sjmp	00107$
      007D73                       1199 00109$:
                                   1200 ;	quantum/action_util.c:141: }
      007D73 22               [24] 1201 	ret
                                   1202 ;------------------------------------------------------------
                                   1203 ;Allocation info for local variables in function 'add_owned_key'
                                   1204 ;------------------------------------------------------------
                                   1205 ;code          Allocated with name '_add_owned_key_code_10000_332'
                                   1206 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_341'
                                   1207 ;key           Allocated with name '_add_owned_key_key_50000_342'
                                   1208 ;i             Allocated with name '_add_owned_key_i_40000_340'
                                   1209 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_344'
                                   1210 ;key           Allocated with name '_add_owned_key_key_40000_345'
                                   1211 ;------------------------------------------------------------
                                   1212 ;	quantum/action_util.c:142: bool add_owned_key(uint8_t code) {
                                   1213 ;	-----------------------------------------
                                   1214 ;	 function add_owned_key
                                   1215 ;	-----------------------------------------
      007D74                       1216 _add_owned_key:
      007D74 E5 82            [12] 1217 	mov	a,dpl
      007D76 90 0A 4F         [24] 1218 	mov	dptr,#_add_owned_key_code_10000_332
      007D79 12 81 11         [24] 1219 	lcall	_ak820_outline_0132
                                   1220 ;	quantum/action_util.c:143: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007D7C 74 01            [12] 1221 	mov	a,#0x01
      007D7E F0               [24] 1222 	movx	@dptr,a
      007D7F 90 0A 3A         [24] 1223 	mov	dptr,#_macro_keys
      007D82 C0 07            [24] 1224 	push	ar7
      007D84 12 7B 94         [24] 1225 	lcall	_ak820_macro_change
      007D87 E5 82            [12] 1226 	mov	a, dpl
      007D89 D0 07            [24] 1227 	pop	ar7
      007D8B 70 03            [24] 1228 	jnz	00102$
      007D8D F5 82            [12] 1229 	mov	dpl,a
      007D8F 22               [24] 1230 	ret
      007D90                       1231 00102$:
                                   1232 ;	quantum/action_util.c:144: if (key_refs[code]++) return false;
      007D90 12 80 CB         [24] 1233 	lcall	_ak820_outline_0030
      007D93 FC               [12] 1234 	mov	r4,a
      007D94 04               [12] 1235 	inc	a
      007D95 12 81 00         [24] 1236 	lcall	_ak820_outline_0121
      007D98 EC               [12] 1237 	mov	a,r4
      007D99 60 04            [24] 1238 	jz	00104$
      007D9B 75 82 00         [24] 1239 	mov	dpl, #0x00
      007D9E 22               [24] 1240 	ret
      007D9F                       1241 00104$:
                                   1242 ;	quantum/action_util.c:145: ++distinct_keys;
      007D9F 90 0A 39         [24] 1243 	mov	dptr,#_distinct_keys
      007DA2 E0               [24] 1244 	movx	a,@dptr
      007DA3 24 01            [12] 1245 	add	a, #0x01
      007DA5 F0               [24] 1246 	movx	@dptr,a
                                   1247 ;	quantum/action_util.c:147: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007DA6 90 0D B2         [24] 1248 	mov	dptr,#_keyboard_protocol
      007DA9 E0               [24] 1249 	movx	a,@dptr
      007DAA 60 11            [24] 1250 	jz	00106$
      007DAC 90 0A BE         [24] 1251 	mov	dptr,#_keymap_config
      007DAF E0               [24] 1252 	movx	a,@dptr
      007DB0 30 E7 0A         [24] 1253 	jnb	acc.7,00106$
                                   1254 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007DB3 12 81 1C         [24] 1255 	lcall	_ak820_outline_0175
      007DB6 12 6E BB         [24] 1256 	lcall	_add_key_to_report
                                   1257 ;	quantum/action_util.c:147: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007DB9 75 82 01         [24] 1258 	mov	dpl, #0x01
      007DBC 22               [24] 1259 	ret
      007DBD                       1260 00106$:
                                   1261 ;	quantum/action_util.c:149: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007DBD 90 0A 39         [24] 1262 	mov	dptr,#_distinct_keys
      007DC0 E0               [24] 1263 	movx	a,@dptr
      007DC1 24 F9            [12] 1264 	add	a,#0xff - 0x06
      007DC3 50 17            [24] 1265 	jnc	00110$
                                   1266 ;	free result
                                   1267 ;	quantum/action_util.c:150: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007DC5 7F 00            [12] 1268 	mov	r7,#0x00
      007DC7                       1269 00115$:
      007DC7 BF 06 00         [24] 1270 	cjne	r7,#0x06,00174$
      007DCA                       1271 00174$:
      007DCA 50 1E            [24] 1272 	jnc	00111$
      007DCC EF               [12] 1273 	mov	a,r7
      007DCD 24 C7            [12] 1274 	add	a, #(_actual_keyboard_report + 0x0002)
      007DCF F5 82            [12] 1275 	mov	dpl,a
      007DD1 E4               [12] 1276 	clr	a
      007DD2 34 0D            [12] 1277 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007DD4 F5 83            [12] 1278 	mov	dph,a
      007DD6 74 01            [12] 1279 	mov	a,#0x01
      007DD8 F0               [24] 1280 	movx	@dptr,a
      007DD9 0F               [12] 1281 	inc	r7
      007DDA 80 EB            [24] 1282 	sjmp	00115$
      007DDC                       1283 00110$:
                                   1284 ;	quantum/action_util.c:151: } else add_key(code);
      007DDC 90 0A 4F         [24] 1285 	mov	dptr,#_add_owned_key_code_10000_332
      007DDF E0               [24] 1286 	movx	a,@dptr
                                   1287 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007DE0 90 07 FF         [24] 1288 	mov	dptr,#_add_key_to_report_PARM_2
      007DE3 F0               [24] 1289 	movx	@dptr,a
      007DE4 90 0D C5         [24] 1290 	mov	dptr,#_actual_keyboard_report
      007DE7 12 6E BB         [24] 1291 	lcall	_add_key_to_report
                                   1292 ;	quantum/action_util.c:151: } else add_key(code);
      007DEA                       1293 00111$:
                                   1294 ;	quantum/action_util.c:152: return true;
      007DEA 75 82 01         [24] 1295 	mov	dpl, #0x01
                                   1296 ;	quantum/action_util.c:153: }
      007DED 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'del_owned_key'
                                   1300 ;------------------------------------------------------------
                                   1301 ;code          Allocated with name '_del_owned_key_code_10000_347'
                                   1302 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_358'
                                   1303 ;key           Allocated with name '_del_owned_key_key_50000_359'
                                   1304 ;key           Allocated with name '_del_owned_key_key_40000_356'
                                   1305 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_364'
                                   1306 ;key           Allocated with name '_del_owned_key_key_70000_365'
                                   1307 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_367'
                                   1308 ;key           Allocated with name '_del_owned_key_key_40000_368'
                                   1309 ;------------------------------------------------------------
                                   1310 ;	quantum/action_util.c:154: bool del_owned_key(uint8_t code) {
                                   1311 ;	-----------------------------------------
                                   1312 ;	 function del_owned_key
                                   1313 ;	-----------------------------------------
      007DEE                       1314 _del_owned_key:
      007DEE E5 82            [12] 1315 	mov	a,dpl
      007DF0 90 0A 50         [24] 1316 	mov	dptr,#_del_owned_key_code_10000_347
      007DF3 12 81 11         [24] 1317 	lcall	_ak820_outline_0132
                                   1318 ;	quantum/action_util.c:155: if (!ak820_macro_change(macro_keys, code, false)) return false;
      007DF6 E4               [12] 1319 	clr	a
      007DF7 F0               [24] 1320 	movx	@dptr,a
      007DF8 90 0A 3A         [24] 1321 	mov	dptr,#_macro_keys
      007DFB C0 07            [24] 1322 	push	ar7
      007DFD 12 7B 94         [24] 1323 	lcall	_ak820_macro_change
      007E00 E5 82            [12] 1324 	mov	a, dpl
      007E02 D0 07            [24] 1325 	pop	ar7
      007E04 70 03            [24] 1326 	jnz	00102$
      007E06 F5 82            [12] 1327 	mov	dpl,a
      007E08 22               [24] 1328 	ret
      007E09                       1329 00102$:
                                   1330 ;	quantum/action_util.c:156: if (!key_refs[code] || --key_refs[code]) return false;
      007E09 12 80 CB         [24] 1331 	lcall	_ak820_outline_0030
      007E0C FC               [12] 1332 	mov	r4,a
      007E0D 60 09            [24] 1333 	jz	00103$
      007E0F 1C               [12] 1334 	dec	r4
      007E10 12 38 9C         [24] 1335 	lcall	_ak820_outline_0133
      007E13 EC               [12] 1336 	mov	a,r4
      007E14 F0               [24] 1337 	movx	@dptr,a
      007E15 EC               [12] 1338 	mov	a,r4
      007E16 60 04            [24] 1339 	jz	00104$
      007E18                       1340 00103$:
      007E18 75 82 00         [24] 1341 	mov	dpl, #0x00
      007E1B 22               [24] 1342 	ret
      007E1C                       1343 00104$:
                                   1344 ;	quantum/action_util.c:157: --distinct_keys;
      007E1C 90 0A 39         [24] 1345 	mov	dptr,#_distinct_keys
      007E1F E0               [24] 1346 	movx	a,@dptr
      007E20 14               [12] 1347 	dec	a
      007E21 F0               [24] 1348 	movx	@dptr,a
                                   1349 ;	quantum/action_util.c:159: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007E22 90 0D B2         [24] 1350 	mov	dptr,#_keyboard_protocol
      007E25 E0               [24] 1351 	movx	a,@dptr
      007E26 60 16            [24] 1352 	jz	00107$
      007E28 90 0A BE         [24] 1353 	mov	dptr,#_keymap_config
      007E2B E0               [24] 1354 	movx	a,@dptr
      007E2C 30 E7 0F         [24] 1355 	jnb	acc.7,00107$
                                   1356 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007E2F 90 08 02         [24] 1357 	mov	dptr,#_del_key_from_report_PARM_2
      007E32 EF               [12] 1358 	mov	a,r7
      007E33 F0               [24] 1359 	movx	@dptr,a
      007E34 90 0D C5         [24] 1360 	mov	dptr,#_actual_keyboard_report
      007E37 12 6E F1         [24] 1361 	lcall	_del_key_from_report
                                   1362 ;	quantum/action_util.c:159: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      007E3A 75 82 01         [24] 1363 	mov	dpl, #0x01
      007E3D 22               [24] 1364 	ret
      007E3E                       1365 00107$:
                                   1366 ;	quantum/action_util.c:161: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      007E3E 90 0A 39         [24] 1367 	mov	dptr,#_distinct_keys
      007E41 E0               [24] 1368 	movx	a,@dptr
      007E42 FF               [12] 1369 	mov  r7,a
      007E43 24 F9            [12] 1370 	add	a,#0xff - 0x06
      007E45 50 04            [24] 1371 	jnc	00110$
                                   1372 ;	free result
      007E47 75 82 01         [24] 1373 	mov	dpl, #0x01
      007E4A 22               [24] 1374 	ret
      007E4B                       1375 00110$:
                                   1376 ;	quantum/action_util.c:162: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      007E4B BF 06 1F         [24] 1377 	cjne	r7,#0x06,00115$
                                   1378 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007E4E 90 0D C5         [24] 1379 	mov	dptr,#_actual_keyboard_report
      007E51 12 6F 27         [24] 1380 	lcall	_clear_keys_from_report
                                   1381 ;	quantum/action_util.c:165: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007E54 7F 04            [12] 1382 	mov	r7,#0x04
      007E56                       1383 00122$:
      007E56 EF               [12] 1384 	mov	a,r7
      007E57 24 5B            [12] 1385 	add	a,#0xff - 0xa4
      007E59 40 20            [24] 1386 	jc	00116$
                                   1387 ;	free result
      007E5B 12 80 CB         [24] 1388 	lcall	_ak820_outline_0030
      007E5E 60 0A            [24] 1389 	jz	00123$
                                   1390 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007E60 12 81 1C         [24] 1391 	lcall	_ak820_outline_0175
      007E63 C0 07            [24] 1392 	push	ar7
      007E65 12 6E BB         [24] 1393 	lcall	_add_key_to_report
      007E68 D0 07            [24] 1394 	pop	ar7
                                   1395 ;	quantum/action_util.c:165: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      007E6A                       1396 00123$:
      007E6A 0F               [12] 1397 	inc	r7
      007E6B 80 E9            [24] 1398 	sjmp	00122$
      007E6D                       1399 00115$:
                                   1400 ;	quantum/action_util.c:166: } else del_key(code);
      007E6D 90 0A 50         [24] 1401 	mov	dptr,#_del_owned_key_code_10000_347
      007E70 E0               [24] 1402 	movx	a,@dptr
                                   1403 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      007E71 90 08 02         [24] 1404 	mov	dptr,#_del_key_from_report_PARM_2
      007E74 F0               [24] 1405 	movx	@dptr,a
      007E75 90 0D C5         [24] 1406 	mov	dptr,#_actual_keyboard_report
      007E78 12 6E F1         [24] 1407 	lcall	_del_key_from_report
                                   1408 ;	quantum/action_util.c:166: } else del_key(code);
      007E7B                       1409 00116$:
                                   1410 ;	quantum/action_util.c:167: return true;
      007E7B 75 82 01         [24] 1411 	mov	dpl, #0x01
                                   1412 ;	quantum/action_util.c:168: }
      007E7E 22               [24] 1413 	ret
                                   1414 ;------------------------------------------------------------
                                   1415 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1416 ;------------------------------------------------------------
                                   1417 ;i             Allocated with name '_clear_owned_usages_i_20000_372'
                                   1418 ;i             Allocated with name '_clear_owned_usages_i_20000_373'
                                   1419 ;------------------------------------------------------------
                                   1420 ;	quantum/action_util.c:178: void clear_owned_usages(void) {
                                   1421 ;	-----------------------------------------
                                   1422 ;	 function clear_owned_usages
                                   1423 ;	-----------------------------------------
      007E7F                       1424 _clear_owned_usages:
                                   1425 ;	quantum/action_util.c:179: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      007E7F 7F 00            [12] 1426 	mov	r7,#0x00
      007E81                       1427 00104$:
      007E81 BF 1E 00         [24] 1428 	cjne	r7,#0x1e,00141$
      007E84                       1429 00141$:
      007E84 50 14            [24] 1430 	jnc	00101$
      007E86 EF               [12] 1431 	mov	a,r7
      007E87 24 51            [12] 1432 	add	a, #_usage_refs
      007E89 FD               [12] 1433 	mov	r5,a
      007E8A E4               [12] 1434 	clr	a
      007E8B 34 0A            [12] 1435 	addc	a, #(_usage_refs >> 8)
      007E8D FE               [12] 1436 	mov	r6,a
      007E8E EF               [12] 1437 	mov	a,r7
      007E8F 12 80 E0         [24] 1438 	lcall	_ak820_outline_0067
      007E92 E4               [12] 1439 	clr	a
      007E93 F0               [24] 1440 	movx	@dptr,a
      007E94 12 81 00         [24] 1441 	lcall	_ak820_outline_0121
      007E97 0F               [12] 1442 	inc	r7
      007E98 80 E7            [24] 1443 	sjmp	00104$
      007E9A                       1444 00101$:
                                   1445 ;	quantum/action_util.c:180: usage_lengths[0] = usage_lengths[1] = 0;
      007E9A 90 0A 8E         [24] 1446 	mov	dptr,#(_usage_lengths + 0x0001)
      007E9D E4               [12] 1447 	clr	a
      007E9E F0               [24] 1448 	movx	@dptr,a
      007E9F 90 0A 8D         [24] 1449 	mov	dptr,#_usage_lengths
      007EA2 F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	quantum/action_util.c:181: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      007EA3 FF               [12] 1452 	mov	r7,a
      007EA4                       1453 00107$:
      007EA4 BF 04 00         [24] 1454 	cjne	r7,#0x04,00143$
      007EA7                       1455 00143$:
      007EA7 50 0D            [24] 1456 	jnc	00109$
      007EA9 EF               [12] 1457 	mov	a,r7
      007EAA 24 8F            [12] 1458 	add	a, #_macro_usages
      007EAC F5 82            [12] 1459 	mov	dpl,a
      007EAE E4               [12] 1460 	clr	a
      007EAF 34 0A            [12] 1461 	addc	a, #(_macro_usages >> 8)
      007EB1 12 7B 36         [24] 1462 	lcall	_ak820_outline_0163
      007EB4 80 EE            [24] 1463 	sjmp	00107$
      007EB6                       1464 00109$:
                                   1465 ;	quantum/action_util.c:182: }
      007EB6 22               [24] 1466 	ret
                                   1467 ;------------------------------------------------------------
                                   1468 ;Allocation info for local variables in function 'owned_usage_key'
                                   1469 ;------------------------------------------------------------
                                   1470 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1471 ;code          Allocated with name '_owned_usage_key_code_10000_374'
                                   1472 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_375'
                                   1473 ;which         Allocated with name '_owned_usage_key_which_10000_375'
                                   1474 ;base          Allocated with name '_owned_usage_key_base_10000_375'
                                   1475 ;count         Allocated with name '_owned_usage_key_count_10000_375'
                                   1476 ;index         Allocated with name '_owned_usage_key_index_10000_375'
                                   1477 ;pos           Allocated with name '_owned_usage_key_pos_30001_382'
                                   1478 ;i             Allocated with name '_owned_usage_key_i_40001_383'
                                   1479 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_386'
                                   1480 ;key           Allocated with name '_owned_usage_key_key_40000_387'
                                   1481 ;------------------------------------------------------------
                                   1482 ;	quantum/action_util.c:183: void owned_usage_key(uint8_t code, bool pressed) {
                                   1483 ;	-----------------------------------------
                                   1484 ;	 function owned_usage_key
                                   1485 ;	-----------------------------------------
      007EB7                       1486 _owned_usage_key:
      007EB7 E5 82            [12] 1487 	mov	a,dpl
      007EB9 90 0A 94         [24] 1488 	mov	dptr,#_owned_usage_key_code_10000_374
      007EBC F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	quantum/action_util.c:184: uint8_t which = code >= KC_AUDIO_MUTE;
      007EBD E0               [24] 1491 	movx	a,@dptr
      007EBE FF               [12] 1492 	mov	r7,a
      007EBF BF A8 00         [24] 1493 	cjne	r7,#0xa8,00244$
      007EC2                       1494 00244$:
      007EC2 B3               [12] 1495 	cpl	c
      007EC3 92 24            [24] 1496 	mov	_owned_usage_key_sloc0_1_0,c
      007EC5 E4               [12] 1497 	clr	a
      007EC6 33               [12] 1498 	rlc	a
      007EC7 FF               [12] 1499 	mov	r7,a
      007EC8 90 0A 97         [24] 1500 	mov	dptr,#_owned_usage_key_which_10000_375
      007ECB F0               [24] 1501 	movx	@dptr,a
                                   1502 ;	quantum/action_util.c:185: uint8_t base = which ? SYSTEM_COUNT : 0;
      007ECC EF               [12] 1503 	mov	a,r7
      007ECD 60 02            [24] 1504 	jz	00129$
      007ECF 74 03            [12] 1505 	mov	a,#0x03
      007ED1                       1506 00129$:
      007ED1 FE               [12] 1507 	mov	r6,a
                                   1508 ;	quantum/action_util.c:186: uint8_t count = usage_lengths[which];
      007ED2 EF               [12] 1509 	mov	a,r7
      007ED3 24 8D            [12] 1510 	add	a, #_usage_lengths
      007ED5 FD               [12] 1511 	mov	r5,a
      007ED6 E4               [12] 1512 	clr	a
      007ED7 34 0A            [12] 1513 	addc	a, #(_usage_lengths >> 8)
      007ED9 FF               [12] 1514 	mov	r7,a
      007EDA 12 81 25         [24] 1515 	lcall	_ak820_outline_0189
      007EDD E0               [24] 1516 	movx	a,@dptr
      007EDE FC               [12] 1517 	mov	r4,a
                                   1518 ;	quantum/action_util.c:187: uint8_t index = code - KC_SYSTEM_POWER;
      007EDF 90 0A 94         [24] 1519 	mov	dptr,#_owned_usage_key_code_10000_374
      007EE2 E0               [24] 1520 	movx	a,@dptr
      007EE3 24 5B            [12] 1521 	add	a,#0x5b
      007EE5 FB               [12] 1522 	mov	r3,a
                                   1523 ;	quantum/action_util.c:188: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      007EE6 90 0A 93         [24] 1524 	mov	dptr,#_owned_usage_key_PARM_2
      007EE9 E0               [24] 1525 	movx	a,@dptr
      007EEA FA               [12] 1526 	mov	r2,a
      007EEB 90 09 88         [24] 1527 	mov	dptr,#_ak820_macro_change_PARM_2
      007EEE EB               [12] 1528 	mov	a,r3
      007EEF F0               [24] 1529 	movx	@dptr,a
      007EF0 90 09 89         [24] 1530 	mov	dptr,#_ak820_macro_change_PARM_3
      007EF3 EA               [12] 1531 	mov	a,r2
      007EF4 F0               [24] 1532 	movx	@dptr,a
      007EF5 90 0A 8F         [24] 1533 	mov	dptr,#_macro_usages
      007EF8 C0 07            [24] 1534 	push	ar7
      007EFA C0 06            [24] 1535 	push	ar6
      007EFC C0 05            [24] 1536 	push	ar5
      007EFE C0 04            [24] 1537 	push	ar4
      007F00 C0 03            [24] 1538 	push	ar3
      007F02 C0 02            [24] 1539 	push	ar2
      007F04 12 7B 94         [24] 1540 	lcall	_ak820_macro_change
      007F07 E5 82            [12] 1541 	mov	a, dpl
      007F09 D0 02            [24] 1542 	pop	ar2
      007F0B D0 03            [24] 1543 	pop	ar3
      007F0D D0 04            [24] 1544 	pop	ar4
      007F0F D0 05            [24] 1545 	pop	ar5
      007F11 D0 06            [24] 1546 	pop	ar6
      007F13 D0 07            [24] 1547 	pop	ar7
      007F15 70 01            [24] 1548 	jnz	00102$
      007F17 22               [24] 1549 	ret
      007F18                       1550 00102$:
                                   1551 ;	quantum/action_util.c:189: if (pressed) {
      007F18 EA               [12] 1552 	mov	a,r2
      007F19 60 1B            [24] 1553 	jz	00115$
                                   1554 ;	quantum/action_util.c:190: if (usage_refs[index]++) return;
      007F1B 12 80 EA         [24] 1555 	lcall	_ak820_outline_0075
      007F1E 04               [12] 1556 	inc	a
      007F1F 12 6C 37         [24] 1557 	lcall	_ak820_outline_0139
      007F22 E8               [12] 1558 	mov	a,r0
      007F23 60 01            [24] 1559 	jz	00104$
      007F25 22               [24] 1560 	ret
      007F26                       1561 00104$:
                                   1562 ;	quantum/action_util.c:191: usage_order[base + count++] = index;
      007F26 90 0A 98         [24] 1563 	mov	dptr,#_owned_usage_key_count_10000_375
      007F29 EC               [12] 1564 	mov	a,r4
      007F2A 04               [12] 1565 	inc	a
      007F2B F0               [24] 1566 	movx	@dptr,a
      007F2C EC               [12] 1567 	mov	a,r4
      007F2D 2E               [12] 1568 	add	a, r6
      007F2E 12 80 E0         [24] 1569 	lcall	_ak820_outline_0067
      007F31 EB               [12] 1570 	mov	a,r3
      007F32 F0               [24] 1571 	movx	@dptr,a
      007F33 02 7F 97         [24] 1572 	ljmp	00116$
      007F36                       1573 00115$:
                                   1574 ;	quantum/action_util.c:193: if (!usage_refs[index] || --usage_refs[index]) return;
      007F36 12 80 EA         [24] 1575 	lcall	_ak820_outline_0075
      007F39 60 07            [24] 1576 	jz	00105$
      007F3B 18               [12] 1577 	dec	r0
      007F3C 12 80 D9         [24] 1578 	lcall	_ak820_outline_0062
      007F3F E8               [12] 1579 	mov	a,r0
      007F40 60 01            [24] 1580 	jz	00106$
      007F42                       1581 00105$:
      007F42 22               [24] 1582 	ret
      007F43                       1583 00106$:
                                   1584 ;	quantum/action_util.c:195: while (usage_order[base + pos] != index) ++pos;
      007F43 7A 00            [12] 1585 	mov	r2,#0x00
      007F45                       1586 00108$:
      007F45 EA               [12] 1587 	mov	a,r2
      007F46 2E               [12] 1588 	add	a, r6
      007F47 12 80 E0         [24] 1589 	lcall	_ak820_outline_0067
      007F4A E0               [24] 1590 	movx	a,@dptr
      007F4B B5 03 02         [24] 1591 	cjne	a,ar3,00251$
      007F4E 80 03            [24] 1592 	sjmp	00167$
      007F50                       1593 00251$:
      007F50 0A               [12] 1594 	inc	r2
      007F51 80 F2            [24] 1595 	sjmp	00108$
      007F53                       1596 00167$:
      007F53 90 0A 99         [24] 1597 	mov	dptr,#_owned_usage_key_pos_30001_382
      007F56 EA               [12] 1598 	mov	a,r2
      007F57 F0               [24] 1599 	movx	@dptr,a
                                   1600 ;	quantum/action_util.c:196: --count;
      007F58 1C               [12] 1601 	dec	r4
      007F59 90 0A 98         [24] 1602 	mov	dptr,#_owned_usage_key_count_10000_375
      007F5C EC               [12] 1603 	mov	a,r4
      007F5D F0               [24] 1604 	movx	@dptr,a
                                   1605 ;	quantum/action_util.c:197: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      007F5E 8A 03            [24] 1606 	mov	ar3,r2
      007F60                       1607 00125$:
      007F60 C3               [12] 1608 	clr	c
      007F61 EB               [12] 1609 	mov	a,r3
      007F62 9C               [12] 1610 	subb	a,r4
      007F63 50 23            [24] 1611 	jnc	00111$
      007F65 C0 05            [24] 1612 	push	ar5
      007F67 C0 07            [24] 1613 	push	ar7
      007F69 EB               [12] 1614 	mov	a,r3
      007F6A 2E               [12] 1615 	add	a, r6
      007F6B FA               [12] 1616 	mov	r2,a
      007F6C 24 6F            [12] 1617 	add	a, #_usage_order
      007F6E F8               [12] 1618 	mov	r0,a
      007F6F E4               [12] 1619 	clr	a
      007F70 34 0A            [12] 1620 	addc	a, #(_usage_order >> 8)
      007F72 F9               [12] 1621 	mov	r1,a
      007F73 0A               [12] 1622 	inc	r2
      007F74 EA               [12] 1623 	mov	a,r2
      007F75 33               [12] 1624 	rlc	a
      007F76 95 E0            [12] 1625 	subb	a,acc
      007F78 FF               [12] 1626 	mov	r7,a
      007F79 EA               [12] 1627 	mov	a,r2
      007F7A 12 81 06         [24] 1628 	lcall	_ak820_outline_0125
      007F7D 12 38 B6         [24] 1629 	lcall	_ak820_outline_0157
      007F80 F0               [24] 1630 	movx	@dptr,a
      007F81 0B               [12] 1631 	inc	r3
      007F82 D0 07            [24] 1632 	pop	ar7
      007F84 D0 05            [24] 1633 	pop	ar5
      007F86 80 D8            [24] 1634 	sjmp	00125$
      007F88                       1635 00111$:
                                   1636 ;	quantum/action_util.c:198: usage_lengths[which] = count;
      007F88 12 81 25         [24] 1637 	lcall	_ak820_outline_0189
      007F8B EC               [12] 1638 	mov	a,r4
      007F8C F0               [24] 1639 	movx	@dptr,a
                                   1640 ;	quantum/action_util.c:199: if (pos != count) return; /* A non-winning owner changed only storage. */
      007F8D 90 0A 99         [24] 1641 	mov	dptr,#_owned_usage_key_pos_30001_382
      007F90 E0               [24] 1642 	movx	a,@dptr
      007F91 B5 04 02         [24] 1643 	cjne	a,ar4,00253$
      007F94 80 01            [24] 1644 	sjmp	00116$
      007F96                       1645 00253$:
      007F96 22               [24] 1646 	ret
      007F97                       1647 00116$:
                                   1648 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      007F97 90 0A 98         [24] 1649 	mov	dptr,#_owned_usage_key_count_10000_375
      007F9A E0               [24] 1650 	movx	a,@dptr
      007F9B FC               [12] 1651 	mov	r4,a
      007F9C 12 81 25         [24] 1652 	lcall	_ak820_outline_0189
      007F9F F0               [24] 1653 	movx	@dptr,a
                                   1654 ;	quantum/action_util.c:202: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      007FA0 EC               [12] 1655 	mov	a,r4
      007FA1 60 15            [24] 1656 	jz	00131$
      007FA3 EC               [12] 1657 	mov	a,r4
      007FA4 2E               [12] 1658 	add	a, r6
      007FA5 FE               [12] 1659 	mov	r6,a
      007FA6 1E               [12] 1660 	dec	r6
      007FA7 EE               [12] 1661 	mov	a,r6
      007FA8 33               [12] 1662 	rlc	a
      007FA9 95 E0            [12] 1663 	subb	a,acc
      007FAB FF               [12] 1664 	mov	r7,a
      007FAC EE               [12] 1665 	mov	a,r6
      007FAD 12 81 06         [24] 1666 	lcall	_ak820_outline_0125
      007FB0 24 A5            [12] 1667 	add	a,#0xa5
      007FB2 FE               [12] 1668 	mov	r6,a
      007FB3 33               [12] 1669 	rlc	a
      007FB4 95 E0            [12] 1670 	subb	a,acc
      007FB6 80 02            [24] 1671 	sjmp	00132$
      007FB8                       1672 00131$:
      007FB8 7E 00            [12] 1673 	mov	r6,#0x00
      007FBA                       1674 00132$:
      007FBA 90 0A 94         [24] 1675 	mov	dptr,#_owned_usage_key_code_10000_374
      007FBD EE               [12] 1676 	mov	a,r6
      007FBE F0               [24] 1677 	movx	@dptr,a
                                   1678 ;	quantum/action_util.c:203: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      007FBF 90 0A 97         [24] 1679 	mov	dptr,#_owned_usage_key_which_10000_375
      007FC2 E0               [24] 1680 	movx	a,@dptr
      007FC3 60 18            [24] 1681 	jz	00118$
      007FC5 EE               [12] 1682 	mov	a,r6
      007FC6 60 0B            [24] 1683 	jz	00133$
      007FC8 8E 82            [24] 1684 	mov	dpl, r6
      007FCA 12 6D 77         [24] 1685 	lcall	_KEYCODE2CONSUMER
      007FCD AD 82            [24] 1686 	mov	r5, dpl
      007FCF AF 83            [24] 1687 	mov	r7, dph
      007FD1 80 04            [24] 1688 	sjmp	00134$
      007FD3                       1689 00133$:
      007FD3 7D 00            [12] 1690 	mov	r5,#0x00
      007FD5 7F 00            [12] 1691 	mov	r7,#0x00
      007FD7                       1692 00134$:
      007FD7 12 81 25         [24] 1693 	lcall	_ak820_outline_0189
      007FDA 02 6D 2A         [24] 1694 	ljmp	_host_consumer_send
      007FDD                       1695 00118$:
                                   1696 ;	quantum/action_util.c:204: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007FDD EE               [12] 1697 	mov	a,r6
      007FDE 60 22            [24] 1698 	jz	00135$
                                   1699 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      007FE0 BE A5 00         [24] 1700 	cjne	r6,#0xa5,00258$
      007FE3                       1701 00258$:
      007FE3 40 05            [24] 1702 	jc	00121$
      007FE5 EE               [12] 1703 	mov	a,r6
      007FE6 24 58            [12] 1704 	add	a,#0xff - 0xa7
      007FE8 50 08            [24] 1705 	jnc	00122$
                                   1706 ;	free result
      007FEA                       1707 00121$:
      007FEA 90 0A 95         [24] 1708 	mov	dptr,#_owned_usage_key___200000085_20000_375
      007FED 12 4F 53         [24] 1709 	lcall	_ak820_outline_0182
      007FF0 80 09            [24] 1710 	sjmp	00123$
      007FF2                       1711 00122$:
                                   1712 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      007FF2 74 DC            [12] 1713 	mov	a,#0xdc
      007FF4 2E               [12] 1714 	add	a, r6
      007FF5 90 0A 95         [24] 1715 	mov	dptr,#_owned_usage_key___200000085_20000_375
      007FF8 12 38 A1         [24] 1716 	lcall	_ak820_outline_0135
                                   1717 ;	quantum/action_util.c:204: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      007FFB                       1718 00123$:
      007FFB 90 0A 95         [24] 1719 	mov	dptr,#_owned_usage_key___200000085_20000_375
      007FFE E0               [24] 1720 	movx	a,@dptr
      007FFF FF               [12] 1721 	mov	r7,a
      008000 80 02            [24] 1722 	sjmp	00136$
      008002                       1723 00135$:
      008002 7F 00            [12] 1724 	mov	r7,#0x00
      008004                       1725 00136$:
      008004 7E 00            [12] 1726 	mov	r6,#0x00
      008006 12 43 6D         [24] 1727 	lcall	_ak820_outline_0158
                                   1728 ;	quantum/action_util.c:205: }
      008009 02 6C FA         [24] 1729 	ljmp	_host_system_send
                                   1730 ;------------------------------------------------------------
                                   1731 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1732 ;------------------------------------------------------------
                                   1733 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_395'
                                   1734 ;changed       Allocated with name '_send_keyboard_report_changed_10001_395'
                                   1735 ;dest          Allocated with name '_send_keyboard_report_dest_10001_395'
                                   1736 ;src           Allocated with name '_send_keyboard_report_src_10001_395'
                                   1737 ;i             Allocated with name '_send_keyboard_report_i_20001_396'
                                   1738 ;------------------------------------------------------------
                                   1739 ;	quantum/action_util.c:427: void send_keyboard_report(void) {
                                   1740 ;	-----------------------------------------
                                   1741 ;	 function send_keyboard_report
                                   1742 ;	-----------------------------------------
      00800C                       1743 _send_keyboard_report:
                                   1744 ;	quantum/action_util.c:428: keyboard_report->mods = real_mods;
      00800C 90 0D C3         [24] 1745 	mov	dptr,#_real_mods
      00800F E0               [24] 1746 	movx	a,@dptr
      008010 FF               [12] 1747 	mov	r7,a
      008011 90 0D C5         [24] 1748 	mov	dptr,#_actual_keyboard_report
      008014 F0               [24] 1749 	movx	@dptr,a
                                   1750 ;	quantum/action_util.c:429: keyboard_report->mods |= weak_mods;
      008015 90 0D C4         [24] 1751 	mov	dptr,#_weak_mods
      008018 E0               [24] 1752 	movx	a,@dptr
      008019 42 07            [12] 1753 	orl	ar7,a
      00801B 90 0D C5         [24] 1754 	mov	dptr,#_actual_keyboard_report
      00801E EF               [12] 1755 	mov	a,r7
      00801F F0               [24] 1756 	movx	@dptr,a
                                   1757 ;	quantum/action_util.c:431: keyboard_report->mods |= owned_mods | owned_weak_mods;
      008020 90 09 83         [24] 1758 	mov	dptr,#_owned_weak_mods
      008023 E0               [24] 1759 	movx	a,@dptr
      008024 FE               [12] 1760 	mov	r6,a
      008025 90 09 82         [24] 1761 	mov	dptr,#_owned_mods
      008028 E0               [24] 1762 	movx	a,@dptr
      008029 4E               [12] 1763 	orl	a,r6
      00802A 42 07            [12] 1764 	orl	ar7,a
      00802C 90 0D C5         [24] 1765 	mov	dptr,#_actual_keyboard_report
      00802F EF               [12] 1766 	mov	a,r7
      008030 F0               [24] 1767 	movx	@dptr,a
                                   1768 ;	quantum/action_util.c:468: if (gui_disabled) keyboard_report->mods &= ~(MOD_BIT(KC_LGUI) | MOD_BIT(KC_RGUI));
      008031 30 20 07         [24] 1769 	jnb	_gui_disabled,00102$
      008034 90 0D C5         [24] 1770 	mov	dptr,#_actual_keyboard_report
      008037 E0               [24] 1771 	movx	a,@dptr
      008038 54 77            [12] 1772 	anl	a,#0x77
      00803A F0               [24] 1773 	movx	@dptr,a
      00803B                       1774 00102$:
                                   1775 ;	quantum/action_util.c:479: bool changed = false;
      00803B 90 0A BB         [24] 1776 	mov	dptr,#_send_keyboard_report_changed_10001_395
      00803E E4               [12] 1777 	clr	a
      00803F F0               [24] 1778 	movx	@dptr,a
                                   1779 ;	quantum/action_util.c:481: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1780 ;	quantum/action_util.c:482: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1781 ;	quantum/action_util.c:487: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008040 FF               [12] 1782 	mov	r7,a
      008041                       1783 00109$:
      008041 BF 20 00         [24] 1784 	cjne	r7,#0x20,00150$
      008044                       1785 00150$:
      008044 50 2A            [24] 1786 	jnc	00105$
                                   1787 ;	quantum/action_util.c:488: if (dest[i] != src[i]) {
      008046 EF               [12] 1788 	mov	a,r7
      008047 24 9B            [12] 1789 	add	a, #_send_keyboard_report_last_report_10001_395
      008049 FD               [12] 1790 	mov	r5,a
      00804A E4               [12] 1791 	clr	a
      00804B 34 0A            [12] 1792 	addc	a, #(_send_keyboard_report_last_report_10001_395 >> 8)
      00804D 12 48 8B         [24] 1793 	lcall	_ak820_outline_0056
      008050 EF               [12] 1794 	mov	a,r7
      008051 24 C5            [12] 1795 	add	a, #_actual_keyboard_report
      008053 F5 82            [12] 1796 	mov	dpl,a
      008055 E4               [12] 1797 	clr	a
      008056 34 0D            [12] 1798 	addc	a, #(_actual_keyboard_report >> 8)
      008058 F5 83            [12] 1799 	mov	dph,a
      00805A E0               [24] 1800 	movx	a,@dptr
      00805B FB               [12] 1801 	mov	r3,a
      00805C EC               [12] 1802 	mov	a,r4
      00805D B5 03 02         [24] 1803 	cjne	a,ar3,00152$
      008060 80 0B            [24] 1804 	sjmp	00110$
      008062                       1805 00152$:
                                   1806 ;	quantum/action_util.c:489: dest[i] = src[i];
      008062 12 38 9C         [24] 1807 	lcall	_ak820_outline_0133
      008065 EB               [12] 1808 	mov	a,r3
      008066 F0               [24] 1809 	movx	@dptr,a
                                   1810 ;	quantum/action_util.c:490: changed = true;
      008067 90 0A BB         [24] 1811 	mov	dptr,#_send_keyboard_report_changed_10001_395
      00806A 74 01            [12] 1812 	mov	a,#0x01
      00806C F0               [24] 1813 	movx	@dptr,a
      00806D                       1814 00110$:
                                   1815 ;	quantum/action_util.c:487: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      00806D 0F               [12] 1816 	inc	r7
      00806E 80 D1            [24] 1817 	sjmp	00109$
      008070                       1818 00105$:
                                   1819 ;	quantum/action_util.c:493: if (changed) host_keyboard_send(keyboard_report);
      008070 90 0A BB         [24] 1820 	mov	dptr,#_send_keyboard_report_changed_10001_395
      008073 E0               [24] 1821 	movx	a,@dptr
      008074 60 09            [24] 1822 	jz	00111$
      008076 90 0D C5         [24] 1823 	mov	dptr,#_actual_keyboard_report
      008079 75 F0 00         [24] 1824 	mov	b, #0x00
                                   1825 ;	quantum/action_util.c:501: }
      00807C 02 6C 6F         [24] 1826 	ljmp	_host_keyboard_send
      00807F                       1827 00111$:
      00807F 22               [24] 1828 	ret
                                   1829 ;------------------------------------------------------------
                                   1830 ;Allocation info for local variables in function 'get_mods'
                                   1831 ;------------------------------------------------------------
                                   1832 ;	quantum/action_util.c:507: uint8_t get_mods(void) {
                                   1833 ;	-----------------------------------------
                                   1834 ;	 function get_mods
                                   1835 ;	-----------------------------------------
      008080                       1836 _get_mods:
      008080 C0 07            [24] 1837 	push	ar7
                                   1838 ;	quantum/action_util.c:512: ;
      008082 90 09 82         [24] 1839 	mov	dptr,#_owned_mods
      008085 E0               [24] 1840 	movx	a,@dptr
      008086 FF               [12] 1841 	mov	r7,a
      008087 90 0D C3         [24] 1842 	mov	dptr,#_real_mods
      00808A 12 7B 30         [24] 1843 	lcall	_ak820_outline_0141
                                   1844 ;	quantum/action_util.c:513: }
      00808D D0 07            [24] 1845 	pop	ar7
      00808F 22               [24] 1846 	ret
                                   1847 ;------------------------------------------------------------
                                   1848 ;Allocation info for local variables in function 'add_mods'
                                   1849 ;------------------------------------------------------------
                                   1850 ;mods          Allocated with name '_add_mods_mods_10000_403'
                                   1851 ;------------------------------------------------------------
                                   1852 ;	quantum/action_util.c:518: void add_mods(uint8_t mods) {
                                   1853 ;	-----------------------------------------
                                   1854 ;	 function clear_mods
                                   1855 ;	-----------------------------------------
      008090                       1856 _clear_mods:
                                   1857 ;	quantum/action_util.c:540: real_mods = 0;
      008090 90 0D C3         [24] 1858 	mov	dptr,#_real_mods
      008093 E4               [12] 1859 	clr	a
      008094 F0               [24] 1860 	movx	@dptr,a
                                   1861 ;	quantum/action_util.c:541: }
      008095 22               [24] 1862 	ret
                                   1863 ;------------------------------------------------------------
                                   1864 ;Allocation info for local variables in function 'get_weak_mods'
                                   1865 ;------------------------------------------------------------
                                   1866 ;	quantum/action_util.c:547: uint8_t get_weak_mods(void) {
                                   1867 ;	-----------------------------------------
                                   1868 ;	 function get_weak_mods
                                   1869 ;	-----------------------------------------
      008096                       1870 _get_weak_mods:
      008096 C0 07            [24] 1871 	push	ar7
                                   1872 ;	quantum/action_util.c:552: ;
      008098 90 09 83         [24] 1873 	mov	dptr,#_owned_weak_mods
      00809B E0               [24] 1874 	movx	a,@dptr
      00809C FF               [12] 1875 	mov	r7,a
      00809D 90 0D C4         [24] 1876 	mov	dptr,#_weak_mods
      0080A0 12 7B 30         [24] 1877 	lcall	_ak820_outline_0141
                                   1878 ;	quantum/action_util.c:553: }
      0080A3 D0 07            [24] 1879 	pop	ar7
      0080A5 22               [24] 1880 	ret
                                   1881 ;------------------------------------------------------------
                                   1882 ;Allocation info for local variables in function 'add_weak_mods'
                                   1883 ;------------------------------------------------------------
                                   1884 ;mods          Allocated with name '_add_weak_mods_mods_10000_413'
                                   1885 ;------------------------------------------------------------
                                   1886 ;	quantum/action_util.c:558: void add_weak_mods(uint8_t mods) {
                                   1887 ;	-----------------------------------------
                                   1888 ;	 function add_weak_mods
                                   1889 ;	-----------------------------------------
      0080A6                       1890 _add_weak_mods:
      0080A6 E5 82            [12] 1891 	mov	a,dpl
      0080A8 90 0A BC         [24] 1892 	mov	dptr,#_add_weak_mods_mods_10000_413
      0080AB F0               [24] 1893 	movx	@dptr,a
                                   1894 ;	quantum/action_util.c:559: weak_mods |= mods;
      0080AC E0               [24] 1895 	movx	a,@dptr
      0080AD FF               [12] 1896 	mov	r7,a
      0080AE 90 0D C4         [24] 1897 	mov	dptr,#_weak_mods
      0080B1 E0               [24] 1898 	movx	a,@dptr
      0080B2 4F               [12] 1899 	orl	a,r7
      0080B3 F0               [24] 1900 	movx	@dptr,a
                                   1901 ;	quantum/action_util.c:560: }
      0080B4 22               [24] 1902 	ret
                                   1903 ;------------------------------------------------------------
                                   1904 ;Allocation info for local variables in function 'del_weak_mods'
                                   1905 ;------------------------------------------------------------
                                   1906 ;mods          Allocated with name '_del_weak_mods_mods_10000_415'
                                   1907 ;------------------------------------------------------------
                                   1908 ;	quantum/action_util.c:565: void del_weak_mods(uint8_t mods) {
                                   1909 ;	-----------------------------------------
                                   1910 ;	 function del_weak_mods
                                   1911 ;	-----------------------------------------
      0080B5                       1912 _del_weak_mods:
      0080B5 E5 82            [12] 1913 	mov	a,dpl
      0080B7 90 0A BD         [24] 1914 	mov	dptr,#_del_weak_mods_mods_10000_415
      0080BA F0               [24] 1915 	movx	@dptr,a
                                   1916 ;	quantum/action_util.c:566: weak_mods &= ~mods;
      0080BB E0               [24] 1917 	movx	a,@dptr
      0080BC F4               [12] 1918 	cpl	a
      0080BD FF               [12] 1919 	mov	r7,a
      0080BE 90 0D C4         [24] 1920 	mov	dptr,#_weak_mods
      0080C1 E0               [24] 1921 	movx	a,@dptr
      0080C2 5F               [12] 1922 	anl	a,r7
      0080C3 F0               [24] 1923 	movx	@dptr,a
                                   1924 ;	quantum/action_util.c:567: }
      0080C4 22               [24] 1925 	ret
                                   1926 ;------------------------------------------------------------
                                   1927 ;Allocation info for local variables in function 'set_weak_mods'
                                   1928 ;------------------------------------------------------------
                                   1929 ;mods          Allocated with name '_set_weak_mods_mods_10000_417'
                                   1930 ;------------------------------------------------------------
                                   1931 ;	quantum/action_util.c:572: void set_weak_mods(uint8_t mods) {
                                   1932 ;	-----------------------------------------
                                   1933 ;	 function clear_weak_mods
                                   1934 ;	-----------------------------------------
      0080C5                       1935 _clear_weak_mods:
                                   1936 ;	quantum/action_util.c:580: weak_mods = 0;
      0080C5 90 0D C4         [24] 1937 	mov	dptr,#_weak_mods
      0080C8 E4               [12] 1938 	clr	a
      0080C9 F0               [24] 1939 	movx	@dptr,a
                                   1940 ;	quantum/action_util.c:581: }
      0080CA 22               [24] 1941 	ret
                                   1942 ;------------------------------------------------------------
                                   1943 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1944 ;------------------------------------------------------------
                                   1945 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_421'
                                   1946 ;------------------------------------------------------------
                                   1947 ;	quantum/action_util.c:663: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1948 ;	-----------------------------------------
                                   1949 	.area CSEG    (CODE)
                                   1950 	.area CONST   (CODE)
                                   1951 	.area XINIT   (CODE)
      00C149                       1952 __xinit__real_mods:
      00C149 00                    1953 	.db #0x00	; 0
      00C14A                       1954 __xinit__weak_mods:
      00C14A 00                    1955 	.db #0x00	; 0
      00C14B                       1956 __xinit__actual_keyboard_report:
      00C14B 00                    1957 	.db #0x00	; 0
      00C14C 00                    1958 	.db #0x00	; 0
      00C14D 00                    1959 	.db #0x00	; 0
      00C14E 00                    1960 	.db #0x00	; 0
      00C14F 00                    1961 	.db #0x00	; 0
      00C150 00                    1962 	.db #0x00	; 0
      00C151 00                    1963 	.db #0x00	; 0
      00C152 00                    1964 	.db #0x00	; 0
      00C153 00                    1965 	.db 0x00
      00C154 00                    1966 	.db 0x00
      00C155 00                    1967 	.db 0x00
      00C156 00                    1968 	.db 0x00
      00C157 00                    1969 	.db 0x00
      00C158 00                    1970 	.db 0x00
      00C159 00                    1971 	.db 0x00
      00C15A 00                    1972 	.db 0x00
      00C15B 00                    1973 	.db 0x00
      00C15C 00                    1974 	.db 0x00
      00C15D 00                    1975 	.db 0x00
      00C15E 00                    1976 	.db 0x00
      00C15F 00                    1977 	.db 0x00
      00C160 00                    1978 	.db 0x00
      00C161 00                    1979 	.db 0x00
      00C162 00                    1980 	.db 0x00
      00C163 00                    1981 	.db 0x00
      00C164 00                    1982 	.db 0x00
      00C165 00                    1983 	.db 0x00
      00C166 00                    1984 	.db 0x00
      00C167 00                    1985 	.db 0x00
      00C168 00                    1986 	.db 0x00
      00C169 00                    1987 	.db 0x00
      00C16A 00                    1988 	.db 0x00
                                   1989 	.area CABS    (ABS,CODE)
                                   1990 
                                   1991 ; Experimental exact instruction outlining.
                                   1992 	.globl _ak820_outline_0016
                                   1993 	.globl _ak820_outline_0030
                                   1994 	.globl _ak820_outline_0051
                                   1995 	.globl _ak820_outline_0056
                                   1996 	.globl _ak820_outline_0059
                                   1997 	.globl _ak820_outline_0061
                                   1998 	.globl _ak820_outline_0062
                                   1999 	.globl _ak820_outline_0063
                                   2000 	.globl _ak820_outline_0067
                                   2001 	.globl _ak820_outline_0075
                                   2002 	.globl _ak820_outline_0107
                                   2003 	.globl _ak820_outline_0108
                                   2004 	.globl _ak820_outline_0117
                                   2005 	.globl _ak820_outline_0121
                                   2006 	.globl _ak820_outline_0123
                                   2007 	.globl _ak820_outline_0125
                                   2008 	.globl _ak820_outline_0132
                                   2009 	.globl _ak820_outline_0133
                                   2010 	.globl _ak820_outline_0135
                                   2011 	.globl _ak820_outline_0139
                                   2012 	.globl _ak820_outline_0141
                                   2013 	.globl _ak820_outline_0157
                                   2014 	.globl _ak820_outline_0158
                                   2015 	.globl _ak820_outline_0163
                                   2016 	.globl _ak820_outline_0175
                                   2017 	.globl _ak820_outline_0182
                                   2018 	.globl _ak820_outline_0188
                                   2019 	.globl _ak820_outline_0189
                                   2020 
                                   2021 	.area CSEG (CODE)
                                   2022 ; function ak820_outline_0030
      0080CB                       2023 _ak820_outline_0030:
      0080CB EF               [12] 2024 	mov	a,r7
      0080CC 24 94            [12] 2025 	add	a,#_key_refs
      0080CE FD               [12] 2026 	mov	r5,a
      0080CF E4               [12] 2027 	clr	a
      0080D0 34 09            [12] 2028 	addc	a,#(_key_refs>>8)
      0080D2 FE               [12] 2029 	mov	r6,a
      0080D3 8D 82            [24] 2030 	mov	dpl,r5
      0080D5 8E 83            [24] 2031 	mov	dph,r6
      0080D7 E0               [24] 2032 	movx	a,@dptr
      0080D8 22               [24] 2033 	ret
                                   2034 
                                   2035 	.area CSEG (CODE)
                                   2036 ; function ak820_outline_0062
      0080D9                       2037 _ak820_outline_0062:
      0080D9 89 82            [24] 2038 	mov	dpl,r1
      0080DB 8A 83            [24] 2039 	mov	dph,r2
      0080DD E8               [12] 2040 	mov	a,r0
      0080DE F0               [24] 2041 	movx	@dptr,a
      0080DF 22               [24] 2042 	ret
                                   2043 
                                   2044 	.area CSEG (CODE)
                                   2045 ; function ak820_outline_0067
      0080E0                       2046 _ak820_outline_0067:
      0080E0 24 6F            [12] 2047 	add	a,#_usage_order
      0080E2 F5 82            [12] 2048 	mov	dpl,a
      0080E4 E4               [12] 2049 	clr	a
      0080E5 34 0A            [12] 2050 	addc	a,#(_usage_order>>8)
      0080E7 F5 83            [12] 2051 	mov	dph,a
      0080E9 22               [24] 2052 	ret
                                   2053 
                                   2054 	.area CSEG (CODE)
                                   2055 ; function ak820_outline_0075
      0080EA                       2056 _ak820_outline_0075:
      0080EA EB               [12] 2057 	mov	a,r3
      0080EB 24 51            [12] 2058 	add	a,#_usage_refs
      0080ED F9               [12] 2059 	mov	r1,a
      0080EE E4               [12] 2060 	clr	a
      0080EF 34 0A            [12] 2061 	addc	a,#(_usage_refs>>8)
      0080F1 FA               [12] 2062 	mov	r2,a
      0080F2 89 82            [24] 2063 	mov	dpl,r1
      0080F4 8A 83            [24] 2064 	mov	dph,r2
      0080F6 E0               [24] 2065 	movx	a,@dptr
      0080F7 F8               [12] 2066 	mov	r0,a
      0080F8 22               [24] 2067 	ret
                                   2068 
                                   2069 	.area CSEG (CODE)
                                   2070 ; function ak820_outline_0117
      0080F9                       2071 _ak820_outline_0117:
      0080F9 F0               [24] 2072 	movx	@dptr,a
      0080FA E0               [24] 2073 	movx	a,@dptr
      0080FB FF               [12] 2074 	mov	r7,a
      0080FC 90 09 8C         [24] 2075 	mov	dptr,#_change_owned_PARM_2
      0080FF 22               [24] 2076 	ret
                                   2077 
                                   2078 	.area CSEG (CODE)
                                   2079 ; function ak820_outline_0121
      008100                       2080 _ak820_outline_0121:
      008100 8D 82            [24] 2081 	mov	dpl,r5
      008102 8E 83            [24] 2082 	mov	dph,r6
      008104 F0               [24] 2083 	movx	@dptr,a
      008105 22               [24] 2084 	ret
                                   2085 
                                   2086 	.area CSEG (CODE)
                                   2087 ; function ak820_outline_0125
      008106                       2088 _ak820_outline_0125:
      008106 24 6F            [12] 2089 	add	a,#_usage_order
      008108 F5 82            [12] 2090 	mov	dpl,a
      00810A EF               [12] 2091 	mov	a,r7
      00810B 34 0A            [12] 2092 	addc	a,#(_usage_order>>8)
      00810D F5 83            [12] 2093 	mov	dph,a
      00810F E0               [24] 2094 	movx	a,@dptr
      008110 22               [24] 2095 	ret
                                   2096 
                                   2097 	.area CSEG (CODE)
                                   2098 ; function ak820_outline_0132
      008111                       2099 _ak820_outline_0132:
      008111 F0               [24] 2100 	movx	@dptr,a
      008112 E0               [24] 2101 	movx	a,@dptr
      008113 FF               [12] 2102 	mov	r7,a
      008114 90 09 88         [24] 2103 	mov	dptr,#_ak820_macro_change_PARM_2
      008117 F0               [24] 2104 	movx	@dptr,a
      008118 90 09 89         [24] 2105 	mov	dptr,#_ak820_macro_change_PARM_3
      00811B 22               [24] 2106 	ret
                                   2107 
                                   2108 	.area CSEG (CODE)
                                   2109 ; function ak820_outline_0175
      00811C                       2110 _ak820_outline_0175:
      00811C 90 07 FF         [24] 2111 	mov	dptr,#_add_key_to_report_PARM_2
      00811F EF               [12] 2112 	mov	a,r7
      008120 F0               [24] 2113 	movx	@dptr,a
      008121 90 0D C5         [24] 2114 	mov	dptr,#_actual_keyboard_report
      008124 22               [24] 2115 	ret
                                   2116 
                                   2117 	.area CSEG (CODE)
                                   2118 ; function ak820_outline_0189
      008125                       2119 _ak820_outline_0189:
      008125 8D 82            [24] 2120 	mov	dpl,r5
      008127 8F 83            [24] 2121 	mov	dph,r7
      008129 22               [24] 2122 	ret
