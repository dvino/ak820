                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000C8C                        569 _g_direct_mode_colors::
      000C8C                        570 	.ds 246
      000D82                        571 _get_supported_PARM_2:
      000D82                        572 	.ds 1
      000D83                        573 _get_supported_args_10000_255:
      000D83                        574 	.ds 2
      000D85                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000D85                        576 	.ds 2
      000D87                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000D87                        578 	.ds 2
      000D89                        579 _set_mode_mode_10000_275:
      000D89                        580 	.ds 2
      000D8B                        581 _get_matrix_pos_for_led_PARM_2:
      000D8B                        582 	.ds 2
      000D8D                        583 _get_matrix_pos_for_led_led_10000_280:
      000D8D                        584 	.ds 2
      000D8F                        585 _fast_set_leds_PARM_2:
      000D8F                        586 	.ds 1
      000D90                        587 _fast_set_leds_args_10000_282:
      000D90                        588 	.ds 2
      000D92                        589 _fast_set_leds_first_index_10001_285:
      000D92                        590 	.ds 2
      000D94                        591 _fast_set_leds_num_leds_10001_285:
      000D94                        592 	.ds 1
      000D95                        593 _vialrgb_get_value_PARM_2:
      000D95                        594 	.ds 1
      000D96                        595 _vialrgb_get_value_data_10000_291:
      000D96                        596 	.ds 3
      000D99                        597 _vialrgb_set_value_PARM_2:
      000D99                        598 	.ds 1
      000D9A                        599 _vialrgb_set_value_data_10000_302:
      000D9A                        600 	.ds 3
      000D9D                        601 _vialrgb_save_PARM_2:
      000D9D                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B2CE                        654 _get_supported:
      00B2CE 12 38 82         [24]  655 	lcall	_ak820_outline_0107
      00B2D1 90 0D 83         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B2D4 12 38 87         [24]  657 	lcall	_ak820_outline_0108
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B2D7 90 0D 83         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B2DA 12 37 F4         [24]  660 	lcall	_ak820_outline_0005
      00B2DD E0               [24]  661 	movx	a,@dptr
      00B2DE FD               [12]  662 	mov	r5,a
      00B2DF 7C 00            [12]  663 	mov	r4,#0x00
      00B2E1 12 38 8C         [24]  664 	lcall	_ak820_outline_0118
      00B2E4 A3               [24]  665 	inc	dptr
      00B2E5 E0               [24]  666 	movx	a,@dptr
      00B2E6 FA               [12]  667 	mov	r2,a
      00B2E7 E4               [12]  668 	clr	a
      00B2E8 12 43 62         [24]  669 	lcall	_ak820_outline_0142
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B2EB 90 0D 82         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00B2EE E0               [24]  672 	movx	a,@dptr
      00B2EF FB               [12]  673 	mov	r3,a
      00B2F0 7A 00            [12]  674 	mov	r2,#0x00
      00B2F2                        675 00107$:
      00B2F2 C3               [12]  676 	clr	c
      00B2F3 EA               [12]  677 	mov	a,r2
      00B2F4 9B               [12]  678 	subb	a,r3
      00B2F5 50 0A            [24]  679 	jnc	00101$
      00B2F7 EA               [12]  680 	mov	a,r2
      00B2F8 12 38 31         [24]  681 	lcall	_ak820_outline_0021
      00B2FB 74 FF            [12]  682 	mov	a,#0xff
      00B2FD F0               [24]  683 	movx	@dptr,a
      00B2FE 0A               [12]  684 	inc	r2
      00B2FF 80 F1            [24]  685 	sjmp	00107$
      00B301                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B301 8D 06            [24]  688 	mov	ar6,r5
      00B303 8C 07            [24]  689 	mov	ar7,r4
      00B305 8B 05            [24]  690 	mov	ar5,r3
      00B307 90 0D 83         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00B30A 12 38 91         [24]  692 	lcall	_ak820_outline_0122
      00B30D 7A 00            [12]  693 	mov	r2,#0x00
      00B30F                        694 00110$:
      00B30F BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00B312                        696 00159$:
      00B312 50 46            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B314 EA               [12]  699 	mov	a,r2
      00B315 75 F0 02         [24]  700 	mov	b,#0x02
      00B318 A4               [48]  701 	mul	ab
      00B319 24 78            [12]  702 	add	a, #_supported_modes
      00B31B F5 82            [12]  703 	mov	dpl,a
      00B31D 74 BF            [12]  704 	mov	a,#(_supported_modes >> 8)
      00B31F 12 57 17         [24]  705 	lcall	_ak820_outline_0109
      00B322 F8               [12]  706 	mov	r0,a
      00B323 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B325 C3               [12]  709 	clr	c
      00B326 EE               [12]  710 	mov	a,r6
      00B327 98               [12]  711 	subb	a,r0
      00B328 EF               [12]  712 	mov	a,r7
      00B329 99               [12]  713 	subb	a,r1
      00B32A 50 2B            [24]  714 	jnc	00111$
                                    715 ;	free result
      00B32C BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00B32F                        717 00162$:
      00B32F 40 26            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00B331 C0 06            [24]  720 	push	ar6
      00B333 C0 07            [24]  721 	push	ar7
      00B335 88 07            [24]  722 	mov	ar7,r0
      00B337 12 33 FC         [24]  723 	lcall	_ak820_outline_0123
      00B33A EF               [12]  724 	mov	a,r7
      00B33B F0               [24]  725 	movx	@dptr,a
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B33C 12 33 FC         [24]  727 	lcall	_ak820_outline_0123
      00B33F A3               [24]  728 	inc	dptr
      00B340 89 00            [24]  729 	mov	ar0,r1
      00B342 E8               [12]  730 	mov	a,r0
      00B343 F0               [24]  731 	movx	@dptr,a
                                    732 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B344 1D               [12]  733 	dec	r5
      00B345 1D               [12]  734 	dec	r5
                                    735 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B346 74 02            [12]  736 	mov	a,#0x02
      00B348 2B               [12]  737 	add	a, r3
      00B349 FB               [12]  738 	mov	r3,a
      00B34A E4               [12]  739 	clr	a
      00B34B 3C               [12]  740 	addc	a, r4
      00B34C FC               [12]  741 	mov	r4,a
      00B34D 90 0D 83         [24]  742 	mov	dptr,#_get_supported_args_10000_255
      00B350 12 38 64         [24]  743 	lcall	_ak820_outline_0083
                                    744 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B353 D0 07            [24]  745 	pop	ar7
      00B355 D0 06            [24]  746 	pop	ar6
                                    747 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B357                        748 00111$:
                                    749 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B357 0A               [12]  750 	inc	r2
      00B358 80 B5            [24]  751 	sjmp	00110$
      00B35A                        752 00127$:
      00B35A 90 0D 83         [24]  753 	mov	dptr,#_get_supported_args_10000_255
      00B35D 12 38 64         [24]  754 	lcall	_ak820_outline_0083
                                    755 ;	quantum/vialrgb.c:55: }
      00B360 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    759 ;------------------------------------------------------------
                                    760 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    761 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    762 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    763 ;------------------------------------------------------------
                                    764 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function qmk_id_to_vialrgb_id
                                    767 ;	-----------------------------------------
      00B361                        768 _qmk_id_to_vialrgb_id:
      00B361 12 38 82         [24]  769 	lcall	_ak820_outline_0107
      00B364 90 0D 85         [24]  770 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B367 12 38 87         [24]  771 	lcall	_ak820_outline_0108
                                    772 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B36A 90 0D 85         [24]  773 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B36D 12 38 41         [24]  774 	lcall	_ak820_outline_0051
      00B370 7D 00            [12]  775 	mov	r5,#0x00
      00B372                        776 00105$:
      00B372 BD 07 00         [24]  777 	cjne	r5,#0x07,00130$
      00B375                        778 00130$:
      00B375 50 19            [24]  779 	jnc	00103$
                                    780 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B377 12 B7 97         [24]  781 	lcall	_ak820_outline_0047
      00B37A A3               [24]  782 	inc	dptr
      00B37B E4               [12]  783 	clr	a
      00B37C 93               [24]  784 	movc	a,@a+dptr
                                    785 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B37D 7A 00            [12]  786 	mov	r2,#0x00
      00B37F B5 06 0B         [24]  787 	cjne	a,ar6,00106$
      00B382 EA               [12]  788 	mov	a,r2
      00B383 B5 07 07         [24]  789 	cjne	a,ar7,00106$
                                    790 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B386 12 33 FC         [24]  791 	lcall	_ak820_outline_0123
      00B389 12 B7 C3         [24]  792 	lcall	_ak820_outline_0144
      00B38C 22               [24]  793 	ret
      00B38D                        794 00106$:
                                    795 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B38D 0D               [12]  796 	inc	r5
      00B38E 80 E2            [24]  797 	sjmp	00105$
      00B390                        798 00103$:
                                    799 ;	quantum/vialrgb.c:63: return 0;
      00B390 90 00 00         [24]  800 	mov	dptr,#0x0000
                                    801 ;	quantum/vialrgb.c:64: }
      00B393 22               [24]  802 	ret
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    805 ;------------------------------------------------------------
                                    806 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    807 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    808 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    809 ;------------------------------------------------------------
                                    810 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    811 ;	-----------------------------------------
                                    812 ;	 function vialrgb_id_to_qmk_id
                                    813 ;	-----------------------------------------
      00B394                        814 _vialrgb_id_to_qmk_id:
      00B394 12 38 82         [24]  815 	lcall	_ak820_outline_0107
      00B397 90 0D 87         [24]  816 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B39A 12 38 87         [24]  817 	lcall	_ak820_outline_0108
                                    818 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B39D 90 0D 87         [24]  819 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B3A0 12 38 41         [24]  820 	lcall	_ak820_outline_0051
      00B3A3 7D 00            [12]  821 	mov	r5,#0x00
      00B3A5                        822 00105$:
      00B3A5 BD 07 00         [24]  823 	cjne	r5,#0x07,00130$
      00B3A8                        824 00130$:
      00B3A8 50 19            [24]  825 	jnc	00103$
                                    826 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B3AA 12 B7 97         [24]  827 	lcall	_ak820_outline_0047
      00B3AD E4               [12]  828 	clr	a
      00B3AE 93               [24]  829 	movc	a,@a+dptr
                                    830 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B3AF 7A 00            [12]  831 	mov	r2,#0x00
      00B3B1 B5 06 0C         [24]  832 	cjne	a,ar6,00106$
      00B3B4 EA               [12]  833 	mov	a,r2
      00B3B5 B5 07 08         [24]  834 	cjne	a,ar7,00106$
                                    835 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B3B8 12 33 FC         [24]  836 	lcall	_ak820_outline_0123
      00B3BB A3               [24]  837 	inc	dptr
      00B3BC 12 B7 C3         [24]  838 	lcall	_ak820_outline_0144
      00B3BF 22               [24]  839 	ret
      00B3C0                        840 00106$:
                                    841 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B3C0 0D               [12]  842 	inc	r5
      00B3C1 80 E2            [24]  843 	sjmp	00105$
      00B3C3                        844 00103$:
                                    845 ;	quantum/vialrgb.c:72: return 0;
      00B3C3 90 00 00         [24]  846 	mov	dptr,#0x0000
                                    847 ;	quantum/vialrgb.c:73: }
      00B3C6 22               [24]  848 	ret
                                    849 ;------------------------------------------------------------
                                    850 ;Allocation info for local variables in function 'get_mode'
                                    851 ;------------------------------------------------------------
                                    852 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    853 ;	-----------------------------------------
                                    854 ;	 function get_mode
                                    855 ;	-----------------------------------------
      00B3C7                        856 _get_mode:
                                    857 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B3C7 12 54 FD         [24]  858 	lcall	_rgb_matrix_is_enabled
      00B3CA E5 82            [12]  859 	mov	a, dpl
      00B3CC 70 04            [24]  860 	jnz	00102$
                                    861 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B3CE 90 00 00         [24]  862 	mov	dptr,#0x0000
      00B3D1 22               [24]  863 	ret
      00B3D2                        864 00102$:
                                    865 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B3D2 12 55 03         [24]  866 	lcall	_rgb_matrix_get_mode
      00B3D5 7E 00            [12]  867 	mov	r6,#0x00
      00B3D7 8E 83            [24]  868 	mov	dph, r6
                                    869 ;	quantum/vialrgb.c:80: }
      00B3D9 02 B3 61         [24]  870 	ljmp	_qmk_id_to_vialrgb_id
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'set_mode'
                                    873 ;------------------------------------------------------------
                                    874 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    875 ;------------------------------------------------------------
                                    876 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    877 ;	-----------------------------------------
                                    878 ;	 function set_mode
                                    879 ;	-----------------------------------------
      00B3DC                        880 _set_mode:
      00B3DC 12 38 82         [24]  881 	lcall	_ak820_outline_0107
      00B3DF 90 0D 89         [24]  882 	mov	dptr,#_set_mode_mode_10000_275
      00B3E2 12 38 87         [24]  883 	lcall	_ak820_outline_0108
                                    884 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B3E5 90 0D 89         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00B3E8 12 38 41         [24]  886 	lcall	_ak820_outline_0051
      00B3EB 90 0D 89         [24]  887 	mov	dptr,#_set_mode_mode_10000_275
      00B3EE 12 6D 68         [24]  888 	lcall	_ak820_outline_0040
      00B3F1 70 03            [24]  889 	jnz	00102$
                                    890 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B3F3 02 55 50         [24]  891 	ljmp	_rgb_matrix_disable_noeeprom
      00B3F6                        892 00102$:
                                    893 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B3F6 C0 07            [24]  894 	push	ar7
      00B3F8 C0 06            [24]  895 	push	ar6
      00B3FA 12 55 3F         [24]  896 	lcall	_rgb_matrix_enable_noeeprom
      00B3FD D0 06            [24]  897 	pop	ar6
      00B3FF D0 07            [24]  898 	pop	ar7
                                    899 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B401 12 38 8C         [24]  900 	lcall	_ak820_outline_0118
      00B404 12 B3 94         [24]  901 	lcall	_vialrgb_id_to_qmk_id
                                    902 ;	quantum/vialrgb.c:90: }
      00B407 02 55 59         [24]  903 	ljmp	_rgb_matrix_mode_noeeprom
                                    904 ;------------------------------------------------------------
                                    905 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    906 ;------------------------------------------------------------
                                    907 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    908 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    909 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    910 ;------------------------------------------------------------
                                    911 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    912 ;	-----------------------------------------
                                    913 ;	 function get_matrix_pos_for_led
                                    914 ;	-----------------------------------------
      00B40A                        915 _get_matrix_pos_for_led:
      00B40A 12 38 82         [24]  916 	lcall	_ak820_outline_0107
      00B40D 90 0D 8D         [24]  917 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B410 12 38 87         [24]  918 	lcall	_ak820_outline_0108
                                    919 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B413 90 0D 8D         [24]  920 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B416 12 38 41         [24]  921 	lcall	_ak820_outline_0051
      00B419 EE               [12]  922 	mov	a,r6
      00B41A 24 7F            [12]  923 	add	a, #_ak820_rgb_slots
      00B41C F5 82            [12]  924 	mov	dpl,a
      00B41E EF               [12]  925 	mov	a,r7
      00B41F 34 B9            [12]  926 	addc	a, #(_ak820_rgb_slots >> 8)
      00B421 F5 83            [12]  927 	mov	dph,a
      00B423 E4               [12]  928 	clr	a
      00B424 93               [24]  929 	movc	a,@a+dptr
      00B425 FF               [12]  930 	mov	r7,a
                                    931 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B426 90 0D 8B         [24]  932 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B429 12 38 6A         [24]  933 	lcall	_ak820_outline_0084
      00B42C EF               [12]  934 	mov	a,r7
      00B42D 12 57 4D         [24]  935 	lcall	_ak820_outline_0188
      00B430 12 81 00         [24]  936 	lcall	_ak820_outline_0121
                                    937 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B433 12 38 9C         [24]  938 	lcall	_ak820_outline_0133
      00B436 A3               [24]  939 	inc	dptr
      00B437 53 07 07         [24]  940 	anl	ar7,#0x07
      00B43A EF               [12]  941 	mov	a,r7
      00B43B F0               [24]  942 	movx	@dptr,a
                                    943 ;	quantum/vialrgb.c:110: }
      00B43C 22               [24]  944 	ret
                                    945 ;------------------------------------------------------------
                                    946 ;Allocation info for local variables in function 'fast_set_leds'
                                    947 ;------------------------------------------------------------
                                    948 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    949 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    950 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    951 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    952 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    953 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    954 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    955 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    956 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function fast_set_leds
                                    961 ;	-----------------------------------------
      00B43D                        962 _fast_set_leds:
      00B43D 12 38 82         [24]  963 	lcall	_ak820_outline_0107
      00B440 90 0D 90         [24]  964 	mov	dptr,#_fast_set_leds_args_10000_282
      00B443 12 38 87         [24]  965 	lcall	_ak820_outline_0108
                                    966 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B446 90 0D 8F         [24]  967 	mov	dptr,#_fast_set_leds_PARM_2
      00B449 E0               [24]  968 	movx	a,@dptr
      00B44A FF               [12]  969 	mov	r7,a
      00B44B BF 03 00         [24]  970 	cjne	r7,#0x03,00159$
      00B44E                        971 00159$:
      00B44E 50 01            [24]  972 	jnc	00102$
      00B450 22               [24]  973 	ret
      00B451                        974 00102$:
                                    975 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B451 90 0D 90         [24]  976 	mov	dptr,#_fast_set_leds_args_10000_282
      00B454 E0               [24]  977 	movx	a,@dptr
      00B455 FD               [12]  978 	mov	r5,a
      00B456 A3               [24]  979 	inc	dptr
      00B457 E0               [24]  980 	movx	a,@dptr
      00B458 12 48 8B         [24]  981 	lcall	_ak820_outline_0056
      00B45B 7B 00            [12]  982 	mov	r3,#0x00
      00B45D 12 38 9C         [24]  983 	lcall	_ak820_outline_0133
      00B460 A3               [24]  984 	inc	dptr
      00B461 E0               [24]  985 	movx	a,@dptr
      00B462 FA               [12]  986 	mov	r2,a
      00B463 79 00            [12]  987 	mov	r1,#0x00
      00B465 90 0D 92         [24]  988 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B468 E9               [12]  989 	mov	a,r1
      00B469 4C               [12]  990 	orl	a,r4
      00B46A F0               [24]  991 	movx	@dptr,a
      00B46B EA               [12]  992 	mov	a,r2
      00B46C 4B               [12]  993 	orl	a,r3
      00B46D A3               [24]  994 	inc	dptr
      00B46E F0               [24]  995 	movx	@dptr,a
                                    996 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B46F 12 38 9C         [24]  997 	lcall	_ak820_outline_0133
      00B472 A3               [24]  998 	inc	dptr
      00B473 A3               [24]  999 	inc	dptr
      00B474 E0               [24] 1000 	movx	a,@dptr
      00B475 90 0D 94         [24] 1001 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B478 F0               [24] 1002 	movx	@dptr,a
                                   1003 ;	quantum/vialrgb.c:119: length -= 3;
      00B479 EF               [12] 1004 	mov	a,r7
      00B47A 24 FD            [12] 1005 	add	a,#0xfd
      00B47C 90 0D 8F         [24] 1006 	mov	dptr,#_fast_set_leds_PARM_2
      00B47F F0               [24] 1007 	movx	@dptr,a
                                   1008 ;	quantum/vialrgb.c:120: args += 3;
      00B480 90 0D 90         [24] 1009 	mov	dptr,#_fast_set_leds_args_10000_282
      00B483 74 03            [12] 1010 	mov	a,#0x03
      00B485 2D               [12] 1011 	add	a, r5
      00B486 F0               [24] 1012 	movx	@dptr,a
      00B487 E4               [12] 1013 	clr	a
      00B488 3E               [12] 1014 	addc	a, r6
      00B489 A3               [24] 1015 	inc	dptr
      00B48A F0               [24] 1016 	movx	@dptr,a
                                   1017 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B48B 90 0D 94         [24] 1018 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B48E E0               [24] 1019 	movx	a,@dptr
      00B48F FF               [12] 1020 	mov	r7,a
      00B490 75 F0 03         [24] 1021 	mov	b,#0x03
      00B493 A4               [48] 1022 	mul	ab
      00B494 FE               [12] 1023 	mov	r6,a
      00B495 AD F0            [24] 1024 	mov	r5,b
      00B497 90 0D 8F         [24] 1025 	mov	dptr,#_fast_set_leds_PARM_2
      00B49A E0               [24] 1026 	movx	a,@dptr
      00B49B FB               [12] 1027 	mov	r3,a
      00B49C 7C 00            [12] 1028 	mov	r4,#0x00
      00B49E C3               [12] 1029 	clr	c
      00B49F EB               [12] 1030 	mov	a,r3
      00B4A0 9E               [12] 1031 	subb	a,r6
      00B4A1 EC               [12] 1032 	mov	a,r4
      00B4A2 9D               [12] 1033 	subb	a,r5
      00B4A3 40 13            [24] 1034 	jc	00103$
                                   1035 ;	free result
      00B4A5 90 0D 92         [24] 1036 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B4A8 12 38 6A         [24] 1037 	lcall	_ak820_outline_0084
      00B4AB 8D 03            [24] 1038 	mov	ar3,r5
      00B4AD 8E 04            [24] 1039 	mov	ar4,r6
      00B4AF C3               [12] 1040 	clr	c
      00B4B0 EB               [12] 1041 	mov	a,r3
      00B4B1 94 52            [12] 1042 	subb	a,#0x52
      00B4B3 EC               [12] 1043 	mov	a,r4
      00B4B4 94 00            [12] 1044 	subb	a,#0x00
      00B4B6 40 01            [24] 1045 	jc	00104$
      00B4B8                       1046 00103$:
      00B4B8 22               [24] 1047 	ret
      00B4B9                       1048 00104$:
                                   1049 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B4B9 74 52            [12] 1050 	mov	a,#0x52
      00B4BB C3               [12] 1051 	clr	c
      00B4BC 9D               [12] 1052 	subb	a,r5
      00B4BD FB               [12] 1053 	mov	r3,a
      00B4BE E4               [12] 1054 	clr	a
      00B4BF 9E               [12] 1055 	subb	a,r6
      00B4C0 FC               [12] 1056 	mov	r4,a
      00B4C1 7A 00            [12] 1057 	mov	r2,#0x00
      00B4C3 C3               [12] 1058 	clr	c
      00B4C4 EB               [12] 1059 	mov	a,r3
      00B4C5 9F               [12] 1060 	subb	a,r7
      00B4C6 EC               [12] 1061 	mov	a,r4
      00B4C7 9A               [12] 1062 	subb	a,r2
      00B4C8 50 08            [24] 1063 	jnc	00127$
                                   1064 ;	free result
      00B4CA 90 0D 94         [24] 1065 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B4CD 74 52            [12] 1066 	mov	a,#0x52
      00B4CF C3               [12] 1067 	clr	c
      00B4D0 9D               [12] 1068 	subb	a,r5
      00B4D1 F0               [24] 1069 	movx	@dptr,a
                                   1070 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B4D2                       1071 00127$:
      00B4D2 90 0D 94         [24] 1072 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B4D5 E0               [24] 1073 	movx	a,@dptr
      00B4D6 FF               [12] 1074 	mov	r7,a
      00B4D7 90 0D 92         [24] 1075 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B4DA 12 38 6A         [24] 1076 	lcall	_ak820_outline_0084
      00B4DD 7C 00            [12] 1077 	mov	r4,#0x00
      00B4DF                       1078 00110$:
      00B4DF C3               [12] 1079 	clr	c
      00B4E0 EC               [12] 1080 	mov	a,r4
      00B4E1 9F               [12] 1081 	subb	a,r7
      00B4E2 40 01            [24] 1082 	jc	00164$
      00B4E4 22               [24] 1083 	ret
      00B4E5                       1084 00164$:
                                   1085 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B4E5 C0 07            [24] 1086 	push	ar7
      00B4E7 90 0D AC         [24] 1087 	mov	dptr,#__mulint_PARM_2
      00B4EA 12 43 78         [24] 1088 	lcall	_ak820_outline_0162
      00B4ED 90 00 03         [24] 1089 	mov	dptr,#0x0003
      00B4F0 C0 07            [24] 1090 	push	ar7
      00B4F2 C0 06            [24] 1091 	push	ar6
      00B4F4 C0 05            [24] 1092 	push	ar5
      00B4F6 C0 04            [24] 1093 	push	ar4
      00B4F8 12 B9 2F         [24] 1094 	lcall	__mulint
      00B4FB AA 82            [24] 1095 	mov	r2, dpl
      00B4FD AB 83            [24] 1096 	mov	r3, dph
      00B4FF D0 04            [24] 1097 	pop	ar4
      00B501 D0 05            [24] 1098 	pop	ar5
      00B503 D0 06            [24] 1099 	pop	ar6
      00B505 D0 07            [24] 1100 	pop	ar7
      00B507 0D               [12] 1101 	inc	r5
      00B508 BD 00 01         [24] 1102 	cjne	r5,#0x00,00165$
      00B50B 0E               [12] 1103 	inc	r6
      00B50C                       1104 00165$:
      00B50C EA               [12] 1105 	mov	a,r2
      00B50D 24 8C            [12] 1106 	add	a, #_g_direct_mode_colors
      00B50F FA               [12] 1107 	mov	r2,a
      00B510 EB               [12] 1108 	mov	a,r3
      00B511 34 0C            [12] 1109 	addc	a, #(_g_direct_mode_colors >> 8)
      00B513 FB               [12] 1110 	mov	r3,a
                                   1111 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B514 8A 4A            [24] 1112 	mov	_fast_set_leds_sloc0_1_0,r2
      00B516 8B 4B            [24] 1113 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B518 12 B7 A9         [24] 1114 	lcall	_ak820_outline_0082
      00B51B F8               [12] 1115 	mov	r0,a
      00B51C 12 B7 B7         [24] 1116 	lcall	_ak820_outline_0106
      00B51F 85 4A 82         [24] 1117 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B522 85 4B 83         [24] 1118 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B525 E8               [12] 1119 	mov	a,r0
      00B526 F0               [24] 1120 	movx	@dptr,a
                                   1121 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B527 74 01            [12] 1122 	mov	a,#0x01
      00B529 2A               [12] 1123 	add	a, r2
      00B52A F5 4A            [12] 1124 	mov	_fast_set_leds_sloc0_1_0,a
      00B52C E4               [12] 1125 	clr	a
      00B52D 3B               [12] 1126 	addc	a, r3
      00B52E F5 4B            [12] 1127 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B530 90 0D 90         [24] 1128 	mov	dptr,#_fast_set_leds_args_10000_282
      00B533 E0               [24] 1129 	movx	a,@dptr
      00B534 F8               [12] 1130 	mov	r0,a
      00B535 A3               [24] 1131 	inc	dptr
      00B536 E0               [24] 1132 	movx	a,@dptr
      00B537 FF               [12] 1133 	mov	r7,a
      00B538 88 82            [24] 1134 	mov	dpl,r0
      00B53A 8F 83            [24] 1135 	mov	dph,r7
      00B53C E0               [24] 1136 	movx	a,@dptr
      00B53D F9               [12] 1137 	mov	r1,a
      00B53E 90 0D 90         [24] 1138 	mov	dptr,#_fast_set_leds_args_10000_282
      00B541 74 01            [12] 1139 	mov	a,#0x01
      00B543 28               [12] 1140 	add	a, r0
      00B544 F0               [24] 1141 	movx	@dptr,a
      00B545 E4               [12] 1142 	clr	a
      00B546 3F               [12] 1143 	addc	a, r7
      00B547 A3               [24] 1144 	inc	dptr
      00B548 F0               [24] 1145 	movx	@dptr,a
      00B549 85 4A 82         [24] 1146 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B54C 85 4B 83         [24] 1147 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B54F E9               [12] 1148 	mov	a,r1
      00B550 F0               [24] 1149 	movx	@dptr,a
                                   1150 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B551 12 B7 A9         [24] 1151 	lcall	_ak820_outline_0082
      00B554 F5 4A            [12] 1152 	mov	_fast_set_leds_sloc0_1_0,a
      00B556 12 B7 B7         [24] 1153 	lcall	_ak820_outline_0106
                                   1154 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B559 74 02            [12] 1155 	mov	a,#0x02
      00B55B 2A               [12] 1156 	add	a, r2
      00B55C F5 4C            [12] 1157 	mov	_fast_set_leds_sloc1_1_0,a
      00B55E E4               [12] 1158 	clr	a
      00B55F 3B               [12] 1159 	addc	a, r3
      00B560 F5 4D            [12] 1160 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B562 C3               [12] 1161 	clr	c
      00B563 74 A0            [12] 1162 	mov	a,#0xa0
      00B565 95 4A            [12] 1163 	subb	a,_fast_set_leds_sloc0_1_0
      00B567 D0 07            [24] 1164 	pop	ar7
      00B569 50 04            [24] 1165 	jnc	00114$
                                   1166 ;	free result
      00B56B 7B A0            [12] 1167 	mov	r3,#0xa0
      00B56D 80 04            [24] 1168 	sjmp	00115$
      00B56F                       1169 00114$:
      00B56F AA 4A            [24] 1170 	mov	r2,_fast_set_leds_sloc0_1_0
      00B571 8A 03            [24] 1171 	mov	ar3,r2
      00B573                       1172 00115$:
      00B573 85 4C 82         [24] 1173 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B576 85 4D 83         [24] 1174 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B579 EB               [12] 1175 	mov	a,r3
      00B57A F0               [24] 1176 	movx	@dptr,a
                                   1177 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B57B 0C               [12] 1178 	inc	r4
                                   1179 ;	quantum/vialrgb.c:133: }
      00B57C 02 B4 DF         [24] 1180 	ljmp	00110$
                                   1181 ;------------------------------------------------------------
                                   1182 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1183 ;------------------------------------------------------------
                                   1184 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1185 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1186 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1187 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1188 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1189 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1190 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1191 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1192 ;------------------------------------------------------------
                                   1193 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1194 ;	-----------------------------------------
                                   1195 ;	 function vialrgb_get_value
                                   1196 ;	-----------------------------------------
      00B57F                       1197 _vialrgb_get_value:
      00B57F 12 43 15         [24] 1198 	lcall	_ak820_outline_0037
      00B582 90 0D 96         [24] 1199 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B585 12 38 29         [24] 1200 	lcall	_ak820_outline_0017
                                   1201 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B588 90 0D 95         [24] 1202 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B58B E0               [24] 1203 	movx	a,@dptr
      00B58C FF               [12] 1204 	mov	r7,a
      00B58D BF 20 02         [24] 1205 	cjne	r7,#0x20,00162$
      00B590 80 01            [24] 1206 	sjmp	00102$
      00B592                       1207 00162$:
      00B592 22               [24] 1208 	ret
      00B593                       1209 00102$:
                                   1210 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B593 90 0D 96         [24] 1211 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B596 12 B7 83         [24] 1212 	lcall	_ak820_outline_0046
                                   1213 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1214 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B599 BA 40 02         [24] 1215 	cjne	r2,#0x40,00163$
      00B59C 80 18            [24] 1216 	sjmp	00103$
      00B59E                       1217 00163$:
      00B59E BA 41 02         [24] 1218 	cjne	r2,#0x41,00164$
      00B5A1 80 26            [24] 1219 	sjmp	00104$
      00B5A3                       1220 00164$:
      00B5A3 BA 42 03         [24] 1221 	cjne	r2,#0x42,00165$
      00B5A6 02 B6 5B         [24] 1222 	ljmp	00105$
      00B5A9                       1223 00165$:
      00B5A9 BA 43 03         [24] 1224 	cjne	r2,#0x43,00166$
      00B5AC 02 B6 68         [24] 1225 	ljmp	00106$
      00B5AF                       1226 00166$:
      00B5AF BA 44 03         [24] 1227 	cjne	r2,#0x44,00167$
      00B5B2 02 B6 74         [24] 1228 	ljmp	00107$
      00B5B5                       1229 00167$:
      00B5B5 22               [24] 1230 	ret
                                   1231 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B5B6                       1232 00103$:
                                   1233 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B5B6 12 33 FC         [24] 1234 	lcall	_ak820_outline_0123
      00B5B9 74 01            [12] 1235 	mov	a,#0x01
      00B5BB F0               [24] 1236 	movx	@dptr,a
                                   1237 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B5BC 12 B7 7B         [24] 1238 	lcall	_ak820_outline_0039
      00B5BF E4               [12] 1239 	clr	a
      00B5C0 F0               [24] 1240 	movx	@dptr,a
                                   1241 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B5C1 12 B7 7B         [24] 1242 	lcall	_ak820_outline_0039
      00B5C4 A3               [24] 1243 	inc	dptr
      00B5C5 74 A0            [12] 1244 	mov	a,#0xa0
      00B5C7 F0               [24] 1245 	movx	@dptr,a
                                   1246 ;	quantum/vialrgb.c:147: break;
      00B5C8 22               [24] 1247 	ret
                                   1248 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B5C9                       1249 00104$:
                                   1250 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B5C9 C0 06            [24] 1251 	push	ar6
      00B5CB C0 05            [24] 1252 	push	ar5
      00B5CD C0 04            [24] 1253 	push	ar4
      00B5CF C0 03            [24] 1254 	push	ar3
      00B5D1 12 B3 C7         [24] 1255 	lcall	_get_mode
      00B5D4 A9 82            [24] 1256 	mov	r1, dpl
      00B5D6 AA 83            [24] 1257 	mov	r2, dph
      00B5D8 D0 03            [24] 1258 	pop	ar3
      00B5DA D0 04            [24] 1259 	pop	ar4
      00B5DC D0 05            [24] 1260 	pop	ar5
      00B5DE D0 06            [24] 1261 	pop	ar6
                                   1262 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B5E0 89 00            [24] 1263 	mov	ar0,r1
      00B5E2 12 33 FC         [24] 1264 	lcall	_ak820_outline_0123
      00B5E5 E8               [12] 1265 	mov	a,r0
      00B5E6 F0               [24] 1266 	movx	@dptr,a
                                   1267 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B5E7 12 B7 7B         [24] 1268 	lcall	_ak820_outline_0039
      00B5EA 8A 01            [24] 1269 	mov	ar1,r2
      00B5EC E9               [12] 1270 	mov	a,r1
      00B5ED F0               [24] 1271 	movx	@dptr,a
                                   1272 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B5EE 74 04            [12] 1273 	mov	a,#0x04
      00B5F0 12 8E 74         [24] 1274 	lcall	_ak820_outline_0136
      00B5F3 C0 06            [24] 1275 	push	ar6
      00B5F5 C0 05            [24] 1276 	push	ar5
      00B5F7 C0 02            [24] 1277 	push	ar2
      00B5F9 C0 01            [24] 1278 	push	ar1
      00B5FB 12 55 1E         [24] 1279 	lcall	_rgb_matrix_get_speed
      00B5FE A8 82            [24] 1280 	mov	r0, dpl
      00B600 D0 01            [24] 1281 	pop	ar1
      00B602 D0 02            [24] 1282 	pop	ar2
      00B604 D0 05            [24] 1283 	pop	ar5
      00B606 D0 06            [24] 1284 	pop	ar6
      00B608 12 80 D9         [24] 1285 	lcall	_ak820_outline_0062
                                   1286 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B60B 74 05            [12] 1287 	mov	a,#0x05
      00B60D 12 8E 74         [24] 1288 	lcall	_ak820_outline_0136
      00B610 C0 06            [24] 1289 	push	ar6
      00B612 C0 05            [24] 1290 	push	ar5
      00B614 C0 02            [24] 1291 	push	ar2
      00B616 C0 01            [24] 1292 	push	ar1
      00B618 12 55 09         [24] 1293 	lcall	_rgb_matrix_get_hue
      00B61B A8 82            [24] 1294 	mov	r0, dpl
      00B61D D0 01            [24] 1295 	pop	ar1
      00B61F D0 02            [24] 1296 	pop	ar2
      00B621 D0 05            [24] 1297 	pop	ar5
      00B623 D0 06            [24] 1298 	pop	ar6
      00B625 12 80 D9         [24] 1299 	lcall	_ak820_outline_0062
                                   1300 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B628 74 06            [12] 1301 	mov	a,#0x06
      00B62A 12 8E 74         [24] 1302 	lcall	_ak820_outline_0136
      00B62D C0 06            [24] 1303 	push	ar6
      00B62F C0 05            [24] 1304 	push	ar5
      00B631 C0 02            [24] 1305 	push	ar2
      00B633 C0 01            [24] 1306 	push	ar1
      00B635 12 55 10         [24] 1307 	lcall	_rgb_matrix_get_sat
      00B638 A8 82            [24] 1308 	mov	r0, dpl
      00B63A D0 01            [24] 1309 	pop	ar1
      00B63C D0 02            [24] 1310 	pop	ar2
      00B63E D0 05            [24] 1311 	pop	ar5
      00B640 D0 06            [24] 1312 	pop	ar6
      00B642 12 80 D9         [24] 1313 	lcall	_ak820_outline_0062
                                   1314 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B645 74 07            [12] 1315 	mov	a,#0x07
      00B647 12 8E 74         [24] 1316 	lcall	_ak820_outline_0136
      00B64A C0 02            [24] 1317 	push	ar2
      00B64C C0 01            [24] 1318 	push	ar1
      00B64E 12 55 17         [24] 1319 	lcall	_rgb_matrix_get_val
      00B651 A8 82            [24] 1320 	mov	r0, dpl
      00B653 D0 01            [24] 1321 	pop	ar1
      00B655 D0 02            [24] 1322 	pop	ar2
      00B657 12 80 D9         [24] 1323 	lcall	_ak820_outline_0062
                                   1324 ;	quantum/vialrgb.c:156: break;
      00B65A 22               [24] 1325 	ret
                                   1326 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B65B                       1327 00105$:
                                   1328 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B65B EF               [12] 1329 	mov	a,r7
      00B65C 24 FE            [12] 1330 	add	a,#0xfe
      00B65E 90 0D 82         [24] 1331 	mov	dptr,#_get_supported_PARM_2
      00B661 F0               [24] 1332 	movx	@dptr,a
      00B662 12 33 FC         [24] 1333 	lcall	_ak820_outline_0123
                                   1334 ;	quantum/vialrgb.c:160: break;
      00B665 02 B2 CE         [24] 1335 	ljmp	_get_supported
                                   1336 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B668                       1337 00106$:
                                   1338 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B668 12 33 FC         [24] 1339 	lcall	_ak820_outline_0123
      00B66B 74 52            [12] 1340 	mov	a,#0x52
      00B66D F0               [24] 1341 	movx	@dptr,a
                                   1342 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B66E 12 B7 7B         [24] 1343 	lcall	_ak820_outline_0039
      00B671 E4               [12] 1344 	clr	a
      00B672 F0               [24] 1345 	movx	@dptr,a
                                   1346 ;	quantum/vialrgb.c:166: break;
      00B673 22               [24] 1347 	ret
                                   1348 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B674                       1349 00107$:
                                   1350 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B674 12 33 FC         [24] 1351 	lcall	_ak820_outline_0123
      00B677 E0               [24] 1352 	movx	a,@dptr
      00B678 FF               [12] 1353 	mov	r7,a
      00B679 7A 00            [12] 1354 	mov	r2,#0x00
      00B67B 74 03            [12] 1355 	mov	a,#0x03
      00B67D 2D               [12] 1356 	add	a, r5
      00B67E F8               [12] 1357 	mov	r0,a
      00B67F E4               [12] 1358 	clr	a
      00B680 3E               [12] 1359 	addc	a, r6
      00B681 F9               [12] 1360 	mov	r1,a
      00B682 C0 03            [24] 1361 	push	ar3
      00B684 C0 04            [24] 1362 	push	ar4
      00B686 12 38 B6         [24] 1363 	lcall	_ak820_outline_0157
      00B689 E0               [24] 1364 	movx	a,@dptr
      00B68A FB               [12] 1365 	mov	r3,a
      00B68B E4               [12] 1366 	clr	a
      00B68C 4F               [12] 1367 	orl	a,r7
      00B68D F5 4E            [12] 1368 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B68F EB               [12] 1369 	mov	a,r3
      00B690 4A               [12] 1370 	orl	a,r2
      00B691 F5 4F            [12] 1371 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1372 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B693 AC 4E            [24] 1373 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B695 AF 4F            [24] 1374 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B697 C3               [12] 1375 	clr	c
      00B698 EC               [12] 1376 	mov	a,r4
      00B699 94 52            [12] 1377 	subb	a,#0x52
      00B69B EF               [12] 1378 	mov	a,r7
      00B69C 94 00            [12] 1379 	subb	a,#0x00
      00B69E D0 04            [24] 1380 	pop	ar4
      00B6A0 D0 03            [24] 1381 	pop	ar3
      00B6A2 40 01            [24] 1382 	jc	00109$
      00B6A4 22               [24] 1383 	ret
      00B6A5                       1384 00109$:
                                   1385 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B6A5 E5 4E            [12] 1386 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B6A7 25 4E            [12] 1387 	add	a,_vialrgb_get_value_sloc0_1_0
      00B6A9 FA               [12] 1388 	mov	r2,a
      00B6AA E5 4F            [12] 1389 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B6AC 33               [12] 1390 	rlc	a
      00B6AD FF               [12] 1391 	mov	r7,a
      00B6AE EA               [12] 1392 	mov	a,r2
      00B6AF 24 39            [12] 1393 	add	a, #_ak820_led_points
      00B6B1 F5 50            [12] 1394 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B6B3 EF               [12] 1395 	mov	a,r7
      00B6B4 34 BC            [12] 1396 	addc	a, #(_ak820_led_points >> 8)
      00B6B6 F5 51            [12] 1397 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B6B8 85 50 82         [24] 1398 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B6BB 85 51 83         [24] 1399 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B6BE E4               [12] 1400 	clr	a
      00B6BF 93               [24] 1401 	movc	a,@a+dptr
      00B6C0 12 33 FC         [24] 1402 	lcall	_ak820_outline_0123
      00B6C3 F0               [24] 1403 	movx	@dptr,a
                                   1404 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B6C4 85 50 82         [24] 1405 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B6C7 85 51 83         [24] 1406 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B6CA A3               [24] 1407 	inc	dptr
      00B6CB E4               [12] 1408 	clr	a
      00B6CC 93               [24] 1409 	movc	a,@a+dptr
      00B6CD 12 38 B6         [24] 1410 	lcall	_ak820_outline_0157
      00B6D0 F0               [24] 1411 	movx	@dptr,a
                                   1412 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B6D1 12 B7 7B         [24] 1413 	lcall	_ak820_outline_0039
      00B6D4 A3               [24] 1414 	inc	dptr
      00B6D5 74 04            [12] 1415 	mov	a,#0x04
      00B6D7 F0               [24] 1416 	movx	@dptr,a
                                   1417 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B6D8 90 0D 8B         [24] 1418 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B6DB 04               [12] 1419 	inc	a
      00B6DC 2D               [12] 1420 	add	a, r5
      00B6DD F0               [24] 1421 	movx	@dptr,a
      00B6DE E4               [12] 1422 	clr	a
      00B6DF 3E               [12] 1423 	addc	a, r6
      00B6E0 A3               [24] 1424 	inc	dptr
      00B6E1 F0               [24] 1425 	movx	@dptr,a
      00B6E2 85 4E 82         [24] 1426 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B6E5 85 4F 83         [24] 1427 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1428 ;	quantum/vialrgb.c:187: }
                                   1429 ;	quantum/vialrgb.c:188: }
      00B6E8 02 B4 0A         [24] 1430 	ljmp	_get_matrix_pos_for_led
                                   1431 ;------------------------------------------------------------
                                   1432 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1433 ;------------------------------------------------------------
                                   1434 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1435 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1436 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1437 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1438 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1439 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1440 ;------------------------------------------------------------
                                   1441 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1442 ;	-----------------------------------------
                                   1443 ;	 function vialrgb_set_value
                                   1444 ;	-----------------------------------------
      00B6EB                       1445 _vialrgb_set_value:
      00B6EB 12 43 15         [24] 1446 	lcall	_ak820_outline_0037
      00B6EE 90 0D 9A         [24] 1447 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B6F1 12 38 29         [24] 1448 	lcall	_ak820_outline_0017
                                   1449 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B6F4 90 0D 99         [24] 1450 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B6F7 E0               [24] 1451 	movx	a,@dptr
      00B6F8 FF               [12] 1452 	mov	r7,a
      00B6F9 BF 20 02         [24] 1453 	cjne	r7,#0x20,00129$
      00B6FC 80 01            [24] 1454 	sjmp	00102$
      00B6FE                       1455 00129$:
      00B6FE 22               [24] 1456 	ret
      00B6FF                       1457 00102$:
                                   1458 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B6FF 90 0D 9A         [24] 1459 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B702 12 B7 83         [24] 1460 	lcall	_ak820_outline_0046
                                   1461 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1462 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B705 BA 41 02         [24] 1463 	cjne	r2,#0x41,00130$
      00B708 80 06            [24] 1464 	sjmp	00103$
      00B70A                       1465 00130$:
      00B70A BA 42 02         [24] 1466 	cjne	r2,#0x42,00131$
      00B70D 80 5C            [24] 1467 	sjmp	00104$
      00B70F                       1468 00131$:
      00B70F 22               [24] 1469 	ret
                                   1470 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B710                       1471 00103$:
                                   1472 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B710 12 48 99         [24] 1473 	lcall	_ak820_outline_0063
      00B713 12 B7 7B         [24] 1474 	lcall	_ak820_outline_0039
      00B716 E0               [24] 1475 	movx	a,@dptr
      00B717 F8               [12] 1476 	mov	r0,a
      00B718 79 00            [12] 1477 	mov	r1,#0x00
      00B71A 88 53            [24] 1478 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B71C 89 52            [24] 1479 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B71E 8A 01            [24] 1480 	mov	ar1,r2
      00B720 7A 00            [12] 1481 	mov	r2,#0x00
      00B722 E5 53            [12] 1482 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B724 42 02            [12] 1483 	orl	ar2,a
                                   1484 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B726 12 43 7E         [24] 1485 	lcall	_ak820_outline_0183
      00B729 C0 06            [24] 1486 	push	ar6
      00B72B C0 05            [24] 1487 	push	ar5
      00B72D 12 B3 DC         [24] 1488 	lcall	_set_mode
      00B730 D0 05            [24] 1489 	pop	ar5
      00B732 D0 06            [24] 1490 	pop	ar6
                                   1491 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B734 12 B7 7B         [24] 1492 	lcall	_ak820_outline_0039
      00B737 A3               [24] 1493 	inc	dptr
      00B738 E0               [24] 1494 	movx	a,@dptr
      00B739 F5 82            [12] 1495 	mov	dpl,a
      00B73B C0 06            [24] 1496 	push	ar6
      00B73D C0 05            [24] 1497 	push	ar5
      00B73F 12 55 EC         [24] 1498 	lcall	_rgb_matrix_set_speed_noeeprom
      00B742 D0 05            [24] 1499 	pop	ar5
      00B744 D0 06            [24] 1500 	pop	ar6
                                   1501 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B746 12 B7 7B         [24] 1502 	lcall	_ak820_outline_0039
      00B749 A3               [24] 1503 	inc	dptr
      00B74A A3               [24] 1504 	inc	dptr
      00B74B E0               [24] 1505 	movx	a,@dptr
      00B74C F9               [12] 1506 	mov	r1,a
      00B74D 7A 00            [12] 1507 	mov	r2,#0x00
      00B74F 74 06            [12] 1508 	mov	a,#0x06
      00B751 12 B7 CD         [24] 1509 	lcall	_ak820_outline_0171
      00B754 F8               [12] 1510 	mov	r0,a
      00B755 74 07            [12] 1511 	mov	a,#0x07
      00B757 12 B7 CD         [24] 1512 	lcall	_ak820_outline_0171
      00B75A FE               [12] 1513 	mov	r6,a
      00B75B 90 07 30         [24] 1514 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B75E E8               [12] 1515 	mov	a,r0
      00B75F F0               [24] 1516 	movx	@dptr,a
      00B760 90 07 31         [24] 1517 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B763 EE               [12] 1518 	mov	a,r6
      00B764 F0               [24] 1519 	movx	@dptr,a
      00B765 12 43 7E         [24] 1520 	lcall	_ak820_outline_0183
                                   1521 ;	quantum/vialrgb.c:202: break;
                                   1522 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B768 02 55 BD         [24] 1523 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B76B                       1524 00104$:
                                   1525 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B76B EF               [12] 1526 	mov	a,r7
      00B76C 24 FE            [12] 1527 	add	a,#0xfe
      00B76E 90 0D 8F         [24] 1528 	mov	dptr,#_fast_set_leds_PARM_2
      00B771 F0               [24] 1529 	movx	@dptr,a
      00B772 12 33 FC         [24] 1530 	lcall	_ak820_outline_0123
                                   1531 ;	quantum/vialrgb.c:210: }
                                   1532 ;	quantum/vialrgb.c:211: }
      00B775 02 B4 3D         [24] 1533 	ljmp	_fast_set_leds
                                   1534 ;------------------------------------------------------------
                                   1535 ;Allocation info for local variables in function 'vialrgb_save'
                                   1536 ;------------------------------------------------------------
                                   1537 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1538 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1539 ;------------------------------------------------------------
                                   1540 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1541 ;	-----------------------------------------
                                   1542 ;	 function vialrgb_save
                                   1543 ;	-----------------------------------------
      00B778                       1544 _vialrgb_save:
                                   1545 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1546 ;	quantum/vialrgb.c:218: }
      00B778 02 50 44         [24] 1547 	ljmp	_eeconfig_update_rgb_matrix
                                   1548 	.area CSEG    (CODE)
                                   1549 	.area CONST   (CODE)
                                   1550 	.area CONST   (CODE)
      00BF78                       1551 _supported_modes:
      00BF78 00                    1552 	.db #0x00	; 0
      00BF79 00                    1553 	.db #0x00	; 0
      00BF7A 01                    1554 	.db #0x01	; 1
      00BF7B 05                    1555 	.db #0x05	; 5
      00BF7C 02                    1556 	.db #0x02	; 2
      00BF7D 01                    1557 	.db #0x01	; 1
      00BF7E 06                    1558 	.db #0x06	; 6
      00BF7F 02                    1559 	.db #0x02	; 2
      00BF80 0D                    1560 	.db #0x0d	; 13
      00BF81 03                    1561 	.db #0x03	; 3
      00BF82 0E                    1562 	.db #0x0e	; 14
      00BF83 04                    1563 	.db #0x04	; 4
      00BF84 1F                    1564 	.db #0x1f	; 31
      00BF85 06                    1565 	.db #0x06	; 6
                                   1566 	.area CSEG    (CODE)
                                   1567 	.area XINIT   (CODE)
                                   1568 	.area CABS    (ABS,CODE)
                                   1569 
                                   1570 ; Experimental exact instruction outlining.
                                   1571 	.globl _ak820_outline_0005
                                   1572 	.globl _ak820_outline_0017
                                   1573 	.globl _ak820_outline_0021
                                   1574 	.globl _ak820_outline_0037
                                   1575 	.globl _ak820_outline_0039
                                   1576 	.globl _ak820_outline_0040
                                   1577 	.globl _ak820_outline_0046
                                   1578 	.globl _ak820_outline_0047
                                   1579 	.globl _ak820_outline_0051
                                   1580 	.globl _ak820_outline_0056
                                   1581 	.globl _ak820_outline_0062
                                   1582 	.globl _ak820_outline_0063
                                   1583 	.globl _ak820_outline_0082
                                   1584 	.globl _ak820_outline_0083
                                   1585 	.globl _ak820_outline_0084
                                   1586 	.globl _ak820_outline_0106
                                   1587 	.globl _ak820_outline_0107
                                   1588 	.globl _ak820_outline_0108
                                   1589 	.globl _ak820_outline_0109
                                   1590 	.globl _ak820_outline_0118
                                   1591 	.globl _ak820_outline_0121
                                   1592 	.globl _ak820_outline_0122
                                   1593 	.globl _ak820_outline_0123
                                   1594 	.globl _ak820_outline_0133
                                   1595 	.globl _ak820_outline_0136
                                   1596 	.globl _ak820_outline_0142
                                   1597 	.globl _ak820_outline_0144
                                   1598 	.globl _ak820_outline_0157
                                   1599 	.globl _ak820_outline_0162
                                   1600 	.globl _ak820_outline_0171
                                   1601 	.globl _ak820_outline_0183
                                   1602 	.globl _ak820_outline_0188
                                   1603 
                                   1604 	.area CSEG (CODE)
                                   1605 ; function ak820_outline_0039
      00B77B                       1606 _ak820_outline_0039:
      00B77B 8D 82            [24] 1607 	mov	dpl,r5
      00B77D 8E 83            [24] 1608 	mov	dph,r6
      00B77F A3               [24] 1609 	inc	dptr
      00B780 A3               [24] 1610 	inc	dptr
      00B781 A3               [24] 1611 	inc	dptr
      00B782 22               [24] 1612 	ret
                                   1613 
                                   1614 	.area CSEG (CODE)
                                   1615 ; function ak820_outline_0046
      00B783                       1616 _ak820_outline_0046:
      00B783 E0               [24] 1617 	movx	a,@dptr
      00B784 FD               [12] 1618 	mov	r5,a
      00B785 A3               [24] 1619 	inc	dptr
      00B786 E0               [24] 1620 	movx	a,@dptr
      00B787 FE               [12] 1621 	mov	r6,a
      00B788 74 02            [12] 1622 	mov	a,#0x02
      00B78A 2D               [12] 1623 	add	a,r5
      00B78B FB               [12] 1624 	mov	r3,a
      00B78C E4               [12] 1625 	clr	a
      00B78D 3E               [12] 1626 	addc	a,r6
      00B78E FC               [12] 1627 	mov	r4,a
      00B78F 8D 82            [24] 1628 	mov	dpl,r5
      00B791 8E 83            [24] 1629 	mov	dph,r6
      00B793 A3               [24] 1630 	inc	dptr
      00B794 E0               [24] 1631 	movx	a,@dptr
      00B795 FA               [12] 1632 	mov	r2,a
      00B796 22               [24] 1633 	ret
                                   1634 
                                   1635 	.area CSEG (CODE)
                                   1636 ; function ak820_outline_0047
      00B797                       1637 _ak820_outline_0047:
      00B797 ED               [12] 1638 	mov	a,r5
      00B798 75 F0 02         [24] 1639 	mov	b,#0x02
      00B79B A4               [48] 1640 	mul	ab
      00B79C 24 78            [12] 1641 	add	a,#_supported_modes
      00B79E FB               [12] 1642 	mov	r3,a
      00B79F 74 BF            [12] 1643 	mov	a,#(_supported_modes>>8)
      00B7A1 35 F0            [12] 1644 	addc	a,b
      00B7A3 FC               [12] 1645 	mov	r4,a
      00B7A4 8B 82            [24] 1646 	mov	dpl,r3
      00B7A6 8C 83            [24] 1647 	mov	dph,r4
      00B7A8 22               [24] 1648 	ret
                                   1649 
                                   1650 	.area CSEG (CODE)
                                   1651 ; function ak820_outline_0082
      00B7A9                       1652 _ak820_outline_0082:
      00B7A9 90 0D 90         [24] 1653 	mov	dptr,#_fast_set_leds_args_10000_282
      00B7AC E0               [24] 1654 	movx	a,@dptr
      00B7AD F9               [12] 1655 	mov	r1,a
      00B7AE A3               [24] 1656 	inc	dptr
      00B7AF E0               [24] 1657 	movx	a,@dptr
      00B7B0 FF               [12] 1658 	mov	r7,a
      00B7B1 89 82            [24] 1659 	mov	dpl,r1
      00B7B3 8F 83            [24] 1660 	mov	dph,r7
      00B7B5 E0               [24] 1661 	movx	a,@dptr
      00B7B6 22               [24] 1662 	ret
                                   1663 
                                   1664 	.area CSEG (CODE)
                                   1665 ; function ak820_outline_0106
      00B7B7                       1666 _ak820_outline_0106:
      00B7B7 90 0D 90         [24] 1667 	mov	dptr,#_fast_set_leds_args_10000_282
      00B7BA 74 01            [12] 1668 	mov	a,#0x01
      00B7BC 29               [12] 1669 	add	a,r1
      00B7BD F0               [24] 1670 	movx	@dptr,a
      00B7BE E4               [12] 1671 	clr	a
      00B7BF 3F               [12] 1672 	addc	a,r7
      00B7C0 A3               [24] 1673 	inc	dptr
      00B7C1 F0               [24] 1674 	movx	@dptr,a
      00B7C2 22               [24] 1675 	ret
                                   1676 
                                   1677 	.area CSEG (CODE)
                                   1678 ; function ak820_outline_0144
      00B7C3                       1679 _ak820_outline_0144:
      00B7C3 E4               [12] 1680 	clr	a
      00B7C4 93               [24] 1681 	movc	a,@a+dptr
      00B7C5 FC               [12] 1682 	mov	r4,a
      00B7C6 7B 00            [12] 1683 	mov	r3,#0x00
      00B7C8 8C 82            [24] 1684 	mov	dpl,r4
      00B7CA 8B 83            [24] 1685 	mov	dph,r3
      00B7CC 22               [24] 1686 	ret
                                   1687 
                                   1688 	.area CSEG (CODE)
                                   1689 ; function ak820_outline_0171
      00B7CD                       1690 _ak820_outline_0171:
      00B7CD 2D               [12] 1691 	add	a,r5
      00B7CE F5 82            [12] 1692 	mov	dpl,a
      00B7D0 E4               [12] 1693 	clr	a
      00B7D1 3E               [12] 1694 	addc	a,r6
      00B7D2 F5 83            [12] 1695 	mov	dph,a
      00B7D4 E0               [24] 1696 	movx	a,@dptr
      00B7D5 22               [24] 1697 	ret
