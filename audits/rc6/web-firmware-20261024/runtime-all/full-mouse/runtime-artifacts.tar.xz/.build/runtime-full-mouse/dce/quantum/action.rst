                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _register_mouse
                                     12 	.globl _ak820_combo_cancel
                                     13 	.globl _ak820_combo_tick
                                     14 	.globl _ak820_oneshot_cancel
                                     15 	.globl _ak820_oneshot_post
                                     16 	.globl _ak820_oneshot_process
                                     17 	.globl _ak820_tapping_source
                                     18 	.globl _ak820_tapping_cancel
                                     19 	.globl _ak820_tapping_process
                                     20 	.globl _ak820_tapping_before
                                     21 	.globl _pre_process_record_quantum
                                     22 	.globl _get_record_keycode
                                     23 	.globl _repeat_key_cancel
                                     24 	.globl _clear_owned_usages
                                     25 	.globl _owned_usage_key
                                     26 	.globl _clear_owned_keys
                                     27 	.globl _del_owned_key
                                     28 	.globl _add_owned_key
                                     29 	.globl _clear_owned_mods
                                     30 	.globl _del_owned_weak_mods
                                     31 	.globl _add_owned_weak_mods
                                     32 	.globl _del_owned_mods
                                     33 	.globl _add_owned_mods
                                     34 	.globl _clear_weak_mods
                                     35 	.globl _clear_mods
                                     36 	.globl _send_keyboard_report
                                     37 	.globl _layer_hold_clear
                                     38 	.globl _layer_hold_off
                                     39 	.globl _layer_hold_on
                                     40 	.globl _ak820_resolve_key
                                     41 	.globl _layer_xor
                                     42 	.globl _layer_and
                                     43 	.globl _layer_or
                                     44 	.globl _layer_off
                                     45 	.globl _layer_on
                                     46 	.globl _layer_move
                                     47 	.globl _layer_clear
                                     48 	.globl _layer_state_set
                                     49 	.globl _default_layer_xor
                                     50 	.globl _default_layer_and
                                     51 	.globl _default_layer_or
                                     52 	.globl _default_layer_set
                                     53 	.globl _post_process_record_quantum
                                     54 	.globl _process_record_quantum
                                     55 	.globl _action_for_keycode
                                     56 	.globl _mousekey_send
                                     57 	.globl _mousekey_clear
                                     58 	.globl _mousekey_off
                                     59 	.globl _mousekey_on
                                     60 	.globl _mDelaymS
                                     61 	.globl _host_consumer_send
                                     62 	.globl _host_system_send
                                     63 	.globl _host_keyboard_leds
                                     64 	.globl _led_set
                                     65 	.globl _clear_keys_from_report
                                     66 	.globl ___memcpy
                                     67 	.globl _ADC_START
                                     68 	.globl _S0_R_FIFO
                                     69 	.globl _S0_T_FIFO
                                     70 	.globl _S0_FREE
                                     71 	.globl _S0_IF_BYTE
                                     72 	.globl _S0_IF_FIRST
                                     73 	.globl _S0_IF_OV
                                     74 	.globl _S0_FST_ACT
                                     75 	.globl _CP_RL2
                                     76 	.globl _C_T2
                                     77 	.globl _TR2
                                     78 	.globl _EXEN2
                                     79 	.globl _TCLK
                                     80 	.globl _RCLK
                                     81 	.globl _EXF2
                                     82 	.globl _CAP1F
                                     83 	.globl _TF2
                                     84 	.globl _RI
                                     85 	.globl _TI
                                     86 	.globl _RB8
                                     87 	.globl _TB8
                                     88 	.globl _REN
                                     89 	.globl _SM2
                                     90 	.globl _SM1
                                     91 	.globl _SM0
                                     92 	.globl _IT0
                                     93 	.globl _IE0
                                     94 	.globl _IT1
                                     95 	.globl _IE1
                                     96 	.globl _TR0
                                     97 	.globl _TF0
                                     98 	.globl _TR1
                                     99 	.globl _TF1
                                    100 	.globl _P4_0
                                    101 	.globl _P4_1
                                    102 	.globl _P4_2
                                    103 	.globl _P4_3
                                    104 	.globl _P4_4
                                    105 	.globl _P4_5
                                    106 	.globl _P4_6
                                    107 	.globl _RXD
                                    108 	.globl _TXD
                                    109 	.globl _INT0
                                    110 	.globl _INT1
                                    111 	.globl _T0
                                    112 	.globl _T1
                                    113 	.globl _MOSI1
                                    114 	.globl _MISO1
                                    115 	.globl _SCK1
                                    116 	.globl _P3_0
                                    117 	.globl _P3_1
                                    118 	.globl _P3_2
                                    119 	.globl _P3_3
                                    120 	.globl _P3_4
                                    121 	.globl _P3_5
                                    122 	.globl _P3_6
                                    123 	.globl _P3_7
                                    124 	.globl _CAP1_
                                    125 	.globl _T2_
                                    126 	.globl _CAP2_
                                    127 	.globl _T2EX_
                                    128 	.globl _RXD1
                                    129 	.globl _TXD1
                                    130 	.globl _P2_0
                                    131 	.globl _P2_1
                                    132 	.globl _P2_2
                                    133 	.globl _P2_3
                                    134 	.globl _P2_4
                                    135 	.globl _P2_5
                                    136 	.globl _P2_6
                                    137 	.globl _P2_7
                                    138 	.globl _AIN0
                                    139 	.globl _AIN1
                                    140 	.globl _AIN2
                                    141 	.globl _AIN3
                                    142 	.globl _AIN4
                                    143 	.globl _AIN5
                                    144 	.globl _AIN6
                                    145 	.globl _AIN7
                                    146 	.globl _CAP1
                                    147 	.globl _T2
                                    148 	.globl _CAP2
                                    149 	.globl _T2EX
                                    150 	.globl _INT0_
                                    151 	.globl _SCS
                                    152 	.globl _MOSI
                                    153 	.globl _MISO
                                    154 	.globl _SCK
                                    155 	.globl _RXD1_
                                    156 	.globl _TXD1_
                                    157 	.globl _P1_0
                                    158 	.globl _P1_1
                                    159 	.globl _P1_2
                                    160 	.globl _P1_3
                                    161 	.globl _P1_4
                                    162 	.globl _P1_5
                                    163 	.globl _P1_6
                                    164 	.globl _P1_7
                                    165 	.globl _AIN8
                                    166 	.globl _AIN9
                                    167 	.globl _AIN10
                                    168 	.globl _AIN11
                                    169 	.globl _AIN12
                                    170 	.globl _AIN13
                                    171 	.globl _RXD_
                                    172 	.globl _TXD_
                                    173 	.globl _SCL0
                                    174 	.globl _SDA0
                                    175 	.globl _P0_0
                                    176 	.globl _P0_1
                                    177 	.globl _P0_2
                                    178 	.globl _P0_3
                                    179 	.globl _P0_4
                                    180 	.globl _P0_5
                                    181 	.globl _P0_6
                                    182 	.globl _P0_7
                                    183 	.globl _IE_SPI0
                                    184 	.globl _IE_USB
                                    185 	.globl _IE_ADC
                                    186 	.globl _IE_UART1
                                    187 	.globl _IE_PWM_I2C
                                    188 	.globl _IE_GPIO
                                    189 	.globl _IE_WDOG
                                    190 	.globl _PX0
                                    191 	.globl _PT0
                                    192 	.globl _PX1
                                    193 	.globl _PT1
                                    194 	.globl _PS
                                    195 	.globl _PT2
                                    196 	.globl _PL_FLAG
                                    197 	.globl _PH_FLAG
                                    198 	.globl _EX0
                                    199 	.globl _ET0
                                    200 	.globl _EX1
                                    201 	.globl _ET1
                                    202 	.globl _ES
                                    203 	.globl _ET2
                                    204 	.globl _E_DIS
                                    205 	.globl _EA
                                    206 	.globl _P
                                    207 	.globl _F1
                                    208 	.globl _OV
                                    209 	.globl _RS0
                                    210 	.globl _RS1
                                    211 	.globl _F0
                                    212 	.globl _AC
                                    213 	.globl _CY
                                    214 	.globl _I2CS_INT_ST
                                    215 	.globl _I2CX_INT
                                    216 	.globl _LED_STATUS
                                    217 	.globl _LED_DMA_H
                                    218 	.globl _LED_DMA_L
                                    219 	.globl _LED_DMA
                                    220 	.globl _LED_PWM_OE
                                    221 	.globl _LED_COMMON
                                    222 	.globl _ADC_CHAN
                                    223 	.globl _ADC_DAT_H
                                    224 	.globl _ADC_DAT_L
                                    225 	.globl _ADC_DAT
                                    226 	.globl _ADC_CTRL
                                    227 	.globl _SPI1_CK_SE
                                    228 	.globl _SPI1_CTRL
                                    229 	.globl _SPI1_DATA
                                    230 	.globl _SPI1_STAT
                                    231 	.globl _SIF1
                                    232 	.globl _SBAUD1
                                    233 	.globl _SBUF1
                                    234 	.globl _SCON1
                                    235 	.globl _SPI0_SETUP
                                    236 	.globl _SPI0_CK_SE
                                    237 	.globl _SPI0_CTRL
                                    238 	.globl _SPI0_DATA
                                    239 	.globl _SPI0_STAT
                                    240 	.globl _T2CAP1H
                                    241 	.globl _T2CAP1L
                                    242 	.globl _T2CAP1
                                    243 	.globl _TH2
                                    244 	.globl _TL2
                                    245 	.globl _T2COUNT
                                    246 	.globl _RCAP2H
                                    247 	.globl _RCAP2L
                                    248 	.globl _RCAP2
                                    249 	.globl _T2MOD
                                    250 	.globl _T2CON
                                    251 	.globl _SBUF
                                    252 	.globl _SCON
                                    253 	.globl _TH1
                                    254 	.globl _TH0
                                    255 	.globl _TL1
                                    256 	.globl _TL0
                                    257 	.globl _TMOD
                                    258 	.globl _TCON
                                    259 	.globl _XBUS_AUX
                                    260 	.globl _P7
                                    261 	.globl _P6_DIR
                                    262 	.globl _P6_OUT_PU
                                    263 	.globl _P6_IN
                                    264 	.globl _P5_DIR
                                    265 	.globl _P5_OUT_PU
                                    266 	.globl _P5_IN
                                    267 	.globl _P4_LED_KEY
                                    268 	.globl _P4_DIR_PU
                                    269 	.globl _P4_MOD_OC
                                    270 	.globl _P4
                                    271 	.globl _P3_DIR_PU
                                    272 	.globl _P3_MOD_OC
                                    273 	.globl _P3
                                    274 	.globl _P2_DIR_PU
                                    275 	.globl _P2_MOD_OC
                                    276 	.globl _P2
                                    277 	.globl _P1_DIR_PU
                                    278 	.globl _P1_MOD_OC
                                    279 	.globl _P1
                                    280 	.globl _P0_DIR_PU
                                    281 	.globl _P0_MOD_OC
                                    282 	.globl _P0
                                    283 	.globl _ROM_CTRL
                                    284 	.globl _ROM_DATA_HH
                                    285 	.globl _ROM_DATA_HL
                                    286 	.globl _ROM_DATA_HI
                                    287 	.globl _ROM_ADDR_H
                                    288 	.globl _ROM_ADDR_L
                                    289 	.globl _ROM_ADDR
                                    290 	.globl _GPIO_IE
                                    291 	.globl _IP_EX
                                    292 	.globl _IE_EX
                                    293 	.globl _IP
                                    294 	.globl _IE
                                    295 	.globl _WDOG_COUNT
                                    296 	.globl _RESET_KEEP
                                    297 	.globl _WAKE_CTRL
                                    298 	.globl _CLOCK_CFG
                                    299 	.globl _POWER_CFG
                                    300 	.globl _PCON
                                    301 	.globl _GLOBAL_CFG
                                    302 	.globl _SAFE_MOD
                                    303 	.globl _DPH
                                    304 	.globl _DPL
                                    305 	.globl _SP
                                    306 	.globl _A_INV
                                    307 	.globl _B
                                    308 	.globl _ACC
                                    309 	.globl _PSW
                                    310 	.globl _disable_action_cache
                                    311 	.globl _tap_code_delay_PARM_2
                                    312 	.globl _process_action_PARM_2
                                    313 	.globl _register_mouse_PARM_2
                                    314 	.globl _action_exec_PARM_1
                                    315 	.globl _tp_buttons
                                    316 	.globl _action_exec
                                    317 	.globl _ak820_action_exec
                                    318 	.globl _process_record
                                    319 	.globl _process_record_handler
                                    320 	.globl _process_action
                                    321 	.globl _register_code
                                    322 	.globl _unregister_code
                                    323 	.globl _tap_code_delay
                                    324 	.globl _tap_code
                                    325 	.globl _register_mods
                                    326 	.globl _unregister_mods
                                    327 	.globl _register_weak_mods
                                    328 	.globl _unregister_weak_mods
                                    329 	.globl _clear_keyboard
                                    330 	.globl _clear_keyboard_but_mods
                                    331 	.globl _clear_keyboard_but_mods_and_keys
                                    332 ;--------------------------------------------------------
                                    333 ; special function registers
                                    334 ;--------------------------------------------------------
                                    335 	.area RSEG    (ABS,DATA)
      000000                        336 	.org 0x0000
                           0000D0   337 _PSW	=	0x00d0
                           0000E0   338 _ACC	=	0x00e0
                           0000F0   339 _B	=	0x00f0
                           0000FD   340 _A_INV	=	0x00fd
                           000081   341 _SP	=	0x0081
                           000082   342 _DPL	=	0x0082
                           000083   343 _DPH	=	0x0083
                           0000A1   344 _SAFE_MOD	=	0x00a1
                           0000B1   345 _GLOBAL_CFG	=	0x00b1
                           000087   346 _PCON	=	0x0087
                           0000BA   347 _POWER_CFG	=	0x00ba
                           0000B9   348 _CLOCK_CFG	=	0x00b9
                           0000A9   349 _WAKE_CTRL	=	0x00a9
                           0000FE   350 _RESET_KEEP	=	0x00fe
                           0000FF   351 _WDOG_COUNT	=	0x00ff
                           0000A8   352 _IE	=	0x00a8
                           0000B8   353 _IP	=	0x00b8
                           0000E8   354 _IE_EX	=	0x00e8
                           0000E9   355 _IP_EX	=	0x00e9
                           0000B2   356 _GPIO_IE	=	0x00b2
                           008584   357 _ROM_ADDR	=	0x8584
                           000084   358 _ROM_ADDR_L	=	0x0084
                           000085   359 _ROM_ADDR_H	=	0x0085
                           008F8E   360 _ROM_DATA_HI	=	0x8f8e
                           00008E   361 _ROM_DATA_HL	=	0x008e
                           00008F   362 _ROM_DATA_HH	=	0x008f
                           000086   363 _ROM_CTRL	=	0x0086
                           000080   364 _P0	=	0x0080
                           0000C4   365 _P0_MOD_OC	=	0x00c4
                           0000C5   366 _P0_DIR_PU	=	0x00c5
                           000090   367 _P1	=	0x0090
                           000092   368 _P1_MOD_OC	=	0x0092
                           000093   369 _P1_DIR_PU	=	0x0093
                           0000A0   370 _P2	=	0x00a0
                           000094   371 _P2_MOD_OC	=	0x0094
                           000095   372 _P2_DIR_PU	=	0x0095
                           0000B0   373 _P3	=	0x00b0
                           000096   374 _P3_MOD_OC	=	0x0096
                           000097   375 _P3_DIR_PU	=	0x0097
                           0000C0   376 _P4	=	0x00c0
                           0000C2   377 _P4_MOD_OC	=	0x00c2
                           0000C3   378 _P4_DIR_PU	=	0x00c3
                           0000C1   379 _P4_LED_KEY	=	0x00c1
                           0000AA   380 _P5_IN	=	0x00aa
                           0000AB   381 _P5_OUT_PU	=	0x00ab
                           0000AC   382 _P5_DIR	=	0x00ac
                           0000AD   383 _P6_IN	=	0x00ad
                           0000AE   384 _P6_OUT_PU	=	0x00ae
                           0000AF   385 _P6_DIR	=	0x00af
                           0000F1   386 _P7	=	0x00f1
                           0000A2   387 _XBUS_AUX	=	0x00a2
                           000088   388 _TCON	=	0x0088
                           000089   389 _TMOD	=	0x0089
                           00008A   390 _TL0	=	0x008a
                           00008B   391 _TL1	=	0x008b
                           00008C   392 _TH0	=	0x008c
                           00008D   393 _TH1	=	0x008d
                           000098   394 _SCON	=	0x0098
                           000099   395 _SBUF	=	0x0099
                           0000C8   396 _T2CON	=	0x00c8
                           0000C9   397 _T2MOD	=	0x00c9
                           00CBCA   398 _RCAP2	=	0xcbca
                           0000CA   399 _RCAP2L	=	0x00ca
                           0000CB   400 _RCAP2H	=	0x00cb
                           00CDCC   401 _T2COUNT	=	0xcdcc
                           0000CC   402 _TL2	=	0x00cc
                           0000CD   403 _TH2	=	0x00cd
                           00CFCE   404 _T2CAP1	=	0xcfce
                           0000CE   405 _T2CAP1L	=	0x00ce
                           0000CF   406 _T2CAP1H	=	0x00cf
                           0000F8   407 _SPI0_STAT	=	0x00f8
                           0000F9   408 _SPI0_DATA	=	0x00f9
                           0000FA   409 _SPI0_CTRL	=	0x00fa
                           0000FB   410 _SPI0_CK_SE	=	0x00fb
                           0000FC   411 _SPI0_SETUP	=	0x00fc
                           0000BC   412 _SCON1	=	0x00bc
                           0000BD   413 _SBUF1	=	0x00bd
                           0000BE   414 _SBAUD1	=	0x00be
                           0000BF   415 _SIF1	=	0x00bf
                           0000B4   416 _SPI1_STAT	=	0x00b4
                           0000B5   417 _SPI1_DATA	=	0x00b5
                           0000B6   418 _SPI1_CTRL	=	0x00b6
                           0000B7   419 _SPI1_CK_SE	=	0x00b7
                           0000F3   420 _ADC_CTRL	=	0x00f3
                           00F5F4   421 _ADC_DAT	=	0xf5f4
                           0000F4   422 _ADC_DAT_L	=	0x00f4
                           0000F5   423 _ADC_DAT_H	=	0x00f5
                           0000F6   424 _ADC_CHAN	=	0x00f6
                           0000A6   425 _LED_COMMON	=	0x00a6
                           0000A7   426 _LED_PWM_OE	=	0x00a7
                           00C7C6   427 _LED_DMA	=	0xc7c6
                           0000C6   428 _LED_DMA_L	=	0x00c6
                           0000C7   429 _LED_DMA_H	=	0x00c7
                           0000F7   430 _LED_STATUS	=	0x00f7
                           0000B3   431 _I2CX_INT	=	0x00b3
                           0000BB   432 _I2CS_INT_ST	=	0x00bb
                                    433 ;--------------------------------------------------------
                                    434 ; special function bits
                                    435 ;--------------------------------------------------------
                                    436 	.area RSEG    (ABS,DATA)
      000000                        437 	.org 0x0000
                           0000D7   438 _CY	=	0x00d7
                           0000D6   439 _AC	=	0x00d6
                           0000D5   440 _F0	=	0x00d5
                           0000D4   441 _RS1	=	0x00d4
                           0000D3   442 _RS0	=	0x00d3
                           0000D2   443 _OV	=	0x00d2
                           0000D1   444 _F1	=	0x00d1
                           0000D0   445 _P	=	0x00d0
                           0000AF   446 _EA	=	0x00af
                           0000AE   447 _E_DIS	=	0x00ae
                           0000AD   448 _ET2	=	0x00ad
                           0000AC   449 _ES	=	0x00ac
                           0000AB   450 _ET1	=	0x00ab
                           0000AA   451 _EX1	=	0x00aa
                           0000A9   452 _ET0	=	0x00a9
                           0000A8   453 _EX0	=	0x00a8
                           0000BF   454 _PH_FLAG	=	0x00bf
                           0000BE   455 _PL_FLAG	=	0x00be
                           0000BD   456 _PT2	=	0x00bd
                           0000BC   457 _PS	=	0x00bc
                           0000BB   458 _PT1	=	0x00bb
                           0000BA   459 _PX1	=	0x00ba
                           0000B9   460 _PT0	=	0x00b9
                           0000B8   461 _PX0	=	0x00b8
                           0000EF   462 _IE_WDOG	=	0x00ef
                           0000EE   463 _IE_GPIO	=	0x00ee
                           0000ED   464 _IE_PWM_I2C	=	0x00ed
                           0000EC   465 _IE_UART1	=	0x00ec
                           0000EB   466 _IE_ADC	=	0x00eb
                           0000E9   467 _IE_USB	=	0x00e9
                           0000E8   468 _IE_SPI0	=	0x00e8
                           000087   469 _P0_7	=	0x0087
                           000086   470 _P0_6	=	0x0086
                           000085   471 _P0_5	=	0x0085
                           000084   472 _P0_4	=	0x0084
                           000083   473 _P0_3	=	0x0083
                           000082   474 _P0_2	=	0x0082
                           000081   475 _P0_1	=	0x0081
                           000080   476 _P0_0	=	0x0080
                           000081   477 _SDA0	=	0x0081
                           000080   478 _SCL0	=	0x0080
                           000083   479 _TXD_	=	0x0083
                           000082   480 _RXD_	=	0x0082
                           000085   481 _AIN13	=	0x0085
                           000084   482 _AIN12	=	0x0084
                           000083   483 _AIN11	=	0x0083
                           000082   484 _AIN10	=	0x0082
                           000081   485 _AIN9	=	0x0081
                           000080   486 _AIN8	=	0x0080
                           000097   487 _P1_7	=	0x0097
                           000096   488 _P1_6	=	0x0096
                           000095   489 _P1_5	=	0x0095
                           000094   490 _P1_4	=	0x0094
                           000093   491 _P1_3	=	0x0093
                           000092   492 _P1_2	=	0x0092
                           000091   493 _P1_1	=	0x0091
                           000090   494 _P1_0	=	0x0090
                           000097   495 _TXD1_	=	0x0097
                           000096   496 _RXD1_	=	0x0096
                           000097   497 _SCK	=	0x0097
                           000096   498 _MISO	=	0x0096
                           000095   499 _MOSI	=	0x0095
                           000094   500 _SCS	=	0x0094
                           000092   501 _INT0_	=	0x0092
                           000091   502 _T2EX	=	0x0091
                           000091   503 _CAP2	=	0x0091
                           000090   504 _T2	=	0x0090
                           000090   505 _CAP1	=	0x0090
                           000097   506 _AIN7	=	0x0097
                           000096   507 _AIN6	=	0x0096
                           000095   508 _AIN5	=	0x0095
                           000094   509 _AIN4	=	0x0094
                           000093   510 _AIN3	=	0x0093
                           000092   511 _AIN2	=	0x0092
                           000091   512 _AIN1	=	0x0091
                           000090   513 _AIN0	=	0x0090
                           0000A7   514 _P2_7	=	0x00a7
                           0000A6   515 _P2_6	=	0x00a6
                           0000A5   516 _P2_5	=	0x00a5
                           0000A4   517 _P2_4	=	0x00a4
                           0000A3   518 _P2_3	=	0x00a3
                           0000A2   519 _P2_2	=	0x00a2
                           0000A1   520 _P2_1	=	0x00a1
                           0000A0   521 _P2_0	=	0x00a0
                           0000A7   522 _TXD1	=	0x00a7
                           0000A6   523 _RXD1	=	0x00a6
                           0000A5   524 _T2EX_	=	0x00a5
                           0000A5   525 _CAP2_	=	0x00a5
                           0000A4   526 _T2_	=	0x00a4
                           0000A4   527 _CAP1_	=	0x00a4
                           0000B7   528 _P3_7	=	0x00b7
                           0000B6   529 _P3_6	=	0x00b6
                           0000B5   530 _P3_5	=	0x00b5
                           0000B4   531 _P3_4	=	0x00b4
                           0000B3   532 _P3_3	=	0x00b3
                           0000B2   533 _P3_2	=	0x00b2
                           0000B1   534 _P3_1	=	0x00b1
                           0000B0   535 _P3_0	=	0x00b0
                           0000B7   536 _SCK1	=	0x00b7
                           0000B6   537 _MISO1	=	0x00b6
                           0000B5   538 _MOSI1	=	0x00b5
                           0000B5   539 _T1	=	0x00b5
                           0000B4   540 _T0	=	0x00b4
                           0000B3   541 _INT1	=	0x00b3
                           0000B2   542 _INT0	=	0x00b2
                           0000B1   543 _TXD	=	0x00b1
                           0000B0   544 _RXD	=	0x00b0
                           0000C6   545 _P4_6	=	0x00c6
                           0000C5   546 _P4_5	=	0x00c5
                           0000C4   547 _P4_4	=	0x00c4
                           0000C3   548 _P4_3	=	0x00c3
                           0000C2   549 _P4_2	=	0x00c2
                           0000C1   550 _P4_1	=	0x00c1
                           0000C0   551 _P4_0	=	0x00c0
                           00008F   552 _TF1	=	0x008f
                           00008E   553 _TR1	=	0x008e
                           00008D   554 _TF0	=	0x008d
                           00008C   555 _TR0	=	0x008c
                           00008B   556 _IE1	=	0x008b
                           00008A   557 _IT1	=	0x008a
                           000089   558 _IE0	=	0x0089
                           000088   559 _IT0	=	0x0088
                           00009F   560 _SM0	=	0x009f
                           00009E   561 _SM1	=	0x009e
                           00009D   562 _SM2	=	0x009d
                           00009C   563 _REN	=	0x009c
                           00009B   564 _TB8	=	0x009b
                           00009A   565 _RB8	=	0x009a
                           000099   566 _TI	=	0x0099
                           000098   567 _RI	=	0x0098
                           0000CF   568 _TF2	=	0x00cf
                           0000CF   569 _CAP1F	=	0x00cf
                           0000CE   570 _EXF2	=	0x00ce
                           0000CD   571 _RCLK	=	0x00cd
                           0000CC   572 _TCLK	=	0x00cc
                           0000CB   573 _EXEN2	=	0x00cb
                           0000CA   574 _TR2	=	0x00ca
                           0000C9   575 _C_T2	=	0x00c9
                           0000C8   576 _CP_RL2	=	0x00c8
                           0000FF   577 _S0_FST_ACT	=	0x00ff
                           0000FE   578 _S0_IF_OV	=	0x00fe
                           0000FD   579 _S0_IF_FIRST	=	0x00fd
                           0000FC   580 _S0_IF_BYTE	=	0x00fc
                           0000FB   581 _S0_FREE	=	0x00fb
                           0000FA   582 _S0_T_FIFO	=	0x00fa
                           0000F8   583 _S0_R_FIFO	=	0x00f8
                           0000F7   584 _ADC_START	=	0x00f7
                                    585 ;--------------------------------------------------------
                                    586 ; overlayable register banks
                                    587 ;--------------------------------------------------------
                                    588 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        589 	.ds 8
                                    590 ;--------------------------------------------------------
                                    591 ; internal ram data
                                    592 ;--------------------------------------------------------
                                    593 	.area DSEG    (DATA)
      000027                        594 _process_action_sloc0_1_0:
      000027                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; overlayable items in internal ram
                                    598 ;--------------------------------------------------------
                                    599 ;--------------------------------------------------------
                                    600 ; indirectly addressable internal ram data
                                    601 ;--------------------------------------------------------
                                    602 	.area ISEG    (DATA)
                                    603 ;--------------------------------------------------------
                                    604 ; absolute internal ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area IABS    (ABS,DATA)
                                    607 	.area IABS    (ABS,DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; bit data
                                    610 ;--------------------------------------------------------
                                    611 	.area BSEG    (BIT)
      00001F                        612 _process_action_sloc1_1_0:
      00001F                        613 	.ds 1
                                    614 ;--------------------------------------------------------
                                    615 ; paged external ram data
                                    616 ;--------------------------------------------------------
                                    617 	.area PSEG    (PAG,XDATA)
                                    618 ;--------------------------------------------------------
                                    619 ; uninitialized external ram data
                                    620 ;--------------------------------------------------------
                                    621 	.area XSEG    (XDATA)
      00082A                        622 _tp_buttons::
      00082A                        623 	.ds 2
      00082C                        624 _action_exec_PARM_1:
      00082C                        625 	.ds 6
      000832                        626 _action_exec_record_10001_625:
      000832                        627 	.ds 9
      00083B                        628 _ak820_action_exec_event_10000_629:
      00083B                        629 	.ds 2
      00083D                        630 _ak820_action_exec_snapshot_10000_630:
      00083D                        631 	.ds 6
      000843                        632 _process_record_record_10000_633:
      000843                        633 	.ds 3
      000846                        634 _process_record_handler_record_argument_10000_641:
      000846                        635 	.ds 3
      000849                        636 _process_record_handler_action_10000_642:
      000849                        637 	.ds 2
      00084B                        638 _register_mouse_PARM_2:
      00084B                        639 	.ds 1
      00084C                        640 _register_mouse_mouse_keycode_10000_650:
      00084C                        641 	.ds 1
      00084D                        642 _process_action_PARM_2:
      00084D                        643 	.ds 2
      00084F                        644 _process_action_record_argument_10000_657:
      00084F                        645 	.ds 3
      000852                        646 _process_action_on_40000_680:
      000852                        647 	.ds 1
      000853                        648 _register_code_code_10000_714:
      000853                        649 	.ds 1
      000854                        650 _unregister_code_code_10000_728:
      000854                        651 	.ds 1
      000855                        652 _tap_code_delay_PARM_2:
      000855                        653 	.ds 2
      000857                        654 _tap_code_delay_code_10000_741:
      000857                        655 	.ds 1
      000858                        656 _tap_code_code_10000_748:
      000858                        657 	.ds 1
      000859                        658 _register_mods_mods_10000_750:
      000859                        659 	.ds 1
      00085A                        660 _unregister_mods_mods_10000_754:
      00085A                        661 	.ds 1
      00085B                        662 _register_weak_mods_mods_10000_758:
      00085B                        663 	.ds 1
      00085C                        664 _unregister_weak_mods_mods_10000_762:
      00085C                        665 	.ds 1
                                    666 ;--------------------------------------------------------
                                    667 ; absolute external ram data
                                    668 ;--------------------------------------------------------
                                    669 	.area XABS    (ABS,XDATA)
                                    670 ;--------------------------------------------------------
                                    671 ; initialized external ram data
                                    672 ;--------------------------------------------------------
                                    673 	.area XISEG   (XDATA)
      000DDB                        674 _disable_action_cache::
      000DDB                        675 	.ds 1
                                    676 	.area HOME    (CODE)
                                    677 	.area GSINIT0 (CODE)
                                    678 	.area GSINIT1 (CODE)
                                    679 	.area GSINIT2 (CODE)
                                    680 	.area GSINIT3 (CODE)
                                    681 	.area GSINIT4 (CODE)
                                    682 	.area GSINIT5 (CODE)
                                    683 	.area GSINIT  (CODE)
                                    684 	.area GSFINAL (CODE)
                                    685 	.area CSEG    (CODE)
                                    686 ;--------------------------------------------------------
                                    687 ; global & static initialisations
                                    688 ;--------------------------------------------------------
                                    689 	.area HOME    (CODE)
                                    690 	.area GSINIT  (CODE)
                                    691 	.area GSFINAL (CODE)
                                    692 	.area GSINIT  (CODE)
                                    693 ;--------------------------------------------------------
                                    694 ; Home
                                    695 ;--------------------------------------------------------
                                    696 	.area HOME    (CODE)
                                    697 	.area HOME    (CODE)
                                    698 ;--------------------------------------------------------
                                    699 ; code
                                    700 ;--------------------------------------------------------
                                    701 	.area CSEG    (CODE)
                                    702 ;------------------------------------------------------------
                                    703 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    704 ;------------------------------------------------------------
                                    705 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    706 ;------------------------------------------------------------
                                    707 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    708 ;	-----------------------------------------
                           000007   709 	ar7 = 0x07
                           000006   710 	ar6 = 0x06
                           000005   711 	ar5 = 0x05
                           000004   712 	ar4 = 0x04
                           000003   713 	ar3 = 0x03
                           000002   714 	ar2 = 0x02
                           000001   715 	ar1 = 0x01
                           000000   716 	ar0 = 0x00
                                    717 ;	 function action_exec
                                    718 ;	-----------------------------------------
      00728B                        719 _action_exec:
                                    720 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      00728B 90 08 2E         [24]  721 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00728E 12 37 F4         [24]  722 	lcall	_ak820_outline_0005
      007291 12 36 04         [24]  723 	lcall	_ak820_combo_tick
                                    724 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      007294 90 08 2C         [24]  725 	mov	dptr,#_action_exec_PARM_1
      007297 12 44 53         [24]  726 	lcall	_ak820_tapping_before
      00729A E5 82            [12]  727 	mov	a, dpl
      00729C 70 01            [24]  728 	jnz	00102$
      00729E 22               [24]  729 	ret
      00729F                        730 00102$:
                                    731 ;	quantum/action.c:116: if (event.pressed) {
      00729F 90 08 31         [24]  732 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      0072A2 E0               [24]  733 	movx	a,@dptr
      0072A3 60 03            [24]  734 	jz	00104$
                                    735 ;	quantum/action.c:118: clear_weak_mods();
      0072A5 12 83 53         [24]  736 	lcall	_clear_weak_mods
      0072A8                        737 00104$:
                                    738 ;	quantum/action.c:130: record.event = event;
      0072A8 90 0D BB         [24]  739 	mov	dptr,#___memcpy_PARM_2
      0072AB 74 2C            [12]  740 	mov	a,#_action_exec_PARM_1
      0072AD F0               [24]  741 	movx	@dptr,a
      0072AE 74 08            [12]  742 	mov	a,#(_action_exec_PARM_1 >> 8)
      0072B0 12 38 70         [24]  743 	lcall	_ak820_outline_0093
      0072B3 12 79 C3         [24]  744 	lcall	_ak820_outline_0070
      0072B6 90 08 32         [24]  745 	mov	dptr,#_action_exec_record_10001_625
      0072B9 F5 F0            [12]  746 	mov	b,a
      0072BB 12 BA 8C         [24]  747 	lcall	___memcpy
                                    748 ;	quantum/action.c:132: record.tap.count = 0;
      0072BE 90 08 38         [24]  749 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      0072C1 E0               [24]  750 	movx	a,@dptr
      0072C2 54 0F            [12]  751 	anl	a,#0x0f
      0072C4 F0               [24]  752 	movx	@dptr,a
                                    753 ;	quantum/action.c:137: record.keycode = 0;
      0072C5 90 08 39         [24]  754 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      0072C8 12 4F 67         [24]  755 	lcall	_ak820_outline_0182
                                    756 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      0072CB 90 08 36         [24]  757 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      0072CE E0               [24]  758 	movx	a,@dptr
      0072CF 60 0D            [24]  759 	jz	00107$
      0072D1 90 08 32         [24]  760 	mov	dptr,#_action_exec_record_10001_625
      0072D4 75 F0 00         [24]  761 	mov	b, #0x00
      0072D7 12 A1 34         [24]  762 	lcall	_pre_process_record_quantum
      0072DA E5 82            [12]  763 	mov	a, dpl
      0072DC 60 14            [24]  764 	jz	00110$
      0072DE                        765 00107$:
                                    766 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      0072DE 90 08 32         [24]  767 	mov	dptr,#_action_exec_record_10001_625
      0072E1 12 45 3A         [24]  768 	lcall	_ak820_tapping_process
      0072E4 E5 82            [12]  769 	mov	a, dpl
      0072E6 70 01            [24]  770 	jnz	00106$
      0072E8 22               [24]  771 	ret
      0072E9                        772 00106$:
                                    773 ;	quantum/action.c:175: process_record(&record);
      0072E9 90 08 32         [24]  774 	mov	dptr,#_action_exec_record_10001_625
      0072EC 75 F0 00         [24]  775 	mov	b, #0x00
                                    776 ;	quantum/action.c:190: }
      0072EF 02 73 2F         [24]  777 	ljmp	_process_record
      0072F2                        778 00110$:
      0072F2 22               [24]  779 	ret
                                    780 ;------------------------------------------------------------
                                    781 ;Allocation info for local variables in function 'ak820_action_exec'
                                    782 ;------------------------------------------------------------
                                    783 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    784 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    785 ;------------------------------------------------------------
                                    786 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    787 ;	-----------------------------------------
                                    788 ;	 function ak820_action_exec
                                    789 ;	-----------------------------------------
      0072F3                        790 _ak820_action_exec:
      0072F3 12 38 82         [24]  791 	lcall	_ak820_outline_0107
      0072F6 90 08 3B         [24]  792 	mov	dptr,#_ak820_action_exec_event_10000_629
      0072F9 12 38 87         [24]  793 	lcall	_ak820_outline_0108
                                    794 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      0072FC 90 08 3B         [24]  795 	mov	dptr,#_ak820_action_exec_event_10000_629
      0072FF 12 38 64         [24]  796 	lcall	_ak820_outline_0079
      007302 7F 00            [12]  797 	mov	r7,#0x00
      007304 90 0D BB         [24]  798 	mov	dptr,#___memcpy_PARM_2
      007307 ED               [12]  799 	mov	a,r5
      007308 12 38 29         [24]  800 	lcall	_ak820_outline_0017
      00730B 12 79 C3         [24]  801 	lcall	_ak820_outline_0070
      00730E 90 08 3D         [24]  802 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      007311 F5 F0            [12]  803 	mov	b,a
      007313 12 BA 8C         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:197: action_exec(snapshot);
      007316 90 0D BB         [24]  806 	mov	dptr,#___memcpy_PARM_2
      007319 74 3D            [12]  807 	mov	a,#_ak820_action_exec_snapshot_10000_630
      00731B F0               [24]  808 	movx	@dptr,a
      00731C 74 08            [12]  809 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      00731E 12 38 70         [24]  810 	lcall	_ak820_outline_0093
      007321 12 79 C3         [24]  811 	lcall	_ak820_outline_0070
      007324 90 08 2C         [24]  812 	mov	dptr,#_action_exec_PARM_1
      007327 F5 F0            [12]  813 	mov	b,a
      007329 12 BA 8C         [24]  814 	lcall	___memcpy
                                    815 ;	quantum/action.c:198: }
      00732C 02 72 8B         [24]  816 	ljmp	_action_exec
                                    817 ;------------------------------------------------------------
                                    818 ;Allocation info for local variables in function 'process_record_nocache'
                                    819 ;------------------------------------------------------------
                                    820 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    821 ;------------------------------------------------------------
                                    822 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    823 ;	-----------------------------------------
                                    824 ;	 function process_record
                                    825 ;	-----------------------------------------
      00732F                        826 _process_record:
      00732F 12 43 13         [24]  827 	lcall	_ak820_outline_0037
      007332 90 08 43         [24]  828 	mov	dptr,#_process_record_record_10000_633
      007335 12 38 29         [24]  829 	lcall	_ak820_outline_0017
                                    830 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      007338 90 08 43         [24]  831 	mov	dptr,#_process_record_record_10000_633
      00733B 12 4F 14         [24]  832 	lcall	_ak820_outline_0012
      00733E 74 04            [12]  833 	mov	a,#0x04
      007340 12 79 96         [24]  834 	lcall	_ak820_outline_0014
      007343 12 BB 65         [24]  835 	lcall	__gptrget
      007346 70 01            [24]  836 	jnz	00102$
                                    837 ;	quantum/action.c:338: return;
      007348 22               [24]  838 	ret
      007349                        839 00102$:
                                    840 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007349 8D 02            [24]  841 	mov	ar2,r5
      00734B 8E 03            [24]  842 	mov	ar3,r6
      00734D 8F 04            [24]  843 	mov	ar4,r7
      00734F 90 0D BB         [24]  844 	mov	dptr,#___memcpy_PARM_2
      007352 EA               [12]  845 	mov	a,r2
      007353 12 7A 0A         [24]  846 	lcall	_ak820_outline_0187
      007356 EC               [12]  847 	mov	a,r4
      007357 A3               [24]  848 	inc	dptr
      007358 F0               [24]  849 	movx	@dptr,a
      007359 90 0D BE         [24]  850 	mov	dptr,#___memcpy_PARM_3
      00735C 12 4F 59         [24]  851 	lcall	_ak820_outline_0110
      00735F 90 06 24         [24]  852 	mov	dptr,#_ak820_tapping_source_PARM_1
      007362 F5 F0            [12]  853 	mov	b,a
      007364 C0 07            [24]  854 	push	ar7
      007366 C0 06            [24]  855 	push	ar6
      007368 C0 05            [24]  856 	push	ar5
      00736A 12 BA 8C         [24]  857 	lcall	___memcpy
      00736D 12 43 8D         [24]  858 	lcall	_ak820_tapping_source
      007370 AC 82            [24]  859 	mov	r4, dpl
      007372 D0 05            [24]  860 	pop	ar5
      007374 D0 06            [24]  861 	pop	ar6
      007376 D0 07            [24]  862 	pop	ar7
                                    863 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      007378 74 05            [12]  864 	mov	a,#0x05
      00737A 12 79 88         [24]  865 	lcall	_ak820_outline_0013
      00737D 12 BB 65         [24]  866 	lcall	__gptrget
      007380 FB               [12]  867 	mov	r3,a
                                    868 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      007381 12 79 FB         [24]  869 	lcall	_ak820_outline_0148
      007384 90 0C 12         [24]  870 	mov	dptr,#_get_record_keycode_PARM_2
      007387 74 01            [12]  871 	mov	a,#0x01
      007389 12 4F 1D         [24]  872 	lcall	_ak820_outline_0034
      00738C C0 04            [24]  873 	push	ar4
      00738E C0 03            [24]  874 	push	ar3
      007390 C0 02            [24]  875 	push	ar2
      007392 C0 01            [24]  876 	push	ar1
      007394 C0 00            [24]  877 	push	ar0
      007396 12 A0 F6         [24]  878 	lcall	_get_record_keycode
      007399 12 43 5C         [24]  879 	lcall	_ak820_outline_0133
      00739C D0 00            [24]  880 	pop	ar0
      00739E D0 01            [24]  881 	pop	ar1
      0073A0 D0 02            [24]  882 	pop	ar2
      0073A2 D0 03            [24]  883 	pop	ar3
      0073A4 D0 04            [24]  884 	pop	ar4
      0073A6 12 48 B2         [24]  885 	lcall	_ak820_outline_0112
      0073A9 EE               [12]  886 	mov	a,r6
      0073AA 12 BB 2A         [24]  887 	lcall	__gptrput
      0073AD A3               [24]  888 	inc	dptr
      0073AE EF               [12]  889 	mov	a,r7
      0073AF 12 BB 2A         [24]  890 	lcall	__gptrput
                                    891 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      0073B2 90 08 43         [24]  892 	mov	dptr,#_process_record_record_10000_633
      0073B5 12 4F 14         [24]  893 	lcall	_ak820_outline_0012
      0073B8 12 79 FB         [24]  894 	lcall	_ak820_outline_0148
      0073BB 12 48 B2         [24]  895 	lcall	_ak820_outline_0112
      0073BE 12 BB 65         [24]  896 	lcall	__gptrget
      0073C1 F8               [12]  897 	mov	r0,a
      0073C2 A3               [24]  898 	inc	dptr
      0073C3 12 BB 65         [24]  899 	lcall	__gptrget
      0073C6 F9               [12]  900 	mov	r1,a
      0073C7 90 06 34         [24]  901 	mov	dptr,#_ak820_oneshot_process_PARM_2
      0073CA EC               [12]  902 	mov	a,r4
      0073CB F0               [24]  903 	movx	@dptr,a
      0073CC 90 06 35         [24]  904 	mov	dptr,#_ak820_oneshot_process_PARM_3
      0073CF EB               [12]  905 	mov	a,r3
      0073D0 F0               [24]  906 	movx	@dptr,a
      0073D1 12 38 B6         [24]  907 	lcall	_ak820_outline_0160
      0073D4 C0 07            [24]  908 	push	ar7
      0073D6 C0 06            [24]  909 	push	ar6
      0073D8 C0 05            [24]  910 	push	ar5
      0073DA C0 04            [24]  911 	push	ar4
      0073DC C0 03            [24]  912 	push	ar3
      0073DE 12 46 EC         [24]  913 	lcall	_ak820_oneshot_process
      0073E1 E5 82            [12]  914 	mov	a, dpl
      0073E3 D0 03            [24]  915 	pop	ar3
      0073E5 D0 04            [24]  916 	pop	ar4
      0073E7 D0 05            [24]  917 	pop	ar5
      0073E9 D0 06            [24]  918 	pop	ar6
      0073EB D0 07            [24]  919 	pop	ar7
      0073ED 70 01            [24]  920 	jnz	00104$
      0073EF 22               [24]  921 	ret
      0073F0                        922 00104$:
                                    923 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      0073F0 12 6F EE         [24]  924 	lcall	_ak820_outline_0057
      0073F3 C0 04            [24]  925 	push	ar4
      0073F5 C0 03            [24]  926 	push	ar3
      0073F7 12 A1 C0         [24]  927 	lcall	_process_record_quantum
      0073FA E5 82            [12]  928 	mov	a, dpl
      0073FC D0 03            [24]  929 	pop	ar3
      0073FE D0 04            [24]  930 	pop	ar4
      007400 70 0A            [24]  931 	jnz	00106$
                                    932 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007402 90 05 9C         [24]  933 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007405 EB               [12]  934 	mov	a,r3
      007406 F0               [24]  935 	movx	@dptr,a
      007407 8C 82            [24]  936 	mov	dpl, r4
                                    937 ;	quantum/action.c:360: return;
      007409 02 2E BB         [24]  938 	ljmp	_ak820_oneshot_post
      00740C                        939 00106$:
                                    940 ;	quantum/action.c:366: process_record_handler(record);
      00740C 90 08 43         [24]  941 	mov	dptr,#_process_record_record_10000_633
      00740F 12 4E EE         [24]  942 	lcall	_ak820_outline_0001
      007412 C0 04            [24]  943 	push	ar4
      007414 C0 03            [24]  944 	push	ar3
      007416 12 74 30         [24]  945 	lcall	_process_record_handler
                                    946 ;	quantum/action.c:370: post_process_record_quantum(record);
      007419 90 08 43         [24]  947 	mov	dptr,#_process_record_record_10000_633
      00741C 12 4E EE         [24]  948 	lcall	_ak820_outline_0001
      00741F 12 A1 95         [24]  949 	lcall	_post_process_record_quantum
      007422 D0 03            [24]  950 	pop	ar3
      007424 D0 04            [24]  951 	pop	ar4
                                    952 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      007426 90 05 9C         [24]  953 	mov	dptr,#_ak820_oneshot_post_PARM_2
      007429 EB               [12]  954 	mov	a,r3
      00742A F0               [24]  955 	movx	@dptr,a
      00742B 8C 82            [24]  956 	mov	dpl, r4
                                    957 ;	quantum/action.c:374: }
      00742D 02 2E BB         [24]  958 	ljmp	_ak820_oneshot_post
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'process_record_handler'
                                    961 ;------------------------------------------------------------
                                    962 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    963 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    964 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    965 ;------------------------------------------------------------
                                    966 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                    967 ;	-----------------------------------------
                                    968 ;	 function process_record_handler
                                    969 ;	-----------------------------------------
      007430                        970 _process_record_handler:
      007430 12 43 13         [24]  971 	lcall	_ak820_outline_0037
      007433 90 08 46         [24]  972 	mov	dptr,#_process_record_handler_record_argument_10000_641
      007436 12 38 29         [24]  973 	lcall	_ak820_outline_0017
                                    974 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007439 90 08 46         [24]  975 	mov	dptr,#_process_record_handler_record_argument_10000_641
      00743C 12 37 FE         [24]  976 	lcall	_ak820_outline_0007
                                    977 ;	quantum/action.c:387: if (record->keycode) {
      00743F 4C               [12]  978 	orl	a,r4
      007440 60 19            [24]  979 	jz	00102$
                                    980 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      007442 12 38 97         [24]  981 	lcall	_ak820_outline_0124
      007445 C0 07            [24]  982 	push	ar7
      007447 C0 06            [24]  983 	push	ar6
      007449 12 97 32         [24]  984 	lcall	_action_for_keycode
      00744C 12 43 6D         [24]  985 	lcall	_ak820_outline_0152
      00744F D0 06            [24]  986 	pop	ar6
      007451 D0 07            [24]  987 	pop	ar7
      007453 90 08 49         [24]  988 	mov	dptr,#_process_record_handler_action_10000_642
      007456 12 38 5E         [24]  989 	lcall	_ak820_outline_0072
      007459 80 2B            [24]  990 	sjmp	00104$
      00745B                        991 00102$:
                                    992 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      00745B 12 79 A4         [24]  993 	lcall	_ak820_outline_0021
      00745E 7A 00            [12]  994 	mov	r2,#0x00
      007460 12 43 67         [24]  995 	lcall	_ak820_outline_0144
      007463 12 43 01         [24]  996 	lcall	_ak820_outline_0011
      007466 E0               [24]  997 	movx	a,@dptr
      007467 90 09 87         [24]  998 	mov	dptr,#_ak820_resolve_key_PARM_2
      00746A F0               [24]  999 	movx	@dptr,a
      00746B 8D 82            [24] 1000 	mov	dpl, r5
      00746D 8C 83            [24] 1001 	mov	dph, r4
      00746F C0 07            [24] 1002 	push	ar7
      007471 C0 06            [24] 1003 	push	ar6
      007473 12 7D 50         [24] 1004 	lcall	_ak820_resolve_key
      007476 12 97 32         [24] 1005 	lcall	_action_for_keycode
      007479 12 43 6D         [24] 1006 	lcall	_ak820_outline_0152
      00747C D0 06            [24] 1007 	pop	ar6
      00747E D0 07            [24] 1008 	pop	ar7
      007480 90 08 49         [24] 1009 	mov	dptr,#_process_record_handler_action_10000_642
      007483 12 38 5E         [24] 1010 	lcall	_ak820_outline_0072
                                   1011 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      007486                       1012 00104$:
                                   1013 ;	quantum/action.c:411: process_action(record, action);
      007486 7D 00            [12] 1014 	mov	r5,#0x00
      007488 90 0D BB         [24] 1015 	mov	dptr,#___memcpy_PARM_2
      00748B 74 49            [12] 1016 	mov	a,#_process_record_handler_action_10000_642
      00748D F0               [24] 1017 	movx	@dptr,a
      00748E 74 08            [12] 1018 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      007490 12 38 70         [24] 1019 	lcall	_ak820_outline_0093
      007493 90 0D BE         [24] 1020 	mov	dptr,#___memcpy_PARM_3
      007496 12 4F 59         [24] 1021 	lcall	_ak820_outline_0110
      007499 90 08 4D         [24] 1022 	mov	dptr,#_process_action_PARM_2
      00749C F5 F0            [12] 1023 	mov	b,a
      00749E C0 07            [24] 1024 	push	ar7
      0074A0 C0 06            [24] 1025 	push	ar6
      0074A2 C0 05            [24] 1026 	push	ar5
      0074A4 12 BA 8C         [24] 1027 	lcall	___memcpy
      0074A7 D0 05            [24] 1028 	pop	ar5
      0074A9 D0 06            [24] 1029 	pop	ar6
      0074AB D0 07            [24] 1030 	pop	ar7
      0074AD 12 72 03         [24] 1031 	lcall	_ak820_outline_0064
                                   1032 ;	quantum/action.c:412: }
      0074B0 02 74 D6         [24] 1033 	ljmp	_process_action
                                   1034 ;------------------------------------------------------------
                                   1035 ;Allocation info for local variables in function 'register_mouse'
                                   1036 ;------------------------------------------------------------
                                   1037 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1038 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function register_mouse
                                   1043 ;	-----------------------------------------
      0074B3                       1044 _register_mouse:
      0074B3 E5 82            [12] 1045 	mov	a,dpl
      0074B5 90 08 4C         [24] 1046 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      0074B8 F0               [24] 1047 	movx	@dptr,a
                                   1048 ;	quantum/action.c:427: if (pressed) {
      0074B9 90 08 4B         [24] 1049 	mov	dptr,#_register_mouse_PARM_2
      0074BC E0               [24] 1050 	movx	a,@dptr
      0074BD 60 0B            [24] 1051 	jz	00102$
                                   1052 ;	quantum/action.c:428: mousekey_on(mouse_keycode);
      0074BF 90 08 4C         [24] 1053 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      0074C2 E0               [24] 1054 	movx	a,@dptr
      0074C3 F5 82            [12] 1055 	mov	dpl,a
      0074C5 12 4F B7         [24] 1056 	lcall	_mousekey_on
      0074C8 80 09            [24] 1057 	sjmp	00103$
      0074CA                       1058 00102$:
                                   1059 ;	quantum/action.c:430: mousekey_off(mouse_keycode);
      0074CA 90 08 4C         [24] 1060 	mov	dptr,#_register_mouse_mouse_keycode_10000_650
      0074CD E0               [24] 1061 	movx	a,@dptr
      0074CE F5 82            [12] 1062 	mov	dpl,a
      0074D0 12 50 2B         [24] 1063 	lcall	_mousekey_off
      0074D3                       1064 00103$:
                                   1065 ;	quantum/action.c:451: mousekey_send();
                                   1066 ;	quantum/action.c:453: }
                                   1067 ;	quantum/action.c:469: }
      0074D3 02 50 8A         [24] 1068 	ljmp	_mousekey_send
                                   1069 ;------------------------------------------------------------
                                   1070 ;Allocation info for local variables in function 'process_action'
                                   1071 ;------------------------------------------------------------
                                   1072 ;sloc0         Allocated with name '_process_action_sloc0_1_0'
                                   1073 ;action        Allocated with name '_process_action_PARM_2'
                                   1074 ;record_argument Allocated with name '_process_action_record_argument_10000_657'
                                   1075 ;record        Allocated with name '_process_action_record_10000_658'
                                   1076 ;pressed       Allocated with name '_process_action_pressed_10000_658'
                                   1077 ;mods          Allocated with name '_process_action_mods_10000_658'
                                   1078 ;on            Allocated with name '_process_action_on_40000_680'
                                   1079 ;shift         Allocated with name '_process_action_shift_60000_682'
                                   1080 ;bits          Allocated with name '_process_action_bits_60000_682'
                                   1081 ;mask          Allocated with name '_process_action_mask_60000_682'
                                   1082 ;i             Allocated with name '_process_action_i_110000_706'
                                   1083 ;i             Allocated with name '_process_action_i_110000_710'
                                   1084 ;------------------------------------------------------------
                                   1085 ;	quantum/action.c:475: void process_action(keyrecord_t *record_argument, action_t action) {
                                   1086 ;	-----------------------------------------
                                   1087 ;	 function process_action
                                   1088 ;	-----------------------------------------
      0074D6                       1089 _process_action:
      0074D6 12 43 13         [24] 1090 	lcall	_ak820_outline_0037
      0074D9 90 08 4F         [24] 1091 	mov	dptr,#_process_action_record_argument_10000_657
      0074DC 12 38 29         [24] 1092 	lcall	_ak820_outline_0017
                                   1093 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0074DF 90 08 4F         [24] 1094 	mov	dptr,#_process_action_record_argument_10000_657
      0074E2 12 37 F4         [24] 1095 	lcall	_ak820_outline_0005
                                   1096 ;	quantum/action.c:483: pressed = record->event.pressed;
      0074E5 A3               [24] 1097 	inc	dptr
      0074E6 A3               [24] 1098 	inc	dptr
      0074E7 A3               [24] 1099 	inc	dptr
      0074E8 A3               [24] 1100 	inc	dptr
      0074E9 A3               [24] 1101 	inc	dptr
      0074EA E0               [24] 1102 	movx	a,@dptr
      0074EB F5 27            [12] 1103 	mov	_process_action_sloc0_1_0,a
                                   1104 ;	quantum/action.c:507: switch (action.kind.id) {
      0074ED 90 08 4E         [24] 1105 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074F0 E0               [24] 1106 	movx	a,@dptr
      0074F1 C4               [12] 1107 	swap	a
      0074F2 54 0F            [12] 1108 	anl	a,#0x0f
      0074F4 FD               [12] 1109 	mov  r5,a
      0074F5 24 F4            [12] 1110 	add	a,#0xff - 0x0b
      0074F7 50 03            [24] 1111 	jnc	00434$
      0074F9 02 77 89         [24] 1112 	ljmp	00181$
      0074FC                       1113 00434$:
                                   1114 ;	free result
      0074FC ED               [12] 1115 	mov	a,r5
      0074FD 24 0A            [12] 1116 	add	a,#(00435$-3-.)
      0074FF 83               [24] 1117 	movc	a,@a+pc
      007500 F5 82            [12] 1118 	mov	dpl,a
      007502 ED               [12] 1119 	mov	a,r5
      007503 24 10            [12] 1120 	add	a,#(00436$-3-.)
      007505 83               [24] 1121 	movc	a,@a+pc
      007506 F5 83            [12] 1122 	mov	dph,a
      007508 E4               [12] 1123 	clr	a
      007509 73               [24] 1124 	jmp	@a+dptr
      00750A                       1125 00435$:
      00750A 22                    1126 	.db	00102$
      00750B 22                    1127 	.db	00102$
      00750C 89                    1128 	.db	00181$
      00750D 89                    1129 	.db	00181$
      00750E AC                    1130 	.db	00123$
      00750F 0C                    1131 	.db	00130$
      007510 89                    1132 	.db	00181$
      007511 89                    1133 	.db	00181$
      007512 1E                    1134 	.db	00131$
      007513 F0                    1135 	.db	00147$
      007514 16                    1136 	.db	00152$
      007515 16                    1137 	.db	00152$
      007516                       1138 00436$:
      007516 75                    1139 	.db	00102$>>8
      007517 75                    1140 	.db	00102$>>8
      007518 77                    1141 	.db	00181$>>8
      007519 77                    1142 	.db	00181$>>8
      00751A 75                    1143 	.db	00123$>>8
      00751B 76                    1144 	.db	00130$>>8
      00751C 77                    1145 	.db	00181$>>8
      00751D 77                    1146 	.db	00181$>>8
      00751E 76                    1147 	.db	00131$>>8
      00751F 76                    1148 	.db	00147$>>8
      007520 77                    1149 	.db	00152$>>8
      007521 77                    1150 	.db	00152$>>8
                                   1151 ;	quantum/action.c:510: case ACT_RMODS: {
      007522                       1152 00102$:
                                   1153 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007522 90 08 4E         [24] 1154 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007525 E0               [24] 1155 	movx	a,@dptr
      007526 54 F0            [12] 1156 	anl	a,#0xf0
      007528 70 06            [24] 1157 	jnz	00194$
      00752A 12 79 DD         [24] 1158 	lcall	_ak820_outline_0113
      00752D FD               [12] 1159 	mov	r5,a
      00752E 80 07            [24] 1160 	sjmp	00195$
      007530                       1161 00194$:
      007530 12 79 DD         [24] 1162 	lcall	_ak820_outline_0113
      007533 C4               [12] 1163 	swap	a
      007534 54 F0            [12] 1164 	anl	a,#0xf0
      007536 FD               [12] 1165 	mov	r5,a
      007537                       1166 00195$:
                                   1167 ;	quantum/action.c:513: if (pressed) {
      007537 E5 27            [12] 1168 	mov	a,_process_action_sloc0_1_0
      007539 60 35            [24] 1169 	jz	00119$
                                   1170 ;	quantum/action.c:514: if (mods) {
      00753B ED               [12] 1171 	mov	a,r5
      00753C 60 29            [24] 1172 	jz	00110$
                                   1173 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      00753E 12 7A 05         [24] 1174 	lcall	_ak820_outline_0151
      007541 FC               [12] 1175 	mov	r4,a
      007542 BC E0 00         [24] 1176 	cjne	r4,#0xe0,00440$
      007545                       1177 00440$:
      007545 40 07            [24] 1178 	jc	00108$
      007547 12 7A 05         [24] 1179 	lcall	_ak820_outline_0151
      00754A 24 18            [12] 1180 	add	a,#0xff - 0xe7
      00754C 50 0A            [24] 1181 	jnc	00104$
                                   1182 ;	free result
      00754E                       1183 00108$:
      00754E 7B 4D            [12] 1184 	mov	r3,#_process_action_PARM_2
      007550 7C 08            [12] 1185 	mov	r4,#(_process_action_PARM_2 >> 8)
      007552 12 33 FC         [24] 1186 	lcall	_ak820_outline_0123
      007555 E0               [24] 1187 	movx	a,@dptr
      007556 70 07            [24] 1188 	jnz	00105$
      007558                       1189 00104$:
                                   1190 ;	quantum/action.c:519: add_owned_mods(mods);
      007558 8D 82            [24] 1191 	mov	dpl, r5
      00755A 12 7F 6A         [24] 1192 	lcall	_add_owned_mods
      00755D 80 05            [24] 1193 	sjmp	00106$
      00755F                       1194 00105$:
                                   1195 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      00755F 8D 82            [24] 1196 	mov	dpl, r5
      007561 12 7F 88         [24] 1197 	lcall	_add_owned_weak_mods
      007564                       1198 00106$:
                                   1199 ;	quantum/action.c:523: send_keyboard_report();
      007564 12 82 A3         [24] 1200 	lcall	_send_keyboard_report
      007567                       1201 00110$:
                                   1202 ;	quantum/action.c:525: register_code(action.key.code);
      007567 12 79 CD         [24] 1203 	lcall	_ak820_outline_0078
      00756A 12 77 A0         [24] 1204 	lcall	_register_code
      00756D 02 77 89         [24] 1205 	ljmp	00181$
      007570                       1206 00119$:
                                   1207 ;	quantum/action.c:527: unregister_code(action.key.code);
      007570 12 79 CD         [24] 1208 	lcall	_ak820_outline_0078
      007573 C0 05            [24] 1209 	push	ar5
      007575 12 78 25         [24] 1210 	lcall	_unregister_code
      007578 D0 05            [24] 1211 	pop	ar5
                                   1212 ;	quantum/action.c:528: if (mods) {
      00757A ED               [12] 1213 	mov	a,r5
      00757B 70 03            [24] 1214 	jnz	00444$
      00757D 02 77 89         [24] 1215 	ljmp	00181$
      007580                       1216 00444$:
                                   1217 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007580 12 7A 05         [24] 1218 	lcall	_ak820_outline_0151
      007583 FC               [12] 1219 	mov	r4,a
      007584 BC E0 00         [24] 1220 	cjne	r4,#0xe0,00445$
      007587                       1221 00445$:
      007587 40 07            [24] 1222 	jc	00115$
      007589 12 7A 05         [24] 1223 	lcall	_ak820_outline_0151
      00758C 24 18            [12] 1224 	add	a,#0xff - 0xe7
      00758E 50 0A            [24] 1225 	jnc	00111$
                                   1226 ;	free result
      007590                       1227 00115$:
      007590 7B 4D            [12] 1228 	mov	r3,#_process_action_PARM_2
      007592 7C 08            [12] 1229 	mov	r4,#(_process_action_PARM_2 >> 8)
      007594 12 33 FC         [24] 1230 	lcall	_ak820_outline_0123
      007597 E0               [24] 1231 	movx	a,@dptr
      007598 70 07            [24] 1232 	jnz	00112$
      00759A                       1233 00111$:
                                   1234 ;	quantum/action.c:530: del_owned_mods(mods);
      00759A 8D 82            [24] 1235 	mov	dpl, r5
      00759C 12 7F 7A         [24] 1236 	lcall	_del_owned_mods
      00759F 80 05            [24] 1237 	sjmp	00113$
      0075A1                       1238 00112$:
                                   1239 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      0075A1 8D 82            [24] 1240 	mov	dpl, r5
      0075A3 12 7F 98         [24] 1241 	lcall	_del_owned_weak_mods
      0075A6                       1242 00113$:
                                   1243 ;	quantum/action.c:534: send_keyboard_report();
      0075A6 12 82 A3         [24] 1244 	lcall	_send_keyboard_report
                                   1245 ;	quantum/action.c:537: } break;
      0075A9 02 77 89         [24] 1246 	ljmp	00181$
                                   1247 ;	quantum/action.c:614: case ACT_USAGE:
      0075AC                       1248 00123$:
                                   1249 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0075AC 74 07            [12] 1250 	mov	a,#0x07
      0075AE 12 38 31         [24] 1251 	lcall	_ak820_outline_0022
      0075B1 12 48 26         [24] 1252 	lcall	_ak820_outline_0008
      0075B4 C3               [12] 1253 	clr	c
      0075B5 EC               [12] 1254 	mov	a,r4
      0075B6 94 A5            [12] 1255 	subb	a,#0xa5
      0075B8 ED               [12] 1256 	mov	a,r5
      0075B9 94 00            [12] 1257 	subb	a,#0x00
      0075BB 40 15            [24] 1258 	jc	00125$
      0075BD 74 C2            [12] 1259 	mov	a,#0xc2
      0075BF 9C               [12] 1260 	subb	a,r4
      0075C0 E4               [12] 1261 	clr	a
      0075C1 9D               [12] 1262 	subb	a,r5
      0075C2 40 0E            [24] 1263 	jc	00125$
                                   1264 ;	free result
                                   1265 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      0075C4 90 0A AE         [24] 1266 	mov	dptr,#_owned_usage_key_PARM_2
      0075C7 E5 27            [12] 1267 	mov	a,_process_action_sloc0_1_0
      0075C9 F0               [24] 1268 	movx	@dptr,a
      0075CA 8E 82            [24] 1269 	mov	dpl, r6
      0075CC 12 81 4E         [24] 1270 	lcall	_owned_usage_key
                                   1271 ;	quantum/action.c:622: break;
      0075CF 02 77 89         [24] 1272 	ljmp	00181$
      0075D2                       1273 00125$:
                                   1274 ;	quantum/action.c:625: switch (action.usage.page) {
      0075D2 12 79 D4         [24] 1275 	lcall	_ak820_outline_0089
      0075D5 FF               [12] 1276 	mov	r7,a
      0075D6 60 08            [24] 1277 	jz	00127$
      0075D8 BF 01 02         [24] 1278 	cjne	r7,#0x01,00452$
      0075DB 80 19            [24] 1279 	sjmp	00128$
      0075DD                       1280 00452$:
      0075DD 02 77 89         [24] 1281 	ljmp	00181$
                                   1282 ;	quantum/action.c:626: case PAGE_SYSTEM:
      0075E0                       1283 00127$:
                                   1284 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      0075E0 E5 27            [12] 1285 	mov	a,_process_action_sloc0_1_0
      0075E2 60 05            [24] 1286 	jz	00196$
      0075E4 12 79 E4         [24] 1287 	lcall	_ak820_outline_0130
      0075E7 80 04            [24] 1288 	sjmp	00197$
      0075E9                       1289 00196$:
      0075E9 7E 00            [12] 1290 	mov	r6,#0x00
      0075EB 7F 00            [12] 1291 	mov	r7,#0x00
      0075ED                       1292 00197$:
      0075ED 12 38 8C         [24] 1293 	lcall	_ak820_outline_0118
      0075F0 12 6F 78         [24] 1294 	lcall	_host_system_send
                                   1295 ;	quantum/action.c:628: break;
      0075F3 02 77 89         [24] 1296 	ljmp	00181$
                                   1297 ;	quantum/action.c:629: case PAGE_CONSUMER:
      0075F6                       1298 00128$:
                                   1299 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      0075F6 E5 27            [12] 1300 	mov	a,_process_action_sloc0_1_0
      0075F8 60 05            [24] 1301 	jz	00198$
      0075FA 12 79 E4         [24] 1302 	lcall	_ak820_outline_0130
      0075FD 80 04            [24] 1303 	sjmp	00199$
      0075FF                       1304 00198$:
      0075FF 7E 00            [12] 1305 	mov	r6,#0x00
      007601 7F 00            [12] 1306 	mov	r7,#0x00
      007603                       1307 00199$:
      007603 12 38 8C         [24] 1308 	lcall	_ak820_outline_0118
      007606 12 6F A8         [24] 1309 	lcall	_host_consumer_send
                                   1310 ;	quantum/action.c:633: break;
      007609 02 77 89         [24] 1311 	ljmp	00181$
                                   1312 ;	quantum/action.c:636: case ACT_MOUSEKEY:
      00760C                       1313 00130$:
                                   1314 ;	quantum/action.c:637: register_mouse(action.key.code, pressed);
      00760C 12 7A 05         [24] 1315 	lcall	_ak820_outline_0151
      00760F FF               [12] 1316 	mov	r7,a
      007610 90 08 4B         [24] 1317 	mov	dptr,#_register_mouse_PARM_2
      007613 E5 27            [12] 1318 	mov	a,_process_action_sloc0_1_0
      007615 F0               [24] 1319 	movx	@dptr,a
      007616 8F 82            [24] 1320 	mov	dpl, r7
      007618 12 74 B3         [24] 1321 	lcall	_register_mouse
                                   1322 ;	quantum/action.c:638: break;
      00761B 02 77 89         [24] 1323 	ljmp	00181$
                                   1324 ;	quantum/action.c:640: case ACT_LAYER: {
      00761E                       1325 00131$:
                                   1326 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      00761E 90 08 4E         [24] 1327 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007621 E0               [24] 1328 	movx	a,@dptr
      007622 54 03            [12] 1329 	anl	a,#0x03
      007624 90 08 52         [24] 1330 	mov	dptr,#_process_action_on_40000_680
      007627 F0               [24] 1331 	movx	@dptr,a
                                   1332 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007628 E0               [24] 1333 	movx	a,@dptr
      007629 FF               [12] 1334 	mov	r7,a
      00762A 60 11            [24] 1335 	jz	00200$
      00762C E5 27            [12] 1336 	mov	a,_process_action_sloc0_1_0
      00762E 60 07            [24] 1337 	jz	00202$
      007630 8F 06            [24] 1338 	mov	ar6,r7
      007632 53 06 01         [24] 1339 	anl	ar6,#0x01
      007635 80 10            [24] 1340 	sjmp	00201$
      007637                       1341 00202$:
      007637 74 02            [12] 1342 	mov	a,#0x02
      007639 5F               [12] 1343 	anl	a,r7
      00763A FE               [12] 1344 	mov	r6,a
      00763B 80 0A            [24] 1345 	sjmp	00201$
      00763D                       1346 00200$:
      00763D E5 27            [12] 1347 	mov	a,_process_action_sloc0_1_0
      00763F B4 01 00         [24] 1348 	cjne	a,#0x01,00457$
      007642                       1349 00457$:
      007642 92 1F            [24] 1350 	mov  _process_action_sloc1_1_0,c
      007644 E4               [12] 1351 	clr	a
      007645 33               [12] 1352 	rlc	a
      007646 FE               [12] 1353 	mov	r6,a
      007647                       1354 00201$:
      007647 EE               [12] 1355 	mov	a,r6
      007648 70 03            [24] 1356 	jnz	00458$
      00764A 02 77 89         [24] 1357 	ljmp	00181$
      00764D                       1358 00458$:
                                   1359 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      00764D 12 7A 05         [24] 1360 	lcall	_ak820_outline_0151
      007650 C4               [12] 1361 	swap	a
      007651 03               [12] 1362 	rr	a
      007652 54 07            [12] 1363 	anl	a,#0x07
      007654 25 E0            [12] 1364 	add	a,acc
      007656 25 E0            [12] 1365 	add	a,acc
      007658 FF               [12] 1366 	mov	r7,a
                                   1367 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      007659 12 7A 05         [24] 1368 	lcall	_ak820_outline_0151
      00765C 54 0F            [12] 1369 	anl	a,#0x0f
      00765E FE               [12] 1370 	mov	r6,a
      00765F 8F F0            [24] 1371 	mov	b,r7
      007661 05 F0            [12] 1372 	inc	b
      007663 EE               [12] 1373 	mov	a,r6
      007664 80 02            [24] 1374 	sjmp	00460$
      007666                       1375 00459$:
      007666 25 E0            [12] 1376 	add	a,acc
      007668                       1377 00460$:
      007668 D5 F0 FB         [24] 1378 	djnz	b,00459$
      00766B FE               [12] 1379 	mov	r6,a
                                   1380 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      00766C 12 7A 05         [24] 1381 	lcall	_ak820_outline_0151
      00766F 30 E4 11         [24] 1382 	jnb	acc.4,00204$
      007672 8F F0            [24] 1383 	mov	b,r7
      007674 05 F0            [12] 1384 	inc	b
      007676 74 0F            [12] 1385 	mov	a,#0x0f
      007678 80 02            [24] 1386 	sjmp	00463$
      00767A                       1387 00462$:
      00767A 25 E0            [12] 1388 	add	a,acc
      00767C                       1389 00463$:
      00767C D5 F0 FB         [24] 1390 	djnz	b,00462$
      00767F F4               [12] 1391 	cpl	a
      007680 FF               [12] 1392 	mov	r7,a
      007681 80 02            [24] 1393 	sjmp	00205$
      007683                       1394 00204$:
      007683 7F 00            [12] 1395 	mov	r7,#0x00
      007685                       1396 00205$:
                                   1397 ;	quantum/action.c:648: bits |= mask;
      007685 EE               [12] 1398 	mov	a,r6
      007686 42 07            [12] 1399 	orl	ar7,a
                                   1400 ;	quantum/action.c:649: if (!on) {
      007688 90 08 52         [24] 1401 	mov	dptr,#_process_action_on_40000_680
      00768B E0               [24] 1402 	movx	a,@dptr
      00768C 70 31            [24] 1403 	jnz	00143$
                                   1404 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      00768E 12 79 D4         [24] 1405 	lcall	_ak820_outline_0089
      007691 FE               [12] 1406 	mov	r6,a
      007692 2E               [12] 1407 	add	a,r6
                                   1408 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      007693 90 76 97         [24] 1409 	mov	dptr,#00465$
      007696 73               [24] 1410 	jmp	@a+dptr
      007697                       1411 00465$:
      007697 80 06            [24] 1412 	sjmp	00132$
      007699 80 0C            [24] 1413 	sjmp	00133$
      00769B 80 12            [24] 1414 	sjmp	00134$
      00769D 80 18            [24] 1415 	sjmp	00135$
      00769F                       1416 00132$:
      00769F 8F 82            [24] 1417 	mov	dpl, r7
      0076A1 12 7A 5E         [24] 1418 	lcall	_default_layer_and
      0076A4 02 77 89         [24] 1419 	ljmp	00181$
                                   1420 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      0076A7                       1421 00133$:
      0076A7 8F 82            [24] 1422 	mov	dpl, r7
      0076A9 12 7A 4D         [24] 1423 	lcall	_default_layer_or
      0076AC 02 77 89         [24] 1424 	ljmp	00181$
                                   1425 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      0076AF                       1426 00134$:
      0076AF 8F 82            [24] 1427 	mov	dpl, r7
      0076B1 12 7A 74         [24] 1428 	lcall	_default_layer_xor
      0076B4 02 77 89         [24] 1429 	ljmp	00181$
                                   1430 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      0076B7                       1431 00135$:
      0076B7 8F 82            [24] 1432 	mov	dpl, r7
      0076B9 12 7A 42         [24] 1433 	lcall	_default_layer_set
                                   1434 ;	quantum/action.c:655: }
      0076BC 02 77 89         [24] 1435 	ljmp	00181$
      0076BF                       1436 00143$:
                                   1437 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      0076BF 12 79 D4         [24] 1438 	lcall	_ak820_outline_0089
      0076C2 FE               [12] 1439 	mov	r6,a
      0076C3 2E               [12] 1440 	add	a,r6
                                   1441 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      0076C4 90 76 C8         [24] 1442 	mov	dptr,#00466$
      0076C7 73               [24] 1443 	jmp	@a+dptr
      0076C8                       1444 00466$:
      0076C8 80 06            [24] 1445 	sjmp	00137$
      0076CA 80 0C            [24] 1446 	sjmp	00138$
      0076CC 80 12            [24] 1447 	sjmp	00139$
      0076CE 80 18            [24] 1448 	sjmp	00140$
      0076D0                       1449 00137$:
      0076D0 8F 82            [24] 1450 	mov	dpl, r7
      0076D2 12 7B F8         [24] 1451 	lcall	_layer_and
      0076D5 02 77 89         [24] 1452 	ljmp	00181$
                                   1453 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      0076D8                       1454 00138$:
      0076D8 8F 82            [24] 1455 	mov	dpl, r7
      0076DA 12 7B E7         [24] 1456 	lcall	_layer_or
      0076DD 02 77 89         [24] 1457 	ljmp	00181$
                                   1458 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      0076E0                       1459 00139$:
      0076E0 8F 82            [24] 1460 	mov	dpl, r7
      0076E2 12 7C 0E         [24] 1461 	lcall	_layer_xor
      0076E5 02 77 89         [24] 1462 	ljmp	00181$
                                   1463 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      0076E8                       1464 00140$:
      0076E8 8F 82            [24] 1465 	mov	dpl, r7
      0076EA 12 7B 84         [24] 1466 	lcall	_layer_state_set
                                   1467 ;	quantum/action.c:665: break;
      0076ED 02 77 89         [24] 1468 	ljmp	00181$
                                   1469 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      0076F0                       1470 00147$:
                                   1471 ;	quantum/action.c:668: if (pressed) {
      0076F0 E5 27            [12] 1472 	mov	a,_process_action_sloc0_1_0
      0076F2 60 11            [24] 1473 	jz	00149$
                                   1474 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      0076F4 12 79 DD         [24] 1475 	lcall	_ak820_outline_0113
      0076F7 F5 82            [12] 1476 	mov	dpl,a
      0076F9 12 7A E4         [24] 1477 	lcall	_layer_hold_on
                                   1478 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      0076FC 12 79 CD         [24] 1479 	lcall	_ak820_outline_0078
      0076FF 12 78 F0         [24] 1480 	lcall	_register_mods
      007702 02 77 89         [24] 1481 	ljmp	00181$
      007705                       1482 00149$:
                                   1483 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      007705 12 79 CD         [24] 1484 	lcall	_ak820_outline_0078
      007708 12 79 04         [24] 1485 	lcall	_unregister_mods
                                   1486 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      00770B 12 79 DD         [24] 1487 	lcall	_ak820_outline_0113
      00770E F5 82            [12] 1488 	mov	dpl,a
      007710 12 7B 1C         [24] 1489 	lcall	_layer_hold_off
                                   1490 ;	quantum/action.c:675: break;
      007713 02 77 89         [24] 1491 	ljmp	00181$
                                   1492 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      007716                       1493 00152$:
                                   1494 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      007716 12 7A 05         [24] 1495 	lcall	_ak820_outline_0151
      007719 FF               [12] 1496 	mov	r7,a
      00771A BF F1 02         [24] 1497 	cjne	r7,#0xf1,00468$
      00771D 80 0A            [24] 1498 	sjmp	00154$
      00771F                       1499 00468$:
      00771F BF F2 02         [24] 1500 	cjne	r7,#0xf2,00469$
      007722 80 19            [24] 1501 	sjmp	00155$
      007724                       1502 00469$:
                                   1503 ;	quantum/action.c:694: momentary_layer_action:
      007724 BF F3 3B         [24] 1504 	cjne	r7,#0xf3,00160$
      007727 80 28            [24] 1505 	sjmp	00156$
      007729                       1506 00154$:
                                   1507 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007729 E5 27            [12] 1508 	mov	a,_process_action_sloc0_1_0
      00772B 60 08            [24] 1509 	jz	00206$
      00772D 12 79 B3         [24] 1510 	lcall	_ak820_outline_0042
      007730 12 7A E4         [24] 1511 	lcall	_layer_hold_on
      007733 80 54            [24] 1512 	sjmp	00181$
      007735                       1513 00206$:
      007735 12 79 B3         [24] 1514 	lcall	_ak820_outline_0042
      007738 12 7B 1C         [24] 1515 	lcall	_layer_hold_off
                                   1516 ;	quantum/action.c:696: break;
                                   1517 ;	quantum/action.c:697: case OP_OFF_ON:
      00773B 80 4C            [24] 1518 	sjmp	00181$
      00773D                       1519 00155$:
                                   1520 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      00773D E5 27            [12] 1521 	mov	a,_process_action_sloc0_1_0
      00773F 60 08            [24] 1522 	jz	00208$
      007741 12 79 B3         [24] 1523 	lcall	_ak820_outline_0042
      007744 12 7B C9         [24] 1524 	lcall	_layer_off
      007747 80 40            [24] 1525 	sjmp	00181$
      007749                       1526 00208$:
      007749 12 79 B3         [24] 1527 	lcall	_ak820_outline_0042
      00774C 12 7B AE         [24] 1528 	lcall	_layer_on
                                   1529 ;	quantum/action.c:699: break;
                                   1530 ;	quantum/action.c:700: case OP_SET_CLEAR:
      00774F 80 38            [24] 1531 	sjmp	00181$
      007751                       1532 00156$:
                                   1533 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007751 E5 27            [12] 1534 	mov	a,_process_action_sloc0_1_0
      007753 60 08            [24] 1535 	jz	00210$
      007755 12 79 B3         [24] 1536 	lcall	_ak820_outline_0042
      007758 12 7B 98         [24] 1537 	lcall	_layer_move
      00775B 80 2C            [24] 1538 	sjmp	00181$
      00775D                       1539 00210$:
      00775D 12 7B 92         [24] 1540 	lcall	_layer_clear
                                   1541 ;	quantum/action.c:702: break;
                                   1542 ;	quantum/action.c:748: default:
      007760 80 27            [24] 1543 	sjmp	00181$
      007762                       1544 00160$:
                                   1545 ;	quantum/action.c:755: if (pressed) {
      007762 E5 27            [12] 1546 	mov	a,_process_action_sloc0_1_0
      007764 60 08            [24] 1547 	jz	00163$
                                   1548 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      007766 12 79 CD         [24] 1549 	lcall	_ak820_outline_0078
      007769 12 77 A0         [24] 1550 	lcall	_register_code
                                   1551 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      00776C 80 1B            [24] 1552 	sjmp	00181$
      00776E                       1553 00163$:
                                   1554 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      00776E 12 7A 05         [24] 1555 	lcall	_ak820_outline_0151
      007771 FF               [12] 1556 	mov	r7,a
      007772 BF 39 0E         [24] 1557 	cjne	r7,#0x39,00175$
                                   1558 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      007775 7F 50            [12] 1559 	mov	r7,#0x50
      007777                       1560 00187$:
      007777 EF               [12] 1561 	mov	a,r7
      007778 60 09            [24] 1562 	jz	00175$
      00777A 90 00 01         [24] 1563 	mov	dptr,#0x0001
      00777D 12 5B 4C         [24] 1564 	lcall	_mDelaymS
      007780 1F               [12] 1565 	dec	r7
                                   1566 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      007781 80 F4            [24] 1567 	sjmp	00187$
      007783                       1568 00175$:
                                   1569 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      007783 12 79 CD         [24] 1570 	lcall	_ak820_outline_0078
      007786 12 78 25         [24] 1571 	lcall	_unregister_code
                                   1572 ;	quantum/action.c:848: }
      007789                       1573 00181$:
                                   1574 ;	quantum/action.c:869: switch (action.kind.id) {
      007789 90 08 4E         [24] 1575 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00778C E0               [24] 1576 	movx	a,@dptr
      00778D C4               [12] 1577 	swap	a
      00778E 54 0F            [12] 1578 	anl	a,#0x0f
      007790 FF               [12] 1579 	mov	r7,a
      007791 BF 08 02         [24] 1580 	cjne	r7,#0x08,00478$
      007794 80 03            [24] 1581 	sjmp	00183$
      007796                       1582 00478$:
      007796 BF 09 06         [24] 1583 	cjne	r7,#0x09,00192$
                                   1584 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      007799                       1585 00183$:
                                   1586 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      007799 12 6E DD         [24] 1587 	lcall	_host_keyboard_leds
                                   1588 ;	quantum/action.c:880: }
                                   1589 ;	quantum/action.c:933: }
      00779C 02 99 E7         [24] 1590 	ljmp	_led_set
      00779F                       1591 00192$:
      00779F 22               [24] 1592 	ret
                                   1593 ;------------------------------------------------------------
                                   1594 ;Allocation info for local variables in function 'register_code'
                                   1595 ;------------------------------------------------------------
                                   1596 ;code          Allocated with name '_register_code_code_10000_714'
                                   1597 ;------------------------------------------------------------
                                   1598 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1599 ;	-----------------------------------------
                                   1600 ;	 function register_code
                                   1601 ;	-----------------------------------------
      0077A0                       1602 _register_code:
      0077A0 E5 82            [12] 1603 	mov	a,dpl
      0077A2 90 08 53         [24] 1604 	mov	dptr,#_register_code_code_10000_714
      0077A5 F0               [24] 1605 	movx	@dptr,a
                                   1606 ;	quantum/action.c:940: if (code == KC_NO) {
      0077A6 E0               [24] 1607 	movx	a,@dptr
      0077A7 FF               [12] 1608 	mov	r7,a
      0077A8 70 01            [24] 1609 	jnz	00123$
                                   1610 ;	quantum/action.c:941: return;
      0077AA 22               [24] 1611 	ret
      0077AB                       1612 00123$:
                                   1613 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      0077AB BF 04 00         [24] 1614 	cjne	r7,#0x04,00198$
      0077AE                       1615 00198$:
      0077AE 40 12            [24] 1616 	jc	00119$
      0077B0 EF               [12] 1617 	mov	a,r7
      0077B1 24 5B            [12] 1618 	add	a,#0xff - 0xa4
      0077B3 40 0D            [24] 1619 	jc	00119$
                                   1620 ;	free result
                                   1621 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      0077B5 8F 82            [24] 1622 	mov	dpl, r7
      0077B7 12 80 0D         [24] 1623 	lcall	_add_owned_key
      0077BA E5 82            [12] 1624 	mov	a, dpl
      0077BC 70 01            [24] 1625 	jnz	00104$
      0077BE 22               [24] 1626 	ret
      0077BF                       1627 00104$:
                                   1628 ;	quantum/action.c:995: send_keyboard_report();
      0077BF 02 82 A3         [24] 1629 	ljmp	_send_keyboard_report
      0077C2                       1630 00119$:
                                   1631 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      0077C2 12 79 EF         [24] 1632 	lcall	_ak820_outline_0141
      0077C5 BF E0 00         [24] 1633 	cjne	r7,#0xe0,00202$
      0077C8                       1634 00202$:
      0077C8 40 1A            [24] 1635 	jc	00115$
      0077CA EF               [12] 1636 	mov	a,r7
      0077CB 24 18            [12] 1637 	add	a,#0xff - 0xe7
      0077CD 40 15            [24] 1638 	jc	00115$
                                   1639 ;	free result
                                   1640 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      0077CF 74 07            [12] 1641 	mov	a,#0x07
      0077D1 5F               [12] 1642 	anl	a,r7
      0077D2 12 79 BC         [24] 1643 	lcall	_ak820_outline_0061
      0077D5 80 02            [24] 1644 	sjmp	00206$
      0077D7                       1645 00205$:
      0077D7 25 E0            [12] 1646 	add	a,acc
      0077D9                       1647 00206$:
      0077D9 D5 F0 FB         [24] 1648 	djnz	b,00205$
      0077DC F5 82            [12] 1649 	mov	dpl,a
      0077DE 12 7F 6A         [24] 1650 	lcall	_add_owned_mods
                                   1651 ;	quantum/action.c:998: send_keyboard_report();
      0077E1 02 82 A3         [24] 1652 	ljmp	_send_keyboard_report
      0077E4                       1653 00115$:
                                   1654 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0077E4 12 79 EF         [24] 1655 	lcall	_ak820_outline_0141
      0077E7 BF A5 00         [24] 1656 	cjne	r7,#0xa5,00207$
      0077EA                       1657 00207$:
      0077EA 40 05            [24] 1658 	jc	00113$
      0077EC EF               [12] 1659 	mov	a,r7
      0077ED 24 58            [12] 1660 	add	a,#0xff - 0xa7
      0077EF 50 0D            [24] 1661 	jnc	00108$
                                   1662 ;	free result
      0077F1                       1663 00113$:
      0077F1 12 79 EF         [24] 1664 	lcall	_ak820_outline_0141
      0077F4 BF A8 00         [24] 1665 	cjne	r7,#0xa8,00210$
      0077F7                       1666 00210$:
      0077F7 40 13            [24] 1667 	jc	00109$
      0077F9 EF               [12] 1668 	mov	a,r7
      0077FA 24 3D            [12] 1669 	add	a,#0xff - 0xc2
      0077FC 40 0E            [24] 1670 	jc	00109$
                                   1671 ;	free result
      0077FE                       1672 00108$:
                                   1673 ;	quantum/action.c:1003: owned_usage_key(code, true);
      0077FE 12 79 EF         [24] 1674 	lcall	_ak820_outline_0141
      007801 90 0A AE         [24] 1675 	mov	dptr,#_owned_usage_key_PARM_2
      007804 74 01            [12] 1676 	mov	a,#0x01
      007806 F0               [24] 1677 	movx	@dptr,a
      007807 8F 82            [24] 1678 	mov	dpl, r7
      007809 02 81 4E         [24] 1679 	ljmp	_owned_usage_key
      00780C                       1680 00109$:
                                   1681 ;	quantum/action.c:1010: } else if (IS_MOUSE_KEYCODE(code)) {
      00780C 12 79 EF         [24] 1682 	lcall	_ak820_outline_0141
      00780F BF CD 00         [24] 1683 	cjne	r7,#0xcd,00213$
      007812                       1684 00213$:
      007812 40 10            [24] 1685 	jc	00125$
      007814 EF               [12] 1686 	mov	a,r7
      007815 24 20            [12] 1687 	add	a,#0xff - 0xdf
      007817 40 0B            [24] 1688 	jc	00125$
                                   1689 ;	free result
                                   1690 ;	quantum/action.c:1011: register_mouse(code, true);
      007819 90 08 4B         [24] 1691 	mov	dptr,#_register_mouse_PARM_2
      00781C 74 01            [12] 1692 	mov	a,#0x01
      00781E F0               [24] 1693 	movx	@dptr,a
      00781F 8F 82            [24] 1694 	mov	dpl, r7
                                   1695 ;	quantum/action.c:1013: }
      007821 02 74 B3         [24] 1696 	ljmp	_register_mouse
      007824                       1697 00125$:
      007824 22               [24] 1698 	ret
                                   1699 ;------------------------------------------------------------
                                   1700 ;Allocation info for local variables in function 'unregister_code'
                                   1701 ;------------------------------------------------------------
                                   1702 ;code          Allocated with name '_unregister_code_code_10000_728'
                                   1703 ;------------------------------------------------------------
                                   1704 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1705 ;	-----------------------------------------
                                   1706 ;	 function unregister_code
                                   1707 ;	-----------------------------------------
      007825                       1708 _unregister_code:
      007825 E5 82            [12] 1709 	mov	a,dpl
      007827 90 08 54         [24] 1710 	mov	dptr,#_unregister_code_code_10000_728
      00782A F0               [24] 1711 	movx	@dptr,a
                                   1712 ;	quantum/action.c:1020: if (code == KC_NO) {
      00782B E0               [24] 1713 	movx	a,@dptr
      00782C FF               [12] 1714 	mov	r7,a
      00782D 70 01            [24] 1715 	jnz	00121$
                                   1716 ;	quantum/action.c:1021: return;
      00782F 22               [24] 1717 	ret
      007830                       1718 00121$:
                                   1719 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      007830 BF 04 00         [24] 1720 	cjne	r7,#0x04,00196$
      007833                       1721 00196$:
      007833 40 12            [24] 1722 	jc	00117$
      007835 EF               [12] 1723 	mov	a,r7
      007836 24 5B            [12] 1724 	add	a,#0xff - 0xa4
      007838 40 0D            [24] 1725 	jc	00117$
                                   1726 ;	free result
                                   1727 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      00783A 8F 82            [24] 1728 	mov	dpl, r7
      00783C 12 80 87         [24] 1729 	lcall	_del_owned_key
      00783F E5 82            [12] 1730 	mov	a, dpl
      007841 70 01            [24] 1731 	jnz	00102$
      007843 22               [24] 1732 	ret
      007844                       1733 00102$:
                                   1734 ;	quantum/action.c:1062: send_keyboard_report();
      007844 02 82 A3         [24] 1735 	ljmp	_send_keyboard_report
      007847                       1736 00117$:
                                   1737 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      007847 12 79 F5         [24] 1738 	lcall	_ak820_outline_0142
      00784A BF E0 00         [24] 1739 	cjne	r7,#0xe0,00200$
      00784D                       1740 00200$:
      00784D 40 1A            [24] 1741 	jc	00113$
      00784F EF               [12] 1742 	mov	a,r7
      007850 24 18            [12] 1743 	add	a,#0xff - 0xe7
      007852 40 15            [24] 1744 	jc	00113$
                                   1745 ;	free result
                                   1746 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      007854 74 07            [12] 1747 	mov	a,#0x07
      007856 5F               [12] 1748 	anl	a,r7
      007857 12 79 BC         [24] 1749 	lcall	_ak820_outline_0061
      00785A 80 02            [24] 1750 	sjmp	00204$
      00785C                       1751 00203$:
      00785C 25 E0            [12] 1752 	add	a,acc
      00785E                       1753 00204$:
      00785E D5 F0 FB         [24] 1754 	djnz	b,00203$
      007861 F5 82            [12] 1755 	mov	dpl,a
      007863 12 7F 7A         [24] 1756 	lcall	_del_owned_mods
                                   1757 ;	quantum/action.c:1065: send_keyboard_report();
      007866 02 82 A3         [24] 1758 	ljmp	_send_keyboard_report
      007869                       1759 00113$:
                                   1760 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007869 12 79 F5         [24] 1761 	lcall	_ak820_outline_0142
      00786C BF A5 00         [24] 1762 	cjne	r7,#0xa5,00205$
      00786F                       1763 00205$:
      00786F 40 05            [24] 1764 	jc	00111$
      007871 EF               [12] 1765 	mov	a,r7
      007872 24 58            [12] 1766 	add	a,#0xff - 0xa7
      007874 50 0D            [24] 1767 	jnc	00106$
                                   1768 ;	free result
      007876                       1769 00111$:
      007876 12 79 F5         [24] 1770 	lcall	_ak820_outline_0142
      007879 BF A8 00         [24] 1771 	cjne	r7,#0xa8,00208$
      00787C                       1772 00208$:
      00787C 40 11            [24] 1773 	jc	00107$
      00787E EF               [12] 1774 	mov	a,r7
      00787F 24 3D            [12] 1775 	add	a,#0xff - 0xc2
      007881 40 0C            [24] 1776 	jc	00107$
                                   1777 ;	free result
      007883                       1778 00106$:
                                   1779 ;	quantum/action.c:1070: owned_usage_key(code, false);
      007883 12 79 F5         [24] 1780 	lcall	_ak820_outline_0142
      007886 90 0A AE         [24] 1781 	mov	dptr,#_owned_usage_key_PARM_2
      007889 12 7A 0F         [24] 1782 	lcall	_ak820_outline_0189
      00788C 02 81 4E         [24] 1783 	ljmp	_owned_usage_key
      00788F                       1784 00107$:
                                   1785 ;	quantum/action.c:1077: } else if (IS_MOUSE_KEYCODE(code)) {
      00788F 12 79 F5         [24] 1786 	lcall	_ak820_outline_0142
      007892 BF CD 00         [24] 1787 	cjne	r7,#0xcd,00211$
      007895                       1788 00211$:
      007895 40 0E            [24] 1789 	jc	00123$
      007897 EF               [12] 1790 	mov	a,r7
      007898 24 20            [12] 1791 	add	a,#0xff - 0xdf
      00789A 40 09            [24] 1792 	jc	00123$
                                   1793 ;	free result
                                   1794 ;	quantum/action.c:1078: register_mouse(code, false);
      00789C 90 08 4B         [24] 1795 	mov	dptr,#_register_mouse_PARM_2
      00789F 12 7A 0F         [24] 1796 	lcall	_ak820_outline_0189
                                   1797 ;	quantum/action.c:1080: }
      0078A2 02 74 B3         [24] 1798 	ljmp	_register_mouse
      0078A5                       1799 00123$:
      0078A5 22               [24] 1800 	ret
                                   1801 ;------------------------------------------------------------
                                   1802 ;Allocation info for local variables in function 'tap_code_delay'
                                   1803 ;------------------------------------------------------------
                                   1804 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1805 ;code          Allocated with name '_tap_code_delay_code_10000_741'
                                   1806 ;i             Allocated with name '_tap_code_delay_i_20000_743'
                                   1807 ;i             Allocated with name '_tap_code_delay_i_50000_746'
                                   1808 ;------------------------------------------------------------
                                   1809 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1810 ;	-----------------------------------------
                                   1811 ;	 function tap_code_delay
                                   1812 ;	-----------------------------------------
      0078A6                       1813 _tap_code_delay:
      0078A6 E5 82            [12] 1814 	mov	a,dpl
      0078A8 90 08 57         [24] 1815 	mov	dptr,#_tap_code_delay_code_10000_741
      0078AB F0               [24] 1816 	movx	@dptr,a
                                   1817 ;	quantum/action.c:1088: register_code(code);
      0078AC E0               [24] 1818 	movx	a,@dptr
      0078AD FF               [12] 1819 	mov	r7,a
      0078AE F5 82            [12] 1820 	mov	dpl,a
      0078B0 C0 07            [24] 1821 	push	ar7
      0078B2 12 77 A0         [24] 1822 	lcall	_register_code
      0078B5 D0 07            [24] 1823 	pop	ar7
                                   1824 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      0078B7 90 08 55         [24] 1825 	mov	dptr,#_tap_code_delay_PARM_2
      0078BA 12 38 64         [24] 1826 	lcall	_ak820_outline_0079
      0078BD                       1827 00110$:
      0078BD ED               [12] 1828 	mov	a,r5
      0078BE 4E               [12] 1829 	orl	a,r6
      0078BF 60 0D            [24] 1830 	jz	00105$
                                   1831 ;	quantum/action.c:1090: wait_ms(1);
      0078C1 90 00 01         [24] 1832 	mov	dptr,#0x0001
      0078C4 12 5B 4C         [24] 1833 	lcall	_mDelaymS
                                   1834 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      0078C7 1D               [12] 1835 	dec	r5
      0078C8 BD FF 01         [24] 1836 	cjne	r5,#0xff,00141$
      0078CB 1E               [12] 1837 	dec	r6
      0078CC                       1838 00141$:
      0078CC 80 EF            [24] 1839 	sjmp	00110$
      0078CE                       1840 00105$:
                                   1841 ;	quantum/action.c:1092: unregister_code(code);
      0078CE 8F 82            [24] 1842 	mov	dpl, r7
                                   1843 ;	quantum/action.c:1093: }
      0078D0 02 78 25         [24] 1844 	ljmp	_unregister_code
                                   1845 ;------------------------------------------------------------
                                   1846 ;Allocation info for local variables in function 'tap_code'
                                   1847 ;------------------------------------------------------------
                                   1848 ;code          Allocated with name '_tap_code_code_10000_748'
                                   1849 ;------------------------------------------------------------
                                   1850 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1851 ;	-----------------------------------------
                                   1852 ;	 function tap_code
                                   1853 ;	-----------------------------------------
      0078D3                       1854 _tap_code:
      0078D3 E5 82            [12] 1855 	mov	a,dpl
      0078D5 90 08 58         [24] 1856 	mov	dptr,#_tap_code_code_10000_748
      0078D8 F0               [24] 1857 	movx	@dptr,a
                                   1858 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0078D9 E0               [24] 1859 	movx	a,@dptr
      0078DA FF               [12] 1860 	mov	r7,a
      0078DB BF 39 04         [24] 1861 	cjne	r7,#0x39,00103$
      0078DE 7E 50            [12] 1862 	mov	r6,#0x50
      0078E0 80 02            [24] 1863 	sjmp	00104$
      0078E2                       1864 00103$:
      0078E2 7E 00            [12] 1865 	mov	r6,#0x00
      0078E4                       1866 00104$:
      0078E4 90 08 55         [24] 1867 	mov	dptr,#_tap_code_delay_PARM_2
      0078E7 EE               [12] 1868 	mov	a,r6
      0078E8 12 38 9C         [24] 1869 	lcall	_ak820_outline_0134
      0078EB 8F 82            [24] 1870 	mov	dpl, r7
                                   1871 ;	quantum/action.c:1101: }
      0078ED 02 78 A6         [24] 1872 	ljmp	_tap_code_delay
                                   1873 ;------------------------------------------------------------
                                   1874 ;Allocation info for local variables in function 'register_mods'
                                   1875 ;------------------------------------------------------------
                                   1876 ;mods          Allocated with name '_register_mods_mods_10000_750'
                                   1877 ;------------------------------------------------------------
                                   1878 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1879 ;	-----------------------------------------
                                   1880 ;	 function register_mods
                                   1881 ;	-----------------------------------------
      0078F0                       1882 _register_mods:
      0078F0 E5 82            [12] 1883 	mov	a,dpl
      0078F2 90 08 59         [24] 1884 	mov	dptr,#_register_mods_mods_10000_750
      0078F5 F0               [24] 1885 	movx	@dptr,a
                                   1886 ;	quantum/action.c:1108: if (mods) {
      0078F6 E0               [24] 1887 	movx	a,@dptr
      0078F7 FF               [12] 1888 	mov	r7,a
      0078F8 E0               [24] 1889 	movx	a,@dptr
      0078F9 60 08            [24] 1890 	jz	00103$
                                   1891 ;	quantum/action.c:1109: add_owned_mods(mods);
      0078FB 8F 82            [24] 1892 	mov	dpl, r7
      0078FD 12 7F 6A         [24] 1893 	lcall	_add_owned_mods
                                   1894 ;	quantum/action.c:1110: send_keyboard_report();
                                   1895 ;	quantum/action.c:1112: }
      007900 02 82 A3         [24] 1896 	ljmp	_send_keyboard_report
      007903                       1897 00103$:
      007903 22               [24] 1898 	ret
                                   1899 ;------------------------------------------------------------
                                   1900 ;Allocation info for local variables in function 'unregister_mods'
                                   1901 ;------------------------------------------------------------
                                   1902 ;mods          Allocated with name '_unregister_mods_mods_10000_754'
                                   1903 ;------------------------------------------------------------
                                   1904 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1905 ;	-----------------------------------------
                                   1906 ;	 function unregister_mods
                                   1907 ;	-----------------------------------------
      007904                       1908 _unregister_mods:
      007904 E5 82            [12] 1909 	mov	a,dpl
      007906 90 08 5A         [24] 1910 	mov	dptr,#_unregister_mods_mods_10000_754
      007909 F0               [24] 1911 	movx	@dptr,a
                                   1912 ;	quantum/action.c:1119: if (mods) {
      00790A E0               [24] 1913 	movx	a,@dptr
      00790B FF               [12] 1914 	mov	r7,a
      00790C E0               [24] 1915 	movx	a,@dptr
      00790D 60 08            [24] 1916 	jz	00103$
                                   1917 ;	quantum/action.c:1120: del_owned_mods(mods);
      00790F 8F 82            [24] 1918 	mov	dpl, r7
      007911 12 7F 7A         [24] 1919 	lcall	_del_owned_mods
                                   1920 ;	quantum/action.c:1121: send_keyboard_report();
                                   1921 ;	quantum/action.c:1123: }
      007914 02 82 A3         [24] 1922 	ljmp	_send_keyboard_report
      007917                       1923 00103$:
      007917 22               [24] 1924 	ret
                                   1925 ;------------------------------------------------------------
                                   1926 ;Allocation info for local variables in function 'register_weak_mods'
                                   1927 ;------------------------------------------------------------
                                   1928 ;mods          Allocated with name '_register_weak_mods_mods_10000_758'
                                   1929 ;------------------------------------------------------------
                                   1930 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1931 ;	-----------------------------------------
                                   1932 ;	 function register_weak_mods
                                   1933 ;	-----------------------------------------
      007918                       1934 _register_weak_mods:
      007918 E5 82            [12] 1935 	mov	a,dpl
      00791A 90 08 5B         [24] 1936 	mov	dptr,#_register_weak_mods_mods_10000_758
      00791D F0               [24] 1937 	movx	@dptr,a
                                   1938 ;	quantum/action.c:1130: if (mods) {
      00791E E0               [24] 1939 	movx	a,@dptr
      00791F FF               [12] 1940 	mov	r7,a
      007920 E0               [24] 1941 	movx	a,@dptr
      007921 60 08            [24] 1942 	jz	00103$
                                   1943 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      007923 8F 82            [24] 1944 	mov	dpl, r7
      007925 12 7F 88         [24] 1945 	lcall	_add_owned_weak_mods
                                   1946 ;	quantum/action.c:1132: send_keyboard_report();
                                   1947 ;	quantum/action.c:1134: }
      007928 02 82 A3         [24] 1948 	ljmp	_send_keyboard_report
      00792B                       1949 00103$:
      00792B 22               [24] 1950 	ret
                                   1951 ;------------------------------------------------------------
                                   1952 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1953 ;------------------------------------------------------------
                                   1954 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_762'
                                   1955 ;------------------------------------------------------------
                                   1956 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1957 ;	-----------------------------------------
                                   1958 ;	 function unregister_weak_mods
                                   1959 ;	-----------------------------------------
      00792C                       1960 _unregister_weak_mods:
      00792C E5 82            [12] 1961 	mov	a,dpl
      00792E 90 08 5C         [24] 1962 	mov	dptr,#_unregister_weak_mods_mods_10000_762
      007931 F0               [24] 1963 	movx	@dptr,a
                                   1964 ;	quantum/action.c:1141: if (mods) {
      007932 E0               [24] 1965 	movx	a,@dptr
      007933 FF               [12] 1966 	mov	r7,a
      007934 E0               [24] 1967 	movx	a,@dptr
      007935 60 08            [24] 1968 	jz	00103$
                                   1969 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      007937 8F 82            [24] 1970 	mov	dpl, r7
      007939 12 7F 98         [24] 1971 	lcall	_del_owned_weak_mods
                                   1972 ;	quantum/action.c:1143: send_keyboard_report();
                                   1973 ;	quantum/action.c:1145: }
      00793C 02 82 A3         [24] 1974 	ljmp	_send_keyboard_report
      00793F                       1975 00103$:
      00793F 22               [24] 1976 	ret
                                   1977 ;------------------------------------------------------------
                                   1978 ;Allocation info for local variables in function 'clear_keyboard'
                                   1979 ;------------------------------------------------------------
                                   1980 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   1981 ;	-----------------------------------------
                                   1982 ;	 function clear_keyboard
                                   1983 ;	-----------------------------------------
      007940                       1984 _clear_keyboard:
                                   1985 ;	quantum/action.c:1152: clear_mods();
      007940 12 83 1E         [24] 1986 	lcall	_clear_mods
                                   1987 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   1988 ;	quantum/action.c:1154: }
      007943 02 79 46         [24] 1989 	ljmp	_clear_keyboard_but_mods
                                   1990 ;------------------------------------------------------------
                                   1991 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1992 ;------------------------------------------------------------
                                   1993 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   1994 ;	-----------------------------------------
                                   1995 ;	 function clear_keyboard_but_mods
                                   1996 ;	-----------------------------------------
      007946                       1997 _clear_keyboard_but_mods:
                                   1998 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007946 90 0D E0         [24] 1999 	mov	dptr,#_actual_keyboard_report
      007949 12 71 A4         [24] 2000 	lcall	_clear_keys_from_report
                                   2001 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   2002 ;	quantum/action.c:1163: }
      00794C 02 79 4F         [24] 2003 	ljmp	_clear_keyboard_but_mods_and_keys
                                   2004 ;------------------------------------------------------------
                                   2005 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   2006 ;------------------------------------------------------------
                                   2007 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   2008 ;	-----------------------------------------
                                   2009 ;	 function clear_keyboard_but_mods_and_keys
                                   2010 ;	-----------------------------------------
      00794F                       2011 _clear_keyboard_but_mods_and_keys:
                                   2012 ;	quantum/action.c:1171: ak820_tapping_cancel();
      00794F 12 46 CB         [24] 2013 	lcall	_ak820_tapping_cancel
                                   2014 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      007952 12 2E F0         [24] 2015 	lcall	_ak820_oneshot_cancel
                                   2016 ;	quantum/action.c:1185: ak820_combo_cancel();
      007955 12 35 70         [24] 2017 	lcall	_ak820_combo_cancel
                                   2018 ;	quantum/action.c:1188: repeat_key_cancel();
      007958 12 A3 DD         [24] 2019 	lcall	_repeat_key_cancel
                                   2020 ;	quantum/action.c:1190: clear_owned_mods();
      00795B 12 7F A8         [24] 2021 	lcall	_clear_owned_mods
                                   2022 ;	quantum/action.c:1191: clear_owned_keys();
      00795E 12 7F E0         [24] 2023 	lcall	_clear_owned_keys
                                   2024 ;	quantum/action.c:1192: clear_owned_usages();
      007961 12 81 16         [24] 2025 	lcall	_clear_owned_usages
                                   2026 ;	quantum/action.c:1193: layer_hold_clear();
      007964 12 7B 55         [24] 2027 	lcall	_layer_hold_clear
                                   2028 ;	quantum/action.c:1195: clear_macro_tri_layer();
      007967 12 9E 9C         [24] 2029 	lcall	_clear_macro_tri_layer
                                   2030 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00796A 90 0D E0         [24] 2031 	mov	dptr,#_actual_keyboard_report
      00796D 12 71 A4         [24] 2032 	lcall	_clear_keys_from_report
                                   2033 ;	quantum/action.c:1200: host_system_send(0);
      007970 90 00 00         [24] 2034 	mov	dptr,#0x0000
      007973 12 6F 78         [24] 2035 	lcall	_host_system_send
                                   2036 ;	quantum/action.c:1201: host_consumer_send(0);
      007976 90 00 00         [24] 2037 	mov	dptr,#0x0000
      007979 12 6F A8         [24] 2038 	lcall	_host_consumer_send
                                   2039 ;	quantum/action.c:1203: clear_weak_mods();
      00797C 12 83 53         [24] 2040 	lcall	_clear_weak_mods
                                   2041 ;	quantum/action.c:1204: send_keyboard_report();
      00797F 12 82 A3         [24] 2042 	lcall	_send_keyboard_report
                                   2043 ;	quantum/action.c:1206: mousekey_clear();
      007982 12 51 C2         [24] 2044 	lcall	_mousekey_clear
                                   2045 ;	quantum/action.c:1207: mousekey_send();
                                   2046 ;	quantum/action.c:1212: }
      007985 02 50 8A         [24] 2047 	ljmp	_mousekey_send
                                   2048 ;------------------------------------------------------------
                                   2049 ;Allocation info for local variables in function 'is_tap_record'
                                   2050 ;------------------------------------------------------------
                                   2051 ;record        Allocated with name '_is_tap_record_record_10000_778'
                                   2052 ;action        Allocated with name '_is_tap_record_action_10001_782'
                                   2053 ;------------------------------------------------------------
                                   2054 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   2055 ;	-----------------------------------------
                                   2056 	.area CSEG    (CODE)
                                   2057 	.area CONST   (CODE)
                                   2058 	.area XINIT   (CODE)
      00C3AD                       2059 __xinit__disable_action_cache:
      00C3AD 00                    2060 	.db #0x00	;  0
                                   2061 	.area CABS    (ABS,CODE)
                                   2062 
                                   2063 ; Experimental exact instruction outlining.
                                   2064 	.globl _ak820_outline_0001
                                   2065 	.globl _ak820_outline_0005
                                   2066 	.globl _ak820_outline_0007
                                   2067 	.globl _ak820_outline_0008
                                   2068 	.globl _ak820_outline_0011
                                   2069 	.globl _ak820_outline_0012
                                   2070 	.globl _ak820_outline_0013
                                   2071 	.globl _ak820_outline_0014
                                   2072 	.globl _ak820_outline_0017
                                   2073 	.globl _ak820_outline_0021
                                   2074 	.globl _ak820_outline_0022
                                   2075 	.globl _ak820_outline_0034
                                   2076 	.globl _ak820_outline_0037
                                   2077 	.globl _ak820_outline_0042
                                   2078 	.globl _ak820_outline_0057
                                   2079 	.globl _ak820_outline_0061
                                   2080 	.globl _ak820_outline_0064
                                   2081 	.globl _ak820_outline_0070
                                   2082 	.globl _ak820_outline_0072
                                   2083 	.globl _ak820_outline_0078
                                   2084 	.globl _ak820_outline_0079
                                   2085 	.globl _ak820_outline_0089
                                   2086 	.globl _ak820_outline_0093
                                   2087 	.globl _ak820_outline_0107
                                   2088 	.globl _ak820_outline_0108
                                   2089 	.globl _ak820_outline_0110
                                   2090 	.globl _ak820_outline_0112
                                   2091 	.globl _ak820_outline_0113
                                   2092 	.globl _ak820_outline_0118
                                   2093 	.globl _ak820_outline_0123
                                   2094 	.globl _ak820_outline_0124
                                   2095 	.globl _ak820_outline_0130
                                   2096 	.globl _ak820_outline_0133
                                   2097 	.globl _ak820_outline_0134
                                   2098 	.globl _ak820_outline_0141
                                   2099 	.globl _ak820_outline_0142
                                   2100 	.globl _ak820_outline_0144
                                   2101 	.globl _ak820_outline_0148
                                   2102 	.globl _ak820_outline_0151
                                   2103 	.globl _ak820_outline_0152
                                   2104 	.globl _ak820_outline_0160
                                   2105 	.globl _ak820_outline_0182
                                   2106 	.globl _ak820_outline_0187
                                   2107 	.globl _ak820_outline_0189
                                   2108 
                                   2109 	.area CSEG (CODE)
                                   2110 ; function ak820_outline_0013
      007988                       2111 _ak820_outline_0013:
      007988 2D               [12] 2112 	add	a,r5
      007989 F9               [12] 2113 	mov	r1,a
      00798A E4               [12] 2114 	clr	a
      00798B 3E               [12] 2115 	addc	a,r6
      00798C FA               [12] 2116 	mov	r2,a
      00798D 8F 03            [24] 2117 	mov	ar3,r7
      00798F 89 82            [24] 2118 	mov	dpl,r1
      007991 8A 83            [24] 2119 	mov	dph,r2
      007993 8B F0            [24] 2120 	mov	b,r3
      007995 22               [24] 2121 	ret
                                   2122 
                                   2123 	.area CSEG (CODE)
                                   2124 ; function ak820_outline_0014
      007996                       2125 _ak820_outline_0014:
      007996 2D               [12] 2126 	add	a,r5
      007997 FA               [12] 2127 	mov	r2,a
      007998 E4               [12] 2128 	clr	a
      007999 3E               [12] 2129 	addc	a,r6
      00799A FB               [12] 2130 	mov	r3,a
      00799B 8F 04            [24] 2131 	mov	ar4,r7
      00799D 8A 82            [24] 2132 	mov	dpl,r2
      00799F 8B 83            [24] 2133 	mov	dph,r3
      0079A1 8C F0            [24] 2134 	mov	b,r4
      0079A3 22               [24] 2135 	ret
                                   2136 
                                   2137 	.area CSEG (CODE)
                                   2138 ; function ak820_outline_0021
      0079A4                       2139 _ak820_outline_0021:
      0079A4 8E 82            [24] 2140 	mov	dpl,r6
      0079A6 8F 83            [24] 2141 	mov	dph,r7
      0079A8 A3               [24] 2142 	inc	dptr
      0079A9 E0               [24] 2143 	movx	a,@dptr
      0079AA FC               [12] 2144 	mov	r4,a
      0079AB 7D 00            [12] 2145 	mov	r5,#0x00
      0079AD 8E 82            [24] 2146 	mov	dpl,r6
      0079AF 8F 83            [24] 2147 	mov	dph,r7
      0079B1 E0               [24] 2148 	movx	a,@dptr
      0079B2 22               [24] 2149 	ret
                                   2150 
                                   2151 	.area CSEG (CODE)
                                   2152 ; function ak820_outline_0042
      0079B3                       2153 _ak820_outline_0042:
      0079B3 90 08 4E         [24] 2154 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0079B6 E0               [24] 2155 	movx	a,@dptr
      0079B7 54 1F            [12] 2156 	anl	a,#0x1f
      0079B9 F5 82            [12] 2157 	mov	dpl,a
      0079BB 22               [24] 2158 	ret
                                   2159 
                                   2160 	.area CSEG (CODE)
                                   2161 ; function ak820_outline_0061
      0079BC                       2162 _ak820_outline_0061:
      0079BC F5 F0            [12] 2163 	mov	b,a
      0079BE 05 F0            [12] 2164 	inc	b
      0079C0 74 01            [12] 2165 	mov	a,#0x01
      0079C2 22               [24] 2166 	ret
                                   2167 
                                   2168 	.area CSEG (CODE)
                                   2169 ; function ak820_outline_0070
      0079C3                       2170 _ak820_outline_0070:
      0079C3 90 0D BE         [24] 2171 	mov	dptr,#___memcpy_PARM_3
      0079C6 74 06            [12] 2172 	mov	a,#0x06
      0079C8 F0               [24] 2173 	movx	@dptr,a
      0079C9 E4               [12] 2174 	clr	a
      0079CA A3               [24] 2175 	inc	dptr
      0079CB F0               [24] 2176 	movx	@dptr,a
      0079CC 22               [24] 2177 	ret
                                   2178 
                                   2179 	.area CSEG (CODE)
                                   2180 ; function ak820_outline_0078
      0079CD                       2181 _ak820_outline_0078:
      0079CD 90 08 4D         [24] 2182 	mov	dptr,#_process_action_PARM_2
      0079D0 E0               [24] 2183 	movx	a,@dptr
      0079D1 F5 82            [12] 2184 	mov	dpl,a
      0079D3 22               [24] 2185 	ret
                                   2186 
                                   2187 	.area CSEG (CODE)
                                   2188 ; function ak820_outline_0089
      0079D4                       2189 _ak820_outline_0089:
      0079D4 90 08 4E         [24] 2190 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0079D7 E0               [24] 2191 	movx	a,@dptr
      0079D8 03               [12] 2192 	rr	a
      0079D9 03               [12] 2193 	rr	a
      0079DA 54 03            [12] 2194 	anl	a,#0x03
      0079DC 22               [24] 2195 	ret
                                   2196 
                                   2197 	.area CSEG (CODE)
                                   2198 ; function ak820_outline_0113
      0079DD                       2199 _ak820_outline_0113:
      0079DD 90 08 4E         [24] 2200 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0079E0 E0               [24] 2201 	movx	a,@dptr
      0079E1 54 0F            [12] 2202 	anl	a,#0x0f
      0079E3 22               [24] 2203 	ret
                                   2204 
                                   2205 	.area CSEG (CODE)
                                   2206 ; function ak820_outline_0130
      0079E4                       2207 _ak820_outline_0130:
      0079E4 90 08 4D         [24] 2208 	mov	dptr,#_process_action_PARM_2
      0079E7 E0               [24] 2209 	movx	a,@dptr
      0079E8 FE               [12] 2210 	mov	r6,a
      0079E9 A3               [24] 2211 	inc	dptr
      0079EA E0               [24] 2212 	movx	a,@dptr
      0079EB 54 03            [12] 2213 	anl	a,#0x03
      0079ED FF               [12] 2214 	mov	r7,a
      0079EE 22               [24] 2215 	ret
                                   2216 
                                   2217 	.area CSEG (CODE)
                                   2218 ; function ak820_outline_0141
      0079EF                       2219 _ak820_outline_0141:
      0079EF 90 08 53         [24] 2220 	mov	dptr,#_register_code_code_10000_714
      0079F2 E0               [24] 2221 	movx	a,@dptr
      0079F3 FF               [12] 2222 	mov	r7,a
      0079F4 22               [24] 2223 	ret
                                   2224 
                                   2225 	.area CSEG (CODE)
                                   2226 ; function ak820_outline_0142
      0079F5                       2227 _ak820_outline_0142:
      0079F5 90 08 54         [24] 2228 	mov	dptr,#_unregister_code_code_10000_728
      0079F8 E0               [24] 2229 	movx	a,@dptr
      0079F9 FF               [12] 2230 	mov	r7,a
      0079FA 22               [24] 2231 	ret
                                   2232 
                                   2233 	.area CSEG (CODE)
                                   2234 ; function ak820_outline_0148
      0079FB                       2235 _ak820_outline_0148:
      0079FB 74 07            [12] 2236 	mov	a,#0x07
      0079FD 2D               [12] 2237 	add	a,r5
      0079FE F8               [12] 2238 	mov	r0,a
      0079FF E4               [12] 2239 	clr	a
      007A00 3E               [12] 2240 	addc	a,r6
      007A01 F9               [12] 2241 	mov	r1,a
      007A02 8F 02            [24] 2242 	mov	ar2,r7
      007A04 22               [24] 2243 	ret
                                   2244 
                                   2245 	.area CSEG (CODE)
                                   2246 ; function ak820_outline_0151
      007A05                       2247 _ak820_outline_0151:
      007A05 90 08 4D         [24] 2248 	mov	dptr,#_process_action_PARM_2
      007A08 E0               [24] 2249 	movx	a,@dptr
      007A09 22               [24] 2250 	ret
                                   2251 
                                   2252 	.area CSEG (CODE)
                                   2253 ; function ak820_outline_0187
      007A0A                       2254 _ak820_outline_0187:
      007A0A F0               [24] 2255 	movx	@dptr,a
      007A0B EB               [12] 2256 	mov	a,r3
      007A0C A3               [24] 2257 	inc	dptr
      007A0D F0               [24] 2258 	movx	@dptr,a
      007A0E 22               [24] 2259 	ret
                                   2260 
                                   2261 	.area CSEG (CODE)
                                   2262 ; function ak820_outline_0189
      007A0F                       2263 _ak820_outline_0189:
      007A0F E4               [12] 2264 	clr	a
      007A10 F0               [24] 2265 	movx	@dptr,a
      007A11 8F 82            [24] 2266 	mov	dpl,r7
      007A13 22               [24] 2267 	ret
