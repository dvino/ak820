                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_macro_change
                                    268 	.globl _add_owned_mods
                                    269 	.globl _del_owned_mods
                                    270 	.globl _add_owned_weak_mods
                                    271 	.globl _del_owned_weak_mods
                                    272 	.globl _clear_owned_mods
                                    273 	.globl _clear_owned_keys
                                    274 	.globl _add_owned_key
                                    275 	.globl _del_owned_key
                                    276 	.globl _clear_owned_usages
                                    277 	.globl _owned_usage_key
                                    278 	.globl _send_keyboard_report
                                    279 	.globl _get_mods
                                    280 	.globl _clear_mods
                                    281 	.globl _get_weak_mods
                                    282 	.globl _add_weak_mods
                                    283 	.globl _del_weak_mods
                                    284 	.globl _clear_weak_mods
                                    285 ;--------------------------------------------------------
                                    286 ; special function registers
                                    287 ;--------------------------------------------------------
                                    288 	.area RSEG    (ABS,DATA)
      000000                        289 	.org 0x0000
                           0000D0   290 _PSW	=	0x00d0
                           0000E0   291 _ACC	=	0x00e0
                           0000F0   292 _B	=	0x00f0
                           0000FD   293 _A_INV	=	0x00fd
                           000081   294 _SP	=	0x0081
                           000082   295 _DPL	=	0x0082
                           000083   296 _DPH	=	0x0083
                           0000A1   297 _SAFE_MOD	=	0x00a1
                           0000B1   298 _GLOBAL_CFG	=	0x00b1
                           000087   299 _PCON	=	0x0087
                           0000BA   300 _POWER_CFG	=	0x00ba
                           0000B9   301 _CLOCK_CFG	=	0x00b9
                           0000A9   302 _WAKE_CTRL	=	0x00a9
                           0000FE   303 _RESET_KEEP	=	0x00fe
                           0000FF   304 _WDOG_COUNT	=	0x00ff
                           0000A8   305 _IE	=	0x00a8
                           0000B8   306 _IP	=	0x00b8
                           0000E8   307 _IE_EX	=	0x00e8
                           0000E9   308 _IP_EX	=	0x00e9
                           0000B2   309 _GPIO_IE	=	0x00b2
                           008584   310 _ROM_ADDR	=	0x8584
                           000084   311 _ROM_ADDR_L	=	0x0084
                           000085   312 _ROM_ADDR_H	=	0x0085
                           008F8E   313 _ROM_DATA_HI	=	0x8f8e
                           00008E   314 _ROM_DATA_HL	=	0x008e
                           00008F   315 _ROM_DATA_HH	=	0x008f
                           000086   316 _ROM_CTRL	=	0x0086
                           000080   317 _P0	=	0x0080
                           0000C4   318 _P0_MOD_OC	=	0x00c4
                           0000C5   319 _P0_DIR_PU	=	0x00c5
                           000090   320 _P1	=	0x0090
                           000092   321 _P1_MOD_OC	=	0x0092
                           000093   322 _P1_DIR_PU	=	0x0093
                           0000A0   323 _P2	=	0x00a0
                           000094   324 _P2_MOD_OC	=	0x0094
                           000095   325 _P2_DIR_PU	=	0x0095
                           0000B0   326 _P3	=	0x00b0
                           000096   327 _P3_MOD_OC	=	0x0096
                           000097   328 _P3_DIR_PU	=	0x0097
                           0000C0   329 _P4	=	0x00c0
                           0000C2   330 _P4_MOD_OC	=	0x00c2
                           0000C3   331 _P4_DIR_PU	=	0x00c3
                           0000C1   332 _P4_LED_KEY	=	0x00c1
                           0000AA   333 _P5_IN	=	0x00aa
                           0000AB   334 _P5_OUT_PU	=	0x00ab
                           0000AC   335 _P5_DIR	=	0x00ac
                           0000AD   336 _P6_IN	=	0x00ad
                           0000AE   337 _P6_OUT_PU	=	0x00ae
                           0000AF   338 _P6_DIR	=	0x00af
                           0000F1   339 _P7	=	0x00f1
                           0000A2   340 _XBUS_AUX	=	0x00a2
                           000088   341 _TCON	=	0x0088
                           000089   342 _TMOD	=	0x0089
                           00008A   343 _TL0	=	0x008a
                           00008B   344 _TL1	=	0x008b
                           00008C   345 _TH0	=	0x008c
                           00008D   346 _TH1	=	0x008d
                           000098   347 _SCON	=	0x0098
                           000099   348 _SBUF	=	0x0099
                           0000C8   349 _T2CON	=	0x00c8
                           0000C9   350 _T2MOD	=	0x00c9
                           00CBCA   351 _RCAP2	=	0xcbca
                           0000CA   352 _RCAP2L	=	0x00ca
                           0000CB   353 _RCAP2H	=	0x00cb
                           00CDCC   354 _T2COUNT	=	0xcdcc
                           0000CC   355 _TL2	=	0x00cc
                           0000CD   356 _TH2	=	0x00cd
                           00CFCE   357 _T2CAP1	=	0xcfce
                           0000CE   358 _T2CAP1L	=	0x00ce
                           0000CF   359 _T2CAP1H	=	0x00cf
                           0000F8   360 _SPI0_STAT	=	0x00f8
                           0000F9   361 _SPI0_DATA	=	0x00f9
                           0000FA   362 _SPI0_CTRL	=	0x00fa
                           0000FB   363 _SPI0_CK_SE	=	0x00fb
                           0000FC   364 _SPI0_SETUP	=	0x00fc
                           0000BC   365 _SCON1	=	0x00bc
                           0000BD   366 _SBUF1	=	0x00bd
                           0000BE   367 _SBAUD1	=	0x00be
                           0000BF   368 _SIF1	=	0x00bf
                           0000B4   369 _SPI1_STAT	=	0x00b4
                           0000B5   370 _SPI1_DATA	=	0x00b5
                           0000B6   371 _SPI1_CTRL	=	0x00b6
                           0000B7   372 _SPI1_CK_SE	=	0x00b7
                           0000F3   373 _ADC_CTRL	=	0x00f3
                           00F5F4   374 _ADC_DAT	=	0xf5f4
                           0000F4   375 _ADC_DAT_L	=	0x00f4
                           0000F5   376 _ADC_DAT_H	=	0x00f5
                           0000F6   377 _ADC_CHAN	=	0x00f6
                           0000A6   378 _LED_COMMON	=	0x00a6
                           0000A7   379 _LED_PWM_OE	=	0x00a7
                           00C7C6   380 _LED_DMA	=	0xc7c6
                           0000C6   381 _LED_DMA_L	=	0x00c6
                           0000C7   382 _LED_DMA_H	=	0x00c7
                           0000F7   383 _LED_STATUS	=	0x00f7
                           0000B3   384 _I2CX_INT	=	0x00b3
                           0000BB   385 _I2CS_INT_ST	=	0x00bb
                                    386 ;--------------------------------------------------------
                                    387 ; special function bits
                                    388 ;--------------------------------------------------------
                                    389 	.area RSEG    (ABS,DATA)
      000000                        390 	.org 0x0000
                           0000D7   391 _CY	=	0x00d7
                           0000D6   392 _AC	=	0x00d6
                           0000D5   393 _F0	=	0x00d5
                           0000D4   394 _RS1	=	0x00d4
                           0000D3   395 _RS0	=	0x00d3
                           0000D2   396 _OV	=	0x00d2
                           0000D1   397 _F1	=	0x00d1
                           0000D0   398 _P	=	0x00d0
                           0000AF   399 _EA	=	0x00af
                           0000AE   400 _E_DIS	=	0x00ae
                           0000AD   401 _ET2	=	0x00ad
                           0000AC   402 _ES	=	0x00ac
                           0000AB   403 _ET1	=	0x00ab
                           0000AA   404 _EX1	=	0x00aa
                           0000A9   405 _ET0	=	0x00a9
                           0000A8   406 _EX0	=	0x00a8
                           0000BF   407 _PH_FLAG	=	0x00bf
                           0000BE   408 _PL_FLAG	=	0x00be
                           0000BD   409 _PT2	=	0x00bd
                           0000BC   410 _PS	=	0x00bc
                           0000BB   411 _PT1	=	0x00bb
                           0000BA   412 _PX1	=	0x00ba
                           0000B9   413 _PT0	=	0x00b9
                           0000B8   414 _PX0	=	0x00b8
                           0000EF   415 _IE_WDOG	=	0x00ef
                           0000EE   416 _IE_GPIO	=	0x00ee
                           0000ED   417 _IE_PWM_I2C	=	0x00ed
                           0000EC   418 _IE_UART1	=	0x00ec
                           0000EB   419 _IE_ADC	=	0x00eb
                           0000E9   420 _IE_USB	=	0x00e9
                           0000E8   421 _IE_SPI0	=	0x00e8
                           000087   422 _P0_7	=	0x0087
                           000086   423 _P0_6	=	0x0086
                           000085   424 _P0_5	=	0x0085
                           000084   425 _P0_4	=	0x0084
                           000083   426 _P0_3	=	0x0083
                           000082   427 _P0_2	=	0x0082
                           000081   428 _P0_1	=	0x0081
                           000080   429 _P0_0	=	0x0080
                           000081   430 _SDA0	=	0x0081
                           000080   431 _SCL0	=	0x0080
                           000083   432 _TXD_	=	0x0083
                           000082   433 _RXD_	=	0x0082
                           000085   434 _AIN13	=	0x0085
                           000084   435 _AIN12	=	0x0084
                           000083   436 _AIN11	=	0x0083
                           000082   437 _AIN10	=	0x0082
                           000081   438 _AIN9	=	0x0081
                           000080   439 _AIN8	=	0x0080
                           000097   440 _P1_7	=	0x0097
                           000096   441 _P1_6	=	0x0096
                           000095   442 _P1_5	=	0x0095
                           000094   443 _P1_4	=	0x0094
                           000093   444 _P1_3	=	0x0093
                           000092   445 _P1_2	=	0x0092
                           000091   446 _P1_1	=	0x0091
                           000090   447 _P1_0	=	0x0090
                           000097   448 _TXD1_	=	0x0097
                           000096   449 _RXD1_	=	0x0096
                           000097   450 _SCK	=	0x0097
                           000096   451 _MISO	=	0x0096
                           000095   452 _MOSI	=	0x0095
                           000094   453 _SCS	=	0x0094
                           000092   454 _INT0_	=	0x0092
                           000091   455 _T2EX	=	0x0091
                           000091   456 _CAP2	=	0x0091
                           000090   457 _T2	=	0x0090
                           000090   458 _CAP1	=	0x0090
                           000097   459 _AIN7	=	0x0097
                           000096   460 _AIN6	=	0x0096
                           000095   461 _AIN5	=	0x0095
                           000094   462 _AIN4	=	0x0094
                           000093   463 _AIN3	=	0x0093
                           000092   464 _AIN2	=	0x0092
                           000091   465 _AIN1	=	0x0091
                           000090   466 _AIN0	=	0x0090
                           0000A7   467 _P2_7	=	0x00a7
                           0000A6   468 _P2_6	=	0x00a6
                           0000A5   469 _P2_5	=	0x00a5
                           0000A4   470 _P2_4	=	0x00a4
                           0000A3   471 _P2_3	=	0x00a3
                           0000A2   472 _P2_2	=	0x00a2
                           0000A1   473 _P2_1	=	0x00a1
                           0000A0   474 _P2_0	=	0x00a0
                           0000A7   475 _TXD1	=	0x00a7
                           0000A6   476 _RXD1	=	0x00a6
                           0000A5   477 _T2EX_	=	0x00a5
                           0000A5   478 _CAP2_	=	0x00a5
                           0000A4   479 _T2_	=	0x00a4
                           0000A4   480 _CAP1_	=	0x00a4
                           0000B7   481 _P3_7	=	0x00b7
                           0000B6   482 _P3_6	=	0x00b6
                           0000B5   483 _P3_5	=	0x00b5
                           0000B4   484 _P3_4	=	0x00b4
                           0000B3   485 _P3_3	=	0x00b3
                           0000B2   486 _P3_2	=	0x00b2
                           0000B1   487 _P3_1	=	0x00b1
                           0000B0   488 _P3_0	=	0x00b0
                           0000B7   489 _SCK1	=	0x00b7
                           0000B6   490 _MISO1	=	0x00b6
                           0000B5   491 _MOSI1	=	0x00b5
                           0000B5   492 _T1	=	0x00b5
                           0000B4   493 _T0	=	0x00b4
                           0000B3   494 _INT1	=	0x00b3
                           0000B2   495 _INT0	=	0x00b2
                           0000B1   496 _TXD	=	0x00b1
                           0000B0   497 _RXD	=	0x00b0
                           0000C6   498 _P4_6	=	0x00c6
                           0000C5   499 _P4_5	=	0x00c5
                           0000C4   500 _P4_4	=	0x00c4
                           0000C3   501 _P4_3	=	0x00c3
                           0000C2   502 _P4_2	=	0x00c2
                           0000C1   503 _P4_1	=	0x00c1
                           0000C0   504 _P4_0	=	0x00c0
                           00008F   505 _TF1	=	0x008f
                           00008E   506 _TR1	=	0x008e
                           00008D   507 _TF0	=	0x008d
                           00008C   508 _TR0	=	0x008c
                           00008B   509 _IE1	=	0x008b
                           00008A   510 _IT1	=	0x008a
                           000089   511 _IE0	=	0x0089
                           000088   512 _IT0	=	0x0088
                           00009F   513 _SM0	=	0x009f
                           00009E   514 _SM1	=	0x009e
                           00009D   515 _SM2	=	0x009d
                           00009C   516 _REN	=	0x009c
                           00009B   517 _TB8	=	0x009b
                           00009A   518 _RB8	=	0x009a
                           000099   519 _TI	=	0x0099
                           000098   520 _RI	=	0x0098
                           0000CF   521 _TF2	=	0x00cf
                           0000CF   522 _CAP1F	=	0x00cf
                           0000CE   523 _EXF2	=	0x00ce
                           0000CD   524 _RCLK	=	0x00cd
                           0000CC   525 _TCLK	=	0x00cc
                           0000CB   526 _EXEN2	=	0x00cb
                           0000CA   527 _TR2	=	0x00ca
                           0000C9   528 _C_T2	=	0x00c9
                           0000C8   529 _CP_RL2	=	0x00c8
                           0000FF   530 _S0_FST_ACT	=	0x00ff
                           0000FE   531 _S0_IF_OV	=	0x00fe
                           0000FD   532 _S0_IF_FIRST	=	0x00fd
                           0000FC   533 _S0_IF_BYTE	=	0x00fc
                           0000FB   534 _S0_FREE	=	0x00fb
                           0000FA   535 _S0_T_FIFO	=	0x00fa
                           0000F8   536 _S0_R_FIFO	=	0x00f8
                           0000F7   537 _ADC_START	=	0x00f7
                                    538 ;--------------------------------------------------------
                                    539 ; overlayable register banks
                                    540 ;--------------------------------------------------------
                                    541 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        542 	.ds 8
                                    543 ;--------------------------------------------------------
                                    544 ; internal ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area DSEG    (DATA)
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable items in internal ram
                                    549 ;--------------------------------------------------------
                                    550 	.area	OSEG    (OVR,DATA)
      000054                        551 _change_owned_sloc1_1_0:
      000054                        552 	.ds 1
                                    553 ;--------------------------------------------------------
                                    554 ; indirectly addressable internal ram data
                                    555 ;--------------------------------------------------------
                                    556 	.area ISEG    (DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; absolute internal ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area IABS    (ABS,DATA)
                                    561 	.area IABS    (ABS,DATA)
                                    562 ;--------------------------------------------------------
                                    563 ; bit data
                                    564 ;--------------------------------------------------------
                                    565 	.area BSEG    (BIT)
      000020                        566 _ak820_macro_change_sloc0_1_0:
      000020                        567 	.ds 1
      000021                        568 _change_owned_sloc0_1_0:
      000021                        569 	.ds 1
      000022                        570 _owned_usage_key_sloc0_1_0:
      000022                        571 	.ds 1
                                    572 ;--------------------------------------------------------
                                    573 ; paged external ram data
                                    574 ;--------------------------------------------------------
                                    575 	.area PSEG    (PAG,XDATA)
                                    576 ;--------------------------------------------------------
                                    577 ; uninitialized external ram data
                                    578 ;--------------------------------------------------------
                                    579 	.area XSEG    (XDATA)
      00098D                        580 _owned_mod_refs:
      00098D                        581 	.ds 8
      000995                        582 _owned_weak_refs:
      000995                        583 	.ds 8
      00099D                        584 _owned_mods:
      00099D                        585 	.ds 1
      00099E                        586 _owned_weak_mods:
      00099E                        587 	.ds 1
      00099F                        588 _macro_mods:
      00099F                        589 	.ds 2
      0009A1                        590 _ak820_macro_primitive::
      0009A1                        591 	.ds 1
      0009A2                        592 _ak820_macro_cancelled::
      0009A2                        593 	.ds 1
      0009A3                        594 _ak820_macro_change_PARM_2:
      0009A3                        595 	.ds 1
      0009A4                        596 _ak820_macro_change_PARM_3:
      0009A4                        597 	.ds 1
      0009A5                        598 _ak820_macro_change_bits_10000_294:
      0009A5                        599 	.ds 2
      0009A7                        600 _change_owned_PARM_2:
      0009A7                        601 	.ds 1
      0009A8                        602 _change_owned_mods_10000_299:
      0009A8                        603 	.ds 1
      0009A9                        604 _change_owned_result_10001_303:
      0009A9                        605 	.ds 1
      0009AA                        606 _change_owned_bit_20001_304:
      0009AA                        607 	.ds 1
      0009AB                        608 _add_owned_mods_mods_10000_312:
      0009AB                        609 	.ds 1
      0009AC                        610 _del_owned_mods_mods_10000_314:
      0009AC                        611 	.ds 1
      0009AD                        612 _add_owned_weak_mods_mods_10000_316:
      0009AD                        613 	.ds 1
      0009AE                        614 _del_owned_weak_mods_mods_10000_318:
      0009AE                        615 	.ds 1
      0009AF                        616 _key_refs:
      0009AF                        617 	.ds 165
      000A54                        618 _distinct_keys:
      000A54                        619 	.ds 1
      000A55                        620 _macro_keys:
      000A55                        621 	.ds 21
      000A6A                        622 _add_owned_key_code_10000_327:
      000A6A                        623 	.ds 1
      000A6B                        624 _del_owned_key_code_10000_342:
      000A6B                        625 	.ds 1
      000A6C                        626 _usage_refs:
      000A6C                        627 	.ds 30
      000A8A                        628 _usage_order:
      000A8A                        629 	.ds 30
      000AA8                        630 _usage_lengths:
      000AA8                        631 	.ds 2
      000AAA                        632 _macro_usages:
      000AAA                        633 	.ds 4
      000AAE                        634 _owned_usage_key_PARM_2:
      000AAE                        635 	.ds 1
      000AAF                        636 _owned_usage_key_code_10000_369:
      000AAF                        637 	.ds 1
      000AB0                        638 _owned_usage_key___200000085_20000_370:
      000AB0                        639 	.ds 2
      000AB2                        640 _owned_usage_key_which_10000_370:
      000AB2                        641 	.ds 1
      000AB3                        642 _owned_usage_key_count_10000_370:
      000AB3                        643 	.ds 1
      000AB4                        644 _owned_usage_key_pos_30001_377:
      000AB4                        645 	.ds 1
      000AB5                        646 _owned_usage_key_key_40000_382:
      000AB5                        647 	.ds 1
      000AB6                        648 _send_keyboard_report_last_report_10001_389:
      000AB6                        649 	.ds 32
      000AD6                        650 _send_keyboard_report_changed_10001_389:
      000AD6                        651 	.ds 1
      000AD7                        652 _add_weak_mods_mods_10000_407:
      000AD7                        653 	.ds 1
      000AD8                        654 _del_weak_mods_mods_10000_409:
      000AD8                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DDE                        664 _real_mods:
      000DDE                        665 	.ds 1
      000DDF                        666 _weak_mods:
      000DDF                        667 	.ds 1
      000DE0                        668 _actual_keyboard_report::
      000DE0                        669 	.ds 32
                                    670 	.area HOME    (CODE)
                                    671 	.area GSINIT0 (CODE)
                                    672 	.area GSINIT1 (CODE)
                                    673 	.area GSINIT2 (CODE)
                                    674 	.area GSINIT3 (CODE)
                                    675 	.area GSINIT4 (CODE)
                                    676 	.area GSINIT5 (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 	.area GSFINAL (CODE)
                                    679 	.area CSEG    (CODE)
                                    680 ;--------------------------------------------------------
                                    681 ; global & static initialisations
                                    682 ;--------------------------------------------------------
                                    683 	.area HOME    (CODE)
                                    684 	.area GSINIT  (CODE)
                                    685 	.area GSFINAL (CODE)
                                    686 	.area GSINIT  (CODE)
                                    687 ;--------------------------------------------------------
                                    688 ; Home
                                    689 ;--------------------------------------------------------
                                    690 	.area HOME    (CODE)
                                    691 	.area HOME    (CODE)
                                    692 ;--------------------------------------------------------
                                    693 ; code
                                    694 ;--------------------------------------------------------
                                    695 	.area CSEG    (CODE)
                                    696 ;------------------------------------------------------------
                                    697 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    698 ;------------------------------------------------------------
                                    699 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    700 ;------------------------------------------------------------
                                    701 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    702 ;	-----------------------------------------
                           000007   703 	ar7 = 0x07
                           000006   704 	ar6 = 0x06
                           000005   705 	ar5 = 0x05
                           000004   706 	ar4 = 0x04
                           000003   707 	ar3 = 0x03
                           000002   708 	ar2 = 0x02
                           000001   709 	ar1 = 0x01
                           000000   710 	ar0 = 0x00
                                    711 ;	 function ak820_macro_change
                                    712 ;	-----------------------------------------
      007E2F                        713 _ak820_macro_change:
      007E2F 12 38 82         [24]  714 	lcall	_ak820_outline_0107
      007E32 90 09 A5         [24]  715 	mov	dptr,#_ak820_macro_change_bits_10000_294
      007E35 12 38 87         [24]  716 	lcall	_ak820_outline_0108
                                    717 ;	quantum/action_util.c:96: if (!ak820_macro_primitive) return true;
      007E38 90 09 A1         [24]  718 	mov	dptr,#_ak820_macro_primitive
      007E3B E0               [24]  719 	movx	a,@dptr
      007E3C 70 04            [24]  720 	jnz	00102$
      007E3E 75 82 01         [24]  721 	mov	dpl, #0x01
      007E41 22               [24]  722 	ret
      007E42                        723 00102$:
                                    724 ;	quantum/action_util.c:97: uint8_t mask = 1u << (index & 7);
      007E42 90 09 A3         [24]  725 	mov	dptr,#_ak820_macro_change_PARM_2
      007E45 E0               [24]  726 	movx	a,@dptr
      007E46 FF               [12]  727 	mov	r7,a
      007E47 74 07            [12]  728 	mov	a,#0x07
      007E49 5F               [12]  729 	anl	a,r7
      007E4A 12 79 BC         [24]  730 	lcall	_ak820_outline_0061
      007E4D 80 02            [24]  731 	sjmp	00123$
      007E4F                        732 00122$:
      007E4F 25 E0            [12]  733 	add	a,acc
      007E51                        734 00123$:
      007E51 D5 F0 FB         [24]  735 	djnz	b,00122$
      007E54 FE               [12]  736 	mov	r6,a
                                    737 ;	quantum/action_util.c:98: bits += index >> 3;
      007E55 EF               [12]  738 	mov	a,r7
      007E56 12 59 C5         [24]  739 	lcall	_ak820_outline_0188
      007E59 FF               [12]  740 	mov	r7,a
      007E5A 90 09 A5         [24]  741 	mov	dptr,#_ak820_macro_change_bits_10000_294
      007E5D 12 38 58         [24]  742 	lcall	_ak820_outline_0059
      007E60 90 09 A5         [24]  743 	mov	dptr,#_ak820_macro_change_bits_10000_294
      007E63 EF               [12]  744 	mov	a,r7
      007E64 2C               [12]  745 	add	a, r4
      007E65 F0               [24]  746 	movx	@dptr,a
      007E66 E4               [12]  747 	clr	a
      007E67 3D               [12]  748 	addc	a, r5
      007E68 A3               [24]  749 	inc	dptr
      007E69 F0               [24]  750 	movx	@dptr,a
                                    751 ;	quantum/action_util.c:99: if (((*bits & mask) != 0) == pressed) return false;
      007E6A 90 09 A5         [24]  752 	mov	dptr,#_ak820_macro_change_bits_10000_294
      007E6D E0               [24]  753 	movx	a,@dptr
      007E6E FD               [12]  754 	mov	r5,a
      007E6F A3               [24]  755 	inc	dptr
      007E70 E0               [24]  756 	movx	a,@dptr
      007E71 FF               [12]  757 	mov	r7,a
      007E72 12 83 B3         [24]  758 	lcall	_ak820_outline_0190
      007E75 E0               [24]  759 	movx	a,@dptr
      007E76 FC               [12]  760 	mov	r4,a
      007E77 EE               [12]  761 	mov	a,r6
      007E78 5C               [12]  762 	anl	a,r4
      007E79 B4 01 00         [24]  763 	cjne	a,#0x01,00124$
      007E7C                        764 00124$:
      007E7C B3               [12]  765 	cpl	c
      007E7D 92 20            [24]  766 	mov	_ak820_macro_change_sloc0_1_0,c
      007E7F 90 09 A4         [24]  767 	mov	dptr,#_ak820_macro_change_PARM_3
      007E82 E0               [24]  768 	movx	a,@dptr
      007E83 FB               [12]  769 	mov	r3,a
      007E84 A2 20            [12]  770 	mov	c,_ak820_macro_change_sloc0_1_0
      007E86 E4               [12]  771 	clr	a
      007E87 33               [12]  772 	rlc	a
      007E88 B5 03 04         [24]  773 	cjne	a,ar3,00104$
      007E8B 75 82 00         [24]  774 	mov	dpl, #0x00
      007E8E 22               [24]  775 	ret
      007E8F                        776 00104$:
                                    777 ;	quantum/action_util.c:100: *bits ^= mask;
      007E8F EC               [12]  778 	mov	a,r4
      007E90 62 06            [12]  779 	xrl	ar6,a
      007E92 12 83 B3         [24]  780 	lcall	_ak820_outline_0190
      007E95 EE               [12]  781 	mov	a,r6
      007E96 F0               [24]  782 	movx	@dptr,a
                                    783 ;	quantum/action_util.c:101: return true;
      007E97 75 82 01         [24]  784 	mov	dpl, #0x01
                                    785 ;	quantum/action_util.c:102: }
      007E9A 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'change_owned'
                                    789 ;------------------------------------------------------------
                                    790 ;mode          Allocated with name '_change_owned_PARM_2'
                                    791 ;mods          Allocated with name '_change_owned_mods_10000_299'
                                    792 ;kind          Allocated with name '_change_owned_kind_10000_300'
                                    793 ;pressed       Allocated with name '_change_owned_pressed_10000_300'
                                    794 ;refs          Allocated with name '_change_owned_refs_10000_300'
                                    795 ;old           Allocated with name '_change_owned_old_30000_302'
                                    796 ;result        Allocated with name '_change_owned_result_10001_303'
                                    797 ;i             Allocated with name '_change_owned_i_20001_304'
                                    798 ;bit           Allocated with name '_change_owned_bit_20001_304'
                                    799 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    800 ;------------------------------------------------------------
                                    801 ;	quantum/action_util.c:103: static void change_owned(uint8_t mods, uint8_t mode) {
                                    802 ;	-----------------------------------------
                                    803 ;	 function change_owned
                                    804 ;	-----------------------------------------
      007E9B                        805 _change_owned:
      007E9B E5 82            [12]  806 	mov	a,dpl
      007E9D 90 09 A8         [24]  807 	mov	dptr,#_change_owned_mods_10000_299
      007EA0 F0               [24]  808 	movx	@dptr,a
                                    809 ;	quantum/action_util.c:104: uint8_t kind = mode >> 1;
      007EA1 90 09 A7         [24]  810 	mov	dptr,#_change_owned_PARM_2
      007EA4 E0               [24]  811 	movx	a,@dptr
      007EA5 FF               [12]  812 	mov	r7,a
      007EA6 C3               [12]  813 	clr	c
      007EA7 13               [12]  814 	rrc	a
      007EA8 FE               [12]  815 	mov	r6,a
                                    816 ;	quantum/action_util.c:105: bool pressed = (mode & 1) != 0;
      007EA9 53 07 01         [24]  817 	anl	ar7,#0x01
      007EAC EF               [12]  818 	mov	a,r7
      007EAD B4 01 00         [24]  819 	cjne	a,#0x01,00205$
      007EB0                        820 00205$:
      007EB0 92 21            [24]  821 	mov  _change_owned_sloc0_1_0,c
      007EB2 B3               [12]  822 	cpl	c
      007EB3 E4               [12]  823 	clr	a
      007EB4 33               [12]  824 	rlc	a
      007EB5 F5 54            [12]  825 	mov	_change_owned_sloc1_1_0,a
                                    826 ;	quantum/action_util.c:106: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007EB7 EE               [12]  827 	mov	a,r6
      007EB8 60 06            [24]  828 	jz	00121$
      007EBA 7D 95            [12]  829 	mov	r5,#_owned_weak_refs
      007EBC 7F 09            [12]  830 	mov	r7,#(_owned_weak_refs >> 8)
      007EBE 80 04            [24]  831 	sjmp	00122$
      007EC0                        832 00121$:
      007EC0 7D 8D            [12]  833 	mov	r5,#_owned_mod_refs
      007EC2 7F 09            [12]  834 	mov	r7,#(_owned_mod_refs >> 8)
      007EC4                        835 00122$:
                                    836 ;	quantum/action_util.c:107: if (ak820_macro_primitive) {
      007EC4 90 09 A1         [24]  837 	mov	dptr,#_ak820_macro_primitive
      007EC7 E0               [24]  838 	movx	a,@dptr
      007EC8 60 36            [24]  839 	jz	00102$
                                    840 ;	quantum/action_util.c:108: uint8_t old = macro_mods[kind];
      007ECA EE               [12]  841 	mov	a,r6
      007ECB 24 9F            [12]  842 	add	a, #_macro_mods
      007ECD FB               [12]  843 	mov	r3,a
      007ECE E4               [12]  844 	clr	a
      007ECF 34 09            [12]  845 	addc	a, #(_macro_mods >> 8)
      007ED1 12 48 7B         [24]  846 	lcall	_ak820_outline_0055
                                    847 ;	quantum/action_util.c:109: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007ED4 E5 54            [12]  848 	mov	a,_change_owned_sloc1_1_0
      007ED6 60 0A            [24]  849 	jz	00123$
      007ED8 90 09 A8         [24]  850 	mov	dptr,#_change_owned_mods_10000_299
      007EDB E0               [24]  851 	movx	a,@dptr
      007EDC F9               [12]  852 	mov	r1,a
      007EDD EA               [12]  853 	mov	a,r2
      007EDE 42 01            [12]  854 	orl	ar1,a
      007EE0 80 07            [24]  855 	sjmp	00124$
      007EE2                        856 00123$:
      007EE2 90 09 A8         [24]  857 	mov	dptr,#_change_owned_mods_10000_299
      007EE5 E0               [24]  858 	movx	a,@dptr
      007EE6 F4               [12]  859 	cpl	a
      007EE7 5A               [12]  860 	anl	a,r2
      007EE8 F9               [12]  861 	mov	r1,a
      007EE9                        862 00124$:
      007EE9 12 33 FC         [24]  863 	lcall	_ak820_outline_0123
      007EEC E9               [12]  864 	mov	a,r1
      007EED F0               [24]  865 	movx	@dptr,a
                                    866 ;	quantum/action_util.c:110: mods &= pressed ? ~old : old;
      007EEE E5 54            [12]  867 	mov	a,_change_owned_sloc1_1_0
      007EF0 60 06            [24]  868 	jz	00125$
      007EF2 74 FF            [12]  869 	mov	a,#0xff
      007EF4 6A               [12]  870 	xrl	a,r2
      007EF5 FC               [12]  871 	mov	r4,a
      007EF6 80 02            [24]  872 	sjmp	00126$
      007EF8                        873 00125$:
      007EF8 8A 04            [24]  874 	mov	ar4,r2
      007EFA                        875 00126$:
      007EFA 90 09 A8         [24]  876 	mov	dptr,#_change_owned_mods_10000_299
      007EFD E0               [24]  877 	movx	a,@dptr
      007EFE 5C               [12]  878 	anl	a,r4
      007EFF F0               [24]  879 	movx	@dptr,a
      007F00                        880 00102$:
                                    881 ;	quantum/action_util.c:112: uint8_t result = 0;
      007F00 90 09 A9         [24]  882 	mov	dptr,#_change_owned_result_10001_303
      007F03 E4               [12]  883 	clr	a
      007F04 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:113: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007F05 90 09 AA         [24]  886 	mov	dptr,#_change_owned_bit_20001_304
      007F08 04               [12]  887 	inc	a
      007F09 F0               [24]  888 	movx	@dptr,a
      007F0A 90 09 A8         [24]  889 	mov	dptr,#_change_owned_mods_10000_299
      007F0D E0               [24]  890 	movx	a,@dptr
      007F0E FC               [12]  891 	mov	r4,a
      007F0F 7B 00            [12]  892 	mov	r3,#0x00
      007F11                        893 00117$:
      007F11 BB 08 00         [24]  894 	cjne	r3,#0x08,00210$
      007F14                        895 00210$:
      007F14 50 3F            [24]  896 	jnc	00112$
                                    897 ;	quantum/action_util.c:114: if (mods & bit) {
      007F16 90 09 AA         [24]  898 	mov	dptr,#_change_owned_bit_20001_304
      007F19 E0               [24]  899 	movx	a,@dptr
      007F1A 5C               [12]  900 	anl	a,r4
      007F1B 60 1C            [24]  901 	jz	00109$
                                    902 ;	quantum/action_util.c:115: if (pressed) ++refs[i];
      007F1D E5 54            [12]  903 	mov	a,_change_owned_sloc1_1_0
      007F1F 60 0C            [24]  904 	jz	00106$
      007F21 EB               [12]  905 	mov	a,r3
      007F22 2D               [12]  906 	add	a, r5
      007F23 12 38 1F         [24]  907 	lcall	_ak820_outline_0016
      007F26 F8               [12]  908 	mov	r0,a
      007F27 08               [12]  909 	inc	r0
      007F28 12 83 67         [24]  910 	lcall	_ak820_outline_0062
      007F2B 80 0C            [24]  911 	sjmp	00109$
      007F2D                        912 00106$:
                                    913 ;	quantum/action_util.c:116: else if (refs[i]) --refs[i];
      007F2D EB               [12]  914 	mov	a,r3
      007F2E 2D               [12]  915 	add	a, r5
      007F2F 12 38 1F         [24]  916 	lcall	_ak820_outline_0016
      007F32 F8               [12]  917 	mov	r0,a
      007F33 60 04            [24]  918 	jz	00109$
      007F35 18               [12]  919 	dec	r0
      007F36 12 83 67         [24]  920 	lcall	_ak820_outline_0062
      007F39                        921 00109$:
                                    922 ;	quantum/action_util.c:118: if (refs[i]) result |= bit;
      007F39 EB               [12]  923 	mov	a,r3
      007F3A 2D               [12]  924 	add	a, r5
      007F3B 12 38 1F         [24]  925 	lcall	_ak820_outline_0016
      007F3E 60 0B            [24]  926 	jz	00118$
      007F40 90 09 AA         [24]  927 	mov	dptr,#_change_owned_bit_20001_304
      007F43 E0               [24]  928 	movx	a,@dptr
      007F44 FA               [12]  929 	mov	r2,a
      007F45 90 09 A9         [24]  930 	mov	dptr,#_change_owned_result_10001_303
      007F48 E0               [24]  931 	movx	a,@dptr
      007F49 4A               [12]  932 	orl	a,r2
      007F4A F0               [24]  933 	movx	@dptr,a
      007F4B                        934 00118$:
                                    935 ;	quantum/action_util.c:113: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007F4B 0B               [12]  936 	inc	r3
      007F4C 90 09 AA         [24]  937 	mov	dptr,#_change_owned_bit_20001_304
      007F4F E0               [24]  938 	movx	a,@dptr
      007F50 25 E0            [12]  939 	add	a,acc
      007F52 F0               [24]  940 	movx	@dptr,a
      007F53 80 BC            [24]  941 	sjmp	00117$
      007F55                        942 00112$:
                                    943 ;	quantum/action_util.c:120: if (kind) owned_weak_mods = result;
      007F55 EE               [12]  944 	mov	a,r6
      007F56 60 09            [24]  945 	jz	00114$
      007F58 90 09 A9         [24]  946 	mov	dptr,#_change_owned_result_10001_303
      007F5B E0               [24]  947 	movx	a,@dptr
      007F5C 90 09 9E         [24]  948 	mov	dptr,#_owned_weak_mods
      007F5F F0               [24]  949 	movx	@dptr,a
      007F60 22               [24]  950 	ret
      007F61                        951 00114$:
                                    952 ;	quantum/action_util.c:121: else owned_mods = result;
      007F61 90 09 A9         [24]  953 	mov	dptr,#_change_owned_result_10001_303
      007F64 E0               [24]  954 	movx	a,@dptr
      007F65 90 09 9D         [24]  955 	mov	dptr,#_owned_mods
      007F68 F0               [24]  956 	movx	@dptr,a
                                    957 ;	quantum/action_util.c:122: }
      007F69 22               [24]  958 	ret
                                    959 ;------------------------------------------------------------
                                    960 ;Allocation info for local variables in function 'add_owned_mods'
                                    961 ;------------------------------------------------------------
                                    962 ;mods          Allocated with name '_add_owned_mods_mods_10000_312'
                                    963 ;------------------------------------------------------------
                                    964 ;	quantum/action_util.c:123: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                    965 ;	-----------------------------------------
                                    966 ;	 function add_owned_mods
                                    967 ;	-----------------------------------------
      007F6A                        968 _add_owned_mods:
      007F6A E5 82            [12]  969 	mov	a,dpl
      007F6C 90 09 AB         [24]  970 	mov	dptr,#_add_owned_mods_mods_10000_312
      007F6F 12 83 87         [24]  971 	lcall	_ak820_outline_0117
      007F72 74 01            [12]  972 	mov	a,#0x01
      007F74 F0               [24]  973 	movx	@dptr,a
      007F75 8F 82            [24]  974 	mov	dpl, r7
      007F77 02 7E 9B         [24]  975 	ljmp	_change_owned
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'del_owned_mods'
                                    978 ;------------------------------------------------------------
                                    979 ;mods          Allocated with name '_del_owned_mods_mods_10000_314'
                                    980 ;------------------------------------------------------------
                                    981 ;	quantum/action_util.c:124: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                    982 ;	-----------------------------------------
                                    983 ;	 function del_owned_mods
                                    984 ;	-----------------------------------------
      007F7A                        985 _del_owned_mods:
      007F7A E5 82            [12]  986 	mov	a,dpl
      007F7C 90 09 AC         [24]  987 	mov	dptr,#_del_owned_mods_mods_10000_314
      007F7F 12 83 87         [24]  988 	lcall	_ak820_outline_0117
      007F82 12 7A 0F         [24]  989 	lcall	_ak820_outline_0189
      007F85 02 7E 9B         [24]  990 	ljmp	_change_owned
                                    991 ;------------------------------------------------------------
                                    992 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                    993 ;------------------------------------------------------------
                                    994 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_316'
                                    995 ;------------------------------------------------------------
                                    996 ;	quantum/action_util.c:125: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                    997 ;	-----------------------------------------
                                    998 ;	 function add_owned_weak_mods
                                    999 ;	-----------------------------------------
      007F88                       1000 _add_owned_weak_mods:
      007F88 E5 82            [12] 1001 	mov	a,dpl
      007F8A 90 09 AD         [24] 1002 	mov	dptr,#_add_owned_weak_mods_mods_10000_316
      007F8D 12 83 87         [24] 1003 	lcall	_ak820_outline_0117
      007F90 74 03            [12] 1004 	mov	a,#0x03
      007F92 F0               [24] 1005 	movx	@dptr,a
      007F93 8F 82            [24] 1006 	mov	dpl, r7
      007F95 02 7E 9B         [24] 1007 	ljmp	_change_owned
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1010 ;------------------------------------------------------------
                                   1011 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_318'
                                   1012 ;------------------------------------------------------------
                                   1013 ;	quantum/action_util.c:126: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1014 ;	-----------------------------------------
                                   1015 ;	 function del_owned_weak_mods
                                   1016 ;	-----------------------------------------
      007F98                       1017 _del_owned_weak_mods:
      007F98 E5 82            [12] 1018 	mov	a,dpl
      007F9A 90 09 AE         [24] 1019 	mov	dptr,#_del_owned_weak_mods_mods_10000_318
      007F9D 12 83 87         [24] 1020 	lcall	_ak820_outline_0117
      007FA0 74 02            [12] 1021 	mov	a,#0x02
      007FA2 F0               [24] 1022 	movx	@dptr,a
      007FA3 8F 82            [24] 1023 	mov	dpl, r7
      007FA5 02 7E 9B         [24] 1024 	ljmp	_change_owned
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1027 ;------------------------------------------------------------
                                   1028 ;i             Allocated with name '_clear_owned_mods_i_20000_322'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/action_util.c:127: void clear_owned_mods(void) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function clear_owned_mods
                                   1033 ;	-----------------------------------------
      007FA8                       1034 _clear_owned_mods:
                                   1035 ;	quantum/action_util.c:128: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007FA8 7F 00            [12] 1036 	mov	r7,#0x00
      007FAA                       1037 00103$:
      007FAA BF 08 00         [24] 1038 	cjne	r7,#0x08,00122$
      007FAD                       1039 00122$:
      007FAD 50 1A            [24] 1040 	jnc	00101$
      007FAF EF               [12] 1041 	mov	a,r7
      007FB0 24 8D            [12] 1042 	add	a, #_owned_mod_refs
      007FB2 FD               [12] 1043 	mov	r5,a
      007FB3 E4               [12] 1044 	clr	a
      007FB4 34 09            [12] 1045 	addc	a, #(_owned_mod_refs >> 8)
      007FB6 FE               [12] 1046 	mov	r6,a
      007FB7 EF               [12] 1047 	mov	a,r7
      007FB8 24 95            [12] 1048 	add	a, #_owned_weak_refs
      007FBA F5 82            [12] 1049 	mov	dpl,a
      007FBC E4               [12] 1050 	clr	a
      007FBD 34 09            [12] 1051 	addc	a, #(_owned_weak_refs >> 8)
      007FBF F5 83            [12] 1052 	mov	dph,a
      007FC1 E4               [12] 1053 	clr	a
      007FC2 F0               [24] 1054 	movx	@dptr,a
      007FC3 12 83 8E         [24] 1055 	lcall	_ak820_outline_0121
      007FC6 0F               [12] 1056 	inc	r7
      007FC7 80 E1            [24] 1057 	sjmp	00103$
      007FC9                       1058 00101$:
                                   1059 ;	quantum/action_util.c:129: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007FC9 90 09 A0         [24] 1060 	mov	dptr,#(_macro_mods + 0x0001)
      007FCC E4               [12] 1061 	clr	a
      007FCD F0               [24] 1062 	movx	@dptr,a
      007FCE 90 09 9F         [24] 1063 	mov	dptr,#_macro_mods
      007FD1 F0               [24] 1064 	movx	@dptr,a
      007FD2 90 09 9E         [24] 1065 	mov	dptr,#_owned_weak_mods
      007FD5 F0               [24] 1066 	movx	@dptr,a
      007FD6 90 09 9D         [24] 1067 	mov	dptr,#_owned_mods
      007FD9 F0               [24] 1068 	movx	@dptr,a
                                   1069 ;	quantum/action_util.c:130: ak820_macro_cancelled = true;
      007FDA 90 09 A2         [24] 1070 	mov	dptr,#_ak820_macro_cancelled
      007FDD 04               [12] 1071 	inc	a
      007FDE F0               [24] 1072 	movx	@dptr,a
                                   1073 ;	quantum/action_util.c:131: }
      007FDF 22               [24] 1074 	ret
                                   1075 ;------------------------------------------------------------
                                   1076 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1077 ;------------------------------------------------------------
                                   1078 ;i             Allocated with name '_clear_owned_keys_i_20000_325'
                                   1079 ;i             Allocated with name '_clear_owned_keys_i_20000_326'
                                   1080 ;------------------------------------------------------------
                                   1081 ;	quantum/action_util.c:137: void clear_owned_keys(void) {
                                   1082 ;	-----------------------------------------
                                   1083 ;	 function clear_owned_keys
                                   1084 ;	-----------------------------------------
      007FE0                       1085 _clear_owned_keys:
                                   1086 ;	quantum/action_util.c:138: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007FE0 7F 00            [12] 1087 	mov	r7,#0x00
      007FE2                       1088 00104$:
      007FE2 EF               [12] 1089 	mov	a,r7
      007FE3 24 5B            [12] 1090 	add	a,#0xff - 0xa4
      007FE5 40 0D            [24] 1091 	jc	00101$
                                   1092 ;	free result
      007FE7 EF               [12] 1093 	mov	a,r7
      007FE8 24 AF            [12] 1094 	add	a, #_key_refs
      007FEA F5 82            [12] 1095 	mov	dpl,a
      007FEC E4               [12] 1096 	clr	a
      007FED 34 09            [12] 1097 	addc	a, #(_key_refs >> 8)
      007FEF 12 7E 20         [24] 1098 	lcall	_ak820_outline_0165
      007FF2 80 EE            [24] 1099 	sjmp	00104$
      007FF4                       1100 00101$:
                                   1101 ;	quantum/action_util.c:139: distinct_keys = 0;
      007FF4 90 0A 54         [24] 1102 	mov	dptr,#_distinct_keys
      007FF7 E4               [12] 1103 	clr	a
      007FF8 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	quantum/action_util.c:140: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007FF9 FF               [12] 1106 	mov	r7,a
      007FFA                       1107 00107$:
      007FFA BF 15 00         [24] 1108 	cjne	r7,#0x15,00142$
      007FFD                       1109 00142$:
      007FFD 50 0D            [24] 1110 	jnc	00109$
      007FFF EF               [12] 1111 	mov	a,r7
      008000 24 55            [12] 1112 	add	a, #_macro_keys
      008002 F5 82            [12] 1113 	mov	dpl,a
      008004 E4               [12] 1114 	clr	a
      008005 34 0A            [12] 1115 	addc	a, #(_macro_keys >> 8)
      008007 12 7E 20         [24] 1116 	lcall	_ak820_outline_0165
      00800A 80 EE            [24] 1117 	sjmp	00107$
      00800C                       1118 00109$:
                                   1119 ;	quantum/action_util.c:141: }
      00800C 22               [24] 1120 	ret
                                   1121 ;------------------------------------------------------------
                                   1122 ;Allocation info for local variables in function 'add_owned_key'
                                   1123 ;------------------------------------------------------------
                                   1124 ;code          Allocated with name '_add_owned_key_code_10000_327'
                                   1125 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_336'
                                   1126 ;key           Allocated with name '_add_owned_key_key_50000_337'
                                   1127 ;i             Allocated with name '_add_owned_key_i_40000_335'
                                   1128 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_339'
                                   1129 ;key           Allocated with name '_add_owned_key_key_40000_340'
                                   1130 ;------------------------------------------------------------
                                   1131 ;	quantum/action_util.c:142: bool add_owned_key(uint8_t code) {
                                   1132 ;	-----------------------------------------
                                   1133 ;	 function add_owned_key
                                   1134 ;	-----------------------------------------
      00800D                       1135 _add_owned_key:
      00800D E5 82            [12] 1136 	mov	a,dpl
      00800F 90 0A 6A         [24] 1137 	mov	dptr,#_add_owned_key_code_10000_327
      008012 12 83 9F         [24] 1138 	lcall	_ak820_outline_0132
                                   1139 ;	quantum/action_util.c:143: if (!ak820_macro_change(macro_keys, code, true)) return false;
      008015 74 01            [12] 1140 	mov	a,#0x01
      008017 F0               [24] 1141 	movx	@dptr,a
      008018 90 0A 55         [24] 1142 	mov	dptr,#_macro_keys
      00801B C0 07            [24] 1143 	push	ar7
      00801D 12 7E 2F         [24] 1144 	lcall	_ak820_macro_change
      008020 E5 82            [12] 1145 	mov	a, dpl
      008022 D0 07            [24] 1146 	pop	ar7
      008024 70 03            [24] 1147 	jnz	00102$
      008026 F5 82            [12] 1148 	mov	dpl,a
      008028 22               [24] 1149 	ret
      008029                       1150 00102$:
                                   1151 ;	quantum/action_util.c:144: if (key_refs[code]++) return false;
      008029 12 83 59         [24] 1152 	lcall	_ak820_outline_0030
      00802C FC               [12] 1153 	mov	r4,a
      00802D 04               [12] 1154 	inc	a
      00802E 12 83 8E         [24] 1155 	lcall	_ak820_outline_0121
      008031 EC               [12] 1156 	mov	a,r4
      008032 60 04            [24] 1157 	jz	00104$
      008034 75 82 00         [24] 1158 	mov	dpl, #0x00
      008037 22               [24] 1159 	ret
      008038                       1160 00104$:
                                   1161 ;	quantum/action_util.c:145: ++distinct_keys;
      008038 90 0A 54         [24] 1162 	mov	dptr,#_distinct_keys
      00803B E0               [24] 1163 	movx	a,@dptr
      00803C 24 01            [12] 1164 	add	a, #0x01
      00803E F0               [24] 1165 	movx	@dptr,a
                                   1166 ;	quantum/action_util.c:147: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      00803F 90 0D CD         [24] 1167 	mov	dptr,#_keyboard_protocol
      008042 E0               [24] 1168 	movx	a,@dptr
      008043 60 11            [24] 1169 	jz	00106$
      008045 90 0A D9         [24] 1170 	mov	dptr,#_keymap_config
      008048 E0               [24] 1171 	movx	a,@dptr
      008049 30 E7 0A         [24] 1172 	jnb	acc.7,00106$
                                   1173 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00804C 12 83 AA         [24] 1174 	lcall	_ak820_outline_0175
      00804F 12 71 38         [24] 1175 	lcall	_add_key_to_report
                                   1176 ;	quantum/action_util.c:147: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      008052 75 82 01         [24] 1177 	mov	dpl, #0x01
      008055 22               [24] 1178 	ret
      008056                       1179 00106$:
                                   1180 ;	quantum/action_util.c:149: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      008056 90 0A 54         [24] 1181 	mov	dptr,#_distinct_keys
      008059 E0               [24] 1182 	movx	a,@dptr
      00805A 24 F9            [12] 1183 	add	a,#0xff - 0x06
      00805C 50 17            [24] 1184 	jnc	00110$
                                   1185 ;	free result
                                   1186 ;	quantum/action_util.c:150: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      00805E 7F 00            [12] 1187 	mov	r7,#0x00
      008060                       1188 00115$:
      008060 BF 06 00         [24] 1189 	cjne	r7,#0x06,00174$
      008063                       1190 00174$:
      008063 50 1E            [24] 1191 	jnc	00111$
      008065 EF               [12] 1192 	mov	a,r7
      008066 24 E2            [12] 1193 	add	a, #(_actual_keyboard_report + 0x0002)
      008068 F5 82            [12] 1194 	mov	dpl,a
      00806A E4               [12] 1195 	clr	a
      00806B 34 0D            [12] 1196 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      00806D F5 83            [12] 1197 	mov	dph,a
      00806F 74 01            [12] 1198 	mov	a,#0x01
      008071 F0               [24] 1199 	movx	@dptr,a
      008072 0F               [12] 1200 	inc	r7
      008073 80 EB            [24] 1201 	sjmp	00115$
      008075                       1202 00110$:
                                   1203 ;	quantum/action_util.c:151: } else add_key(code);
      008075 90 0A 6A         [24] 1204 	mov	dptr,#_add_owned_key_code_10000_327
      008078 E0               [24] 1205 	movx	a,@dptr
                                   1206 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      008079 90 08 1B         [24] 1207 	mov	dptr,#_add_key_to_report_PARM_2
      00807C F0               [24] 1208 	movx	@dptr,a
      00807D 90 0D E0         [24] 1209 	mov	dptr,#_actual_keyboard_report
      008080 12 71 38         [24] 1210 	lcall	_add_key_to_report
                                   1211 ;	quantum/action_util.c:151: } else add_key(code);
      008083                       1212 00111$:
                                   1213 ;	quantum/action_util.c:152: return true;
      008083 75 82 01         [24] 1214 	mov	dpl, #0x01
                                   1215 ;	quantum/action_util.c:153: }
      008086 22               [24] 1216 	ret
                                   1217 ;------------------------------------------------------------
                                   1218 ;Allocation info for local variables in function 'del_owned_key'
                                   1219 ;------------------------------------------------------------
                                   1220 ;code          Allocated with name '_del_owned_key_code_10000_342'
                                   1221 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_353'
                                   1222 ;key           Allocated with name '_del_owned_key_key_50000_354'
                                   1223 ;key           Allocated with name '_del_owned_key_key_40000_351'
                                   1224 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_359'
                                   1225 ;key           Allocated with name '_del_owned_key_key_70000_360'
                                   1226 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_362'
                                   1227 ;key           Allocated with name '_del_owned_key_key_40000_363'
                                   1228 ;------------------------------------------------------------
                                   1229 ;	quantum/action_util.c:154: bool del_owned_key(uint8_t code) {
                                   1230 ;	-----------------------------------------
                                   1231 ;	 function del_owned_key
                                   1232 ;	-----------------------------------------
      008087                       1233 _del_owned_key:
      008087 E5 82            [12] 1234 	mov	a,dpl
      008089 90 0A 6B         [24] 1235 	mov	dptr,#_del_owned_key_code_10000_342
      00808C 12 83 9F         [24] 1236 	lcall	_ak820_outline_0132
                                   1237 ;	quantum/action_util.c:155: if (!ak820_macro_change(macro_keys, code, false)) return false;
      00808F E4               [12] 1238 	clr	a
      008090 F0               [24] 1239 	movx	@dptr,a
      008091 90 0A 55         [24] 1240 	mov	dptr,#_macro_keys
      008094 C0 07            [24] 1241 	push	ar7
      008096 12 7E 2F         [24] 1242 	lcall	_ak820_macro_change
      008099 E5 82            [12] 1243 	mov	a, dpl
      00809B D0 07            [24] 1244 	pop	ar7
      00809D 70 03            [24] 1245 	jnz	00102$
      00809F F5 82            [12] 1246 	mov	dpl,a
      0080A1 22               [24] 1247 	ret
      0080A2                       1248 00102$:
                                   1249 ;	quantum/action_util.c:156: if (!key_refs[code] || --key_refs[code]) return false;
      0080A2 12 83 59         [24] 1250 	lcall	_ak820_outline_0030
      0080A5 FC               [12] 1251 	mov	r4,a
      0080A6 60 07            [24] 1252 	jz	00103$
      0080A8 1C               [12] 1253 	dec	r4
      0080A9 12 43 37         [24] 1254 	lcall	_ak820_outline_0063
      0080AC EC               [12] 1255 	mov	a,r4
      0080AD 60 04            [24] 1256 	jz	00104$
      0080AF                       1257 00103$:
      0080AF 75 82 00         [24] 1258 	mov	dpl, #0x00
      0080B2 22               [24] 1259 	ret
      0080B3                       1260 00104$:
                                   1261 ;	quantum/action_util.c:157: --distinct_keys;
      0080B3 90 0A 54         [24] 1262 	mov	dptr,#_distinct_keys
      0080B6 E0               [24] 1263 	movx	a,@dptr
      0080B7 14               [12] 1264 	dec	a
      0080B8 F0               [24] 1265 	movx	@dptr,a
                                   1266 ;	quantum/action_util.c:159: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      0080B9 90 0D CD         [24] 1267 	mov	dptr,#_keyboard_protocol
      0080BC E0               [24] 1268 	movx	a,@dptr
      0080BD 60 16            [24] 1269 	jz	00107$
      0080BF 90 0A D9         [24] 1270 	mov	dptr,#_keymap_config
      0080C2 E0               [24] 1271 	movx	a,@dptr
      0080C3 30 E7 0F         [24] 1272 	jnb	acc.7,00107$
                                   1273 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      0080C6 90 08 1E         [24] 1274 	mov	dptr,#_del_key_from_report_PARM_2
      0080C9 EF               [12] 1275 	mov	a,r7
      0080CA F0               [24] 1276 	movx	@dptr,a
      0080CB 90 0D E0         [24] 1277 	mov	dptr,#_actual_keyboard_report
      0080CE 12 71 6E         [24] 1278 	lcall	_del_key_from_report
                                   1279 ;	quantum/action_util.c:159: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      0080D1 75 82 01         [24] 1280 	mov	dpl, #0x01
      0080D4 22               [24] 1281 	ret
      0080D5                       1282 00107$:
                                   1283 ;	quantum/action_util.c:161: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      0080D5 90 0A 54         [24] 1284 	mov	dptr,#_distinct_keys
      0080D8 E0               [24] 1285 	movx	a,@dptr
      0080D9 FF               [12] 1286 	mov  r7,a
      0080DA 24 F9            [12] 1287 	add	a,#0xff - 0x06
      0080DC 50 04            [24] 1288 	jnc	00110$
                                   1289 ;	free result
      0080DE 75 82 01         [24] 1290 	mov	dpl, #0x01
      0080E1 22               [24] 1291 	ret
      0080E2                       1292 00110$:
                                   1293 ;	quantum/action_util.c:162: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      0080E2 BF 06 1F         [24] 1294 	cjne	r7,#0x06,00115$
                                   1295 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0080E5 90 0D E0         [24] 1296 	mov	dptr,#_actual_keyboard_report
      0080E8 12 71 A4         [24] 1297 	lcall	_clear_keys_from_report
                                   1298 ;	quantum/action_util.c:165: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      0080EB 7F 04            [12] 1299 	mov	r7,#0x04
      0080ED                       1300 00122$:
      0080ED EF               [12] 1301 	mov	a,r7
      0080EE 24 5B            [12] 1302 	add	a,#0xff - 0xa4
      0080F0 40 20            [24] 1303 	jc	00116$
                                   1304 ;	free result
      0080F2 12 83 59         [24] 1305 	lcall	_ak820_outline_0030
      0080F5 60 0A            [24] 1306 	jz	00123$
                                   1307 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      0080F7 12 83 AA         [24] 1308 	lcall	_ak820_outline_0175
      0080FA C0 07            [24] 1309 	push	ar7
      0080FC 12 71 38         [24] 1310 	lcall	_add_key_to_report
      0080FF D0 07            [24] 1311 	pop	ar7
                                   1312 ;	quantum/action_util.c:165: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008101                       1313 00123$:
      008101 0F               [12] 1314 	inc	r7
      008102 80 E9            [24] 1315 	sjmp	00122$
      008104                       1316 00115$:
                                   1317 ;	quantum/action_util.c:166: } else del_key(code);
      008104 90 0A 6B         [24] 1318 	mov	dptr,#_del_owned_key_code_10000_342
      008107 E0               [24] 1319 	movx	a,@dptr
                                   1320 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008108 90 08 1E         [24] 1321 	mov	dptr,#_del_key_from_report_PARM_2
      00810B F0               [24] 1322 	movx	@dptr,a
      00810C 90 0D E0         [24] 1323 	mov	dptr,#_actual_keyboard_report
      00810F 12 71 6E         [24] 1324 	lcall	_del_key_from_report
                                   1325 ;	quantum/action_util.c:166: } else del_key(code);
      008112                       1326 00116$:
                                   1327 ;	quantum/action_util.c:167: return true;
      008112 75 82 01         [24] 1328 	mov	dpl, #0x01
                                   1329 ;	quantum/action_util.c:168: }
      008115 22               [24] 1330 	ret
                                   1331 ;------------------------------------------------------------
                                   1332 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1333 ;------------------------------------------------------------
                                   1334 ;i             Allocated with name '_clear_owned_usages_i_20000_367'
                                   1335 ;i             Allocated with name '_clear_owned_usages_i_20000_368'
                                   1336 ;------------------------------------------------------------
                                   1337 ;	quantum/action_util.c:178: void clear_owned_usages(void) {
                                   1338 ;	-----------------------------------------
                                   1339 ;	 function clear_owned_usages
                                   1340 ;	-----------------------------------------
      008116                       1341 _clear_owned_usages:
                                   1342 ;	quantum/action_util.c:179: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      008116 7F 00            [12] 1343 	mov	r7,#0x00
      008118                       1344 00104$:
      008118 BF 1E 00         [24] 1345 	cjne	r7,#0x1e,00141$
      00811B                       1346 00141$:
      00811B 50 14            [24] 1347 	jnc	00101$
      00811D EF               [12] 1348 	mov	a,r7
      00811E 24 6C            [12] 1349 	add	a, #_usage_refs
      008120 FD               [12] 1350 	mov	r5,a
      008121 E4               [12] 1351 	clr	a
      008122 34 0A            [12] 1352 	addc	a, #(_usage_refs >> 8)
      008124 FE               [12] 1353 	mov	r6,a
      008125 EF               [12] 1354 	mov	a,r7
      008126 12 83 6E         [24] 1355 	lcall	_ak820_outline_0067
      008129 E4               [12] 1356 	clr	a
      00812A F0               [24] 1357 	movx	@dptr,a
      00812B 12 83 8E         [24] 1358 	lcall	_ak820_outline_0121
      00812E 0F               [12] 1359 	inc	r7
      00812F 80 E7            [24] 1360 	sjmp	00104$
      008131                       1361 00101$:
                                   1362 ;	quantum/action_util.c:180: usage_lengths[0] = usage_lengths[1] = 0;
      008131 90 0A A9         [24] 1363 	mov	dptr,#(_usage_lengths + 0x0001)
      008134 E4               [12] 1364 	clr	a
      008135 F0               [24] 1365 	movx	@dptr,a
      008136 90 0A A8         [24] 1366 	mov	dptr,#_usage_lengths
      008139 F0               [24] 1367 	movx	@dptr,a
                                   1368 ;	quantum/action_util.c:181: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      00813A FF               [12] 1369 	mov	r7,a
      00813B                       1370 00107$:
      00813B BF 04 00         [24] 1371 	cjne	r7,#0x04,00143$
      00813E                       1372 00143$:
      00813E 50 0D            [24] 1373 	jnc	00109$
      008140 EF               [12] 1374 	mov	a,r7
      008141 24 AA            [12] 1375 	add	a, #_macro_usages
      008143 F5 82            [12] 1376 	mov	dpl,a
      008145 E4               [12] 1377 	clr	a
      008146 34 0A            [12] 1378 	addc	a, #(_macro_usages >> 8)
      008148 12 7E 20         [24] 1379 	lcall	_ak820_outline_0165
      00814B 80 EE            [24] 1380 	sjmp	00107$
      00814D                       1381 00109$:
                                   1382 ;	quantum/action_util.c:182: }
      00814D 22               [24] 1383 	ret
                                   1384 ;------------------------------------------------------------
                                   1385 ;Allocation info for local variables in function 'owned_usage_key'
                                   1386 ;------------------------------------------------------------
                                   1387 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1388 ;code          Allocated with name '_owned_usage_key_code_10000_369'
                                   1389 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_370'
                                   1390 ;which         Allocated with name '_owned_usage_key_which_10000_370'
                                   1391 ;base          Allocated with name '_owned_usage_key_base_10000_370'
                                   1392 ;count         Allocated with name '_owned_usage_key_count_10000_370'
                                   1393 ;index         Allocated with name '_owned_usage_key_index_10000_370'
                                   1394 ;pos           Allocated with name '_owned_usage_key_pos_30001_377'
                                   1395 ;i             Allocated with name '_owned_usage_key_i_40001_378'
                                   1396 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_381'
                                   1397 ;key           Allocated with name '_owned_usage_key_key_40000_382'
                                   1398 ;------------------------------------------------------------
                                   1399 ;	quantum/action_util.c:183: void owned_usage_key(uint8_t code, bool pressed) {
                                   1400 ;	-----------------------------------------
                                   1401 ;	 function owned_usage_key
                                   1402 ;	-----------------------------------------
      00814E                       1403 _owned_usage_key:
      00814E E5 82            [12] 1404 	mov	a,dpl
      008150 90 0A AF         [24] 1405 	mov	dptr,#_owned_usage_key_code_10000_369
      008153 F0               [24] 1406 	movx	@dptr,a
                                   1407 ;	quantum/action_util.c:184: uint8_t which = code >= KC_AUDIO_MUTE;
      008154 E0               [24] 1408 	movx	a,@dptr
      008155 FF               [12] 1409 	mov	r7,a
      008156 BF A8 00         [24] 1410 	cjne	r7,#0xa8,00244$
      008159                       1411 00244$:
      008159 B3               [12] 1412 	cpl	c
      00815A 92 22            [24] 1413 	mov	_owned_usage_key_sloc0_1_0,c
      00815C E4               [12] 1414 	clr	a
      00815D 33               [12] 1415 	rlc	a
      00815E FF               [12] 1416 	mov	r7,a
      00815F 90 0A B2         [24] 1417 	mov	dptr,#_owned_usage_key_which_10000_370
      008162 F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	quantum/action_util.c:185: uint8_t base = which ? SYSTEM_COUNT : 0;
      008163 EF               [12] 1420 	mov	a,r7
      008164 60 02            [24] 1421 	jz	00129$
      008166 74 03            [12] 1422 	mov	a,#0x03
      008168                       1423 00129$:
      008168 FE               [12] 1424 	mov	r6,a
                                   1425 ;	quantum/action_util.c:186: uint8_t count = usage_lengths[which];
      008169 EF               [12] 1426 	mov	a,r7
      00816A 24 A8            [12] 1427 	add	a, #_usage_lengths
      00816C FD               [12] 1428 	mov	r5,a
      00816D E4               [12] 1429 	clr	a
      00816E 34 0A            [12] 1430 	addc	a, #(_usage_lengths >> 8)
      008170 FF               [12] 1431 	mov	r7,a
      008171 12 83 B3         [24] 1432 	lcall	_ak820_outline_0190
      008174 E0               [24] 1433 	movx	a,@dptr
      008175 FC               [12] 1434 	mov	r4,a
                                   1435 ;	quantum/action_util.c:187: uint8_t index = code - KC_SYSTEM_POWER;
      008176 90 0A AF         [24] 1436 	mov	dptr,#_owned_usage_key_code_10000_369
      008179 E0               [24] 1437 	movx	a,@dptr
      00817A 24 5B            [12] 1438 	add	a,#0x5b
      00817C FB               [12] 1439 	mov	r3,a
                                   1440 ;	quantum/action_util.c:188: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      00817D 90 0A AE         [24] 1441 	mov	dptr,#_owned_usage_key_PARM_2
      008180 E0               [24] 1442 	movx	a,@dptr
      008181 FA               [12] 1443 	mov	r2,a
      008182 90 09 A3         [24] 1444 	mov	dptr,#_ak820_macro_change_PARM_2
      008185 EB               [12] 1445 	mov	a,r3
      008186 F0               [24] 1446 	movx	@dptr,a
      008187 90 09 A4         [24] 1447 	mov	dptr,#_ak820_macro_change_PARM_3
      00818A EA               [12] 1448 	mov	a,r2
      00818B F0               [24] 1449 	movx	@dptr,a
      00818C 90 0A AA         [24] 1450 	mov	dptr,#_macro_usages
      00818F C0 07            [24] 1451 	push	ar7
      008191 C0 06            [24] 1452 	push	ar6
      008193 C0 05            [24] 1453 	push	ar5
      008195 C0 04            [24] 1454 	push	ar4
      008197 C0 03            [24] 1455 	push	ar3
      008199 C0 02            [24] 1456 	push	ar2
      00819B 12 7E 2F         [24] 1457 	lcall	_ak820_macro_change
      00819E E5 82            [12] 1458 	mov	a, dpl
      0081A0 D0 02            [24] 1459 	pop	ar2
      0081A2 D0 03            [24] 1460 	pop	ar3
      0081A4 D0 04            [24] 1461 	pop	ar4
      0081A6 D0 05            [24] 1462 	pop	ar5
      0081A8 D0 06            [24] 1463 	pop	ar6
      0081AA D0 07            [24] 1464 	pop	ar7
      0081AC 70 01            [24] 1465 	jnz	00102$
      0081AE 22               [24] 1466 	ret
      0081AF                       1467 00102$:
                                   1468 ;	quantum/action_util.c:189: if (pressed) {
      0081AF EA               [12] 1469 	mov	a,r2
      0081B0 60 1B            [24] 1470 	jz	00115$
                                   1471 ;	quantum/action_util.c:190: if (usage_refs[index]++) return;
      0081B2 12 83 78         [24] 1472 	lcall	_ak820_outline_0075
      0081B5 04               [12] 1473 	inc	a
      0081B6 12 6E B5         [24] 1474 	lcall	_ak820_outline_0139
      0081B9 E8               [12] 1475 	mov	a,r0
      0081BA 60 01            [24] 1476 	jz	00104$
      0081BC 22               [24] 1477 	ret
      0081BD                       1478 00104$:
                                   1479 ;	quantum/action_util.c:191: usage_order[base + count++] = index;
      0081BD 90 0A B3         [24] 1480 	mov	dptr,#_owned_usage_key_count_10000_370
      0081C0 EC               [12] 1481 	mov	a,r4
      0081C1 04               [12] 1482 	inc	a
      0081C2 F0               [24] 1483 	movx	@dptr,a
      0081C3 EC               [12] 1484 	mov	a,r4
      0081C4 2E               [12] 1485 	add	a, r6
      0081C5 12 83 6E         [24] 1486 	lcall	_ak820_outline_0067
      0081C8 EB               [12] 1487 	mov	a,r3
      0081C9 F0               [24] 1488 	movx	@dptr,a
      0081CA 02 82 2E         [24] 1489 	ljmp	00116$
      0081CD                       1490 00115$:
                                   1491 ;	quantum/action_util.c:193: if (!usage_refs[index] || --usage_refs[index]) return;
      0081CD 12 83 78         [24] 1492 	lcall	_ak820_outline_0075
      0081D0 60 07            [24] 1493 	jz	00105$
      0081D2 18               [12] 1494 	dec	r0
      0081D3 12 83 67         [24] 1495 	lcall	_ak820_outline_0062
      0081D6 E8               [12] 1496 	mov	a,r0
      0081D7 60 01            [24] 1497 	jz	00106$
      0081D9                       1498 00105$:
      0081D9 22               [24] 1499 	ret
      0081DA                       1500 00106$:
                                   1501 ;	quantum/action_util.c:195: while (usage_order[base + pos] != index) ++pos;
      0081DA 7A 00            [12] 1502 	mov	r2,#0x00
      0081DC                       1503 00108$:
      0081DC EA               [12] 1504 	mov	a,r2
      0081DD 2E               [12] 1505 	add	a, r6
      0081DE 12 83 6E         [24] 1506 	lcall	_ak820_outline_0067
      0081E1 E0               [24] 1507 	movx	a,@dptr
      0081E2 B5 03 02         [24] 1508 	cjne	a,ar3,00251$
      0081E5 80 03            [24] 1509 	sjmp	00167$
      0081E7                       1510 00251$:
      0081E7 0A               [12] 1511 	inc	r2
      0081E8 80 F2            [24] 1512 	sjmp	00108$
      0081EA                       1513 00167$:
      0081EA 90 0A B4         [24] 1514 	mov	dptr,#_owned_usage_key_pos_30001_377
      0081ED EA               [12] 1515 	mov	a,r2
      0081EE F0               [24] 1516 	movx	@dptr,a
                                   1517 ;	quantum/action_util.c:196: --count;
      0081EF 1C               [12] 1518 	dec	r4
      0081F0 90 0A B3         [24] 1519 	mov	dptr,#_owned_usage_key_count_10000_370
      0081F3 EC               [12] 1520 	mov	a,r4
      0081F4 F0               [24] 1521 	movx	@dptr,a
                                   1522 ;	quantum/action_util.c:197: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      0081F5 8A 03            [24] 1523 	mov	ar3,r2
      0081F7                       1524 00125$:
      0081F7 C3               [12] 1525 	clr	c
      0081F8 EB               [12] 1526 	mov	a,r3
      0081F9 9C               [12] 1527 	subb	a,r4
      0081FA 50 23            [24] 1528 	jnc	00111$
      0081FC C0 05            [24] 1529 	push	ar5
      0081FE C0 07            [24] 1530 	push	ar7
      008200 EB               [12] 1531 	mov	a,r3
      008201 2E               [12] 1532 	add	a, r6
      008202 FA               [12] 1533 	mov	r2,a
      008203 24 8A            [12] 1534 	add	a, #_usage_order
      008205 F8               [12] 1535 	mov	r0,a
      008206 E4               [12] 1536 	clr	a
      008207 34 0A            [12] 1537 	addc	a, #(_usage_order >> 8)
      008209 F9               [12] 1538 	mov	r1,a
      00820A 0A               [12] 1539 	inc	r2
      00820B EA               [12] 1540 	mov	a,r2
      00820C 33               [12] 1541 	rlc	a
      00820D 95 E0            [12] 1542 	subb	a,acc
      00820F FF               [12] 1543 	mov	r7,a
      008210 EA               [12] 1544 	mov	a,r2
      008211 12 83 94         [24] 1545 	lcall	_ak820_outline_0125
      008214 12 38 B6         [24] 1546 	lcall	_ak820_outline_0160
      008217 F0               [24] 1547 	movx	@dptr,a
      008218 0B               [12] 1548 	inc	r3
      008219 D0 07            [24] 1549 	pop	ar7
      00821B D0 05            [24] 1550 	pop	ar5
      00821D 80 D8            [24] 1551 	sjmp	00125$
      00821F                       1552 00111$:
                                   1553 ;	quantum/action_util.c:198: usage_lengths[which] = count;
      00821F 12 83 B3         [24] 1554 	lcall	_ak820_outline_0190
      008222 EC               [12] 1555 	mov	a,r4
      008223 F0               [24] 1556 	movx	@dptr,a
                                   1557 ;	quantum/action_util.c:199: if (pos != count) return; /* A non-winning owner changed only storage. */
      008224 90 0A B4         [24] 1558 	mov	dptr,#_owned_usage_key_pos_30001_377
      008227 E0               [24] 1559 	movx	a,@dptr
      008228 B5 04 02         [24] 1560 	cjne	a,ar4,00253$
      00822B 80 01            [24] 1561 	sjmp	00116$
      00822D                       1562 00253$:
      00822D 22               [24] 1563 	ret
      00822E                       1564 00116$:
                                   1565 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      00822E 90 0A B3         [24] 1566 	mov	dptr,#_owned_usage_key_count_10000_370
      008231 E0               [24] 1567 	movx	a,@dptr
      008232 FC               [12] 1568 	mov	r4,a
      008233 12 83 B3         [24] 1569 	lcall	_ak820_outline_0190
      008236 F0               [24] 1570 	movx	@dptr,a
                                   1571 ;	quantum/action_util.c:202: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      008237 EC               [12] 1572 	mov	a,r4
      008238 60 15            [24] 1573 	jz	00131$
      00823A EC               [12] 1574 	mov	a,r4
      00823B 2E               [12] 1575 	add	a, r6
      00823C FE               [12] 1576 	mov	r6,a
      00823D 1E               [12] 1577 	dec	r6
      00823E EE               [12] 1578 	mov	a,r6
      00823F 33               [12] 1579 	rlc	a
      008240 95 E0            [12] 1580 	subb	a,acc
      008242 FF               [12] 1581 	mov	r7,a
      008243 EE               [12] 1582 	mov	a,r6
      008244 12 83 94         [24] 1583 	lcall	_ak820_outline_0125
      008247 24 A5            [12] 1584 	add	a,#0xa5
      008249 FE               [12] 1585 	mov	r6,a
      00824A 33               [12] 1586 	rlc	a
      00824B 95 E0            [12] 1587 	subb	a,acc
      00824D 80 02            [24] 1588 	sjmp	00132$
      00824F                       1589 00131$:
      00824F 7E 00            [12] 1590 	mov	r6,#0x00
      008251                       1591 00132$:
      008251 90 0A AF         [24] 1592 	mov	dptr,#_owned_usage_key_code_10000_369
      008254 EE               [12] 1593 	mov	a,r6
      008255 F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	quantum/action_util.c:203: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      008256 90 0A B2         [24] 1596 	mov	dptr,#_owned_usage_key_which_10000_370
      008259 E0               [24] 1597 	movx	a,@dptr
      00825A 60 18            [24] 1598 	jz	00118$
      00825C EE               [12] 1599 	mov	a,r6
      00825D 60 0B            [24] 1600 	jz	00133$
      00825F 8E 82            [24] 1601 	mov	dpl, r6
      008261 12 6F F5         [24] 1602 	lcall	_KEYCODE2CONSUMER
      008264 AD 82            [24] 1603 	mov	r5, dpl
      008266 AF 83            [24] 1604 	mov	r7, dph
      008268 80 04            [24] 1605 	sjmp	00134$
      00826A                       1606 00133$:
      00826A 7D 00            [12] 1607 	mov	r5,#0x00
      00826C 7F 00            [12] 1608 	mov	r7,#0x00
      00826E                       1609 00134$:
      00826E 12 83 B3         [24] 1610 	lcall	_ak820_outline_0190
      008271 02 6F A8         [24] 1611 	ljmp	_host_consumer_send
      008274                       1612 00118$:
                                   1613 ;	quantum/action_util.c:204: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008274 EE               [12] 1614 	mov	a,r6
      008275 60 22            [24] 1615 	jz	00135$
                                   1616 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      008277 BE A5 00         [24] 1617 	cjne	r6,#0xa5,00258$
      00827A                       1618 00258$:
      00827A 40 05            [24] 1619 	jc	00121$
      00827C EE               [12] 1620 	mov	a,r6
      00827D 24 58            [12] 1621 	add	a,#0xff - 0xa7
      00827F 50 08            [24] 1622 	jnc	00122$
                                   1623 ;	free result
      008281                       1624 00121$:
      008281 90 0A B0         [24] 1625 	mov	dptr,#_owned_usage_key___200000085_20000_370
      008284 12 4F 67         [24] 1626 	lcall	_ak820_outline_0182
      008287 80 09            [24] 1627 	sjmp	00123$
      008289                       1628 00122$:
                                   1629 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      008289 74 DC            [12] 1630 	mov	a,#0xdc
      00828B 2E               [12] 1631 	add	a, r6
      00828C 90 0A B0         [24] 1632 	mov	dptr,#_owned_usage_key___200000085_20000_370
      00828F 12 38 9C         [24] 1633 	lcall	_ak820_outline_0134
                                   1634 ;	quantum/action_util.c:204: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008292                       1635 00123$:
      008292 90 0A B0         [24] 1636 	mov	dptr,#_owned_usage_key___200000085_20000_370
      008295 E0               [24] 1637 	movx	a,@dptr
      008296 FF               [12] 1638 	mov	r7,a
      008297 80 02            [24] 1639 	sjmp	00136$
      008299                       1640 00135$:
      008299 7F 00            [12] 1641 	mov	r7,#0x00
      00829B                       1642 00136$:
      00829B 7E 00            [12] 1643 	mov	r6,#0x00
      00829D 12 43 72         [24] 1644 	lcall	_ak820_outline_0161
                                   1645 ;	quantum/action_util.c:205: }
      0082A0 02 6F 78         [24] 1646 	ljmp	_host_system_send
                                   1647 ;------------------------------------------------------------
                                   1648 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1649 ;------------------------------------------------------------
                                   1650 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_389'
                                   1651 ;changed       Allocated with name '_send_keyboard_report_changed_10001_389'
                                   1652 ;dest          Allocated with name '_send_keyboard_report_dest_10001_389'
                                   1653 ;src           Allocated with name '_send_keyboard_report_src_10001_389'
                                   1654 ;i             Allocated with name '_send_keyboard_report_i_20001_390'
                                   1655 ;------------------------------------------------------------
                                   1656 ;	quantum/action_util.c:427: void send_keyboard_report(void) {
                                   1657 ;	-----------------------------------------
                                   1658 ;	 function send_keyboard_report
                                   1659 ;	-----------------------------------------
      0082A3                       1660 _send_keyboard_report:
                                   1661 ;	quantum/action_util.c:428: keyboard_report->mods = real_mods;
      0082A3 90 0D DE         [24] 1662 	mov	dptr,#_real_mods
      0082A6 E0               [24] 1663 	movx	a,@dptr
      0082A7 FF               [12] 1664 	mov	r7,a
      0082A8 90 0D E0         [24] 1665 	mov	dptr,#_actual_keyboard_report
      0082AB F0               [24] 1666 	movx	@dptr,a
                                   1667 ;	quantum/action_util.c:429: keyboard_report->mods |= weak_mods;
      0082AC 90 0D DF         [24] 1668 	mov	dptr,#_weak_mods
      0082AF E0               [24] 1669 	movx	a,@dptr
      0082B0 42 07            [12] 1670 	orl	ar7,a
      0082B2 90 0D E0         [24] 1671 	mov	dptr,#_actual_keyboard_report
      0082B5 EF               [12] 1672 	mov	a,r7
      0082B6 F0               [24] 1673 	movx	@dptr,a
                                   1674 ;	quantum/action_util.c:431: keyboard_report->mods |= owned_mods | owned_weak_mods;
      0082B7 90 09 9E         [24] 1675 	mov	dptr,#_owned_weak_mods
      0082BA E0               [24] 1676 	movx	a,@dptr
      0082BB FE               [12] 1677 	mov	r6,a
      0082BC 90 09 9D         [24] 1678 	mov	dptr,#_owned_mods
      0082BF E0               [24] 1679 	movx	a,@dptr
      0082C0 4E               [12] 1680 	orl	a,r6
      0082C1 42 07            [12] 1681 	orl	ar7,a
      0082C3 90 0D E0         [24] 1682 	mov	dptr,#_actual_keyboard_report
      0082C6 EF               [12] 1683 	mov	a,r7
      0082C7 F0               [24] 1684 	movx	@dptr,a
                                   1685 ;	quantum/action_util.c:479: bool changed = false;
      0082C8 90 0A D6         [24] 1686 	mov	dptr,#_send_keyboard_report_changed_10001_389
      0082CB E4               [12] 1687 	clr	a
      0082CC F0               [24] 1688 	movx	@dptr,a
                                   1689 ;	quantum/action_util.c:481: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1690 ;	quantum/action_util.c:482: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1691 ;	quantum/action_util.c:487: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0082CD FF               [12] 1692 	mov	r7,a
      0082CE                       1693 00107$:
      0082CE BF 20 00         [24] 1694 	cjne	r7,#0x20,00140$
      0082D1                       1695 00140$:
      0082D1 50 2B            [24] 1696 	jnc	00103$
                                   1697 ;	quantum/action_util.c:488: if (dest[i] != src[i]) {
      0082D3 EF               [12] 1698 	mov	a,r7
      0082D4 24 B6            [12] 1699 	add	a, #_send_keyboard_report_last_report_10001_389
      0082D6 FD               [12] 1700 	mov	r5,a
      0082D7 E4               [12] 1701 	clr	a
      0082D8 34 0A            [12] 1702 	addc	a, #(_send_keyboard_report_last_report_10001_389 >> 8)
      0082DA FE               [12] 1703 	mov	r6,a
      0082DB 12 48 90         [24] 1704 	lcall	_ak820_outline_0077
      0082DE EF               [12] 1705 	mov	a,r7
      0082DF 24 E0            [12] 1706 	add	a, #_actual_keyboard_report
      0082E1 F5 82            [12] 1707 	mov	dpl,a
      0082E3 E4               [12] 1708 	clr	a
      0082E4 34 0D            [12] 1709 	addc	a, #(_actual_keyboard_report >> 8)
      0082E6 F5 83            [12] 1710 	mov	dph,a
      0082E8 E0               [24] 1711 	movx	a,@dptr
      0082E9 FB               [12] 1712 	mov	r3,a
      0082EA EC               [12] 1713 	mov	a,r4
      0082EB B5 03 02         [24] 1714 	cjne	a,ar3,00142$
      0082EE 80 0B            [24] 1715 	sjmp	00108$
      0082F0                       1716 00142$:
                                   1717 ;	quantum/action_util.c:489: dest[i] = src[i];
      0082F0 12 38 A1         [24] 1718 	lcall	_ak820_outline_0135
      0082F3 EB               [12] 1719 	mov	a,r3
      0082F4 F0               [24] 1720 	movx	@dptr,a
                                   1721 ;	quantum/action_util.c:490: changed = true;
      0082F5 90 0A D6         [24] 1722 	mov	dptr,#_send_keyboard_report_changed_10001_389
      0082F8 74 01            [12] 1723 	mov	a,#0x01
      0082FA F0               [24] 1724 	movx	@dptr,a
      0082FB                       1725 00108$:
                                   1726 ;	quantum/action_util.c:487: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0082FB 0F               [12] 1727 	inc	r7
      0082FC 80 D0            [24] 1728 	sjmp	00107$
      0082FE                       1729 00103$:
                                   1730 ;	quantum/action_util.c:493: if (changed) host_keyboard_send(keyboard_report);
      0082FE 90 0A D6         [24] 1731 	mov	dptr,#_send_keyboard_report_changed_10001_389
      008301 E0               [24] 1732 	movx	a,@dptr
      008302 60 09            [24] 1733 	jz	00109$
      008304 90 0D E0         [24] 1734 	mov	dptr,#_actual_keyboard_report
      008307 75 F0 00         [24] 1735 	mov	b, #0x00
                                   1736 ;	quantum/action_util.c:501: }
      00830A 02 6E ED         [24] 1737 	ljmp	_host_keyboard_send
      00830D                       1738 00109$:
      00830D 22               [24] 1739 	ret
                                   1740 ;------------------------------------------------------------
                                   1741 ;Allocation info for local variables in function 'get_mods'
                                   1742 ;------------------------------------------------------------
                                   1743 ;	quantum/action_util.c:507: uint8_t get_mods(void) {
                                   1744 ;	-----------------------------------------
                                   1745 ;	 function get_mods
                                   1746 ;	-----------------------------------------
      00830E                       1747 _get_mods:
      00830E C0 07            [24] 1748 	push	ar7
                                   1749 ;	quantum/action_util.c:512: ;
      008310 90 09 9D         [24] 1750 	mov	dptr,#_owned_mods
      008313 E0               [24] 1751 	movx	a,@dptr
      008314 FF               [12] 1752 	mov	r7,a
      008315 90 0D DE         [24] 1753 	mov	dptr,#_real_mods
      008318 12 7E 1A         [24] 1754 	lcall	_ak820_outline_0143
                                   1755 ;	quantum/action_util.c:513: }
      00831B D0 07            [24] 1756 	pop	ar7
      00831D 22               [24] 1757 	ret
                                   1758 ;------------------------------------------------------------
                                   1759 ;Allocation info for local variables in function 'add_mods'
                                   1760 ;------------------------------------------------------------
                                   1761 ;mods          Allocated with name '_add_mods_mods_10000_397'
                                   1762 ;------------------------------------------------------------
                                   1763 ;	quantum/action_util.c:518: void add_mods(uint8_t mods) {
                                   1764 ;	-----------------------------------------
                                   1765 ;	 function clear_mods
                                   1766 ;	-----------------------------------------
      00831E                       1767 _clear_mods:
                                   1768 ;	quantum/action_util.c:540: real_mods = 0;
      00831E 90 0D DE         [24] 1769 	mov	dptr,#_real_mods
      008321 E4               [12] 1770 	clr	a
      008322 F0               [24] 1771 	movx	@dptr,a
                                   1772 ;	quantum/action_util.c:541: }
      008323 22               [24] 1773 	ret
                                   1774 ;------------------------------------------------------------
                                   1775 ;Allocation info for local variables in function 'get_weak_mods'
                                   1776 ;------------------------------------------------------------
                                   1777 ;	quantum/action_util.c:547: uint8_t get_weak_mods(void) {
                                   1778 ;	-----------------------------------------
                                   1779 ;	 function get_weak_mods
                                   1780 ;	-----------------------------------------
      008324                       1781 _get_weak_mods:
      008324 C0 07            [24] 1782 	push	ar7
                                   1783 ;	quantum/action_util.c:552: ;
      008326 90 09 9E         [24] 1784 	mov	dptr,#_owned_weak_mods
      008329 E0               [24] 1785 	movx	a,@dptr
      00832A FF               [12] 1786 	mov	r7,a
      00832B 90 0D DF         [24] 1787 	mov	dptr,#_weak_mods
      00832E 12 7E 1A         [24] 1788 	lcall	_ak820_outline_0143
                                   1789 ;	quantum/action_util.c:553: }
      008331 D0 07            [24] 1790 	pop	ar7
      008333 22               [24] 1791 	ret
                                   1792 ;------------------------------------------------------------
                                   1793 ;Allocation info for local variables in function 'add_weak_mods'
                                   1794 ;------------------------------------------------------------
                                   1795 ;mods          Allocated with name '_add_weak_mods_mods_10000_407'
                                   1796 ;------------------------------------------------------------
                                   1797 ;	quantum/action_util.c:558: void add_weak_mods(uint8_t mods) {
                                   1798 ;	-----------------------------------------
                                   1799 ;	 function add_weak_mods
                                   1800 ;	-----------------------------------------
      008334                       1801 _add_weak_mods:
      008334 E5 82            [12] 1802 	mov	a,dpl
      008336 90 0A D7         [24] 1803 	mov	dptr,#_add_weak_mods_mods_10000_407
      008339 F0               [24] 1804 	movx	@dptr,a
                                   1805 ;	quantum/action_util.c:559: weak_mods |= mods;
      00833A E0               [24] 1806 	movx	a,@dptr
      00833B FF               [12] 1807 	mov	r7,a
      00833C 90 0D DF         [24] 1808 	mov	dptr,#_weak_mods
      00833F E0               [24] 1809 	movx	a,@dptr
      008340 4F               [12] 1810 	orl	a,r7
      008341 F0               [24] 1811 	movx	@dptr,a
                                   1812 ;	quantum/action_util.c:560: }
      008342 22               [24] 1813 	ret
                                   1814 ;------------------------------------------------------------
                                   1815 ;Allocation info for local variables in function 'del_weak_mods'
                                   1816 ;------------------------------------------------------------
                                   1817 ;mods          Allocated with name '_del_weak_mods_mods_10000_409'
                                   1818 ;------------------------------------------------------------
                                   1819 ;	quantum/action_util.c:565: void del_weak_mods(uint8_t mods) {
                                   1820 ;	-----------------------------------------
                                   1821 ;	 function del_weak_mods
                                   1822 ;	-----------------------------------------
      008343                       1823 _del_weak_mods:
      008343 E5 82            [12] 1824 	mov	a,dpl
      008345 90 0A D8         [24] 1825 	mov	dptr,#_del_weak_mods_mods_10000_409
      008348 F0               [24] 1826 	movx	@dptr,a
                                   1827 ;	quantum/action_util.c:566: weak_mods &= ~mods;
      008349 E0               [24] 1828 	movx	a,@dptr
      00834A F4               [12] 1829 	cpl	a
      00834B FF               [12] 1830 	mov	r7,a
      00834C 90 0D DF         [24] 1831 	mov	dptr,#_weak_mods
      00834F E0               [24] 1832 	movx	a,@dptr
      008350 5F               [12] 1833 	anl	a,r7
      008351 F0               [24] 1834 	movx	@dptr,a
                                   1835 ;	quantum/action_util.c:567: }
      008352 22               [24] 1836 	ret
                                   1837 ;------------------------------------------------------------
                                   1838 ;Allocation info for local variables in function 'set_weak_mods'
                                   1839 ;------------------------------------------------------------
                                   1840 ;mods          Allocated with name '_set_weak_mods_mods_10000_411'
                                   1841 ;------------------------------------------------------------
                                   1842 ;	quantum/action_util.c:572: void set_weak_mods(uint8_t mods) {
                                   1843 ;	-----------------------------------------
                                   1844 ;	 function clear_weak_mods
                                   1845 ;	-----------------------------------------
      008353                       1846 _clear_weak_mods:
                                   1847 ;	quantum/action_util.c:580: weak_mods = 0;
      008353 90 0D DF         [24] 1848 	mov	dptr,#_weak_mods
      008356 E4               [12] 1849 	clr	a
      008357 F0               [24] 1850 	movx	@dptr,a
                                   1851 ;	quantum/action_util.c:581: }
      008358 22               [24] 1852 	ret
                                   1853 ;------------------------------------------------------------
                                   1854 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1855 ;------------------------------------------------------------
                                   1856 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_415'
                                   1857 ;------------------------------------------------------------
                                   1858 ;	quantum/action_util.c:663: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1859 ;	-----------------------------------------
                                   1860 	.area CSEG    (CODE)
                                   1861 	.area CONST   (CODE)
                                   1862 	.area XINIT   (CODE)
      00C3B0                       1863 __xinit__real_mods:
      00C3B0 00                    1864 	.db #0x00	; 0
      00C3B1                       1865 __xinit__weak_mods:
      00C3B1 00                    1866 	.db #0x00	; 0
      00C3B2                       1867 __xinit__actual_keyboard_report:
      00C3B2 00                    1868 	.db #0x00	; 0
      00C3B3 00                    1869 	.db #0x00	; 0
      00C3B4 00                    1870 	.db #0x00	; 0
      00C3B5 00                    1871 	.db #0x00	; 0
      00C3B6 00                    1872 	.db #0x00	; 0
      00C3B7 00                    1873 	.db #0x00	; 0
      00C3B8 00                    1874 	.db #0x00	; 0
      00C3B9 00                    1875 	.db #0x00	; 0
      00C3BA 00                    1876 	.db 0x00
      00C3BB 00                    1877 	.db 0x00
      00C3BC 00                    1878 	.db 0x00
      00C3BD 00                    1879 	.db 0x00
      00C3BE 00                    1880 	.db 0x00
      00C3BF 00                    1881 	.db 0x00
      00C3C0 00                    1882 	.db 0x00
      00C3C1 00                    1883 	.db 0x00
      00C3C2 00                    1884 	.db 0x00
      00C3C3 00                    1885 	.db 0x00
      00C3C4 00                    1886 	.db 0x00
      00C3C5 00                    1887 	.db 0x00
      00C3C6 00                    1888 	.db 0x00
      00C3C7 00                    1889 	.db 0x00
      00C3C8 00                    1890 	.db 0x00
      00C3C9 00                    1891 	.db 0x00
      00C3CA 00                    1892 	.db 0x00
      00C3CB 00                    1893 	.db 0x00
      00C3CC 00                    1894 	.db 0x00
      00C3CD 00                    1895 	.db 0x00
      00C3CE 00                    1896 	.db 0x00
      00C3CF 00                    1897 	.db 0x00
      00C3D0 00                    1898 	.db 0x00
      00C3D1 00                    1899 	.db 0x00
                                   1900 	.area CABS    (ABS,CODE)
                                   1901 
                                   1902 ; Experimental exact instruction outlining.
                                   1903 	.globl _ak820_outline_0016
                                   1904 	.globl _ak820_outline_0030
                                   1905 	.globl _ak820_outline_0055
                                   1906 	.globl _ak820_outline_0059
                                   1907 	.globl _ak820_outline_0061
                                   1908 	.globl _ak820_outline_0062
                                   1909 	.globl _ak820_outline_0063
                                   1910 	.globl _ak820_outline_0067
                                   1911 	.globl _ak820_outline_0075
                                   1912 	.globl _ak820_outline_0077
                                   1913 	.globl _ak820_outline_0107
                                   1914 	.globl _ak820_outline_0108
                                   1915 	.globl _ak820_outline_0117
                                   1916 	.globl _ak820_outline_0121
                                   1917 	.globl _ak820_outline_0123
                                   1918 	.globl _ak820_outline_0125
                                   1919 	.globl _ak820_outline_0132
                                   1920 	.globl _ak820_outline_0134
                                   1921 	.globl _ak820_outline_0135
                                   1922 	.globl _ak820_outline_0139
                                   1923 	.globl _ak820_outline_0143
                                   1924 	.globl _ak820_outline_0160
                                   1925 	.globl _ak820_outline_0161
                                   1926 	.globl _ak820_outline_0165
                                   1927 	.globl _ak820_outline_0175
                                   1928 	.globl _ak820_outline_0182
                                   1929 	.globl _ak820_outline_0188
                                   1930 	.globl _ak820_outline_0189
                                   1931 	.globl _ak820_outline_0190
                                   1932 
                                   1933 	.area CSEG (CODE)
                                   1934 ; function ak820_outline_0030
      008359                       1935 _ak820_outline_0030:
      008359 EF               [12] 1936 	mov	a,r7
      00835A 24 AF            [12] 1937 	add	a,#_key_refs
      00835C FD               [12] 1938 	mov	r5,a
      00835D E4               [12] 1939 	clr	a
      00835E 34 09            [12] 1940 	addc	a,#(_key_refs>>8)
      008360 FE               [12] 1941 	mov	r6,a
      008361 8D 82            [24] 1942 	mov	dpl,r5
      008363 8E 83            [24] 1943 	mov	dph,r6
      008365 E0               [24] 1944 	movx	a,@dptr
      008366 22               [24] 1945 	ret
                                   1946 
                                   1947 	.area CSEG (CODE)
                                   1948 ; function ak820_outline_0062
      008367                       1949 _ak820_outline_0062:
      008367 89 82            [24] 1950 	mov	dpl,r1
      008369 8A 83            [24] 1951 	mov	dph,r2
      00836B E8               [12] 1952 	mov	a,r0
      00836C F0               [24] 1953 	movx	@dptr,a
      00836D 22               [24] 1954 	ret
                                   1955 
                                   1956 	.area CSEG (CODE)
                                   1957 ; function ak820_outline_0067
      00836E                       1958 _ak820_outline_0067:
      00836E 24 8A            [12] 1959 	add	a,#_usage_order
      008370 F5 82            [12] 1960 	mov	dpl,a
      008372 E4               [12] 1961 	clr	a
      008373 34 0A            [12] 1962 	addc	a,#(_usage_order>>8)
      008375 F5 83            [12] 1963 	mov	dph,a
      008377 22               [24] 1964 	ret
                                   1965 
                                   1966 	.area CSEG (CODE)
                                   1967 ; function ak820_outline_0075
      008378                       1968 _ak820_outline_0075:
      008378 EB               [12] 1969 	mov	a,r3
      008379 24 6C            [12] 1970 	add	a,#_usage_refs
      00837B F9               [12] 1971 	mov	r1,a
      00837C E4               [12] 1972 	clr	a
      00837D 34 0A            [12] 1973 	addc	a,#(_usage_refs>>8)
      00837F FA               [12] 1974 	mov	r2,a
      008380 89 82            [24] 1975 	mov	dpl,r1
      008382 8A 83            [24] 1976 	mov	dph,r2
      008384 E0               [24] 1977 	movx	a,@dptr
      008385 F8               [12] 1978 	mov	r0,a
      008386 22               [24] 1979 	ret
                                   1980 
                                   1981 	.area CSEG (CODE)
                                   1982 ; function ak820_outline_0117
      008387                       1983 _ak820_outline_0117:
      008387 F0               [24] 1984 	movx	@dptr,a
      008388 E0               [24] 1985 	movx	a,@dptr
      008389 FF               [12] 1986 	mov	r7,a
      00838A 90 09 A7         [24] 1987 	mov	dptr,#_change_owned_PARM_2
      00838D 22               [24] 1988 	ret
                                   1989 
                                   1990 	.area CSEG (CODE)
                                   1991 ; function ak820_outline_0121
      00838E                       1992 _ak820_outline_0121:
      00838E 8D 82            [24] 1993 	mov	dpl,r5
      008390 8E 83            [24] 1994 	mov	dph,r6
      008392 F0               [24] 1995 	movx	@dptr,a
      008393 22               [24] 1996 	ret
                                   1997 
                                   1998 	.area CSEG (CODE)
                                   1999 ; function ak820_outline_0125
      008394                       2000 _ak820_outline_0125:
      008394 24 8A            [12] 2001 	add	a,#_usage_order
      008396 F5 82            [12] 2002 	mov	dpl,a
      008398 EF               [12] 2003 	mov	a,r7
      008399 34 0A            [12] 2004 	addc	a,#(_usage_order>>8)
      00839B F5 83            [12] 2005 	mov	dph,a
      00839D E0               [24] 2006 	movx	a,@dptr
      00839E 22               [24] 2007 	ret
                                   2008 
                                   2009 	.area CSEG (CODE)
                                   2010 ; function ak820_outline_0132
      00839F                       2011 _ak820_outline_0132:
      00839F F0               [24] 2012 	movx	@dptr,a
      0083A0 E0               [24] 2013 	movx	a,@dptr
      0083A1 FF               [12] 2014 	mov	r7,a
      0083A2 90 09 A3         [24] 2015 	mov	dptr,#_ak820_macro_change_PARM_2
      0083A5 F0               [24] 2016 	movx	@dptr,a
      0083A6 90 09 A4         [24] 2017 	mov	dptr,#_ak820_macro_change_PARM_3
      0083A9 22               [24] 2018 	ret
                                   2019 
                                   2020 	.area CSEG (CODE)
                                   2021 ; function ak820_outline_0175
      0083AA                       2022 _ak820_outline_0175:
      0083AA 90 08 1B         [24] 2023 	mov	dptr,#_add_key_to_report_PARM_2
      0083AD EF               [12] 2024 	mov	a,r7
      0083AE F0               [24] 2025 	movx	@dptr,a
      0083AF 90 0D E0         [24] 2026 	mov	dptr,#_actual_keyboard_report
      0083B2 22               [24] 2027 	ret
                                   2028 
                                   2029 	.area CSEG (CODE)
                                   2030 ; function ak820_outline_0190
      0083B3                       2031 _ak820_outline_0190:
      0083B3 8D 82            [24] 2032 	mov	dpl,r5
      0083B5 8F 83            [24] 2033 	mov	dph,r7
      0083B7 22               [24] 2034 	ret
