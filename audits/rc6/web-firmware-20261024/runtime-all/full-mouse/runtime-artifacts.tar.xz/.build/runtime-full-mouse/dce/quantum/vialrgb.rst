                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module vialrgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _rgb_matrix_get_speed
                                     12 	.globl _rgb_matrix_set_speed_noeeprom
                                     13 	.globl _rgb_matrix_get_val
                                     14 	.globl _rgb_matrix_get_sat
                                     15 	.globl _rgb_matrix_get_hue
                                     16 	.globl _rgb_matrix_sethsv_noeeprom
                                     17 	.globl _rgb_matrix_get_mode
                                     18 	.globl _rgb_matrix_mode_noeeprom
                                     19 	.globl _rgb_matrix_is_enabled
                                     20 	.globl _rgb_matrix_disable_noeeprom
                                     21 	.globl _rgb_matrix_enable_noeeprom
                                     22 	.globl _eeconfig_update_rgb_matrix
                                     23 	.globl _ADC_START
                                     24 	.globl _S0_R_FIFO
                                     25 	.globl _S0_T_FIFO
                                     26 	.globl _S0_FREE
                                     27 	.globl _S0_IF_BYTE
                                     28 	.globl _S0_IF_FIRST
                                     29 	.globl _S0_IF_OV
                                     30 	.globl _S0_FST_ACT
                                     31 	.globl _CP_RL2
                                     32 	.globl _C_T2
                                     33 	.globl _TR2
                                     34 	.globl _EXEN2
                                     35 	.globl _TCLK
                                     36 	.globl _RCLK
                                     37 	.globl _EXF2
                                     38 	.globl _CAP1F
                                     39 	.globl _TF2
                                     40 	.globl _RI
                                     41 	.globl _TI
                                     42 	.globl _RB8
                                     43 	.globl _TB8
                                     44 	.globl _REN
                                     45 	.globl _SM2
                                     46 	.globl _SM1
                                     47 	.globl _SM0
                                     48 	.globl _IT0
                                     49 	.globl _IE0
                                     50 	.globl _IT1
                                     51 	.globl _IE1
                                     52 	.globl _TR0
                                     53 	.globl _TF0
                                     54 	.globl _TR1
                                     55 	.globl _TF1
                                     56 	.globl _P4_0
                                     57 	.globl _P4_1
                                     58 	.globl _P4_2
                                     59 	.globl _P4_3
                                     60 	.globl _P4_4
                                     61 	.globl _P4_5
                                     62 	.globl _P4_6
                                     63 	.globl _RXD
                                     64 	.globl _TXD
                                     65 	.globl _INT0
                                     66 	.globl _INT1
                                     67 	.globl _T0
                                     68 	.globl _T1
                                     69 	.globl _MOSI1
                                     70 	.globl _MISO1
                                     71 	.globl _SCK1
                                     72 	.globl _P3_0
                                     73 	.globl _P3_1
                                     74 	.globl _P3_2
                                     75 	.globl _P3_3
                                     76 	.globl _P3_4
                                     77 	.globl _P3_5
                                     78 	.globl _P3_6
                                     79 	.globl _P3_7
                                     80 	.globl _CAP1_
                                     81 	.globl _T2_
                                     82 	.globl _CAP2_
                                     83 	.globl _T2EX_
                                     84 	.globl _RXD1
                                     85 	.globl _TXD1
                                     86 	.globl _P2_0
                                     87 	.globl _P2_1
                                     88 	.globl _P2_2
                                     89 	.globl _P2_3
                                     90 	.globl _P2_4
                                     91 	.globl _P2_5
                                     92 	.globl _P2_6
                                     93 	.globl _P2_7
                                     94 	.globl _AIN0
                                     95 	.globl _AIN1
                                     96 	.globl _AIN2
                                     97 	.globl _AIN3
                                     98 	.globl _AIN4
                                     99 	.globl _AIN5
                                    100 	.globl _AIN6
                                    101 	.globl _AIN7
                                    102 	.globl _CAP1
                                    103 	.globl _T2
                                    104 	.globl _CAP2
                                    105 	.globl _T2EX
                                    106 	.globl _INT0_
                                    107 	.globl _SCS
                                    108 	.globl _MOSI
                                    109 	.globl _MISO
                                    110 	.globl _SCK
                                    111 	.globl _RXD1_
                                    112 	.globl _TXD1_
                                    113 	.globl _P1_0
                                    114 	.globl _P1_1
                                    115 	.globl _P1_2
                                    116 	.globl _P1_3
                                    117 	.globl _P1_4
                                    118 	.globl _P1_5
                                    119 	.globl _P1_6
                                    120 	.globl _P1_7
                                    121 	.globl _AIN8
                                    122 	.globl _AIN9
                                    123 	.globl _AIN10
                                    124 	.globl _AIN11
                                    125 	.globl _AIN12
                                    126 	.globl _AIN13
                                    127 	.globl _RXD_
                                    128 	.globl _TXD_
                                    129 	.globl _SCL0
                                    130 	.globl _SDA0
                                    131 	.globl _P0_0
                                    132 	.globl _P0_1
                                    133 	.globl _P0_2
                                    134 	.globl _P0_3
                                    135 	.globl _P0_4
                                    136 	.globl _P0_5
                                    137 	.globl _P0_6
                                    138 	.globl _P0_7
                                    139 	.globl _IE_SPI0
                                    140 	.globl _IE_USB
                                    141 	.globl _IE_ADC
                                    142 	.globl _IE_UART1
                                    143 	.globl _IE_PWM_I2C
                                    144 	.globl _IE_GPIO
                                    145 	.globl _IE_WDOG
                                    146 	.globl _PX0
                                    147 	.globl _PT0
                                    148 	.globl _PX1
                                    149 	.globl _PT1
                                    150 	.globl _PS
                                    151 	.globl _PT2
                                    152 	.globl _PL_FLAG
                                    153 	.globl _PH_FLAG
                                    154 	.globl _EX0
                                    155 	.globl _ET0
                                    156 	.globl _EX1
                                    157 	.globl _ET1
                                    158 	.globl _ES
                                    159 	.globl _ET2
                                    160 	.globl _E_DIS
                                    161 	.globl _EA
                                    162 	.globl _P
                                    163 	.globl _F1
                                    164 	.globl _OV
                                    165 	.globl _RS0
                                    166 	.globl _RS1
                                    167 	.globl _F0
                                    168 	.globl _AC
                                    169 	.globl _CY
                                    170 	.globl _I2CS_INT_ST
                                    171 	.globl _I2CX_INT
                                    172 	.globl _LED_STATUS
                                    173 	.globl _LED_DMA_H
                                    174 	.globl _LED_DMA_L
                                    175 	.globl _LED_DMA
                                    176 	.globl _LED_PWM_OE
                                    177 	.globl _LED_COMMON
                                    178 	.globl _ADC_CHAN
                                    179 	.globl _ADC_DAT_H
                                    180 	.globl _ADC_DAT_L
                                    181 	.globl _ADC_DAT
                                    182 	.globl _ADC_CTRL
                                    183 	.globl _SPI1_CK_SE
                                    184 	.globl _SPI1_CTRL
                                    185 	.globl _SPI1_DATA
                                    186 	.globl _SPI1_STAT
                                    187 	.globl _SIF1
                                    188 	.globl _SBAUD1
                                    189 	.globl _SBUF1
                                    190 	.globl _SCON1
                                    191 	.globl _SPI0_SETUP
                                    192 	.globl _SPI0_CK_SE
                                    193 	.globl _SPI0_CTRL
                                    194 	.globl _SPI0_DATA
                                    195 	.globl _SPI0_STAT
                                    196 	.globl _T2CAP1H
                                    197 	.globl _T2CAP1L
                                    198 	.globl _T2CAP1
                                    199 	.globl _TH2
                                    200 	.globl _TL2
                                    201 	.globl _T2COUNT
                                    202 	.globl _RCAP2H
                                    203 	.globl _RCAP2L
                                    204 	.globl _RCAP2
                                    205 	.globl _T2MOD
                                    206 	.globl _T2CON
                                    207 	.globl _SBUF
                                    208 	.globl _SCON
                                    209 	.globl _TH1
                                    210 	.globl _TH0
                                    211 	.globl _TL1
                                    212 	.globl _TL0
                                    213 	.globl _TMOD
                                    214 	.globl _TCON
                                    215 	.globl _XBUS_AUX
                                    216 	.globl _P7
                                    217 	.globl _P6_DIR
                                    218 	.globl _P6_OUT_PU
                                    219 	.globl _P6_IN
                                    220 	.globl _P5_DIR
                                    221 	.globl _P5_OUT_PU
                                    222 	.globl _P5_IN
                                    223 	.globl _P4_LED_KEY
                                    224 	.globl _P4_DIR_PU
                                    225 	.globl _P4_MOD_OC
                                    226 	.globl _P4
                                    227 	.globl _P3_DIR_PU
                                    228 	.globl _P3_MOD_OC
                                    229 	.globl _P3
                                    230 	.globl _P2_DIR_PU
                                    231 	.globl _P2_MOD_OC
                                    232 	.globl _P2
                                    233 	.globl _P1_DIR_PU
                                    234 	.globl _P1_MOD_OC
                                    235 	.globl _P1
                                    236 	.globl _P0_DIR_PU
                                    237 	.globl _P0_MOD_OC
                                    238 	.globl _P0
                                    239 	.globl _ROM_CTRL
                                    240 	.globl _ROM_DATA_HH
                                    241 	.globl _ROM_DATA_HL
                                    242 	.globl _ROM_DATA_HI
                                    243 	.globl _ROM_ADDR_H
                                    244 	.globl _ROM_ADDR_L
                                    245 	.globl _ROM_ADDR
                                    246 	.globl _GPIO_IE
                                    247 	.globl _IP_EX
                                    248 	.globl _IE_EX
                                    249 	.globl _IP
                                    250 	.globl _IE
                                    251 	.globl _WDOG_COUNT
                                    252 	.globl _RESET_KEEP
                                    253 	.globl _WAKE_CTRL
                                    254 	.globl _CLOCK_CFG
                                    255 	.globl _POWER_CFG
                                    256 	.globl _PCON
                                    257 	.globl _GLOBAL_CFG
                                    258 	.globl _SAFE_MOD
                                    259 	.globl _DPH
                                    260 	.globl _DPL
                                    261 	.globl _SP
                                    262 	.globl _A_INV
                                    263 	.globl _B
                                    264 	.globl _ACC
                                    265 	.globl _PSW
                                    266 	.globl _vialrgb_save_PARM_2
                                    267 	.globl _vialrgb_set_value_PARM_2
                                    268 	.globl _vialrgb_get_value_PARM_2
                                    269 	.globl _g_direct_mode_colors
                                    270 	.globl _vialrgb_get_value
                                    271 	.globl _vialrgb_set_value
                                    272 	.globl _vialrgb_save
                                    273 ;--------------------------------------------------------
                                    274 ; special function registers
                                    275 ;--------------------------------------------------------
                                    276 	.area RSEG    (ABS,DATA)
      000000                        277 	.org 0x0000
                           0000D0   278 _PSW	=	0x00d0
                           0000E0   279 _ACC	=	0x00e0
                           0000F0   280 _B	=	0x00f0
                           0000FD   281 _A_INV	=	0x00fd
                           000081   282 _SP	=	0x0081
                           000082   283 _DPL	=	0x0082
                           000083   284 _DPH	=	0x0083
                           0000A1   285 _SAFE_MOD	=	0x00a1
                           0000B1   286 _GLOBAL_CFG	=	0x00b1
                           000087   287 _PCON	=	0x0087
                           0000BA   288 _POWER_CFG	=	0x00ba
                           0000B9   289 _CLOCK_CFG	=	0x00b9
                           0000A9   290 _WAKE_CTRL	=	0x00a9
                           0000FE   291 _RESET_KEEP	=	0x00fe
                           0000FF   292 _WDOG_COUNT	=	0x00ff
                           0000A8   293 _IE	=	0x00a8
                           0000B8   294 _IP	=	0x00b8
                           0000E8   295 _IE_EX	=	0x00e8
                           0000E9   296 _IP_EX	=	0x00e9
                           0000B2   297 _GPIO_IE	=	0x00b2
                           008584   298 _ROM_ADDR	=	0x8584
                           000084   299 _ROM_ADDR_L	=	0x0084
                           000085   300 _ROM_ADDR_H	=	0x0085
                           008F8E   301 _ROM_DATA_HI	=	0x8f8e
                           00008E   302 _ROM_DATA_HL	=	0x008e
                           00008F   303 _ROM_DATA_HH	=	0x008f
                           000086   304 _ROM_CTRL	=	0x0086
                           000080   305 _P0	=	0x0080
                           0000C4   306 _P0_MOD_OC	=	0x00c4
                           0000C5   307 _P0_DIR_PU	=	0x00c5
                           000090   308 _P1	=	0x0090
                           000092   309 _P1_MOD_OC	=	0x0092
                           000093   310 _P1_DIR_PU	=	0x0093
                           0000A0   311 _P2	=	0x00a0
                           000094   312 _P2_MOD_OC	=	0x0094
                           000095   313 _P2_DIR_PU	=	0x0095
                           0000B0   314 _P3	=	0x00b0
                           000096   315 _P3_MOD_OC	=	0x0096
                           000097   316 _P3_DIR_PU	=	0x0097
                           0000C0   317 _P4	=	0x00c0
                           0000C2   318 _P4_MOD_OC	=	0x00c2
                           0000C3   319 _P4_DIR_PU	=	0x00c3
                           0000C1   320 _P4_LED_KEY	=	0x00c1
                           0000AA   321 _P5_IN	=	0x00aa
                           0000AB   322 _P5_OUT_PU	=	0x00ab
                           0000AC   323 _P5_DIR	=	0x00ac
                           0000AD   324 _P6_IN	=	0x00ad
                           0000AE   325 _P6_OUT_PU	=	0x00ae
                           0000AF   326 _P6_DIR	=	0x00af
                           0000F1   327 _P7	=	0x00f1
                           0000A2   328 _XBUS_AUX	=	0x00a2
                           000088   329 _TCON	=	0x0088
                           000089   330 _TMOD	=	0x0089
                           00008A   331 _TL0	=	0x008a
                           00008B   332 _TL1	=	0x008b
                           00008C   333 _TH0	=	0x008c
                           00008D   334 _TH1	=	0x008d
                           000098   335 _SCON	=	0x0098
                           000099   336 _SBUF	=	0x0099
                           0000C8   337 _T2CON	=	0x00c8
                           0000C9   338 _T2MOD	=	0x00c9
                           00CBCA   339 _RCAP2	=	0xcbca
                           0000CA   340 _RCAP2L	=	0x00ca
                           0000CB   341 _RCAP2H	=	0x00cb
                           00CDCC   342 _T2COUNT	=	0xcdcc
                           0000CC   343 _TL2	=	0x00cc
                           0000CD   344 _TH2	=	0x00cd
                           00CFCE   345 _T2CAP1	=	0xcfce
                           0000CE   346 _T2CAP1L	=	0x00ce
                           0000CF   347 _T2CAP1H	=	0x00cf
                           0000F8   348 _SPI0_STAT	=	0x00f8
                           0000F9   349 _SPI0_DATA	=	0x00f9
                           0000FA   350 _SPI0_CTRL	=	0x00fa
                           0000FB   351 _SPI0_CK_SE	=	0x00fb
                           0000FC   352 _SPI0_SETUP	=	0x00fc
                           0000BC   353 _SCON1	=	0x00bc
                           0000BD   354 _SBUF1	=	0x00bd
                           0000BE   355 _SBAUD1	=	0x00be
                           0000BF   356 _SIF1	=	0x00bf
                           0000B4   357 _SPI1_STAT	=	0x00b4
                           0000B5   358 _SPI1_DATA	=	0x00b5
                           0000B6   359 _SPI1_CTRL	=	0x00b6
                           0000B7   360 _SPI1_CK_SE	=	0x00b7
                           0000F3   361 _ADC_CTRL	=	0x00f3
                           00F5F4   362 _ADC_DAT	=	0xf5f4
                           0000F4   363 _ADC_DAT_L	=	0x00f4
                           0000F5   364 _ADC_DAT_H	=	0x00f5
                           0000F6   365 _ADC_CHAN	=	0x00f6
                           0000A6   366 _LED_COMMON	=	0x00a6
                           0000A7   367 _LED_PWM_OE	=	0x00a7
                           00C7C6   368 _LED_DMA	=	0xc7c6
                           0000C6   369 _LED_DMA_L	=	0x00c6
                           0000C7   370 _LED_DMA_H	=	0x00c7
                           0000F7   371 _LED_STATUS	=	0x00f7
                           0000B3   372 _I2CX_INT	=	0x00b3
                           0000BB   373 _I2CS_INT_ST	=	0x00bb
                                    374 ;--------------------------------------------------------
                                    375 ; special function bits
                                    376 ;--------------------------------------------------------
                                    377 	.area RSEG    (ABS,DATA)
      000000                        378 	.org 0x0000
                           0000D7   379 _CY	=	0x00d7
                           0000D6   380 _AC	=	0x00d6
                           0000D5   381 _F0	=	0x00d5
                           0000D4   382 _RS1	=	0x00d4
                           0000D3   383 _RS0	=	0x00d3
                           0000D2   384 _OV	=	0x00d2
                           0000D1   385 _F1	=	0x00d1
                           0000D0   386 _P	=	0x00d0
                           0000AF   387 _EA	=	0x00af
                           0000AE   388 _E_DIS	=	0x00ae
                           0000AD   389 _ET2	=	0x00ad
                           0000AC   390 _ES	=	0x00ac
                           0000AB   391 _ET1	=	0x00ab
                           0000AA   392 _EX1	=	0x00aa
                           0000A9   393 _ET0	=	0x00a9
                           0000A8   394 _EX0	=	0x00a8
                           0000BF   395 _PH_FLAG	=	0x00bf
                           0000BE   396 _PL_FLAG	=	0x00be
                           0000BD   397 _PT2	=	0x00bd
                           0000BC   398 _PS	=	0x00bc
                           0000BB   399 _PT1	=	0x00bb
                           0000BA   400 _PX1	=	0x00ba
                           0000B9   401 _PT0	=	0x00b9
                           0000B8   402 _PX0	=	0x00b8
                           0000EF   403 _IE_WDOG	=	0x00ef
                           0000EE   404 _IE_GPIO	=	0x00ee
                           0000ED   405 _IE_PWM_I2C	=	0x00ed
                           0000EC   406 _IE_UART1	=	0x00ec
                           0000EB   407 _IE_ADC	=	0x00eb
                           0000E9   408 _IE_USB	=	0x00e9
                           0000E8   409 _IE_SPI0	=	0x00e8
                           000087   410 _P0_7	=	0x0087
                           000086   411 _P0_6	=	0x0086
                           000085   412 _P0_5	=	0x0085
                           000084   413 _P0_4	=	0x0084
                           000083   414 _P0_3	=	0x0083
                           000082   415 _P0_2	=	0x0082
                           000081   416 _P0_1	=	0x0081
                           000080   417 _P0_0	=	0x0080
                           000081   418 _SDA0	=	0x0081
                           000080   419 _SCL0	=	0x0080
                           000083   420 _TXD_	=	0x0083
                           000082   421 _RXD_	=	0x0082
                           000085   422 _AIN13	=	0x0085
                           000084   423 _AIN12	=	0x0084
                           000083   424 _AIN11	=	0x0083
                           000082   425 _AIN10	=	0x0082
                           000081   426 _AIN9	=	0x0081
                           000080   427 _AIN8	=	0x0080
                           000097   428 _P1_7	=	0x0097
                           000096   429 _P1_6	=	0x0096
                           000095   430 _P1_5	=	0x0095
                           000094   431 _P1_4	=	0x0094
                           000093   432 _P1_3	=	0x0093
                           000092   433 _P1_2	=	0x0092
                           000091   434 _P1_1	=	0x0091
                           000090   435 _P1_0	=	0x0090
                           000097   436 _TXD1_	=	0x0097
                           000096   437 _RXD1_	=	0x0096
                           000097   438 _SCK	=	0x0097
                           000096   439 _MISO	=	0x0096
                           000095   440 _MOSI	=	0x0095
                           000094   441 _SCS	=	0x0094
                           000092   442 _INT0_	=	0x0092
                           000091   443 _T2EX	=	0x0091
                           000091   444 _CAP2	=	0x0091
                           000090   445 _T2	=	0x0090
                           000090   446 _CAP1	=	0x0090
                           000097   447 _AIN7	=	0x0097
                           000096   448 _AIN6	=	0x0096
                           000095   449 _AIN5	=	0x0095
                           000094   450 _AIN4	=	0x0094
                           000093   451 _AIN3	=	0x0093
                           000092   452 _AIN2	=	0x0092
                           000091   453 _AIN1	=	0x0091
                           000090   454 _AIN0	=	0x0090
                           0000A7   455 _P2_7	=	0x00a7
                           0000A6   456 _P2_6	=	0x00a6
                           0000A5   457 _P2_5	=	0x00a5
                           0000A4   458 _P2_4	=	0x00a4
                           0000A3   459 _P2_3	=	0x00a3
                           0000A2   460 _P2_2	=	0x00a2
                           0000A1   461 _P2_1	=	0x00a1
                           0000A0   462 _P2_0	=	0x00a0
                           0000A7   463 _TXD1	=	0x00a7
                           0000A6   464 _RXD1	=	0x00a6
                           0000A5   465 _T2EX_	=	0x00a5
                           0000A5   466 _CAP2_	=	0x00a5
                           0000A4   467 _T2_	=	0x00a4
                           0000A4   468 _CAP1_	=	0x00a4
                           0000B7   469 _P3_7	=	0x00b7
                           0000B6   470 _P3_6	=	0x00b6
                           0000B5   471 _P3_5	=	0x00b5
                           0000B4   472 _P3_4	=	0x00b4
                           0000B3   473 _P3_3	=	0x00b3
                           0000B2   474 _P3_2	=	0x00b2
                           0000B1   475 _P3_1	=	0x00b1
                           0000B0   476 _P3_0	=	0x00b0
                           0000B7   477 _SCK1	=	0x00b7
                           0000B6   478 _MISO1	=	0x00b6
                           0000B5   479 _MOSI1	=	0x00b5
                           0000B5   480 _T1	=	0x00b5
                           0000B4   481 _T0	=	0x00b4
                           0000B3   482 _INT1	=	0x00b3
                           0000B2   483 _INT0	=	0x00b2
                           0000B1   484 _TXD	=	0x00b1
                           0000B0   485 _RXD	=	0x00b0
                           0000C6   486 _P4_6	=	0x00c6
                           0000C5   487 _P4_5	=	0x00c5
                           0000C4   488 _P4_4	=	0x00c4
                           0000C3   489 _P4_3	=	0x00c3
                           0000C2   490 _P4_2	=	0x00c2
                           0000C1   491 _P4_1	=	0x00c1
                           0000C0   492 _P4_0	=	0x00c0
                           00008F   493 _TF1	=	0x008f
                           00008E   494 _TR1	=	0x008e
                           00008D   495 _TF0	=	0x008d
                           00008C   496 _TR0	=	0x008c
                           00008B   497 _IE1	=	0x008b
                           00008A   498 _IT1	=	0x008a
                           000089   499 _IE0	=	0x0089
                           000088   500 _IT0	=	0x0088
                           00009F   501 _SM0	=	0x009f
                           00009E   502 _SM1	=	0x009e
                           00009D   503 _SM2	=	0x009d
                           00009C   504 _REN	=	0x009c
                           00009B   505 _TB8	=	0x009b
                           00009A   506 _RB8	=	0x009a
                           000099   507 _TI	=	0x0099
                           000098   508 _RI	=	0x0098
                           0000CF   509 _TF2	=	0x00cf
                           0000CF   510 _CAP1F	=	0x00cf
                           0000CE   511 _EXF2	=	0x00ce
                           0000CD   512 _RCLK	=	0x00cd
                           0000CC   513 _TCLK	=	0x00cc
                           0000CB   514 _EXEN2	=	0x00cb
                           0000CA   515 _TR2	=	0x00ca
                           0000C9   516 _C_T2	=	0x00c9
                           0000C8   517 _CP_RL2	=	0x00c8
                           0000FF   518 _S0_FST_ACT	=	0x00ff
                           0000FE   519 _S0_IF_OV	=	0x00fe
                           0000FD   520 _S0_IF_FIRST	=	0x00fd
                           0000FC   521 _S0_IF_BYTE	=	0x00fc
                           0000FB   522 _S0_FREE	=	0x00fb
                           0000FA   523 _S0_T_FIFO	=	0x00fa
                           0000F8   524 _S0_R_FIFO	=	0x00f8
                           0000F7   525 _ADC_START	=	0x00f7
                                    526 ;--------------------------------------------------------
                                    527 ; overlayable register banks
                                    528 ;--------------------------------------------------------
                                    529 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        530 	.ds 8
                                    531 ;--------------------------------------------------------
                                    532 ; internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area DSEG    (DATA)
      00004A                        535 _fast_set_leds_sloc0_1_0:
      00004A                        536 	.ds 2
      00004C                        537 _fast_set_leds_sloc1_1_0:
      00004C                        538 	.ds 2
      00004E                        539 _vialrgb_get_value_sloc0_1_0:
      00004E                        540 	.ds 2
      000050                        541 _vialrgb_get_value_sloc1_1_0:
      000050                        542 	.ds 2
      000052                        543 _vialrgb_set_value_sloc0_1_0:
      000052                        544 	.ds 2
                                    545 ;--------------------------------------------------------
                                    546 ; overlayable items in internal ram
                                    547 ;--------------------------------------------------------
                                    548 ;--------------------------------------------------------
                                    549 ; indirectly addressable internal ram data
                                    550 ;--------------------------------------------------------
                                    551 	.area ISEG    (DATA)
                                    552 ;--------------------------------------------------------
                                    553 ; absolute internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area IABS    (ABS,DATA)
                                    556 	.area IABS    (ABS,DATA)
                                    557 ;--------------------------------------------------------
                                    558 ; bit data
                                    559 ;--------------------------------------------------------
                                    560 	.area BSEG    (BIT)
                                    561 ;--------------------------------------------------------
                                    562 ; paged external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area PSEG    (PAG,XDATA)
                                    565 ;--------------------------------------------------------
                                    566 ; uninitialized external ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area XSEG    (XDATA)
      000CA7                        569 _g_direct_mode_colors::
      000CA7                        570 	.ds 246
      000D9D                        571 _get_supported_PARM_2:
      000D9D                        572 	.ds 1
      000D9E                        573 _get_supported_args_10000_255:
      000D9E                        574 	.ds 2
      000DA0                        575 _qmk_id_to_vialrgb_id_id_10000_262:
      000DA0                        576 	.ds 2
      000DA2                        577 _vialrgb_id_to_qmk_id_id_10000_267:
      000DA2                        578 	.ds 2
      000DA4                        579 _set_mode_mode_10000_275:
      000DA4                        580 	.ds 2
      000DA6                        581 _get_matrix_pos_for_led_PARM_2:
      000DA6                        582 	.ds 2
      000DA8                        583 _get_matrix_pos_for_led_led_10000_280:
      000DA8                        584 	.ds 2
      000DAA                        585 _fast_set_leds_PARM_2:
      000DAA                        586 	.ds 1
      000DAB                        587 _fast_set_leds_args_10000_282:
      000DAB                        588 	.ds 2
      000DAD                        589 _fast_set_leds_first_index_10001_285:
      000DAD                        590 	.ds 2
      000DAF                        591 _fast_set_leds_num_leds_10001_285:
      000DAF                        592 	.ds 1
      000DB0                        593 _vialrgb_get_value_PARM_2:
      000DB0                        594 	.ds 1
      000DB1                        595 _vialrgb_get_value_data_10000_291:
      000DB1                        596 	.ds 3
      000DB4                        597 _vialrgb_set_value_PARM_2:
      000DB4                        598 	.ds 1
      000DB5                        599 _vialrgb_set_value_data_10000_302:
      000DB5                        600 	.ds 3
      000DB8                        601 _vialrgb_save_PARM_2:
      000DB8                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; absolute external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area XABS    (ABS,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; initialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XISEG   (XDATA)
                                    611 	.area HOME    (CODE)
                                    612 	.area GSINIT0 (CODE)
                                    613 	.area GSINIT1 (CODE)
                                    614 	.area GSINIT2 (CODE)
                                    615 	.area GSINIT3 (CODE)
                                    616 	.area GSINIT4 (CODE)
                                    617 	.area GSINIT5 (CODE)
                                    618 	.area GSINIT  (CODE)
                                    619 	.area GSFINAL (CODE)
                                    620 	.area CSEG    (CODE)
                                    621 ;--------------------------------------------------------
                                    622 ; global & static initialisations
                                    623 ;--------------------------------------------------------
                                    624 	.area HOME    (CODE)
                                    625 	.area GSINIT  (CODE)
                                    626 	.area GSFINAL (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; Home
                                    630 ;--------------------------------------------------------
                                    631 	.area HOME    (CODE)
                                    632 	.area HOME    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; code
                                    635 ;--------------------------------------------------------
                                    636 	.area CSEG    (CODE)
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    639 ;------------------------------------------------------------
                                    640 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_167'
                                    641 ;------------------------------------------------------------
                                    642 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    643 ;	-----------------------------------------
                           000007   644 	ar7 = 0x07
                           000006   645 	ar6 = 0x06
                           000005   646 	ar5 = 0x05
                           000004   647 	ar4 = 0x04
                           000003   648 	ar3 = 0x03
                           000002   649 	ar2 = 0x02
                           000001   650 	ar1 = 0x01
                           000000   651 	ar0 = 0x00
                                    652 ;	 function get_supported
                                    653 ;	-----------------------------------------
      00B4E3                        654 _get_supported:
      00B4E3 12 38 82         [24]  655 	lcall	_ak820_outline_0107
      00B4E6 90 0D 9E         [24]  656 	mov	dptr,#_get_supported_args_10000_255
      00B4E9 12 38 87         [24]  657 	lcall	_ak820_outline_0108
                                    658 ;	quantum/vialrgb.c:44: uint16_t gt = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B4EC 90 0D 9E         [24]  659 	mov	dptr,#_get_supported_args_10000_255
      00B4EF 12 37 F4         [24]  660 	lcall	_ak820_outline_0005
      00B4F2 E0               [24]  661 	movx	a,@dptr
      00B4F3 FD               [12]  662 	mov	r5,a
      00B4F4 7C 00            [12]  663 	mov	r4,#0x00
      00B4F6 12 38 8C         [24]  664 	lcall	_ak820_outline_0118
      00B4F9 A3               [24]  665 	inc	dptr
      00B4FA E0               [24]  666 	movx	a,@dptr
      00B4FB FA               [12]  667 	mov	r2,a
      00B4FC E4               [12]  668 	clr	a
      00B4FD 12 43 67         [24]  669 	lcall	_ak820_outline_0144
                                    670 ;	quantum/vialrgb.c:45: for (uint8_t i = 0; i < length; ++i) args[i] = 0xff;
      00B500 90 0D 9D         [24]  671 	mov	dptr,#_get_supported_PARM_2
      00B503 E0               [24]  672 	movx	a,@dptr
      00B504 FB               [12]  673 	mov	r3,a
      00B505 7A 00            [12]  674 	mov	r2,#0x00
      00B507                        675 00107$:
      00B507 C3               [12]  676 	clr	c
      00B508 EA               [12]  677 	mov	a,r2
      00B509 9B               [12]  678 	subb	a,r3
      00B50A 50 0A            [24]  679 	jnc	00101$
      00B50C EA               [12]  680 	mov	a,r2
      00B50D 12 38 31         [24]  681 	lcall	_ak820_outline_0022
      00B510 74 FF            [12]  682 	mov	a,#0xff
      00B512 F0               [24]  683 	movx	@dptr,a
      00B513 0A               [12]  684 	inc	r2
      00B514 80 F1            [24]  685 	sjmp	00107$
      00B516                        686 00101$:
                                    687 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B516 8D 06            [24]  688 	mov	ar6,r5
      00B518 8C 07            [24]  689 	mov	ar7,r4
      00B51A 8B 05            [24]  690 	mov	ar5,r3
      00B51C 90 0D 9E         [24]  691 	mov	dptr,#_get_supported_args_10000_255
      00B51F 12 38 91         [24]  692 	lcall	_ak820_outline_0122
      00B522 7A 00            [12]  693 	mov	r2,#0x00
      00B524                        694 00110$:
      00B524 BA 07 00         [24]  695 	cjne	r2,#0x07,00159$
      00B527                        696 00159$:
      00B527 50 46            [24]  697 	jnc	00127$
                                    698 ;	quantum/vialrgb.c:47: uint16_t id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B529 EA               [12]  699 	mov	a,r2
      00B52A 75 F0 02         [24]  700 	mov	b,#0x02
      00B52D A4               [48]  701 	mul	ab
      00B52E 24 96            [12]  702 	add	a, #_supported_modes
      00B530 F5 82            [12]  703 	mov	dpl,a
      00B532 74 C1            [12]  704 	mov	a,#(_supported_modes >> 8)
      00B534 12 59 8F         [24]  705 	lcall	_ak820_outline_0109
      00B537 F8               [12]  706 	mov	r0,a
      00B538 79 00            [12]  707 	mov	r1,#0x00
                                    708 ;	quantum/vialrgb.c:48: if (id > gt && length >= sizeof(id)) {
      00B53A C3               [12]  709 	clr	c
      00B53B EE               [12]  710 	mov	a,r6
      00B53C 98               [12]  711 	subb	a,r0
      00B53D EF               [12]  712 	mov	a,r7
      00B53E 99               [12]  713 	subb	a,r1
      00B53F 50 2B            [24]  714 	jnc	00111$
                                    715 ;	free result
      00B541 BD 02 00         [24]  716 	cjne	r5,#0x02,00162$
      00B544                        717 00162$:
      00B544 40 26            [24]  718 	jc	00111$
                                    719 ;	quantum/vialrgb.c:49: args[0] = id;
      00B546 C0 06            [24]  720 	push	ar6
      00B548 C0 07            [24]  721 	push	ar7
      00B54A 88 07            [24]  722 	mov	ar7,r0
      00B54C 12 33 FC         [24]  723 	lcall	_ak820_outline_0123
      00B54F EF               [12]  724 	mov	a,r7
      00B550 F0               [24]  725 	movx	@dptr,a
                                    726 ;	quantum/vialrgb.c:50: args[1] = id >> 8;
      00B551 12 33 FC         [24]  727 	lcall	_ak820_outline_0123
      00B554 A3               [24]  728 	inc	dptr
      00B555 89 00            [24]  729 	mov	ar0,r1
      00B557 E8               [12]  730 	mov	a,r0
      00B558 F0               [24]  731 	movx	@dptr,a
                                    732 ;	quantum/vialrgb.c:51: length -= sizeof(id);
      00B559 1D               [12]  733 	dec	r5
      00B55A 1D               [12]  734 	dec	r5
                                    735 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B55B 74 02            [12]  736 	mov	a,#0x02
      00B55D 2B               [12]  737 	add	a, r3
      00B55E FB               [12]  738 	mov	r3,a
      00B55F E4               [12]  739 	clr	a
      00B560 3C               [12]  740 	addc	a, r4
      00B561 FC               [12]  741 	mov	r4,a
      00B562 90 0D 9E         [24]  742 	mov	dptr,#_get_supported_args_10000_255
      00B565 12 38 6A         [24]  743 	lcall	_ak820_outline_0085
                                    744 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B568 D0 07            [24]  745 	pop	ar7
      00B56A D0 06            [24]  746 	pop	ar6
                                    747 ;	quantum/vialrgb.c:52: args += sizeof(id);
      00B56C                        748 00111$:
                                    749 ;	quantum/vialrgb.c:46: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B56C 0A               [12]  750 	inc	r2
      00B56D 80 B5            [24]  751 	sjmp	00110$
      00B56F                        752 00127$:
      00B56F 90 0D 9E         [24]  753 	mov	dptr,#_get_supported_args_10000_255
      00B572 12 38 6A         [24]  754 	lcall	_ak820_outline_0085
                                    755 ;	quantum/vialrgb.c:55: }
      00B575 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'qmk_id_to_vialrgb_id'
                                    759 ;------------------------------------------------------------
                                    760 ;id            Allocated with name '_qmk_id_to_vialrgb_id_id_10000_262'
                                    761 ;i             Allocated with name '_qmk_id_to_vialrgb_id_i_20000_264'
                                    762 ;qmk_id        Allocated with name '_qmk_id_to_vialrgb_id_qmk_id_30000_265'
                                    763 ;------------------------------------------------------------
                                    764 ;	quantum/vialrgb.c:57: static uint16_t qmk_id_to_vialrgb_id(uint16_t id) {
                                    765 ;	-----------------------------------------
                                    766 ;	 function qmk_id_to_vialrgb_id
                                    767 ;	-----------------------------------------
      00B576                        768 _qmk_id_to_vialrgb_id:
      00B576 12 38 82         [24]  769 	lcall	_ak820_outline_0107
      00B579 90 0D A0         [24]  770 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B57C 12 38 87         [24]  771 	lcall	_ak820_outline_0108
                                    772 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B57F 90 0D A0         [24]  773 	mov	dptr,#_qmk_id_to_vialrgb_id_id_10000_262
      00B582 12 38 41         [24]  774 	lcall	_ak820_outline_0051
      00B585 7D 00            [12]  775 	mov	r5,#0x00
      00B587                        776 00105$:
      00B587 BD 07 00         [24]  777 	cjne	r5,#0x07,00130$
      00B58A                        778 00130$:
      00B58A 50 19            [24]  779 	jnc	00103$
                                    780 ;	quantum/vialrgb.c:59: uint16_t qmk_id = READ_MODE_ID(&supported_modes[i].qmk_id);
      00B58C 12 B9 AD         [24]  781 	lcall	_ak820_outline_0047
      00B58F A3               [24]  782 	inc	dptr
      00B590 E4               [12]  783 	clr	a
      00B591 93               [24]  784 	movc	a,@a+dptr
                                    785 ;	quantum/vialrgb.c:60: if (qmk_id == id)
      00B592 7A 00            [12]  786 	mov	r2,#0x00
      00B594 B5 06 0B         [24]  787 	cjne	a,ar6,00106$
      00B597 EA               [12]  788 	mov	a,r2
      00B598 B5 07 07         [24]  789 	cjne	a,ar7,00106$
                                    790 ;	quantum/vialrgb.c:61: return READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B59B 12 33 FC         [24]  791 	lcall	_ak820_outline_0123
      00B59E 12 B9 D9         [24]  792 	lcall	_ak820_outline_0146
      00B5A1 22               [24]  793 	ret
      00B5A2                        794 00106$:
                                    795 ;	quantum/vialrgb.c:58: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B5A2 0D               [12]  796 	inc	r5
      00B5A3 80 E2            [24]  797 	sjmp	00105$
      00B5A5                        798 00103$:
                                    799 ;	quantum/vialrgb.c:63: return 0;
      00B5A5 90 00 00         [24]  800 	mov	dptr,#0x0000
                                    801 ;	quantum/vialrgb.c:64: }
      00B5A8 22               [24]  802 	ret
                                    803 ;------------------------------------------------------------
                                    804 ;Allocation info for local variables in function 'vialrgb_id_to_qmk_id'
                                    805 ;------------------------------------------------------------
                                    806 ;id            Allocated with name '_vialrgb_id_to_qmk_id_id_10000_267'
                                    807 ;i             Allocated with name '_vialrgb_id_to_qmk_id_i_20000_269'
                                    808 ;vialrgb_id    Allocated with name '_vialrgb_id_to_qmk_id_vialrgb_id_30000_270'
                                    809 ;------------------------------------------------------------
                                    810 ;	quantum/vialrgb.c:66: static uint16_t vialrgb_id_to_qmk_id(uint16_t id) {
                                    811 ;	-----------------------------------------
                                    812 ;	 function vialrgb_id_to_qmk_id
                                    813 ;	-----------------------------------------
      00B5A9                        814 _vialrgb_id_to_qmk_id:
      00B5A9 12 38 82         [24]  815 	lcall	_ak820_outline_0107
      00B5AC 90 0D A2         [24]  816 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B5AF 12 38 87         [24]  817 	lcall	_ak820_outline_0108
                                    818 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B5B2 90 0D A2         [24]  819 	mov	dptr,#_vialrgb_id_to_qmk_id_id_10000_267
      00B5B5 12 38 41         [24]  820 	lcall	_ak820_outline_0051
      00B5B8 7D 00            [12]  821 	mov	r5,#0x00
      00B5BA                        822 00105$:
      00B5BA BD 07 00         [24]  823 	cjne	r5,#0x07,00130$
      00B5BD                        824 00130$:
      00B5BD 50 19            [24]  825 	jnc	00103$
                                    826 ;	quantum/vialrgb.c:68: uint16_t vialrgb_id = READ_MODE_ID(&supported_modes[i].vialrgb_id);
      00B5BF 12 B9 AD         [24]  827 	lcall	_ak820_outline_0047
      00B5C2 E4               [12]  828 	clr	a
      00B5C3 93               [24]  829 	movc	a,@a+dptr
                                    830 ;	quantum/vialrgb.c:69: if (vialrgb_id == id)
      00B5C4 7A 00            [12]  831 	mov	r2,#0x00
      00B5C6 B5 06 0C         [24]  832 	cjne	a,ar6,00106$
      00B5C9 EA               [12]  833 	mov	a,r2
      00B5CA B5 07 08         [24]  834 	cjne	a,ar7,00106$
                                    835 ;	quantum/vialrgb.c:70: return READ_MODE_ID(&supported_modes[i].qmk_id);
      00B5CD 12 33 FC         [24]  836 	lcall	_ak820_outline_0123
      00B5D0 A3               [24]  837 	inc	dptr
      00B5D1 12 B9 D9         [24]  838 	lcall	_ak820_outline_0146
      00B5D4 22               [24]  839 	ret
      00B5D5                        840 00106$:
                                    841 ;	quantum/vialrgb.c:67: for (uint8_t i = 0; i < SUPPORTED_MODES_LENGTH; ++i) {
      00B5D5 0D               [12]  842 	inc	r5
      00B5D6 80 E2            [24]  843 	sjmp	00105$
      00B5D8                        844 00103$:
                                    845 ;	quantum/vialrgb.c:72: return 0;
      00B5D8 90 00 00         [24]  846 	mov	dptr,#0x0000
                                    847 ;	quantum/vialrgb.c:73: }
      00B5DB 22               [24]  848 	ret
                                    849 ;------------------------------------------------------------
                                    850 ;Allocation info for local variables in function 'get_mode'
                                    851 ;------------------------------------------------------------
                                    852 ;	quantum/vialrgb.c:75: static uint16_t get_mode(void) {
                                    853 ;	-----------------------------------------
                                    854 ;	 function get_mode
                                    855 ;	-----------------------------------------
      00B5DC                        856 _get_mode:
                                    857 ;	quantum/vialrgb.c:77: if (!rgb_matrix_is_enabled())
      00B5DC 12 57 75         [24]  858 	lcall	_rgb_matrix_is_enabled
      00B5DF E5 82            [12]  859 	mov	a, dpl
      00B5E1 70 04            [24]  860 	jnz	00102$
                                    861 ;	quantum/vialrgb.c:78: return VIALRGB_EFFECT_OFF;
      00B5E3 90 00 00         [24]  862 	mov	dptr,#0x0000
      00B5E6 22               [24]  863 	ret
      00B5E7                        864 00102$:
                                    865 ;	quantum/vialrgb.c:79: return qmk_id_to_vialrgb_id(rgb_matrix_get_mode());
      00B5E7 12 57 7B         [24]  866 	lcall	_rgb_matrix_get_mode
      00B5EA 7E 00            [12]  867 	mov	r6,#0x00
      00B5EC 8E 83            [24]  868 	mov	dph, r6
                                    869 ;	quantum/vialrgb.c:80: }
      00B5EE 02 B5 76         [24]  870 	ljmp	_qmk_id_to_vialrgb_id
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'set_mode'
                                    873 ;------------------------------------------------------------
                                    874 ;mode          Allocated with name '_set_mode_mode_10000_275'
                                    875 ;------------------------------------------------------------
                                    876 ;	quantum/vialrgb.c:82: static void set_mode(uint16_t mode) {
                                    877 ;	-----------------------------------------
                                    878 ;	 function set_mode
                                    879 ;	-----------------------------------------
      00B5F1                        880 _set_mode:
      00B5F1 12 38 82         [24]  881 	lcall	_ak820_outline_0107
      00B5F4 90 0D A4         [24]  882 	mov	dptr,#_set_mode_mode_10000_275
      00B5F7 12 38 87         [24]  883 	lcall	_ak820_outline_0108
                                    884 ;	quantum/vialrgb.c:84: if (mode == VIALRGB_EFFECT_OFF) {
      00B5FA 90 0D A4         [24]  885 	mov	dptr,#_set_mode_mode_10000_275
      00B5FD 12 38 41         [24]  886 	lcall	_ak820_outline_0051
      00B600 90 0D A4         [24]  887 	mov	dptr,#_set_mode_mode_10000_275
      00B603 12 6F E6         [24]  888 	lcall	_ak820_outline_0040
      00B606 70 03            [24]  889 	jnz	00102$
                                    890 ;	quantum/vialrgb.c:85: rgb_matrix_disable_noeeprom();
      00B608 02 57 C8         [24]  891 	ljmp	_rgb_matrix_disable_noeeprom
      00B60B                        892 00102$:
                                    893 ;	quantum/vialrgb.c:87: rgb_matrix_enable_noeeprom();
      00B60B C0 07            [24]  894 	push	ar7
      00B60D C0 06            [24]  895 	push	ar6
      00B60F 12 57 B7         [24]  896 	lcall	_rgb_matrix_enable_noeeprom
      00B612 D0 06            [24]  897 	pop	ar6
      00B614 D0 07            [24]  898 	pop	ar7
                                    899 ;	quantum/vialrgb.c:88: rgb_matrix_mode_noeeprom(vialrgb_id_to_qmk_id(mode));
      00B616 12 38 8C         [24]  900 	lcall	_ak820_outline_0118
      00B619 12 B5 A9         [24]  901 	lcall	_vialrgb_id_to_qmk_id
                                    902 ;	quantum/vialrgb.c:90: }
      00B61C 02 57 D1         [24]  903 	ljmp	_rgb_matrix_mode_noeeprom
                                    904 ;------------------------------------------------------------
                                    905 ;Allocation info for local variables in function 'get_matrix_pos_for_led'
                                    906 ;------------------------------------------------------------
                                    907 ;output        Allocated with name '_get_matrix_pos_for_led_PARM_2'
                                    908 ;led           Allocated with name '_get_matrix_pos_for_led_led_10000_280'
                                    909 ;slot          Allocated with name '_get_matrix_pos_for_led_slot_10000_281'
                                    910 ;------------------------------------------------------------
                                    911 ;	quantum/vialrgb.c:93: static void get_matrix_pos_for_led(uint16_t led, uint8_t VIALRGB_BUFFER *output) {
                                    912 ;	-----------------------------------------
                                    913 ;	 function get_matrix_pos_for_led
                                    914 ;	-----------------------------------------
      00B61F                        915 _get_matrix_pos_for_led:
      00B61F 12 38 82         [24]  916 	lcall	_ak820_outline_0107
      00B622 90 0D A8         [24]  917 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B625 12 38 87         [24]  918 	lcall	_ak820_outline_0108
                                    919 ;	quantum/vialrgb.c:95: uint8_t slot = ak820_rgb_slots[led];
      00B628 90 0D A8         [24]  920 	mov	dptr,#_get_matrix_pos_for_led_led_10000_280
      00B62B 12 38 41         [24]  921 	lcall	_ak820_outline_0051
      00B62E EE               [12]  922 	mov	a,r6
      00B62F 24 95            [12]  923 	add	a, #_ak820_rgb_slots
      00B631 F5 82            [12]  924 	mov	dpl,a
      00B633 EF               [12]  925 	mov	a,r7
      00B634 34 BB            [12]  926 	addc	a, #(_ak820_rgb_slots >> 8)
      00B636 F5 83            [12]  927 	mov	dph,a
      00B638 E4               [12]  928 	clr	a
      00B639 93               [24]  929 	movc	a,@a+dptr
      00B63A FF               [12]  930 	mov	r7,a
                                    931 ;	quantum/vialrgb.c:96: output[0] = slot >> 3;
      00B63B 90 0D A6         [24]  932 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B63E 12 38 64         [24]  933 	lcall	_ak820_outline_0079
      00B641 EF               [12]  934 	mov	a,r7
      00B642 12 59 C5         [24]  935 	lcall	_ak820_outline_0188
      00B645 12 83 8E         [24]  936 	lcall	_ak820_outline_0121
                                    937 ;	quantum/vialrgb.c:97: output[1] = slot & 7;
      00B648 12 38 A1         [24]  938 	lcall	_ak820_outline_0135
      00B64B A3               [24]  939 	inc	dptr
      00B64C 53 07 07         [24]  940 	anl	ar7,#0x07
      00B64F EF               [12]  941 	mov	a,r7
      00B650 F0               [24]  942 	movx	@dptr,a
                                    943 ;	quantum/vialrgb.c:110: }
      00B651 22               [24]  944 	ret
                                    945 ;------------------------------------------------------------
                                    946 ;Allocation info for local variables in function 'fast_set_leds'
                                    947 ;------------------------------------------------------------
                                    948 ;sloc0         Allocated with name '_fast_set_leds_sloc0_1_0'
                                    949 ;sloc1         Allocated with name '_fast_set_leds_sloc1_1_0'
                                    950 ;length        Allocated with name '_fast_set_leds_PARM_2'
                                    951 ;args          Allocated with name '_fast_set_leds_args_10000_282'
                                    952 ;first_index   Allocated with name '_fast_set_leds_first_index_10001_285'
                                    953 ;num_leds      Allocated with name '_fast_set_leds_num_leds_10001_285'
                                    954 ;i             Allocated with name '_fast_set_leds_i_20001_288'
                                    955 ;color         Allocated with name '_fast_set_leds_color_30001_289'
                                    956 ;val           Allocated with name '_fast_set_leds_val_30002_290'
                                    957 ;------------------------------------------------------------
                                    958 ;	quantum/vialrgb.c:112: static void fast_set_leds(uint8_t VIALRGB_BUFFER *args, uint8_t length) {
                                    959 ;	-----------------------------------------
                                    960 ;	 function fast_set_leds
                                    961 ;	-----------------------------------------
      00B652                        962 _fast_set_leds:
      00B652 12 38 82         [24]  963 	lcall	_ak820_outline_0107
      00B655 90 0D AB         [24]  964 	mov	dptr,#_fast_set_leds_args_10000_282
      00B658 12 38 87         [24]  965 	lcall	_ak820_outline_0108
                                    966 ;	quantum/vialrgb.c:115: if (length < 3) return;
      00B65B 90 0D AA         [24]  967 	mov	dptr,#_fast_set_leds_PARM_2
      00B65E E0               [24]  968 	movx	a,@dptr
      00B65F FF               [12]  969 	mov	r7,a
      00B660 BF 03 00         [24]  970 	cjne	r7,#0x03,00159$
      00B663                        971 00159$:
      00B663 50 01            [24]  972 	jnc	00102$
      00B665 22               [24]  973 	ret
      00B666                        974 00102$:
                                    975 ;	quantum/vialrgb.c:117: uint16_t first_index = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B666 90 0D AB         [24]  976 	mov	dptr,#_fast_set_leds_args_10000_282
      00B669 12 38 64         [24]  977 	lcall	_ak820_outline_0079
      00B66C 12 48 90         [24]  978 	lcall	_ak820_outline_0077
      00B66F 7B 00            [12]  979 	mov	r3,#0x00
      00B671 12 38 A1         [24]  980 	lcall	_ak820_outline_0135
      00B674 A3               [24]  981 	inc	dptr
      00B675 E0               [24]  982 	movx	a,@dptr
      00B676 FA               [12]  983 	mov	r2,a
      00B677 79 00            [12]  984 	mov	r1,#0x00
      00B679 90 0D AD         [24]  985 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B67C E9               [12]  986 	mov	a,r1
      00B67D 4C               [12]  987 	orl	a,r4
      00B67E F0               [24]  988 	movx	@dptr,a
      00B67F EA               [12]  989 	mov	a,r2
      00B680 4B               [12]  990 	orl	a,r3
      00B681 A3               [24]  991 	inc	dptr
      00B682 F0               [24]  992 	movx	@dptr,a
                                    993 ;	quantum/vialrgb.c:118: uint8_t num_leds = args[2];
      00B683 12 38 A1         [24]  994 	lcall	_ak820_outline_0135
      00B686 A3               [24]  995 	inc	dptr
      00B687 A3               [24]  996 	inc	dptr
      00B688 E0               [24]  997 	movx	a,@dptr
      00B689 90 0D AF         [24]  998 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B68C F0               [24]  999 	movx	@dptr,a
                                   1000 ;	quantum/vialrgb.c:119: length -= 3;
      00B68D EF               [12] 1001 	mov	a,r7
      00B68E 24 FD            [12] 1002 	add	a,#0xfd
      00B690 90 0D AA         [24] 1003 	mov	dptr,#_fast_set_leds_PARM_2
      00B693 F0               [24] 1004 	movx	@dptr,a
                                   1005 ;	quantum/vialrgb.c:120: args += 3;
      00B694 90 0D AB         [24] 1006 	mov	dptr,#_fast_set_leds_args_10000_282
      00B697 74 03            [12] 1007 	mov	a,#0x03
      00B699 2D               [12] 1008 	add	a, r5
      00B69A F0               [24] 1009 	movx	@dptr,a
      00B69B E4               [12] 1010 	clr	a
      00B69C 3E               [12] 1011 	addc	a, r6
      00B69D A3               [24] 1012 	inc	dptr
      00B69E F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	quantum/vialrgb.c:123: if ((uint16_t)num_leds * 3u > length || first_index >= RGB_MATRIX_LED_COUNT) return;
      00B69F 90 0D AF         [24] 1015 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B6A2 E0               [24] 1016 	movx	a,@dptr
      00B6A3 FF               [12] 1017 	mov	r7,a
      00B6A4 75 F0 03         [24] 1018 	mov	b,#0x03
      00B6A7 A4               [48] 1019 	mul	ab
      00B6A8 FE               [12] 1020 	mov	r6,a
      00B6A9 AD F0            [24] 1021 	mov	r5,b
      00B6AB 90 0D AA         [24] 1022 	mov	dptr,#_fast_set_leds_PARM_2
      00B6AE E0               [24] 1023 	movx	a,@dptr
      00B6AF FB               [12] 1024 	mov	r3,a
      00B6B0 7C 00            [12] 1025 	mov	r4,#0x00
      00B6B2 C3               [12] 1026 	clr	c
      00B6B3 EB               [12] 1027 	mov	a,r3
      00B6B4 9E               [12] 1028 	subb	a,r6
      00B6B5 EC               [12] 1029 	mov	a,r4
      00B6B6 9D               [12] 1030 	subb	a,r5
      00B6B7 40 13            [24] 1031 	jc	00103$
                                   1032 ;	free result
      00B6B9 90 0D AD         [24] 1033 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B6BC 12 38 64         [24] 1034 	lcall	_ak820_outline_0079
      00B6BF 8D 03            [24] 1035 	mov	ar3,r5
      00B6C1 8E 04            [24] 1036 	mov	ar4,r6
      00B6C3 C3               [12] 1037 	clr	c
      00B6C4 EB               [12] 1038 	mov	a,r3
      00B6C5 94 52            [12] 1039 	subb	a,#0x52
      00B6C7 EC               [12] 1040 	mov	a,r4
      00B6C8 94 00            [12] 1041 	subb	a,#0x00
      00B6CA 40 01            [24] 1042 	jc	00104$
      00B6CC                       1043 00103$:
      00B6CC 22               [24] 1044 	ret
      00B6CD                       1045 00104$:
                                   1046 ;	quantum/vialrgb.c:124: if (num_leds > RGB_MATRIX_LED_COUNT - first_index) num_leds = RGB_MATRIX_LED_COUNT - first_index;
      00B6CD 74 52            [12] 1047 	mov	a,#0x52
      00B6CF C3               [12] 1048 	clr	c
      00B6D0 9D               [12] 1049 	subb	a,r5
      00B6D1 FB               [12] 1050 	mov	r3,a
      00B6D2 E4               [12] 1051 	clr	a
      00B6D3 9E               [12] 1052 	subb	a,r6
      00B6D4 FC               [12] 1053 	mov	r4,a
      00B6D5 7A 00            [12] 1054 	mov	r2,#0x00
      00B6D7 C3               [12] 1055 	clr	c
      00B6D8 EB               [12] 1056 	mov	a,r3
      00B6D9 9F               [12] 1057 	subb	a,r7
      00B6DA EC               [12] 1058 	mov	a,r4
      00B6DB 9A               [12] 1059 	subb	a,r2
      00B6DC 50 08            [24] 1060 	jnc	00127$
                                   1061 ;	free result
      00B6DE 90 0D AF         [24] 1062 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B6E1 74 52            [12] 1063 	mov	a,#0x52
      00B6E3 C3               [12] 1064 	clr	c
      00B6E4 9D               [12] 1065 	subb	a,r5
      00B6E5 F0               [24] 1066 	movx	@dptr,a
                                   1067 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B6E6                       1068 00127$:
      00B6E6 90 0D AF         [24] 1069 	mov	dptr,#_fast_set_leds_num_leds_10001_285
      00B6E9 E0               [24] 1070 	movx	a,@dptr
      00B6EA FF               [12] 1071 	mov	r7,a
      00B6EB 90 0D AD         [24] 1072 	mov	dptr,#_fast_set_leds_first_index_10001_285
      00B6EE 12 38 64         [24] 1073 	lcall	_ak820_outline_0079
      00B6F1 7C 00            [12] 1074 	mov	r4,#0x00
      00B6F3                       1075 00110$:
      00B6F3 C3               [12] 1076 	clr	c
      00B6F4 EC               [12] 1077 	mov	a,r4
      00B6F5 9F               [12] 1078 	subb	a,r7
      00B6F6 40 01            [24] 1079 	jc	00164$
      00B6F8 22               [24] 1080 	ret
      00B6F9                       1081 00164$:
                                   1082 ;	quantum/vialrgb.c:127: HSV VIALRGB_BUFFER *color = &g_direct_mode_colors[first_index++];
      00B6F9 C0 07            [24] 1083 	push	ar7
      00B6FB 90 0D C7         [24] 1084 	mov	dptr,#__mulint_PARM_2
      00B6FE 12 43 7D         [24] 1085 	lcall	_ak820_outline_0164
      00B701 90 00 03         [24] 1086 	mov	dptr,#0x0003
      00B704 C0 07            [24] 1087 	push	ar7
      00B706 C0 06            [24] 1088 	push	ar6
      00B708 C0 05            [24] 1089 	push	ar5
      00B70A C0 04            [24] 1090 	push	ar4
      00B70C 12 BB 45         [24] 1091 	lcall	__mulint
      00B70F AA 82            [24] 1092 	mov	r2, dpl
      00B711 AB 83            [24] 1093 	mov	r3, dph
      00B713 D0 04            [24] 1094 	pop	ar4
      00B715 D0 05            [24] 1095 	pop	ar5
      00B717 D0 06            [24] 1096 	pop	ar6
      00B719 D0 07            [24] 1097 	pop	ar7
      00B71B 0D               [12] 1098 	inc	r5
      00B71C BD 00 01         [24] 1099 	cjne	r5,#0x00,00165$
      00B71F 0E               [12] 1100 	inc	r6
      00B720                       1101 00165$:
      00B720 EA               [12] 1102 	mov	a,r2
      00B721 24 A7            [12] 1103 	add	a, #_g_direct_mode_colors
      00B723 FA               [12] 1104 	mov	r2,a
      00B724 EB               [12] 1105 	mov	a,r3
      00B725 34 0C            [12] 1106 	addc	a, #(_g_direct_mode_colors >> 8)
      00B727 FB               [12] 1107 	mov	r3,a
                                   1108 ;	quantum/vialrgb.c:128: color->h = *args++;
      00B728 8A 4A            [24] 1109 	mov	_fast_set_leds_sloc0_1_0,r2
      00B72A 8B 4B            [24] 1110 	mov	(_fast_set_leds_sloc0_1_0 + 1),r3
      00B72C 12 B9 BF         [24] 1111 	lcall	_ak820_outline_0084
      00B72F F8               [12] 1112 	mov	r0,a
      00B730 12 B9 CD         [24] 1113 	lcall	_ak820_outline_0106
      00B733 85 4A 82         [24] 1114 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B736 85 4B 83         [24] 1115 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B739 E8               [12] 1116 	mov	a,r0
      00B73A F0               [24] 1117 	movx	@dptr,a
                                   1118 ;	quantum/vialrgb.c:129: color->s = *args++;
      00B73B 74 01            [12] 1119 	mov	a,#0x01
      00B73D 2A               [12] 1120 	add	a, r2
      00B73E F5 4A            [12] 1121 	mov	_fast_set_leds_sloc0_1_0,a
      00B740 E4               [12] 1122 	clr	a
      00B741 3B               [12] 1123 	addc	a, r3
      00B742 F5 4B            [12] 1124 	mov	(_fast_set_leds_sloc0_1_0 + 1),a
      00B744 90 0D AB         [24] 1125 	mov	dptr,#_fast_set_leds_args_10000_282
      00B747 E0               [24] 1126 	movx	a,@dptr
      00B748 F8               [12] 1127 	mov	r0,a
      00B749 A3               [24] 1128 	inc	dptr
      00B74A E0               [24] 1129 	movx	a,@dptr
      00B74B FF               [12] 1130 	mov	r7,a
      00B74C 88 82            [24] 1131 	mov	dpl,r0
      00B74E 8F 83            [24] 1132 	mov	dph,r7
      00B750 E0               [24] 1133 	movx	a,@dptr
      00B751 F9               [12] 1134 	mov	r1,a
      00B752 90 0D AB         [24] 1135 	mov	dptr,#_fast_set_leds_args_10000_282
      00B755 74 01            [12] 1136 	mov	a,#0x01
      00B757 28               [12] 1137 	add	a, r0
      00B758 F0               [24] 1138 	movx	@dptr,a
      00B759 E4               [12] 1139 	clr	a
      00B75A 3F               [12] 1140 	addc	a, r7
      00B75B A3               [24] 1141 	inc	dptr
      00B75C F0               [24] 1142 	movx	@dptr,a
      00B75D 85 4A 82         [24] 1143 	mov	dpl,_fast_set_leds_sloc0_1_0
      00B760 85 4B 83         [24] 1144 	mov	dph,(_fast_set_leds_sloc0_1_0 + 1)
      00B763 E9               [12] 1145 	mov	a,r1
      00B764 F0               [24] 1146 	movx	@dptr,a
                                   1147 ;	quantum/vialrgb.c:130: uint8_t val = *args++;
      00B765 12 B9 BF         [24] 1148 	lcall	_ak820_outline_0084
      00B768 F5 4A            [12] 1149 	mov	_fast_set_leds_sloc0_1_0,a
      00B76A 12 B9 CD         [24] 1150 	lcall	_ak820_outline_0106
                                   1151 ;	quantum/vialrgb.c:131: color->v = (val > RGB_MATRIX_MAXIMUM_BRIGHTNESS) ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      00B76D 74 02            [12] 1152 	mov	a,#0x02
      00B76F 2A               [12] 1153 	add	a, r2
      00B770 F5 4C            [12] 1154 	mov	_fast_set_leds_sloc1_1_0,a
      00B772 E4               [12] 1155 	clr	a
      00B773 3B               [12] 1156 	addc	a, r3
      00B774 F5 4D            [12] 1157 	mov	(_fast_set_leds_sloc1_1_0 + 1),a
      00B776 C3               [12] 1158 	clr	c
      00B777 74 A0            [12] 1159 	mov	a,#0xa0
      00B779 95 4A            [12] 1160 	subb	a,_fast_set_leds_sloc0_1_0
      00B77B D0 07            [24] 1161 	pop	ar7
      00B77D 50 04            [24] 1162 	jnc	00114$
                                   1163 ;	free result
      00B77F 7B A0            [12] 1164 	mov	r3,#0xa0
      00B781 80 04            [24] 1165 	sjmp	00115$
      00B783                       1166 00114$:
      00B783 AA 4A            [24] 1167 	mov	r2,_fast_set_leds_sloc0_1_0
      00B785 8A 03            [24] 1168 	mov	ar3,r2
      00B787                       1169 00115$:
      00B787 85 4C 82         [24] 1170 	mov	dpl,_fast_set_leds_sloc1_1_0
      00B78A 85 4D 83         [24] 1171 	mov	dph,(_fast_set_leds_sloc1_1_0 + 1)
      00B78D EB               [12] 1172 	mov	a,r3
      00B78E F0               [24] 1173 	movx	@dptr,a
                                   1174 ;	quantum/vialrgb.c:126: for (uint8_t i = 0; i < num_leds; ++i) {
      00B78F 0C               [12] 1175 	inc	r4
                                   1176 ;	quantum/vialrgb.c:133: }
      00B790 02 B6 F3         [24] 1177 	ljmp	00110$
                                   1178 ;------------------------------------------------------------
                                   1179 ;Allocation info for local variables in function 'vialrgb_get_value'
                                   1180 ;------------------------------------------------------------
                                   1181 ;sloc0         Allocated with name '_vialrgb_get_value_sloc0_1_0'
                                   1182 ;sloc1         Allocated with name '_vialrgb_get_value_sloc1_1_0'
                                   1183 ;length        Allocated with name '_vialrgb_get_value_PARM_2'
                                   1184 ;data          Allocated with name '_vialrgb_get_value_data_10000_291'
                                   1185 ;args          Allocated with name '_vialrgb_get_value_args_10001_294'
                                   1186 ;cmd           Allocated with name '_vialrgb_get_value_cmd_10001_294'
                                   1187 ;vialrgb_id    Allocated with name '_vialrgb_get_value_vialrgb_id_40001_297'
                                   1188 ;led           Allocated with name '_vialrgb_get_value_led_40001_300'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	quantum/vialrgb.c:136: void vialrgb_get_value(uint8_t *data, uint8_t length) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function vialrgb_get_value
                                   1193 ;	-----------------------------------------
      00B793                       1194 _vialrgb_get_value:
      00B793 12 43 13         [24] 1195 	lcall	_ak820_outline_0037
      00B796 90 0D B1         [24] 1196 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B799 12 38 29         [24] 1197 	lcall	_ak820_outline_0017
                                   1198 ;	quantum/vialrgb.c:137: if (length != VIAL_RAW_EPSIZE) return;
      00B79C 90 0D B0         [24] 1199 	mov	dptr,#_vialrgb_get_value_PARM_2
      00B79F E0               [24] 1200 	movx	a,@dptr
      00B7A0 FF               [12] 1201 	mov	r7,a
      00B7A1 BF 20 02         [24] 1202 	cjne	r7,#0x20,00162$
      00B7A4 80 01            [24] 1203 	sjmp	00102$
      00B7A6                       1204 00162$:
      00B7A6 22               [24] 1205 	ret
      00B7A7                       1206 00102$:
                                   1207 ;	quantum/vialrgb.c:140: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B7A7 90 0D B1         [24] 1208 	mov	dptr,#_vialrgb_get_value_data_10000_291
      00B7AA 12 B9 99         [24] 1209 	lcall	_ak820_outline_0046
                                   1210 ;	quantum/vialrgb.c:141: uint8_t cmd = args[-1];
                                   1211 ;	quantum/vialrgb.c:142: switch (cmd) {
      00B7AD BA 40 02         [24] 1212 	cjne	r2,#0x40,00163$
      00B7B0 80 18            [24] 1213 	sjmp	00103$
      00B7B2                       1214 00163$:
      00B7B2 BA 41 02         [24] 1215 	cjne	r2,#0x41,00164$
      00B7B5 80 26            [24] 1216 	sjmp	00104$
      00B7B7                       1217 00164$:
      00B7B7 BA 42 03         [24] 1218 	cjne	r2,#0x42,00165$
      00B7BA 02 B8 6F         [24] 1219 	ljmp	00105$
      00B7BD                       1220 00165$:
      00B7BD BA 43 03         [24] 1221 	cjne	r2,#0x43,00166$
      00B7C0 02 B8 7C         [24] 1222 	ljmp	00106$
      00B7C3                       1223 00166$:
      00B7C3 BA 44 03         [24] 1224 	cjne	r2,#0x44,00167$
      00B7C6 02 B8 88         [24] 1225 	ljmp	00107$
      00B7C9                       1226 00167$:
      00B7C9 22               [24] 1227 	ret
                                   1228 ;	quantum/vialrgb.c:143: case vialrgb_get_info:
      00B7CA                       1229 00103$:
                                   1230 ;	quantum/vialrgb.c:144: args[0] = VIALRGB_PROTOCOL_VERSION & 0xFF;
      00B7CA 12 33 FC         [24] 1231 	lcall	_ak820_outline_0123
      00B7CD 74 01            [12] 1232 	mov	a,#0x01
      00B7CF F0               [24] 1233 	movx	@dptr,a
                                   1234 ;	quantum/vialrgb.c:145: args[1] = VIALRGB_PROTOCOL_VERSION >> 8;
      00B7D0 12 B9 91         [24] 1235 	lcall	_ak820_outline_0039
      00B7D3 E4               [12] 1236 	clr	a
      00B7D4 F0               [24] 1237 	movx	@dptr,a
                                   1238 ;	quantum/vialrgb.c:146: args[2] = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      00B7D5 12 B9 91         [24] 1239 	lcall	_ak820_outline_0039
      00B7D8 A3               [24] 1240 	inc	dptr
      00B7D9 74 A0            [12] 1241 	mov	a,#0xa0
      00B7DB F0               [24] 1242 	movx	@dptr,a
                                   1243 ;	quantum/vialrgb.c:147: break;
      00B7DC 22               [24] 1244 	ret
                                   1245 ;	quantum/vialrgb.c:148: case vialrgb_get_mode: {
      00B7DD                       1246 00104$:
                                   1247 ;	quantum/vialrgb.c:149: uint16_t vialrgb_id = get_mode();
      00B7DD C0 06            [24] 1248 	push	ar6
      00B7DF C0 05            [24] 1249 	push	ar5
      00B7E1 C0 04            [24] 1250 	push	ar4
      00B7E3 C0 03            [24] 1251 	push	ar3
      00B7E5 12 B5 DC         [24] 1252 	lcall	_get_mode
      00B7E8 A9 82            [24] 1253 	mov	r1, dpl
      00B7EA AA 83            [24] 1254 	mov	r2, dph
      00B7EC D0 03            [24] 1255 	pop	ar3
      00B7EE D0 04            [24] 1256 	pop	ar4
      00B7F0 D0 05            [24] 1257 	pop	ar5
      00B7F2 D0 06            [24] 1258 	pop	ar6
                                   1259 ;	quantum/vialrgb.c:150: args[0] = vialrgb_id & 0xFF;
      00B7F4 89 00            [24] 1260 	mov	ar0,r1
      00B7F6 12 33 FC         [24] 1261 	lcall	_ak820_outline_0123
      00B7F9 E8               [12] 1262 	mov	a,r0
      00B7FA F0               [24] 1263 	movx	@dptr,a
                                   1264 ;	quantum/vialrgb.c:151: args[1] = vialrgb_id >> 8;
      00B7FB 12 B9 91         [24] 1265 	lcall	_ak820_outline_0039
      00B7FE 8A 01            [24] 1266 	mov	ar1,r2
      00B800 E9               [12] 1267 	mov	a,r1
      00B801 F0               [24] 1268 	movx	@dptr,a
                                   1269 ;	quantum/vialrgb.c:152: args[2] = rgb_matrix_get_speed();
      00B802 74 04            [12] 1270 	mov	a,#0x04
      00B804 12 91 01         [24] 1271 	lcall	_ak820_outline_0136
      00B807 C0 06            [24] 1272 	push	ar6
      00B809 C0 05            [24] 1273 	push	ar5
      00B80B C0 02            [24] 1274 	push	ar2
      00B80D C0 01            [24] 1275 	push	ar1
      00B80F 12 57 96         [24] 1276 	lcall	_rgb_matrix_get_speed
      00B812 A8 82            [24] 1277 	mov	r0, dpl
      00B814 D0 01            [24] 1278 	pop	ar1
      00B816 D0 02            [24] 1279 	pop	ar2
      00B818 D0 05            [24] 1280 	pop	ar5
      00B81A D0 06            [24] 1281 	pop	ar6
      00B81C 12 83 67         [24] 1282 	lcall	_ak820_outline_0062
                                   1283 ;	quantum/vialrgb.c:153: args[3] = rgb_matrix_get_hue();
      00B81F 74 05            [12] 1284 	mov	a,#0x05
      00B821 12 91 01         [24] 1285 	lcall	_ak820_outline_0136
      00B824 C0 06            [24] 1286 	push	ar6
      00B826 C0 05            [24] 1287 	push	ar5
      00B828 C0 02            [24] 1288 	push	ar2
      00B82A C0 01            [24] 1289 	push	ar1
      00B82C 12 57 81         [24] 1290 	lcall	_rgb_matrix_get_hue
      00B82F A8 82            [24] 1291 	mov	r0, dpl
      00B831 D0 01            [24] 1292 	pop	ar1
      00B833 D0 02            [24] 1293 	pop	ar2
      00B835 D0 05            [24] 1294 	pop	ar5
      00B837 D0 06            [24] 1295 	pop	ar6
      00B839 12 83 67         [24] 1296 	lcall	_ak820_outline_0062
                                   1297 ;	quantum/vialrgb.c:154: args[4] = rgb_matrix_get_sat();
      00B83C 74 06            [12] 1298 	mov	a,#0x06
      00B83E 12 91 01         [24] 1299 	lcall	_ak820_outline_0136
      00B841 C0 06            [24] 1300 	push	ar6
      00B843 C0 05            [24] 1301 	push	ar5
      00B845 C0 02            [24] 1302 	push	ar2
      00B847 C0 01            [24] 1303 	push	ar1
      00B849 12 57 88         [24] 1304 	lcall	_rgb_matrix_get_sat
      00B84C A8 82            [24] 1305 	mov	r0, dpl
      00B84E D0 01            [24] 1306 	pop	ar1
      00B850 D0 02            [24] 1307 	pop	ar2
      00B852 D0 05            [24] 1308 	pop	ar5
      00B854 D0 06            [24] 1309 	pop	ar6
      00B856 12 83 67         [24] 1310 	lcall	_ak820_outline_0062
                                   1311 ;	quantum/vialrgb.c:155: args[5] = rgb_matrix_get_val();
      00B859 74 07            [12] 1312 	mov	a,#0x07
      00B85B 12 91 01         [24] 1313 	lcall	_ak820_outline_0136
      00B85E C0 02            [24] 1314 	push	ar2
      00B860 C0 01            [24] 1315 	push	ar1
      00B862 12 57 8F         [24] 1316 	lcall	_rgb_matrix_get_val
      00B865 A8 82            [24] 1317 	mov	r0, dpl
      00B867 D0 01            [24] 1318 	pop	ar1
      00B869 D0 02            [24] 1319 	pop	ar2
      00B86B 12 83 67         [24] 1320 	lcall	_ak820_outline_0062
                                   1321 ;	quantum/vialrgb.c:156: break;
      00B86E 22               [24] 1322 	ret
                                   1323 ;	quantum/vialrgb.c:158: case vialrgb_get_supported: {
      00B86F                       1324 00105$:
                                   1325 ;	quantum/vialrgb.c:159: get_supported(args, length - 2);
      00B86F EF               [12] 1326 	mov	a,r7
      00B870 24 FE            [12] 1327 	add	a,#0xfe
      00B872 90 0D 9D         [24] 1328 	mov	dptr,#_get_supported_PARM_2
      00B875 F0               [24] 1329 	movx	@dptr,a
      00B876 12 33 FC         [24] 1330 	lcall	_ak820_outline_0123
                                   1331 ;	quantum/vialrgb.c:160: break;
      00B879 02 B4 E3         [24] 1332 	ljmp	_get_supported
                                   1333 ;	quantum/vialrgb.c:163: case vialrgb_get_number_leds: {
      00B87C                       1334 00106$:
                                   1335 ;	quantum/vialrgb.c:164: args[0] = RGB_MATRIX_LED_COUNT & 0xFF;
      00B87C 12 33 FC         [24] 1336 	lcall	_ak820_outline_0123
      00B87F 74 52            [12] 1337 	mov	a,#0x52
      00B881 F0               [24] 1338 	movx	@dptr,a
                                   1339 ;	quantum/vialrgb.c:165: args[1] = RGB_MATRIX_LED_COUNT >> 8;
      00B882 12 B9 91         [24] 1340 	lcall	_ak820_outline_0039
      00B885 E4               [12] 1341 	clr	a
      00B886 F0               [24] 1342 	movx	@dptr,a
                                   1343 ;	quantum/vialrgb.c:166: break;
      00B887 22               [24] 1344 	ret
                                   1345 ;	quantum/vialrgb.c:168: case vialrgb_get_led_info: {
      00B888                       1346 00107$:
                                   1347 ;	quantum/vialrgb.c:169: uint16_t led = (uint16_t)args[0] | ((uint16_t)args[1] << 8);
      00B888 12 33 FC         [24] 1348 	lcall	_ak820_outline_0123
      00B88B E0               [24] 1349 	movx	a,@dptr
      00B88C FF               [12] 1350 	mov	r7,a
      00B88D 7A 00            [12] 1351 	mov	r2,#0x00
      00B88F 74 03            [12] 1352 	mov	a,#0x03
      00B891 2D               [12] 1353 	add	a, r5
      00B892 F8               [12] 1354 	mov	r0,a
      00B893 E4               [12] 1355 	clr	a
      00B894 3E               [12] 1356 	addc	a, r6
      00B895 F9               [12] 1357 	mov	r1,a
      00B896 C0 03            [24] 1358 	push	ar3
      00B898 C0 04            [24] 1359 	push	ar4
      00B89A 12 38 B6         [24] 1360 	lcall	_ak820_outline_0160
      00B89D E0               [24] 1361 	movx	a,@dptr
      00B89E FB               [12] 1362 	mov	r3,a
      00B89F E4               [12] 1363 	clr	a
      00B8A0 4F               [12] 1364 	orl	a,r7
      00B8A1 F5 4E            [12] 1365 	mov	_vialrgb_get_value_sloc0_1_0,a
      00B8A3 EB               [12] 1366 	mov	a,r3
      00B8A4 4A               [12] 1367 	orl	a,r2
      00B8A5 F5 4F            [12] 1368 	mov	(_vialrgb_get_value_sloc0_1_0 + 1),a
                                   1369 ;	quantum/vialrgb.c:170: if (led >= RGB_MATRIX_LED_COUNT) return;
      00B8A7 AC 4E            [24] 1370 	mov	r4,_vialrgb_get_value_sloc0_1_0
      00B8A9 AF 4F            [24] 1371 	mov	r7,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B8AB C3               [12] 1372 	clr	c
      00B8AC EC               [12] 1373 	mov	a,r4
      00B8AD 94 52            [12] 1374 	subb	a,#0x52
      00B8AF EF               [12] 1375 	mov	a,r7
      00B8B0 94 00            [12] 1376 	subb	a,#0x00
      00B8B2 D0 04            [24] 1377 	pop	ar4
      00B8B4 D0 03            [24] 1378 	pop	ar3
      00B8B6 40 01            [24] 1379 	jc	00109$
      00B8B8 22               [24] 1380 	ret
      00B8B9                       1381 00109$:
                                   1382 ;	quantum/vialrgb.c:172: args[0] = ak820_led_points[led].x;
      00B8B9 E5 4E            [12] 1383 	mov	a,_vialrgb_get_value_sloc0_1_0
      00B8BB 25 4E            [12] 1384 	add	a,_vialrgb_get_value_sloc0_1_0
      00B8BD FA               [12] 1385 	mov	r2,a
      00B8BE E5 4F            [12] 1386 	mov	a,(_vialrgb_get_value_sloc0_1_0 + 1)
      00B8C0 33               [12] 1387 	rlc	a
      00B8C1 FF               [12] 1388 	mov	r7,a
      00B8C2 EA               [12] 1389 	mov	a,r2
      00B8C3 24 4F            [12] 1390 	add	a, #_ak820_led_points
      00B8C5 F5 50            [12] 1391 	mov	_vialrgb_get_value_sloc1_1_0,a
      00B8C7 EF               [12] 1392 	mov	a,r7
      00B8C8 34 BE            [12] 1393 	addc	a, #(_ak820_led_points >> 8)
      00B8CA F5 51            [12] 1394 	mov	(_vialrgb_get_value_sloc1_1_0 + 1),a
      00B8CC 85 50 82         [24] 1395 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B8CF 85 51 83         [24] 1396 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B8D2 E4               [12] 1397 	clr	a
      00B8D3 93               [24] 1398 	movc	a,@a+dptr
      00B8D4 12 33 FC         [24] 1399 	lcall	_ak820_outline_0123
      00B8D7 F0               [24] 1400 	movx	@dptr,a
                                   1401 ;	quantum/vialrgb.c:173: args[1] = ak820_led_points[led].y;
      00B8D8 85 50 82         [24] 1402 	mov	dpl,_vialrgb_get_value_sloc1_1_0
      00B8DB 85 51 83         [24] 1403 	mov	dph,(_vialrgb_get_value_sloc1_1_0 + 1)
      00B8DE A3               [24] 1404 	inc	dptr
      00B8DF E4               [12] 1405 	clr	a
      00B8E0 93               [24] 1406 	movc	a,@a+dptr
      00B8E1 12 38 B6         [24] 1407 	lcall	_ak820_outline_0160
      00B8E4 F0               [24] 1408 	movx	@dptr,a
                                   1409 ;	quantum/vialrgb.c:174: args[2] = LED_FLAG_KEYLIGHT;
      00B8E5 12 B9 91         [24] 1410 	lcall	_ak820_outline_0039
      00B8E8 A3               [24] 1411 	inc	dptr
      00B8E9 74 04            [12] 1412 	mov	a,#0x04
      00B8EB F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	quantum/vialrgb.c:183: get_matrix_pos_for_led(led, &args[3]);
      00B8EC 90 0D A6         [24] 1415 	mov	dptr,#_get_matrix_pos_for_led_PARM_2
      00B8EF 04               [12] 1416 	inc	a
      00B8F0 2D               [12] 1417 	add	a, r5
      00B8F1 F0               [24] 1418 	movx	@dptr,a
      00B8F2 E4               [12] 1419 	clr	a
      00B8F3 3E               [12] 1420 	addc	a, r6
      00B8F4 A3               [24] 1421 	inc	dptr
      00B8F5 F0               [24] 1422 	movx	@dptr,a
      00B8F6 85 4E 82         [24] 1423 	mov	dpl, _vialrgb_get_value_sloc0_1_0
      00B8F9 85 4F 83         [24] 1424 	mov	dph, (_vialrgb_get_value_sloc0_1_0 + 1)
                                   1425 ;	quantum/vialrgb.c:187: }
                                   1426 ;	quantum/vialrgb.c:188: }
      00B8FC 02 B6 1F         [24] 1427 	ljmp	_get_matrix_pos_for_led
                                   1428 ;------------------------------------------------------------
                                   1429 ;Allocation info for local variables in function 'vialrgb_set_value'
                                   1430 ;------------------------------------------------------------
                                   1431 ;sloc0         Allocated with name '_vialrgb_set_value_sloc0_1_0'
                                   1432 ;length        Allocated with name '_vialrgb_set_value_PARM_2'
                                   1433 ;data          Allocated with name '_vialrgb_set_value_data_10000_302'
                                   1434 ;args          Allocated with name '_vialrgb_set_value_args_10001_305'
                                   1435 ;cmd           Allocated with name '_vialrgb_set_value_cmd_10001_305'
                                   1436 ;vialrgb_id    Allocated with name '_vialrgb_set_value_vialrgb_id_40001_308'
                                   1437 ;------------------------------------------------------------
                                   1438 ;	quantum/vialrgb.c:190: void vialrgb_set_value(uint8_t *data, uint8_t length) {
                                   1439 ;	-----------------------------------------
                                   1440 ;	 function vialrgb_set_value
                                   1441 ;	-----------------------------------------
      00B8FF                       1442 _vialrgb_set_value:
      00B8FF 12 43 13         [24] 1443 	lcall	_ak820_outline_0037
      00B902 90 0D B5         [24] 1444 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B905 12 38 29         [24] 1445 	lcall	_ak820_outline_0017
                                   1446 ;	quantum/vialrgb.c:191: if (length != VIAL_RAW_EPSIZE) return;
      00B908 90 0D B4         [24] 1447 	mov	dptr,#_vialrgb_set_value_PARM_2
      00B90B E0               [24] 1448 	movx	a,@dptr
      00B90C FF               [12] 1449 	mov	r7,a
      00B90D BF 20 02         [24] 1450 	cjne	r7,#0x20,00129$
      00B910 80 01            [24] 1451 	sjmp	00102$
      00B912                       1452 00129$:
      00B912 22               [24] 1453 	ret
      00B913                       1454 00102$:
                                   1455 ;	quantum/vialrgb.c:194: uint8_t VIALRGB_BUFFER *args = (uint8_t VIALRGB_BUFFER *)data + 2;
      00B913 90 0D B5         [24] 1456 	mov	dptr,#_vialrgb_set_value_data_10000_302
      00B916 12 B9 99         [24] 1457 	lcall	_ak820_outline_0046
                                   1458 ;	quantum/vialrgb.c:195: uint8_t cmd = args[-1];
                                   1459 ;	quantum/vialrgb.c:196: switch (cmd) {
      00B919 BA 41 02         [24] 1460 	cjne	r2,#0x41,00130$
      00B91C 80 06            [24] 1461 	sjmp	00103$
      00B91E                       1462 00130$:
      00B91E BA 42 02         [24] 1463 	cjne	r2,#0x42,00131$
      00B921 80 5E            [24] 1464 	sjmp	00104$
      00B923                       1465 00131$:
      00B923 22               [24] 1466 	ret
                                   1467 ;	quantum/vialrgb.c:197: case vialrgb_set_mode: {
      00B924                       1468 00103$:
                                   1469 ;	quantum/vialrgb.c:198: uint16_t vialrgb_id = args[0] | (args[1] << 8);
      00B924 12 33 FC         [24] 1470 	lcall	_ak820_outline_0123
      00B927 E0               [24] 1471 	movx	a,@dptr
      00B928 FA               [12] 1472 	mov	r2,a
      00B929 12 B9 91         [24] 1473 	lcall	_ak820_outline_0039
      00B92C E0               [24] 1474 	movx	a,@dptr
      00B92D F8               [12] 1475 	mov	r0,a
      00B92E 79 00            [12] 1476 	mov	r1,#0x00
      00B930 88 53            [24] 1477 	mov	(_vialrgb_set_value_sloc0_1_0 + 1),r0
      00B932 89 52            [24] 1478 	mov	_vialrgb_set_value_sloc0_1_0,r1
      00B934 8A 01            [24] 1479 	mov	ar1,r2
      00B936 7A 00            [12] 1480 	mov	r2,#0x00
      00B938 E5 53            [12] 1481 	mov	a,(_vialrgb_set_value_sloc0_1_0 + 1)
      00B93A 42 02            [12] 1482 	orl	ar2,a
                                   1483 ;	quantum/vialrgb.c:199: set_mode(vialrgb_id);
      00B93C 12 43 83         [24] 1484 	lcall	_ak820_outline_0183
      00B93F C0 06            [24] 1485 	push	ar6
      00B941 C0 05            [24] 1486 	push	ar5
      00B943 12 B5 F1         [24] 1487 	lcall	_set_mode
      00B946 D0 05            [24] 1488 	pop	ar5
      00B948 D0 06            [24] 1489 	pop	ar6
                                   1490 ;	quantum/vialrgb.c:200: rgb_matrix_set_speed_noeeprom(args[2]);
      00B94A 12 B9 91         [24] 1491 	lcall	_ak820_outline_0039
      00B94D A3               [24] 1492 	inc	dptr
      00B94E E0               [24] 1493 	movx	a,@dptr
      00B94F F5 82            [12] 1494 	mov	dpl,a
      00B951 C0 06            [24] 1495 	push	ar6
      00B953 C0 05            [24] 1496 	push	ar5
      00B955 12 58 64         [24] 1497 	lcall	_rgb_matrix_set_speed_noeeprom
      00B958 D0 05            [24] 1498 	pop	ar5
      00B95A D0 06            [24] 1499 	pop	ar6
                                   1500 ;	quantum/vialrgb.c:201: rgb_matrix_sethsv_noeeprom(args[3], args[4], args[5]);
      00B95C 12 B9 91         [24] 1501 	lcall	_ak820_outline_0039
      00B95F A3               [24] 1502 	inc	dptr
      00B960 A3               [24] 1503 	inc	dptr
      00B961 E0               [24] 1504 	movx	a,@dptr
      00B962 F9               [12] 1505 	mov	r1,a
      00B963 7A 00            [12] 1506 	mov	r2,#0x00
      00B965 74 06            [12] 1507 	mov	a,#0x06
      00B967 12 B9 E3         [24] 1508 	lcall	_ak820_outline_0171
      00B96A F8               [12] 1509 	mov	r0,a
      00B96B 74 07            [12] 1510 	mov	a,#0x07
      00B96D 12 B9 E3         [24] 1511 	lcall	_ak820_outline_0171
      00B970 FE               [12] 1512 	mov	r6,a
      00B971 90 07 46         [24] 1513 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      00B974 E8               [12] 1514 	mov	a,r0
      00B975 F0               [24] 1515 	movx	@dptr,a
      00B976 90 07 47         [24] 1516 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00B979 EE               [12] 1517 	mov	a,r6
      00B97A F0               [24] 1518 	movx	@dptr,a
      00B97B 12 43 83         [24] 1519 	lcall	_ak820_outline_0183
                                   1520 ;	quantum/vialrgb.c:202: break;
                                   1521 ;	quantum/vialrgb.c:205: case vialrgb_direct_fastset: {
      00B97E 02 58 35         [24] 1522 	ljmp	_rgb_matrix_sethsv_noeeprom
      00B981                       1523 00104$:
                                   1524 ;	quantum/vialrgb.c:206: fast_set_leds(args, length - 2);
      00B981 EF               [12] 1525 	mov	a,r7
      00B982 24 FE            [12] 1526 	add	a,#0xfe
      00B984 90 0D AA         [24] 1527 	mov	dptr,#_fast_set_leds_PARM_2
      00B987 F0               [24] 1528 	movx	@dptr,a
      00B988 12 33 FC         [24] 1529 	lcall	_ak820_outline_0123
                                   1530 ;	quantum/vialrgb.c:210: }
                                   1531 ;	quantum/vialrgb.c:211: }
      00B98B 02 B6 52         [24] 1532 	ljmp	_fast_set_leds
                                   1533 ;------------------------------------------------------------
                                   1534 ;Allocation info for local variables in function 'vialrgb_save'
                                   1535 ;------------------------------------------------------------
                                   1536 ;length        Allocated with name '_vialrgb_save_PARM_2'
                                   1537 ;data          Allocated with name '_vialrgb_save_data_10000_310'
                                   1538 ;------------------------------------------------------------
                                   1539 ;	quantum/vialrgb.c:213: void vialrgb_save(uint8_t *data, uint8_t length) {
                                   1540 ;	-----------------------------------------
                                   1541 ;	 function vialrgb_save
                                   1542 ;	-----------------------------------------
      00B98E                       1543 _vialrgb_save:
                                   1544 ;	quantum/vialrgb.c:217: eeconfig_update_rgb_matrix();
                                   1545 ;	quantum/vialrgb.c:218: }
      00B98E 02 52 BC         [24] 1546 	ljmp	_eeconfig_update_rgb_matrix
                                   1547 	.area CSEG    (CODE)
                                   1548 	.area CONST   (CODE)
                                   1549 	.area CONST   (CODE)
      00C196                       1550 _supported_modes:
      00C196 00                    1551 	.db #0x00	; 0
      00C197 00                    1552 	.db #0x00	; 0
      00C198 01                    1553 	.db #0x01	; 1
      00C199 05                    1554 	.db #0x05	; 5
      00C19A 02                    1555 	.db #0x02	; 2
      00C19B 01                    1556 	.db #0x01	; 1
      00C19C 06                    1557 	.db #0x06	; 6
      00C19D 02                    1558 	.db #0x02	; 2
      00C19E 0D                    1559 	.db #0x0d	; 13
      00C19F 03                    1560 	.db #0x03	; 3
      00C1A0 0E                    1561 	.db #0x0e	; 14
      00C1A1 04                    1562 	.db #0x04	; 4
      00C1A2 1F                    1563 	.db #0x1f	; 31
      00C1A3 06                    1564 	.db #0x06	; 6
                                   1565 	.area CSEG    (CODE)
                                   1566 	.area XINIT   (CODE)
                                   1567 	.area CABS    (ABS,CODE)
                                   1568 
                                   1569 ; Experimental exact instruction outlining.
                                   1570 	.globl _ak820_outline_0005
                                   1571 	.globl _ak820_outline_0017
                                   1572 	.globl _ak820_outline_0022
                                   1573 	.globl _ak820_outline_0037
                                   1574 	.globl _ak820_outline_0039
                                   1575 	.globl _ak820_outline_0040
                                   1576 	.globl _ak820_outline_0046
                                   1577 	.globl _ak820_outline_0047
                                   1578 	.globl _ak820_outline_0051
                                   1579 	.globl _ak820_outline_0062
                                   1580 	.globl _ak820_outline_0077
                                   1581 	.globl _ak820_outline_0079
                                   1582 	.globl _ak820_outline_0084
                                   1583 	.globl _ak820_outline_0085
                                   1584 	.globl _ak820_outline_0106
                                   1585 	.globl _ak820_outline_0107
                                   1586 	.globl _ak820_outline_0108
                                   1587 	.globl _ak820_outline_0109
                                   1588 	.globl _ak820_outline_0118
                                   1589 	.globl _ak820_outline_0121
                                   1590 	.globl _ak820_outline_0122
                                   1591 	.globl _ak820_outline_0123
                                   1592 	.globl _ak820_outline_0135
                                   1593 	.globl _ak820_outline_0136
                                   1594 	.globl _ak820_outline_0144
                                   1595 	.globl _ak820_outline_0146
                                   1596 	.globl _ak820_outline_0160
                                   1597 	.globl _ak820_outline_0164
                                   1598 	.globl _ak820_outline_0171
                                   1599 	.globl _ak820_outline_0183
                                   1600 	.globl _ak820_outline_0188
                                   1601 
                                   1602 	.area CSEG (CODE)
                                   1603 ; function ak820_outline_0039
      00B991                       1604 _ak820_outline_0039:
      00B991 8D 82            [24] 1605 	mov	dpl,r5
      00B993 8E 83            [24] 1606 	mov	dph,r6
      00B995 A3               [24] 1607 	inc	dptr
      00B996 A3               [24] 1608 	inc	dptr
      00B997 A3               [24] 1609 	inc	dptr
      00B998 22               [24] 1610 	ret
                                   1611 
                                   1612 	.area CSEG (CODE)
                                   1613 ; function ak820_outline_0046
      00B999                       1614 _ak820_outline_0046:
      00B999 E0               [24] 1615 	movx	a,@dptr
      00B99A FD               [12] 1616 	mov	r5,a
      00B99B A3               [24] 1617 	inc	dptr
      00B99C E0               [24] 1618 	movx	a,@dptr
      00B99D FE               [12] 1619 	mov	r6,a
      00B99E 74 02            [12] 1620 	mov	a,#0x02
      00B9A0 2D               [12] 1621 	add	a,r5
      00B9A1 FB               [12] 1622 	mov	r3,a
      00B9A2 E4               [12] 1623 	clr	a
      00B9A3 3E               [12] 1624 	addc	a,r6
      00B9A4 FC               [12] 1625 	mov	r4,a
      00B9A5 8D 82            [24] 1626 	mov	dpl,r5
      00B9A7 8E 83            [24] 1627 	mov	dph,r6
      00B9A9 A3               [24] 1628 	inc	dptr
      00B9AA E0               [24] 1629 	movx	a,@dptr
      00B9AB FA               [12] 1630 	mov	r2,a
      00B9AC 22               [24] 1631 	ret
                                   1632 
                                   1633 	.area CSEG (CODE)
                                   1634 ; function ak820_outline_0047
      00B9AD                       1635 _ak820_outline_0047:
      00B9AD ED               [12] 1636 	mov	a,r5
      00B9AE 75 F0 02         [24] 1637 	mov	b,#0x02
      00B9B1 A4               [48] 1638 	mul	ab
      00B9B2 24 96            [12] 1639 	add	a,#_supported_modes
      00B9B4 FB               [12] 1640 	mov	r3,a
      00B9B5 74 C1            [12] 1641 	mov	a,#(_supported_modes>>8)
      00B9B7 35 F0            [12] 1642 	addc	a,b
      00B9B9 FC               [12] 1643 	mov	r4,a
      00B9BA 8B 82            [24] 1644 	mov	dpl,r3
      00B9BC 8C 83            [24] 1645 	mov	dph,r4
      00B9BE 22               [24] 1646 	ret
                                   1647 
                                   1648 	.area CSEG (CODE)
                                   1649 ; function ak820_outline_0084
      00B9BF                       1650 _ak820_outline_0084:
      00B9BF 90 0D AB         [24] 1651 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9C2 E0               [24] 1652 	movx	a,@dptr
      00B9C3 F9               [12] 1653 	mov	r1,a
      00B9C4 A3               [24] 1654 	inc	dptr
      00B9C5 E0               [24] 1655 	movx	a,@dptr
      00B9C6 FF               [12] 1656 	mov	r7,a
      00B9C7 89 82            [24] 1657 	mov	dpl,r1
      00B9C9 8F 83            [24] 1658 	mov	dph,r7
      00B9CB E0               [24] 1659 	movx	a,@dptr
      00B9CC 22               [24] 1660 	ret
                                   1661 
                                   1662 	.area CSEG (CODE)
                                   1663 ; function ak820_outline_0106
      00B9CD                       1664 _ak820_outline_0106:
      00B9CD 90 0D AB         [24] 1665 	mov	dptr,#_fast_set_leds_args_10000_282
      00B9D0 74 01            [12] 1666 	mov	a,#0x01
      00B9D2 29               [12] 1667 	add	a,r1
      00B9D3 F0               [24] 1668 	movx	@dptr,a
      00B9D4 E4               [12] 1669 	clr	a
      00B9D5 3F               [12] 1670 	addc	a,r7
      00B9D6 A3               [24] 1671 	inc	dptr
      00B9D7 F0               [24] 1672 	movx	@dptr,a
      00B9D8 22               [24] 1673 	ret
                                   1674 
                                   1675 	.area CSEG (CODE)
                                   1676 ; function ak820_outline_0146
      00B9D9                       1677 _ak820_outline_0146:
      00B9D9 E4               [12] 1678 	clr	a
      00B9DA 93               [24] 1679 	movc	a,@a+dptr
      00B9DB FC               [12] 1680 	mov	r4,a
      00B9DC 7B 00            [12] 1681 	mov	r3,#0x00
      00B9DE 8C 82            [24] 1682 	mov	dpl,r4
      00B9E0 8B 83            [24] 1683 	mov	dph,r3
      00B9E2 22               [24] 1684 	ret
                                   1685 
                                   1686 	.area CSEG (CODE)
                                   1687 ; function ak820_outline_0171
      00B9E3                       1688 _ak820_outline_0171:
      00B9E3 2D               [12] 1689 	add	a,r5
      00B9E4 F5 82            [12] 1690 	mov	dpl,a
      00B9E6 E4               [12] 1691 	clr	a
      00B9E7 3E               [12] 1692 	addc	a,r6
      00B9E8 F5 83            [12] 1693 	mov	dph,a
      00B9EA E0               [24] 1694 	movx	a,@dptr
      00B9EB 22               [24] 1695 	ret
