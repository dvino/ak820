gpio.o: lib/ch555/gpio.c keyboards/ajazz/ak820/config.h \
 .build/runtime-full-short/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h platforms/gpio.h platforms/pin_defs.h \
 platforms/mcs51/_pin_defs.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdint.h \
 platforms/mcs51/gpio.h \
 /workspace/scratch/f17cca441b33/accepted-input/ak820/toolchains/sdcc-4.6.0/share/sdcc/include/stdbool.h \
 lib/ch555/ch555.h
