                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_rgb
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_update_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _ak820_rgb_set_color_all
                                     14 	.globl _ak820_rgb_set_color
                                     15 	.globl _timer_elapsed
                                     16 	.globl _timer_read
                                     17 	.globl _hsv_to_rgb_into
                                     18 	.globl _memset
                                     19 	.globl _ADC_START
                                     20 	.globl _S0_R_FIFO
                                     21 	.globl _S0_T_FIFO
                                     22 	.globl _S0_FREE
                                     23 	.globl _S0_IF_BYTE
                                     24 	.globl _S0_IF_FIRST
                                     25 	.globl _S0_IF_OV
                                     26 	.globl _S0_FST_ACT
                                     27 	.globl _CP_RL2
                                     28 	.globl _C_T2
                                     29 	.globl _TR2
                                     30 	.globl _EXEN2
                                     31 	.globl _TCLK
                                     32 	.globl _RCLK
                                     33 	.globl _EXF2
                                     34 	.globl _CAP1F
                                     35 	.globl _TF2
                                     36 	.globl _RI
                                     37 	.globl _TI
                                     38 	.globl _RB8
                                     39 	.globl _TB8
                                     40 	.globl _REN
                                     41 	.globl _SM2
                                     42 	.globl _SM1
                                     43 	.globl _SM0
                                     44 	.globl _IT0
                                     45 	.globl _IE0
                                     46 	.globl _IT1
                                     47 	.globl _IE1
                                     48 	.globl _TR0
                                     49 	.globl _TF0
                                     50 	.globl _TR1
                                     51 	.globl _TF1
                                     52 	.globl _P4_0
                                     53 	.globl _P4_1
                                     54 	.globl _P4_2
                                     55 	.globl _P4_3
                                     56 	.globl _P4_4
                                     57 	.globl _P4_5
                                     58 	.globl _P4_6
                                     59 	.globl _RXD
                                     60 	.globl _TXD
                                     61 	.globl _INT0
                                     62 	.globl _INT1
                                     63 	.globl _T0
                                     64 	.globl _T1
                                     65 	.globl _MOSI1
                                     66 	.globl _MISO1
                                     67 	.globl _SCK1
                                     68 	.globl _P3_0
                                     69 	.globl _P3_1
                                     70 	.globl _P3_2
                                     71 	.globl _P3_3
                                     72 	.globl _P3_4
                                     73 	.globl _P3_5
                                     74 	.globl _P3_6
                                     75 	.globl _P3_7
                                     76 	.globl _CAP1_
                                     77 	.globl _T2_
                                     78 	.globl _CAP2_
                                     79 	.globl _T2EX_
                                     80 	.globl _RXD1
                                     81 	.globl _TXD1
                                     82 	.globl _P2_0
                                     83 	.globl _P2_1
                                     84 	.globl _P2_2
                                     85 	.globl _P2_3
                                     86 	.globl _P2_4
                                     87 	.globl _P2_5
                                     88 	.globl _P2_6
                                     89 	.globl _P2_7
                                     90 	.globl _AIN0
                                     91 	.globl _AIN1
                                     92 	.globl _AIN2
                                     93 	.globl _AIN3
                                     94 	.globl _AIN4
                                     95 	.globl _AIN5
                                     96 	.globl _AIN6
                                     97 	.globl _AIN7
                                     98 	.globl _CAP1
                                     99 	.globl _T2
                                    100 	.globl _CAP2
                                    101 	.globl _T2EX
                                    102 	.globl _INT0_
                                    103 	.globl _SCS
                                    104 	.globl _MOSI
                                    105 	.globl _MISO
                                    106 	.globl _SCK
                                    107 	.globl _RXD1_
                                    108 	.globl _TXD1_
                                    109 	.globl _P1_0
                                    110 	.globl _P1_1
                                    111 	.globl _P1_2
                                    112 	.globl _P1_3
                                    113 	.globl _P1_4
                                    114 	.globl _P1_5
                                    115 	.globl _P1_6
                                    116 	.globl _P1_7
                                    117 	.globl _AIN8
                                    118 	.globl _AIN9
                                    119 	.globl _AIN10
                                    120 	.globl _AIN11
                                    121 	.globl _AIN12
                                    122 	.globl _AIN13
                                    123 	.globl _RXD_
                                    124 	.globl _TXD_
                                    125 	.globl _SCL0
                                    126 	.globl _SDA0
                                    127 	.globl _P0_0
                                    128 	.globl _P0_1
                                    129 	.globl _P0_2
                                    130 	.globl _P0_3
                                    131 	.globl _P0_4
                                    132 	.globl _P0_5
                                    133 	.globl _P0_6
                                    134 	.globl _P0_7
                                    135 	.globl _IE_SPI0
                                    136 	.globl _IE_USB
                                    137 	.globl _IE_ADC
                                    138 	.globl _IE_UART1
                                    139 	.globl _IE_PWM_I2C
                                    140 	.globl _IE_GPIO
                                    141 	.globl _IE_WDOG
                                    142 	.globl _PX0
                                    143 	.globl _PT0
                                    144 	.globl _PX1
                                    145 	.globl _PT1
                                    146 	.globl _PS
                                    147 	.globl _PT2
                                    148 	.globl _PL_FLAG
                                    149 	.globl _PH_FLAG
                                    150 	.globl _EX0
                                    151 	.globl _ET0
                                    152 	.globl _EX1
                                    153 	.globl _ET1
                                    154 	.globl _ES
                                    155 	.globl _ET2
                                    156 	.globl _E_DIS
                                    157 	.globl _EA
                                    158 	.globl _P
                                    159 	.globl _F1
                                    160 	.globl _OV
                                    161 	.globl _RS0
                                    162 	.globl _RS1
                                    163 	.globl _F0
                                    164 	.globl _AC
                                    165 	.globl _CY
                                    166 	.globl _I2CS_INT_ST
                                    167 	.globl _I2CX_INT
                                    168 	.globl _LED_STATUS
                                    169 	.globl _LED_DMA_H
                                    170 	.globl _LED_DMA_L
                                    171 	.globl _LED_DMA
                                    172 	.globl _LED_PWM_OE
                                    173 	.globl _LED_COMMON
                                    174 	.globl _ADC_CHAN
                                    175 	.globl _ADC_DAT_H
                                    176 	.globl _ADC_DAT_L
                                    177 	.globl _ADC_DAT
                                    178 	.globl _ADC_CTRL
                                    179 	.globl _SPI1_CK_SE
                                    180 	.globl _SPI1_CTRL
                                    181 	.globl _SPI1_DATA
                                    182 	.globl _SPI1_STAT
                                    183 	.globl _SIF1
                                    184 	.globl _SBAUD1
                                    185 	.globl _SBUF1
                                    186 	.globl _SCON1
                                    187 	.globl _SPI0_SETUP
                                    188 	.globl _SPI0_CK_SE
                                    189 	.globl _SPI0_CTRL
                                    190 	.globl _SPI0_DATA
                                    191 	.globl _SPI0_STAT
                                    192 	.globl _T2CAP1H
                                    193 	.globl _T2CAP1L
                                    194 	.globl _T2CAP1
                                    195 	.globl _TH2
                                    196 	.globl _TL2
                                    197 	.globl _T2COUNT
                                    198 	.globl _RCAP2H
                                    199 	.globl _RCAP2L
                                    200 	.globl _RCAP2
                                    201 	.globl _T2MOD
                                    202 	.globl _T2CON
                                    203 	.globl _SBUF
                                    204 	.globl _SCON
                                    205 	.globl _TH1
                                    206 	.globl _TH0
                                    207 	.globl _TL1
                                    208 	.globl _TL0
                                    209 	.globl _TMOD
                                    210 	.globl _TCON
                                    211 	.globl _XBUS_AUX
                                    212 	.globl _P7
                                    213 	.globl _P6_DIR
                                    214 	.globl _P6_OUT_PU
                                    215 	.globl _P6_IN
                                    216 	.globl _P5_DIR
                                    217 	.globl _P5_OUT_PU
                                    218 	.globl _P5_IN
                                    219 	.globl _P4_LED_KEY
                                    220 	.globl _P4_DIR_PU
                                    221 	.globl _P4_MOD_OC
                                    222 	.globl _P4
                                    223 	.globl _P3_DIR_PU
                                    224 	.globl _P3_MOD_OC
                                    225 	.globl _P3
                                    226 	.globl _P2_DIR_PU
                                    227 	.globl _P2_MOD_OC
                                    228 	.globl _P2
                                    229 	.globl _P1_DIR_PU
                                    230 	.globl _P1_MOD_OC
                                    231 	.globl _P1
                                    232 	.globl _P0_DIR_PU
                                    233 	.globl _P0_MOD_OC
                                    234 	.globl _P0
                                    235 	.globl _ROM_CTRL
                                    236 	.globl _ROM_DATA_HH
                                    237 	.globl _ROM_DATA_HL
                                    238 	.globl _ROM_DATA_HI
                                    239 	.globl _ROM_ADDR_H
                                    240 	.globl _ROM_ADDR_L
                                    241 	.globl _ROM_ADDR
                                    242 	.globl _GPIO_IE
                                    243 	.globl _IP_EX
                                    244 	.globl _IE_EX
                                    245 	.globl _IP
                                    246 	.globl _IE
                                    247 	.globl _WDOG_COUNT
                                    248 	.globl _RESET_KEEP
                                    249 	.globl _WAKE_CTRL
                                    250 	.globl _CLOCK_CFG
                                    251 	.globl _POWER_CFG
                                    252 	.globl _PCON
                                    253 	.globl _GLOBAL_CFG
                                    254 	.globl _SAFE_MOD
                                    255 	.globl _DPH
                                    256 	.globl _DPL
                                    257 	.globl _SP
                                    258 	.globl _A_INV
                                    259 	.globl _B
                                    260 	.globl _ACC
                                    261 	.globl _PSW
                                    262 	.globl _rgb_matrix_sethsv_noeeprom_PARM_3
                                    263 	.globl _rgb_matrix_sethsv_noeeprom_PARM_2
                                    264 	.globl _process_rgb_matrix_PARM_3
                                    265 	.globl _process_rgb_matrix_PARM_2
                                    266 	.globl _rgb_matrix_set_color_all_PARM_3
                                    267 	.globl _rgb_matrix_set_color_all_PARM_2
                                    268 	.globl _rgb_matrix_set_color_PARM_4
                                    269 	.globl _rgb_matrix_set_color_PARM_3
                                    270 	.globl _rgb_matrix_set_color_PARM_2
                                    271 	.globl _rgb_matrix_config
                                    272 	.globl _eeconfig_update_rgb_matrix
                                    273 	.globl _eeconfig_update_rgb_matrix_default
                                    274 	.globl _rgb_matrix_reload_from_eeprom
                                    275 	.globl _rgb_matrix_init
                                    276 	.globl _rgb_matrix_set_color
                                    277 	.globl _rgb_matrix_set_color_all
                                    278 	.globl _rgb_matrix_task
                                    279 	.globl _process_rgb_matrix
                                    280 	.globl _rgb_matrix_set_suspend_state
                                    281 	.globl _rgb_matrix_is_enabled
                                    282 	.globl _rgb_matrix_get_mode
                                    283 	.globl _rgb_matrix_get_hue
                                    284 	.globl _rgb_matrix_get_sat
                                    285 	.globl _rgb_matrix_get_val
                                    286 	.globl _rgb_matrix_get_speed
                                    287 	.globl _rgb_matrix_toggle_noeeprom
                                    288 	.globl _rgb_matrix_enable_noeeprom
                                    289 	.globl _rgb_matrix_disable_noeeprom
                                    290 	.globl _rgb_matrix_mode_noeeprom
                                    291 	.globl _rgb_matrix_step_noeeprom
                                    292 	.globl _rgb_matrix_step_reverse_noeeprom
                                    293 	.globl _rgb_matrix_sethsv_noeeprom
                                    294 	.globl _rgb_matrix_set_speed_noeeprom
                                    295 	.globl _rgb_matrix_increase_hue_noeeprom
                                    296 	.globl _rgb_matrix_decrease_hue_noeeprom
                                    297 	.globl _rgb_matrix_increase_sat_noeeprom
                                    298 	.globl _rgb_matrix_decrease_sat_noeeprom
                                    299 	.globl _rgb_matrix_increase_val_noeeprom
                                    300 	.globl _rgb_matrix_decrease_val_noeeprom
                                    301 	.globl _rgb_matrix_increase_speed_noeeprom
                                    302 	.globl _rgb_matrix_decrease_speed_noeeprom
                                    303 	.globl _rgb_matrix_toggle
                                    304 	.globl _rgb_matrix_step
                                    305 	.globl _rgb_matrix_step_reverse
                                    306 	.globl _rgb_matrix_increase_hue
                                    307 	.globl _rgb_matrix_decrease_hue
                                    308 	.globl _rgb_matrix_increase_sat
                                    309 	.globl _rgb_matrix_decrease_sat
                                    310 	.globl _rgb_matrix_increase_val
                                    311 	.globl _rgb_matrix_decrease_val
                                    312 	.globl _rgb_matrix_increase_speed
                                    313 	.globl _rgb_matrix_decrease_speed
                                    314 	.globl _rgb_matrix_mode
                                    315 ;--------------------------------------------------------
                                    316 ; special function registers
                                    317 ;--------------------------------------------------------
                                    318 	.area RSEG    (ABS,DATA)
      000000                        319 	.org 0x0000
                           0000D0   320 _PSW	=	0x00d0
                           0000E0   321 _ACC	=	0x00e0
                           0000F0   322 _B	=	0x00f0
                           0000FD   323 _A_INV	=	0x00fd
                           000081   324 _SP	=	0x0081
                           000082   325 _DPL	=	0x0082
                           000083   326 _DPH	=	0x0083
                           0000A1   327 _SAFE_MOD	=	0x00a1
                           0000B1   328 _GLOBAL_CFG	=	0x00b1
                           000087   329 _PCON	=	0x0087
                           0000BA   330 _POWER_CFG	=	0x00ba
                           0000B9   331 _CLOCK_CFG	=	0x00b9
                           0000A9   332 _WAKE_CTRL	=	0x00a9
                           0000FE   333 _RESET_KEEP	=	0x00fe
                           0000FF   334 _WDOG_COUNT	=	0x00ff
                           0000A8   335 _IE	=	0x00a8
                           0000B8   336 _IP	=	0x00b8
                           0000E8   337 _IE_EX	=	0x00e8
                           0000E9   338 _IP_EX	=	0x00e9
                           0000B2   339 _GPIO_IE	=	0x00b2
                           008584   340 _ROM_ADDR	=	0x8584
                           000084   341 _ROM_ADDR_L	=	0x0084
                           000085   342 _ROM_ADDR_H	=	0x0085
                           008F8E   343 _ROM_DATA_HI	=	0x8f8e
                           00008E   344 _ROM_DATA_HL	=	0x008e
                           00008F   345 _ROM_DATA_HH	=	0x008f
                           000086   346 _ROM_CTRL	=	0x0086
                           000080   347 _P0	=	0x0080
                           0000C4   348 _P0_MOD_OC	=	0x00c4
                           0000C5   349 _P0_DIR_PU	=	0x00c5
                           000090   350 _P1	=	0x0090
                           000092   351 _P1_MOD_OC	=	0x0092
                           000093   352 _P1_DIR_PU	=	0x0093
                           0000A0   353 _P2	=	0x00a0
                           000094   354 _P2_MOD_OC	=	0x0094
                           000095   355 _P2_DIR_PU	=	0x0095
                           0000B0   356 _P3	=	0x00b0
                           000096   357 _P3_MOD_OC	=	0x0096
                           000097   358 _P3_DIR_PU	=	0x0097
                           0000C0   359 _P4	=	0x00c0
                           0000C2   360 _P4_MOD_OC	=	0x00c2
                           0000C3   361 _P4_DIR_PU	=	0x00c3
                           0000C1   362 _P4_LED_KEY	=	0x00c1
                           0000AA   363 _P5_IN	=	0x00aa
                           0000AB   364 _P5_OUT_PU	=	0x00ab
                           0000AC   365 _P5_DIR	=	0x00ac
                           0000AD   366 _P6_IN	=	0x00ad
                           0000AE   367 _P6_OUT_PU	=	0x00ae
                           0000AF   368 _P6_DIR	=	0x00af
                           0000F1   369 _P7	=	0x00f1
                           0000A2   370 _XBUS_AUX	=	0x00a2
                           000088   371 _TCON	=	0x0088
                           000089   372 _TMOD	=	0x0089
                           00008A   373 _TL0	=	0x008a
                           00008B   374 _TL1	=	0x008b
                           00008C   375 _TH0	=	0x008c
                           00008D   376 _TH1	=	0x008d
                           000098   377 _SCON	=	0x0098
                           000099   378 _SBUF	=	0x0099
                           0000C8   379 _T2CON	=	0x00c8
                           0000C9   380 _T2MOD	=	0x00c9
                           00CBCA   381 _RCAP2	=	0xcbca
                           0000CA   382 _RCAP2L	=	0x00ca
                           0000CB   383 _RCAP2H	=	0x00cb
                           00CDCC   384 _T2COUNT	=	0xcdcc
                           0000CC   385 _TL2	=	0x00cc
                           0000CD   386 _TH2	=	0x00cd
                           00CFCE   387 _T2CAP1	=	0xcfce
                           0000CE   388 _T2CAP1L	=	0x00ce
                           0000CF   389 _T2CAP1H	=	0x00cf
                           0000F8   390 _SPI0_STAT	=	0x00f8
                           0000F9   391 _SPI0_DATA	=	0x00f9
                           0000FA   392 _SPI0_CTRL	=	0x00fa
                           0000FB   393 _SPI0_CK_SE	=	0x00fb
                           0000FC   394 _SPI0_SETUP	=	0x00fc
                           0000BC   395 _SCON1	=	0x00bc
                           0000BD   396 _SBUF1	=	0x00bd
                           0000BE   397 _SBAUD1	=	0x00be
                           0000BF   398 _SIF1	=	0x00bf
                           0000B4   399 _SPI1_STAT	=	0x00b4
                           0000B5   400 _SPI1_DATA	=	0x00b5
                           0000B6   401 _SPI1_CTRL	=	0x00b6
                           0000B7   402 _SPI1_CK_SE	=	0x00b7
                           0000F3   403 _ADC_CTRL	=	0x00f3
                           00F5F4   404 _ADC_DAT	=	0xf5f4
                           0000F4   405 _ADC_DAT_L	=	0x00f4
                           0000F5   406 _ADC_DAT_H	=	0x00f5
                           0000F6   407 _ADC_CHAN	=	0x00f6
                           0000A6   408 _LED_COMMON	=	0x00a6
                           0000A7   409 _LED_PWM_OE	=	0x00a7
                           00C7C6   410 _LED_DMA	=	0xc7c6
                           0000C6   411 _LED_DMA_L	=	0x00c6
                           0000C7   412 _LED_DMA_H	=	0x00c7
                           0000F7   413 _LED_STATUS	=	0x00f7
                           0000B3   414 _I2CX_INT	=	0x00b3
                           0000BB   415 _I2CS_INT_ST	=	0x00bb
                                    416 ;--------------------------------------------------------
                                    417 ; special function bits
                                    418 ;--------------------------------------------------------
                                    419 	.area RSEG    (ABS,DATA)
      000000                        420 	.org 0x0000
                           0000D7   421 _CY	=	0x00d7
                           0000D6   422 _AC	=	0x00d6
                           0000D5   423 _F0	=	0x00d5
                           0000D4   424 _RS1	=	0x00d4
                           0000D3   425 _RS0	=	0x00d3
                           0000D2   426 _OV	=	0x00d2
                           0000D1   427 _F1	=	0x00d1
                           0000D0   428 _P	=	0x00d0
                           0000AF   429 _EA	=	0x00af
                           0000AE   430 _E_DIS	=	0x00ae
                           0000AD   431 _ET2	=	0x00ad
                           0000AC   432 _ES	=	0x00ac
                           0000AB   433 _ET1	=	0x00ab
                           0000AA   434 _EX1	=	0x00aa
                           0000A9   435 _ET0	=	0x00a9
                           0000A8   436 _EX0	=	0x00a8
                           0000BF   437 _PH_FLAG	=	0x00bf
                           0000BE   438 _PL_FLAG	=	0x00be
                           0000BD   439 _PT2	=	0x00bd
                           0000BC   440 _PS	=	0x00bc
                           0000BB   441 _PT1	=	0x00bb
                           0000BA   442 _PX1	=	0x00ba
                           0000B9   443 _PT0	=	0x00b9
                           0000B8   444 _PX0	=	0x00b8
                           0000EF   445 _IE_WDOG	=	0x00ef
                           0000EE   446 _IE_GPIO	=	0x00ee
                           0000ED   447 _IE_PWM_I2C	=	0x00ed
                           0000EC   448 _IE_UART1	=	0x00ec
                           0000EB   449 _IE_ADC	=	0x00eb
                           0000E9   450 _IE_USB	=	0x00e9
                           0000E8   451 _IE_SPI0	=	0x00e8
                           000087   452 _P0_7	=	0x0087
                           000086   453 _P0_6	=	0x0086
                           000085   454 _P0_5	=	0x0085
                           000084   455 _P0_4	=	0x0084
                           000083   456 _P0_3	=	0x0083
                           000082   457 _P0_2	=	0x0082
                           000081   458 _P0_1	=	0x0081
                           000080   459 _P0_0	=	0x0080
                           000081   460 _SDA0	=	0x0081
                           000080   461 _SCL0	=	0x0080
                           000083   462 _TXD_	=	0x0083
                           000082   463 _RXD_	=	0x0082
                           000085   464 _AIN13	=	0x0085
                           000084   465 _AIN12	=	0x0084
                           000083   466 _AIN11	=	0x0083
                           000082   467 _AIN10	=	0x0082
                           000081   468 _AIN9	=	0x0081
                           000080   469 _AIN8	=	0x0080
                           000097   470 _P1_7	=	0x0097
                           000096   471 _P1_6	=	0x0096
                           000095   472 _P1_5	=	0x0095
                           000094   473 _P1_4	=	0x0094
                           000093   474 _P1_3	=	0x0093
                           000092   475 _P1_2	=	0x0092
                           000091   476 _P1_1	=	0x0091
                           000090   477 _P1_0	=	0x0090
                           000097   478 _TXD1_	=	0x0097
                           000096   479 _RXD1_	=	0x0096
                           000097   480 _SCK	=	0x0097
                           000096   481 _MISO	=	0x0096
                           000095   482 _MOSI	=	0x0095
                           000094   483 _SCS	=	0x0094
                           000092   484 _INT0_	=	0x0092
                           000091   485 _T2EX	=	0x0091
                           000091   486 _CAP2	=	0x0091
                           000090   487 _T2	=	0x0090
                           000090   488 _CAP1	=	0x0090
                           000097   489 _AIN7	=	0x0097
                           000096   490 _AIN6	=	0x0096
                           000095   491 _AIN5	=	0x0095
                           000094   492 _AIN4	=	0x0094
                           000093   493 _AIN3	=	0x0093
                           000092   494 _AIN2	=	0x0092
                           000091   495 _AIN1	=	0x0091
                           000090   496 _AIN0	=	0x0090
                           0000A7   497 _P2_7	=	0x00a7
                           0000A6   498 _P2_6	=	0x00a6
                           0000A5   499 _P2_5	=	0x00a5
                           0000A4   500 _P2_4	=	0x00a4
                           0000A3   501 _P2_3	=	0x00a3
                           0000A2   502 _P2_2	=	0x00a2
                           0000A1   503 _P2_1	=	0x00a1
                           0000A0   504 _P2_0	=	0x00a0
                           0000A7   505 _TXD1	=	0x00a7
                           0000A6   506 _RXD1	=	0x00a6
                           0000A5   507 _T2EX_	=	0x00a5
                           0000A5   508 _CAP2_	=	0x00a5
                           0000A4   509 _T2_	=	0x00a4
                           0000A4   510 _CAP1_	=	0x00a4
                           0000B7   511 _P3_7	=	0x00b7
                           0000B6   512 _P3_6	=	0x00b6
                           0000B5   513 _P3_5	=	0x00b5
                           0000B4   514 _P3_4	=	0x00b4
                           0000B3   515 _P3_3	=	0x00b3
                           0000B2   516 _P3_2	=	0x00b2
                           0000B1   517 _P3_1	=	0x00b1
                           0000B0   518 _P3_0	=	0x00b0
                           0000B7   519 _SCK1	=	0x00b7
                           0000B6   520 _MISO1	=	0x00b6
                           0000B5   521 _MOSI1	=	0x00b5
                           0000B5   522 _T1	=	0x00b5
                           0000B4   523 _T0	=	0x00b4
                           0000B3   524 _INT1	=	0x00b3
                           0000B2   525 _INT0	=	0x00b2
                           0000B1   526 _TXD	=	0x00b1
                           0000B0   527 _RXD	=	0x00b0
                           0000C6   528 _P4_6	=	0x00c6
                           0000C5   529 _P4_5	=	0x00c5
                           0000C4   530 _P4_4	=	0x00c4
                           0000C3   531 _P4_3	=	0x00c3
                           0000C2   532 _P4_2	=	0x00c2
                           0000C1   533 _P4_1	=	0x00c1
                           0000C0   534 _P4_0	=	0x00c0
                           00008F   535 _TF1	=	0x008f
                           00008E   536 _TR1	=	0x008e
                           00008D   537 _TF0	=	0x008d
                           00008C   538 _TR0	=	0x008c
                           00008B   539 _IE1	=	0x008b
                           00008A   540 _IT1	=	0x008a
                           000089   541 _IE0	=	0x0089
                           000088   542 _IT0	=	0x0088
                           00009F   543 _SM0	=	0x009f
                           00009E   544 _SM1	=	0x009e
                           00009D   545 _SM2	=	0x009d
                           00009C   546 _REN	=	0x009c
                           00009B   547 _TB8	=	0x009b
                           00009A   548 _RB8	=	0x009a
                           000099   549 _TI	=	0x0099
                           000098   550 _RI	=	0x0098
                           0000CF   551 _TF2	=	0x00cf
                           0000CF   552 _CAP1F	=	0x00cf
                           0000CE   553 _EXF2	=	0x00ce
                           0000CD   554 _RCLK	=	0x00cd
                           0000CC   555 _TCLK	=	0x00cc
                           0000CB   556 _EXEN2	=	0x00cb
                           0000CA   557 _TR2	=	0x00ca
                           0000C9   558 _C_T2	=	0x00c9
                           0000C8   559 _CP_RL2	=	0x00c8
                           0000FF   560 _S0_FST_ACT	=	0x00ff
                           0000FE   561 _S0_IF_OV	=	0x00fe
                           0000FD   562 _S0_IF_FIRST	=	0x00fd
                           0000FC   563 _S0_IF_BYTE	=	0x00fc
                           0000FB   564 _S0_FREE	=	0x00fb
                           0000FA   565 _S0_T_FIFO	=	0x00fa
                           0000F8   566 _S0_R_FIFO	=	0x00f8
                           0000F7   567 _ADC_START	=	0x00f7
                                    568 ;--------------------------------------------------------
                                    569 ; overlayable register banks
                                    570 ;--------------------------------------------------------
                                    571 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        572 	.ds 8
                                    573 ;--------------------------------------------------------
                                    574 ; internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area DSEG    (DATA)
      000015                        577 _rgb_matrix_set_suspend_state_sloc0_1_0:
      000015                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable items in internal ram
                                    581 ;--------------------------------------------------------
                                    582 ;--------------------------------------------------------
                                    583 ; indirectly addressable internal ram data
                                    584 ;--------------------------------------------------------
                                    585 	.area ISEG    (DATA)
                                    586 ;--------------------------------------------------------
                                    587 ; absolute internal ram data
                                    588 ;--------------------------------------------------------
                                    589 	.area IABS    (ABS,DATA)
                                    590 	.area IABS    (ABS,DATA)
                                    591 ;--------------------------------------------------------
                                    592 ; bit data
                                    593 ;--------------------------------------------------------
                                    594 	.area BSEG    (BIT)
      000011                        595 _suspended:
      000011                        596 	.ds 1
      000012                        597 _dirty:
      000012                        598 	.ds 1
      000013                        599 _rendering:
      000013                        600 	.ds 1
      000014                        601 _rgb_matrix_task_sloc0_1_0:
      000014                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      0006AB                        611 _rgb_matrix_config::
      0006AB                        612 	.ds 8
      0006B3                        613 _changed_at:
      0006B3                        614 	.ds 2
      0006B5                        615 _frame_at:
      0006B5                        616 	.ds 2
      0006B7                        617 _phase:
      0006B7                        618 	.ds 2
      0006B9                        619 _led_index:
      0006B9                        620 	.ds 1
      0006BA                        621 _frame_mode:
      0006BA                        622 	.ds 1
      0006BB                        623 _frame_hue:
      0006BB                        624 	.ds 1
      0006BC                        625 _frame_sat:
      0006BC                        626 	.ds 1
      0006BD                        627 _frame_val:
      0006BD                        628 	.ds 1
      0006BE                        629 _frame_flags:
      0006BE                        630 	.ds 1
      0006BF                        631 _frame_phase:
      0006BF                        632 	.ds 1
      0006C0                        633 _reactive_age:
      0006C0                        634 	.ds 82
      000712                        635 _reactive_at:
      000712                        636 	.ds 2
      000714                        637 _add_sat_PARM_2:
      000714                        638 	.ds 1
      000715                        639 _add_sat_x_10000_266:
      000715                        640 	.ds 1
      000716                        641 _sub_sat_PARM_2:
      000716                        642 	.ds 1
      000717                        643 _sub_sat_x_10000_268:
      000717                        644 	.ds 1
      000718                        645 _rgb_matrix_set_color_PARM_2:
      000718                        646 	.ds 1
      000719                        647 _rgb_matrix_set_color_PARM_3:
      000719                        648 	.ds 1
      00071A                        649 _rgb_matrix_set_color_PARM_4:
      00071A                        650 	.ds 1
      00071B                        651 _rgb_matrix_set_color_index_10000_284:
      00071B                        652 	.ds 2
      00071D                        653 _rgb_matrix_set_color_all_PARM_2:
      00071D                        654 	.ds 1
      00071E                        655 _rgb_matrix_set_color_all_PARM_3:
      00071E                        656 	.ds 1
      00071F                        657 _rgb_matrix_set_color_all_r_10000_287:
      00071F                        658 	.ds 1
      000720                        659 _sine8_theta_10000_289:
      000720                        660 	.ds 1
      000721                        661 _sine8_offset_10000_290:
      000721                        662 	.ds 1
      000722                        663 _sine8_fraction_10000_290:
      000722                        664 	.ds 1
      000723                        665 _breathing_cie_value_10000_293:
      000723                        666 	.ds 1
      000724                        667 _rgb_matrix_task_end_10000_298:
      000724                        668 	.ds 1
      000725                        669 _rgb_matrix_task_hsv_10000_298:
      000725                        670 	.ds 3
      000728                        671 _rgb_matrix_task_rgb_10000_298:
      000728                        672 	.ds 3
      00072B                        673 _process_rgb_matrix_PARM_2:
      00072B                        674 	.ds 1
      00072C                        675 _process_rgb_matrix_PARM_3:
      00072C                        676 	.ds 1
      00072D                        677 _process_rgb_matrix_row_10000_319:
      00072D                        678 	.ds 1
      00072E                        679 _rgb_matrix_set_suspend_state_state_10000_326:
      00072E                        680 	.ds 1
      00072F                        681 _rgb_matrix_mode_noeeprom_mode_10000_355:
      00072F                        682 	.ds 1
      000730                        683 _rgb_matrix_sethsv_noeeprom_PARM_2:
      000730                        684 	.ds 1
      000731                        685 _rgb_matrix_sethsv_noeeprom_PARM_3:
      000731                        686 	.ds 1
      000732                        687 _rgb_matrix_sethsv_noeeprom_hue_10000_363:
      000732                        688 	.ds 2
      000734                        689 _rgb_matrix_set_speed_noeeprom_speed_10000_365:
      000734                        690 	.ds 1
      000735                        691 _rgb_matrix_mode_mode_10000_411:
      000735                        692 	.ds 1
                                    693 ;--------------------------------------------------------
                                    694 ; absolute external ram data
                                    695 ;--------------------------------------------------------
                                    696 	.area XABS    (ABS,XDATA)
                                    697 ;--------------------------------------------------------
                                    698 ; initialized external ram data
                                    699 ;--------------------------------------------------------
                                    700 	.area XISEG   (XDATA)
                                    701 	.area HOME    (CODE)
                                    702 	.area GSINIT0 (CODE)
                                    703 	.area GSINIT1 (CODE)
                                    704 	.area GSINIT2 (CODE)
                                    705 	.area GSINIT3 (CODE)
                                    706 	.area GSINIT4 (CODE)
                                    707 	.area GSINIT5 (CODE)
                                    708 	.area GSINIT  (CODE)
                                    709 	.area GSFINAL (CODE)
                                    710 	.area CSEG    (CODE)
                                    711 ;--------------------------------------------------------
                                    712 ; global & static initialisations
                                    713 ;--------------------------------------------------------
                                    714 	.area HOME    (CODE)
                                    715 	.area GSINIT  (CODE)
                                    716 	.area GSFINAL (CODE)
                                    717 	.area GSINIT  (CODE)
                                    718 ;--------------------------------------------------------
                                    719 ; Home
                                    720 ;--------------------------------------------------------
                                    721 	.area HOME    (CODE)
                                    722 	.area HOME    (CODE)
                                    723 ;--------------------------------------------------------
                                    724 ; code
                                    725 ;--------------------------------------------------------
                                    726 	.area CSEG    (CODE)
                                    727 ;------------------------------------------------------------
                                    728 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    729 ;------------------------------------------------------------
                                    730 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_166'
                                    731 ;------------------------------------------------------------
                                    732 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    733 ;	-----------------------------------------
                           000007   734 	ar7 = 0x07
                           000006   735 	ar6 = 0x06
                           000005   736 	ar5 = 0x05
                           000004   737 	ar4 = 0x04
                           000003   738 	ar3 = 0x03
                           000002   739 	ar2 = 0x02
                           000001   740 	ar1 = 0x01
                           000000   741 	ar0 = 0x00
                                    742 ;	 function clear_reactive
                                    743 ;	-----------------------------------------
      004F2B                        744 _clear_reactive:
                                    745 ;	keyboards/ajazz/ak820/ak820_rgb.c:50: memset(reactive_age, 0, sizeof(reactive_age));
      004F2B 12 56 E8         [24]  746 	lcall	_ak820_outline_0179
      004F2E 74 52            [12]  747 	mov	a,#0x52
      004F30 12 38 8F         [24]  748 	lcall	_ak820_outline_0134
      004F33 90 06 C0         [24]  749 	mov	dptr,#_reactive_age
      004F36 F5 F0            [12]  750 	mov	b,a
      004F38 12 B7 0A         [24]  751 	lcall	_memset
                                    752 ;	keyboards/ajazz/ak820/ak820_rgb.c:51: reactive_at = timer_read();
      004F3B 31 20            [12]  753 	acall	_timer_read
      004F3D 12 38 99         [24]  754 	lcall	_ak820_outline_0138
      004F40 90 07 12         [24]  755 	mov	dptr,#_reactive_at
      004F43 12 56 D4         [24]  756 	lcall	_ak820_outline_0169
                                    757 ;	keyboards/ajazz/ak820/ak820_rgb.c:52: }
      004F46 22               [24]  758 	ret
                                    759 ;------------------------------------------------------------
                                    760 ;Allocation info for local variables in function 'age_reactive'
                                    761 ;------------------------------------------------------------
                                    762 ;ticks         Allocated with name '_age_reactive_ticks_10000_262'
                                    763 ;i             Allocated with name '_age_reactive_i_10000_262'
                                    764 ;decay         Allocated with name '_age_reactive_decay_10000_262'
                                    765 ;------------------------------------------------------------
                                    766 ;	keyboards/ajazz/ak820/ak820_rgb.c:54: static void age_reactive(void) {
                                    767 ;	-----------------------------------------
                                    768 ;	 function age_reactive
                                    769 ;	-----------------------------------------
      004F47                        770 _age_reactive:
                                    771 ;	keyboards/ajazz/ak820/ak820_rgb.c:55: uint16_t ticks = timer_elapsed(reactive_at) >> 4;
      004F47 90 07 12         [24]  772 	mov	dptr,#_reactive_at
      004F4A 12 37 E7         [24]  773 	lcall	_ak820_outline_0005
      004F4D 31 23            [12]  774 	acall	_timer_elapsed
      004F4F AE 82            [24]  775 	mov	r6, dpl
      004F51 E5 83            [12]  776 	mov	a,dph
      004F53 C4               [12]  777 	swap	a
      004F54 CE               [12]  778 	xch	a,r6
      004F55 C4               [12]  779 	swap	a
      004F56 54 0F            [12]  780 	anl	a,#0x0f
      004F58 6E               [12]  781 	xrl	a,r6
      004F59 CE               [12]  782 	xch	a,r6
      004F5A 54 0F            [12]  783 	anl	a,#0x0f
      004F5C CE               [12]  784 	xch	a,r6
      004F5D 6E               [12]  785 	xrl	a,r6
      004F5E CE               [12]  786 	xch	a,r6
                                    787 ;	keyboards/ajazz/ak820/ak820_rgb.c:57: if (!ticks) return;
      004F5F FF               [12]  788 	mov	r7,a
      004F60 4E               [12]  789 	orl	a,r6
      004F61 70 01            [24]  790 	jnz	00102$
      004F63 22               [24]  791 	ret
      004F64                        792 00102$:
                                    793 ;	keyboards/ajazz/ak820/ak820_rgb.c:58: reactive_at += ticks << 4;
      004F64 8E 04            [24]  794 	mov	ar4,r6
      004F66 EF               [12]  795 	mov	a,r7
      004F67 C4               [12]  796 	swap	a
      004F68 54 F0            [12]  797 	anl	a,#0xf0
      004F6A CC               [12]  798 	xch	a,r4
      004F6B C4               [12]  799 	swap	a
      004F6C CC               [12]  800 	xch	a,r4
      004F6D 6C               [12]  801 	xrl	a,r4
      004F6E CC               [12]  802 	xch	a,r4
      004F6F 54 F0            [12]  803 	anl	a,#0xf0
      004F71 CC               [12]  804 	xch	a,r4
      004F72 6C               [12]  805 	xrl	a,r4
      004F73 FD               [12]  806 	mov	r5,a
      004F74 90 07 12         [24]  807 	mov	dptr,#_reactive_at
      004F77 12 43 3D         [24]  808 	lcall	_ak820_outline_0103
      004F7A 90 07 12         [24]  809 	mov	dptr,#_reactive_at
      004F7D EC               [12]  810 	mov	a,r4
      004F7E 2A               [12]  811 	add	a, r2
      004F7F F0               [24]  812 	movx	@dptr,a
      004F80 ED               [12]  813 	mov	a,r5
      004F81 3B               [12]  814 	addc	a, r3
      004F82 A3               [24]  815 	inc	dptr
      004F83 F0               [24]  816 	movx	@dptr,a
                                    817 ;	keyboards/ajazz/ak820/ak820_rgb.c:60: decay = ticks > 255 ? 255 : (uint8_t)ticks;
      004F84 8E 04            [24]  818 	mov	ar4,r6
      004F86 8F 05            [24]  819 	mov	ar5,r7
      004F88 C3               [12]  820 	clr	c
      004F89 74 FF            [12]  821 	mov	a,#0xff
      004F8B 9C               [12]  822 	subb	a,r4
      004F8C E4               [12]  823 	clr	a
      004F8D 9D               [12]  824 	subb	a,r5
      004F8E 50 04            [24]  825 	jnc	00108$
                                    826 ;	free result
      004F90 7D FF            [12]  827 	mov	r5,#0xff
      004F92 80 02            [24]  828 	sjmp	00109$
      004F94                        829 00108$:
      004F94 8E 05            [24]  830 	mov	ar5,r6
      004F96                        831 00109$:
                                    832 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      004F96 7F 00            [12]  833 	mov	r7,#0x00
      004F98                        834 00104$:
                                    835 ;	keyboards/ajazz/ak820/ak820_rgb.c:62: reactive_age[i] = decay >= reactive_age[i] ? 0 : reactive_age[i] - decay;
      004F98 EF               [12]  836 	mov	a,r7
      004F99 24 C0            [12]  837 	add	a, #_reactive_age
      004F9B FC               [12]  838 	mov	r4,a
      004F9C E4               [12]  839 	clr	a
      004F9D 34 06            [12]  840 	addc	a, #(_reactive_age >> 8)
      004F9F FE               [12]  841 	mov	r6,a
      004FA0 8C 82            [24]  842 	mov	dpl,r4
      004FA2 8E 83            [24]  843 	mov	dph,r6
      004FA4 E0               [24]  844 	movx	a,@dptr
      004FA5 FB               [12]  845 	mov	r3,a
      004FA6 C3               [12]  846 	clr	c
      004FA7 ED               [12]  847 	mov	a,r5
      004FA8 9B               [12]  848 	subb	a,r3
      004FA9 40 04            [24]  849 	jc	00110$
      004FAB 7B 00            [12]  850 	mov	r3,#0x00
      004FAD 80 08            [24]  851 	sjmp	00111$
      004FAF                        852 00110$:
      004FAF 8C 82            [24]  853 	mov	dpl,r4
      004FB1 8E 83            [24]  854 	mov	dph,r6
      004FB3 E0               [24]  855 	movx	a,@dptr
      004FB4 C3               [12]  856 	clr	c
      004FB5 9D               [12]  857 	subb	a,r5
      004FB6 FB               [12]  858 	mov	r3,a
      004FB7                        859 00111$:
      004FB7 8C 82            [24]  860 	mov	dpl,r4
      004FB9 8E 83            [24]  861 	mov	dph,r6
      004FBB EB               [12]  862 	mov	a,r3
      004FBC F0               [24]  863 	movx	@dptr,a
                                    864 ;	keyboards/ajazz/ak820/ak820_rgb.c:61: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      004FBD 0F               [12]  865 	inc	r7
      004FBE BF 52 00         [24]  866 	cjne	r7,#0x52,00144$
      004FC1                        867 00144$:
      004FC1 40 D5            [24]  868 	jc	00104$
                                    869 ;	keyboards/ajazz/ak820/ak820_rgb.c:64: }
      004FC3 22               [24]  870 	ret
                                    871 ;------------------------------------------------------------
                                    872 ;Allocation info for local variables in function 'add_sat'
                                    873 ;------------------------------------------------------------
                                    874 ;y             Allocated with name '_add_sat_PARM_2'
                                    875 ;x             Allocated with name '_add_sat_x_10000_266'
                                    876 ;------------------------------------------------------------
                                    877 ;	keyboards/ajazz/ak820/ak820_rgb.c:66: static uint8_t add_sat(uint8_t x, uint8_t y) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function add_sat
                                    880 ;	-----------------------------------------
      004FC4                        881 _add_sat:
      004FC4 E5 82            [12]  882 	mov	a,dpl
      004FC6 90 07 15         [24]  883 	mov	dptr,#_add_sat_x_10000_266
      004FC9 F0               [24]  884 	movx	@dptr,a
                                    885 ;	keyboards/ajazz/ak820/ak820_rgb.c:67: return x > (uint8_t)(255 - y) ? 255 : x + y;
      004FCA 90 07 14         [24]  886 	mov	dptr,#_add_sat_PARM_2
      004FCD E0               [24]  887 	movx	a,@dptr
      004FCE FF               [12]  888 	mov	r7,a
      004FCF FE               [12]  889 	mov	r6,a
      004FD0 74 FF            [12]  890 	mov	a,#0xff
      004FD2 C3               [12]  891 	clr	c
      004FD3 9E               [12]  892 	subb	a,r6
      004FD4 FE               [12]  893 	mov	r6,a
      004FD5 90 07 15         [24]  894 	mov	dptr,#_add_sat_x_10000_266
      004FD8 E0               [24]  895 	movx	a,@dptr
      004FD9 FD               [12]  896 	mov	r5,a
      004FDA C3               [12]  897 	clr	c
      004FDB EE               [12]  898 	mov	a,r6
      004FDC 9D               [12]  899 	subb	a,r5
      004FDD 50 04            [24]  900 	jnc	00103$
                                    901 ;	free result
      004FDF 7E FF            [12]  902 	mov	r6,#0xff
      004FE1 80 03            [24]  903 	sjmp	00104$
      004FE3                        904 00103$:
      004FE3 EF               [12]  905 	mov	a,r7
      004FE4 2D               [12]  906 	add	a, r5
      004FE5 FE               [12]  907 	mov	r6,a
      004FE6                        908 00104$:
      004FE6 8E 82            [24]  909 	mov	dpl, r6
                                    910 ;	keyboards/ajazz/ak820/ak820_rgb.c:68: }
      004FE8 22               [24]  911 	ret
                                    912 ;------------------------------------------------------------
                                    913 ;Allocation info for local variables in function 'sub_sat'
                                    914 ;------------------------------------------------------------
                                    915 ;y             Allocated with name '_sub_sat_PARM_2'
                                    916 ;x             Allocated with name '_sub_sat_x_10000_268'
                                    917 ;------------------------------------------------------------
                                    918 ;	keyboards/ajazz/ak820/ak820_rgb.c:70: static uint8_t sub_sat(uint8_t x, uint8_t y) {
                                    919 ;	-----------------------------------------
                                    920 ;	 function sub_sat
                                    921 ;	-----------------------------------------
      004FE9                        922 _sub_sat:
      004FE9 E5 82            [12]  923 	mov	a,dpl
      004FEB 90 07 17         [24]  924 	mov	dptr,#_sub_sat_x_10000_268
      004FEE F0               [24]  925 	movx	@dptr,a
                                    926 ;	keyboards/ajazz/ak820/ak820_rgb.c:71: return x < y ? 0 : x - y;
      004FEF E0               [24]  927 	movx	a,@dptr
      004FF0 FF               [12]  928 	mov	r7,a
      004FF1 90 07 16         [24]  929 	mov	dptr,#_sub_sat_PARM_2
      004FF4 E0               [24]  930 	movx	a,@dptr
      004FF5 FE               [12]  931 	mov	r6,a
      004FF6 C3               [12]  932 	clr	c
      004FF7 EF               [12]  933 	mov	a,r7
      004FF8 9E               [12]  934 	subb	a,r6
      004FF9 50 04            [24]  935 	jnc	00103$
      004FFB 7D 00            [12]  936 	mov	r5,#0x00
      004FFD 80 04            [24]  937 	sjmp	00104$
      004FFF                        938 00103$:
      004FFF EF               [12]  939 	mov	a,r7
      005000 C3               [12]  940 	clr	c
      005001 9E               [12]  941 	subb	a,r6
      005002 FD               [12]  942 	mov	r5,a
      005003                        943 00104$:
      005003 8D 82            [24]  944 	mov	dpl, r5
                                    945 ;	keyboards/ajazz/ak820/ak820_rgb.c:72: }
      005005 22               [24]  946 	ret
                                    947 ;------------------------------------------------------------
                                    948 ;Allocation info for local variables in function 'mark_dirty'
                                    949 ;------------------------------------------------------------
                                    950 ;	keyboards/ajazz/ak820/ak820_rgb.c:74: static void mark_dirty(void) {
                                    951 ;	-----------------------------------------
                                    952 ;	 function mark_dirty
                                    953 ;	-----------------------------------------
      005006                        954 _mark_dirty:
                                    955 ;	keyboards/ajazz/ak820/ak820_rgb.c:75: dirty = true;
                                    956 ;	assignBit
      005006 D2 12            [12]  957 	setb	_dirty
                                    958 ;	keyboards/ajazz/ak820/ak820_rgb.c:76: changed_at = timer_read();
      005008 12 49 20         [24]  959 	lcall	_timer_read
      00500B 12 38 99         [24]  960 	lcall	_ak820_outline_0138
      00500E 90 06 B3         [24]  961 	mov	dptr,#_changed_at
      005011 12 56 D4         [24]  962 	lcall	_ak820_outline_0169
                                    963 ;	keyboards/ajazz/ak820/ak820_rgb.c:77: }
      005014 22               [24]  964 	ret
                                    965 ;------------------------------------------------------------
                                    966 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix'
                                    967 ;------------------------------------------------------------
                                    968 ;raw           Allocated with name '_eeconfig_update_rgb_matrix_raw_10000_273'
                                    969 ;------------------------------------------------------------
                                    970 ;	keyboards/ajazz/ak820/ak820_rgb.c:79: void eeconfig_update_rgb_matrix(void) {
                                    971 ;	-----------------------------------------
                                    972 ;	 function eeconfig_update_rgb_matrix
                                    973 ;	-----------------------------------------
      005015                        974 _eeconfig_update_rgb_matrix:
                                    975 ;	keyboards/ajazz/ak820/ak820_rgb.c:81: uint8_t *raw = (uint8_t *)&rgb_matrix_config;
                                    976 ;	keyboards/ajazz/ak820/ak820_rgb.c:82: raw[6] = raw[7] = 0;
      005015 90 06 B2         [24]  977 	mov	dptr,#(_rgb_matrix_config + 0x0007)
      005018 E4               [12]  978 	clr	a
      005019 F0               [24]  979 	movx	@dptr,a
      00501A 90 06 B1         [24]  980 	mov	dptr,#(_rgb_matrix_config + 0x0006)
      00501D F0               [24]  981 	movx	@dptr,a
                                    982 ;	keyboards/ajazz/ak820/ak820_rgb.c:83: ak820_eeprom_update_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      00501E 90 05 95         [24]  983 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      005021 12 56 B7         [24]  984 	lcall	_ak820_outline_0086
      005024 90 05 98         [24]  985 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      005027 12 56 9E         [24]  986 	lcall	_ak820_outline_0069
      00502A 12 42 11         [24]  987 	lcall	_ak820_eeprom_update_block_xdata
                                    988 ;	keyboards/ajazz/ak820/ak820_rgb.c:84: dirty = false;
                                    989 ;	assignBit
      00502D C2 12            [12]  990 	clr	_dirty
                                    991 ;	keyboards/ajazz/ak820/ak820_rgb.c:85: }
      00502F 22               [24]  992 	ret
                                    993 ;------------------------------------------------------------
                                    994 ;Allocation info for local variables in function 'eeconfig_update_rgb_matrix_default'
                                    995 ;------------------------------------------------------------
                                    996 ;	keyboards/ajazz/ak820/ak820_rgb.c:87: void eeconfig_update_rgb_matrix_default(void) {
                                    997 ;	-----------------------------------------
                                    998 ;	 function eeconfig_update_rgb_matrix_default
                                    999 ;	-----------------------------------------
      005030                       1000 _eeconfig_update_rgb_matrix_default:
                                   1001 ;	keyboards/ajazz/ak820/ak820_rgb.c:88: memset(&rgb_matrix_config, 0, sizeof(rgb_matrix_config));
      005030 12 56 E8         [24] 1002 	lcall	_ak820_outline_0179
      005033 12 56 9E         [24] 1003 	lcall	_ak820_outline_0069
      005036 F5 F0            [12] 1004 	mov	b,a
      005038 12 B7 0A         [24] 1005 	lcall	_memset
                                   1006 ;	keyboards/ajazz/ak820/ak820_rgb.c:89: rgb_matrix_config.enable = 1;
      00503B 12 56 C7         [24] 1007 	lcall	_ak820_outline_0115
      00503E 44 01            [12] 1008 	orl	a,#0x01
      005040 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_rgb.c:90: rgb_matrix_config.mode = RGB_MATRIX_DEFAULT_MODE;
      005041 12 56 97         [24] 1011 	lcall	_ak820_outline_0065
      005044 44 04            [12] 1012 	orl	a,#0x04
      005046 F0               [24] 1013 	movx	@dptr,a
                                   1014 ;	keyboards/ajazz/ak820/ak820_rgb.c:91: rgb_matrix_config.hsv.h = 0;
      005047 90 06 AC         [24] 1015 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00504A E4               [12] 1016 	clr	a
      00504B F0               [24] 1017 	movx	@dptr,a
                                   1018 ;	keyboards/ajazz/ak820/ak820_rgb.c:92: rgb_matrix_config.hsv.s = 255;
      00504C 90 06 AD         [24] 1019 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      00504F 14               [12] 1020 	dec	a
      005050 F0               [24] 1021 	movx	@dptr,a
                                   1022 ;	keyboards/ajazz/ak820/ak820_rgb.c:93: rgb_matrix_config.hsv.v = RGB_MATRIX_DEFAULT_VAL;
      005051 90 06 AE         [24] 1023 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005054 74 50            [12] 1024 	mov	a,#0x50
      005056 F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	keyboards/ajazz/ak820/ak820_rgb.c:94: rgb_matrix_config.speed = RGB_MATRIX_DEFAULT_SPD;
      005057 90 06 AF         [24] 1027 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00505A 74 60            [12] 1028 	mov	a,#0x60
      00505C F0               [24] 1029 	movx	@dptr,a
                                   1030 ;	keyboards/ajazz/ak820/ak820_rgb.c:95: rgb_matrix_config.flags = LED_FLAG_ALL;
      00505D 90 06 B0         [24] 1031 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005060 74 FF            [12] 1032 	mov	a,#0xff
      005062 F0               [24] 1033 	movx	@dptr,a
                                   1034 ;	keyboards/ajazz/ak820/ak820_rgb.c:96: eeconfig_update_rgb_matrix();
                                   1035 ;	keyboards/ajazz/ak820/ak820_rgb.c:97: }
      005063 01 15            [12] 1036 	ajmp	_eeconfig_update_rgb_matrix
                                   1037 ;------------------------------------------------------------
                                   1038 ;Allocation info for local variables in function 'rgb_matrix_reload_from_eeprom'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	keyboards/ajazz/ak820/ak820_rgb.c:99: void rgb_matrix_reload_from_eeprom(void) {
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function rgb_matrix_reload_from_eeprom
                                   1043 ;	-----------------------------------------
      005065                       1044 _rgb_matrix_reload_from_eeprom:
                                   1045 ;	keyboards/ajazz/ak820/ak820_rgb.c:100: ak820_eeprom_read_block_xdata(&rgb_matrix_config, EECONFIG_RGB_MATRIX, sizeof(rgb_matrix_config));
      005065 90 05 85         [24] 1046 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      005068 12 56 B7         [24] 1047 	lcall	_ak820_outline_0086
      00506B 90 05 88         [24] 1048 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00506E 12 56 9E         [24] 1049 	lcall	_ak820_outline_0069
      005071 12 40 A2         [24] 1050 	lcall	_ak820_eeprom_read_block_xdata
                                   1051 ;	keyboards/ajazz/ak820/ak820_rgb.c:101: if (!rgb_matrix_config.mode || rgb_matrix_config.mode >= RGB_MATRIX_EFFECT_MAX || rgb_matrix_config.enable > 1) {
      005074 12 56 C7         [24] 1052 	lcall	_ak820_outline_0115
      005077 60 11            [24] 1053 	jz	00101$
      005079 12 56 78         [24] 1054 	lcall	_ak820_outline_0019
      00507C C3               [12] 1055 	clr	c
      00507D 64 80            [12] 1056 	xrl	a,#0x80
      00507F 94 87            [12] 1057 	subb	a,#0x87
      005081 50 07            [24] 1058 	jnc	00101$
      005083 12 56 97         [24] 1059 	lcall	_ak820_outline_0065
      005086 24 FE            [12] 1060 	add	a,#0xff - 0x01
      005088 50 02            [24] 1061 	jnc	00102$
                                   1062 ;	free result
      00508A                       1063 00101$:
                                   1064 ;	keyboards/ajazz/ak820/ak820_rgb.c:102: eeconfig_update_rgb_matrix_default();
      00508A 11 30            [24] 1065 	acall	_eeconfig_update_rgb_matrix_default
      00508C                       1066 00102$:
                                   1067 ;	keyboards/ajazz/ak820/ak820_rgb.c:104: if (rgb_matrix_config.hsv.v > RGB_MATRIX_MAXIMUM_BRIGHTNESS) {
      00508C 90 06 AE         [24] 1068 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00508F E0               [24] 1069 	movx	a,@dptr
      005090 24 5F            [12] 1070 	add	a,#0xff - 0xa0
      005092 50 06            [24] 1071 	jnc	00106$
                                   1072 ;	free result
                                   1073 ;	keyboards/ajazz/ak820/ak820_rgb.c:105: rgb_matrix_config.hsv.v = RGB_MATRIX_MAXIMUM_BRIGHTNESS;
      005094 90 06 AE         [24] 1074 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005097 74 A0            [12] 1075 	mov	a,#0xa0
      005099 F0               [24] 1076 	movx	@dptr,a
      00509A                       1077 00106$:
                                   1078 ;	keyboards/ajazz/ak820/ak820_rgb.c:107: dirty = false;
                                   1079 ;	assignBit
      00509A C2 12            [12] 1080 	clr	_dirty
                                   1081 ;	keyboards/ajazz/ak820/ak820_rgb.c:108: rendering = false;
                                   1082 ;	assignBit
      00509C C2 13            [12] 1083 	clr	_rendering
                                   1084 ;	keyboards/ajazz/ak820/ak820_rgb.c:109: clear_reactive();
                                   1085 ;	keyboards/ajazz/ak820/ak820_rgb.c:110: }
      00509E 02 4F 2B         [24] 1086 	ljmp	_clear_reactive
                                   1087 ;------------------------------------------------------------
                                   1088 ;Allocation info for local variables in function 'rgb_matrix_init'
                                   1089 ;------------------------------------------------------------
                                   1090 ;	keyboards/ajazz/ak820/ak820_rgb.c:112: void rgb_matrix_init(void) {
                                   1091 ;	-----------------------------------------
                                   1092 ;	 function rgb_matrix_init
                                   1093 ;	-----------------------------------------
      0050A1                       1094 _rgb_matrix_init:
                                   1095 ;	keyboards/ajazz/ak820/ak820_rgb.c:114: rgb_matrix_reload_from_eeprom();
      0050A1 11 65            [24] 1096 	acall	_rgb_matrix_reload_from_eeprom
                                   1097 ;	keyboards/ajazz/ak820/ak820_rgb.c:115: frame_at = timer_read() - RGB_MATRIX_LED_FLUSH_LIMIT;
      0050A3 12 49 20         [24] 1098 	lcall	_timer_read
      0050A6 12 43 4F         [24] 1099 	lcall	_ak820_outline_0133
      0050A9 EE               [12] 1100 	mov	a,r6
      0050AA 24 F0            [12] 1101 	add	a,#0xf0
      0050AC FE               [12] 1102 	mov	r6,a
      0050AD EF               [12] 1103 	mov	a,r7
      0050AE 34 FF            [12] 1104 	addc	a,#0xff
      0050B0 FF               [12] 1105 	mov	r7,a
      0050B1 90 06 B5         [24] 1106 	mov	dptr,#_frame_at
      0050B4 12 48 6D         [24] 1107 	lcall	_ak820_outline_0058
                                   1108 ;	keyboards/ajazz/ak820/ak820_rgb.c:116: }
      0050B7 22               [24] 1109 	ret
                                   1110 ;------------------------------------------------------------
                                   1111 ;Allocation info for local variables in function 'rgb_matrix_set_color'
                                   1112 ;------------------------------------------------------------
                                   1113 ;r             Allocated with name '_rgb_matrix_set_color_PARM_2'
                                   1114 ;g             Allocated with name '_rgb_matrix_set_color_PARM_3'
                                   1115 ;b             Allocated with name '_rgb_matrix_set_color_PARM_4'
                                   1116 ;index         Allocated with name '_rgb_matrix_set_color_index_10000_284'
                                   1117 ;------------------------------------------------------------
                                   1118 ;	keyboards/ajazz/ak820/ak820_rgb.c:118: void rgb_matrix_set_color(int index, uint8_t r, uint8_t g, uint8_t b) {
                                   1119 ;	-----------------------------------------
                                   1120 ;	 function rgb_matrix_set_color
                                   1121 ;	-----------------------------------------
      0050B8                       1122 _rgb_matrix_set_color:
      0050B8 12 38 75         [24] 1123 	lcall	_ak820_outline_0107
      0050BB 90 07 1B         [24] 1124 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0050BE 12 38 7A         [24] 1125 	lcall	_ak820_outline_0108
                                   1126 ;	keyboards/ajazz/ak820/ak820_rgb.c:119: if (index >= 0 && index < RGB_MATRIX_LED_COUNT) ak820_rgb_set_color((uint8_t)index, r, g, b);
      0050C1 90 07 1B         [24] 1127 	mov	dptr,#_rgb_matrix_set_color_index_10000_284
      0050C4 12 38 34         [24] 1128 	lcall	_ak820_outline_0051
      0050C7 20 E7 2E         [24] 1129 	jb	acc.7,00104$
      0050CA C3               [12] 1130 	clr	c
      0050CB EE               [12] 1131 	mov	a,r6
      0050CC 94 52            [12] 1132 	subb	a,#0x52
      0050CE EF               [12] 1133 	mov	a,r7
      0050CF 64 80            [12] 1134 	xrl	a,#0x80
      0050D1 94 80            [12] 1135 	subb	a,#0x80
      0050D3 50 23            [24] 1136 	jnc	00104$
      0050D5 90 07 18         [24] 1137 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0050D8 E0               [24] 1138 	movx	a,@dptr
      0050D9 FF               [12] 1139 	mov	r7,a
      0050DA 90 07 19         [24] 1140 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0050DD E0               [24] 1141 	movx	a,@dptr
      0050DE FD               [12] 1142 	mov	r5,a
      0050DF 90 07 1A         [24] 1143 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0050E2 E0               [24] 1144 	movx	a,@dptr
      0050E3 FC               [12] 1145 	mov	r4,a
      0050E4 90 04 1A         [24] 1146 	mov	dptr,#_ak820_rgb_set_color_PARM_2
      0050E7 EF               [12] 1147 	mov	a,r7
      0050E8 F0               [24] 1148 	movx	@dptr,a
      0050E9 90 04 1B         [24] 1149 	mov	dptr,#_ak820_rgb_set_color_PARM_3
      0050EC ED               [12] 1150 	mov	a,r5
      0050ED F0               [24] 1151 	movx	@dptr,a
      0050EE 90 04 1C         [24] 1152 	mov	dptr,#_ak820_rgb_set_color_PARM_4
      0050F1 EC               [12] 1153 	mov	a,r4
      0050F2 F0               [24] 1154 	movx	@dptr,a
      0050F3 8E 82            [24] 1155 	mov	dpl, r6
                                   1156 ;	keyboards/ajazz/ak820/ak820_rgb.c:120: }
      0050F5 02 33 82         [24] 1157 	ljmp	_ak820_rgb_set_color
      0050F8                       1158 00104$:
      0050F8 22               [24] 1159 	ret
                                   1160 ;------------------------------------------------------------
                                   1161 ;Allocation info for local variables in function 'rgb_matrix_set_color_all'
                                   1162 ;------------------------------------------------------------
                                   1163 ;g             Allocated with name '_rgb_matrix_set_color_all_PARM_2'
                                   1164 ;b             Allocated with name '_rgb_matrix_set_color_all_PARM_3'
                                   1165 ;r             Allocated with name '_rgb_matrix_set_color_all_r_10000_287'
                                   1166 ;------------------------------------------------------------
                                   1167 ;	keyboards/ajazz/ak820/ak820_rgb.c:122: void rgb_matrix_set_color_all(uint8_t r, uint8_t g, uint8_t b) {
                                   1168 ;	-----------------------------------------
                                   1169 ;	 function rgb_matrix_set_color_all
                                   1170 ;	-----------------------------------------
      0050F9                       1171 _rgb_matrix_set_color_all:
      0050F9 E5 82            [12] 1172 	mov	a,dpl
      0050FB 90 07 1F         [24] 1173 	mov	dptr,#_rgb_matrix_set_color_all_r_10000_287
      0050FE F0               [24] 1174 	movx	@dptr,a
                                   1175 ;	keyboards/ajazz/ak820/ak820_rgb.c:123: ak820_rgb_set_color_all(r, g, b);
      0050FF E0               [24] 1176 	movx	a,@dptr
      005100 FF               [12] 1177 	mov	r7,a
      005101 90 07 1D         [24] 1178 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      005104 E0               [24] 1179 	movx	a,@dptr
      005105 FE               [12] 1180 	mov	r6,a
      005106 90 07 1E         [24] 1181 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      005109 E0               [24] 1182 	movx	a,@dptr
      00510A FD               [12] 1183 	mov	r5,a
      00510B 90 04 1E         [24] 1184 	mov	dptr,#_ak820_rgb_set_color_all_PARM_2
      00510E EE               [12] 1185 	mov	a,r6
      00510F F0               [24] 1186 	movx	@dptr,a
      005110 90 04 1F         [24] 1187 	mov	dptr,#_ak820_rgb_set_color_all_PARM_3
      005113 ED               [12] 1188 	mov	a,r5
      005114 F0               [24] 1189 	movx	@dptr,a
      005115 8F 82            [24] 1190 	mov	dpl, r7
                                   1191 ;	keyboards/ajazz/ak820/ak820_rgb.c:124: }
      005117 02 33 B9         [24] 1192 	ljmp	_ak820_rgb_set_color_all
                                   1193 ;------------------------------------------------------------
                                   1194 ;Allocation info for local variables in function 'sine8'
                                   1195 ;------------------------------------------------------------
                                   1196 ;theta         Allocated with name '_sine8_theta_10000_289'
                                   1197 ;offset        Allocated with name '_sine8_offset_10000_290'
                                   1198 ;section       Allocated with name '_sine8_section_10000_290'
                                   1199 ;fraction      Allocated with name '_sine8_fraction_10000_290'
                                   1200 ;value         Allocated with name '_sine8_value_10000_290'
                                   1201 ;------------------------------------------------------------
                                   1202 ;	keyboards/ajazz/ak820/ak820_rgb.c:127: static uint8_t sine8(uint8_t theta) {
                                   1203 ;	-----------------------------------------
                                   1204 ;	 function sine8
                                   1205 ;	-----------------------------------------
      00511A                       1206 _sine8:
      00511A E5 82            [12] 1207 	mov	a,dpl
      00511C 90 07 20         [24] 1208 	mov	dptr,#_sine8_theta_10000_289
      00511F F0               [24] 1209 	movx	@dptr,a
                                   1210 ;	keyboards/ajazz/ak820/ak820_rgb.c:129: uint8_t offset = theta;
      005120 E0               [24] 1211 	movx	a,@dptr
      005121 FF               [12] 1212 	mov	r7,a
      005122 90 07 21         [24] 1213 	mov	dptr,#_sine8_offset_10000_290
      005125 F0               [24] 1214 	movx	@dptr,a
                                   1215 ;	keyboards/ajazz/ak820/ak820_rgb.c:131: if (theta & 0x40) offset = 255 - offset;
      005126 EF               [12] 1216 	mov	a,r7
      005127 30 E6 08         [24] 1217 	jnb	acc.6,00102$
      00512A 90 07 21         [24] 1218 	mov	dptr,#_sine8_offset_10000_290
      00512D 74 FF            [12] 1219 	mov	a,#0xff
      00512F C3               [12] 1220 	clr	c
      005130 9F               [12] 1221 	subb	a,r7
      005131 F0               [24] 1222 	movx	@dptr,a
      005132                       1223 00102$:
                                   1224 ;	keyboards/ajazz/ak820/ak820_rgb.c:132: offset &= 0x3f;
      005132 90 07 21         [24] 1225 	mov	dptr,#_sine8_offset_10000_290
      005135 E0               [24] 1226 	movx	a,@dptr
      005136 53 E0 3F         [24] 1227 	anl	acc,#0x3f
      005139 F0               [24] 1228 	movx	@dptr,a
                                   1229 ;	keyboards/ajazz/ak820/ak820_rgb.c:133: fraction = offset & 15;
      00513A 90 07 21         [24] 1230 	mov	dptr,#_sine8_offset_10000_290
      00513D E0               [24] 1231 	movx	a,@dptr
      00513E 54 0F            [12] 1232 	anl	a,#0x0f
      005140 FF               [12] 1233 	mov	r7,a
      005141 90 07 22         [24] 1234 	mov	dptr,#_sine8_fraction_10000_290
      005144 F0               [24] 1235 	movx	@dptr,a
                                   1236 ;	keyboards/ajazz/ak820/ak820_rgb.c:134: if (theta & 0x40) ++fraction;
      005145 90 07 20         [24] 1237 	mov	dptr,#_sine8_theta_10000_289
      005148 E0               [24] 1238 	movx	a,@dptr
      005149 30 E6 06         [24] 1239 	jnb	acc.6,00104$
      00514C 90 07 22         [24] 1240 	mov	dptr,#_sine8_fraction_10000_290
      00514F EF               [12] 1241 	mov	a,r7
      005150 04               [12] 1242 	inc	a
      005151 F0               [24] 1243 	movx	@dptr,a
      005152                       1244 00104$:
                                   1245 ;	keyboards/ajazz/ak820/ak820_rgb.c:135: section = (offset >> 4) * 2;
      005152 90 07 21         [24] 1246 	mov	dptr,#_sine8_offset_10000_290
      005155 E0               [24] 1247 	movx	a,@dptr
      005156 C4               [12] 1248 	swap	a
      005157 54 0F            [12] 1249 	anl	a,#0x0f
                                   1250 ;	keyboards/ajazz/ak820/ak820_rgb.c:136: value = coefficients[section] + (((uint16_t)coefficients[section + 1] * fraction) >> 4);
      005159 25 E0            [12] 1251 	add	a,acc
      00515B FF               [12] 1252 	mov	r7,a
      00515C 90 B7 EF         [24] 1253 	mov	dptr,#_sine8_coefficients_10000_290
      00515F 93               [24] 1254 	movc	a,@a+dptr
      005160 FE               [12] 1255 	mov	r6,a
      005161 0F               [12] 1256 	inc	r7
      005162 EF               [12] 1257 	mov	a,r7
      005163 90 B7 EF         [24] 1258 	mov	dptr,#_sine8_coefficients_10000_290
      005166 93               [24] 1259 	movc	a,@a+dptr
      005167 FF               [12] 1260 	mov	r7,a
      005168 90 07 22         [24] 1261 	mov	dptr,#_sine8_fraction_10000_290
      00516B E0               [24] 1262 	movx	a,@dptr
      00516C 8F F0            [24] 1263 	mov	b,r7
      00516E A4               [48] 1264 	mul	ab
      00516F FF               [12] 1265 	mov	r7,a
      005170 E5 F0            [12] 1266 	mov	a,b
      005172 C4               [12] 1267 	swap	a
      005173 CF               [12] 1268 	xch	a,r7
      005174 C4               [12] 1269 	swap	a
      005175 54 0F            [12] 1270 	anl	a,#0x0f
      005177 6F               [12] 1271 	xrl	a,r7
      005178 CF               [12] 1272 	xch	a,r7
      005179 54 0F            [12] 1273 	anl	a,#0x0f
      00517B CF               [12] 1274 	xch	a,r7
      00517C 6F               [12] 1275 	xrl	a,r7
      00517D CF               [12] 1276 	xch	a,r7
      00517E EF               [12] 1277 	mov	a,r7
      00517F 2E               [12] 1278 	add	a, r6
      005180 FF               [12] 1279 	mov	r7,a
                                   1280 ;	keyboards/ajazz/ak820/ak820_rgb.c:137: return (theta & 0x80) ? 128 - value : 128 + value;
      005181 90 07 20         [24] 1281 	mov	dptr,#_sine8_theta_10000_289
      005184 E0               [24] 1282 	movx	a,@dptr
      005185 30 E7 09         [24] 1283 	jnb	acc.7,00107$
      005188 8F 06            [24] 1284 	mov	ar6,r7
      00518A 74 80            [12] 1285 	mov	a,#0x80
      00518C C3               [12] 1286 	clr	c
      00518D 9E               [12] 1287 	subb	a,r6
      00518E FE               [12] 1288 	mov	r6,a
      00518F 80 04            [24] 1289 	sjmp	00108$
      005191                       1290 00107$:
      005191 74 80            [12] 1291 	mov	a,#0x80
      005193 2F               [12] 1292 	add	a, r7
      005194 FE               [12] 1293 	mov	r6,a
      005195                       1294 00108$:
      005195 8E 82            [24] 1295 	mov	dpl, r6
                                   1296 ;	keyboards/ajazz/ak820/ak820_rgb.c:138: }
      005197 22               [24] 1297 	ret
                                   1298 ;------------------------------------------------------------
                                   1299 ;Allocation info for local variables in function 'breathing_cie'
                                   1300 ;------------------------------------------------------------
                                   1301 ;value         Allocated with name '_breathing_cie_value_10000_293'
                                   1302 ;index         Allocated with name '_breathing_cie_index_10000_294'
                                   1303 ;low           Allocated with name '_breathing_cie_low_10000_294'
                                   1304 ;delta         Allocated with name '_breathing_cie_delta_10001_296'
                                   1305 ;fraction      Allocated with name '_breathing_cie_fraction_10001_296'
                                   1306 ;product       Allocated with name '_breathing_cie_product_10001_296'
                                   1307 ;------------------------------------------------------------
                                   1308 ;	keyboards/ajazz/ak820/ak820_rgb.c:145: static uint8_t breathing_cie(uint8_t value) {
                                   1309 ;	-----------------------------------------
                                   1310 ;	 function breathing_cie
                                   1311 ;	-----------------------------------------
      005198                       1312 _breathing_cie:
      005198 E5 82            [12] 1313 	mov	a,dpl
      00519A 90 07 23         [24] 1314 	mov	dptr,#_breathing_cie_value_10000_293
      00519D F0               [24] 1315 	movx	@dptr,a
                                   1316 ;	keyboards/ajazz/ak820/ak820_rgb.c:149: uint8_t index = value >> 3;
      00519E E0               [24] 1317 	movx	a,@dptr
      00519F FF               [12] 1318 	mov	r7,a
      0051A0 12 56 F6         [24] 1319 	lcall	_ak820_outline_0188
                                   1320 ;	keyboards/ajazz/ak820/ak820_rgb.c:150: uint8_t low = pgm_read_byte(&CIE1931_CURVE[index]);
      0051A3 FE               [12] 1321 	mov	r6,a
      0051A4 90 BA FB         [24] 1322 	mov	dptr,#_CIE1931_CURVE
      0051A7 93               [24] 1323 	movc	a,@a+dptr
      0051A8 FD               [12] 1324 	mov	r5,a
                                   1325 ;	keyboards/ajazz/ak820/ak820_rgb.c:151: if (index == 31) return low;
      0051A9 BE 1F 03         [24] 1326 	cjne	r6,#0x1f,00102$
      0051AC 8D 82            [24] 1327 	mov	dpl, r5
      0051AE 22               [24] 1328 	ret
      0051AF                       1329 00102$:
                                   1330 ;	keyboards/ajazz/ak820/ak820_rgb.c:152: uint8_t delta = pgm_read_byte(&CIE1931_CURVE[index + 1]) - low;
      0051AF EE               [12] 1331 	mov	a,r6
      0051B0 04               [12] 1332 	inc	a
      0051B1 90 BA FB         [24] 1333 	mov	dptr,#_CIE1931_CURVE
      0051B4 93               [24] 1334 	movc	a,@a+dptr
      0051B5 C3               [12] 1335 	clr	c
      0051B6 9D               [12] 1336 	subb	a,r5
      0051B7 FE               [12] 1337 	mov	r6,a
                                   1338 ;	keyboards/ajazz/ak820/ak820_rgb.c:153: uint8_t fraction = value & 7;
      0051B8 74 07            [12] 1339 	mov	a,#0x07
      0051BA 5F               [12] 1340 	anl	a,r7
                                   1341 ;	keyboards/ajazz/ak820/ak820_rgb.c:154: uint8_t product = (uint8_t)(delta * fraction);
      0051BB F5 F0            [12] 1342 	mov	b,a
      0051BD EE               [12] 1343 	mov	a,r6
      0051BE A4               [48] 1344 	mul	ab
                                   1345 ;	keyboards/ajazz/ak820/ak820_rgb.c:155: return low + (product >> 3);
      0051BF 12 56 F6         [24] 1346 	lcall	_ak820_outline_0188
      0051C2 2D               [12] 1347 	add	a, r5
                                   1348 ;	keyboards/ajazz/ak820/ak820_rgb.c:157: }
      0051C3 F5 82            [12] 1349 	mov	dpl,a
      0051C5 22               [24] 1350 	ret
                                   1351 ;------------------------------------------------------------
                                   1352 ;Allocation info for local variables in function 'rgb_matrix_task'
                                   1353 ;------------------------------------------------------------
                                   1354 ;end           Allocated with name '_rgb_matrix_task_end_10000_298'
                                   1355 ;hsv           Allocated with name '_rgb_matrix_task_hsv_10000_298'
                                   1356 ;rgb           Allocated with name '_rgb_matrix_task_rgb_10000_298'
                                   1357 ;shift         Allocated with name '_rgb_matrix_task_shift_80000_316'
                                   1358 ;duration      Allocated with name '_rgb_matrix_task_duration_80000_316'
                                   1359 ;age           Allocated with name '_rgb_matrix_task_age_80000_316'
                                   1360 ;------------------------------------------------------------
                                   1361 ;	keyboards/ajazz/ak820/ak820_rgb.c:160: void rgb_matrix_task(void) {
                                   1362 ;	-----------------------------------------
                                   1363 ;	 function rgb_matrix_task
                                   1364 ;	-----------------------------------------
      0051C6                       1365 _rgb_matrix_task:
                                   1366 ;	keyboards/ajazz/ak820/ak820_rgb.c:164: age_reactive();
      0051C6 12 4F 47         [24] 1367 	lcall	_age_reactive
                                   1368 ;	keyboards/ajazz/ak820/ak820_rgb.c:165: if (dirty && timer_elapsed(changed_at) >= 1000) eeconfig_update_rgb_matrix();
      0051C9 30 12 17         [24] 1369 	jnb	_dirty,00102$
      0051CC 90 06 B3         [24] 1370 	mov	dptr,#_changed_at
      0051CF 12 37 E7         [24] 1371 	lcall	_ak820_outline_0005
      0051D2 12 49 23         [24] 1372 	lcall	_timer_elapsed
      0051D5 12 43 4F         [24] 1373 	lcall	_ak820_outline_0133
      0051D8 C3               [12] 1374 	clr	c
      0051D9 EE               [12] 1375 	mov	a,r6
      0051DA 94 E8            [12] 1376 	subb	a,#0xe8
      0051DC EF               [12] 1377 	mov	a,r7
      0051DD 94 03            [12] 1378 	subb	a,#0x03
      0051DF 40 02            [24] 1379 	jc	00102$
      0051E1 11 15            [12] 1380 	acall	_eeconfig_update_rgb_matrix
      0051E3                       1381 00102$:
                                   1382 ;	keyboards/ajazz/ak820/ak820_rgb.c:166: if (!rendering) {
      0051E3 30 13 02         [24] 1383 	jnb	_rendering,00254$
      0051E6 41 9B            [12] 1384 	ajmp	00109$
      0051E8                       1385 00254$:
                                   1386 ;	keyboards/ajazz/ak820/ak820_rgb.c:167: if (timer_elapsed(frame_at) < RGB_MATRIX_LED_FLUSH_LIMIT) return;
      0051E8 90 06 B5         [24] 1387 	mov	dptr,#_frame_at
      0051EB 12 37 E7         [24] 1388 	lcall	_ak820_outline_0005
      0051EE 12 49 23         [24] 1389 	lcall	_timer_elapsed
      0051F1 12 43 4F         [24] 1390 	lcall	_ak820_outline_0133
      0051F4 C3               [12] 1391 	clr	c
      0051F5 EE               [12] 1392 	mov	a,r6
      0051F6 94 10            [12] 1393 	subb	a,#0x10
      0051F8 EF               [12] 1394 	mov	a,r7
      0051F9 94 00            [12] 1395 	subb	a,#0x00
      0051FB 50 01            [24] 1396 	jnc	00105$
      0051FD 22               [24] 1397 	ret
      0051FE                       1398 00105$:
                                   1399 ;	keyboards/ajazz/ak820/ak820_rgb.c:168: frame_at = timer_read();
      0051FE 12 49 20         [24] 1400 	lcall	_timer_read
      005201 12 38 99         [24] 1401 	lcall	_ak820_outline_0138
      005204 90 06 B5         [24] 1402 	mov	dptr,#_frame_at
      005207 12 56 D4         [24] 1403 	lcall	_ak820_outline_0169
                                   1404 ;	keyboards/ajazz/ak820/ak820_rgb.c:169: phase += (uint16_t)rgb_matrix_config.speed + 32;
      00520A 90 06 AF         [24] 1405 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00520D E0               [24] 1406 	movx	a,@dptr
      00520E FF               [12] 1407 	mov	r7,a
      00520F 7E 00            [12] 1408 	mov	r6,#0x00
      005211 74 20            [12] 1409 	mov	a,#0x20
      005213 2F               [12] 1410 	add	a, r7
      005214 FF               [12] 1411 	mov	r7,a
      005215 E4               [12] 1412 	clr	a
      005216 3E               [12] 1413 	addc	a, r6
      005217 FE               [12] 1414 	mov	r6,a
      005218 90 06 B7         [24] 1415 	mov	dptr,#_phase
      00521B 12 38 4B         [24] 1416 	lcall	_ak820_outline_0059
      00521E EF               [12] 1417 	mov	a,r7
      00521F 2C               [12] 1418 	add	a, r4
      005220 FF               [12] 1419 	mov	r7,a
      005221 EE               [12] 1420 	mov	a,r6
      005222 3D               [12] 1421 	addc	a, r5
      005223 FE               [12] 1422 	mov	r6,a
      005224 90 06 B7         [24] 1423 	mov	dptr,#_phase
      005227 EF               [12] 1424 	mov	a,r7
      005228 F0               [24] 1425 	movx	@dptr,a
      005229 EE               [12] 1426 	mov	a,r6
      00522A A3               [24] 1427 	inc	dptr
      00522B F0               [24] 1428 	movx	@dptr,a
                                   1429 ;	keyboards/ajazz/ak820/ak820_rgb.c:170: frame_phase = phase >> 8;
      00522C 90 06 B7         [24] 1430 	mov	dptr,#_phase
      00522F E0               [24] 1431 	movx	a,@dptr
      005230 A3               [24] 1432 	inc	dptr
      005231 E0               [24] 1433 	movx	a,@dptr
      005232 FF               [12] 1434 	mov	r7,a
      005233 90 06 BF         [24] 1435 	mov	dptr,#_frame_phase
      005236 F0               [24] 1436 	movx	@dptr,a
                                   1437 ;	keyboards/ajazz/ak820/ak820_rgb.c:171: frame_mode = suspended || !rgb_matrix_config.enable ? RGB_MATRIX_NONE : rgb_matrix_config.mode;
      005237 20 11 05         [24] 1438 	jb	_suspended,00135$
      00523A 12 56 97         [24] 1439 	lcall	_ak820_outline_0065
      00523D 70 04            [24] 1440 	jnz	00132$
      00523F                       1441 00135$:
      00523F 7E 00            [12] 1442 	mov	r6,#0x00
      005241 80 04            [24] 1443 	sjmp	00133$
      005243                       1444 00132$:
      005243 12 56 78         [24] 1445 	lcall	_ak820_outline_0019
      005246 FE               [12] 1446 	mov	r6,a
      005247                       1447 00133$:
      005247 90 06 BA         [24] 1448 	mov	dptr,#_frame_mode
      00524A EE               [12] 1449 	mov	a,r6
      00524B F0               [24] 1450 	movx	@dptr,a
                                   1451 ;	keyboards/ajazz/ak820/ak820_rgb.c:172: frame_hue = rgb_matrix_config.hsv.h;
      00524C 90 06 AC         [24] 1452 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00524F E0               [24] 1453 	movx	a,@dptr
      005250 90 06 BB         [24] 1454 	mov	dptr,#_frame_hue
      005253 F0               [24] 1455 	movx	@dptr,a
                                   1456 ;	keyboards/ajazz/ak820/ak820_rgb.c:173: frame_sat = rgb_matrix_config.hsv.s;
      005254 90 06 AD         [24] 1457 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005257 E0               [24] 1458 	movx	a,@dptr
      005258 90 06 BC         [24] 1459 	mov	dptr,#_frame_sat
      00525B F0               [24] 1460 	movx	@dptr,a
                                   1461 ;	keyboards/ajazz/ak820/ak820_rgb.c:174: frame_val = rgb_matrix_config.hsv.v;
      00525C 90 06 AE         [24] 1462 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00525F E0               [24] 1463 	movx	a,@dptr
      005260 FD               [12] 1464 	mov	r5,a
      005261 90 06 BD         [24] 1465 	mov	dptr,#_frame_val
      005264 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_rgb.c:175: frame_flags = rgb_matrix_config.flags;
      005265 90 06 B0         [24] 1468 	mov	dptr,#(_rgb_matrix_config + 0x0005)
      005268 E0               [24] 1469 	movx	a,@dptr
      005269 90 06 BE         [24] 1470 	mov	dptr,#_frame_flags
      00526C F0               [24] 1471 	movx	@dptr,a
                                   1472 ;	keyboards/ajazz/ak820/ak820_rgb.c:176: if (frame_mode == RGB_MATRIX_BREATHING) {
      00526D BE 02 24         [24] 1473 	cjne	r6,#0x02,00107$
                                   1474 ;	keyboards/ajazz/ak820/ak820_rgb.c:177: frame_val = ((uint16_t)frame_val * sine8(frame_phase - 64)) >> 8;
      005270 EF               [12] 1475 	mov	a,r7
      005271 24 C0            [12] 1476 	add	a,#0xc0
      005273 F5 82            [12] 1477 	mov	dpl,a
      005275 C0 05            [24] 1478 	push	ar5
      005277 31 1A            [24] 1479 	acall	_sine8
      005279 AF 82            [24] 1480 	mov	r7, dpl
      00527B D0 05            [24] 1481 	pop	ar5
      00527D 8D F0            [24] 1482 	mov	b,r5
      00527F EF               [12] 1483 	mov	a,r7
      005280 A4               [48] 1484 	mul	ab
      005281 AE F0            [24] 1485 	mov	r6,b
      005283 8E 05            [24] 1486 	mov	ar5,r6
      005285 90 06 BD         [24] 1487 	mov	dptr,#_frame_val
      005288 ED               [12] 1488 	mov	a,r5
      005289 F0               [24] 1489 	movx	@dptr,a
                                   1490 ;	keyboards/ajazz/ak820/ak820_rgb.c:179: frame_val = breathing_cie(frame_val);
      00528A 8D 82            [24] 1491 	mov	dpl, r5
      00528C 31 98            [24] 1492 	acall	_breathing_cie
      00528E E5 82            [12] 1493 	mov	a, dpl
      005290 90 06 BD         [24] 1494 	mov	dptr,#_frame_val
      005293 F0               [24] 1495 	movx	@dptr,a
      005294                       1496 00107$:
                                   1497 ;	keyboards/ajazz/ak820/ak820_rgb.c:182: led_index = 0;
      005294 90 06 B9         [24] 1498 	mov	dptr,#_led_index
      005297 E4               [12] 1499 	clr	a
      005298 F0               [24] 1500 	movx	@dptr,a
                                   1501 ;	keyboards/ajazz/ak820/ak820_rgb.c:183: rendering = true;
                                   1502 ;	assignBit
      005299 D2 13            [12] 1503 	setb	_rendering
      00529B                       1504 00109$:
                                   1505 ;	keyboards/ajazz/ak820/ak820_rgb.c:185: end = led_index + 8;
      00529B 12 56 F1         [24] 1506 	lcall	_ak820_outline_0186
      00529E 24 08            [12] 1507 	add	a,#0x08
      0052A0 FF               [12] 1508 	mov	r7,a
      0052A1 90 07 24         [24] 1509 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0052A4 F0               [24] 1510 	movx	@dptr,a
                                   1511 ;	keyboards/ajazz/ak820/ak820_rgb.c:186: if (end > RGB_MATRIX_LED_COUNT) end = RGB_MATRIX_LED_COUNT;
      0052A5 EF               [12] 1512 	mov	a,r7
      0052A6 24 AD            [12] 1513 	add	a,#0xff - 0x52
      0052A8 50 06            [24] 1514 	jnc	00125$
                                   1515 ;	free result
      0052AA 90 07 24         [24] 1516 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0052AD 74 52            [12] 1517 	mov	a,#0x52
      0052AF F0               [24] 1518 	movx	@dptr,a
                                   1519 ;	keyboards/ajazz/ak820/ak820_rgb.c:187: while (led_index < end) {
      0052B0                       1520 00125$:
      0052B0 12 56 F1         [24] 1521 	lcall	_ak820_outline_0186
      0052B3 FF               [12] 1522 	mov	r7,a
      0052B4 90 07 24         [24] 1523 	mov	dptr,#_rgb_matrix_task_end_10000_298
      0052B7 E0               [24] 1524 	movx	a,@dptr
      0052B8 FE               [12] 1525 	mov	r6,a
      0052B9 C3               [12] 1526 	clr	c
      0052BA EF               [12] 1527 	mov	a,r7
      0052BB 9E               [12] 1528 	subb	a,r6
      0052BC 40 02            [24] 1529 	jc	00261$
      0052BE 81 1B            [12] 1530 	ajmp	00127$
      0052C0                       1531 00261$:
                                   1532 ;	keyboards/ajazz/ak820/ak820_rgb.c:188: if (!frame_mode || !(LED_FLAG_KEYLIGHT & frame_flags)) {
      0052C0 12 56 CE         [24] 1533 	lcall	_ak820_outline_0140
      0052C3 E0               [24] 1534 	movx	a,@dptr
      0052C4 60 07            [24] 1535 	jz	00121$
      0052C6 90 06 BE         [24] 1536 	mov	dptr,#_frame_flags
      0052C9 E0               [24] 1537 	movx	a,@dptr
      0052CA 20 E2 19         [24] 1538 	jb	acc.2,00122$
      0052CD                       1539 00121$:
                                   1540 ;	keyboards/ajazz/ak820/ak820_rgb.c:189: rgb_matrix_set_color(led_index, 0, 0, 0);
      0052CD 12 56 F1         [24] 1541 	lcall	_ak820_outline_0186
      0052D0 FC               [12] 1542 	mov	r4,a
      0052D1 7D 00            [12] 1543 	mov	r5,#0x00
      0052D3 90 07 18         [24] 1544 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      0052D6 E4               [12] 1545 	clr	a
      0052D7 F0               [24] 1546 	movx	@dptr,a
      0052D8 90 07 19         [24] 1547 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      0052DB F0               [24] 1548 	movx	@dptr,a
      0052DC 90 07 1A         [24] 1549 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      0052DF 12 38 69         [24] 1550 	lcall	_ak820_outline_0101
      0052E2 11 B8            [24] 1551 	acall	_rgb_matrix_set_color
      0052E4 81 13            [12] 1552 	ajmp	00123$
      0052E6                       1553 00122$:
                                   1554 ;	keyboards/ajazz/ak820/ak820_rgb.c:191: if (frame_mode == RGB_MATRIX_VIALRGB_DIRECT) {
      0052E6 BE 05 20         [24] 1555 	cjne	r6,#0x05,00119$
                                   1556 ;	keyboards/ajazz/ak820/ak820_rgb.c:192: hsv = g_direct_mode_colors[led_index];
      0052E9 EF               [12] 1557 	mov	a,r7
      0052EA 75 F0 03         [24] 1558 	mov	b,#0x03
      0052ED A4               [48] 1559 	mul	ab
      0052EE 24 89            [12] 1560 	add	a, #_g_direct_mode_colors
      0052F0 FD               [12] 1561 	mov	r5,a
      0052F1 74 0C            [12] 1562 	mov	a,#(_g_direct_mode_colors >> 8)
      0052F3 35 F0            [12] 1563 	addc	a, b
      0052F5 FE               [12] 1564 	mov	r6,a
      0052F6 90 0D 9D         [24] 1565 	mov	dptr,#___memcpy_PARM_2
      0052F9 ED               [12] 1566 	mov	a,r5
      0052FA F0               [24] 1567 	movx	@dptr,a
      0052FB EE               [12] 1568 	mov	a,r6
      0052FC 12 56 A8         [24] 1569 	lcall	_ak820_outline_0073
      0052FF 90 07 25         [24] 1570 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005302 F5 F0            [12] 1571 	mov	b,a
      005304 12 B6 94         [24] 1572 	lcall	___memcpy
      005307 61 B8            [12] 1573 	ajmp	00120$
      005309                       1574 00119$:
                                   1575 ;	keyboards/ajazz/ak820/ak820_rgb.c:194: hsv.h = frame_hue;
      005309 90 06 BB         [24] 1576 	mov	dptr,#_frame_hue
      00530C E0               [24] 1577 	movx	a,@dptr
      00530D 90 07 25         [24] 1578 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005310 F0               [24] 1579 	movx	@dptr,a
                                   1580 ;	keyboards/ajazz/ak820/ak820_rgb.c:195: hsv.s = frame_sat;
      005311 90 06 BC         [24] 1581 	mov	dptr,#_frame_sat
      005314 E0               [24] 1582 	movx	a,@dptr
      005315 90 07 26         [24] 1583 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0001)
      005318 F0               [24] 1584 	movx	@dptr,a
                                   1585 ;	keyboards/ajazz/ak820/ak820_rgb.c:196: hsv.v = frame_val;
      005319 90 06 BD         [24] 1586 	mov	dptr,#_frame_val
      00531C E0               [24] 1587 	movx	a,@dptr
      00531D 90 07 27         [24] 1588 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      005320 F0               [24] 1589 	movx	@dptr,a
                                   1590 ;	keyboards/ajazz/ak820/ak820_rgb.c:197: if (frame_mode == RGB_MATRIX_CYCLE_ALL) hsv.h += frame_phase;
      005321 12 56 CE         [24] 1591 	lcall	_ak820_outline_0140
      005324 BE 03 0E         [24] 1592 	cjne	r6,#0x03,00113$
      005327 90 07 25         [24] 1593 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00532A E0               [24] 1594 	movx	a,@dptr
      00532B FE               [12] 1595 	mov	r6,a
      00532C 90 06 BF         [24] 1596 	mov	dptr,#_frame_phase
      00532F E0               [24] 1597 	movx	a,@dptr
      005330 2E               [12] 1598 	add	a, r6
      005331 90 07 25         [24] 1599 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      005334 F0               [24] 1600 	movx	@dptr,a
      005335                       1601 00113$:
                                   1602 ;	keyboards/ajazz/ak820/ak820_rgb.c:198: if (frame_mode == RGB_MATRIX_CYCLE_LEFT_RIGHT) hsv.h += ak820_led_points[led_index].x - frame_phase;
      005335 12 56 CE         [24] 1603 	lcall	_ak820_outline_0140
      005338 BE 04 23         [24] 1604 	cjne	r6,#0x04,00115$
      00533B 90 07 25         [24] 1605 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00533E E0               [24] 1606 	movx	a,@dptr
      00533F FE               [12] 1607 	mov	r6,a
      005340 12 56 F1         [24] 1608 	lcall	_ak820_outline_0186
      005343 75 F0 02         [24] 1609 	mov	b,#0x02
      005346 A4               [48] 1610 	mul	ab
      005347 24 57            [12] 1611 	add	a, #_ak820_led_points
      005349 F5 82            [12] 1612 	mov	dpl,a
      00534B 74 BA            [12] 1613 	mov	a,#(_ak820_led_points >> 8)
      00534D 12 56 C0         [24] 1614 	lcall	_ak820_outline_0109
      005350 FD               [12] 1615 	mov	r5,a
      005351 90 06 BF         [24] 1616 	mov	dptr,#_frame_phase
      005354 E0               [24] 1617 	movx	a,@dptr
      005355 FC               [12] 1618 	mov	r4,a
      005356 ED               [12] 1619 	mov	a,r5
      005357 C3               [12] 1620 	clr	c
      005358 9C               [12] 1621 	subb	a,r4
      005359 2E               [12] 1622 	add	a, r6
      00535A 90 07 25         [24] 1623 	mov	dptr,#_rgb_matrix_task_hsv_10000_298
      00535D F0               [24] 1624 	movx	@dptr,a
      00535E                       1625 00115$:
                                   1626 ;	keyboards/ajazz/ak820/ak820_rgb.c:199: if (frame_mode == RGB_MATRIX_SOLID_REACTIVE_SIMPLE) {
      00535E 12 56 CE         [24] 1627 	lcall	_ak820_outline_0140
      005361 BE 06 54         [24] 1628 	cjne	r6,#0x06,00120$
                                   1629 ;	keyboards/ajazz/ak820/ak820_rgb.c:201: uint8_t shift = 7 - (rgb_matrix_config.speed >> 6);
      005364 12 56 DF         [24] 1630 	lcall	_ak820_outline_0173
      005367 FE               [12] 1631 	mov	r6,a
      005368 74 07            [12] 1632 	mov	a,#0x07
      00536A C3               [12] 1633 	clr	c
      00536B 9E               [12] 1634 	subb	a,r6
      00536C FE               [12] 1635 	mov	r6,a
                                   1636 ;	keyboards/ajazz/ak820/ak820_rgb.c:202: uint8_t duration = 1 << shift;
      00536D 8E F0            [24] 1637 	mov	b,r6
      00536F 05 F0            [12] 1638 	inc	b
      005371 74 01            [12] 1639 	mov	a,#0x01
      005373 80 02            [24] 1640 	sjmp	00273$
      005375                       1641 00272$:
      005375 25 E0            [12] 1642 	add	a,acc
      005377                       1643 00273$:
      005377 D5 F0 FB         [24] 1644 	djnz	b,00272$
      00537A FD               [12] 1645 	mov	r5,a
                                   1646 ;	keyboards/ajazz/ak820/ak820_rgb.c:203: uint8_t age = reactive_age[led_index];
      00537B 12 56 F1         [24] 1647 	lcall	_ak820_outline_0186
      00537E 24 C0            [12] 1648 	add	a, #_reactive_age
      005380 F5 82            [12] 1649 	mov	dpl,a
      005382 E4               [12] 1650 	clr	a
      005383 34 06            [12] 1651 	addc	a, #(_reactive_age >> 8)
      005385 F5 83            [12] 1652 	mov	dph,a
      005387 E0               [24] 1653 	movx	a,@dptr
                                   1654 ;	keyboards/ajazz/ak820/ak820_rgb.c:204: hsv.v = age >= duration ? frame_val : ((uint16_t)frame_val * age) >> shift;
      005388 FC               [12] 1655 	mov	r4,a
      005389 C3               [12] 1656 	clr	c
      00538A 9D               [12] 1657 	subb	a,r5
      00538B 40 07            [24] 1658 	jc	00137$
      00538D 90 06 BD         [24] 1659 	mov	dptr,#_frame_val
      005390 E0               [24] 1660 	movx	a,@dptr
      005391 FB               [12] 1661 	mov	r3,a
      005392 80 1F            [24] 1662 	sjmp	00138$
      005394                       1663 00137$:
      005394 90 06 BD         [24] 1664 	mov	dptr,#_frame_val
      005397 E0               [24] 1665 	movx	a,@dptr
      005398 F5 F0            [12] 1666 	mov	b, a
      00539A EC               [12] 1667 	mov	a,r4
      00539B A4               [48] 1668 	mul	ab
      00539C FC               [12] 1669 	mov	r4,a
      00539D AA F0            [24] 1670 	mov	r2,b
      00539F 8E F0            [24] 1671 	mov	b,r6
      0053A1 05 F0            [12] 1672 	inc	b
      0053A3 AB 04            [24] 1673 	mov	r3,ar4
      0053A5 AD 02            [24] 1674 	mov	r5,ar2
      0053A7 80 07            [24] 1675 	sjmp	00276$
      0053A9                       1676 00275$:
      0053A9 C3               [12] 1677 	clr	c
      0053AA ED               [12] 1678 	mov	a,r5
      0053AB 13               [12] 1679 	rrc	a
      0053AC FD               [12] 1680 	mov	r5,a
      0053AD EB               [12] 1681 	mov	a,r3
      0053AE 13               [12] 1682 	rrc	a
      0053AF FB               [12] 1683 	mov	r3,a
      0053B0                       1684 00276$:
      0053B0 D5 F0 F6         [24] 1685 	djnz	b,00275$
      0053B3                       1686 00138$:
      0053B3 90 07 27         [24] 1687 	mov	dptr,#(_rgb_matrix_task_hsv_10000_298 + 0x0002)
      0053B6 EB               [12] 1688 	mov	a,r3
      0053B7 F0               [24] 1689 	movx	@dptr,a
      0053B8                       1690 00120$:
                                   1691 ;	keyboards/ajazz/ak820/ak820_rgb.c:210: hsv_to_rgb_into(hsv, frame_mode != RGB_MATRIX_BREATHING, &rgb);
      0053B8 12 56 CE         [24] 1692 	lcall	_ak820_outline_0140
      0053BB BE 02 03         [24] 1693 	cjne	r6,#0x02,00277$
      0053BE D3               [12] 1694 	setb	c
      0053BF 80 01            [24] 1695 	sjmp	00278$
      0053C1                       1696 00277$:
      0053C1 C3               [12] 1697 	clr	c
      0053C2                       1698 00278$:
      0053C2 B3               [12] 1699 	cpl	c
      0053C3 92 14            [24] 1700 	mov	_rgb_matrix_task_sloc0_1_0,c
      0053C5 90 0D 9D         [24] 1701 	mov	dptr,#___memcpy_PARM_2
      0053C8 74 25            [12] 1702 	mov	a,#_rgb_matrix_task_hsv_10000_298
      0053CA F0               [24] 1703 	movx	@dptr,a
      0053CB 74 07            [12] 1704 	mov	a,#(_rgb_matrix_task_hsv_10000_298 >> 8)
      0053CD 12 56 A8         [24] 1705 	lcall	_ak820_outline_0073
      0053D0 90 0A C0         [24] 1706 	mov	dptr,#_hsv_to_rgb_into_PARM_1
      0053D3 F5 F0            [12] 1707 	mov	b,a
      0053D5 12 B6 94         [24] 1708 	lcall	___memcpy
      0053D8 90 0A C3         [24] 1709 	mov	dptr,#_hsv_to_rgb_into_PARM_3
      0053DB 74 28            [12] 1710 	mov	a,#_rgb_matrix_task_rgb_10000_298
      0053DD F0               [24] 1711 	movx	@dptr,a
      0053DE 74 07            [12] 1712 	mov	a,#(_rgb_matrix_task_rgb_10000_298 >> 8)
      0053E0 A3               [24] 1713 	inc	dptr
      0053E1 F0               [24] 1714 	movx	@dptr,a
      0053E2 A2 14            [12] 1715 	mov	c,_rgb_matrix_task_sloc0_1_0
      0053E4 12 38 A4         [24] 1716 	lcall	_ak820_outline_0156
      0053E7 12 80 B2         [24] 1717 	lcall	_hsv_to_rgb_into
                                   1718 ;	keyboards/ajazz/ak820/ak820_rgb.c:214: rgb_matrix_set_color(led_index, rgb.r, rgb.g, rgb.b);
      0053EA 12 56 F1         [24] 1719 	lcall	_ak820_outline_0186
      0053ED FD               [12] 1720 	mov	r5,a
      0053EE 7E 00            [12] 1721 	mov	r6,#0x00
      0053F0 90 07 29         [24] 1722 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0001)
      0053F3 E0               [24] 1723 	movx	a,@dptr
      0053F4 FC               [12] 1724 	mov	r4,a
      0053F5 90 07 28         [24] 1725 	mov	dptr,#_rgb_matrix_task_rgb_10000_298
      0053F8 E0               [24] 1726 	movx	a,@dptr
      0053F9 FB               [12] 1727 	mov	r3,a
      0053FA 90 07 2A         [24] 1728 	mov	dptr,#(_rgb_matrix_task_rgb_10000_298 + 0x0002)
      0053FD E0               [24] 1729 	movx	a,@dptr
      0053FE FA               [12] 1730 	mov	r2,a
      0053FF 90 07 18         [24] 1731 	mov	dptr,#_rgb_matrix_set_color_PARM_2
      005402 EC               [12] 1732 	mov	a,r4
      005403 F0               [24] 1733 	movx	@dptr,a
      005404 90 07 19         [24] 1734 	mov	dptr,#_rgb_matrix_set_color_PARM_3
      005407 EB               [12] 1735 	mov	a,r3
      005408 F0               [24] 1736 	movx	@dptr,a
      005409 90 07 1A         [24] 1737 	mov	dptr,#_rgb_matrix_set_color_PARM_4
      00540C EA               [12] 1738 	mov	a,r2
      00540D F0               [24] 1739 	movx	@dptr,a
      00540E 12 38 94         [24] 1740 	lcall	_ak820_outline_0135
      005411 11 B8            [24] 1741 	acall	_rgb_matrix_set_color
      005413                       1742 00123$:
                                   1743 ;	keyboards/ajazz/ak820/ak820_rgb.c:216: ++led_index;
      005413 12 56 F1         [24] 1744 	lcall	_ak820_outline_0186
      005416 24 01            [12] 1745 	add	a, #0x01
      005418 F0               [24] 1746 	movx	@dptr,a
      005419 41 B0            [12] 1747 	ajmp	00125$
      00541B                       1748 00127$:
                                   1749 ;	keyboards/ajazz/ak820/ak820_rgb.c:218: if (led_index == RGB_MATRIX_LED_COUNT) {
      00541B BF 52 02         [24] 1750 	cjne	r7,#0x52,00130$
                                   1751 ;	keyboards/ajazz/ak820/ak820_rgb.c:220: rendering = false;
                                   1752 ;	assignBit
      00541E C2 13            [12] 1753 	clr	_rendering
      005420                       1754 00130$:
                                   1755 ;	keyboards/ajazz/ak820/ak820_rgb.c:222: }
      005420 22               [24] 1756 	ret
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'process_rgb_matrix'
                                   1759 ;------------------------------------------------------------
                                   1760 ;col           Allocated with name '_process_rgb_matrix_PARM_2'
                                   1761 ;pressed       Allocated with name '_process_rgb_matrix_PARM_3'
                                   1762 ;row           Allocated with name '_process_rgb_matrix_row_10000_319'
                                   1763 ;i             Allocated with name '_process_rgb_matrix_i_10000_320'
                                   1764 ;slot          Allocated with name '_process_rgb_matrix_slot_10000_320'
                                   1765 ;------------------------------------------------------------
                                   1766 ;	keyboards/ajazz/ak820/ak820_rgb.c:224: void process_rgb_matrix(uint8_t row, uint8_t col, bool pressed) {
                                   1767 ;	-----------------------------------------
                                   1768 ;	 function process_rgb_matrix
                                   1769 ;	-----------------------------------------
      005421                       1770 _process_rgb_matrix:
      005421 E5 82            [12] 1771 	mov	a,dpl
      005423 90 07 2D         [24] 1772 	mov	dptr,#_process_rgb_matrix_row_10000_319
      005426 F0               [24] 1773 	movx	@dptr,a
                                   1774 ;	keyboards/ajazz/ak820/ak820_rgb.c:226: if (!pressed || suspended || !rgb_matrix_config.enable ||
      005427 90 07 2C         [24] 1775 	mov	dptr,#_process_rgb_matrix_PARM_3
      00542A E0               [24] 1776 	movx	a,@dptr
      00542B 60 23            [24] 1777 	jz	00101$
      00542D 20 11 20         [24] 1778 	jb	_suspended,00101$
      005430 12 56 97         [24] 1779 	lcall	_ak820_outline_0065
      005433 60 1B            [24] 1780 	jz	00101$
                                   1781 ;	keyboards/ajazz/ak820/ak820_rgb.c:227: rgb_matrix_config.mode != RGB_MATRIX_SOLID_REACTIVE_SIMPLE || row >= MATRIX_ROWS || col >= MATRIX_COLS) return;
      005435 12 56 78         [24] 1782 	lcall	_ak820_outline_0019
      005438 FF               [12] 1783 	mov	r7,a
      005439 BF 06 14         [24] 1784 	cjne	r7,#0x06,00101$
      00543C 90 07 2D         [24] 1785 	mov	dptr,#_process_rgb_matrix_row_10000_319
      00543F E0               [24] 1786 	movx	a,@dptr
      005440 FF               [12] 1787 	mov	r7,a
      005441 BF 10 00         [24] 1788 	cjne	r7,#0x10,00169$
      005444                       1789 00169$:
      005444 50 0A            [24] 1790 	jnc	00101$
      005446 90 07 2B         [24] 1791 	mov	dptr,#_process_rgb_matrix_PARM_2
      005449 E0               [24] 1792 	movx	a,@dptr
      00544A FE               [12] 1793 	mov	r6,a
      00544B BE 08 00         [24] 1794 	cjne	r6,#0x08,00171$
      00544E                       1795 00171$:
      00544E 40 01            [24] 1796 	jc	00102$
      005450                       1797 00101$:
      005450 22               [24] 1798 	ret
      005451                       1799 00102$:
                                   1800 ;	keyboards/ajazz/ak820/ak820_rgb.c:228: age_reactive();
      005451 C0 07            [24] 1801 	push	ar7
      005453 C0 06            [24] 1802 	push	ar6
      005455 12 4F 47         [24] 1803 	lcall	_age_reactive
      005458 D0 06            [24] 1804 	pop	ar6
      00545A D0 07            [24] 1805 	pop	ar7
                                   1806 ;	keyboards/ajazz/ak820/ak820_rgb.c:229: slot = row * MATRIX_COLS + col;
      00545C EF               [12] 1807 	mov	a,r7
      00545D 12 38 B9         [24] 1808 	lcall	_ak820_outline_0190
      005460 2E               [12] 1809 	add	a,r6
      005461 FF               [12] 1810 	mov	r7,a
                                   1811 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005462 7E 00            [12] 1812 	mov	r6,#0x00
      005464                       1813 00111$:
                                   1814 ;	keyboards/ajazz/ak820/ak820_rgb.c:231: if (ak820_rgb_slots[i] == slot) {
      005464 EE               [12] 1815 	mov	a,r6
      005465 90 B7 9D         [24] 1816 	mov	dptr,#_ak820_rgb_slots
      005468 93               [24] 1817 	movc	a,@a+dptr
      005469 B5 07 29         [24] 1818 	cjne	a,ar7,00112$
                                   1819 ;	keyboards/ajazz/ak820/ak820_rgb.c:232: reactive_age[i] = 128 >> (rgb_matrix_config.speed >> 6);
      00546C EE               [12] 1820 	mov	a,r6
      00546D 24 C0            [12] 1821 	add	a, #_reactive_age
      00546F FC               [12] 1822 	mov	r4,a
      005470 E4               [12] 1823 	clr	a
      005471 34 06            [12] 1824 	addc	a, #(_reactive_age >> 8)
      005473 FD               [12] 1825 	mov	r5,a
      005474 12 56 DF         [24] 1826 	lcall	_ak820_outline_0173
      005477 F5 F0            [12] 1827 	mov	b, a
      005479 05 F0            [12] 1828 	inc	b
      00547B 7B 80            [12] 1829 	mov	r3,#0x80
      00547D E4               [12] 1830 	clr	a
      00547E FA               [12] 1831 	mov	r2,a
      00547F 33               [12] 1832 	rlc	a
      005480 92 D2            [24] 1833 	mov	ov,c
      005482 80 08            [24] 1834 	sjmp	00176$
      005484                       1835 00175$:
      005484 A2 D2            [12] 1836 	mov	c,ov
      005486 EA               [12] 1837 	mov	a,r2
      005487 13               [12] 1838 	rrc	a
      005488 FA               [12] 1839 	mov	r2,a
      005489 EB               [12] 1840 	mov	a,r3
      00548A 13               [12] 1841 	rrc	a
      00548B FB               [12] 1842 	mov	r3,a
      00548C                       1843 00176$:
      00548C D5 F0 F5         [24] 1844 	djnz	b,00175$
      00548F 12 38 8A         [24] 1845 	lcall	_ak820_outline_0124
      005492 EB               [12] 1846 	mov	a,r3
      005493 F0               [24] 1847 	movx	@dptr,a
                                   1848 ;	keyboards/ajazz/ak820/ak820_rgb.c:233: return;
      005494 22               [24] 1849 	ret
      005495                       1850 00112$:
                                   1851 ;	keyboards/ajazz/ak820/ak820_rgb.c:230: for (i = 0; i < RGB_MATRIX_LED_COUNT; ++i) {
      005495 0E               [12] 1852 	inc	r6
      005496 BE 52 00         [24] 1853 	cjne	r6,#0x52,00177$
      005499                       1854 00177$:
      005499 40 C9            [24] 1855 	jc	00111$
                                   1856 ;	keyboards/ajazz/ak820/ak820_rgb.c:236: }
      00549B 22               [24] 1857 	ret
                                   1858 ;------------------------------------------------------------
                                   1859 ;Allocation info for local variables in function 'rgb_matrix_set_suspend_state'
                                   1860 ;------------------------------------------------------------
                                   1861 ;sloc0         Allocated with name '_rgb_matrix_set_suspend_state_sloc0_1_0'
                                   1862 ;state         Allocated with name '_rgb_matrix_set_suspend_state_state_10000_326'
                                   1863 ;------------------------------------------------------------
                                   1864 ;	keyboards/ajazz/ak820/ak820_rgb.c:238: void rgb_matrix_set_suspend_state(bool state) {
                                   1865 ;	-----------------------------------------
                                   1866 ;	 function rgb_matrix_set_suspend_state
                                   1867 ;	-----------------------------------------
      00549C                       1868 _rgb_matrix_set_suspend_state:
      00549C E5 82            [12] 1869 	mov	a,dpl
      00549E 90 07 2E         [24] 1870 	mov	dptr,#_rgb_matrix_set_suspend_state_state_10000_326
      0054A1 F0               [24] 1871 	movx	@dptr,a
                                   1872 ;	keyboards/ajazz/ak820/ak820_rgb.c:239: suspended = state;
      0054A2 E0               [24] 1873 	movx	a,@dptr
                                   1874 ;	assignBit
      0054A3 F5 15            [12] 1875 	mov	_rgb_matrix_set_suspend_state_sloc0_1_0,a
      0054A5 13               [12] 1876 	rrc	a
      0054A6 92 11            [24] 1877 	mov	_suspended,c
                                   1878 ;	keyboards/ajazz/ak820/ak820_rgb.c:240: rendering = false;
                                   1879 ;	assignBit
      0054A8 C2 13            [12] 1880 	clr	_rendering
                                   1881 ;	keyboards/ajazz/ak820/ak820_rgb.c:241: clear_reactive();
      0054AA 12 4F 2B         [24] 1882 	lcall	_clear_reactive
                                   1883 ;	keyboards/ajazz/ak820/ak820_rgb.c:242: if (state) {
      0054AD E5 15            [12] 1884 	mov	a,_rgb_matrix_set_suspend_state_sloc0_1_0
      0054AF 60 0E            [24] 1885 	jz	00103$
                                   1886 ;	keyboards/ajazz/ak820/ak820_rgb.c:243: rgb_matrix_set_color_all(0, 0, 0);
      0054B1 90 07 1D         [24] 1887 	mov	dptr,#_rgb_matrix_set_color_all_PARM_2
      0054B4 E4               [12] 1888 	clr	a
      0054B5 F0               [24] 1889 	movx	@dptr,a
      0054B6 90 07 1E         [24] 1890 	mov	dptr,#_rgb_matrix_set_color_all_PARM_3
      0054B9 F0               [24] 1891 	movx	@dptr,a
      0054BA 75 82 00         [24] 1892 	mov	dpl, #0x00
                                   1893 ;	keyboards/ajazz/ak820/ak820_rgb.c:245: }
      0054BD 01 F9            [24] 1894 	ajmp	_rgb_matrix_set_color_all
      0054BF                       1895 00103$:
      0054BF 22               [24] 1896 	ret
                                   1897 ;------------------------------------------------------------
                                   1898 ;Allocation info for local variables in function 'rgb_matrix_get_suspend_state'
                                   1899 ;------------------------------------------------------------
                                   1900 ;	keyboards/ajazz/ak820/ak820_rgb.c:247: bool rgb_matrix_get_suspend_state(void) { return suspended; }
                                   1901 ;	-----------------------------------------
                                   1902 ;	 function rgb_matrix_is_enabled
                                   1903 ;	-----------------------------------------
      0054C0                       1904 _rgb_matrix_is_enabled:
      0054C0 12 56 97         [24] 1905 	lcall	_ak820_outline_0065
      0054C3 F5 82            [12] 1906 	mov	dpl,a
      0054C5 22               [24] 1907 	ret
                                   1908 ;------------------------------------------------------------
                                   1909 ;Allocation info for local variables in function 'rgb_matrix_get_mode'
                                   1910 ;------------------------------------------------------------
                                   1911 ;	keyboards/ajazz/ak820/ak820_rgb.c:249: uint8_t rgb_matrix_get_mode(void) { return rgb_matrix_config.mode; }
                                   1912 ;	-----------------------------------------
                                   1913 ;	 function rgb_matrix_get_mode
                                   1914 ;	-----------------------------------------
      0054C6                       1915 _rgb_matrix_get_mode:
      0054C6 12 56 78         [24] 1916 	lcall	_ak820_outline_0019
      0054C9 F5 82            [12] 1917 	mov	dpl,a
      0054CB 22               [24] 1918 	ret
                                   1919 ;------------------------------------------------------------
                                   1920 ;Allocation info for local variables in function 'rgb_matrix_get_hsv'
                                   1921 ;------------------------------------------------------------
                                   1922 ;	keyboards/ajazz/ak820/ak820_rgb.c:250: HSV rgb_matrix_get_hsv(void) { return rgb_matrix_config.hsv; }
                                   1923 ;	-----------------------------------------
                                   1924 ;	 function rgb_matrix_get_hue
                                   1925 ;	-----------------------------------------
      0054CC                       1926 _rgb_matrix_get_hue:
      0054CC 90 06 AC         [24] 1927 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0054CF E0               [24] 1928 	movx	a,@dptr
      0054D0 F5 82            [12] 1929 	mov	dpl,a
      0054D2 22               [24] 1930 	ret
                                   1931 ;------------------------------------------------------------
                                   1932 ;Allocation info for local variables in function 'rgb_matrix_get_sat'
                                   1933 ;------------------------------------------------------------
                                   1934 ;	keyboards/ajazz/ak820/ak820_rgb.c:252: uint8_t rgb_matrix_get_sat(void) { return rgb_matrix_config.hsv.s; }
                                   1935 ;	-----------------------------------------
                                   1936 ;	 function rgb_matrix_get_sat
                                   1937 ;	-----------------------------------------
      0054D3                       1938 _rgb_matrix_get_sat:
      0054D3 90 06 AD         [24] 1939 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0054D6 E0               [24] 1940 	movx	a,@dptr
      0054D7 F5 82            [12] 1941 	mov	dpl,a
      0054D9 22               [24] 1942 	ret
                                   1943 ;------------------------------------------------------------
                                   1944 ;Allocation info for local variables in function 'rgb_matrix_get_val'
                                   1945 ;------------------------------------------------------------
                                   1946 ;	keyboards/ajazz/ak820/ak820_rgb.c:253: uint8_t rgb_matrix_get_val(void) { return rgb_matrix_config.hsv.v; }
                                   1947 ;	-----------------------------------------
                                   1948 ;	 function rgb_matrix_get_val
                                   1949 ;	-----------------------------------------
      0054DA                       1950 _rgb_matrix_get_val:
      0054DA 90 06 AE         [24] 1951 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0054DD E0               [24] 1952 	movx	a,@dptr
      0054DE F5 82            [12] 1953 	mov	dpl,a
      0054E0 22               [24] 1954 	ret
                                   1955 ;------------------------------------------------------------
                                   1956 ;Allocation info for local variables in function 'rgb_matrix_get_speed'
                                   1957 ;------------------------------------------------------------
                                   1958 ;	keyboards/ajazz/ak820/ak820_rgb.c:254: uint8_t rgb_matrix_get_speed(void) { return rgb_matrix_config.speed; }
                                   1959 ;	-----------------------------------------
                                   1960 ;	 function rgb_matrix_get_speed
                                   1961 ;	-----------------------------------------
      0054E1                       1962 _rgb_matrix_get_speed:
      0054E1 90 06 AF         [24] 1963 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0054E4 E0               [24] 1964 	movx	a,@dptr
      0054E5 F5 82            [12] 1965 	mov	dpl,a
      0054E7 22               [24] 1966 	ret
                                   1967 ;------------------------------------------------------------
                                   1968 ;Allocation info for local variables in function 'rgb_matrix_get_flags'
                                   1969 ;------------------------------------------------------------
                                   1970 ;	keyboards/ajazz/ak820/ak820_rgb.c:255: led_flags_t rgb_matrix_get_flags(void) { return rgb_matrix_config.flags; }
                                   1971 ;	-----------------------------------------
                                   1972 ;	 function rgb_matrix_toggle_noeeprom
                                   1973 ;	-----------------------------------------
      0054E8                       1974 _rgb_matrix_toggle_noeeprom:
      0054E8 12 56 97         [24] 1975 	lcall	_ak820_outline_0065
      0054EB FF               [12] 1976 	mov	r7,a
      0054EC 63 07 01         [24] 1977 	xrl	ar7,#0x01
      0054EF 90 06 AB         [24] 1978 	mov	dptr,#_rgb_matrix_config
      0054F2 EF               [12] 1979 	mov	a,r7
      0054F3 54 03            [12] 1980 	anl	a,#0x03
      0054F5 F5 F0            [12] 1981 	mov	b,a
      0054F7 E0               [24] 1982 	movx	a,@dptr
      0054F8 54 FC            [12] 1983 	anl	a,#0xfc
      0054FA 45 F0            [12] 1984 	orl	a,b
      0054FC F0               [24] 1985 	movx	@dptr,a
                                   1986 ;	assignBit
      0054FD C2 13            [12] 1987 	clr	_rendering
      0054FF 02 4F 2B         [24] 1988 	ljmp	_clear_reactive
                                   1989 ;------------------------------------------------------------
                                   1990 ;Allocation info for local variables in function 'rgb_matrix_enable_noeeprom'
                                   1991 ;------------------------------------------------------------
                                   1992 ;	keyboards/ajazz/ak820/ak820_rgb.c:258: void rgb_matrix_enable_noeeprom(void) { if (!rgb_matrix_config.enable) clear_reactive(); rgb_matrix_config.enable = 1; rendering = false; }
                                   1993 ;	-----------------------------------------
                                   1994 ;	 function rgb_matrix_enable_noeeprom
                                   1995 ;	-----------------------------------------
      005502                       1996 _rgb_matrix_enable_noeeprom:
      005502 12 56 97         [24] 1997 	lcall	_ak820_outline_0065
      005505 70 03            [24] 1998 	jnz	00102$
      005507 12 4F 2B         [24] 1999 	lcall	_clear_reactive
      00550A                       2000 00102$:
      00550A 12 56 C7         [24] 2001 	lcall	_ak820_outline_0115
      00550D 44 01            [12] 2002 	orl	a,#0x01
      00550F F0               [24] 2003 	movx	@dptr,a
                                   2004 ;	assignBit
      005510 C2 13            [12] 2005 	clr	_rendering
      005512 22               [24] 2006 	ret
                                   2007 ;------------------------------------------------------------
                                   2008 ;Allocation info for local variables in function 'rgb_matrix_disable_noeeprom'
                                   2009 ;------------------------------------------------------------
                                   2010 ;	keyboards/ajazz/ak820/ak820_rgb.c:259: void rgb_matrix_disable_noeeprom(void) { rgb_matrix_config.enable = 0; rendering = false; clear_reactive(); }
                                   2011 ;	-----------------------------------------
                                   2012 ;	 function rgb_matrix_disable_noeeprom
                                   2013 ;	-----------------------------------------
      005513                       2014 _rgb_matrix_disable_noeeprom:
      005513 12 56 C7         [24] 2015 	lcall	_ak820_outline_0115
      005516 F0               [24] 2016 	movx	@dptr,a
                                   2017 ;	assignBit
      005517 C2 13            [12] 2018 	clr	_rendering
      005519 02 4F 2B         [24] 2019 	ljmp	_clear_reactive
                                   2020 ;------------------------------------------------------------
                                   2021 ;Allocation info for local variables in function 'rgb_matrix_mode_noeeprom'
                                   2022 ;------------------------------------------------------------
                                   2023 ;mode          Allocated with name '_rgb_matrix_mode_noeeprom_mode_10000_355'
                                   2024 ;------------------------------------------------------------
                                   2025 ;	keyboards/ajazz/ak820/ak820_rgb.c:260: void rgb_matrix_mode_noeeprom(uint8_t mode) {
                                   2026 ;	-----------------------------------------
                                   2027 ;	 function rgb_matrix_mode_noeeprom
                                   2028 ;	-----------------------------------------
      00551C                       2029 _rgb_matrix_mode_noeeprom:
      00551C E5 82            [12] 2030 	mov	a,dpl
      00551E 90 07 2F         [24] 2031 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      005521 F0               [24] 2032 	movx	@dptr,a
                                   2033 ;	keyboards/ajazz/ak820/ak820_rgb.c:261: if (!mode || mode >= RGB_MATRIX_EFFECT_MAX) return;
      005522 E0               [24] 2034 	movx	a,@dptr
      005523 FF               [12] 2035 	mov	r7,a
      005524 60 05            [24] 2036 	jz	00101$
      005526 BF 07 00         [24] 2037 	cjne	r7,#0x07,00123$
      005529                       2038 00123$:
      005529 40 01            [24] 2039 	jc	00102$
      00552B                       2040 00101$:
      00552B 22               [24] 2041 	ret
      00552C                       2042 00102$:
                                   2043 ;	keyboards/ajazz/ak820/ak820_rgb.c:262: if (mode != rgb_matrix_config.mode) clear_reactive();
      00552C 12 56 78         [24] 2044 	lcall	_ak820_outline_0019
      00552F FE               [12] 2045 	mov	r6,a
      005530 EF               [12] 2046 	mov	a,r7
      005531 B5 06 02         [24] 2047 	cjne	a,ar6,00125$
      005534 80 03            [24] 2048 	sjmp	00105$
      005536                       2049 00125$:
      005536 12 4F 2B         [24] 2050 	lcall	_clear_reactive
      005539                       2051 00105$:
                                   2052 ;	keyboards/ajazz/ak820/ak820_rgb.c:263: rgb_matrix_config.mode = mode;
      005539 90 07 2F         [24] 2053 	mov	dptr,#_rgb_matrix_mode_noeeprom_mode_10000_355
      00553C E0               [24] 2054 	movx	a,@dptr
      00553D 90 06 AB         [24] 2055 	mov	dptr,#_rgb_matrix_config
      005540 25 E0            [12] 2056 	add	a,acc
      005542 25 E0            [12] 2057 	add	a,acc
      005544 54 FC            [12] 2058 	anl	a,#0xfc
      005546 F5 F0            [12] 2059 	mov	b,a
      005548 E0               [24] 2060 	movx	a,@dptr
      005549 54 03            [12] 2061 	anl	a,#0x03
      00554B 45 F0            [12] 2062 	orl	a,b
      00554D F0               [24] 2063 	movx	@dptr,a
                                   2064 ;	keyboards/ajazz/ak820/ak820_rgb.c:264: rendering = false;
                                   2065 ;	assignBit
      00554E C2 13            [12] 2066 	clr	_rendering
                                   2067 ;	keyboards/ajazz/ak820/ak820_rgb.c:265: }
      005550 22               [24] 2068 	ret
                                   2069 ;------------------------------------------------------------
                                   2070 ;Allocation info for local variables in function 'rgb_matrix_step_noeeprom'
                                   2071 ;------------------------------------------------------------
                                   2072 ;	keyboards/ajazz/ak820/ak820_rgb.c:266: void rgb_matrix_step_noeeprom(void) {
                                   2073 ;	-----------------------------------------
                                   2074 ;	 function rgb_matrix_step_noeeprom
                                   2075 ;	-----------------------------------------
      005551                       2076 _rgb_matrix_step_noeeprom:
                                   2077 ;	keyboards/ajazz/ak820/ak820_rgb.c:267: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode + 1 >= RGB_MATRIX_EFFECT_MAX ? 1 : rgb_matrix_config.mode + 1);
      005551 12 56 78         [24] 2078 	lcall	_ak820_outline_0019
      005554 FF               [12] 2079 	mov	r7,a
      005555 0F               [12] 2080 	inc	r7
      005556 BF 07 00         [24] 2081 	cjne	r7,#0x07,00112$
      005559                       2082 00112$:
      005559 40 04            [24] 2083 	jc	00103$
      00555B 7F 01            [12] 2084 	mov	r7,#0x01
      00555D 80 07            [24] 2085 	sjmp	00104$
      00555F                       2086 00103$:
      00555F 12 56 78         [24] 2087 	lcall	_ak820_outline_0019
      005562 FE               [12] 2088 	mov	r6,a
      005563 0E               [12] 2089 	inc	r6
      005564 8E 07            [24] 2090 	mov	ar7,r6
      005566                       2091 00104$:
      005566 8F 82            [24] 2092 	mov	dpl, r7
                                   2093 ;	keyboards/ajazz/ak820/ak820_rgb.c:268: }
      005568 A1 1C            [12] 2094 	ajmp	_rgb_matrix_mode_noeeprom
                                   2095 ;------------------------------------------------------------
                                   2096 ;Allocation info for local variables in function 'rgb_matrix_step_reverse_noeeprom'
                                   2097 ;------------------------------------------------------------
                                   2098 ;	keyboards/ajazz/ak820/ak820_rgb.c:269: void rgb_matrix_step_reverse_noeeprom(void) {
                                   2099 ;	-----------------------------------------
                                   2100 ;	 function rgb_matrix_step_reverse_noeeprom
                                   2101 ;	-----------------------------------------
      00556A                       2102 _rgb_matrix_step_reverse_noeeprom:
                                   2103 ;	keyboards/ajazz/ak820/ak820_rgb.c:270: rgb_matrix_mode_noeeprom(rgb_matrix_config.mode <= 1 ? RGB_MATRIX_EFFECT_MAX - 1 : rgb_matrix_config.mode - 1);
      00556A 12 56 78         [24] 2104 	lcall	_ak820_outline_0019
      00556D 24 FE            [12] 2105 	add	a,#0xff - 0x01
      00556F 40 04            [24] 2106 	jc	00103$
                                   2107 ;	free result
      005571 7F 06            [12] 2108 	mov	r7,#0x06
      005573 80 05            [24] 2109 	sjmp	00104$
      005575                       2110 00103$:
      005575 12 56 78         [24] 2111 	lcall	_ak820_outline_0019
      005578 14               [12] 2112 	dec	a
      005579 FF               [12] 2113 	mov	r7,a
      00557A                       2114 00104$:
      00557A 8F 82            [24] 2115 	mov	dpl, r7
                                   2116 ;	keyboards/ajazz/ak820/ak820_rgb.c:271: }
      00557C A1 1C            [12] 2117 	ajmp	_rgb_matrix_mode_noeeprom
                                   2118 ;------------------------------------------------------------
                                   2119 ;Allocation info for local variables in function 'rgb_matrix_sethsv_noeeprom'
                                   2120 ;------------------------------------------------------------
                                   2121 ;sat           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_2'
                                   2122 ;val           Allocated with name '_rgb_matrix_sethsv_noeeprom_PARM_3'
                                   2123 ;hue           Allocated with name '_rgb_matrix_sethsv_noeeprom_hue_10000_363'
                                   2124 ;------------------------------------------------------------
                                   2125 ;	keyboards/ajazz/ak820/ak820_rgb.c:272: void rgb_matrix_sethsv_noeeprom(uint16_t hue, uint8_t sat, uint8_t val) {
                                   2126 ;	-----------------------------------------
                                   2127 ;	 function rgb_matrix_sethsv_noeeprom
                                   2128 ;	-----------------------------------------
      00557E                       2129 _rgb_matrix_sethsv_noeeprom:
      00557E 12 38 75         [24] 2130 	lcall	_ak820_outline_0107
      005581 90 07 32         [24] 2131 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      005584 12 38 7A         [24] 2132 	lcall	_ak820_outline_0108
                                   2133 ;	keyboards/ajazz/ak820/ak820_rgb.c:273: rgb_matrix_config.hsv.h = hue;
      005587 90 07 32         [24] 2134 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_hue_10000_363
      00558A E0               [24] 2135 	movx	a,@dptr
      00558B 90 06 AC         [24] 2136 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      00558E F0               [24] 2137 	movx	@dptr,a
                                   2138 ;	keyboards/ajazz/ak820/ak820_rgb.c:274: rgb_matrix_config.hsv.s = sat;
      00558F 90 07 30         [24] 2139 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_2
      005592 E0               [24] 2140 	movx	a,@dptr
      005593 FF               [12] 2141 	mov	r7,a
      005594 90 06 AD         [24] 2142 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      005597 F0               [24] 2143 	movx	@dptr,a
                                   2144 ;	keyboards/ajazz/ak820/ak820_rgb.c:275: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      005598 90 07 31         [24] 2145 	mov	dptr,#_rgb_matrix_sethsv_noeeprom_PARM_3
      00559B E0               [24] 2146 	movx	a,@dptr
      00559C FF               [12] 2147 	mov  r7,a
      00559D 24 5F            [12] 2148 	add	a,#0xff - 0xa0
      00559F 50 04            [24] 2149 	jnc	00103$
                                   2150 ;	free result
      0055A1 7E A0            [12] 2151 	mov	r6,#0xa0
      0055A3 80 02            [24] 2152 	sjmp	00104$
      0055A5                       2153 00103$:
      0055A5 8F 06            [24] 2154 	mov	ar6,r7
      0055A7                       2155 00104$:
      0055A7 90 06 AE         [24] 2156 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0055AA EE               [12] 2157 	mov	a,r6
      0055AB F0               [24] 2158 	movx	@dptr,a
                                   2159 ;	keyboards/ajazz/ak820/ak820_rgb.c:276: }
      0055AC 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'rgb_matrix_set_speed_noeeprom'
                                   2163 ;------------------------------------------------------------
                                   2164 ;speed         Allocated with name '_rgb_matrix_set_speed_noeeprom_speed_10000_365'
                                   2165 ;------------------------------------------------------------
                                   2166 ;	keyboards/ajazz/ak820/ak820_rgb.c:277: void rgb_matrix_set_speed_noeeprom(uint8_t speed) { rgb_matrix_config.speed = speed; }
                                   2167 ;	-----------------------------------------
                                   2168 ;	 function rgb_matrix_set_speed_noeeprom
                                   2169 ;	-----------------------------------------
      0055AD                       2170 _rgb_matrix_set_speed_noeeprom:
      0055AD E5 82            [12] 2171 	mov	a,dpl
      0055AF 90 07 34         [24] 2172 	mov	dptr,#_rgb_matrix_set_speed_noeeprom_speed_10000_365
      0055B2 F0               [24] 2173 	movx	@dptr,a
      0055B3 E0               [24] 2174 	movx	a,@dptr
      0055B4 90 06 AF         [24] 2175 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      0055B7 F0               [24] 2176 	movx	@dptr,a
      0055B8 22               [24] 2177 	ret
                                   2178 ;------------------------------------------------------------
                                   2179 ;Allocation info for local variables in function 'rgb_matrix_set_flags_noeeprom'
                                   2180 ;------------------------------------------------------------
                                   2181 ;flags         Allocated with name '_rgb_matrix_set_flags_noeeprom_flags_10000_367'
                                   2182 ;------------------------------------------------------------
                                   2183 ;	keyboards/ajazz/ak820/ak820_rgb.c:278: void rgb_matrix_set_flags_noeeprom(led_flags_t flags) { rgb_matrix_config.flags = flags; }
                                   2184 ;	-----------------------------------------
                                   2185 ;	 function rgb_matrix_increase_hue_noeeprom
                                   2186 ;	-----------------------------------------
      0055B9                       2187 _rgb_matrix_increase_hue_noeeprom:
      0055B9 90 06 AC         [24] 2188 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055BC E0               [24] 2189 	movx	a,@dptr
      0055BD 24 08            [12] 2190 	add	a,#0x08
      0055BF 90 06 AC         [24] 2191 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055C2 F0               [24] 2192 	movx	@dptr,a
      0055C3 22               [24] 2193 	ret
                                   2194 ;------------------------------------------------------------
                                   2195 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue_noeeprom'
                                   2196 ;------------------------------------------------------------
                                   2197 ;	keyboards/ajazz/ak820/ak820_rgb.c:281: void rgb_matrix_decrease_hue_noeeprom(void) { rgb_matrix_config.hsv.h -= 8; }
                                   2198 ;	-----------------------------------------
                                   2199 ;	 function rgb_matrix_decrease_hue_noeeprom
                                   2200 ;	-----------------------------------------
      0055C4                       2201 _rgb_matrix_decrease_hue_noeeprom:
      0055C4 90 06 AC         [24] 2202 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055C7 E0               [24] 2203 	movx	a,@dptr
      0055C8 24 F8            [12] 2204 	add	a,#0xf8
      0055CA 90 06 AC         [24] 2205 	mov	dptr,#(_rgb_matrix_config + 0x0001)
      0055CD F0               [24] 2206 	movx	@dptr,a
      0055CE 22               [24] 2207 	ret
                                   2208 ;------------------------------------------------------------
                                   2209 ;Allocation info for local variables in function 'rgb_matrix_increase_sat_noeeprom'
                                   2210 ;------------------------------------------------------------
                                   2211 ;	keyboards/ajazz/ak820/ak820_rgb.c:282: void rgb_matrix_increase_sat_noeeprom(void) { rgb_matrix_config.hsv.s = add_sat(rgb_matrix_config.hsv.s, 16); }
                                   2212 ;	-----------------------------------------
                                   2213 ;	 function rgb_matrix_increase_sat_noeeprom
                                   2214 ;	-----------------------------------------
      0055CF                       2215 _rgb_matrix_increase_sat_noeeprom:
      0055CF 90 06 AD         [24] 2216 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0055D2 12 56 81         [24] 2217 	lcall	_ak820_outline_0048
      0055D5 12 4F C4         [24] 2218 	lcall	_add_sat
      0055D8 AF 82            [24] 2219 	mov	r7, dpl
      0055DA 90 06 AD         [24] 2220 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0055DD EF               [12] 2221 	mov	a,r7
      0055DE F0               [24] 2222 	movx	@dptr,a
      0055DF 22               [24] 2223 	ret
                                   2224 ;------------------------------------------------------------
                                   2225 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat_noeeprom'
                                   2226 ;------------------------------------------------------------
                                   2227 ;	keyboards/ajazz/ak820/ak820_rgb.c:283: void rgb_matrix_decrease_sat_noeeprom(void) { rgb_matrix_config.hsv.s = sub_sat(rgb_matrix_config.hsv.s, 16); }
                                   2228 ;	-----------------------------------------
                                   2229 ;	 function rgb_matrix_decrease_sat_noeeprom
                                   2230 ;	-----------------------------------------
      0055E0                       2231 _rgb_matrix_decrease_sat_noeeprom:
      0055E0 90 06 AD         [24] 2232 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0055E3 12 56 8C         [24] 2233 	lcall	_ak820_outline_0049
      0055E6 12 4F E9         [24] 2234 	lcall	_sub_sat
      0055E9 AF 82            [24] 2235 	mov	r7, dpl
      0055EB 90 06 AD         [24] 2236 	mov	dptr,#(_rgb_matrix_config + 0x0002)
      0055EE EF               [12] 2237 	mov	a,r7
      0055EF F0               [24] 2238 	movx	@dptr,a
      0055F0 22               [24] 2239 	ret
                                   2240 ;------------------------------------------------------------
                                   2241 ;Allocation info for local variables in function 'rgb_matrix_increase_val_noeeprom'
                                   2242 ;------------------------------------------------------------
                                   2243 ;val           Allocated with name '_rgb_matrix_increase_val_noeeprom_val_10000_378'
                                   2244 ;------------------------------------------------------------
                                   2245 ;	keyboards/ajazz/ak820/ak820_rgb.c:284: void rgb_matrix_increase_val_noeeprom(void) {
                                   2246 ;	-----------------------------------------
                                   2247 ;	 function rgb_matrix_increase_val_noeeprom
                                   2248 ;	-----------------------------------------
      0055F1                       2249 _rgb_matrix_increase_val_noeeprom:
                                   2250 ;	keyboards/ajazz/ak820/ak820_rgb.c:285: uint8_t val = add_sat(rgb_matrix_config.hsv.v, 16);
      0055F1 90 06 AE         [24] 2251 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      0055F4 12 56 81         [24] 2252 	lcall	_ak820_outline_0048
      0055F7 12 4F C4         [24] 2253 	lcall	_add_sat
                                   2254 ;	keyboards/ajazz/ak820/ak820_rgb.c:286: rgb_matrix_config.hsv.v = val > RGB_MATRIX_MAXIMUM_BRIGHTNESS ? RGB_MATRIX_MAXIMUM_BRIGHTNESS : val;
      0055FA E5 82            [12] 2255 	mov	a,dpl
      0055FC FF               [12] 2256 	mov	r7,a
      0055FD 24 5F            [12] 2257 	add	a,#0xff - 0xa0
      0055FF 50 04            [24] 2258 	jnc	00103$
                                   2259 ;	free result
      005601 7E A0            [12] 2260 	mov	r6,#0xa0
      005603 80 02            [24] 2261 	sjmp	00104$
      005605                       2262 00103$:
      005605 8F 06            [24] 2263 	mov	ar6,r7
      005607                       2264 00104$:
      005607 90 06 AE         [24] 2265 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00560A EE               [12] 2266 	mov	a,r6
      00560B F0               [24] 2267 	movx	@dptr,a
                                   2268 ;	keyboards/ajazz/ak820/ak820_rgb.c:287: }
      00560C 22               [24] 2269 	ret
                                   2270 ;------------------------------------------------------------
                                   2271 ;Allocation info for local variables in function 'rgb_matrix_decrease_val_noeeprom'
                                   2272 ;------------------------------------------------------------
                                   2273 ;	keyboards/ajazz/ak820/ak820_rgb.c:288: void rgb_matrix_decrease_val_noeeprom(void) { rgb_matrix_config.hsv.v = sub_sat(rgb_matrix_config.hsv.v, 16); }
                                   2274 ;	-----------------------------------------
                                   2275 ;	 function rgb_matrix_decrease_val_noeeprom
                                   2276 ;	-----------------------------------------
      00560D                       2277 _rgb_matrix_decrease_val_noeeprom:
      00560D 90 06 AE         [24] 2278 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      005610 12 56 8C         [24] 2279 	lcall	_ak820_outline_0049
      005613 12 4F E9         [24] 2280 	lcall	_sub_sat
      005616 AF 82            [24] 2281 	mov	r7, dpl
      005618 90 06 AE         [24] 2282 	mov	dptr,#(_rgb_matrix_config + 0x0003)
      00561B EF               [12] 2283 	mov	a,r7
      00561C F0               [24] 2284 	movx	@dptr,a
      00561D 22               [24] 2285 	ret
                                   2286 ;------------------------------------------------------------
                                   2287 ;Allocation info for local variables in function 'rgb_matrix_increase_speed_noeeprom'
                                   2288 ;------------------------------------------------------------
                                   2289 ;	keyboards/ajazz/ak820/ak820_rgb.c:289: void rgb_matrix_increase_speed_noeeprom(void) { rgb_matrix_config.speed = add_sat(rgb_matrix_config.speed, 16); }
                                   2290 ;	-----------------------------------------
                                   2291 ;	 function rgb_matrix_increase_speed_noeeprom
                                   2292 ;	-----------------------------------------
      00561E                       2293 _rgb_matrix_increase_speed_noeeprom:
      00561E 90 06 AF         [24] 2294 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005621 12 56 81         [24] 2295 	lcall	_ak820_outline_0048
      005624 12 4F C4         [24] 2296 	lcall	_add_sat
      005627 AF 82            [24] 2297 	mov	r7, dpl
      005629 90 06 AF         [24] 2298 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00562C EF               [12] 2299 	mov	a,r7
      00562D F0               [24] 2300 	movx	@dptr,a
      00562E 22               [24] 2301 	ret
                                   2302 ;------------------------------------------------------------
                                   2303 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed_noeeprom'
                                   2304 ;------------------------------------------------------------
                                   2305 ;	keyboards/ajazz/ak820/ak820_rgb.c:290: void rgb_matrix_decrease_speed_noeeprom(void) { rgb_matrix_config.speed = sub_sat(rgb_matrix_config.speed, 16); }
                                   2306 ;	-----------------------------------------
                                   2307 ;	 function rgb_matrix_decrease_speed_noeeprom
                                   2308 ;	-----------------------------------------
      00562F                       2309 _rgb_matrix_decrease_speed_noeeprom:
      00562F 90 06 AF         [24] 2310 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      005632 12 56 8C         [24] 2311 	lcall	_ak820_outline_0049
      005635 12 4F E9         [24] 2312 	lcall	_sub_sat
      005638 AF 82            [24] 2313 	mov	r7, dpl
      00563A 90 06 AF         [24] 2314 	mov	dptr,#(_rgb_matrix_config + 0x0004)
      00563D EF               [12] 2315 	mov	a,r7
      00563E F0               [24] 2316 	movx	@dptr,a
      00563F 22               [24] 2317 	ret
                                   2318 ;------------------------------------------------------------
                                   2319 ;Allocation info for local variables in function 'rgb_matrix_toggle'
                                   2320 ;------------------------------------------------------------
                                   2321 ;	keyboards/ajazz/ak820/ak820_rgb.c:293: PERSIST_WRAPPER(rgb_matrix_toggle)
                                   2322 ;	-----------------------------------------
                                   2323 ;	 function rgb_matrix_toggle
                                   2324 ;	-----------------------------------------
      005640                       2325 _rgb_matrix_toggle:
      005640 91 E8            [12] 2326 	acall	_rgb_matrix_toggle_noeeprom
      005642 01 06            [12] 2327 	ajmp	_mark_dirty
                                   2328 ;------------------------------------------------------------
                                   2329 ;Allocation info for local variables in function 'rgb_matrix_enable'
                                   2330 ;------------------------------------------------------------
                                   2331 ;	keyboards/ajazz/ak820/ak820_rgb.c:294: PERSIST_WRAPPER(rgb_matrix_enable)
                                   2332 ;	-----------------------------------------
                                   2333 ;	 function rgb_matrix_step
                                   2334 ;	-----------------------------------------
      005644                       2335 _rgb_matrix_step:
      005644 B1 51            [12] 2336 	acall	_rgb_matrix_step_noeeprom
      005646 01 06            [12] 2337 	ajmp	_mark_dirty
                                   2338 ;------------------------------------------------------------
                                   2339 ;Allocation info for local variables in function 'rgb_matrix_step_reverse'
                                   2340 ;------------------------------------------------------------
                                   2341 ;	keyboards/ajazz/ak820/ak820_rgb.c:297: PERSIST_WRAPPER(rgb_matrix_step_reverse)
                                   2342 ;	-----------------------------------------
                                   2343 ;	 function rgb_matrix_step_reverse
                                   2344 ;	-----------------------------------------
      005648                       2345 _rgb_matrix_step_reverse:
      005648 B1 6A            [12] 2346 	acall	_rgb_matrix_step_reverse_noeeprom
      00564A 01 06            [12] 2347 	ajmp	_mark_dirty
                                   2348 ;------------------------------------------------------------
                                   2349 ;Allocation info for local variables in function 'rgb_matrix_increase_hue'
                                   2350 ;------------------------------------------------------------
                                   2351 ;	keyboards/ajazz/ak820/ak820_rgb.c:298: PERSIST_WRAPPER(rgb_matrix_increase_hue)
                                   2352 ;	-----------------------------------------
                                   2353 ;	 function rgb_matrix_increase_hue
                                   2354 ;	-----------------------------------------
      00564C                       2355 _rgb_matrix_increase_hue:
      00564C B1 B9            [12] 2356 	acall	_rgb_matrix_increase_hue_noeeprom
      00564E 01 06            [12] 2357 	ajmp	_mark_dirty
                                   2358 ;------------------------------------------------------------
                                   2359 ;Allocation info for local variables in function 'rgb_matrix_decrease_hue'
                                   2360 ;------------------------------------------------------------
                                   2361 ;	keyboards/ajazz/ak820/ak820_rgb.c:299: PERSIST_WRAPPER(rgb_matrix_decrease_hue)
                                   2362 ;	-----------------------------------------
                                   2363 ;	 function rgb_matrix_decrease_hue
                                   2364 ;	-----------------------------------------
      005650                       2365 _rgb_matrix_decrease_hue:
      005650 B1 C4            [12] 2366 	acall	_rgb_matrix_decrease_hue_noeeprom
      005652 01 06            [12] 2367 	ajmp	_mark_dirty
                                   2368 ;------------------------------------------------------------
                                   2369 ;Allocation info for local variables in function 'rgb_matrix_increase_sat'
                                   2370 ;------------------------------------------------------------
                                   2371 ;	keyboards/ajazz/ak820/ak820_rgb.c:300: PERSIST_WRAPPER(rgb_matrix_increase_sat)
                                   2372 ;	-----------------------------------------
                                   2373 ;	 function rgb_matrix_increase_sat
                                   2374 ;	-----------------------------------------
      005654                       2375 _rgb_matrix_increase_sat:
      005654 B1 CF            [12] 2376 	acall	_rgb_matrix_increase_sat_noeeprom
      005656 01 06            [12] 2377 	ajmp	_mark_dirty
                                   2378 ;------------------------------------------------------------
                                   2379 ;Allocation info for local variables in function 'rgb_matrix_decrease_sat'
                                   2380 ;------------------------------------------------------------
                                   2381 ;	keyboards/ajazz/ak820/ak820_rgb.c:301: PERSIST_WRAPPER(rgb_matrix_decrease_sat)
                                   2382 ;	-----------------------------------------
                                   2383 ;	 function rgb_matrix_decrease_sat
                                   2384 ;	-----------------------------------------
      005658                       2385 _rgb_matrix_decrease_sat:
      005658 B1 E0            [12] 2386 	acall	_rgb_matrix_decrease_sat_noeeprom
      00565A 01 06            [12] 2387 	ajmp	_mark_dirty
                                   2388 ;------------------------------------------------------------
                                   2389 ;Allocation info for local variables in function 'rgb_matrix_increase_val'
                                   2390 ;------------------------------------------------------------
                                   2391 ;	keyboards/ajazz/ak820/ak820_rgb.c:302: PERSIST_WRAPPER(rgb_matrix_increase_val)
                                   2392 ;	-----------------------------------------
                                   2393 ;	 function rgb_matrix_increase_val
                                   2394 ;	-----------------------------------------
      00565C                       2395 _rgb_matrix_increase_val:
      00565C B1 F1            [12] 2396 	acall	_rgb_matrix_increase_val_noeeprom
      00565E 01 06            [12] 2397 	ajmp	_mark_dirty
                                   2398 ;------------------------------------------------------------
                                   2399 ;Allocation info for local variables in function 'rgb_matrix_decrease_val'
                                   2400 ;------------------------------------------------------------
                                   2401 ;	keyboards/ajazz/ak820/ak820_rgb.c:303: PERSIST_WRAPPER(rgb_matrix_decrease_val)
                                   2402 ;	-----------------------------------------
                                   2403 ;	 function rgb_matrix_decrease_val
                                   2404 ;	-----------------------------------------
      005660                       2405 _rgb_matrix_decrease_val:
      005660 D1 0D            [12] 2406 	acall	_rgb_matrix_decrease_val_noeeprom
      005662 01 06            [12] 2407 	ajmp	_mark_dirty
                                   2408 ;------------------------------------------------------------
                                   2409 ;Allocation info for local variables in function 'rgb_matrix_increase_speed'
                                   2410 ;------------------------------------------------------------
                                   2411 ;	keyboards/ajazz/ak820/ak820_rgb.c:304: PERSIST_WRAPPER(rgb_matrix_increase_speed)
                                   2412 ;	-----------------------------------------
                                   2413 ;	 function rgb_matrix_increase_speed
                                   2414 ;	-----------------------------------------
      005664                       2415 _rgb_matrix_increase_speed:
      005664 D1 1E            [12] 2416 	acall	_rgb_matrix_increase_speed_noeeprom
      005666 01 06            [12] 2417 	ajmp	_mark_dirty
                                   2418 ;------------------------------------------------------------
                                   2419 ;Allocation info for local variables in function 'rgb_matrix_decrease_speed'
                                   2420 ;------------------------------------------------------------
                                   2421 ;	keyboards/ajazz/ak820/ak820_rgb.c:305: PERSIST_WRAPPER(rgb_matrix_decrease_speed)
                                   2422 ;	-----------------------------------------
                                   2423 ;	 function rgb_matrix_decrease_speed
                                   2424 ;	-----------------------------------------
      005668                       2425 _rgb_matrix_decrease_speed:
      005668 D1 2F            [12] 2426 	acall	_rgb_matrix_decrease_speed_noeeprom
      00566A 01 06            [12] 2427 	ajmp	_mark_dirty
                                   2428 ;------------------------------------------------------------
                                   2429 ;Allocation info for local variables in function 'rgb_matrix_mode'
                                   2430 ;------------------------------------------------------------
                                   2431 ;mode          Allocated with name '_rgb_matrix_mode_mode_10000_411'
                                   2432 ;------------------------------------------------------------
                                   2433 ;	keyboards/ajazz/ak820/ak820_rgb.c:308: void rgb_matrix_mode(uint8_t mode) { rgb_matrix_mode_noeeprom(mode); mark_dirty(); }
                                   2434 ;	-----------------------------------------
                                   2435 ;	 function rgb_matrix_mode
                                   2436 ;	-----------------------------------------
      00566C                       2437 _rgb_matrix_mode:
      00566C E5 82            [12] 2438 	mov	a,dpl
      00566E 90 07 35         [24] 2439 	mov	dptr,#_rgb_matrix_mode_mode_10000_411
      005671 12 56 DA         [24] 2440 	lcall	_ak820_outline_0170
      005674 B1 1C            [12] 2441 	acall	_rgb_matrix_mode_noeeprom
      005676 01 06            [12] 2442 	ajmp	_mark_dirty
                                   2443 ;------------------------------------------------------------
                                   2444 ;Allocation info for local variables in function 'rgb_matrix_sethsv'
                                   2445 ;------------------------------------------------------------
                                   2446 ;sat           Allocated with name '_rgb_matrix_sethsv_PARM_2'
                                   2447 ;val           Allocated with name '_rgb_matrix_sethsv_PARM_3'
                                   2448 ;hue           Allocated with name '_rgb_matrix_sethsv_hue_10000_413'
                                   2449 ;------------------------------------------------------------
                                   2450 ;	keyboards/ajazz/ak820/ak820_rgb.c:309: void rgb_matrix_sethsv(uint16_t hue, uint8_t sat, uint8_t val) { rgb_matrix_sethsv_noeeprom(hue, sat, val); mark_dirty(); }
                                   2451 ;	-----------------------------------------
                                   2452 	.area CSEG    (CODE)
                                   2453 	.area CONST   (CODE)
                                   2454 	.area CONST   (CODE)
      00B7EF                       2455 _sine8_coefficients_10000_290:
      00B7EF 00                    2456 	.db #0x00	; 0
      00B7F0 31                    2457 	.db #0x31	; 49	'1'
      00B7F1 31                    2458 	.db #0x31	; 49	'1'
      00B7F2 29                    2459 	.db #0x29	; 41
      00B7F3 5A                    2460 	.db #0x5a	; 90	'Z'
      00B7F4 1B                    2461 	.db #0x1b	; 27
      00B7F5 75                    2462 	.db #0x75	; 117	'u'
      00B7F6 0A                    2463 	.db #0x0a	; 10
                                   2464 	.area CSEG    (CODE)
                                   2465 	.area XINIT   (CODE)
                                   2466 	.area CABS    (ABS,CODE)
                                   2467 
                                   2468 ; Experimental exact instruction outlining.
                                   2469 	.globl _ak820_outline_0005
                                   2470 	.globl _ak820_outline_0019
                                   2471 	.globl _ak820_outline_0048
                                   2472 	.globl _ak820_outline_0049
                                   2473 	.globl _ak820_outline_0051
                                   2474 	.globl _ak820_outline_0058
                                   2475 	.globl _ak820_outline_0059
                                   2476 	.globl _ak820_outline_0065
                                   2477 	.globl _ak820_outline_0069
                                   2478 	.globl _ak820_outline_0073
                                   2479 	.globl _ak820_outline_0086
                                   2480 	.globl _ak820_outline_0101
                                   2481 	.globl _ak820_outline_0103
                                   2482 	.globl _ak820_outline_0107
                                   2483 	.globl _ak820_outline_0108
                                   2484 	.globl _ak820_outline_0109
                                   2485 	.globl _ak820_outline_0115
                                   2486 	.globl _ak820_outline_0124
                                   2487 	.globl _ak820_outline_0133
                                   2488 	.globl _ak820_outline_0134
                                   2489 	.globl _ak820_outline_0135
                                   2490 	.globl _ak820_outline_0138
                                   2491 	.globl _ak820_outline_0140
                                   2492 	.globl _ak820_outline_0156
                                   2493 	.globl _ak820_outline_0169
                                   2494 	.globl _ak820_outline_0170
                                   2495 	.globl _ak820_outline_0173
                                   2496 	.globl _ak820_outline_0179
                                   2497 	.globl _ak820_outline_0186
                                   2498 	.globl _ak820_outline_0188
                                   2499 	.globl _ak820_outline_0190
                                   2500 
                                   2501 	.area CSEG (CODE)
                                   2502 ; function ak820_outline_0019
      005678                       2503 _ak820_outline_0019:
      005678 90 06 AB         [24] 2504 	mov	dptr,#_rgb_matrix_config
      00567B E0               [24] 2505 	movx	a,@dptr
      00567C 03               [12] 2506 	rr	a
      00567D 03               [12] 2507 	rr	a
      00567E 54 3F            [12] 2508 	anl	a,#0x3f
      005680 22               [24] 2509 	ret
                                   2510 
                                   2511 	.area CSEG (CODE)
                                   2512 ; function ak820_outline_0048
      005681                       2513 _ak820_outline_0048:
      005681 E0               [24] 2514 	movx	a,@dptr
      005682 FF               [12] 2515 	mov	r7,a
      005683 90 07 14         [24] 2516 	mov	dptr,#_add_sat_PARM_2
      005686 74 10            [12] 2517 	mov	a,#0x10
      005688 F0               [24] 2518 	movx	@dptr,a
      005689 8F 82            [24] 2519 	mov	dpl,r7
      00568B 22               [24] 2520 	ret
                                   2521 
                                   2522 	.area CSEG (CODE)
                                   2523 ; function ak820_outline_0049
      00568C                       2524 _ak820_outline_0049:
      00568C E0               [24] 2525 	movx	a,@dptr
      00568D FF               [12] 2526 	mov	r7,a
      00568E 90 07 16         [24] 2527 	mov	dptr,#_sub_sat_PARM_2
      005691 74 10            [12] 2528 	mov	a,#0x10
      005693 F0               [24] 2529 	movx	@dptr,a
      005694 8F 82            [24] 2530 	mov	dpl,r7
      005696 22               [24] 2531 	ret
                                   2532 
                                   2533 	.area CSEG (CODE)
                                   2534 ; function ak820_outline_0065
      005697                       2535 _ak820_outline_0065:
      005697 90 06 AB         [24] 2536 	mov	dptr,#_rgb_matrix_config
      00569A E0               [24] 2537 	movx	a,@dptr
      00569B 54 03            [12] 2538 	anl	a,#0x03
      00569D 22               [24] 2539 	ret
                                   2540 
                                   2541 	.area CSEG (CODE)
                                   2542 ; function ak820_outline_0069
      00569E                       2543 _ak820_outline_0069:
      00569E 74 08            [12] 2544 	mov	a,#0x08
      0056A0 F0               [24] 2545 	movx	@dptr,a
      0056A1 E4               [12] 2546 	clr	a
      0056A2 A3               [24] 2547 	inc	dptr
      0056A3 F0               [24] 2548 	movx	@dptr,a
      0056A4 90 06 AB         [24] 2549 	mov	dptr,#_rgb_matrix_config
      0056A7 22               [24] 2550 	ret
                                   2551 
                                   2552 	.area CSEG (CODE)
                                   2553 ; function ak820_outline_0073
      0056A8                       2554 _ak820_outline_0073:
      0056A8 A3               [24] 2555 	inc	dptr
      0056A9 F0               [24] 2556 	movx	@dptr,a
      0056AA E4               [12] 2557 	clr	a
      0056AB A3               [24] 2558 	inc	dptr
      0056AC F0               [24] 2559 	movx	@dptr,a
      0056AD 90 0D A0         [24] 2560 	mov	dptr,#___memcpy_PARM_3
      0056B0 74 03            [12] 2561 	mov	a,#0x03
      0056B2 F0               [24] 2562 	movx	@dptr,a
      0056B3 E4               [12] 2563 	clr	a
      0056B4 A3               [24] 2564 	inc	dptr
      0056B5 F0               [24] 2565 	movx	@dptr,a
      0056B6 22               [24] 2566 	ret
                                   2567 
                                   2568 	.area CSEG (CODE)
                                   2569 ; function ak820_outline_0086
      0056B7                       2570 _ak820_outline_0086:
      0056B7 74 18            [12] 2571 	mov	a,#0x18
      0056B9 F0               [24] 2572 	movx	@dptr,a
      0056BA E4               [12] 2573 	clr	a
      0056BB A3               [24] 2574 	inc	dptr
      0056BC F0               [24] 2575 	movx	@dptr,a
      0056BD A3               [24] 2576 	inc	dptr
      0056BE F0               [24] 2577 	movx	@dptr,a
      0056BF 22               [24] 2578 	ret
                                   2579 
                                   2580 	.area CSEG (CODE)
                                   2581 ; function ak820_outline_0109
      0056C0                       2582 _ak820_outline_0109:
      0056C0 35 F0            [12] 2583 	addc	a,b
      0056C2 F5 83            [12] 2584 	mov	dph,a
      0056C4 E4               [12] 2585 	clr	a
      0056C5 93               [24] 2586 	movc	a,@a+dptr
      0056C6 22               [24] 2587 	ret
                                   2588 
                                   2589 	.area CSEG (CODE)
                                   2590 ; function ak820_outline_0115
      0056C7                       2591 _ak820_outline_0115:
      0056C7 90 06 AB         [24] 2592 	mov	dptr,#_rgb_matrix_config
      0056CA E0               [24] 2593 	movx	a,@dptr
      0056CB 54 FC            [12] 2594 	anl	a,#0xfc
      0056CD 22               [24] 2595 	ret
                                   2596 
                                   2597 	.area CSEG (CODE)
                                   2598 ; function ak820_outline_0140
      0056CE                       2599 _ak820_outline_0140:
      0056CE 90 06 BA         [24] 2600 	mov	dptr,#_frame_mode
      0056D1 E0               [24] 2601 	movx	a,@dptr
      0056D2 FE               [12] 2602 	mov	r6,a
      0056D3 22               [24] 2603 	ret
                                   2604 
                                   2605 	.area CSEG (CODE)
                                   2606 ; function ak820_outline_0169
      0056D4                       2607 _ak820_outline_0169:
      0056D4 F0               [24] 2608 	movx	@dptr,a
      0056D5 E5 F0            [12] 2609 	mov	a,b
      0056D7 A3               [24] 2610 	inc	dptr
      0056D8 F0               [24] 2611 	movx	@dptr,a
      0056D9 22               [24] 2612 	ret
                                   2613 
                                   2614 	.area CSEG (CODE)
                                   2615 ; function ak820_outline_0170
      0056DA                       2616 _ak820_outline_0170:
      0056DA F0               [24] 2617 	movx	@dptr,a
      0056DB E0               [24] 2618 	movx	a,@dptr
      0056DC F5 82            [12] 2619 	mov	dpl,a
      0056DE 22               [24] 2620 	ret
                                   2621 
                                   2622 	.area CSEG (CODE)
                                   2623 ; function ak820_outline_0173
      0056DF                       2624 _ak820_outline_0173:
      0056DF 90 06 AF         [24] 2625 	mov	dptr,#(_rgb_matrix_config+0x0004)
      0056E2 E0               [24] 2626 	movx	a,@dptr
      0056E3 23               [12] 2627 	rl	a
      0056E4 23               [12] 2628 	rl	a
      0056E5 54 03            [12] 2629 	anl	a,#0x03
      0056E7 22               [24] 2630 	ret
                                   2631 
                                   2632 	.area CSEG (CODE)
                                   2633 ; function ak820_outline_0179
      0056E8                       2634 _ak820_outline_0179:
      0056E8 90 0D A5         [24] 2635 	mov	dptr,#_memset_PARM_2
      0056EB E4               [12] 2636 	clr	a
      0056EC F0               [24] 2637 	movx	@dptr,a
      0056ED 90 0D A6         [24] 2638 	mov	dptr,#_memset_PARM_3
      0056F0 22               [24] 2639 	ret
                                   2640 
                                   2641 	.area CSEG (CODE)
                                   2642 ; function ak820_outline_0186
      0056F1                       2643 _ak820_outline_0186:
      0056F1 90 06 B9         [24] 2644 	mov	dptr,#_led_index
      0056F4 E0               [24] 2645 	movx	a,@dptr
      0056F5 22               [24] 2646 	ret
                                   2647 
                                   2648 	.area CSEG (CODE)
                                   2649 ; function ak820_outline_0188
      0056F6                       2650 _ak820_outline_0188:
      0056F6 C4               [12] 2651 	swap	a
      0056F7 23               [12] 2652 	rl	a
      0056F8 54 1F            [12] 2653 	anl	a,#0x1f
      0056FA 22               [24] 2654 	ret
