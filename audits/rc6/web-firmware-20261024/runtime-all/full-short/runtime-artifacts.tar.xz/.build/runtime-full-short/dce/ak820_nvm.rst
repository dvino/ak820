                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00051D                        109 _page_data:
      00051D                        110 	.ds 64
      00055D                        111 _cached_page:
      00055D                        112 	.ds 1
      00055E                        113 _batch_depth:
      00055E                        114 	.ds 1
      00055F                        115 _first_failure_stage:
      00055F                        116 	.ds 1
      000560                        117 _nvm_fail_stage_10000_20:
      000560                        118 	.ds 1
      000561                        119 _ak820_nvm_diagnostic_out_10000_23:
      000561                        120 	.ds 2
      000563                        121 _crc_byte_PARM_2:
      000563                        122 	.ds 1
      000564                        123 _crc_byte_crc_10000_25:
      000564                        124 	.ds 2
      000566                        125 _page_crc_crc_10000_30:
      000566                        126 	.ds 2
      000568                        127 _write_page_address_10000_32:
      000568                        128 	.ds 2
      00056A                        129 _journal_header_valid_header_10000_39:
      00056A                        130 	.ds 2
      00056C                        131 _recover_journal_header_10000_46:
      00056C                        132 	.ds 9
      000575                        133 _ak820_nvm_flush_header_10000_62:
      000575                        134 	.ds 9
      00057E                        135 _ak820_nvm_flush_stage_10000_62:
      00057E                        136 	.ds 1
      00057F                        137 _load_page_page_10000_87:
      00057F                        138 	.ds 1
      000580                        139 _read_offset_offset_10000_93:
      000580                        140 	.ds 2
      000582                        141 _eeprom_read_byte_addr_10000_97:
      000582                        142 	.ds 3
      000585                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000585                        144 	.ds 3
      000588                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000588                        146 	.ds 2
      00058A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00058A                        148 	.ds 2
      00058C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00058C                        150 	.ds 2
      00058E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058E                        152 	.ds 3
      000591                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      000591                        154 	.ds 2
      000593                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000593                        156 	.ds 2
      000595                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000595                        158 	.ds 3
      000598                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000598                        160 	.ds 2
      00059A                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      00059A                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B76                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B76 E5 82            [12]  215 	mov	a,dpl
      003B78 90 05 60         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B7B F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B7C 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003B7F 90 05 60         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B82 E0               [24]  221 	movx	a,@dptr
      003B83 90 05 5F         [24]  222 	mov	dptr,#_first_failure_stage
      003B86 F0               [24]  223 	movx	@dptr,a
      003B87                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B87 D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B89 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B8A                        239 _ak820_nvm_diagnostic:
      003B8A 12 38 75         [24]  240 	lcall	_ak820_outline_0107
      003B8D 90 05 61         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B90 12 38 7A         [24]  242 	lcall	_ak820_outline_0108
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003B93 90 05 61         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B96 12 38 34         [24]  245 	lcall	_ak820_outline_0051
      003B99 A2 0B            [12]  246 	mov	c,_storage_failed
      003B9B E4               [12]  247 	clr	a
      003B9C 33               [12]  248 	rlc	a
      003B9D 12 38 7F         [24]  249 	lcall	_ak820_outline_0118
      003BA0 12 43 31         [24]  250 	lcall	_ak820_outline_0071
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BA3 A3               [24]  252 	inc	dptr
      003BA4 A2 09            [12]  253 	mov	c,_page_valid
      003BA6 E4               [12]  254 	clr	a
      003BA7 33               [12]  255 	rlc	a
      003BA8 12 42 FE         [24]  256 	lcall	_ak820_outline_0031
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BAB A2 0A            [12]  258 	mov	c,_page_dirty
      003BAD E4               [12]  259 	clr	a
      003BAE 33               [12]  260 	rlc	a
      003BAF F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BB0 74 03            [12]  263 	mov	a,#0x03
      003BB2 12 43 6A         [24]  264 	lcall	_ak820_outline_0161
      003BB5 90 05 5E         [24]  265 	mov	dptr,#_batch_depth
      003BB8 E0               [24]  266 	movx	a,@dptr
      003BB9 12 38 8A         [24]  267 	lcall	_ak820_outline_0124
      003BBC F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003BBD 74 04            [12]  270 	mov	a,#0x04
      003BBF 12 43 6A         [24]  271 	lcall	_ak820_outline_0161
      003BC2 90 05 5D         [24]  272 	mov	dptr,#_cached_page
      003BC5 E0               [24]  273 	movx	a,@dptr
      003BC6 12 38 8A         [24]  274 	lcall	_ak820_outline_0124
      003BC9 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003BCA 12 42 F4         [24]  277 	lcall	_ak820_outline_0011
      003BCD E4               [12]  278 	clr	a
      003BCE F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003BCF 74 06            [12]  281 	mov	a,#0x06
      003BD1 12 43 54         [24]  282 	lcall	_ak820_outline_0137
      003BD4 90 05 5F         [24]  283 	mov	dptr,#_first_failure_stage
      003BD7 E0               [24]  284 	movx	a,@dptr
      003BD8 12 38 7F         [24]  285 	lcall	_ak820_outline_0118
      003BDB F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BDC 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003BDD                        300 _crc_byte:
      003BDD 12 38 75         [24]  301 	lcall	_ak820_outline_0107
      003BE0 90 05 64         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003BE3 12 38 7A         [24]  303 	lcall	_ak820_outline_0108
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BE6 90 05 63         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003BE9 E0               [24]  306 	movx	a,@dptr
      003BEA FF               [12]  307 	mov	r7,a
      003BEB 7E 00            [12]  308 	mov	r6,#0x00
      003BED 90 05 64         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003BF0 E0               [24]  310 	movx	a,@dptr
      003BF1 6E               [12]  311 	xrl	a,r6
      003BF2 F0               [24]  312 	movx	@dptr,a
      003BF3 A3               [24]  313 	inc	dptr
      003BF4 E0               [24]  314 	movx	a,@dptr
      003BF5 6F               [12]  315 	xrl	a,r7
      003BF6 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BF7 7F 00            [12]  318 	mov	r7,#0x00
      003BF9                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003BF9 90 05 64         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003BFC 12 38 57         [24]  322 	lcall	_ak820_outline_0079
      003BFF 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003C02 ED               [12]  324 	mov	a,r5
      003C03 2D               [12]  325 	add	a,r5
      003C04 FB               [12]  326 	mov	r3,a
      003C05 EE               [12]  327 	mov	a,r6
      003C06 33               [12]  328 	rlc	a
      003C07 FC               [12]  329 	mov	r4,a
      003C08 63 03 21         [24]  330 	xrl	ar3,#0x21
      003C0B 63 04 10         [24]  331 	xrl	ar4,#0x10
      003C0E 80 06            [24]  332 	sjmp	00107$
      003C10                        333 00106$:
      003C10 ED               [12]  334 	mov	a,r5
      003C11 2D               [12]  335 	add	a,r5
      003C12 FB               [12]  336 	mov	r3,a
      003C13 EE               [12]  337 	mov	a,r6
      003C14 33               [12]  338 	rlc	a
      003C15 FC               [12]  339 	mov	r4,a
      003C16                        340 00107$:
      003C16 90 05 64         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003C19 12 38 5D         [24]  342 	lcall	_ak820_outline_0085
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C1C 0F               [12]  344 	inc	r7
      003C1D BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C20 12 33 FC         [24]  347 	lcall	_ak820_outline_0123
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C23 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003C24                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C24 90 05 66         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003C27 74 FF            [12]  363 	mov	a,#0xff
      003C29 F0               [24]  364 	movx	@dptr,a
      003C2A A3               [24]  365 	inc	dptr
      003C2B F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C2C 7F 00            [12]  368 	mov	r7,#0x00
      003C2E                        369 00102$:
      003C2E 90 05 66         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003C31 12 38 57         [24]  371 	lcall	_ak820_outline_0079
      003C34 12 43 43         [24]  372 	lcall	_ak820_outline_0105
      003C37 90 05 63         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003C3A F0               [24]  374 	movx	@dptr,a
      003C3B 12 38 94         [24]  375 	lcall	_ak820_outline_0135
      003C3E C0 07            [24]  376 	push	ar7
      003C40 12 3B DD         [24]  377 	lcall	_crc_byte
      003C43 AD 82            [24]  378 	mov	r5, dpl
      003C45 AE 83            [24]  379 	mov	r6, dph
      003C47 D0 07            [24]  380 	pop	ar7
      003C49 90 05 66         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003C4C 12 43 70         [24]  382 	lcall	_ak820_outline_0162
      003C4F 0F               [12]  383 	inc	r7
      003C50 BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C53 12 38 94         [24]  386 	lcall	_ak820_outline_0135
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C56 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003C57                        399 _write_page:
      003C57 12 38 75         [24]  400 	lcall	_ak820_outline_0107
      003C5A 90 05 68         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003C5D 12 38 7A         [24]  402 	lcall	_ak820_outline_0108
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C60 90 05 68         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003C63 12 37 E7         [24]  405 	lcall	_ak820_outline_0005
      003C66 C0 07            [24]  406 	push	ar7
      003C68 C0 06            [24]  407 	push	ar6
      003C6A 12 39 EF         [24]  408 	lcall	_ak820_flash_erase
      003C6D E5 82            [12]  409 	mov	a, dpl
      003C6F D0 06            [24]  410 	pop	ar6
      003C71 D0 07            [24]  411 	pop	ar7
      003C73 70 03            [24]  412 	jnz	00102$
      003C75 F5 82            [12]  413 	mov	dpl,a
      003C77 22               [24]  414 	ret
      003C78                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C78 90 04 F9         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C7B 74 1D            [12]  418 	mov	a,#_page_data
      003C7D F0               [24]  419 	movx	@dptr,a
      003C7E 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003C80 A3               [24]  421 	inc	dptr
      003C81 12 43 31         [24]  422 	lcall	_ak820_outline_0071
      003C84 12 3B 03         [24]  423 	lcall	_ak820_flash_program_page
      003C87 E5 82            [12]  424 	mov	a, dpl
      003C89 70 03            [24]  425 	jnz	00120$
      003C8B F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C8D 22               [24]  428 	ret
      003C8E                        429 00120$:
      003C8E 7F 00            [12]  430 	mov	r7,#0x00
      003C90                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C90 8F 05            [24]  433 	mov	ar5,r7
      003C92 7E 00            [12]  434 	mov	r6,#0x00
      003C94 90 05 68         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003C97 12 38 84         [24]  436 	lcall	_ak820_outline_0122
      003C9A ED               [12]  437 	mov	a,r5
      003C9B 2B               [12]  438 	add	a, r3
      003C9C FB               [12]  439 	mov	r3,a
      003C9D EE               [12]  440 	mov	a,r6
      003C9E 3C               [12]  441 	addc	a, r4
      003C9F FC               [12]  442 	mov	r4,a
      003CA0 12 33 FC         [24]  443 	lcall	_ak820_outline_0123
      003CA3 12 38 E2         [24]  444 	lcall	_ak820_flash_read
      003CA6 AE 82            [24]  445 	mov	r6, dpl
      003CA8 12 43 43         [24]  446 	lcall	_ak820_outline_0105
      003CAB FD               [12]  447 	mov	r5,a
      003CAC EE               [12]  448 	mov	a,r6
      003CAD B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003CB0 80 04            [24]  450 	sjmp	00109$
      003CB2                        451 00149$:
      003CB2 75 82 00         [24]  452 	mov	dpl, #0x00
      003CB5 22               [24]  453 	ret
      003CB6                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CB6 0F               [12]  456 	inc	r7
      003CB7 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CBA 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003CBD 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003CBE                        472 _journal_header_valid:
      003CBE 12 38 75         [24]  473 	lcall	_ak820_outline_0107
      003CC1 90 05 6A         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003CC4 12 38 7A         [24]  475 	lcall	_ak820_outline_0108
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003CC7 90 05 6A         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003CCA 12 37 E7         [24]  478 	lcall	_ak820_outline_0005
      003CCD E0               [24]  479 	movx	a,@dptr
      003CCE FD               [12]  480 	mov	r5,a
      003CCF BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003CD2 80 04            [24]  482 	sjmp	00116$
      003CD4                        483 00138$:
      003CD4 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CD7 22               [24]  486 	ret
      003CD8                        487 00116$:
      003CD8 7D 01            [12]  488 	mov	r5,#0x01
      003CDA                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CDA ED               [12]  491 	mov	a,r5
      003CDB 12 38 24         [24]  492 	lcall	_ak820_outline_0022
      003CDE E0               [24]  493 	movx	a,@dptr
      003CDF FC               [12]  494 	mov	r4,a
      003CE0 8D 02            [24]  495 	mov	ar2,r5
      003CE2 7B 00            [12]  496 	mov	r3,#0x00
      003CE4 74 04            [12]  497 	mov	a,#0x04
      003CE6 2A               [12]  498 	add	a, r2
      003CE7 FA               [12]  499 	mov	r2,a
      003CE8 E4               [12]  500 	clr	a
      003CE9 3B               [12]  501 	addc	a, r3
      003CEA FB               [12]  502 	mov	r3,a
      003CEB EA               [12]  503 	mov	a,r2
      003CEC 2E               [12]  504 	add	a, r6
      003CED F5 82            [12]  505 	mov	dpl,a
      003CEF EB               [12]  506 	mov	a,r3
      003CF0 3F               [12]  507 	addc	a, r7
      003CF1 F5 83            [12]  508 	mov	dph,a
      003CF3 E0               [24]  509 	movx	a,@dptr
      003CF4 62 04            [12]  510 	xrl	ar4,a
      003CF6 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003CF9 80 04            [24]  512 	sjmp	00107$
      003CFB                        513 00139$:
      003CFB 75 82 00         [24]  514 	mov	dpl, #0x00
      003CFE 22               [24]  515 	ret
      003CFF                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CFF 0D               [12]  518 	inc	r5
      003D00 BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D03 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D06 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003D07                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D07 7F 00            [12]  538 	mov	r7,#0x00
      003D09                        539 00115$:
      003D09 EF               [12]  540 	mov	a,r7
      003D0A 24 6C            [12]  541 	add	a, #_recover_journal_header_10000_46
      003D0C FD               [12]  542 	mov	r5,a
      003D0D E4               [12]  543 	clr	a
      003D0E 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D10 FE               [12]  545 	mov	r6,a
      003D11 8F 04            [24]  546 	mov	ar4,r7
      003D13 7B 00            [12]  547 	mov	r3,#0x00
      003D15 74 40            [12]  548 	mov	a,#0x40
      003D17 2C               [12]  549 	add	a, r4
      003D18 FC               [12]  550 	mov	r4,a
      003D19 74 EF            [12]  551 	mov	a,#0xef
      003D1B 3B               [12]  552 	addc	a, r3
      003D1C FB               [12]  553 	mov	r3,a
      003D1D 12 43 7B         [24]  554 	lcall	_ak820_outline_0184
      003D20 12 38 E2         [24]  555 	lcall	_ak820_flash_read
      003D23 AC 82            [24]  556 	mov	r4, dpl
      003D25 12 43 2A         [24]  557 	lcall	_ak820_outline_0063
      003D28 0F               [12]  558 	inc	r7
      003D29 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D2C 90 05 6C         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003D2F 12 3C BE         [24]  562 	lcall	_journal_header_valid
      003D32 E5 82            [12]  563 	mov	a, dpl
      003D34 70 01            [24]  564 	jnz	00103$
      003D36 22               [24]  565 	ret
      003D37                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D37 90 05 6D         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D3A E0               [24]  569 	movx	a,@dptr
      003D3B FF               [12]  570 	mov	r7,a
      003D3C 7E 00            [12]  571 	mov	r6,#0x00
      003D3E 90 05 6E         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D41 E0               [24]  573 	movx	a,@dptr
      003D42 FC               [12]  574 	mov	r4,a
      003D43 E4               [12]  575 	clr	a
      003D44 42 07            [12]  576 	orl	ar7,a
      003D46 EC               [12]  577 	mov	a,r4
      003D47 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D49 90 05 6F         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D4C E0               [24]  581 	movx	a,@dptr
      003D4D FD               [12]  582 	mov	r5,a
      003D4E 7C 00            [12]  583 	mov	r4,#0x00
      003D50 90 05 70         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D53 E0               [24]  585 	movx	a,@dptr
      003D54 FA               [12]  586 	mov	r2,a
      003D55 E4               [12]  587 	clr	a
      003D56 12 43 5A         [24]  588 	lcall	_ak820_outline_0142
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D59 C3               [12]  590 	clr	c
      003D5A EF               [12]  591 	mov	a,r7
      003D5B 94 A0            [12]  592 	subb	a,#0xa0
      003D5D EE               [12]  593 	mov	a,r6
      003D5E 94 00            [12]  594 	subb	a,#0x00
      003D60 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D62 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D65 02 3B 76         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D68                        601 00134$:
      003D68 7B 00            [12]  602 	mov	r3,#0x00
      003D6A                        603 00117$:
      003D6A C0 05            [24]  604 	push	ar5
      003D6C C0 04            [24]  605 	push	ar4
      003D6E EB               [12]  606 	mov	a,r3
      003D6F 24 1D            [12]  607 	add	a, #_page_data
      003D71 F9               [12]  608 	mov	r1,a
      003D72 E4               [12]  609 	clr	a
      003D73 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003D75 FA               [12]  611 	mov	r2,a
      003D76 8B 00            [24]  612 	mov	ar0,r3
      003D78 7D 00            [12]  613 	mov	r5,#0x00
      003D7A 74 EF            [12]  614 	mov	a,#0xef
      003D7C 2D               [12]  615 	add	a, r5
      003D7D FD               [12]  616 	mov	r5,a
      003D7E 88 82            [24]  617 	mov	dpl, r0
      003D80 8D 83            [24]  618 	mov	dph, r5
      003D82 12 38 E2         [24]  619 	lcall	_ak820_flash_read
      003D85 AD 82            [24]  620 	mov	r5, dpl
      003D87 12 43 76         [24]  621 	lcall	_ak820_outline_0183
      003D8A ED               [12]  622 	mov	a,r5
      003D8B F0               [24]  623 	movx	@dptr,a
      003D8C 0B               [12]  624 	inc	r3
      003D8D BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      003D90 80 06            [24]  626 	sjmp	00191$
      003D92                        627 00190$:
      003D92 D0 04            [24]  628 	pop	ar4
      003D94 D0 05            [24]  629 	pop	ar5
      003D96 80 D2            [24]  630 	sjmp	00117$
      003D98                        631 00191$:
      003D98 D0 04            [24]  632 	pop	ar4
      003D9A D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003D9C C0 07            [24]  635 	push	ar7
      003D9E C0 06            [24]  636 	push	ar6
      003DA0 C0 05            [24]  637 	push	ar5
      003DA2 C0 04            [24]  638 	push	ar4
      003DA4 12 3C 24         [24]  639 	lcall	_page_crc
      003DA7 AA 82            [24]  640 	mov	r2, dpl
      003DA9 AB 83            [24]  641 	mov	r3, dph
      003DAB D0 04            [24]  642 	pop	ar4
      003DAD D0 05            [24]  643 	pop	ar5
      003DAF D0 06            [24]  644 	pop	ar6
      003DB1 D0 07            [24]  645 	pop	ar7
      003DB3 EA               [12]  646 	mov	a,r2
      003DB4 B5 05 06         [24]  647 	cjne	a,ar5,00192$
      003DB7 EB               [12]  648 	mov	a,r3
      003DB8 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      003DBB 80 06            [24]  650 	sjmp	00113$
      003DBD                        651 00192$:
      003DBD 75 82 02         [24]  652 	mov	dpl, #0x02
      003DC0 02 3B 76         [24]  653 	ljmp	_nvm_fail
      003DC3                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003DC3 EE               [12]  656 	mov	a,r6
      003DC4 54 03            [12]  657 	anl	a,#0x03
      003DC6 A2 E0            [12]  658 	mov	c,acc.0
      003DC8 CF               [12]  659 	xch	a,r7
      003DC9 13               [12]  660 	rrc	a
      003DCA CF               [12]  661 	xch	a,r7
      003DCB 13               [12]  662 	rrc	a
      003DCC A2 E0            [12]  663 	mov	c,acc.0
      003DCE CF               [12]  664 	xch	a,r7
      003DCF 13               [12]  665 	rrc	a
      003DD0 CF               [12]  666 	xch	a,r7
      003DD1 13               [12]  667 	rrc	a
      003DD2 CF               [12]  668 	xch	a,r7
      003DD3 24 C7            [12]  669 	add	a,#0xc7
      003DD5 FE               [12]  670 	mov	r6,a
      003DD6 12 43 65         [24]  671 	lcall	_ak820_outline_0158
      003DD9 12 3C 57         [24]  672 	lcall	_write_page
      003DDC E5 82            [12]  673 	mov	a, dpl
      003DDE 70 06            [24]  674 	jnz	00110$
      003DE0 75 82 03         [24]  675 	mov	dpl, #0x03
      003DE3 02 3B 76         [24]  676 	ljmp	_nvm_fail
      003DE6                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DE6 90 EF 40         [24]  679 	mov	dptr,#0xef40
      003DE9 12 39 EF         [24]  680 	lcall	_ak820_flash_erase
      003DEC E5 82            [12]  681 	mov	a, dpl
      003DEE 70 06            [24]  682 	jnz	00119$
      003DF0 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DF3 02 3B 76         [24]  685 	ljmp	_nvm_fail
      003DF6                        686 00119$:
      003DF6 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      003DF7                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      003DF7 C2 0B            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003DF9 90 05 5F         [24]  700 	mov	dptr,#_first_failure_stage
      003DFC E4               [12]  701 	clr	a
      003DFD F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      003DFE C2 0A            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      003E00 C2 09            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E02 90 05 5E         [24]  709 	mov	dptr,#_batch_depth
      003E05 E4               [12]  710 	clr	a
      003E06 F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E07 12 3D 07         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E0A 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      003E0D                        724 _ak820_nvm_ok:
      003E0D A2 0B            [12]  725 	mov	c,_storage_failed
      003E0F B3               [12]  726 	cpl	c
      003E10 92 0C            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E12 12 38 A4         [24]  728 	lcall	_ak820_outline_0156
      003E15 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      003E16                        737 _ak820_nvm_schema_fault:
      003E16 75 82 10         [24]  738 	mov	dpl, #0x10
      003E19 02 3B 76         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      003E1C                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E1C 30 0A 03         [24]  754 	jnb	_page_dirty,00101$
      003E1F 30 0B 01         [24]  755 	jnb	_storage_failed,00102$
      003E22                        756 00101$:
      003E22 22               [24]  757 	ret
      003E23                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E23 12 3C 24         [24]  760 	lcall	_page_crc
      003E26 12 43 4F         [24]  761 	lcall	_ak820_outline_0133
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E29 90 05 75         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E2C 74 A5            [12]  764 	mov	a,#0xa5
      003E2E F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E2F 90 05 5D         [24]  767 	mov	dptr,#_cached_page
      003E32 E0               [24]  768 	movx	a,@dptr
      003E33 90 05 76         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E36 F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E37 90 05 77         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E3A E4               [12]  773 	clr	a
      003E3B F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E3C 8E 05            [24]  776 	mov	ar5,r6
      003E3E 90 05 78         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E41 ED               [12]  778 	mov	a,r5
      003E42 F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E43 8F 06            [24]  781 	mov	ar6,r7
      003E45 90 05 79         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E48 EE               [12]  783 	mov	a,r6
      003E49 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E4A 7F 01            [12]  786 	mov	r7,#0x01
      003E4C                        787 00128$:
      003E4C 8F 06            [24]  788 	mov	ar6,r7
      003E4E EE               [12]  789 	mov	a,r6
      003E4F 24 04            [12]  790 	add	a,#0x04
      003E51 FE               [12]  791 	mov	r6,a
      003E52 33               [12]  792 	rlc	a
      003E53 95 E0            [12]  793 	subb	a,acc
      003E55 FD               [12]  794 	mov	r5,a
      003E56 EE               [12]  795 	mov	a,r6
      003E57 24 75            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      003E59 FE               [12]  797 	mov	r6,a
      003E5A ED               [12]  798 	mov	a,r5
      003E5B 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E5D FD               [12]  800 	mov	r5,a
      003E5E 12 43 0D         [24]  801 	lcall	_ak820_outline_0043
      003E61 FC               [12]  802 	mov	r4,a
      003E62 63 04 FF         [24]  803 	xrl	ar4,#0xff
      003E65 8E 82            [24]  804 	mov	dpl,r6
      003E67 8D 83            [24]  805 	mov	dph,r5
      003E69 EC               [12]  806 	mov	a,r4
      003E6A F0               [24]  807 	movx	@dptr,a
      003E6B 0F               [12]  808 	inc	r7
      003E6C BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E6F 90 05 7E         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E72 74 05            [12]  812 	mov	a,#0x05
      003E74 F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E75 90 EF 40         [24]  815 	mov	dptr,#0xef40
      003E78 12 39 EF         [24]  816 	lcall	_ak820_flash_erase
      003E7B E5 82            [12]  817 	mov	a, dpl
      003E7D 70 03            [24]  818 	jnz	00269$
      003E7F 02 3F 66         [24]  819 	ljmp	00127$
      003E82                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E82 90 05 7E         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E85 74 06            [12]  823 	mov	a,#0x06
      003E87 F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E88 7F 00            [12]  826 	mov	r7,#0x00
      003E8A                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E8A 12 43 19         [24]  829 	lcall	_ak820_outline_0052
      003E8D 12 38 E2         [24]  830 	lcall	_ak820_flash_read
      003E90 E5 82            [12]  831 	mov	a, dpl
      003E92 60 03            [24]  832 	jz	00270$
      003E94 02 3F 66         [24]  833 	ljmp	00127$
      003E97                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E97 0F               [12]  836 	inc	r7
      003E98 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003E9B 90 05 7E         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E9E 74 07            [12]  840 	mov	a,#0x07
      003EA0 F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003EA1 90 EF 00         [24]  843 	mov	dptr,#0xef00
      003EA4 12 3C 57         [24]  844 	lcall	_write_page
      003EA7 E5 82            [12]  845 	mov	a, dpl
      003EA9 70 03            [24]  846 	jnz	00273$
      003EAB 02 3F 66         [24]  847 	ljmp	00127$
      003EAE                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EAE 90 05 7E         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EB1 74 08            [12]  851 	mov	a,#0x08
      003EB3 F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EB4 7F 01            [12]  854 	mov	r7,#0x01
      003EB6                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003EB6 12 43 0D         [24]  857 	lcall	_ak820_outline_0043
      003EB9 FE               [12]  858 	mov	r6,a
      003EBA 60 23            [24]  859 	jz	00133$
      003EBC 8F 05            [24]  860 	mov	ar5,r7
      003EBE 7C 00            [12]  861 	mov	r4,#0x00
      003EC0 74 40            [12]  862 	mov	a,#0x40
      003EC2 2D               [12]  863 	add	a, r5
      003EC3 FD               [12]  864 	mov	r5,a
      003EC4 74 EF            [12]  865 	mov	a,#0xef
      003EC6 3C               [12]  866 	addc	a, r4
      003EC7 FC               [12]  867 	mov	r4,a
      003EC8 90 04 F6         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      003ECB EE               [12]  869 	mov	a,r6
      003ECC F0               [24]  870 	movx	@dptr,a
      003ECD 8D 82            [24]  871 	mov	dpl, r5
      003ECF 8C 83            [24]  872 	mov	dph, r4
      003ED1 C0 07            [24]  873 	push	ar7
      003ED3 12 3A 4F         [24]  874 	lcall	_ak820_flash_program
      003ED6 E5 82            [12]  875 	mov	a, dpl
      003ED8 D0 07            [24]  876 	pop	ar7
      003EDA 70 03            [24]  877 	jnz	00275$
      003EDC 02 3F 66         [24]  878 	ljmp	00127$
      003EDF                        879 00275$:
      003EDF                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EDF 0F               [12]  882 	inc	r7
      003EE0 BF 09 D3         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EE3 90 05 7E         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EE6 74 09            [12]  886 	mov	a,#0x09
      003EE8 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EE9 7F 01            [12]  889 	mov	r7,#0x01
      003EEB                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EEB 12 43 19         [24]  892 	lcall	_ak820_outline_0052
      003EEE 12 38 E2         [24]  893 	lcall	_ak820_flash_read
      003EF1 AE 82            [24]  894 	mov	r6, dpl
      003EF3 12 43 0D         [24]  895 	lcall	_ak820_outline_0043
      003EF6 FD               [12]  896 	mov	r5,a
      003EF7 EE               [12]  897 	mov	a,r6
      003EF8 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EFB 0F               [12]  900 	inc	r7
      003EFC BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003EFF 90 05 7E         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F02 74 0A            [12]  904 	mov	a,#0x0a
      003F04 F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F05 90 05 75         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F08 E0               [24]  908 	movx	a,@dptr
      003F09 90 04 F6         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      003F0C F0               [24]  910 	movx	@dptr,a
      003F0D 90 EF 40         [24]  911 	mov	dptr,#0xef40
      003F10 12 3A 4F         [24]  912 	lcall	_ak820_flash_program
      003F13 E5 82            [12]  913 	mov	a, dpl
      003F15 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F17 90 05 7E         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F1A 74 0B            [12]  917 	mov	a,#0x0b
      003F1C F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F1D 90 EF 40         [24]  920 	mov	dptr,#0xef40
      003F20 12 38 E2         [24]  921 	lcall	_ak820_flash_read
      003F23 AF 82            [24]  922 	mov	r7, dpl
      003F25 90 05 75         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F28 E0               [24]  924 	movx	a,@dptr
      003F29 FE               [12]  925 	mov	r6,a
      003F2A EF               [12]  926 	mov	a,r7
      003F2B B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F2E 90 05 7E         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F31 74 0C            [12]  930 	mov	a,#0x0c
      003F33 F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F34 90 05 5D         [24]  933 	mov	dptr,#_cached_page
      003F37 E0               [24]  934 	movx	a,@dptr
      003F38 FE               [12]  935 	mov	r6,a
      003F39 E4               [12]  936 	clr	a
      003F3A C3               [12]  937 	clr	c
      003F3B CE               [12]  938 	xch	a,r6
      003F3C 13               [12]  939 	rrc	a
      003F3D CE               [12]  940 	xch	a,r6
      003F3E 13               [12]  941 	rrc	a
      003F3F A2 E0            [12]  942 	mov	c,acc.0
      003F41 CE               [12]  943 	xch	a,r6
      003F42 13               [12]  944 	rrc	a
      003F43 CE               [12]  945 	xch	a,r6
      003F44 13               [12]  946 	rrc	a
      003F45 CE               [12]  947 	xch	a,r6
      003F46 24 C7            [12]  948 	add	a,#0xc7
      003F48 FF               [12]  949 	mov	r7,a
      003F49 12 38 7F         [24]  950 	lcall	_ak820_outline_0118
      003F4C 12 3C 57         [24]  951 	lcall	_write_page
      003F4F E5 82            [12]  952 	mov	a, dpl
      003F51 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F53 90 05 7E         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F56 74 0D            [12]  956 	mov	a,#0x0d
      003F58 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F59 90 EF 40         [24]  959 	mov	dptr,#0xef40
      003F5C 12 39 EF         [24]  960 	lcall	_ak820_flash_erase
      003F5F E5 82            [12]  961 	mov	a, dpl
      003F61 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      003F63 C2 0A            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F65 22               [24]  968 	ret
      003F66                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F66 90 05 7E         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F69 E0               [24]  972 	movx	a,@dptr
      003F6A F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F6C 02 3B 76         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      003F6F                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F6F 90 05 5E         [24]  985 	mov	dptr,#_batch_depth
      003F72 E0               [24]  986 	movx	a,@dptr
      003F73 FF               [12]  987 	mov	r7,a
      003F74 BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      003F77 75 82 0F         [24]  989 	mov	dpl, #0x0f
      003F7A 02 3B 76         [24]  990 	ljmp	_nvm_fail
      003F7D                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F7D 90 05 5E         [24]  993 	mov	dptr,#_batch_depth
      003F80 EF               [12]  994 	mov	a,r7
      003F81 04               [12]  995 	inc	a
      003F82 F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F83 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      003F84                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F84 90 05 5E         [24] 1008 	mov	dptr,#_batch_depth
      003F87 E0               [24] 1009 	movx	a,@dptr
      003F88 FF               [12] 1010 	mov	r7,a
      003F89 E0               [24] 1011 	movx	a,@dptr
      003F8A 60 06            [24] 1012 	jz	00102$
      003F8C EF               [12] 1013 	mov	a,r7
      003F8D 14               [12] 1014 	dec	a
      003F8E 90 05 5E         [24] 1015 	mov	dptr,#_batch_depth
      003F91 F0               [24] 1016 	movx	@dptr,a
      003F92                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F92 90 05 5E         [24] 1019 	mov	dptr,#_batch_depth
      003F95 E0               [24] 1020 	movx	a,@dptr
      003F96 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003F98 02 3E 1C         [24] 1023 	ljmp	_ak820_nvm_flush
      003F9B                       1024 00105$:
      003F9B 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      003F9C                       1036 _load_page:
      003F9C E5 82            [12] 1037 	mov	a,dpl
      003F9E 90 05 7F         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      003FA1 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FA2 30 09 17         [24] 1041 	jnb	_page_valid,00102$
      003FA5 90 05 5D         [24] 1042 	mov	dptr,#_cached_page
      003FA8 E0               [24] 1043 	movx	a,@dptr
      003FA9 FF               [12] 1044 	mov	r7,a
      003FAA 90 05 7F         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      003FAD E0               [24] 1046 	movx	a,@dptr
      003FAE FE               [12] 1047 	mov	r6,a
      003FAF EF               [12] 1048 	mov	a,r7
      003FB0 B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      003FB3 A2 0B            [12] 1050 	mov	c,_storage_failed
      003FB5 B3               [12] 1051 	cpl	c
      003FB6 92 0D            [24] 1052 	mov  _load_page_sloc0_1_0,c
      003FB8 12 38 A4         [24] 1053 	lcall	_ak820_outline_0156
      003FBB 22               [24] 1054 	ret
      003FBC                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FBC 12 3E 1C         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003FBF 30 0B 04         [24] 1059 	jnb	_storage_failed,00119$
      003FC2 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FC5 22               [24] 1062 	ret
      003FC6                       1063 00119$:
      003FC6 7F 00            [12] 1064 	mov	r7,#0x00
      003FC8                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003FC8 EF               [12] 1067 	mov	a,r7
      003FC9 24 1D            [12] 1068 	add	a, #_page_data
      003FCB FD               [12] 1069 	mov	r5,a
      003FCC E4               [12] 1070 	clr	a
      003FCD 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      003FCF FE               [12] 1072 	mov	r6,a
      003FD0 90 05 7F         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      003FD3 E0               [24] 1074 	movx	a,@dptr
      003FD4 FC               [12] 1075 	mov	r4,a
      003FD5 FA               [12] 1076 	mov	r2,a
      003FD6 E4               [12] 1077 	clr	a
      003FD7 C3               [12] 1078 	clr	c
      003FD8 CA               [12] 1079 	xch	a,r2
      003FD9 13               [12] 1080 	rrc	a
      003FDA CA               [12] 1081 	xch	a,r2
      003FDB 13               [12] 1082 	rrc	a
      003FDC A2 E0            [12] 1083 	mov	c,acc.0
      003FDE CA               [12] 1084 	xch	a,r2
      003FDF 13               [12] 1085 	rrc	a
      003FE0 CA               [12] 1086 	xch	a,r2
      003FE1 13               [12] 1087 	rrc	a
      003FE2 CA               [12] 1088 	xch	a,r2
      003FE3 24 C7            [12] 1089 	add	a,#0xc7
      003FE5 FB               [12] 1090 	mov	r3,a
      003FE6 8F 01            [24] 1091 	mov	ar1,r7
      003FE8 89 00            [24] 1092 	mov	ar0,r1
      003FEA 79 00            [12] 1093 	mov	r1,#0x00
      003FEC E8               [12] 1094 	mov	a,r0
      003FED 2A               [12] 1095 	add	a, r2
      003FEE FA               [12] 1096 	mov	r2,a
      003FEF E9               [12] 1097 	mov	a,r1
      003FF0 3B               [12] 1098 	addc	a, r3
      003FF1 FB               [12] 1099 	mov	r3,a
      003FF2 12 38 9F         [24] 1100 	lcall	_ak820_outline_0143
      003FF5 12 38 E2         [24] 1101 	lcall	_ak820_flash_read
      003FF8 AB 82            [24] 1102 	mov	r3, dpl
      003FFA 12 38 94         [24] 1103 	lcall	_ak820_outline_0135
      003FFD EB               [12] 1104 	mov	a,r3
      003FFE F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FFF 0F               [12] 1107 	inc	r7
      004000 BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      004003 90 05 5D         [24] 1110 	mov	dptr,#_cached_page
      004006 EC               [12] 1111 	mov	a,r4
      004007 F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      004008 D2 09            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      00400A 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      00400D 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      00400E                       1129 _read_offset:
      00400E 12 38 75         [24] 1130 	lcall	_ak820_outline_0107
      004011 90 05 80         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      004014 12 38 7A         [24] 1132 	lcall	_ak820_outline_0108
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004017 90 05 80         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      00401A 12 38 34         [24] 1135 	lcall	_ak820_outline_0051
      00401D C3               [12] 1136 	clr	c
      00401E 94 28            [12] 1137 	subb	a,#0x28
      004020 40 04            [24] 1138 	jc	00102$
      004022 75 82 00         [24] 1139 	mov	dpl, #0x00
      004025 22               [24] 1140 	ret
      004026                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      004026 30 09 34         [24] 1143 	jnb	_page_valid,00104$
      004029 8E 04            [24] 1144 	mov	ar4,r6
      00402B EF               [12] 1145 	mov	a,r7
      00402C A2 E7            [12] 1146 	mov	c,acc.7
      00402E CC               [12] 1147 	xch	a,r4
      00402F 33               [12] 1148 	rlc	a
      004030 CC               [12] 1149 	xch	a,r4
      004031 33               [12] 1150 	rlc	a
      004032 A2 E7            [12] 1151 	mov	c,acc.7
      004034 CC               [12] 1152 	xch	a,r4
      004035 33               [12] 1153 	rlc	a
      004036 CC               [12] 1154 	xch	a,r4
      004037 33               [12] 1155 	rlc	a
      004038 CC               [12] 1156 	xch	a,r4
      004039 54 03            [12] 1157 	anl	a,#0x03
      00403B FD               [12] 1158 	mov	r5,a
      00403C 90 05 5D         [24] 1159 	mov	dptr,#_cached_page
      00403F E0               [24] 1160 	movx	a,@dptr
      004040 FA               [12] 1161 	mov	r2,a
      004041 7B 00            [12] 1162 	mov	r3,#0x00
      004043 EC               [12] 1163 	mov	a,r4
      004044 B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      004047 ED               [12] 1165 	mov	a,r5
      004048 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      00404B 74 3F            [12] 1168 	mov	a,#0x3f
      00404D 5E               [12] 1169 	anl	a,r6
      00404E 7D 00            [12] 1170 	mov	r5,#0x00
      004050 24 1D            [12] 1171 	add	a, #_page_data
      004052 F5 82            [12] 1172 	mov	dpl,a
      004054 ED               [12] 1173 	mov	a,r5
      004055 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      004057 F5 83            [12] 1175 	mov	dph,a
      004059 E0               [24] 1176 	movx	a,@dptr
      00405A F5 82            [12] 1177 	mov	dpl,a
      00405C 22               [24] 1178 	ret
      00405D                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      00405D 74 C7            [12] 1181 	mov	a,#0xc7
      00405F 2F               [12] 1182 	add	a, r7
      004060 FF               [12] 1183 	mov	r7,a
      004061 12 38 7F         [24] 1184 	lcall	_ak820_outline_0118
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      004064 02 38 E2         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      004067                       1196 _eeprom_read_byte:
      004067 C0 07            [24] 1197 	push	ar7
      004069 C0 06            [24] 1198 	push	ar6
      00406B 12 43 06         [24] 1199 	lcall	_ak820_outline_0037
      00406E 90 05 82         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004071 12 38 1C         [24] 1201 	lcall	_ak820_outline_0017
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      004074 90 05 82         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004077 12 37 E7         [24] 1204 	lcall	_ak820_outline_0005
      00407A C0 06            [24] 1205 	push	ar6
      00407C C0 05            [24] 1206 	push	ar5
      00407E C0 04            [24] 1207 	push	ar4
      004080 C0 03            [24] 1208 	push	ar3
      004082 C0 02            [24] 1209 	push	ar2
      004084 C0 01            [24] 1210 	push	ar1
      004086 C0 00            [24] 1211 	push	ar0
      004088 12 40 0E         [24] 1212 	lcall	_read_offset
      00408B AF 82            [24] 1213 	mov	r7, dpl
      00408D D0 00            [24] 1214 	pop	ar0
      00408F D0 01            [24] 1215 	pop	ar1
      004091 D0 02            [24] 1216 	pop	ar2
      004093 D0 03            [24] 1217 	pop	ar3
      004095 D0 04            [24] 1218 	pop	ar4
      004097 D0 05            [24] 1219 	pop	ar5
      004099 D0 06            [24] 1220 	pop	ar6
      00409B 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      00409D D0 06            [24] 1223 	pop	ar6
      00409F D0 07            [24] 1224 	pop	ar7
      0040A1 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      0040A2                       1239 _ak820_eeprom_read_block_xdata:
      0040A2 12 38 75         [24] 1240 	lcall	_ak820_outline_0107
      0040A5 90 05 8A         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040A8 12 38 7A         [24] 1242 	lcall	_ak820_outline_0108
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040AB 90 05 85         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040AE 12 38 34         [24] 1245 	lcall	_ak820_outline_0051
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040B1 90 05 8A         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040B4 12 38 4B         [24] 1248 	lcall	_ak820_outline_0059
      0040B7 90 05 8C         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040BA 12 38 51         [24] 1250 	lcall	_ak820_outline_0072
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0040BD 90 05 88         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0040C0 12 38 4B         [24] 1253 	lcall	_ak820_outline_0059
      0040C3                       1254 00103$:
      0040C3 8C 02            [24] 1255 	mov	ar2,r4
      0040C5 8D 03            [24] 1256 	mov	ar3,r5
      0040C7 1C               [12] 1257 	dec	r4
      0040C8 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      0040CB 1D               [12] 1259 	dec	r5
      0040CC                       1260 00130$:
      0040CC EA               [12] 1261 	mov	a,r2
      0040CD 4B               [12] 1262 	orl	a,r3
      0040CE 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0040D0 8E 02            [24] 1265 	mov	ar2,r6
      0040D2 8F 03            [24] 1266 	mov	ar3,r7
      0040D4 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      0040D6 2B               [12] 1268 	add	a,r3
      0040D7 50 17            [24] 1269 	jnc	00102$
      0040D9 90 05 8C         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040DC 12 43 3D         [24] 1271 	lcall	_ak820_outline_0103
      0040DF 12 38 9F         [24] 1272 	lcall	_ak820_outline_0143
      0040E2 E4               [12] 1273 	clr	a
      0040E3 F0               [24] 1274 	movx	@dptr,a
      0040E4 90 05 8C         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040E7 04               [12] 1276 	inc	a
      0040E8 2A               [12] 1277 	add	a, r2
      0040E9 F0               [24] 1278 	movx	@dptr,a
      0040EA E4               [12] 1279 	clr	a
      0040EB 3B               [12] 1280 	addc	a, r3
      0040EC A3               [24] 1281 	inc	dptr
      0040ED F0               [24] 1282 	movx	@dptr,a
      0040EE 80 D3            [24] 1283 	sjmp	00103$
      0040F0                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040F0 90 05 8C         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040F3 12 43 3D         [24] 1287 	lcall	_ak820_outline_0103
      0040F6 12 38 7F         [24] 1288 	lcall	_ak820_outline_0118
      0040F9 C0 07            [24] 1289 	push	ar7
      0040FB C0 06            [24] 1290 	push	ar6
      0040FD C0 05            [24] 1291 	push	ar5
      0040FF C0 04            [24] 1292 	push	ar4
      004101 C0 03            [24] 1293 	push	ar3
      004103 C0 02            [24] 1294 	push	ar2
      004105 12 40 0E         [24] 1295 	lcall	_read_offset
      004108 A9 82            [24] 1296 	mov	r1, dpl
      00410A D0 02            [24] 1297 	pop	ar2
      00410C D0 03            [24] 1298 	pop	ar3
      00410E D0 04            [24] 1299 	pop	ar4
      004110 D0 05            [24] 1300 	pop	ar5
      004112 D0 06            [24] 1301 	pop	ar6
      004114 D0 07            [24] 1302 	pop	ar7
      004116 12 38 9F         [24] 1303 	lcall	_ak820_outline_0143
      004119 E9               [12] 1304 	mov	a,r1
      00411A F0               [24] 1305 	movx	@dptr,a
      00411B 90 05 8C         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00411E 74 01            [12] 1307 	mov	a,#0x01
      004120 2A               [12] 1308 	add	a, r2
      004121 F0               [24] 1309 	movx	@dptr,a
      004122 E4               [12] 1310 	clr	a
      004123 3B               [12] 1311 	addc	a, r3
      004124 A3               [24] 1312 	inc	dptr
      004125 F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      004126 0E               [12] 1315 	inc	r6
      004127 BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      00412A 0F               [12] 1317 	inc	r7
      00412B 80 96            [24] 1318 	sjmp	00103$
      00412D                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      00412D 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      00412E                       1337 _ak820_eeprom_write_block_xdata:
      00412E 12 38 75         [24] 1338 	lcall	_ak820_outline_0107
      004131 90 05 93         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004134 12 38 7A         [24] 1340 	lcall	_ak820_outline_0108
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004137 90 05 8E         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00413A 12 38 34         [24] 1343 	lcall	_ak820_outline_0051
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      00413D 90 05 93         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004140 12 38 4B         [24] 1346 	lcall	_ak820_outline_0059
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      004143 8E 02            [24] 1348 	mov	ar2,r6
      004145 8F 03            [24] 1349 	mov	ar3,r7
      004147 C3               [12] 1350 	clr	c
      004148 E4               [12] 1351 	clr	a
      004149 9A               [12] 1352 	subb	a,r2
      00414A 74 28            [12] 1353 	mov	a,#0x28
      00414C 9B               [12] 1354 	subb	a,r3
      00414D 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      00414F E4               [12] 1357 	clr	a
      004150 C3               [12] 1358 	clr	c
      004151 9E               [12] 1359 	subb	a,r6
      004152 FA               [12] 1360 	mov	r2,a
      004153 74 28            [12] 1361 	mov	a,#0x28
      004155 9F               [12] 1362 	subb	a,r7
      004156 FB               [12] 1363 	mov	r3,a
      004157 90 05 91         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00415A 12 38 6F         [24] 1365 	lcall	_ak820_outline_0102
      00415D C3               [12] 1366 	clr	c
      00415E EA               [12] 1367 	mov	a,r2
      00415F 98               [12] 1368 	subb	a,r0
      004160 EB               [12] 1369 	mov	a,r3
      004161 99               [12] 1370 	subb	a,r1
      004162 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      004164                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      004164 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      004167 02 3B 76         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      00416A                       1379 00125$:
      00416A 90 05 91         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00416D 12 43 3D         [24] 1381 	lcall	_ak820_outline_0103
      004170                       1382 00108$:
      004170 8A 00            [24] 1383 	mov	ar0,r2
      004172 8B 01            [24] 1384 	mov	ar1,r3
      004174 1A               [12] 1385 	dec	r2
      004175 BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      004178 1B               [12] 1387 	dec	r3
      004179                       1388 00159$:
      004179 E8               [12] 1389 	mov	a,r0
      00417A 49               [12] 1390 	orl	a,r1
      00417B 70 03            [24] 1391 	jnz	00160$
      00417D 02 42 07         [24] 1392 	ljmp	00110$
      004180                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004180 C0 02            [24] 1395 	push	ar2
      004182 C0 03            [24] 1396 	push	ar3
      004184 12 43 37         [24] 1397 	lcall	_ak820_outline_0095
      004187 F9               [12] 1398 	mov	r1,a
      004188 A3               [24] 1399 	inc	dptr
      004189 12 43 60         [24] 1400 	lcall	_ak820_outline_0149
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      00418C 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      00418E 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004190 A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004192 E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004194 A2 E7            [12] 1406 	mov	c,acc.7
      004196 C8               [12] 1407 	xch	a,r0
      004197 33               [12] 1408 	rlc	a
      004198 C8               [12] 1409 	xch	a,r0
      004199 33               [12] 1410 	rlc	a
      00419A A2 E7            [12] 1411 	mov	c,acc.7
      00419C C8               [12] 1412 	xch	a,r0
      00419D 33               [12] 1413 	rlc	a
      00419E C8               [12] 1414 	xch	a,r0
      00419F 33               [12] 1415 	rlc	a
      0041A0 C8               [12] 1416 	xch	a,r0
      0041A1 54 03            [12] 1417 	anl	a,#0x03
      0041A3 FB               [12] 1418 	mov	r3,a
      0041A4 88 82            [24] 1419 	mov	dpl, r0
      0041A6 C0 07            [24] 1420 	push	ar7
      0041A8 C0 06            [24] 1421 	push	ar6
      0041AA C0 05            [24] 1422 	push	ar5
      0041AC C0 04            [24] 1423 	push	ar4
      0041AE C0 03            [24] 1424 	push	ar3
      0041B0 C0 02            [24] 1425 	push	ar2
      0041B2 C0 01            [24] 1426 	push	ar1
      0041B4 12 3F 9C         [24] 1427 	lcall	_load_page
      0041B7 E5 82            [12] 1428 	mov	a, dpl
      0041B9 D0 01            [24] 1429 	pop	ar1
      0041BB D0 02            [24] 1430 	pop	ar2
      0041BD D0 03            [24] 1431 	pop	ar3
      0041BF D0 04            [24] 1432 	pop	ar4
      0041C1 D0 05            [24] 1433 	pop	ar5
      0041C3 D0 06            [24] 1434 	pop	ar6
      0041C5 D0 07            [24] 1435 	pop	ar7
      0041C7 D0 03            [24] 1436 	pop	ar3
      0041C9 D0 02            [24] 1437 	pop	ar2
      0041CB 70 01            [24] 1438 	jnz	00105$
      0041CD 22               [24] 1439 	ret
      0041CE                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0041CE C0 06            [24] 1442 	push	ar6
      0041D0 C0 07            [24] 1443 	push	ar7
      0041D2 74 3F            [12] 1444 	mov	a,#0x3f
      0041D4 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041D6 7F 00            [12] 1446 	mov	r7,#0x00
      0041D8 24 1D            [12] 1447 	add	a, #_page_data
      0041DA F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041DC EF               [12] 1449 	mov	a,r7
      0041DD 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      0041DF F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041E1 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041E4 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041E7 E0               [24] 1454 	movx	a,@dptr
      0041E8 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      0041EB D0 07            [24] 1456 	pop	ar7
      0041ED D0 06            [24] 1457 	pop	ar6
      0041EF 80 0E            [24] 1458 	sjmp	00107$
      0041F1                       1459 00162$:
      0041F1 D0 07            [24] 1460 	pop	ar7
      0041F3 D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0041F5 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041F8 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041FB E9               [12] 1465 	mov	a,r1
      0041FC F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      0041FD D2 0A            [12] 1469 	setb	_page_dirty
      0041FF                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      0041FF 0E               [12] 1472 	inc	r6
      004200 BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      004203 0F               [12] 1474 	inc	r7
      004204                       1475 00163$:
      004204 02 41 70         [24] 1476 	ljmp	00108$
      004207                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004207 90 05 5E         [24] 1479 	mov	dptr,#_batch_depth
      00420A E0               [24] 1480 	movx	a,@dptr
      00420B 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      00420D 02 3E 1C         [24] 1483 	ljmp	_ak820_nvm_flush
      004210                       1484 00113$:
      004210 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      004211                       1503 _ak820_eeprom_update_block_xdata:
      004211 12 38 75         [24] 1504 	lcall	_ak820_outline_0107
      004214 90 05 9A         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004217 12 38 7A         [24] 1506 	lcall	_ak820_outline_0108
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      00421A 90 05 9A         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00421D 12 38 34         [24] 1509 	lcall	_ak820_outline_0051
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004220 90 05 95         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      004223 E0               [24] 1512 	movx	a,@dptr
      004224 F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      004226 A3               [24] 1514 	inc	dptr
      004227 E0               [24] 1515 	movx	a,@dptr
      004228 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      00422A A3               [24] 1517 	inc	dptr
      00422B E0               [24] 1518 	movx	a,@dptr
      00422C F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      00422E A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004230 AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004232 E4               [12] 1523 	clr	a
      004233 F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      004235 F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      004237                       1526 00105$:
      004237 90 05 98         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      00423A E0               [24] 1528 	movx	a,@dptr
      00423B F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      00423D A3               [24] 1530 	inc	dptr
      00423E E0               [24] 1531 	movx	a,@dptr
      00423F F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004241 C3               [12] 1533 	clr	c
      004242 E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004244 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004246 E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004248 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00424A 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      00424C 89 00            [24] 1540 	mov	ar0,r1
      00424E 8A 05            [24] 1541 	mov	ar5,r2
      004250 E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004252 28               [12] 1543 	add	a, r0
      004253 F8               [12] 1544 	mov	r0,a
      004254 E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004256 3D               [12] 1546 	addc	a, r5
      004257 FD               [12] 1547 	mov	r5,a
      004258 88 82            [24] 1548 	mov	dpl, r0
      00425A 8D 83            [24] 1549 	mov	dph, r5
      00425C C0 07            [24] 1550 	push	ar7
      00425E C0 06            [24] 1551 	push	ar6
      004260 C0 02            [24] 1552 	push	ar2
      004262 C0 01            [24] 1553 	push	ar1
      004264 12 40 0E         [24] 1554 	lcall	_read_offset
      004267 AD 82            [24] 1555 	mov	r5, dpl
      004269 D0 01            [24] 1556 	pop	ar1
      00426B D0 02            [24] 1557 	pop	ar2
      00426D D0 06            [24] 1558 	pop	ar6
      00426F D0 07            [24] 1559 	pop	ar7
      004271 E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      004273 2E               [12] 1561 	add	a, r6
      004274 F5 82            [12] 1562 	mov	dpl,a
      004276 E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004278 3F               [12] 1564 	addc	a, r7
      004279 F5 83            [12] 1565 	mov	dph,a
      00427B E0               [24] 1566 	movx	a,@dptr
      00427C FC               [12] 1567 	mov	r4,a
      00427D ED               [12] 1568 	mov	a,r5
      00427E B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      004281 80 27            [24] 1570 	sjmp	00106$
      004283                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      004283 90 05 9A         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004286 E0               [24] 1574 	movx	a,@dptr
      004287 F8               [12] 1575 	mov	r0,a
      004288 A3               [24] 1576 	inc	dptr
      004289 E0               [24] 1577 	movx	a,@dptr
      00428A FD               [12] 1578 	mov	r5,a
      00428B 90 05 8E         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      00428E E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004290 F0               [24] 1581 	movx	@dptr,a
      004291 E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      004293 A3               [24] 1583 	inc	dptr
      004294 F0               [24] 1584 	movx	@dptr,a
      004295 E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004297 A3               [24] 1586 	inc	dptr
      004298 F0               [24] 1587 	movx	@dptr,a
      004299 90 05 91         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00429C E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00429E F0               [24] 1590 	movx	@dptr,a
      00429F E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042A1 A3               [24] 1592 	inc	dptr
      0042A2 F0               [24] 1593 	movx	@dptr,a
      0042A3 88 82            [24] 1594 	mov	dpl, r0
      0042A5 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042A7 02 41 2E         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      0042AA                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042AA 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042AC E4               [12] 1601 	clr	a
      0042AD B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042B0 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042B2 80 83            [24] 1604 	sjmp	00105$
      0042B4                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042B4 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      0042B5                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042B5 12 3E 1C         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042B8 7F 00            [12] 1622 	mov	r7,#0x00
      0042BA                       1623 00111$:
      0042BA BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      0042BD 22               [24] 1625 	ret
      0042BE                       1626 00165$:
      0042BE 20 0B 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0042C1 8F 82            [24] 1629 	mov	dpl, r7
      0042C3 C0 07            [24] 1630 	push	ar7
      0042C5 12 3F 9C         [24] 1631 	lcall	_load_page
      0042C8 E5 82            [12] 1632 	mov	a, dpl
      0042CA D0 07            [24] 1633 	pop	ar7
      0042CC 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042CE 22               [24] 1636 	ret
      0042CF                       1637 00126$:
      0042CF 7E 00            [12] 1638 	mov	r6,#0x00
      0042D1                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0042D1 EE               [12] 1641 	mov	a,r6
      0042D2 24 1D            [12] 1642 	add	a, #_page_data
      0042D4 FC               [12] 1643 	mov	r4,a
      0042D5 E4               [12] 1644 	clr	a
      0042D6 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      0042D8 FD               [12] 1646 	mov	r5,a
      0042D9 12 43 37         [24] 1647 	lcall	_ak820_outline_0095
      0042DC 60 07            [24] 1648 	jz	00108$
      0042DE 12 38 8A         [24] 1649 	lcall	_ak820_outline_0124
      0042E1 E4               [12] 1650 	clr	a
      0042E2 F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      0042E3 D2 0A            [12] 1653 	setb	_page_dirty
      0042E5                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042E5 0E               [12] 1656 	inc	r6
      0042E6 BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042E9 C0 07            [24] 1659 	push	ar7
      0042EB 12 3E 1C         [24] 1660 	lcall	_ak820_nvm_flush
      0042EE D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042F0 0F               [12] 1663 	inc	r7
      0042F1 80 C7            [24] 1664 	sjmp	00111$
      0042F3                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042F3 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0005
                                   1675 	.globl _ak820_outline_0011
                                   1676 	.globl _ak820_outline_0017
                                   1677 	.globl _ak820_outline_0022
                                   1678 	.globl _ak820_outline_0031
                                   1679 	.globl _ak820_outline_0037
                                   1680 	.globl _ak820_outline_0043
                                   1681 	.globl _ak820_outline_0051
                                   1682 	.globl _ak820_outline_0052
                                   1683 	.globl _ak820_outline_0059
                                   1684 	.globl _ak820_outline_0063
                                   1685 	.globl _ak820_outline_0071
                                   1686 	.globl _ak820_outline_0072
                                   1687 	.globl _ak820_outline_0079
                                   1688 	.globl _ak820_outline_0085
                                   1689 	.globl _ak820_outline_0095
                                   1690 	.globl _ak820_outline_0102
                                   1691 	.globl _ak820_outline_0103
                                   1692 	.globl _ak820_outline_0105
                                   1693 	.globl _ak820_outline_0107
                                   1694 	.globl _ak820_outline_0108
                                   1695 	.globl _ak820_outline_0118
                                   1696 	.globl _ak820_outline_0122
                                   1697 	.globl _ak820_outline_0123
                                   1698 	.globl _ak820_outline_0124
                                   1699 	.globl _ak820_outline_0133
                                   1700 	.globl _ak820_outline_0135
                                   1701 	.globl _ak820_outline_0137
                                   1702 	.globl _ak820_outline_0142
                                   1703 	.globl _ak820_outline_0143
                                   1704 	.globl _ak820_outline_0149
                                   1705 	.globl _ak820_outline_0156
                                   1706 	.globl _ak820_outline_0158
                                   1707 	.globl _ak820_outline_0161
                                   1708 	.globl _ak820_outline_0162
                                   1709 	.globl _ak820_outline_0183
                                   1710 	.globl _ak820_outline_0184
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0011
      0042F4                       1714 _ak820_outline_0011:
      0042F4 8E 82            [24] 1715 	mov	dpl,r6
      0042F6 8F 83            [24] 1716 	mov	dph,r7
      0042F8 A3               [24] 1717 	inc	dptr
      0042F9 A3               [24] 1718 	inc	dptr
      0042FA A3               [24] 1719 	inc	dptr
      0042FB A3               [24] 1720 	inc	dptr
      0042FC A3               [24] 1721 	inc	dptr
      0042FD 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0031
      0042FE                       1726 _ak820_outline_0031:
      0042FE F0               [24] 1727 	movx	@dptr,a
      0042FF 8E 82            [24] 1728 	mov	dpl,r6
      004301 8F 83            [24] 1729 	mov	dph,r7
      004303 A3               [24] 1730 	inc	dptr
      004304 A3               [24] 1731 	inc	dptr
      004305 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0037
      004306                       1736 _ak820_outline_0037:
      004306 AF F0            [24] 1737 	mov	r7,b
      004308 AE 83            [24] 1738 	mov	r6,dph
      00430A E5 82            [12] 1739 	mov	a,dpl
      00430C 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0043
      00430D                       1744 _ak820_outline_0043:
      00430D EF               [12] 1745 	mov	a,r7
      00430E 24 75            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      004310 F5 82            [12] 1747 	mov	dpl,a
      004312 E4               [12] 1748 	clr	a
      004313 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      004315 F5 83            [12] 1750 	mov	dph,a
      004317 E0               [24] 1751 	movx	a,@dptr
      004318 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0052
      004319                       1756 _ak820_outline_0052:
      004319 8F 06            [24] 1757 	mov	ar6,r7
      00431B 7D 00            [12] 1758 	mov	r5,#0x00
      00431D 74 40            [12] 1759 	mov	a,#0x40
      00431F 2E               [12] 1760 	add	a,r6
      004320 FE               [12] 1761 	mov	r6,a
      004321 74 EF            [12] 1762 	mov	a,#0xef
      004323 3D               [12] 1763 	addc	a,r5
      004324 FD               [12] 1764 	mov	r5,a
      004325 8E 82            [24] 1765 	mov	dpl,r6
      004327 8D 83            [24] 1766 	mov	dph,r5
      004329 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0063
      00432A                       1771 _ak820_outline_0063:
      00432A 8D 82            [24] 1772 	mov	dpl,r5
      00432C 8E 83            [24] 1773 	mov	dph,r6
      00432E EC               [12] 1774 	mov	a,r4
      00432F F0               [24] 1775 	movx	@dptr,a
      004330 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0071
      004331                       1780 _ak820_outline_0071:
      004331 F0               [24] 1781 	movx	@dptr,a
      004332 8E 82            [24] 1782 	mov	dpl,r6
      004334 8F 83            [24] 1783 	mov	dph,r7
      004336 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0095
      004337                       1788 _ak820_outline_0095:
      004337 8C 82            [24] 1789 	mov	dpl,r4
      004339 8D 83            [24] 1790 	mov	dph,r5
      00433B E0               [24] 1791 	movx	a,@dptr
      00433C 22               [24] 1792 	ret
                                   1793 
                                   1794 	.area CSEG (CODE)
                                   1795 ; function ak820_outline_0103
      00433D                       1796 _ak820_outline_0103:
      00433D E0               [24] 1797 	movx	a,@dptr
      00433E FA               [12] 1798 	mov	r2,a
      00433F A3               [24] 1799 	inc	dptr
      004340 E0               [24] 1800 	movx	a,@dptr
      004341 FB               [12] 1801 	mov	r3,a
      004342 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0105
      004343                       1806 _ak820_outline_0105:
      004343 EF               [12] 1807 	mov	a,r7
      004344 24 1D            [12] 1808 	add	a,#_page_data
      004346 F5 82            [12] 1809 	mov	dpl,a
      004348 E4               [12] 1810 	clr	a
      004349 34 05            [12] 1811 	addc	a,#(_page_data>>8)
      00434B F5 83            [12] 1812 	mov	dph,a
      00434D E0               [24] 1813 	movx	a,@dptr
      00434E 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0133
      00434F                       1818 _ak820_outline_0133:
      00434F AE 82            [24] 1819 	mov	r6,dpl
      004351 AF 83            [24] 1820 	mov	r7,dph
      004353 22               [24] 1821 	ret
                                   1822 
                                   1823 	.area CSEG (CODE)
                                   1824 ; function ak820_outline_0137
      004354                       1825 _ak820_outline_0137:
      004354 2E               [12] 1826 	add	a,r6
      004355 FE               [12] 1827 	mov	r6,a
      004356 E4               [12] 1828 	clr	a
      004357 3F               [12] 1829 	addc	a,r7
      004358 FF               [12] 1830 	mov	r7,a
      004359 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0142
      00435A                       1835 _ak820_outline_0142:
      00435A 42 05            [12] 1836 	orl	ar5,a
      00435C EA               [12] 1837 	mov	a,r2
      00435D 42 04            [12] 1838 	orl	ar4,a
      00435F 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0149
      004360                       1843 _ak820_outline_0149:
      004360 AC 82            [24] 1844 	mov	r4,dpl
      004362 AD 83            [24] 1845 	mov	r5,dph
      004364 22               [24] 1846 	ret
                                   1847 
                                   1848 	.area CSEG (CODE)
                                   1849 ; function ak820_outline_0158
      004365                       1850 _ak820_outline_0158:
      004365 8F 82            [24] 1851 	mov	dpl,r7
      004367 8E 83            [24] 1852 	mov	dph,r6
      004369 22               [24] 1853 	ret
                                   1854 
                                   1855 	.area CSEG (CODE)
                                   1856 ; function ak820_outline_0161
      00436A                       1857 _ak820_outline_0161:
      00436A 2E               [12] 1858 	add	a,r6
      00436B FC               [12] 1859 	mov	r4,a
      00436C E4               [12] 1860 	clr	a
      00436D 3F               [12] 1861 	addc	a,r7
      00436E FD               [12] 1862 	mov	r5,a
      00436F 22               [24] 1863 	ret
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0162
      004370                       1867 _ak820_outline_0162:
      004370 ED               [12] 1868 	mov	a,r5
      004371 F0               [24] 1869 	movx	@dptr,a
      004372 EE               [12] 1870 	mov	a,r6
      004373 A3               [24] 1871 	inc	dptr
      004374 F0               [24] 1872 	movx	@dptr,a
      004375 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0183
      004376                       1877 _ak820_outline_0183:
      004376 89 82            [24] 1878 	mov	dpl,r1
      004378 8A 83            [24] 1879 	mov	dph,r2
      00437A 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0184
      00437B                       1884 _ak820_outline_0184:
      00437B 8C 82            [24] 1885 	mov	dpl,r4
      00437D 8B 83            [24] 1886 	mov	dph,r3
      00437F 22               [24] 1887 	ret
