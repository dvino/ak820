                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action_util
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _host_consumer_send
                                     12 	.globl _host_system_send
                                     13 	.globl _host_keyboard_send
                                     14 	.globl _clear_keys_from_report
                                     15 	.globl _del_key_from_report
                                     16 	.globl _add_key_to_report
                                     17 	.globl _KEYCODE2CONSUMER
                                     18 	.globl _ADC_START
                                     19 	.globl _S0_R_FIFO
                                     20 	.globl _S0_T_FIFO
                                     21 	.globl _S0_FREE
                                     22 	.globl _S0_IF_BYTE
                                     23 	.globl _S0_IF_FIRST
                                     24 	.globl _S0_IF_OV
                                     25 	.globl _S0_FST_ACT
                                     26 	.globl _CP_RL2
                                     27 	.globl _C_T2
                                     28 	.globl _TR2
                                     29 	.globl _EXEN2
                                     30 	.globl _TCLK
                                     31 	.globl _RCLK
                                     32 	.globl _EXF2
                                     33 	.globl _CAP1F
                                     34 	.globl _TF2
                                     35 	.globl _RI
                                     36 	.globl _TI
                                     37 	.globl _RB8
                                     38 	.globl _TB8
                                     39 	.globl _REN
                                     40 	.globl _SM2
                                     41 	.globl _SM1
                                     42 	.globl _SM0
                                     43 	.globl _IT0
                                     44 	.globl _IE0
                                     45 	.globl _IT1
                                     46 	.globl _IE1
                                     47 	.globl _TR0
                                     48 	.globl _TF0
                                     49 	.globl _TR1
                                     50 	.globl _TF1
                                     51 	.globl _P4_0
                                     52 	.globl _P4_1
                                     53 	.globl _P4_2
                                     54 	.globl _P4_3
                                     55 	.globl _P4_4
                                     56 	.globl _P4_5
                                     57 	.globl _P4_6
                                     58 	.globl _RXD
                                     59 	.globl _TXD
                                     60 	.globl _INT0
                                     61 	.globl _INT1
                                     62 	.globl _T0
                                     63 	.globl _T1
                                     64 	.globl _MOSI1
                                     65 	.globl _MISO1
                                     66 	.globl _SCK1
                                     67 	.globl _P3_0
                                     68 	.globl _P3_1
                                     69 	.globl _P3_2
                                     70 	.globl _P3_3
                                     71 	.globl _P3_4
                                     72 	.globl _P3_5
                                     73 	.globl _P3_6
                                     74 	.globl _P3_7
                                     75 	.globl _CAP1_
                                     76 	.globl _T2_
                                     77 	.globl _CAP2_
                                     78 	.globl _T2EX_
                                     79 	.globl _RXD1
                                     80 	.globl _TXD1
                                     81 	.globl _P2_0
                                     82 	.globl _P2_1
                                     83 	.globl _P2_2
                                     84 	.globl _P2_3
                                     85 	.globl _P2_4
                                     86 	.globl _P2_5
                                     87 	.globl _P2_6
                                     88 	.globl _P2_7
                                     89 	.globl _AIN0
                                     90 	.globl _AIN1
                                     91 	.globl _AIN2
                                     92 	.globl _AIN3
                                     93 	.globl _AIN4
                                     94 	.globl _AIN5
                                     95 	.globl _AIN6
                                     96 	.globl _AIN7
                                     97 	.globl _CAP1
                                     98 	.globl _T2
                                     99 	.globl _CAP2
                                    100 	.globl _T2EX
                                    101 	.globl _INT0_
                                    102 	.globl _SCS
                                    103 	.globl _MOSI
                                    104 	.globl _MISO
                                    105 	.globl _SCK
                                    106 	.globl _RXD1_
                                    107 	.globl _TXD1_
                                    108 	.globl _P1_0
                                    109 	.globl _P1_1
                                    110 	.globl _P1_2
                                    111 	.globl _P1_3
                                    112 	.globl _P1_4
                                    113 	.globl _P1_5
                                    114 	.globl _P1_6
                                    115 	.globl _P1_7
                                    116 	.globl _AIN8
                                    117 	.globl _AIN9
                                    118 	.globl _AIN10
                                    119 	.globl _AIN11
                                    120 	.globl _AIN12
                                    121 	.globl _AIN13
                                    122 	.globl _RXD_
                                    123 	.globl _TXD_
                                    124 	.globl _SCL0
                                    125 	.globl _SDA0
                                    126 	.globl _P0_0
                                    127 	.globl _P0_1
                                    128 	.globl _P0_2
                                    129 	.globl _P0_3
                                    130 	.globl _P0_4
                                    131 	.globl _P0_5
                                    132 	.globl _P0_6
                                    133 	.globl _P0_7
                                    134 	.globl _IE_SPI0
                                    135 	.globl _IE_USB
                                    136 	.globl _IE_ADC
                                    137 	.globl _IE_UART1
                                    138 	.globl _IE_PWM_I2C
                                    139 	.globl _IE_GPIO
                                    140 	.globl _IE_WDOG
                                    141 	.globl _PX0
                                    142 	.globl _PT0
                                    143 	.globl _PX1
                                    144 	.globl _PT1
                                    145 	.globl _PS
                                    146 	.globl _PT2
                                    147 	.globl _PL_FLAG
                                    148 	.globl _PH_FLAG
                                    149 	.globl _EX0
                                    150 	.globl _ET0
                                    151 	.globl _EX1
                                    152 	.globl _ET1
                                    153 	.globl _ES
                                    154 	.globl _ET2
                                    155 	.globl _E_DIS
                                    156 	.globl _EA
                                    157 	.globl _P
                                    158 	.globl _F1
                                    159 	.globl _OV
                                    160 	.globl _RS0
                                    161 	.globl _RS1
                                    162 	.globl _F0
                                    163 	.globl _AC
                                    164 	.globl _CY
                                    165 	.globl _I2CS_INT_ST
                                    166 	.globl _I2CX_INT
                                    167 	.globl _LED_STATUS
                                    168 	.globl _LED_DMA_H
                                    169 	.globl _LED_DMA_L
                                    170 	.globl _LED_DMA
                                    171 	.globl _LED_PWM_OE
                                    172 	.globl _LED_COMMON
                                    173 	.globl _ADC_CHAN
                                    174 	.globl _ADC_DAT_H
                                    175 	.globl _ADC_DAT_L
                                    176 	.globl _ADC_DAT
                                    177 	.globl _ADC_CTRL
                                    178 	.globl _SPI1_CK_SE
                                    179 	.globl _SPI1_CTRL
                                    180 	.globl _SPI1_DATA
                                    181 	.globl _SPI1_STAT
                                    182 	.globl _SIF1
                                    183 	.globl _SBAUD1
                                    184 	.globl _SBUF1
                                    185 	.globl _SCON1
                                    186 	.globl _SPI0_SETUP
                                    187 	.globl _SPI0_CK_SE
                                    188 	.globl _SPI0_CTRL
                                    189 	.globl _SPI0_DATA
                                    190 	.globl _SPI0_STAT
                                    191 	.globl _T2CAP1H
                                    192 	.globl _T2CAP1L
                                    193 	.globl _T2CAP1
                                    194 	.globl _TH2
                                    195 	.globl _TL2
                                    196 	.globl _T2COUNT
                                    197 	.globl _RCAP2H
                                    198 	.globl _RCAP2L
                                    199 	.globl _RCAP2
                                    200 	.globl _T2MOD
                                    201 	.globl _T2CON
                                    202 	.globl _SBUF
                                    203 	.globl _SCON
                                    204 	.globl _TH1
                                    205 	.globl _TH0
                                    206 	.globl _TL1
                                    207 	.globl _TL0
                                    208 	.globl _TMOD
                                    209 	.globl _TCON
                                    210 	.globl _XBUS_AUX
                                    211 	.globl _P7
                                    212 	.globl _P6_DIR
                                    213 	.globl _P6_OUT_PU
                                    214 	.globl _P6_IN
                                    215 	.globl _P5_DIR
                                    216 	.globl _P5_OUT_PU
                                    217 	.globl _P5_IN
                                    218 	.globl _P4_LED_KEY
                                    219 	.globl _P4_DIR_PU
                                    220 	.globl _P4_MOD_OC
                                    221 	.globl _P4
                                    222 	.globl _P3_DIR_PU
                                    223 	.globl _P3_MOD_OC
                                    224 	.globl _P3
                                    225 	.globl _P2_DIR_PU
                                    226 	.globl _P2_MOD_OC
                                    227 	.globl _P2
                                    228 	.globl _P1_DIR_PU
                                    229 	.globl _P1_MOD_OC
                                    230 	.globl _P1
                                    231 	.globl _P0_DIR_PU
                                    232 	.globl _P0_MOD_OC
                                    233 	.globl _P0
                                    234 	.globl _ROM_CTRL
                                    235 	.globl _ROM_DATA_HH
                                    236 	.globl _ROM_DATA_HL
                                    237 	.globl _ROM_DATA_HI
                                    238 	.globl _ROM_ADDR_H
                                    239 	.globl _ROM_ADDR_L
                                    240 	.globl _ROM_ADDR
                                    241 	.globl _GPIO_IE
                                    242 	.globl _IP_EX
                                    243 	.globl _IE_EX
                                    244 	.globl _IP
                                    245 	.globl _IE
                                    246 	.globl _WDOG_COUNT
                                    247 	.globl _RESET_KEEP
                                    248 	.globl _WAKE_CTRL
                                    249 	.globl _CLOCK_CFG
                                    250 	.globl _POWER_CFG
                                    251 	.globl _PCON
                                    252 	.globl _GLOBAL_CFG
                                    253 	.globl _SAFE_MOD
                                    254 	.globl _DPH
                                    255 	.globl _DPL
                                    256 	.globl _SP
                                    257 	.globl _A_INV
                                    258 	.globl _B
                                    259 	.globl _ACC
                                    260 	.globl _PSW
                                    261 	.globl _actual_keyboard_report
                                    262 	.globl _owned_usage_key_PARM_2
                                    263 	.globl _ak820_macro_change_PARM_3
                                    264 	.globl _ak820_macro_change_PARM_2
                                    265 	.globl _ak820_macro_cancelled
                                    266 	.globl _ak820_macro_primitive
                                    267 	.globl _ak820_gui_process_PARM_2
                                    268 	.globl _ak820_mac_mode
                                    269 	.globl _ak820_gui_process
                                    270 	.globl _ak820_macro_change
                                    271 	.globl _add_owned_mods
                                    272 	.globl _del_owned_mods
                                    273 	.globl _add_owned_weak_mods
                                    274 	.globl _del_owned_weak_mods
                                    275 	.globl _clear_owned_mods
                                    276 	.globl _clear_owned_keys
                                    277 	.globl _add_owned_key
                                    278 	.globl _del_owned_key
                                    279 	.globl _clear_owned_usages
                                    280 	.globl _owned_usage_key
                                    281 	.globl _send_keyboard_report
                                    282 	.globl _get_mods
                                    283 	.globl _clear_mods
                                    284 	.globl _get_weak_mods
                                    285 	.globl _add_weak_mods
                                    286 	.globl _del_weak_mods
                                    287 	.globl _clear_weak_mods
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
                                    550 ;--------------------------------------------------------
                                    551 ; overlayable items in internal ram
                                    552 ;--------------------------------------------------------
                                    553 	.area	OSEG    (OVR,DATA)
      000054                        554 _change_owned_sloc1_1_0:
      000054                        555 	.ds 1
                                    556 ;--------------------------------------------------------
                                    557 ; indirectly addressable internal ram data
                                    558 ;--------------------------------------------------------
                                    559 	.area ISEG    (DATA)
                                    560 ;--------------------------------------------------------
                                    561 ; absolute internal ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area IABS    (ABS,DATA)
                                    564 	.area IABS    (ABS,DATA)
                                    565 ;--------------------------------------------------------
                                    566 ; bit data
                                    567 ;--------------------------------------------------------
                                    568 	.area BSEG    (BIT)
      000020                        569 _ak820_mac_mode::
      000020                        570 	.ds 1
      000021                        571 _ak820_gui_process_sloc0_1_0:
      000021                        572 	.ds 1
      000022                        573 _ak820_macro_change_sloc0_1_0:
      000022                        574 	.ds 1
      000023                        575 _change_owned_sloc0_1_0:
      000023                        576 	.ds 1
      000024                        577 _owned_usage_key_sloc0_1_0:
      000024                        578 	.ds 1
                                    579 ;--------------------------------------------------------
                                    580 ; paged external ram data
                                    581 ;--------------------------------------------------------
                                    582 	.area PSEG    (PAG,XDATA)
                                    583 ;--------------------------------------------------------
                                    584 ; uninitialized external ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area XSEG    (XDATA)
      000978                        587 _ak820_gui_process_PARM_2:
      000978                        588 	.ds 1
      000979                        589 _ak820_gui_process_code_10000_294:
      000979                        590 	.ds 2
      00097B                        591 _owned_mod_refs:
      00097B                        592 	.ds 8
      000983                        593 _owned_weak_refs:
      000983                        594 	.ds 8
      00098B                        595 _owned_mods:
      00098B                        596 	.ds 1
      00098C                        597 _owned_weak_mods:
      00098C                        598 	.ds 1
      00098D                        599 _macro_mods:
      00098D                        600 	.ds 2
      00098F                        601 _ak820_macro_primitive::
      00098F                        602 	.ds 1
      000990                        603 _ak820_macro_cancelled::
      000990                        604 	.ds 1
      000991                        605 _ak820_macro_change_PARM_2:
      000991                        606 	.ds 1
      000992                        607 _ak820_macro_change_PARM_3:
      000992                        608 	.ds 1
      000993                        609 _ak820_macro_change_bits_10000_300:
      000993                        610 	.ds 2
      000995                        611 _change_owned_PARM_2:
      000995                        612 	.ds 1
      000996                        613 _change_owned_mods_10000_305:
      000996                        614 	.ds 1
      000997                        615 _change_owned_result_10001_309:
      000997                        616 	.ds 1
      000998                        617 _change_owned_bit_20001_310:
      000998                        618 	.ds 1
      000999                        619 _add_owned_mods_mods_10000_318:
      000999                        620 	.ds 1
      00099A                        621 _del_owned_mods_mods_10000_320:
      00099A                        622 	.ds 1
      00099B                        623 _add_owned_weak_mods_mods_10000_322:
      00099B                        624 	.ds 1
      00099C                        625 _del_owned_weak_mods_mods_10000_324:
      00099C                        626 	.ds 1
      00099D                        627 _key_refs:
      00099D                        628 	.ds 165
      000A42                        629 _distinct_keys:
      000A42                        630 	.ds 1
      000A43                        631 _macro_keys:
      000A43                        632 	.ds 21
      000A58                        633 _add_owned_key_code_10000_333:
      000A58                        634 	.ds 1
      000A59                        635 _del_owned_key_code_10000_348:
      000A59                        636 	.ds 1
      000A5A                        637 _usage_refs:
      000A5A                        638 	.ds 30
      000A78                        639 _usage_order:
      000A78                        640 	.ds 30
      000A96                        641 _usage_lengths:
      000A96                        642 	.ds 2
      000A98                        643 _macro_usages:
      000A98                        644 	.ds 4
      000A9C                        645 _owned_usage_key_PARM_2:
      000A9C                        646 	.ds 1
      000A9D                        647 _owned_usage_key_code_10000_375:
      000A9D                        648 	.ds 1
      000A9E                        649 _owned_usage_key___200000085_20000_376:
      000A9E                        650 	.ds 2
      000AA0                        651 _owned_usage_key_which_10000_376:
      000AA0                        652 	.ds 1
      000AA1                        653 _owned_usage_key_count_10000_376:
      000AA1                        654 	.ds 1
      000AA2                        655 _owned_usage_key_pos_30001_383:
      000AA2                        656 	.ds 1
      000AA3                        657 _owned_usage_key_key_40000_388:
      000AA3                        658 	.ds 1
      000AA4                        659 _send_keyboard_report_last_report_10001_397:
      000AA4                        660 	.ds 32
      000AC4                        661 _send_keyboard_report_changed_10001_397:
      000AC4                        662 	.ds 1
      000AC5                        663 _add_weak_mods_mods_10000_415:
      000AC5                        664 	.ds 1
      000AC6                        665 _del_weak_mods_mods_10000_417:
      000AC6                        666 	.ds 1
                                    667 ;--------------------------------------------------------
                                    668 ; absolute external ram data
                                    669 ;--------------------------------------------------------
                                    670 	.area XABS    (ABS,XDATA)
                                    671 ;--------------------------------------------------------
                                    672 ; initialized external ram data
                                    673 ;--------------------------------------------------------
                                    674 	.area XISEG   (XDATA)
      000DCC                        675 _real_mods:
      000DCC                        676 	.ds 1
      000DCD                        677 _weak_mods:
      000DCD                        678 	.ds 1
      000DCE                        679 _actual_keyboard_report::
      000DCE                        680 	.ds 32
                                    681 	.area HOME    (CODE)
                                    682 	.area GSINIT0 (CODE)
                                    683 	.area GSINIT1 (CODE)
                                    684 	.area GSINIT2 (CODE)
                                    685 	.area GSINIT3 (CODE)
                                    686 	.area GSINIT4 (CODE)
                                    687 	.area GSINIT5 (CODE)
                                    688 	.area GSINIT  (CODE)
                                    689 	.area GSFINAL (CODE)
                                    690 	.area CSEG    (CODE)
                                    691 ;--------------------------------------------------------
                                    692 ; global & static initialisations
                                    693 ;--------------------------------------------------------
                                    694 	.area HOME    (CODE)
                                    695 	.area GSINIT  (CODE)
                                    696 	.area GSFINAL (CODE)
                                    697 	.area GSINIT  (CODE)
                                    698 ;--------------------------------------------------------
                                    699 ; Home
                                    700 ;--------------------------------------------------------
                                    701 	.area HOME    (CODE)
                                    702 	.area HOME    (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; code
                                    705 ;--------------------------------------------------------
                                    706 	.area CSEG    (CODE)
                                    707 ;------------------------------------------------------------
                                    708 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    709 ;------------------------------------------------------------
                                    710 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    711 ;------------------------------------------------------------
                                    712 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    713 ;	-----------------------------------------
                           000007   714 	ar7 = 0x07
                           000006   715 	ar6 = 0x06
                           000005   716 	ar5 = 0x05
                           000004   717 	ar4 = 0x04
                           000003   718 	ar3 = 0x03
                           000002   719 	ar2 = 0x02
                           000001   720 	ar1 = 0x01
                           000000   721 	ar0 = 0x00
                                    722 ;	 function ak820_gui_process
                                    723 ;	-----------------------------------------
      007D61                        724 _ak820_gui_process:
      007D61 12 38 82         [24]  725 	lcall	_ak820_outline_0107
      007D64 90 09 79         [24]  726 	mov	dptr,#_ak820_gui_process_code_10000_294
      007D67 12 38 87         [24]  727 	lcall	_ak820_outline_0108
                                    728 ;	quantum/action_util.c:59: if (code == QK_MAGIC_SWAP_ALT_GUI || code == QK_MAGIC_UNSWAP_ALT_GUI || code == QK_MAGIC_TOGGLE_ALT_GUI) {
      007D6A 90 09 79         [24]  729 	mov	dptr,#_ak820_gui_process_code_10000_294
      007D6D 12 38 41         [24]  730 	lcall	_ak820_outline_0052
      007D70 E4               [12]  731 	clr	a
      007D71 BE 14 04         [24]  732 	cjne	r6,#0x14,00139$
      007D74 BF 70 01         [24]  733 	cjne	r7,#0x70,00139$
      007D77 04               [12]  734 	inc	a
      007D78                        735 00139$:
      007D78 FD               [12]  736 	mov	r5,a
      007D79 70 0E            [24]  737 	jnz	00103$
      007D7B BE 15 05         [24]  738 	cjne	r6,#0x15,00142$
      007D7E BF 70 02         [24]  739 	cjne	r7,#0x70,00142$
      007D81 80 06            [24]  740 	sjmp	00103$
      007D83                        741 00142$:
      007D83 BE 16 27         [24]  742 	cjne	r6,#0x16,00104$
      007D86 BF 70 24         [24]  743 	cjne	r7,#0x70,00104$
      007D89                        744 00103$:
                                    745 ;	quantum/action_util.c:60: if (pressed) {
      007D89 90 09 78         [24]  746 	mov	dptr,#_ak820_gui_process_PARM_2
      007D8C E0               [24]  747 	movx	a,@dptr
      007D8D 60 1A            [24]  748 	jz	00102$
                                    749 ;	quantum/action_util.c:61: ak820_mac_mode = code == QK_MAGIC_TOGGLE_ALT_GUI ? !ak820_mac_mode : code == QK_MAGIC_SWAP_ALT_GUI;
      007D8F BE 16 0D         [24]  750 	cjne	r6,#0x16,00109$
      007D92 BF 70 0A         [24]  751 	cjne	r7,#0x70,00109$
      007D95 A2 20            [12]  752 	mov	c,_ak820_mac_mode
      007D97 B3               [12]  753 	cpl	c
      007D98 92 21            [24]  754 	mov  _ak820_gui_process_sloc0_1_0,c
      007D9A E4               [12]  755 	clr	a
      007D9B 33               [12]  756 	rlc	a
      007D9C FF               [12]  757 	mov	r7,a
      007D9D 80 02            [24]  758 	sjmp	00110$
      007D9F                        759 00109$:
      007D9F 8D 07            [24]  760 	mov	ar7,r5
      007DA1                        761 00110$:
                                    762 ;	assignBit
      007DA1 EF               [12]  763 	mov	a,r7
      007DA2 24 FF            [12]  764 	add	a,#0xff
      007DA4 92 20            [24]  765 	mov	_ak820_mac_mode,c
                                    766 ;	quantum/action_util.c:62: send_keyboard_report();
      007DA6 12 82 26         [24]  767 	lcall	_send_keyboard_report
      007DA9                        768 00102$:
                                    769 ;	quantum/action_util.c:64: return false;
      007DA9 75 82 00         [24]  770 	mov	dpl, #0x00
      007DAC 22               [24]  771 	ret
      007DAD                        772 00104$:
                                    773 ;	quantum/action_util.c:84: return true;
      007DAD 75 82 01         [24]  774 	mov	dpl, #0x01
                                    775 ;	quantum/action_util.c:86: }
      007DB0 22               [24]  776 	ret
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'ak820_macro_change'
                                    779 ;------------------------------------------------------------
                                    780 ;index         Allocated with name '_ak820_macro_change_PARM_2'
                                    781 ;pressed       Allocated with name '_ak820_macro_change_PARM_3'
                                    782 ;bits          Allocated with name '_ak820_macro_change_bits_10000_300'
                                    783 ;mask          Allocated with name '_ak820_macro_change_mask_10001_303'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/action_util.c:95: bool ak820_macro_change(uint8_t AK820_STATE_MEM *bits, uint8_t index, bool pressed) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function ak820_macro_change
                                    788 ;	-----------------------------------------
      007DB1                        789 _ak820_macro_change:
      007DB1 12 38 82         [24]  790 	lcall	_ak820_outline_0107
      007DB4 90 09 93         [24]  791 	mov	dptr,#_ak820_macro_change_bits_10000_300
      007DB7 12 38 87         [24]  792 	lcall	_ak820_outline_0108
                                    793 ;	quantum/action_util.c:96: if (!ak820_macro_primitive) return true;
      007DBA 90 09 8F         [24]  794 	mov	dptr,#_ak820_macro_primitive
      007DBD E0               [24]  795 	movx	a,@dptr
      007DBE 70 04            [24]  796 	jnz	00102$
      007DC0 75 82 01         [24]  797 	mov	dpl, #0x01
      007DC3 22               [24]  798 	ret
      007DC4                        799 00102$:
                                    800 ;	quantum/action_util.c:97: uint8_t mask = 1u << (index & 7);
      007DC4 90 09 91         [24]  801 	mov	dptr,#_ak820_macro_change_PARM_2
      007DC7 E0               [24]  802 	movx	a,@dptr
      007DC8 FF               [12]  803 	mov	r7,a
      007DC9 74 07            [12]  804 	mov	a,#0x07
      007DCB 5F               [12]  805 	anl	a,r7
      007DCC 12 78 F3         [24]  806 	lcall	_ak820_outline_0062
      007DCF 80 02            [24]  807 	sjmp	00123$
      007DD1                        808 00122$:
      007DD1 25 E0            [12]  809 	add	a,acc
      007DD3                        810 00123$:
      007DD3 D5 F0 FB         [24]  811 	djnz	b,00122$
      007DD6 FE               [12]  812 	mov	r6,a
                                    813 ;	quantum/action_util.c:98: bits += index >> 3;
      007DD7 EF               [12]  814 	mov	a,r7
      007DD8 12 58 86         [24]  815 	lcall	_ak820_outline_0188
      007DDB FF               [12]  816 	mov	r7,a
      007DDC 90 09 93         [24]  817 	mov	dptr,#_ak820_macro_change_bits_10000_300
      007DDF 12 38 58         [24]  818 	lcall	_ak820_outline_0060
      007DE2 90 09 93         [24]  819 	mov	dptr,#_ak820_macro_change_bits_10000_300
      007DE5 EF               [12]  820 	mov	a,r7
      007DE6 2C               [12]  821 	add	a, r4
      007DE7 F0               [24]  822 	movx	@dptr,a
      007DE8 E4               [12]  823 	clr	a
      007DE9 3D               [12]  824 	addc	a, r5
      007DEA A3               [24]  825 	inc	dptr
      007DEB F0               [24]  826 	movx	@dptr,a
                                    827 ;	quantum/action_util.c:99: if (((*bits & mask) != 0) == pressed) return false;
      007DEC 90 09 93         [24]  828 	mov	dptr,#_ak820_macro_change_bits_10000_300
      007DEF E0               [24]  829 	movx	a,@dptr
      007DF0 FD               [12]  830 	mov	r5,a
      007DF1 A3               [24]  831 	inc	dptr
      007DF2 E0               [24]  832 	movx	a,@dptr
      007DF3 FF               [12]  833 	mov	r7,a
      007DF4 12 83 5D         [24]  834 	lcall	_ak820_outline_0190
      007DF7 E0               [24]  835 	movx	a,@dptr
      007DF8 FC               [12]  836 	mov	r4,a
      007DF9 EE               [12]  837 	mov	a,r6
      007DFA 5C               [12]  838 	anl	a,r4
      007DFB B4 01 00         [24]  839 	cjne	a,#0x01,00124$
      007DFE                        840 00124$:
      007DFE B3               [12]  841 	cpl	c
      007DFF 92 22            [24]  842 	mov	_ak820_macro_change_sloc0_1_0,c
      007E01 90 09 92         [24]  843 	mov	dptr,#_ak820_macro_change_PARM_3
      007E04 E0               [24]  844 	movx	a,@dptr
      007E05 FB               [12]  845 	mov	r3,a
      007E06 A2 22            [12]  846 	mov	c,_ak820_macro_change_sloc0_1_0
      007E08 E4               [12]  847 	clr	a
      007E09 33               [12]  848 	rlc	a
      007E0A B5 03 04         [24]  849 	cjne	a,ar3,00104$
      007E0D 75 82 00         [24]  850 	mov	dpl, #0x00
      007E10 22               [24]  851 	ret
      007E11                        852 00104$:
                                    853 ;	quantum/action_util.c:100: *bits ^= mask;
      007E11 EC               [12]  854 	mov	a,r4
      007E12 62 06            [12]  855 	xrl	ar6,a
      007E14 12 83 5D         [24]  856 	lcall	_ak820_outline_0190
      007E17 EE               [12]  857 	mov	a,r6
      007E18 F0               [24]  858 	movx	@dptr,a
                                    859 ;	quantum/action_util.c:101: return true;
      007E19 75 82 01         [24]  860 	mov	dpl, #0x01
                                    861 ;	quantum/action_util.c:102: }
      007E1C 22               [24]  862 	ret
                                    863 ;------------------------------------------------------------
                                    864 ;Allocation info for local variables in function 'change_owned'
                                    865 ;------------------------------------------------------------
                                    866 ;mode          Allocated with name '_change_owned_PARM_2'
                                    867 ;mods          Allocated with name '_change_owned_mods_10000_305'
                                    868 ;kind          Allocated with name '_change_owned_kind_10000_306'
                                    869 ;pressed       Allocated with name '_change_owned_pressed_10000_306'
                                    870 ;refs          Allocated with name '_change_owned_refs_10000_306'
                                    871 ;old           Allocated with name '_change_owned_old_30000_308'
                                    872 ;result        Allocated with name '_change_owned_result_10001_309'
                                    873 ;i             Allocated with name '_change_owned_i_20001_310'
                                    874 ;bit           Allocated with name '_change_owned_bit_20001_310'
                                    875 ;sloc1         Allocated with name '_change_owned_sloc1_1_0'
                                    876 ;------------------------------------------------------------
                                    877 ;	quantum/action_util.c:103: static void change_owned(uint8_t mods, uint8_t mode) {
                                    878 ;	-----------------------------------------
                                    879 ;	 function change_owned
                                    880 ;	-----------------------------------------
      007E1D                        881 _change_owned:
      007E1D E5 82            [12]  882 	mov	a,dpl
      007E1F 90 09 96         [24]  883 	mov	dptr,#_change_owned_mods_10000_305
      007E22 F0               [24]  884 	movx	@dptr,a
                                    885 ;	quantum/action_util.c:104: uint8_t kind = mode >> 1;
      007E23 90 09 95         [24]  886 	mov	dptr,#_change_owned_PARM_2
      007E26 E0               [24]  887 	movx	a,@dptr
      007E27 FF               [12]  888 	mov	r7,a
      007E28 C3               [12]  889 	clr	c
      007E29 13               [12]  890 	rrc	a
      007E2A FE               [12]  891 	mov	r6,a
                                    892 ;	quantum/action_util.c:105: bool pressed = (mode & 1) != 0;
      007E2B 53 07 01         [24]  893 	anl	ar7,#0x01
      007E2E EF               [12]  894 	mov	a,r7
      007E2F B4 01 00         [24]  895 	cjne	a,#0x01,00205$
      007E32                        896 00205$:
      007E32 92 23            [24]  897 	mov  _change_owned_sloc0_1_0,c
      007E34 B3               [12]  898 	cpl	c
      007E35 E4               [12]  899 	clr	a
      007E36 33               [12]  900 	rlc	a
      007E37 F5 54            [12]  901 	mov	_change_owned_sloc1_1_0,a
                                    902 ;	quantum/action_util.c:106: uint8_t AK820_STATE_MEM *refs = kind ? owned_weak_refs : owned_mod_refs;
      007E39 EE               [12]  903 	mov	a,r6
      007E3A 60 06            [24]  904 	jz	00121$
      007E3C 7D 83            [12]  905 	mov	r5,#_owned_weak_refs
      007E3E 7F 09            [12]  906 	mov	r7,#(_owned_weak_refs >> 8)
      007E40 80 04            [24]  907 	sjmp	00122$
      007E42                        908 00121$:
      007E42 7D 7B            [12]  909 	mov	r5,#_owned_mod_refs
      007E44 7F 09            [12]  910 	mov	r7,#(_owned_mod_refs >> 8)
      007E46                        911 00122$:
                                    912 ;	quantum/action_util.c:107: if (ak820_macro_primitive) {
      007E46 90 09 8F         [24]  913 	mov	dptr,#_ak820_macro_primitive
      007E49 E0               [24]  914 	movx	a,@dptr
      007E4A 60 36            [24]  915 	jz	00102$
                                    916 ;	quantum/action_util.c:108: uint8_t old = macro_mods[kind];
      007E4C EE               [12]  917 	mov	a,r6
      007E4D 24 8D            [12]  918 	add	a, #_macro_mods
      007E4F FB               [12]  919 	mov	r3,a
      007E50 E4               [12]  920 	clr	a
      007E51 34 09            [12]  921 	addc	a, #(_macro_mods >> 8)
      007E53 12 49 CB         [24]  922 	lcall	_ak820_outline_0056
                                    923 ;	quantum/action_util.c:109: macro_mods[kind] = pressed ? old | mods : old & ~mods;
      007E56 E5 54            [12]  924 	mov	a,_change_owned_sloc1_1_0
      007E58 60 0A            [24]  925 	jz	00123$
      007E5A 90 09 96         [24]  926 	mov	dptr,#_change_owned_mods_10000_305
      007E5D E0               [24]  927 	movx	a,@dptr
      007E5E F9               [12]  928 	mov	r1,a
      007E5F EA               [12]  929 	mov	a,r2
      007E60 42 01            [12]  930 	orl	ar1,a
      007E62 80 07            [24]  931 	sjmp	00124$
      007E64                        932 00123$:
      007E64 90 09 96         [24]  933 	mov	dptr,#_change_owned_mods_10000_305
      007E67 E0               [24]  934 	movx	a,@dptr
      007E68 F4               [12]  935 	cpl	a
      007E69 5A               [12]  936 	anl	a,r2
      007E6A F9               [12]  937 	mov	r1,a
      007E6B                        938 00124$:
      007E6B 12 33 FC         [24]  939 	lcall	_ak820_outline_0121
      007E6E E9               [12]  940 	mov	a,r1
      007E6F F0               [24]  941 	movx	@dptr,a
                                    942 ;	quantum/action_util.c:110: mods &= pressed ? ~old : old;
      007E70 E5 54            [12]  943 	mov	a,_change_owned_sloc1_1_0
      007E72 60 06            [24]  944 	jz	00125$
      007E74 74 FF            [12]  945 	mov	a,#0xff
      007E76 6A               [12]  946 	xrl	a,r2
      007E77 FC               [12]  947 	mov	r4,a
      007E78 80 02            [24]  948 	sjmp	00126$
      007E7A                        949 00125$:
      007E7A 8A 04            [24]  950 	mov	ar4,r2
      007E7C                        951 00126$:
      007E7C 90 09 96         [24]  952 	mov	dptr,#_change_owned_mods_10000_305
      007E7F E0               [24]  953 	movx	a,@dptr
      007E80 5C               [12]  954 	anl	a,r4
      007E81 F0               [24]  955 	movx	@dptr,a
      007E82                        956 00102$:
                                    957 ;	quantum/action_util.c:112: uint8_t result = 0;
      007E82 90 09 97         [24]  958 	mov	dptr,#_change_owned_result_10001_309
      007E85 E4               [12]  959 	clr	a
      007E86 F0               [24]  960 	movx	@dptr,a
                                    961 ;	quantum/action_util.c:113: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007E87 90 09 98         [24]  962 	mov	dptr,#_change_owned_bit_20001_310
      007E8A 04               [12]  963 	inc	a
      007E8B F0               [24]  964 	movx	@dptr,a
      007E8C 90 09 96         [24]  965 	mov	dptr,#_change_owned_mods_10000_305
      007E8F E0               [24]  966 	movx	a,@dptr
      007E90 FC               [12]  967 	mov	r4,a
      007E91 7B 00            [12]  968 	mov	r3,#0x00
      007E93                        969 00117$:
      007E93 BB 08 00         [24]  970 	cjne	r3,#0x08,00210$
      007E96                        971 00210$:
      007E96 50 3F            [24]  972 	jnc	00112$
                                    973 ;	quantum/action_util.c:114: if (mods & bit) {
      007E98 90 09 98         [24]  974 	mov	dptr,#_change_owned_bit_20001_310
      007E9B E0               [24]  975 	movx	a,@dptr
      007E9C 5C               [12]  976 	anl	a,r4
      007E9D 60 1C            [24]  977 	jz	00109$
                                    978 ;	quantum/action_util.c:115: if (pressed) ++refs[i];
      007E9F E5 54            [12]  979 	mov	a,_change_owned_sloc1_1_0
      007EA1 60 0C            [24]  980 	jz	00106$
      007EA3 EB               [12]  981 	mov	a,r3
      007EA4 2D               [12]  982 	add	a, r5
      007EA5 12 38 1F         [24]  983 	lcall	_ak820_outline_0017
      007EA8 F8               [12]  984 	mov	r0,a
      007EA9 08               [12]  985 	inc	r0
      007EAA 12 83 11         [24]  986 	lcall	_ak820_outline_0063
      007EAD 80 0C            [24]  987 	sjmp	00109$
      007EAF                        988 00106$:
                                    989 ;	quantum/action_util.c:116: else if (refs[i]) --refs[i];
      007EAF EB               [12]  990 	mov	a,r3
      007EB0 2D               [12]  991 	add	a, r5
      007EB1 12 38 1F         [24]  992 	lcall	_ak820_outline_0017
      007EB4 F8               [12]  993 	mov	r0,a
      007EB5 60 04            [24]  994 	jz	00109$
      007EB7 18               [12]  995 	dec	r0
      007EB8 12 83 11         [24]  996 	lcall	_ak820_outline_0063
      007EBB                        997 00109$:
                                    998 ;	quantum/action_util.c:118: if (refs[i]) result |= bit;
      007EBB EB               [12]  999 	mov	a,r3
      007EBC 2D               [12] 1000 	add	a, r5
      007EBD 12 38 1F         [24] 1001 	lcall	_ak820_outline_0017
      007EC0 60 0B            [24] 1002 	jz	00118$
      007EC2 90 09 98         [24] 1003 	mov	dptr,#_change_owned_bit_20001_310
      007EC5 E0               [24] 1004 	movx	a,@dptr
      007EC6 FA               [12] 1005 	mov	r2,a
      007EC7 90 09 97         [24] 1006 	mov	dptr,#_change_owned_result_10001_309
      007ECA E0               [24] 1007 	movx	a,@dptr
      007ECB 4A               [12] 1008 	orl	a,r2
      007ECC F0               [24] 1009 	movx	@dptr,a
      007ECD                       1010 00118$:
                                   1011 ;	quantum/action_util.c:113: for (uint8_t i = 0, bit = 1; i < 8; ++i, bit <<= 1) {
      007ECD 0B               [12] 1012 	inc	r3
      007ECE 90 09 98         [24] 1013 	mov	dptr,#_change_owned_bit_20001_310
      007ED1 E0               [24] 1014 	movx	a,@dptr
      007ED2 25 E0            [12] 1015 	add	a,acc
      007ED4 F0               [24] 1016 	movx	@dptr,a
      007ED5 80 BC            [24] 1017 	sjmp	00117$
      007ED7                       1018 00112$:
                                   1019 ;	quantum/action_util.c:120: if (kind) owned_weak_mods = result;
      007ED7 EE               [12] 1020 	mov	a,r6
      007ED8 60 09            [24] 1021 	jz	00114$
      007EDA 90 09 97         [24] 1022 	mov	dptr,#_change_owned_result_10001_309
      007EDD E0               [24] 1023 	movx	a,@dptr
      007EDE 90 09 8C         [24] 1024 	mov	dptr,#_owned_weak_mods
      007EE1 F0               [24] 1025 	movx	@dptr,a
      007EE2 22               [24] 1026 	ret
      007EE3                       1027 00114$:
                                   1028 ;	quantum/action_util.c:121: else owned_mods = result;
      007EE3 90 09 97         [24] 1029 	mov	dptr,#_change_owned_result_10001_309
      007EE6 E0               [24] 1030 	movx	a,@dptr
      007EE7 90 09 8B         [24] 1031 	mov	dptr,#_owned_mods
      007EEA F0               [24] 1032 	movx	@dptr,a
                                   1033 ;	quantum/action_util.c:122: }
      007EEB 22               [24] 1034 	ret
                                   1035 ;------------------------------------------------------------
                                   1036 ;Allocation info for local variables in function 'add_owned_mods'
                                   1037 ;------------------------------------------------------------
                                   1038 ;mods          Allocated with name '_add_owned_mods_mods_10000_318'
                                   1039 ;------------------------------------------------------------
                                   1040 ;	quantum/action_util.c:123: void add_owned_mods(uint8_t mods) { change_owned(mods, 1); }
                                   1041 ;	-----------------------------------------
                                   1042 ;	 function add_owned_mods
                                   1043 ;	-----------------------------------------
      007EEC                       1044 _add_owned_mods:
      007EEC E5 82            [12] 1045 	mov	a,dpl
      007EEE 90 09 99         [24] 1046 	mov	dptr,#_add_owned_mods_mods_10000_318
      007EF1 12 83 31         [24] 1047 	lcall	_ak820_outline_0117
      007EF4 74 01            [12] 1048 	mov	a,#0x01
      007EF6 F0               [24] 1049 	movx	@dptr,a
      007EF7 8F 82            [24] 1050 	mov	dpl, r7
      007EF9 02 7E 1D         [24] 1051 	ljmp	_change_owned
                                   1052 ;------------------------------------------------------------
                                   1053 ;Allocation info for local variables in function 'del_owned_mods'
                                   1054 ;------------------------------------------------------------
                                   1055 ;mods          Allocated with name '_del_owned_mods_mods_10000_320'
                                   1056 ;------------------------------------------------------------
                                   1057 ;	quantum/action_util.c:124: void del_owned_mods(uint8_t mods) { change_owned(mods, 0); }
                                   1058 ;	-----------------------------------------
                                   1059 ;	 function del_owned_mods
                                   1060 ;	-----------------------------------------
      007EFC                       1061 _del_owned_mods:
      007EFC E5 82            [12] 1062 	mov	a,dpl
      007EFE 90 09 9A         [24] 1063 	mov	dptr,#_del_owned_mods_mods_10000_320
      007F01 12 83 31         [24] 1064 	lcall	_ak820_outline_0117
      007F04 E4               [12] 1065 	clr	a
      007F05 F0               [24] 1066 	movx	@dptr,a
      007F06 8F 82            [24] 1067 	mov	dpl, r7
      007F08 02 7E 1D         [24] 1068 	ljmp	_change_owned
                                   1069 ;------------------------------------------------------------
                                   1070 ;Allocation info for local variables in function 'add_owned_weak_mods'
                                   1071 ;------------------------------------------------------------
                                   1072 ;mods          Allocated with name '_add_owned_weak_mods_mods_10000_322'
                                   1073 ;------------------------------------------------------------
                                   1074 ;	quantum/action_util.c:125: void add_owned_weak_mods(uint8_t mods) { change_owned(mods, 3); }
                                   1075 ;	-----------------------------------------
                                   1076 ;	 function add_owned_weak_mods
                                   1077 ;	-----------------------------------------
      007F0B                       1078 _add_owned_weak_mods:
      007F0B E5 82            [12] 1079 	mov	a,dpl
      007F0D 90 09 9B         [24] 1080 	mov	dptr,#_add_owned_weak_mods_mods_10000_322
      007F10 12 83 31         [24] 1081 	lcall	_ak820_outline_0117
      007F13 74 03            [12] 1082 	mov	a,#0x03
      007F15 F0               [24] 1083 	movx	@dptr,a
      007F16 8F 82            [24] 1084 	mov	dpl, r7
      007F18 02 7E 1D         [24] 1085 	ljmp	_change_owned
                                   1086 ;------------------------------------------------------------
                                   1087 ;Allocation info for local variables in function 'del_owned_weak_mods'
                                   1088 ;------------------------------------------------------------
                                   1089 ;mods          Allocated with name '_del_owned_weak_mods_mods_10000_324'
                                   1090 ;------------------------------------------------------------
                                   1091 ;	quantum/action_util.c:126: void del_owned_weak_mods(uint8_t mods) { change_owned(mods, 2); }
                                   1092 ;	-----------------------------------------
                                   1093 ;	 function del_owned_weak_mods
                                   1094 ;	-----------------------------------------
      007F1B                       1095 _del_owned_weak_mods:
      007F1B E5 82            [12] 1096 	mov	a,dpl
      007F1D 90 09 9C         [24] 1097 	mov	dptr,#_del_owned_weak_mods_mods_10000_324
      007F20 12 83 31         [24] 1098 	lcall	_ak820_outline_0117
      007F23 74 02            [12] 1099 	mov	a,#0x02
      007F25 F0               [24] 1100 	movx	@dptr,a
      007F26 8F 82            [24] 1101 	mov	dpl, r7
      007F28 02 7E 1D         [24] 1102 	ljmp	_change_owned
                                   1103 ;------------------------------------------------------------
                                   1104 ;Allocation info for local variables in function 'clear_owned_mods'
                                   1105 ;------------------------------------------------------------
                                   1106 ;i             Allocated with name '_clear_owned_mods_i_20000_328'
                                   1107 ;------------------------------------------------------------
                                   1108 ;	quantum/action_util.c:127: void clear_owned_mods(void) {
                                   1109 ;	-----------------------------------------
                                   1110 ;	 function clear_owned_mods
                                   1111 ;	-----------------------------------------
      007F2B                       1112 _clear_owned_mods:
                                   1113 ;	quantum/action_util.c:128: for (uint8_t i = 0; i < 8; ++i) owned_mod_refs[i] = owned_weak_refs[i] = 0;
      007F2B 7F 00            [12] 1114 	mov	r7,#0x00
      007F2D                       1115 00103$:
      007F2D BF 08 00         [24] 1116 	cjne	r7,#0x08,00122$
      007F30                       1117 00122$:
      007F30 50 1A            [24] 1118 	jnc	00101$
      007F32 EF               [12] 1119 	mov	a,r7
      007F33 24 7B            [12] 1120 	add	a, #_owned_mod_refs
      007F35 FD               [12] 1121 	mov	r5,a
      007F36 E4               [12] 1122 	clr	a
      007F37 34 09            [12] 1123 	addc	a, #(_owned_mod_refs >> 8)
      007F39 FE               [12] 1124 	mov	r6,a
      007F3A EF               [12] 1125 	mov	a,r7
      007F3B 24 83            [12] 1126 	add	a, #_owned_weak_refs
      007F3D F5 82            [12] 1127 	mov	dpl,a
      007F3F E4               [12] 1128 	clr	a
      007F40 34 09            [12] 1129 	addc	a, #(_owned_weak_refs >> 8)
      007F42 F5 83            [12] 1130 	mov	dph,a
      007F44 E4               [12] 1131 	clr	a
      007F45 F0               [24] 1132 	movx	@dptr,a
      007F46 12 83 38         [24] 1133 	lcall	_ak820_outline_0122
      007F49 0F               [12] 1134 	inc	r7
      007F4A 80 E1            [24] 1135 	sjmp	00103$
      007F4C                       1136 00101$:
                                   1137 ;	quantum/action_util.c:129: owned_mods = owned_weak_mods = macro_mods[0] = macro_mods[1] = 0;
      007F4C 90 09 8E         [24] 1138 	mov	dptr,#(_macro_mods + 0x0001)
      007F4F E4               [12] 1139 	clr	a
      007F50 F0               [24] 1140 	movx	@dptr,a
      007F51 90 09 8D         [24] 1141 	mov	dptr,#_macro_mods
      007F54 F0               [24] 1142 	movx	@dptr,a
      007F55 90 09 8C         [24] 1143 	mov	dptr,#_owned_weak_mods
      007F58 F0               [24] 1144 	movx	@dptr,a
      007F59 90 09 8B         [24] 1145 	mov	dptr,#_owned_mods
      007F5C F0               [24] 1146 	movx	@dptr,a
                                   1147 ;	quantum/action_util.c:130: ak820_macro_cancelled = true;
      007F5D 90 09 90         [24] 1148 	mov	dptr,#_ak820_macro_cancelled
      007F60 04               [12] 1149 	inc	a
      007F61 F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	quantum/action_util.c:131: }
      007F62 22               [24] 1152 	ret
                                   1153 ;------------------------------------------------------------
                                   1154 ;Allocation info for local variables in function 'clear_owned_keys'
                                   1155 ;------------------------------------------------------------
                                   1156 ;i             Allocated with name '_clear_owned_keys_i_20000_331'
                                   1157 ;i             Allocated with name '_clear_owned_keys_i_20000_332'
                                   1158 ;------------------------------------------------------------
                                   1159 ;	quantum/action_util.c:137: void clear_owned_keys(void) {
                                   1160 ;	-----------------------------------------
                                   1161 ;	 function clear_owned_keys
                                   1162 ;	-----------------------------------------
      007F63                       1163 _clear_owned_keys:
                                   1164 ;	quantum/action_util.c:138: for (uint8_t i = 0; i <= KC_EXSEL; ++i) key_refs[i] = 0;
      007F63 7F 00            [12] 1165 	mov	r7,#0x00
      007F65                       1166 00104$:
      007F65 EF               [12] 1167 	mov	a,r7
      007F66 24 5B            [12] 1168 	add	a,#0xff - 0xa4
      007F68 40 0D            [24] 1169 	jc	00101$
                                   1170 ;	free result
      007F6A EF               [12] 1171 	mov	a,r7
      007F6B 24 9D            [12] 1172 	add	a, #_key_refs
      007F6D F5 82            [12] 1173 	mov	dpl,a
      007F6F E4               [12] 1174 	clr	a
      007F70 34 09            [12] 1175 	addc	a, #(_key_refs >> 8)
      007F72 12 7D 52         [24] 1176 	lcall	_ak820_outline_0163
      007F75 80 EE            [24] 1177 	sjmp	00104$
      007F77                       1178 00101$:
                                   1179 ;	quantum/action_util.c:139: distinct_keys = 0;
      007F77 90 0A 42         [24] 1180 	mov	dptr,#_distinct_keys
      007F7A E4               [12] 1181 	clr	a
      007F7B F0               [24] 1182 	movx	@dptr,a
                                   1183 ;	quantum/action_util.c:140: for (uint8_t i = 0; i < sizeof(macro_keys); ++i) macro_keys[i] = 0;
      007F7C FF               [12] 1184 	mov	r7,a
      007F7D                       1185 00107$:
      007F7D BF 15 00         [24] 1186 	cjne	r7,#0x15,00142$
      007F80                       1187 00142$:
      007F80 50 0D            [24] 1188 	jnc	00109$
      007F82 EF               [12] 1189 	mov	a,r7
      007F83 24 43            [12] 1190 	add	a, #_macro_keys
      007F85 F5 82            [12] 1191 	mov	dpl,a
      007F87 E4               [12] 1192 	clr	a
      007F88 34 0A            [12] 1193 	addc	a, #(_macro_keys >> 8)
      007F8A 12 7D 52         [24] 1194 	lcall	_ak820_outline_0163
      007F8D 80 EE            [24] 1195 	sjmp	00107$
      007F8F                       1196 00109$:
                                   1197 ;	quantum/action_util.c:141: }
      007F8F 22               [24] 1198 	ret
                                   1199 ;------------------------------------------------------------
                                   1200 ;Allocation info for local variables in function 'add_owned_key'
                                   1201 ;------------------------------------------------------------
                                   1202 ;code          Allocated with name '_add_owned_key_code_10000_333'
                                   1203 ;__400000074   Allocated with name '_add_owned_key___400000074_40000_342'
                                   1204 ;key           Allocated with name '_add_owned_key_key_50000_343'
                                   1205 ;i             Allocated with name '_add_owned_key_i_40000_341'
                                   1206 ;__300000076   Allocated with name '_add_owned_key___300000076_30000_345'
                                   1207 ;key           Allocated with name '_add_owned_key_key_40000_346'
                                   1208 ;------------------------------------------------------------
                                   1209 ;	quantum/action_util.c:142: bool add_owned_key(uint8_t code) {
                                   1210 ;	-----------------------------------------
                                   1211 ;	 function add_owned_key
                                   1212 ;	-----------------------------------------
      007F90                       1213 _add_owned_key:
      007F90 E5 82            [12] 1214 	mov	a,dpl
      007F92 90 0A 58         [24] 1215 	mov	dptr,#_add_owned_key_code_10000_333
      007F95 12 83 49         [24] 1216 	lcall	_ak820_outline_0132
                                   1217 ;	quantum/action_util.c:143: if (!ak820_macro_change(macro_keys, code, true)) return false;
      007F98 74 01            [12] 1218 	mov	a,#0x01
      007F9A F0               [24] 1219 	movx	@dptr,a
      007F9B 90 0A 43         [24] 1220 	mov	dptr,#_macro_keys
      007F9E C0 07            [24] 1221 	push	ar7
      007FA0 12 7D B1         [24] 1222 	lcall	_ak820_macro_change
      007FA3 E5 82            [12] 1223 	mov	a, dpl
      007FA5 D0 07            [24] 1224 	pop	ar7
      007FA7 70 03            [24] 1225 	jnz	00102$
      007FA9 F5 82            [12] 1226 	mov	dpl,a
      007FAB 22               [24] 1227 	ret
      007FAC                       1228 00102$:
                                   1229 ;	quantum/action_util.c:144: if (key_refs[code]++) return false;
      007FAC 12 83 03         [24] 1230 	lcall	_ak820_outline_0031
      007FAF FC               [12] 1231 	mov	r4,a
      007FB0 04               [12] 1232 	inc	a
      007FB1 12 83 38         [24] 1233 	lcall	_ak820_outline_0122
      007FB4 EC               [12] 1234 	mov	a,r4
      007FB5 60 04            [24] 1235 	jz	00104$
      007FB7 75 82 00         [24] 1236 	mov	dpl, #0x00
      007FBA 22               [24] 1237 	ret
      007FBB                       1238 00104$:
                                   1239 ;	quantum/action_util.c:145: ++distinct_keys;
      007FBB 90 0A 42         [24] 1240 	mov	dptr,#_distinct_keys
      007FBE E0               [24] 1241 	movx	a,@dptr
      007FBF 24 01            [12] 1242 	add	a, #0x01
      007FC1 F0               [24] 1243 	movx	@dptr,a
                                   1244 ;	quantum/action_util.c:147: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007FC2 90 0D BB         [24] 1245 	mov	dptr,#_keyboard_protocol
      007FC5 E0               [24] 1246 	movx	a,@dptr
      007FC6 60 11            [24] 1247 	jz	00106$
      007FC8 90 0A C7         [24] 1248 	mov	dptr,#_keymap_config
      007FCB E0               [24] 1249 	movx	a,@dptr
      007FCC 30 E7 0A         [24] 1250 	jnb	acc.7,00106$
                                   1251 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007FCF 12 83 54         [24] 1252 	lcall	_ak820_outline_0175
      007FD2 12 70 D8         [24] 1253 	lcall	_add_key_to_report
                                   1254 ;	quantum/action_util.c:147: if (keyboard_protocol && keymap_config.nkro) { add_key(code); return true; }
      007FD5 75 82 01         [24] 1255 	mov	dpl, #0x01
      007FD8 22               [24] 1256 	ret
      007FD9                       1257 00106$:
                                   1258 ;	quantum/action_util.c:149: if (distinct_keys > KEYBOARD_REPORT_KEYS) {
      007FD9 90 0A 42         [24] 1259 	mov	dptr,#_distinct_keys
      007FDC E0               [24] 1260 	movx	a,@dptr
      007FDD 24 F9            [12] 1261 	add	a,#0xff - 0x06
      007FDF 50 17            [24] 1262 	jnc	00110$
                                   1263 ;	free result
                                   1264 ;	quantum/action_util.c:150: for (uint8_t i = 0; i < KEYBOARD_REPORT_KEYS; ++i) keyboard_report->keys[i] = 1; /* HID ErrorRollOver */
      007FE1 7F 00            [12] 1265 	mov	r7,#0x00
      007FE3                       1266 00115$:
      007FE3 BF 06 00         [24] 1267 	cjne	r7,#0x06,00174$
      007FE6                       1268 00174$:
      007FE6 50 1E            [24] 1269 	jnc	00111$
      007FE8 EF               [12] 1270 	mov	a,r7
      007FE9 24 D0            [12] 1271 	add	a, #(_actual_keyboard_report + 0x0002)
      007FEB F5 82            [12] 1272 	mov	dpl,a
      007FED E4               [12] 1273 	clr	a
      007FEE 34 0D            [12] 1274 	addc	a, #((_actual_keyboard_report + 0x0002) >> 8)
      007FF0 F5 83            [12] 1275 	mov	dph,a
      007FF2 74 01            [12] 1276 	mov	a,#0x01
      007FF4 F0               [24] 1277 	movx	@dptr,a
      007FF5 0F               [12] 1278 	inc	r7
      007FF6 80 EB            [24] 1279 	sjmp	00115$
      007FF8                       1280 00110$:
                                   1281 ;	quantum/action_util.c:151: } else add_key(code);
      007FF8 90 0A 58         [24] 1282 	mov	dptr,#_add_owned_key_code_10000_333
      007FFB E0               [24] 1283 	movx	a,@dptr
                                   1284 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      007FFC 90 08 08         [24] 1285 	mov	dptr,#_add_key_to_report_PARM_2
      007FFF F0               [24] 1286 	movx	@dptr,a
      008000 90 0D CE         [24] 1287 	mov	dptr,#_actual_keyboard_report
      008003 12 70 D8         [24] 1288 	lcall	_add_key_to_report
                                   1289 ;	quantum/action_util.c:151: } else add_key(code);
      008006                       1290 00111$:
                                   1291 ;	quantum/action_util.c:152: return true;
      008006 75 82 01         [24] 1292 	mov	dpl, #0x01
                                   1293 ;	quantum/action_util.c:153: }
      008009 22               [24] 1294 	ret
                                   1295 ;------------------------------------------------------------
                                   1296 ;Allocation info for local variables in function 'del_owned_key'
                                   1297 ;------------------------------------------------------------
                                   1298 ;code          Allocated with name '_del_owned_key_code_10000_348'
                                   1299 ;__400000078   Allocated with name '_del_owned_key___400000078_40000_359'
                                   1300 ;key           Allocated with name '_del_owned_key_key_50000_360'
                                   1301 ;key           Allocated with name '_del_owned_key_key_40000_357'
                                   1302 ;__600000081   Allocated with name '_del_owned_key___600000081_60000_365'
                                   1303 ;key           Allocated with name '_del_owned_key_key_70000_366'
                                   1304 ;__300000083   Allocated with name '_del_owned_key___300000083_30000_368'
                                   1305 ;key           Allocated with name '_del_owned_key_key_40000_369'
                                   1306 ;------------------------------------------------------------
                                   1307 ;	quantum/action_util.c:154: bool del_owned_key(uint8_t code) {
                                   1308 ;	-----------------------------------------
                                   1309 ;	 function del_owned_key
                                   1310 ;	-----------------------------------------
      00800A                       1311 _del_owned_key:
      00800A E5 82            [12] 1312 	mov	a,dpl
      00800C 90 0A 59         [24] 1313 	mov	dptr,#_del_owned_key_code_10000_348
      00800F 12 83 49         [24] 1314 	lcall	_ak820_outline_0132
                                   1315 ;	quantum/action_util.c:155: if (!ak820_macro_change(macro_keys, code, false)) return false;
      008012 E4               [12] 1316 	clr	a
      008013 F0               [24] 1317 	movx	@dptr,a
      008014 90 0A 43         [24] 1318 	mov	dptr,#_macro_keys
      008017 C0 07            [24] 1319 	push	ar7
      008019 12 7D B1         [24] 1320 	lcall	_ak820_macro_change
      00801C E5 82            [12] 1321 	mov	a, dpl
      00801E D0 07            [24] 1322 	pop	ar7
      008020 70 03            [24] 1323 	jnz	00102$
      008022 F5 82            [12] 1324 	mov	dpl,a
      008024 22               [24] 1325 	ret
      008025                       1326 00102$:
                                   1327 ;	quantum/action_util.c:156: if (!key_refs[code] || --key_refs[code]) return false;
      008025 12 83 03         [24] 1328 	lcall	_ak820_outline_0031
      008028 FC               [12] 1329 	mov	r4,a
      008029 60 07            [24] 1330 	jz	00103$
      00802B 1C               [12] 1331 	dec	r4
      00802C 12 43 A4         [24] 1332 	lcall	_ak820_outline_0064
      00802F EC               [12] 1333 	mov	a,r4
      008030 60 04            [24] 1334 	jz	00104$
      008032                       1335 00103$:
      008032 75 82 00         [24] 1336 	mov	dpl, #0x00
      008035 22               [24] 1337 	ret
      008036                       1338 00104$:
                                   1339 ;	quantum/action_util.c:157: --distinct_keys;
      008036 90 0A 42         [24] 1340 	mov	dptr,#_distinct_keys
      008039 E0               [24] 1341 	movx	a,@dptr
      00803A 14               [12] 1342 	dec	a
      00803B F0               [24] 1343 	movx	@dptr,a
                                   1344 ;	quantum/action_util.c:159: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      00803C 90 0D BB         [24] 1345 	mov	dptr,#_keyboard_protocol
      00803F E0               [24] 1346 	movx	a,@dptr
      008040 60 16            [24] 1347 	jz	00107$
      008042 90 0A C7         [24] 1348 	mov	dptr,#_keymap_config
      008045 E0               [24] 1349 	movx	a,@dptr
      008046 30 E7 0F         [24] 1350 	jnb	acc.7,00107$
                                   1351 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      008049 90 08 0B         [24] 1352 	mov	dptr,#_del_key_from_report_PARM_2
      00804C EF               [12] 1353 	mov	a,r7
      00804D F0               [24] 1354 	movx	@dptr,a
      00804E 90 0D CE         [24] 1355 	mov	dptr,#_actual_keyboard_report
      008051 12 71 0E         [24] 1356 	lcall	_del_key_from_report
                                   1357 ;	quantum/action_util.c:159: if (keyboard_protocol && keymap_config.nkro) { del_key(code); return true; }
      008054 75 82 01         [24] 1358 	mov	dpl, #0x01
      008057 22               [24] 1359 	ret
      008058                       1360 00107$:
                                   1361 ;	quantum/action_util.c:161: if (distinct_keys > KEYBOARD_REPORT_KEYS) return true;
      008058 90 0A 42         [24] 1362 	mov	dptr,#_distinct_keys
      00805B E0               [24] 1363 	movx	a,@dptr
      00805C FF               [12] 1364 	mov  r7,a
      00805D 24 F9            [12] 1365 	add	a,#0xff - 0x06
      00805F 50 04            [24] 1366 	jnc	00110$
                                   1367 ;	free result
      008061 75 82 01         [24] 1368 	mov	dpl, #0x01
      008064 22               [24] 1369 	ret
      008065                       1370 00110$:
                                   1371 ;	quantum/action_util.c:162: if (distinct_keys == KEYBOARD_REPORT_KEYS) {
      008065 BF 06 1F         [24] 1372 	cjne	r7,#0x06,00115$
                                   1373 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      008068 90 0D CE         [24] 1374 	mov	dptr,#_actual_keyboard_report
      00806B 12 71 44         [24] 1375 	lcall	_clear_keys_from_report
                                   1376 ;	quantum/action_util.c:165: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      00806E 7F 04            [12] 1377 	mov	r7,#0x04
      008070                       1378 00122$:
      008070 EF               [12] 1379 	mov	a,r7
      008071 24 5B            [12] 1380 	add	a,#0xff - 0xa4
      008073 40 20            [24] 1381 	jc	00116$
                                   1382 ;	free result
      008075 12 83 03         [24] 1383 	lcall	_ak820_outline_0031
      008078 60 0A            [24] 1384 	jz	00123$
                                   1385 ;	quantum/action_util.h:42: add_key_to_report(keyboard_report, key);
      00807A 12 83 54         [24] 1386 	lcall	_ak820_outline_0175
      00807D C0 07            [24] 1387 	push	ar7
      00807F 12 70 D8         [24] 1388 	lcall	_add_key_to_report
      008082 D0 07            [24] 1389 	pop	ar7
                                   1390 ;	quantum/action_util.c:165: for (uint8_t key = KC_A; key <= KC_EXSEL; ++key) if (key_refs[key]) add_key(key);
      008084                       1391 00123$:
      008084 0F               [12] 1392 	inc	r7
      008085 80 E9            [24] 1393 	sjmp	00122$
      008087                       1394 00115$:
                                   1395 ;	quantum/action_util.c:166: } else del_key(code);
      008087 90 0A 59         [24] 1396 	mov	dptr,#_del_owned_key_code_10000_348
      00808A E0               [24] 1397 	movx	a,@dptr
                                   1398 ;	quantum/action_util.h:46: del_key_from_report(keyboard_report, key);
      00808B 90 08 0B         [24] 1399 	mov	dptr,#_del_key_from_report_PARM_2
      00808E F0               [24] 1400 	movx	@dptr,a
      00808F 90 0D CE         [24] 1401 	mov	dptr,#_actual_keyboard_report
      008092 12 71 0E         [24] 1402 	lcall	_del_key_from_report
                                   1403 ;	quantum/action_util.c:166: } else del_key(code);
      008095                       1404 00116$:
                                   1405 ;	quantum/action_util.c:167: return true;
      008095 75 82 01         [24] 1406 	mov	dpl, #0x01
                                   1407 ;	quantum/action_util.c:168: }
      008098 22               [24] 1408 	ret
                                   1409 ;------------------------------------------------------------
                                   1410 ;Allocation info for local variables in function 'clear_owned_usages'
                                   1411 ;------------------------------------------------------------
                                   1412 ;i             Allocated with name '_clear_owned_usages_i_20000_373'
                                   1413 ;i             Allocated with name '_clear_owned_usages_i_20000_374'
                                   1414 ;------------------------------------------------------------
                                   1415 ;	quantum/action_util.c:178: void clear_owned_usages(void) {
                                   1416 ;	-----------------------------------------
                                   1417 ;	 function clear_owned_usages
                                   1418 ;	-----------------------------------------
      008099                       1419 _clear_owned_usages:
                                   1420 ;	quantum/action_util.c:179: for (uint8_t i = 0; i < USAGE_COUNT; ++i) usage_refs[i] = usage_order[i] = 0;
      008099 7F 00            [12] 1421 	mov	r7,#0x00
      00809B                       1422 00104$:
      00809B BF 1E 00         [24] 1423 	cjne	r7,#0x1e,00141$
      00809E                       1424 00141$:
      00809E 50 14            [24] 1425 	jnc	00101$
      0080A0 EF               [12] 1426 	mov	a,r7
      0080A1 24 5A            [12] 1427 	add	a, #_usage_refs
      0080A3 FD               [12] 1428 	mov	r5,a
      0080A4 E4               [12] 1429 	clr	a
      0080A5 34 0A            [12] 1430 	addc	a, #(_usage_refs >> 8)
      0080A7 FE               [12] 1431 	mov	r6,a
      0080A8 EF               [12] 1432 	mov	a,r7
      0080A9 12 83 18         [24] 1433 	lcall	_ak820_outline_0068
      0080AC E4               [12] 1434 	clr	a
      0080AD F0               [24] 1435 	movx	@dptr,a
      0080AE 12 83 38         [24] 1436 	lcall	_ak820_outline_0122
      0080B1 0F               [12] 1437 	inc	r7
      0080B2 80 E7            [24] 1438 	sjmp	00104$
      0080B4                       1439 00101$:
                                   1440 ;	quantum/action_util.c:180: usage_lengths[0] = usage_lengths[1] = 0;
      0080B4 90 0A 97         [24] 1441 	mov	dptr,#(_usage_lengths + 0x0001)
      0080B7 E4               [12] 1442 	clr	a
      0080B8 F0               [24] 1443 	movx	@dptr,a
      0080B9 90 0A 96         [24] 1444 	mov	dptr,#_usage_lengths
      0080BC F0               [24] 1445 	movx	@dptr,a
                                   1446 ;	quantum/action_util.c:181: for (uint8_t i = 0; i < sizeof(macro_usages); ++i) macro_usages[i] = 0;
      0080BD FF               [12] 1447 	mov	r7,a
      0080BE                       1448 00107$:
      0080BE BF 04 00         [24] 1449 	cjne	r7,#0x04,00143$
      0080C1                       1450 00143$:
      0080C1 50 0D            [24] 1451 	jnc	00109$
      0080C3 EF               [12] 1452 	mov	a,r7
      0080C4 24 98            [12] 1453 	add	a, #_macro_usages
      0080C6 F5 82            [12] 1454 	mov	dpl,a
      0080C8 E4               [12] 1455 	clr	a
      0080C9 34 0A            [12] 1456 	addc	a, #(_macro_usages >> 8)
      0080CB 12 7D 52         [24] 1457 	lcall	_ak820_outline_0163
      0080CE 80 EE            [24] 1458 	sjmp	00107$
      0080D0                       1459 00109$:
                                   1460 ;	quantum/action_util.c:182: }
      0080D0 22               [24] 1461 	ret
                                   1462 ;------------------------------------------------------------
                                   1463 ;Allocation info for local variables in function 'owned_usage_key'
                                   1464 ;------------------------------------------------------------
                                   1465 ;pressed       Allocated with name '_owned_usage_key_PARM_2'
                                   1466 ;code          Allocated with name '_owned_usage_key_code_10000_375'
                                   1467 ;__200000085   Allocated with name '_owned_usage_key___200000085_20000_376'
                                   1468 ;which         Allocated with name '_owned_usage_key_which_10000_376'
                                   1469 ;base          Allocated with name '_owned_usage_key_base_10000_376'
                                   1470 ;count         Allocated with name '_owned_usage_key_count_10000_376'
                                   1471 ;index         Allocated with name '_owned_usage_key_index_10000_376'
                                   1472 ;pos           Allocated with name '_owned_usage_key_pos_30001_383'
                                   1473 ;i             Allocated with name '_owned_usage_key_i_40001_384'
                                   1474 ;__300000086   Allocated with name '_owned_usage_key___300000086_30000_387'
                                   1475 ;key           Allocated with name '_owned_usage_key_key_40000_388'
                                   1476 ;------------------------------------------------------------
                                   1477 ;	quantum/action_util.c:183: void owned_usage_key(uint8_t code, bool pressed) {
                                   1478 ;	-----------------------------------------
                                   1479 ;	 function owned_usage_key
                                   1480 ;	-----------------------------------------
      0080D1                       1481 _owned_usage_key:
      0080D1 E5 82            [12] 1482 	mov	a,dpl
      0080D3 90 0A 9D         [24] 1483 	mov	dptr,#_owned_usage_key_code_10000_375
      0080D6 F0               [24] 1484 	movx	@dptr,a
                                   1485 ;	quantum/action_util.c:184: uint8_t which = code >= KC_AUDIO_MUTE;
      0080D7 E0               [24] 1486 	movx	a,@dptr
      0080D8 FF               [12] 1487 	mov	r7,a
      0080D9 BF A8 00         [24] 1488 	cjne	r7,#0xa8,00244$
      0080DC                       1489 00244$:
      0080DC B3               [12] 1490 	cpl	c
      0080DD 92 24            [24] 1491 	mov	_owned_usage_key_sloc0_1_0,c
      0080DF E4               [12] 1492 	clr	a
      0080E0 33               [12] 1493 	rlc	a
      0080E1 FF               [12] 1494 	mov	r7,a
      0080E2 90 0A A0         [24] 1495 	mov	dptr,#_owned_usage_key_which_10000_376
      0080E5 F0               [24] 1496 	movx	@dptr,a
                                   1497 ;	quantum/action_util.c:185: uint8_t base = which ? SYSTEM_COUNT : 0;
      0080E6 EF               [12] 1498 	mov	a,r7
      0080E7 60 02            [24] 1499 	jz	00129$
      0080E9 74 03            [12] 1500 	mov	a,#0x03
      0080EB                       1501 00129$:
      0080EB FE               [12] 1502 	mov	r6,a
                                   1503 ;	quantum/action_util.c:186: uint8_t count = usage_lengths[which];
      0080EC EF               [12] 1504 	mov	a,r7
      0080ED 24 96            [12] 1505 	add	a, #_usage_lengths
      0080EF FD               [12] 1506 	mov	r5,a
      0080F0 E4               [12] 1507 	clr	a
      0080F1 34 0A            [12] 1508 	addc	a, #(_usage_lengths >> 8)
      0080F3 FF               [12] 1509 	mov	r7,a
      0080F4 12 83 5D         [24] 1510 	lcall	_ak820_outline_0190
      0080F7 E0               [24] 1511 	movx	a,@dptr
      0080F8 FC               [12] 1512 	mov	r4,a
                                   1513 ;	quantum/action_util.c:187: uint8_t index = code - KC_SYSTEM_POWER;
      0080F9 90 0A 9D         [24] 1514 	mov	dptr,#_owned_usage_key_code_10000_375
      0080FC E0               [24] 1515 	movx	a,@dptr
      0080FD 24 5B            [12] 1516 	add	a,#0x5b
      0080FF FB               [12] 1517 	mov	r3,a
                                   1518 ;	quantum/action_util.c:188: if (!ak820_macro_change(macro_usages, index, pressed)) return;
      008100 90 0A 9C         [24] 1519 	mov	dptr,#_owned_usage_key_PARM_2
      008103 E0               [24] 1520 	movx	a,@dptr
      008104 FA               [12] 1521 	mov	r2,a
      008105 90 09 91         [24] 1522 	mov	dptr,#_ak820_macro_change_PARM_2
      008108 EB               [12] 1523 	mov	a,r3
      008109 F0               [24] 1524 	movx	@dptr,a
      00810A 90 09 92         [24] 1525 	mov	dptr,#_ak820_macro_change_PARM_3
      00810D EA               [12] 1526 	mov	a,r2
      00810E F0               [24] 1527 	movx	@dptr,a
      00810F 90 0A 98         [24] 1528 	mov	dptr,#_macro_usages
      008112 C0 07            [24] 1529 	push	ar7
      008114 C0 06            [24] 1530 	push	ar6
      008116 C0 05            [24] 1531 	push	ar5
      008118 C0 04            [24] 1532 	push	ar4
      00811A C0 03            [24] 1533 	push	ar3
      00811C C0 02            [24] 1534 	push	ar2
      00811E 12 7D B1         [24] 1535 	lcall	_ak820_macro_change
      008121 E5 82            [12] 1536 	mov	a, dpl
      008123 D0 02            [24] 1537 	pop	ar2
      008125 D0 03            [24] 1538 	pop	ar3
      008127 D0 04            [24] 1539 	pop	ar4
      008129 D0 05            [24] 1540 	pop	ar5
      00812B D0 06            [24] 1541 	pop	ar6
      00812D D0 07            [24] 1542 	pop	ar7
      00812F 70 01            [24] 1543 	jnz	00102$
      008131 22               [24] 1544 	ret
      008132                       1545 00102$:
                                   1546 ;	quantum/action_util.c:189: if (pressed) {
      008132 EA               [12] 1547 	mov	a,r2
      008133 60 1B            [24] 1548 	jz	00115$
                                   1549 ;	quantum/action_util.c:190: if (usage_refs[index]++) return;
      008135 12 83 22         [24] 1550 	lcall	_ak820_outline_0076
      008138 04               [12] 1551 	inc	a
      008139 12 6E 56         [24] 1552 	lcall	_ak820_outline_0139
      00813C E8               [12] 1553 	mov	a,r0
      00813D 60 01            [24] 1554 	jz	00104$
      00813F 22               [24] 1555 	ret
      008140                       1556 00104$:
                                   1557 ;	quantum/action_util.c:191: usage_order[base + count++] = index;
      008140 90 0A A1         [24] 1558 	mov	dptr,#_owned_usage_key_count_10000_376
      008143 EC               [12] 1559 	mov	a,r4
      008144 04               [12] 1560 	inc	a
      008145 F0               [24] 1561 	movx	@dptr,a
      008146 EC               [12] 1562 	mov	a,r4
      008147 2E               [12] 1563 	add	a, r6
      008148 12 83 18         [24] 1564 	lcall	_ak820_outline_0068
      00814B EB               [12] 1565 	mov	a,r3
      00814C F0               [24] 1566 	movx	@dptr,a
      00814D 02 81 B1         [24] 1567 	ljmp	00116$
      008150                       1568 00115$:
                                   1569 ;	quantum/action_util.c:193: if (!usage_refs[index] || --usage_refs[index]) return;
      008150 12 83 22         [24] 1570 	lcall	_ak820_outline_0076
      008153 60 07            [24] 1571 	jz	00105$
      008155 18               [12] 1572 	dec	r0
      008156 12 83 11         [24] 1573 	lcall	_ak820_outline_0063
      008159 E8               [12] 1574 	mov	a,r0
      00815A 60 01            [24] 1575 	jz	00106$
      00815C                       1576 00105$:
      00815C 22               [24] 1577 	ret
      00815D                       1578 00106$:
                                   1579 ;	quantum/action_util.c:195: while (usage_order[base + pos] != index) ++pos;
      00815D 7A 00            [12] 1580 	mov	r2,#0x00
      00815F                       1581 00108$:
      00815F EA               [12] 1582 	mov	a,r2
      008160 2E               [12] 1583 	add	a, r6
      008161 12 83 18         [24] 1584 	lcall	_ak820_outline_0068
      008164 E0               [24] 1585 	movx	a,@dptr
      008165 B5 03 02         [24] 1586 	cjne	a,ar3,00251$
      008168 80 03            [24] 1587 	sjmp	00167$
      00816A                       1588 00251$:
      00816A 0A               [12] 1589 	inc	r2
      00816B 80 F2            [24] 1590 	sjmp	00108$
      00816D                       1591 00167$:
      00816D 90 0A A2         [24] 1592 	mov	dptr,#_owned_usage_key_pos_30001_383
      008170 EA               [12] 1593 	mov	a,r2
      008171 F0               [24] 1594 	movx	@dptr,a
                                   1595 ;	quantum/action_util.c:196: --count;
      008172 1C               [12] 1596 	dec	r4
      008173 90 0A A1         [24] 1597 	mov	dptr,#_owned_usage_key_count_10000_376
      008176 EC               [12] 1598 	mov	a,r4
      008177 F0               [24] 1599 	movx	@dptr,a
                                   1600 ;	quantum/action_util.c:197: for (uint8_t i = pos; i < count; ++i) usage_order[base + i] = usage_order[base + i + 1];
      008178 8A 03            [24] 1601 	mov	ar3,r2
      00817A                       1602 00125$:
      00817A C3               [12] 1603 	clr	c
      00817B EB               [12] 1604 	mov	a,r3
      00817C 9C               [12] 1605 	subb	a,r4
      00817D 50 23            [24] 1606 	jnc	00111$
      00817F C0 05            [24] 1607 	push	ar5
      008181 C0 07            [24] 1608 	push	ar7
      008183 EB               [12] 1609 	mov	a,r3
      008184 2E               [12] 1610 	add	a, r6
      008185 FA               [12] 1611 	mov	r2,a
      008186 24 78            [12] 1612 	add	a, #_usage_order
      008188 F8               [12] 1613 	mov	r0,a
      008189 E4               [12] 1614 	clr	a
      00818A 34 0A            [12] 1615 	addc	a, #(_usage_order >> 8)
      00818C F9               [12] 1616 	mov	r1,a
      00818D 0A               [12] 1617 	inc	r2
      00818E EA               [12] 1618 	mov	a,r2
      00818F 33               [12] 1619 	rlc	a
      008190 95 E0            [12] 1620 	subb	a,acc
      008192 FF               [12] 1621 	mov	r7,a
      008193 EA               [12] 1622 	mov	a,r2
      008194 12 83 3E         [24] 1623 	lcall	_ak820_outline_0125
      008197 12 38 B6         [24] 1624 	lcall	_ak820_outline_0157
      00819A F0               [24] 1625 	movx	@dptr,a
      00819B 0B               [12] 1626 	inc	r3
      00819C D0 07            [24] 1627 	pop	ar7
      00819E D0 05            [24] 1628 	pop	ar5
      0081A0 80 D8            [24] 1629 	sjmp	00125$
      0081A2                       1630 00111$:
                                   1631 ;	quantum/action_util.c:198: usage_lengths[which] = count;
      0081A2 12 83 5D         [24] 1632 	lcall	_ak820_outline_0190
      0081A5 EC               [12] 1633 	mov	a,r4
      0081A6 F0               [24] 1634 	movx	@dptr,a
                                   1635 ;	quantum/action_util.c:199: if (pos != count) return; /* A non-winning owner changed only storage. */
      0081A7 90 0A A2         [24] 1636 	mov	dptr,#_owned_usage_key_pos_30001_383
      0081AA E0               [24] 1637 	movx	a,@dptr
      0081AB B5 04 02         [24] 1638 	cjne	a,ar4,00253$
      0081AE 80 01            [24] 1639 	sjmp	00116$
      0081B0                       1640 00253$:
      0081B0 22               [24] 1641 	ret
      0081B1                       1642 00116$:
                                   1643 ;	quantum/action_util.c:201: usage_lengths[which] = count;
      0081B1 90 0A A1         [24] 1644 	mov	dptr,#_owned_usage_key_count_10000_376
      0081B4 E0               [24] 1645 	movx	a,@dptr
      0081B5 FC               [12] 1646 	mov	r4,a
      0081B6 12 83 5D         [24] 1647 	lcall	_ak820_outline_0190
      0081B9 F0               [24] 1648 	movx	@dptr,a
                                   1649 ;	quantum/action_util.c:202: code = count ? usage_order[base + count - 1] + KC_SYSTEM_POWER : 0;
      0081BA EC               [12] 1650 	mov	a,r4
      0081BB 60 15            [24] 1651 	jz	00131$
      0081BD EC               [12] 1652 	mov	a,r4
      0081BE 2E               [12] 1653 	add	a, r6
      0081BF FE               [12] 1654 	mov	r6,a
      0081C0 1E               [12] 1655 	dec	r6
      0081C1 EE               [12] 1656 	mov	a,r6
      0081C2 33               [12] 1657 	rlc	a
      0081C3 95 E0            [12] 1658 	subb	a,acc
      0081C5 FF               [12] 1659 	mov	r7,a
      0081C6 EE               [12] 1660 	mov	a,r6
      0081C7 12 83 3E         [24] 1661 	lcall	_ak820_outline_0125
      0081CA 24 A5            [12] 1662 	add	a,#0xa5
      0081CC FE               [12] 1663 	mov	r6,a
      0081CD 33               [12] 1664 	rlc	a
      0081CE 95 E0            [12] 1665 	subb	a,acc
      0081D0 80 02            [24] 1666 	sjmp	00132$
      0081D2                       1667 00131$:
      0081D2 7E 00            [12] 1668 	mov	r6,#0x00
      0081D4                       1669 00132$:
      0081D4 90 0A 9D         [24] 1670 	mov	dptr,#_owned_usage_key_code_10000_375
      0081D7 EE               [12] 1671 	mov	a,r6
      0081D8 F0               [24] 1672 	movx	@dptr,a
                                   1673 ;	quantum/action_util.c:203: if (which) host_consumer_send(code ? KEYCODE2CONSUMER(code) : 0);
      0081D9 90 0A A0         [24] 1674 	mov	dptr,#_owned_usage_key_which_10000_376
      0081DC E0               [24] 1675 	movx	a,@dptr
      0081DD 60 18            [24] 1676 	jz	00118$
      0081DF EE               [12] 1677 	mov	a,r6
      0081E0 60 0B            [24] 1678 	jz	00133$
      0081E2 8E 82            [24] 1679 	mov	dpl, r6
      0081E4 12 6F 96         [24] 1680 	lcall	_KEYCODE2CONSUMER
      0081E7 AD 82            [24] 1681 	mov	r5, dpl
      0081E9 AF 83            [24] 1682 	mov	r7, dph
      0081EB 80 04            [24] 1683 	sjmp	00134$
      0081ED                       1684 00133$:
      0081ED 7D 00            [12] 1685 	mov	r5,#0x00
      0081EF 7F 00            [12] 1686 	mov	r7,#0x00
      0081F1                       1687 00134$:
      0081F1 12 83 5D         [24] 1688 	lcall	_ak820_outline_0190
      0081F4 02 6F 49         [24] 1689 	ljmp	_host_consumer_send
      0081F7                       1690 00118$:
                                   1691 ;	quantum/action_util.c:204: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      0081F7 EE               [12] 1692 	mov	a,r6
      0081F8 60 22            [24] 1693 	jz	00135$
                                   1694 ;	tmk_core/protocol/report.h:264: if (key < KC_SYSTEM_POWER || key > KC_SYSTEM_WAKE) return 0;
      0081FA BE A5 00         [24] 1695 	cjne	r6,#0xa5,00258$
      0081FD                       1696 00258$:
      0081FD 40 05            [24] 1697 	jc	00121$
      0081FF EE               [12] 1698 	mov	a,r6
      008200 24 58            [12] 1699 	add	a,#0xff - 0xa7
      008202 50 08            [24] 1700 	jnc	00122$
                                   1701 ;	free result
      008204                       1702 00121$:
      008204 90 0A 9E         [24] 1703 	mov	dptr,#_owned_usage_key___200000085_20000_376
      008207 12 50 8C         [24] 1704 	lcall	_ak820_outline_0182
      00820A 80 09            [24] 1705 	sjmp	00123$
      00820C                       1706 00122$:
                                   1707 ;	tmk_core/protocol/report.h:265: return SYSTEM_POWER_DOWN + (key - KC_SYSTEM_POWER);
      00820C 74 DC            [12] 1708 	mov	a,#0xdc
      00820E 2E               [12] 1709 	add	a, r6
      00820F 90 0A 9E         [24] 1710 	mov	dptr,#_owned_usage_key___200000085_20000_376
      008212 12 38 9C         [24] 1711 	lcall	_ak820_outline_0134
                                   1712 ;	quantum/action_util.c:204: else host_system_send(code ? KEYCODE2SYSTEM(code) : 0);
      008215                       1713 00123$:
      008215 90 0A 9E         [24] 1714 	mov	dptr,#_owned_usage_key___200000085_20000_376
      008218 E0               [24] 1715 	movx	a,@dptr
      008219 FF               [12] 1716 	mov	r7,a
      00821A 80 02            [24] 1717 	sjmp	00136$
      00821C                       1718 00135$:
      00821C 7F 00            [12] 1719 	mov	r7,#0x00
      00821E                       1720 00136$:
      00821E 7E 00            [12] 1721 	mov	r6,#0x00
      008220 12 43 DF         [24] 1722 	lcall	_ak820_outline_0158
                                   1723 ;	quantum/action_util.c:205: }
      008223 02 6F 19         [24] 1724 	ljmp	_host_system_send
                                   1725 ;------------------------------------------------------------
                                   1726 ;Allocation info for local variables in function 'send_keyboard_report'
                                   1727 ;------------------------------------------------------------
                                   1728 ;mods          Allocated with name '_send_keyboard_report_mods_30000_396'
                                   1729 ;last_report   Allocated with name '_send_keyboard_report_last_report_10001_397'
                                   1730 ;changed       Allocated with name '_send_keyboard_report_changed_10001_397'
                                   1731 ;dest          Allocated with name '_send_keyboard_report_dest_10001_397'
                                   1732 ;src           Allocated with name '_send_keyboard_report_src_10001_397'
                                   1733 ;i             Allocated with name '_send_keyboard_report_i_20001_398'
                                   1734 ;------------------------------------------------------------
                                   1735 ;	quantum/action_util.c:427: void send_keyboard_report(void) {
                                   1736 ;	-----------------------------------------
                                   1737 ;	 function send_keyboard_report
                                   1738 ;	-----------------------------------------
      008226                       1739 _send_keyboard_report:
                                   1740 ;	quantum/action_util.c:428: keyboard_report->mods = real_mods;
      008226 90 0D CC         [24] 1741 	mov	dptr,#_real_mods
      008229 E0               [24] 1742 	movx	a,@dptr
      00822A FF               [12] 1743 	mov	r7,a
      00822B 90 0D CE         [24] 1744 	mov	dptr,#_actual_keyboard_report
      00822E F0               [24] 1745 	movx	@dptr,a
                                   1746 ;	quantum/action_util.c:429: keyboard_report->mods |= weak_mods;
      00822F 90 0D CD         [24] 1747 	mov	dptr,#_weak_mods
      008232 E0               [24] 1748 	movx	a,@dptr
      008233 42 07            [12] 1749 	orl	ar7,a
      008235 90 0D CE         [24] 1750 	mov	dptr,#_actual_keyboard_report
      008238 EF               [12] 1751 	mov	a,r7
      008239 F0               [24] 1752 	movx	@dptr,a
                                   1753 ;	quantum/action_util.c:431: keyboard_report->mods |= owned_mods | owned_weak_mods;
      00823A 90 09 8C         [24] 1754 	mov	dptr,#_owned_weak_mods
      00823D E0               [24] 1755 	movx	a,@dptr
      00823E FE               [12] 1756 	mov	r6,a
      00823F 90 09 8B         [24] 1757 	mov	dptr,#_owned_mods
      008242 E0               [24] 1758 	movx	a,@dptr
      008243 4E               [12] 1759 	orl	a,r6
      008244 42 07            [12] 1760 	orl	ar7,a
      008246 90 0D CE         [24] 1761 	mov	dptr,#_actual_keyboard_report
      008249 EF               [12] 1762 	mov	a,r7
      00824A F0               [24] 1763 	movx	@dptr,a
                                   1764 ;	quantum/action_util.c:456: if (ak820_mac_mode) {
      00824B 30 20 24         [24] 1765 	jnb	_ak820_mac_mode,00102$
                                   1766 ;	quantum/action_util.c:457: uint8_t mods = keyboard_report->mods;
      00824E 90 0D CE         [24] 1767 	mov	dptr,#_actual_keyboard_report
      008251 E0               [24] 1768 	movx	a,@dptr
      008252 FF               [12] 1769 	mov	r7,a
                                   1770 ;	quantum/action_util.c:458: keyboard_report->mods = (mods & 0x33) | ((mods & 0x44) << 1) | ((mods & 0x88) >> 1);
      008253 74 33            [12] 1771 	mov	a,#0x33
      008255 5F               [12] 1772 	anl	a,r7
      008256 FE               [12] 1773 	mov	r6,a
      008257 8F 05            [24] 1774 	mov	ar5,r7
      008259 53 05 44         [24] 1775 	anl	ar5,#0x44
      00825C ED               [12] 1776 	mov	a,r5
      00825D 2D               [12] 1777 	add	a,r5
      00825E 42 06            [12] 1778 	orl	ar6,a
      008260 53 07 88         [24] 1779 	anl	ar7,#0x88
      008263 E4               [12] 1780 	clr	a
      008264 A2 E7            [12] 1781 	mov	c,acc.7
      008266 13               [12] 1782 	rrc	a
      008267 CF               [12] 1783 	xch	a,r7
      008268 13               [12] 1784 	rrc	a
      008269 CF               [12] 1785 	xch	a,r7
      00826A EF               [12] 1786 	mov	a,r7
      00826B 42 06            [12] 1787 	orl	ar6,a
      00826D 90 0D CE         [24] 1788 	mov	dptr,#_actual_keyboard_report
      008270 EE               [12] 1789 	mov	a,r6
      008271 F0               [24] 1790 	movx	@dptr,a
      008272                       1791 00102$:
                                   1792 ;	quantum/action_util.c:479: bool changed = false;
      008272 90 0A C4         [24] 1793 	mov	dptr,#_send_keyboard_report_changed_10001_397
      008275 E4               [12] 1794 	clr	a
      008276 F0               [24] 1795 	movx	@dptr,a
                                   1796 ;	quantum/action_util.c:481: uint8_t __xdata *dest = (uint8_t __xdata *)&last_report;
                                   1797 ;	quantum/action_util.c:482: const uint8_t __xdata *src = (const uint8_t __xdata *)keyboard_report;
                                   1798 ;	quantum/action_util.c:487: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      008277 FF               [12] 1799 	mov	r7,a
      008278                       1800 00109$:
      008278 BF 20 00         [24] 1801 	cjne	r7,#0x20,00150$
      00827B                       1802 00150$:
      00827B 50 2B            [24] 1803 	jnc	00105$
                                   1804 ;	quantum/action_util.c:488: if (dest[i] != src[i]) {
      00827D EF               [12] 1805 	mov	a,r7
      00827E 24 A4            [12] 1806 	add	a, #_send_keyboard_report_last_report_10001_397
      008280 FD               [12] 1807 	mov	r5,a
      008281 E4               [12] 1808 	clr	a
      008282 34 0A            [12] 1809 	addc	a, #(_send_keyboard_report_last_report_10001_397 >> 8)
      008284 FE               [12] 1810 	mov	r6,a
      008285 12 49 E0         [24] 1811 	lcall	_ak820_outline_0078
      008288 EF               [12] 1812 	mov	a,r7
      008289 24 CE            [12] 1813 	add	a, #_actual_keyboard_report
      00828B F5 82            [12] 1814 	mov	dpl,a
      00828D E4               [12] 1815 	clr	a
      00828E 34 0D            [12] 1816 	addc	a, #(_actual_keyboard_report >> 8)
      008290 F5 83            [12] 1817 	mov	dph,a
      008292 E0               [24] 1818 	movx	a,@dptr
      008293 FB               [12] 1819 	mov	r3,a
      008294 EC               [12] 1820 	mov	a,r4
      008295 B5 03 02         [24] 1821 	cjne	a,ar3,00152$
      008298 80 0B            [24] 1822 	sjmp	00110$
      00829A                       1823 00152$:
                                   1824 ;	quantum/action_util.c:489: dest[i] = src[i];
      00829A 12 38 A1         [24] 1825 	lcall	_ak820_outline_0135
      00829D EB               [12] 1826 	mov	a,r3
      00829E F0               [24] 1827 	movx	@dptr,a
                                   1828 ;	quantum/action_util.c:490: changed = true;
      00829F 90 0A C4         [24] 1829 	mov	dptr,#_send_keyboard_report_changed_10001_397
      0082A2 74 01            [12] 1830 	mov	a,#0x01
      0082A4 F0               [24] 1831 	movx	@dptr,a
      0082A5                       1832 00110$:
                                   1833 ;	quantum/action_util.c:487: for (uint8_t i = 0; i < sizeof(report_keyboard_t); ++i) {
      0082A5 0F               [12] 1834 	inc	r7
      0082A6 80 D0            [24] 1835 	sjmp	00109$
      0082A8                       1836 00105$:
                                   1837 ;	quantum/action_util.c:493: if (changed) host_keyboard_send(keyboard_report);
      0082A8 90 0A C4         [24] 1838 	mov	dptr,#_send_keyboard_report_changed_10001_397
      0082AB E0               [24] 1839 	movx	a,@dptr
      0082AC 60 09            [24] 1840 	jz	00111$
      0082AE 90 0D CE         [24] 1841 	mov	dptr,#_actual_keyboard_report
      0082B1 75 F0 00         [24] 1842 	mov	b, #0x00
                                   1843 ;	quantum/action_util.c:501: }
      0082B4 02 6E 8E         [24] 1844 	ljmp	_host_keyboard_send
      0082B7                       1845 00111$:
      0082B7 22               [24] 1846 	ret
                                   1847 ;------------------------------------------------------------
                                   1848 ;Allocation info for local variables in function 'get_mods'
                                   1849 ;------------------------------------------------------------
                                   1850 ;	quantum/action_util.c:507: uint8_t get_mods(void) {
                                   1851 ;	-----------------------------------------
                                   1852 ;	 function get_mods
                                   1853 ;	-----------------------------------------
      0082B8                       1854 _get_mods:
      0082B8 C0 07            [24] 1855 	push	ar7
                                   1856 ;	quantum/action_util.c:512: ;
      0082BA 90 09 8B         [24] 1857 	mov	dptr,#_owned_mods
      0082BD E0               [24] 1858 	movx	a,@dptr
      0082BE FF               [12] 1859 	mov	r7,a
      0082BF 90 0D CC         [24] 1860 	mov	dptr,#_real_mods
      0082C2 12 7D 4C         [24] 1861 	lcall	_ak820_outline_0141
                                   1862 ;	quantum/action_util.c:513: }
      0082C5 D0 07            [24] 1863 	pop	ar7
      0082C7 22               [24] 1864 	ret
                                   1865 ;------------------------------------------------------------
                                   1866 ;Allocation info for local variables in function 'add_mods'
                                   1867 ;------------------------------------------------------------
                                   1868 ;mods          Allocated with name '_add_mods_mods_10000_405'
                                   1869 ;------------------------------------------------------------
                                   1870 ;	quantum/action_util.c:518: void add_mods(uint8_t mods) {
                                   1871 ;	-----------------------------------------
                                   1872 ;	 function clear_mods
                                   1873 ;	-----------------------------------------
      0082C8                       1874 _clear_mods:
                                   1875 ;	quantum/action_util.c:540: real_mods = 0;
      0082C8 90 0D CC         [24] 1876 	mov	dptr,#_real_mods
      0082CB E4               [12] 1877 	clr	a
      0082CC F0               [24] 1878 	movx	@dptr,a
                                   1879 ;	quantum/action_util.c:541: }
      0082CD 22               [24] 1880 	ret
                                   1881 ;------------------------------------------------------------
                                   1882 ;Allocation info for local variables in function 'get_weak_mods'
                                   1883 ;------------------------------------------------------------
                                   1884 ;	quantum/action_util.c:547: uint8_t get_weak_mods(void) {
                                   1885 ;	-----------------------------------------
                                   1886 ;	 function get_weak_mods
                                   1887 ;	-----------------------------------------
      0082CE                       1888 _get_weak_mods:
      0082CE C0 07            [24] 1889 	push	ar7
                                   1890 ;	quantum/action_util.c:552: ;
      0082D0 90 09 8C         [24] 1891 	mov	dptr,#_owned_weak_mods
      0082D3 E0               [24] 1892 	movx	a,@dptr
      0082D4 FF               [12] 1893 	mov	r7,a
      0082D5 90 0D CD         [24] 1894 	mov	dptr,#_weak_mods
      0082D8 12 7D 4C         [24] 1895 	lcall	_ak820_outline_0141
                                   1896 ;	quantum/action_util.c:553: }
      0082DB D0 07            [24] 1897 	pop	ar7
      0082DD 22               [24] 1898 	ret
                                   1899 ;------------------------------------------------------------
                                   1900 ;Allocation info for local variables in function 'add_weak_mods'
                                   1901 ;------------------------------------------------------------
                                   1902 ;mods          Allocated with name '_add_weak_mods_mods_10000_415'
                                   1903 ;------------------------------------------------------------
                                   1904 ;	quantum/action_util.c:558: void add_weak_mods(uint8_t mods) {
                                   1905 ;	-----------------------------------------
                                   1906 ;	 function add_weak_mods
                                   1907 ;	-----------------------------------------
      0082DE                       1908 _add_weak_mods:
      0082DE E5 82            [12] 1909 	mov	a,dpl
      0082E0 90 0A C5         [24] 1910 	mov	dptr,#_add_weak_mods_mods_10000_415
      0082E3 F0               [24] 1911 	movx	@dptr,a
                                   1912 ;	quantum/action_util.c:559: weak_mods |= mods;
      0082E4 E0               [24] 1913 	movx	a,@dptr
      0082E5 FF               [12] 1914 	mov	r7,a
      0082E6 90 0D CD         [24] 1915 	mov	dptr,#_weak_mods
      0082E9 E0               [24] 1916 	movx	a,@dptr
      0082EA 4F               [12] 1917 	orl	a,r7
      0082EB F0               [24] 1918 	movx	@dptr,a
                                   1919 ;	quantum/action_util.c:560: }
      0082EC 22               [24] 1920 	ret
                                   1921 ;------------------------------------------------------------
                                   1922 ;Allocation info for local variables in function 'del_weak_mods'
                                   1923 ;------------------------------------------------------------
                                   1924 ;mods          Allocated with name '_del_weak_mods_mods_10000_417'
                                   1925 ;------------------------------------------------------------
                                   1926 ;	quantum/action_util.c:565: void del_weak_mods(uint8_t mods) {
                                   1927 ;	-----------------------------------------
                                   1928 ;	 function del_weak_mods
                                   1929 ;	-----------------------------------------
      0082ED                       1930 _del_weak_mods:
      0082ED E5 82            [12] 1931 	mov	a,dpl
      0082EF 90 0A C6         [24] 1932 	mov	dptr,#_del_weak_mods_mods_10000_417
      0082F2 F0               [24] 1933 	movx	@dptr,a
                                   1934 ;	quantum/action_util.c:566: weak_mods &= ~mods;
      0082F3 E0               [24] 1935 	movx	a,@dptr
      0082F4 F4               [12] 1936 	cpl	a
      0082F5 FF               [12] 1937 	mov	r7,a
      0082F6 90 0D CD         [24] 1938 	mov	dptr,#_weak_mods
      0082F9 E0               [24] 1939 	movx	a,@dptr
      0082FA 5F               [12] 1940 	anl	a,r7
      0082FB F0               [24] 1941 	movx	@dptr,a
                                   1942 ;	quantum/action_util.c:567: }
      0082FC 22               [24] 1943 	ret
                                   1944 ;------------------------------------------------------------
                                   1945 ;Allocation info for local variables in function 'set_weak_mods'
                                   1946 ;------------------------------------------------------------
                                   1947 ;mods          Allocated with name '_set_weak_mods_mods_10000_419'
                                   1948 ;------------------------------------------------------------
                                   1949 ;	quantum/action_util.c:572: void set_weak_mods(uint8_t mods) {
                                   1950 ;	-----------------------------------------
                                   1951 ;	 function clear_weak_mods
                                   1952 ;	-----------------------------------------
      0082FD                       1953 _clear_weak_mods:
                                   1954 ;	quantum/action_util.c:580: weak_mods = 0;
      0082FD 90 0D CD         [24] 1955 	mov	dptr,#_weak_mods
      008300 E4               [12] 1956 	clr	a
      008301 F0               [24] 1957 	movx	@dptr,a
                                   1958 ;	quantum/action_util.c:581: }
      008302 22               [24] 1959 	ret
                                   1960 ;------------------------------------------------------------
                                   1961 ;Allocation info for local variables in function 'oneshot_locked_mods_changed_user'
                                   1962 ;------------------------------------------------------------
                                   1963 ;mods          Allocated with name '_oneshot_locked_mods_changed_user_mods_10000_423'
                                   1964 ;------------------------------------------------------------
                                   1965 ;	quantum/action_util.c:663: __attribute__((weak)) void oneshot_locked_mods_changed_user(uint8_t mods) {}
                                   1966 ;	-----------------------------------------
                                   1967 	.area CSEG    (CODE)
                                   1968 	.area CONST   (CODE)
                                   1969 	.area XINIT   (CODE)
      00C37E                       1970 __xinit__real_mods:
      00C37E 00                    1971 	.db #0x00	; 0
      00C37F                       1972 __xinit__weak_mods:
      00C37F 00                    1973 	.db #0x00	; 0
      00C380                       1974 __xinit__actual_keyboard_report:
      00C380 00                    1975 	.db #0x00	; 0
      00C381 00                    1976 	.db #0x00	; 0
      00C382 00                    1977 	.db #0x00	; 0
      00C383 00                    1978 	.db #0x00	; 0
      00C384 00                    1979 	.db #0x00	; 0
      00C385 00                    1980 	.db #0x00	; 0
      00C386 00                    1981 	.db #0x00	; 0
      00C387 00                    1982 	.db #0x00	; 0
      00C388 00                    1983 	.db 0x00
      00C389 00                    1984 	.db 0x00
      00C38A 00                    1985 	.db 0x00
      00C38B 00                    1986 	.db 0x00
      00C38C 00                    1987 	.db 0x00
      00C38D 00                    1988 	.db 0x00
      00C38E 00                    1989 	.db 0x00
      00C38F 00                    1990 	.db 0x00
      00C390 00                    1991 	.db 0x00
      00C391 00                    1992 	.db 0x00
      00C392 00                    1993 	.db 0x00
      00C393 00                    1994 	.db 0x00
      00C394 00                    1995 	.db 0x00
      00C395 00                    1996 	.db 0x00
      00C396 00                    1997 	.db 0x00
      00C397 00                    1998 	.db 0x00
      00C398 00                    1999 	.db 0x00
      00C399 00                    2000 	.db 0x00
      00C39A 00                    2001 	.db 0x00
      00C39B 00                    2002 	.db 0x00
      00C39C 00                    2003 	.db 0x00
      00C39D 00                    2004 	.db 0x00
      00C39E 00                    2005 	.db 0x00
      00C39F 00                    2006 	.db 0x00
                                   2007 	.area CABS    (ABS,CODE)
                                   2008 
                                   2009 ; Experimental exact instruction outlining.
                                   2010 	.globl _ak820_outline_0017
                                   2011 	.globl _ak820_outline_0031
                                   2012 	.globl _ak820_outline_0052
                                   2013 	.globl _ak820_outline_0056
                                   2014 	.globl _ak820_outline_0060
                                   2015 	.globl _ak820_outline_0062
                                   2016 	.globl _ak820_outline_0063
                                   2017 	.globl _ak820_outline_0064
                                   2018 	.globl _ak820_outline_0068
                                   2019 	.globl _ak820_outline_0076
                                   2020 	.globl _ak820_outline_0078
                                   2021 	.globl _ak820_outline_0107
                                   2022 	.globl _ak820_outline_0108
                                   2023 	.globl _ak820_outline_0117
                                   2024 	.globl _ak820_outline_0121
                                   2025 	.globl _ak820_outline_0122
                                   2026 	.globl _ak820_outline_0125
                                   2027 	.globl _ak820_outline_0132
                                   2028 	.globl _ak820_outline_0134
                                   2029 	.globl _ak820_outline_0135
                                   2030 	.globl _ak820_outline_0139
                                   2031 	.globl _ak820_outline_0141
                                   2032 	.globl _ak820_outline_0157
                                   2033 	.globl _ak820_outline_0158
                                   2034 	.globl _ak820_outline_0163
                                   2035 	.globl _ak820_outline_0175
                                   2036 	.globl _ak820_outline_0182
                                   2037 	.globl _ak820_outline_0188
                                   2038 	.globl _ak820_outline_0190
                                   2039 
                                   2040 	.area CSEG (CODE)
                                   2041 ; function ak820_outline_0031
      008303                       2042 _ak820_outline_0031:
      008303 EF               [12] 2043 	mov	a,r7
      008304 24 9D            [12] 2044 	add	a,#_key_refs
      008306 FD               [12] 2045 	mov	r5,a
      008307 E4               [12] 2046 	clr	a
      008308 34 09            [12] 2047 	addc	a,#(_key_refs>>8)
      00830A FE               [12] 2048 	mov	r6,a
      00830B 8D 82            [24] 2049 	mov	dpl,r5
      00830D 8E 83            [24] 2050 	mov	dph,r6
      00830F E0               [24] 2051 	movx	a,@dptr
      008310 22               [24] 2052 	ret
                                   2053 
                                   2054 	.area CSEG (CODE)
                                   2055 ; function ak820_outline_0063
      008311                       2056 _ak820_outline_0063:
      008311 89 82            [24] 2057 	mov	dpl,r1
      008313 8A 83            [24] 2058 	mov	dph,r2
      008315 E8               [12] 2059 	mov	a,r0
      008316 F0               [24] 2060 	movx	@dptr,a
      008317 22               [24] 2061 	ret
                                   2062 
                                   2063 	.area CSEG (CODE)
                                   2064 ; function ak820_outline_0068
      008318                       2065 _ak820_outline_0068:
      008318 24 78            [12] 2066 	add	a,#_usage_order
      00831A F5 82            [12] 2067 	mov	dpl,a
      00831C E4               [12] 2068 	clr	a
      00831D 34 0A            [12] 2069 	addc	a,#(_usage_order>>8)
      00831F F5 83            [12] 2070 	mov	dph,a
      008321 22               [24] 2071 	ret
                                   2072 
                                   2073 	.area CSEG (CODE)
                                   2074 ; function ak820_outline_0076
      008322                       2075 _ak820_outline_0076:
      008322 EB               [12] 2076 	mov	a,r3
      008323 24 5A            [12] 2077 	add	a,#_usage_refs
      008325 F9               [12] 2078 	mov	r1,a
      008326 E4               [12] 2079 	clr	a
      008327 34 0A            [12] 2080 	addc	a,#(_usage_refs>>8)
      008329 FA               [12] 2081 	mov	r2,a
      00832A 89 82            [24] 2082 	mov	dpl,r1
      00832C 8A 83            [24] 2083 	mov	dph,r2
      00832E E0               [24] 2084 	movx	a,@dptr
      00832F F8               [12] 2085 	mov	r0,a
      008330 22               [24] 2086 	ret
                                   2087 
                                   2088 	.area CSEG (CODE)
                                   2089 ; function ak820_outline_0117
      008331                       2090 _ak820_outline_0117:
      008331 F0               [24] 2091 	movx	@dptr,a
      008332 E0               [24] 2092 	movx	a,@dptr
      008333 FF               [12] 2093 	mov	r7,a
      008334 90 09 95         [24] 2094 	mov	dptr,#_change_owned_PARM_2
      008337 22               [24] 2095 	ret
                                   2096 
                                   2097 	.area CSEG (CODE)
                                   2098 ; function ak820_outline_0122
      008338                       2099 _ak820_outline_0122:
      008338 8D 82            [24] 2100 	mov	dpl,r5
      00833A 8E 83            [24] 2101 	mov	dph,r6
      00833C F0               [24] 2102 	movx	@dptr,a
      00833D 22               [24] 2103 	ret
                                   2104 
                                   2105 	.area CSEG (CODE)
                                   2106 ; function ak820_outline_0125
      00833E                       2107 _ak820_outline_0125:
      00833E 24 78            [12] 2108 	add	a,#_usage_order
      008340 F5 82            [12] 2109 	mov	dpl,a
      008342 EF               [12] 2110 	mov	a,r7
      008343 34 0A            [12] 2111 	addc	a,#(_usage_order>>8)
      008345 F5 83            [12] 2112 	mov	dph,a
      008347 E0               [24] 2113 	movx	a,@dptr
      008348 22               [24] 2114 	ret
                                   2115 
                                   2116 	.area CSEG (CODE)
                                   2117 ; function ak820_outline_0132
      008349                       2118 _ak820_outline_0132:
      008349 F0               [24] 2119 	movx	@dptr,a
      00834A E0               [24] 2120 	movx	a,@dptr
      00834B FF               [12] 2121 	mov	r7,a
      00834C 90 09 91         [24] 2122 	mov	dptr,#_ak820_macro_change_PARM_2
      00834F F0               [24] 2123 	movx	@dptr,a
      008350 90 09 92         [24] 2124 	mov	dptr,#_ak820_macro_change_PARM_3
      008353 22               [24] 2125 	ret
                                   2126 
                                   2127 	.area CSEG (CODE)
                                   2128 ; function ak820_outline_0175
      008354                       2129 _ak820_outline_0175:
      008354 90 08 08         [24] 2130 	mov	dptr,#_add_key_to_report_PARM_2
      008357 EF               [12] 2131 	mov	a,r7
      008358 F0               [24] 2132 	movx	@dptr,a
      008359 90 0D CE         [24] 2133 	mov	dptr,#_actual_keyboard_report
      00835C 22               [24] 2134 	ret
                                   2135 
                                   2136 	.area CSEG (CODE)
                                   2137 ; function ak820_outline_0190
      00835D                       2138 _ak820_outline_0190:
      00835D 8D 82            [24] 2139 	mov	dpl,r5
      00835F 8F 83            [24] 2140 	mov	dph,r7
      008361 22               [24] 2141 	ret
