                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module usb_ak820
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_nvm_end
                                     12 	.globl _ak820_nvm_flush
                                     13 	.globl _ak820_nvm_begin
                                     14 	.globl _ak820_nvm_ok
                                     15 	.globl _ak820_os_indicator_get
                                     16 	.globl _ak820_os_indicator_set
                                     17 	.globl _ak820_nvm_diagnostic
                                     18 	.globl _mDelaymS
                                     19 	.globl _mDelayuS
                                     20 	.globl _raw_hid_receive
                                     21 	.globl _ADC_START
                                     22 	.globl _S0_R_FIFO
                                     23 	.globl _S0_T_FIFO
                                     24 	.globl _S0_FREE
                                     25 	.globl _S0_IF_BYTE
                                     26 	.globl _S0_IF_FIRST
                                     27 	.globl _S0_IF_OV
                                     28 	.globl _S0_FST_ACT
                                     29 	.globl _CP_RL2
                                     30 	.globl _C_T2
                                     31 	.globl _TR2
                                     32 	.globl _EXEN2
                                     33 	.globl _TCLK
                                     34 	.globl _RCLK
                                     35 	.globl _EXF2
                                     36 	.globl _CAP1F
                                     37 	.globl _TF2
                                     38 	.globl _RI
                                     39 	.globl _TI
                                     40 	.globl _RB8
                                     41 	.globl _TB8
                                     42 	.globl _REN
                                     43 	.globl _SM2
                                     44 	.globl _SM1
                                     45 	.globl _SM0
                                     46 	.globl _IT0
                                     47 	.globl _IE0
                                     48 	.globl _IT1
                                     49 	.globl _IE1
                                     50 	.globl _TR0
                                     51 	.globl _TF0
                                     52 	.globl _TR1
                                     53 	.globl _TF1
                                     54 	.globl _P4_0
                                     55 	.globl _P4_1
                                     56 	.globl _P4_2
                                     57 	.globl _P4_3
                                     58 	.globl _P4_4
                                     59 	.globl _P4_5
                                     60 	.globl _P4_6
                                     61 	.globl _RXD
                                     62 	.globl _TXD
                                     63 	.globl _INT0
                                     64 	.globl _INT1
                                     65 	.globl _T0
                                     66 	.globl _T1
                                     67 	.globl _MOSI1
                                     68 	.globl _MISO1
                                     69 	.globl _SCK1
                                     70 	.globl _P3_0
                                     71 	.globl _P3_1
                                     72 	.globl _P3_2
                                     73 	.globl _P3_3
                                     74 	.globl _P3_4
                                     75 	.globl _P3_5
                                     76 	.globl _P3_6
                                     77 	.globl _P3_7
                                     78 	.globl _CAP1_
                                     79 	.globl _T2_
                                     80 	.globl _CAP2_
                                     81 	.globl _T2EX_
                                     82 	.globl _RXD1
                                     83 	.globl _TXD1
                                     84 	.globl _P2_0
                                     85 	.globl _P2_1
                                     86 	.globl _P2_2
                                     87 	.globl _P2_3
                                     88 	.globl _P2_4
                                     89 	.globl _P2_5
                                     90 	.globl _P2_6
                                     91 	.globl _P2_7
                                     92 	.globl _AIN0
                                     93 	.globl _AIN1
                                     94 	.globl _AIN2
                                     95 	.globl _AIN3
                                     96 	.globl _AIN4
                                     97 	.globl _AIN5
                                     98 	.globl _AIN6
                                     99 	.globl _AIN7
                                    100 	.globl _CAP1
                                    101 	.globl _T2
                                    102 	.globl _CAP2
                                    103 	.globl _T2EX
                                    104 	.globl _INT0_
                                    105 	.globl _SCS
                                    106 	.globl _MOSI
                                    107 	.globl _MISO
                                    108 	.globl _SCK
                                    109 	.globl _RXD1_
                                    110 	.globl _TXD1_
                                    111 	.globl _P1_0
                                    112 	.globl _P1_1
                                    113 	.globl _P1_2
                                    114 	.globl _P1_3
                                    115 	.globl _P1_4
                                    116 	.globl _P1_5
                                    117 	.globl _P1_6
                                    118 	.globl _P1_7
                                    119 	.globl _AIN8
                                    120 	.globl _AIN9
                                    121 	.globl _AIN10
                                    122 	.globl _AIN11
                                    123 	.globl _AIN12
                                    124 	.globl _AIN13
                                    125 	.globl _RXD_
                                    126 	.globl _TXD_
                                    127 	.globl _SCL0
                                    128 	.globl _SDA0
                                    129 	.globl _P0_0
                                    130 	.globl _P0_1
                                    131 	.globl _P0_2
                                    132 	.globl _P0_3
                                    133 	.globl _P0_4
                                    134 	.globl _P0_5
                                    135 	.globl _P0_6
                                    136 	.globl _P0_7
                                    137 	.globl _IE_SPI0
                                    138 	.globl _IE_USB
                                    139 	.globl _IE_ADC
                                    140 	.globl _IE_UART1
                                    141 	.globl _IE_PWM_I2C
                                    142 	.globl _IE_GPIO
                                    143 	.globl _IE_WDOG
                                    144 	.globl _PX0
                                    145 	.globl _PT0
                                    146 	.globl _PX1
                                    147 	.globl _PT1
                                    148 	.globl _PS
                                    149 	.globl _PT2
                                    150 	.globl _PL_FLAG
                                    151 	.globl _PH_FLAG
                                    152 	.globl _EX0
                                    153 	.globl _ET0
                                    154 	.globl _EX1
                                    155 	.globl _ET1
                                    156 	.globl _ES
                                    157 	.globl _ET2
                                    158 	.globl _E_DIS
                                    159 	.globl _EA
                                    160 	.globl _P
                                    161 	.globl _F1
                                    162 	.globl _OV
                                    163 	.globl _RS0
                                    164 	.globl _RS1
                                    165 	.globl _F0
                                    166 	.globl _AC
                                    167 	.globl _CY
                                    168 	.globl _I2CS_INT_ST
                                    169 	.globl _I2CX_INT
                                    170 	.globl _LED_STATUS
                                    171 	.globl _LED_DMA_H
                                    172 	.globl _LED_DMA_L
                                    173 	.globl _LED_DMA
                                    174 	.globl _LED_PWM_OE
                                    175 	.globl _LED_COMMON
                                    176 	.globl _ADC_CHAN
                                    177 	.globl _ADC_DAT_H
                                    178 	.globl _ADC_DAT_L
                                    179 	.globl _ADC_DAT
                                    180 	.globl _ADC_CTRL
                                    181 	.globl _SPI1_CK_SE
                                    182 	.globl _SPI1_CTRL
                                    183 	.globl _SPI1_DATA
                                    184 	.globl _SPI1_STAT
                                    185 	.globl _SIF1
                                    186 	.globl _SBAUD1
                                    187 	.globl _SBUF1
                                    188 	.globl _SCON1
                                    189 	.globl _SPI0_SETUP
                                    190 	.globl _SPI0_CK_SE
                                    191 	.globl _SPI0_CTRL
                                    192 	.globl _SPI0_DATA
                                    193 	.globl _SPI0_STAT
                                    194 	.globl _T2CAP1H
                                    195 	.globl _T2CAP1L
                                    196 	.globl _T2CAP1
                                    197 	.globl _TH2
                                    198 	.globl _TL2
                                    199 	.globl _T2COUNT
                                    200 	.globl _RCAP2H
                                    201 	.globl _RCAP2L
                                    202 	.globl _RCAP2
                                    203 	.globl _T2MOD
                                    204 	.globl _T2CON
                                    205 	.globl _SBUF
                                    206 	.globl _SCON
                                    207 	.globl _TH1
                                    208 	.globl _TH0
                                    209 	.globl _TL1
                                    210 	.globl _TL0
                                    211 	.globl _TMOD
                                    212 	.globl _TCON
                                    213 	.globl _XBUS_AUX
                                    214 	.globl _P7
                                    215 	.globl _P6_DIR
                                    216 	.globl _P6_OUT_PU
                                    217 	.globl _P6_IN
                                    218 	.globl _P5_DIR
                                    219 	.globl _P5_OUT_PU
                                    220 	.globl _P5_IN
                                    221 	.globl _P4_LED_KEY
                                    222 	.globl _P4_DIR_PU
                                    223 	.globl _P4_MOD_OC
                                    224 	.globl _P4
                                    225 	.globl _P3_DIR_PU
                                    226 	.globl _P3_MOD_OC
                                    227 	.globl _P3
                                    228 	.globl _P2_DIR_PU
                                    229 	.globl _P2_MOD_OC
                                    230 	.globl _P2
                                    231 	.globl _P1_DIR_PU
                                    232 	.globl _P1_MOD_OC
                                    233 	.globl _P1
                                    234 	.globl _P0_DIR_PU
                                    235 	.globl _P0_MOD_OC
                                    236 	.globl _P0
                                    237 	.globl _ROM_CTRL
                                    238 	.globl _ROM_DATA_HH
                                    239 	.globl _ROM_DATA_HL
                                    240 	.globl _ROM_DATA_HI
                                    241 	.globl _ROM_ADDR_H
                                    242 	.globl _ROM_ADDR_L
                                    243 	.globl _ROM_ADDR
                                    244 	.globl _GPIO_IE
                                    245 	.globl _IP_EX
                                    246 	.globl _IE_EX
                                    247 	.globl _IP
                                    248 	.globl _IE
                                    249 	.globl _WDOG_COUNT
                                    250 	.globl _RESET_KEEP
                                    251 	.globl _WAKE_CTRL
                                    252 	.globl _CLOCK_CFG
                                    253 	.globl _POWER_CFG
                                    254 	.globl _PCON
                                    255 	.globl _GLOBAL_CFG
                                    256 	.globl _SAFE_MOD
                                    257 	.globl _DPH
                                    258 	.globl _DPL
                                    259 	.globl _SP
                                    260 	.globl _A_INV
                                    261 	.globl _B
                                    262 	.globl _ACC
                                    263 	.globl _PSW
                                    264 	.globl _ak820_usb_raw_send_PARM_2
                                    265 	.globl _ak820_usb_try_send_PARM_3
                                    266 	.globl _ak820_usb_try_send_PARM_2
                                    267 	.globl _ak820_usb_send_PARM_3
                                    268 	.globl _ak820_usb_send_PARM_2
                                    269 	.globl _ak820_main_heartbeat
                                    270 	.globl _ak820_boot_stage
                                    271 	.globl _KB_USB_SetReport
                                    272 	.globl _KB_USB_UpStatus
                                    273 	.globl _MCU_Sleep_Operate
                                    274 	.globl _USB_SleepStatus
                                    275 	.globl _USB_EnumStatus
                                    276 	.globl _D0UsbConfig
                                    277 	.globl _pD0Descr
                                    278 	.globl _D0SetupLen
                                    279 	.globl _D0SetupReqCode
                                    280 	.globl _USB_DeviceInterrupt
                                    281 	.globl _USB_Device_Init
                                    282 	.globl _USB_WakeUp_PC
                                    283 	.globl _ak820_usb_send
                                    284 	.globl _ak820_usb_try_send
                                    285 	.globl _ak820_usb_raw_send
                                    286 	.globl _ak820_usb_raw_task
                                    287 	.globl _ak820_usb_take_keyboard_reset
                                    288 ;--------------------------------------------------------
                                    289 ; special function registers
                                    290 ;--------------------------------------------------------
                                    291 	.area RSEG    (ABS,DATA)
      000000                        292 	.org 0x0000
                           0000D0   293 _PSW	=	0x00d0
                           0000E0   294 _ACC	=	0x00e0
                           0000F0   295 _B	=	0x00f0
                           0000FD   296 _A_INV	=	0x00fd
                           000081   297 _SP	=	0x0081
                           000082   298 _DPL	=	0x0082
                           000083   299 _DPH	=	0x0083
                           0000A1   300 _SAFE_MOD	=	0x00a1
                           0000B1   301 _GLOBAL_CFG	=	0x00b1
                           000087   302 _PCON	=	0x0087
                           0000BA   303 _POWER_CFG	=	0x00ba
                           0000B9   304 _CLOCK_CFG	=	0x00b9
                           0000A9   305 _WAKE_CTRL	=	0x00a9
                           0000FE   306 _RESET_KEEP	=	0x00fe
                           0000FF   307 _WDOG_COUNT	=	0x00ff
                           0000A8   308 _IE	=	0x00a8
                           0000B8   309 _IP	=	0x00b8
                           0000E8   310 _IE_EX	=	0x00e8
                           0000E9   311 _IP_EX	=	0x00e9
                           0000B2   312 _GPIO_IE	=	0x00b2
                           008584   313 _ROM_ADDR	=	0x8584
                           000084   314 _ROM_ADDR_L	=	0x0084
                           000085   315 _ROM_ADDR_H	=	0x0085
                           008F8E   316 _ROM_DATA_HI	=	0x8f8e
                           00008E   317 _ROM_DATA_HL	=	0x008e
                           00008F   318 _ROM_DATA_HH	=	0x008f
                           000086   319 _ROM_CTRL	=	0x0086
                           000080   320 _P0	=	0x0080
                           0000C4   321 _P0_MOD_OC	=	0x00c4
                           0000C5   322 _P0_DIR_PU	=	0x00c5
                           000090   323 _P1	=	0x0090
                           000092   324 _P1_MOD_OC	=	0x0092
                           000093   325 _P1_DIR_PU	=	0x0093
                           0000A0   326 _P2	=	0x00a0
                           000094   327 _P2_MOD_OC	=	0x0094
                           000095   328 _P2_DIR_PU	=	0x0095
                           0000B0   329 _P3	=	0x00b0
                           000096   330 _P3_MOD_OC	=	0x0096
                           000097   331 _P3_DIR_PU	=	0x0097
                           0000C0   332 _P4	=	0x00c0
                           0000C2   333 _P4_MOD_OC	=	0x00c2
                           0000C3   334 _P4_DIR_PU	=	0x00c3
                           0000C1   335 _P4_LED_KEY	=	0x00c1
                           0000AA   336 _P5_IN	=	0x00aa
                           0000AB   337 _P5_OUT_PU	=	0x00ab
                           0000AC   338 _P5_DIR	=	0x00ac
                           0000AD   339 _P6_IN	=	0x00ad
                           0000AE   340 _P6_OUT_PU	=	0x00ae
                           0000AF   341 _P6_DIR	=	0x00af
                           0000F1   342 _P7	=	0x00f1
                           0000A2   343 _XBUS_AUX	=	0x00a2
                           000088   344 _TCON	=	0x0088
                           000089   345 _TMOD	=	0x0089
                           00008A   346 _TL0	=	0x008a
                           00008B   347 _TL1	=	0x008b
                           00008C   348 _TH0	=	0x008c
                           00008D   349 _TH1	=	0x008d
                           000098   350 _SCON	=	0x0098
                           000099   351 _SBUF	=	0x0099
                           0000C8   352 _T2CON	=	0x00c8
                           0000C9   353 _T2MOD	=	0x00c9
                           00CBCA   354 _RCAP2	=	0xcbca
                           0000CA   355 _RCAP2L	=	0x00ca
                           0000CB   356 _RCAP2H	=	0x00cb
                           00CDCC   357 _T2COUNT	=	0xcdcc
                           0000CC   358 _TL2	=	0x00cc
                           0000CD   359 _TH2	=	0x00cd
                           00CFCE   360 _T2CAP1	=	0xcfce
                           0000CE   361 _T2CAP1L	=	0x00ce
                           0000CF   362 _T2CAP1H	=	0x00cf
                           0000F8   363 _SPI0_STAT	=	0x00f8
                           0000F9   364 _SPI0_DATA	=	0x00f9
                           0000FA   365 _SPI0_CTRL	=	0x00fa
                           0000FB   366 _SPI0_CK_SE	=	0x00fb
                           0000FC   367 _SPI0_SETUP	=	0x00fc
                           0000BC   368 _SCON1	=	0x00bc
                           0000BD   369 _SBUF1	=	0x00bd
                           0000BE   370 _SBAUD1	=	0x00be
                           0000BF   371 _SIF1	=	0x00bf
                           0000B4   372 _SPI1_STAT	=	0x00b4
                           0000B5   373 _SPI1_DATA	=	0x00b5
                           0000B6   374 _SPI1_CTRL	=	0x00b6
                           0000B7   375 _SPI1_CK_SE	=	0x00b7
                           0000F3   376 _ADC_CTRL	=	0x00f3
                           00F5F4   377 _ADC_DAT	=	0xf5f4
                           0000F4   378 _ADC_DAT_L	=	0x00f4
                           0000F5   379 _ADC_DAT_H	=	0x00f5
                           0000F6   380 _ADC_CHAN	=	0x00f6
                           0000A6   381 _LED_COMMON	=	0x00a6
                           0000A7   382 _LED_PWM_OE	=	0x00a7
                           00C7C6   383 _LED_DMA	=	0xc7c6
                           0000C6   384 _LED_DMA_L	=	0x00c6
                           0000C7   385 _LED_DMA_H	=	0x00c7
                           0000F7   386 _LED_STATUS	=	0x00f7
                           0000B3   387 _I2CX_INT	=	0x00b3
                           0000BB   388 _I2CS_INT_ST	=	0x00bb
                                    389 ;--------------------------------------------------------
                                    390 ; special function bits
                                    391 ;--------------------------------------------------------
                                    392 	.area RSEG    (ABS,DATA)
      000000                        393 	.org 0x0000
                           0000D7   394 _CY	=	0x00d7
                           0000D6   395 _AC	=	0x00d6
                           0000D5   396 _F0	=	0x00d5
                           0000D4   397 _RS1	=	0x00d4
                           0000D3   398 _RS0	=	0x00d3
                           0000D2   399 _OV	=	0x00d2
                           0000D1   400 _F1	=	0x00d1
                           0000D0   401 _P	=	0x00d0
                           0000AF   402 _EA	=	0x00af
                           0000AE   403 _E_DIS	=	0x00ae
                           0000AD   404 _ET2	=	0x00ad
                           0000AC   405 _ES	=	0x00ac
                           0000AB   406 _ET1	=	0x00ab
                           0000AA   407 _EX1	=	0x00aa
                           0000A9   408 _ET0	=	0x00a9
                           0000A8   409 _EX0	=	0x00a8
                           0000BF   410 _PH_FLAG	=	0x00bf
                           0000BE   411 _PL_FLAG	=	0x00be
                           0000BD   412 _PT2	=	0x00bd
                           0000BC   413 _PS	=	0x00bc
                           0000BB   414 _PT1	=	0x00bb
                           0000BA   415 _PX1	=	0x00ba
                           0000B9   416 _PT0	=	0x00b9
                           0000B8   417 _PX0	=	0x00b8
                           0000EF   418 _IE_WDOG	=	0x00ef
                           0000EE   419 _IE_GPIO	=	0x00ee
                           0000ED   420 _IE_PWM_I2C	=	0x00ed
                           0000EC   421 _IE_UART1	=	0x00ec
                           0000EB   422 _IE_ADC	=	0x00eb
                           0000E9   423 _IE_USB	=	0x00e9
                           0000E8   424 _IE_SPI0	=	0x00e8
                           000087   425 _P0_7	=	0x0087
                           000086   426 _P0_6	=	0x0086
                           000085   427 _P0_5	=	0x0085
                           000084   428 _P0_4	=	0x0084
                           000083   429 _P0_3	=	0x0083
                           000082   430 _P0_2	=	0x0082
                           000081   431 _P0_1	=	0x0081
                           000080   432 _P0_0	=	0x0080
                           000081   433 _SDA0	=	0x0081
                           000080   434 _SCL0	=	0x0080
                           000083   435 _TXD_	=	0x0083
                           000082   436 _RXD_	=	0x0082
                           000085   437 _AIN13	=	0x0085
                           000084   438 _AIN12	=	0x0084
                           000083   439 _AIN11	=	0x0083
                           000082   440 _AIN10	=	0x0082
                           000081   441 _AIN9	=	0x0081
                           000080   442 _AIN8	=	0x0080
                           000097   443 _P1_7	=	0x0097
                           000096   444 _P1_6	=	0x0096
                           000095   445 _P1_5	=	0x0095
                           000094   446 _P1_4	=	0x0094
                           000093   447 _P1_3	=	0x0093
                           000092   448 _P1_2	=	0x0092
                           000091   449 _P1_1	=	0x0091
                           000090   450 _P1_0	=	0x0090
                           000097   451 _TXD1_	=	0x0097
                           000096   452 _RXD1_	=	0x0096
                           000097   453 _SCK	=	0x0097
                           000096   454 _MISO	=	0x0096
                           000095   455 _MOSI	=	0x0095
                           000094   456 _SCS	=	0x0094
                           000092   457 _INT0_	=	0x0092
                           000091   458 _T2EX	=	0x0091
                           000091   459 _CAP2	=	0x0091
                           000090   460 _T2	=	0x0090
                           000090   461 _CAP1	=	0x0090
                           000097   462 _AIN7	=	0x0097
                           000096   463 _AIN6	=	0x0096
                           000095   464 _AIN5	=	0x0095
                           000094   465 _AIN4	=	0x0094
                           000093   466 _AIN3	=	0x0093
                           000092   467 _AIN2	=	0x0092
                           000091   468 _AIN1	=	0x0091
                           000090   469 _AIN0	=	0x0090
                           0000A7   470 _P2_7	=	0x00a7
                           0000A6   471 _P2_6	=	0x00a6
                           0000A5   472 _P2_5	=	0x00a5
                           0000A4   473 _P2_4	=	0x00a4
                           0000A3   474 _P2_3	=	0x00a3
                           0000A2   475 _P2_2	=	0x00a2
                           0000A1   476 _P2_1	=	0x00a1
                           0000A0   477 _P2_0	=	0x00a0
                           0000A7   478 _TXD1	=	0x00a7
                           0000A6   479 _RXD1	=	0x00a6
                           0000A5   480 _T2EX_	=	0x00a5
                           0000A5   481 _CAP2_	=	0x00a5
                           0000A4   482 _T2_	=	0x00a4
                           0000A4   483 _CAP1_	=	0x00a4
                           0000B7   484 _P3_7	=	0x00b7
                           0000B6   485 _P3_6	=	0x00b6
                           0000B5   486 _P3_5	=	0x00b5
                           0000B4   487 _P3_4	=	0x00b4
                           0000B3   488 _P3_3	=	0x00b3
                           0000B2   489 _P3_2	=	0x00b2
                           0000B1   490 _P3_1	=	0x00b1
                           0000B0   491 _P3_0	=	0x00b0
                           0000B7   492 _SCK1	=	0x00b7
                           0000B6   493 _MISO1	=	0x00b6
                           0000B5   494 _MOSI1	=	0x00b5
                           0000B5   495 _T1	=	0x00b5
                           0000B4   496 _T0	=	0x00b4
                           0000B3   497 _INT1	=	0x00b3
                           0000B2   498 _INT0	=	0x00b2
                           0000B1   499 _TXD	=	0x00b1
                           0000B0   500 _RXD	=	0x00b0
                           0000C6   501 _P4_6	=	0x00c6
                           0000C5   502 _P4_5	=	0x00c5
                           0000C4   503 _P4_4	=	0x00c4
                           0000C3   504 _P4_3	=	0x00c3
                           0000C2   505 _P4_2	=	0x00c2
                           0000C1   506 _P4_1	=	0x00c1
                           0000C0   507 _P4_0	=	0x00c0
                           00008F   508 _TF1	=	0x008f
                           00008E   509 _TR1	=	0x008e
                           00008D   510 _TF0	=	0x008d
                           00008C   511 _TR0	=	0x008c
                           00008B   512 _IE1	=	0x008b
                           00008A   513 _IT1	=	0x008a
                           000089   514 _IE0	=	0x0089
                           000088   515 _IT0	=	0x0088
                           00009F   516 _SM0	=	0x009f
                           00009E   517 _SM1	=	0x009e
                           00009D   518 _SM2	=	0x009d
                           00009C   519 _REN	=	0x009c
                           00009B   520 _TB8	=	0x009b
                           00009A   521 _RB8	=	0x009a
                           000099   522 _TI	=	0x0099
                           000098   523 _RI	=	0x0098
                           0000CF   524 _TF2	=	0x00cf
                           0000CF   525 _CAP1F	=	0x00cf
                           0000CE   526 _EXF2	=	0x00ce
                           0000CD   527 _RCLK	=	0x00cd
                           0000CC   528 _TCLK	=	0x00cc
                           0000CB   529 _EXEN2	=	0x00cb
                           0000CA   530 _TR2	=	0x00ca
                           0000C9   531 _C_T2	=	0x00c9
                           0000C8   532 _CP_RL2	=	0x00c8
                           0000FF   533 _S0_FST_ACT	=	0x00ff
                           0000FE   534 _S0_IF_OV	=	0x00fe
                           0000FD   535 _S0_IF_FIRST	=	0x00fd
                           0000FC   536 _S0_IF_BYTE	=	0x00fc
                           0000FB   537 _S0_FREE	=	0x00fb
                           0000FA   538 _S0_T_FIFO	=	0x00fa
                           0000F8   539 _S0_R_FIFO	=	0x00f8
                           0000F7   540 _ADC_START	=	0x00f7
                                    541 ;--------------------------------------------------------
                                    542 ; overlayable register banks
                                    543 ;--------------------------------------------------------
                                    544 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        545 	.ds 8
                                    546 ;--------------------------------------------------------
                                    547 ; internal ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area DSEG    (DATA)
      000016                        550 _control_setup_sloc1_1_0:
      000016                        551 	.ds 1
      000017                        552 _control_setup_sloc3_1_0:
      000017                        553 	.ds 2
      000019                        554 _control_setup_sloc4_1_0:
      000019                        555 	.ds 2
      00001B                        556 _ak820_usb_send_sloc0_1_0:
      00001B                        557 	.ds 2
      00001D                        558 _ak820_usb_send_sloc1_1_0:
      00001D                        559 	.ds 1
      00001E                        560 _ak820_usb_raw_task_sloc0_1_0:
      00001E                        561 	.ds 2
                                    562 ;--------------------------------------------------------
                                    563 ; overlayable items in internal ram
                                    564 ;--------------------------------------------------------
                                    565 ;--------------------------------------------------------
                                    566 ; indirectly addressable internal ram data
                                    567 ;--------------------------------------------------------
                                    568 	.area ISEG    (DATA)
                                    569 ;--------------------------------------------------------
                                    570 ; absolute internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area IABS    (ABS,DATA)
                                    573 	.area IABS    (ABS,DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; bit data
                                    576 ;--------------------------------------------------------
                                    577 	.area BSEG    (BIT)
      000016                        578 _control_setup_valid_interface_10000_289:
      000016                        579 	.ds 1
      000017                        580 _control_setup_zero_index_10000_289:
      000017                        581 	.ds 1
      000018                        582 _control_setup_zero_value_10000_289:
      000018                        583 	.ds 1
      000019                        584 _control_setup_zero_length_10000_289:
      000019                        585 	.ds 1
      00001A                        586 _control_setup_sloc0_1_0:
      00001A                        587 	.ds 1
      00001B                        588 _control_setup_sloc2_1_0:
      00001B                        589 	.ds 1
      00001C                        590 _ak820_usb_try_send_sloc0_1_0:
      00001C                        591 	.ds 1
      00001D                        592 _ak820_usb_raw_task_sloc1_1_0:
      00001D                        593 	.ds 1
      00001E                        594 _ak820_usb_take_keyboard_reset_sloc0_1_0:
      00001E                        595 	.ds 1
                                    596 ;--------------------------------------------------------
                                    597 ; paged external ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area PSEG    (PAG,XDATA)
                                    600 ;--------------------------------------------------------
                                    601 ; uninitialized external ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area XSEG    (XDATA)
      00076D                        604 _D0SetupReqCode::
      00076D                        605 	.ds 1
      00076E                        606 _D0SetupLen::
      00076E                        607 	.ds 2
      000770                        608 _pD0Descr::
      000770                        609 	.ds 3
      000773                        610 _D0UsbConfig::
      000773                        611 	.ds 1
      000774                        612 _USB_EnumStatus::
      000774                        613 	.ds 1
      000775                        614 _USB_SleepStatus::
      000775                        615 	.ds 1
      000776                        616 _MCU_Sleep_Operate::
      000776                        617 	.ds 1
      000777                        618 _KB_USB_UpStatus::
      000777                        619 	.ds 1
      000778                        620 _KB_USB_SetReport::
      000778                        621 	.ds 1
      000779                        622 _ak820_boot_stage::
      000779                        623 	.ds 1
      00077A                        624 _ak820_main_heartbeat::
      00077A                        625 	.ds 1
      00077B                        626 _raw_state:
      00077B                        627 	.ds 1
      00077C                        628 _raw_buffer:
      00077C                        629 	.ds 32
      00079C                        630 _raw_reply_without_nvm:
      00079C                        631 	.ds 1
      00079D                        632 _keyboard_reset:
      00079D                        633 	.ds 1
      00079E                        634 _input_snapshot:
      00079E                        635 	.ds 46
      0007CC                        636 _control_phase:
      0007CC                        637 	.ds 1
      0007CD                        638 _output_kind:
      0007CD                        639 	.ds 1
      0007CE                        640 _output_report_id:
      0007CE                        641 	.ds 1
      0007CF                        642 _control_zlp:
      0007CF                        643 	.ds 1
      0007D0                        644 _control_pointer:
      0007D0                        645 	.ds 2
      0007D2                        646 _descriptor_select_PARM_2:
      0007D2                        647 	.ds 1
      0007D3                        648 _descriptor_select_PARM_3:
      0007D3                        649 	.ds 2
      0007D5                        650 _descriptor_select_type_10000_271:
      0007D5                        651 	.ds 1
      0007D6                        652 _control_setup_length_10000_289:
      0007D6                        653 	.ds 2
      0007D8                        654 _control_setup_offset_10000_289:
      0007D8                        655 	.ds 1
      0007D9                        656 _ak820_usb_send_PARM_2:
      0007D9                        657 	.ds 2
      0007DB                        658 _ak820_usb_send_PARM_3:
      0007DB                        659 	.ds 1
      0007DC                        660 _ak820_usb_send_endpoint_10000_425:
      0007DC                        661 	.ds 1
      0007DD                        662 _ak820_usb_send_offset_10000_426:
      0007DD                        663 	.ds 1
      0007DE                        664 _ak820_usb_try_send_PARM_2:
      0007DE                        665 	.ds 2
      0007E0                        666 _ak820_usb_try_send_PARM_3:
      0007E0                        667 	.ds 1
      0007E1                        668 _ak820_usb_try_send_endpoint_10000_446:
      0007E1                        669 	.ds 1
      0007E2                        670 _ak820_usb_try_send_sent_10000_447:
      0007E2                        671 	.ds 1
      0007E3                        672 _ak820_usb_raw_send_PARM_2:
      0007E3                        673 	.ds 1
      0007E4                        674 _ak820_usb_raw_send_report_10000_462:
      0007E4                        675 	.ds 3
      0007E7                        676 _ak820_usb_raw_task_length_10000_467:
      0007E7                        677 	.ds 1
                                    678 ;--------------------------------------------------------
                                    679 ; absolute external ram data
                                    680 ;--------------------------------------------------------
                                    681 	.area XABS    (ABS,XDATA)
                                    682 ;--------------------------------------------------------
                                    683 ; initialized external ram data
                                    684 ;--------------------------------------------------------
                                    685 	.area XISEG   (XDATA)
                                    686 	.area HOME    (CODE)
                                    687 	.area GSINIT0 (CODE)
                                    688 	.area GSINIT1 (CODE)
                                    689 	.area GSINIT2 (CODE)
                                    690 	.area GSINIT3 (CODE)
                                    691 	.area GSINIT4 (CODE)
                                    692 	.area GSINIT5 (CODE)
                                    693 	.area GSINIT  (CODE)
                                    694 	.area GSFINAL (CODE)
                                    695 	.area CSEG    (CODE)
                                    696 ;--------------------------------------------------------
                                    697 ; global & static initialisations
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area GSINIT  (CODE)
                                    701 	.area GSFINAL (CODE)
                                    702 	.area GSINIT  (CODE)
                                    703 ;--------------------------------------------------------
                                    704 ; Home
                                    705 ;--------------------------------------------------------
                                    706 	.area HOME    (CODE)
                                    707 	.area HOME    (CODE)
                                    708 ;--------------------------------------------------------
                                    709 ; code
                                    710 ;--------------------------------------------------------
                                    711 	.area CSEG    (CODE)
                                    712 ;------------------------------------------------------------
                                    713 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    714 ;------------------------------------------------------------
                                    715 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_45'
                                    716 ;------------------------------------------------------------
                                    717 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    718 ;	-----------------------------------------
                           000007   719 	ar7 = 0x07
                           000006   720 	ar6 = 0x06
                           000005   721 	ar5 = 0x05
                           000004   722 	ar4 = 0x04
                           000003   723 	ar3 = 0x03
                           000002   724 	ar2 = 0x02
                           000001   725 	ar1 = 0x01
                           000000   726 	ar0 = 0x00
                                    727 ;	 function raw_abort
                                    728 ;	-----------------------------------------
      005B70                        729 _raw_abort:
                                    730 ;	tmk_core/protocol/ch555/usb_ak820.c:97: if (raw_state == RAW_WORK || raw_state == RAW_TX_ACTIVE ||
      005B70 90 07 7B         [24]  731 	mov	dptr,#_raw_state
      005B73 E0               [24]  732 	movx	a,@dptr
      005B74 FF               [12]  733 	mov	r7,a
      005B75 BF 03 02         [24]  734 	cjne	r7,#0x03,00130$
      005B78 80 1C            [24]  735 	sjmp	00101$
      005B7A                        736 00130$:
      005B7A 90 07 7B         [24]  737 	mov	dptr,#_raw_state
      005B7D E0               [24]  738 	movx	a,@dptr
      005B7E FF               [12]  739 	mov	r7,a
      005B7F BF 04 02         [24]  740 	cjne	r7,#0x04,00131$
      005B82 80 12            [24]  741 	sjmp	00101$
      005B84                        742 00131$:
                                    743 ;	tmk_core/protocol/ch555/usb_ak820.c:98: raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED)
      005B84 90 07 7B         [24]  744 	mov	dptr,#_raw_state
      005B87 E0               [24]  745 	movx	a,@dptr
      005B88 FF               [12]  746 	mov	r7,a
      005B89 BF 06 02         [24]  747 	cjne	r7,#0x06,00132$
      005B8C 80 08            [24]  748 	sjmp	00101$
      005B8E                        749 00132$:
      005B8E 90 07 7B         [24]  750 	mov	dptr,#_raw_state
      005B91 E0               [24]  751 	movx	a,@dptr
      005B92 FF               [12]  752 	mov	r7,a
      005B93 BF 07 08         [24]  753 	cjne	r7,#0x07,00102$
      005B96                        754 00101$:
                                    755 ;	tmk_core/protocol/ch555/usb_ak820.c:99: raw_state = RAW_CANCELLED;
      005B96 90 07 7B         [24]  756 	mov	dptr,#_raw_state
      005B99 74 07            [12]  757 	mov	a,#0x07
      005B9B F0               [24]  758 	movx	@dptr,a
      005B9C 80 05            [24]  759 	sjmp	00103$
      005B9E                        760 00102$:
                                    761 ;	tmk_core/protocol/ch555/usb_ak820.c:101: raw_state = RAW_IDLE;
      005B9E 90 07 7B         [24]  762 	mov	dptr,#_raw_state
      005BA1 E4               [12]  763 	clr	a
      005BA2 F0               [24]  764 	movx	@dptr,a
      005BA3                        765 00103$:
                                    766 ;	tmk_core/protocol/ch555/usb_ak820.c:102: output_kind = OUTPUT_NONE;
      005BA3 90 07 CD         [24]  767 	mov	dptr,#_output_kind
      005BA6 E4               [12]  768 	clr	a
      005BA7 F0               [24]  769 	movx	@dptr,a
                                    770 ;	tmk_core/protocol/ch555/usb_ak820.c:103: }
      005BA8 22               [24]  771 	ret
                                    772 ;------------------------------------------------------------
                                    773 ;Allocation info for local variables in function 'raw_complete'
                                    774 ;------------------------------------------------------------
                                    775 ;	tmk_core/protocol/ch555/usb_ak820.c:105: static void raw_complete(void) {
                                    776 ;	-----------------------------------------
                                    777 ;	 function raw_complete
                                    778 ;	-----------------------------------------
      005BA9                        779 _raw_complete:
                                    780 ;	tmk_core/protocol/ch555/usb_ak820.c:106: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_DRAINED;
      005BA9 90 07 7B         [24]  781 	mov	dptr,#_raw_state
      005BAC E0               [24]  782 	movx	a,@dptr
      005BAD FF               [12]  783 	mov	r7,a
      005BAE BF 04 07         [24]  784 	cjne	r7,#0x04,00104$
      005BB1 90 07 7B         [24]  785 	mov	dptr,#_raw_state
      005BB4 74 06            [12]  786 	mov	a,#0x06
      005BB6 F0               [24]  787 	movx	@dptr,a
      005BB7 22               [24]  788 	ret
      005BB8                        789 00104$:
                                    790 ;	tmk_core/protocol/ch555/usb_ak820.c:107: else if (raw_state == RAW_TX_WAIT) raw_state = RAW_IDLE;
      005BB8 90 07 7B         [24]  791 	mov	dptr,#_raw_state
      005BBB E0               [24]  792 	movx	a,@dptr
      005BBC FF               [12]  793 	mov	r7,a
      005BBD BF 05 05         [24]  794 	cjne	r7,#0x05,00106$
      005BC0 90 07 7B         [24]  795 	mov	dptr,#_raw_state
      005BC3 E4               [12]  796 	clr	a
      005BC4 F0               [24]  797 	movx	@dptr,a
      005BC5                        798 00106$:
                                    799 ;	tmk_core/protocol/ch555/usb_ak820.c:108: }
      005BC5 22               [24]  800 	ret
                                    801 ;------------------------------------------------------------
                                    802 ;Allocation info for local variables in function 'endpoints_reset'
                                    803 ;------------------------------------------------------------
                                    804 ;i             Allocated with name '_endpoints_reset_i_10000_261'
                                    805 ;------------------------------------------------------------
                                    806 ;	tmk_core/protocol/ch555/usb_ak820.c:110: static void endpoints_reset(void) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function endpoints_reset
                                    809 ;	-----------------------------------------
      005BC6                        810 _endpoints_reset:
                                    811 ;	tmk_core/protocol/ch555/usb_ak820.c:113: ak820_os_indicator_mode = AK820_OS_NORMAL;
      005BC6 90 05 9E         [24]  812 	mov	dptr,#_ak820_os_indicator_mode
      005BC9 E4               [12]  813 	clr	a
      005BCA F0               [24]  814 	movx	@dptr,a
                                    815 ;	tmk_core/protocol/ch555/usb_ak820.c:116: D0_EP_MOD = bUX_DEV_EN;
      005BCB 90 22 0C         [24]  816 	mov	dptr,#0x220c
      005BCE 04               [12]  817 	inc	a
      005BCF F0               [24]  818 	movx	@dptr,a
                                    819 ;	tmk_core/protocol/ch555/usb_ak820.c:117: D0_EP1RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005BD0 F5 82            [12]  820 	mov	dpl,a
      005BD2 74 12            [12]  821 	mov	a,#0x12
      005BD4 F0               [24]  822 	movx	@dptr,a
                                    823 ;	tmk_core/protocol/ch555/usb_ak820.c:118: D0_EP2RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005BD5 A3               [24]  824 	inc	dptr
      005BD6 F0               [24]  825 	movx	@dptr,a
                                    826 ;	tmk_core/protocol/ch555/usb_ak820.c:119: D0_EP3RES = bUEP_X_AUTO_TOG | UEP_X_RES_NAK;
      005BD7 A3               [24]  827 	inc	dptr
      005BD8 F0               [24]  828 	movx	@dptr,a
                                    829 ;	tmk_core/protocol/ch555/usb_ak820.c:120: D0_EP1T_L = D0_EP2T_L = D0_EP3T_L = 0;
      005BD9 90 22 0B         [24]  830 	mov	dptr,#0x220b
      005BDC E4               [12]  831 	clr	a
      005BDD F0               [24]  832 	movx	@dptr,a
      005BDE 15 82            [12]  833 	dec	dpl
      005BE0 F0               [24]  834 	movx	@dptr,a
      005BE1 15 82            [12]  835 	dec	dpl
      005BE3 F0               [24]  836 	movx	@dptr,a
                                    837 ;	tmk_core/protocol/ch555/usb_ak820.c:121: for (i = 0; i < SNAPSHOT_SIZE; ++i) input_snapshot[i] = 0;
      005BE4 FF               [12]  838 	mov	r7,a
      005BE5                        839 00103$:
      005BE5 EF               [12]  840 	mov	a,r7
      005BE6 24 9E            [12]  841 	add	a, #_input_snapshot
      005BE8 F5 82            [12]  842 	mov	dpl,a
      005BEA E4               [12]  843 	clr	a
      005BEB 34 07            [12]  844 	addc	a, #(_input_snapshot >> 8)
      005BED F5 83            [12]  845 	mov	dph,a
      005BEF E4               [12]  846 	clr	a
      005BF0 F0               [24]  847 	movx	@dptr,a
      005BF1 0F               [12]  848 	inc	r7
      005BF2 BF 2E 00         [24]  849 	cjne	r7,#0x2e,00139$
      005BF5                        850 00139$:
      005BF5 40 EE            [24]  851 	jc	00103$
                                    852 ;	tmk_core/protocol/ch555/usb_ak820.c:122: input_snapshot[SNAPSHOT_NKRO] = REPORT_ID_NKRO;
      005BF7 90 07 A6         [24]  853 	mov	dptr,#(_input_snapshot + 0x0008)
      005BFA 74 06            [12]  854 	mov	a,#0x06
      005BFC F0               [24]  855 	movx	@dptr,a
                                    856 ;	tmk_core/protocol/ch555/usb_ak820.c:126: input_snapshot[SNAPSHOT_SYSTEM] = REPORT_ID_SYSTEM;
      005BFD 90 07 C6         [24]  857 	mov	dptr,#(_input_snapshot + 0x0028)
      005C00 03               [12]  858 	rr	a
      005C01 F0               [24]  859 	movx	@dptr,a
                                    860 ;	tmk_core/protocol/ch555/usb_ak820.c:127: input_snapshot[SNAPSHOT_CONSUMER] = REPORT_ID_CONSUMER;
      005C02 90 07 C9         [24]  861 	mov	dptr,#(_input_snapshot + 0x002b)
      005C05 04               [12]  862 	inc	a
      005C06 F0               [24]  863 	movx	@dptr,a
                                    864 ;	tmk_core/protocol/ch555/usb_ak820.c:128: for (i = 0; i < RAW_EPSIZE; ++i) pUSB_BUF_DEV0[UX_EP3_ADDR + i] = 0;
      005C07 7F 00            [12]  865 	mov	r7,#0x00
      005C09                        866 00105$:
      005C09 8F 06            [24]  867 	mov	ar6,r7
      005C0B 74 C0            [12]  868 	mov	a,#0xc0
      005C0D 2E               [12]  869 	add	a, r6
      005C0E F5 82            [12]  870 	mov	dpl,a
      005C10 74 10            [12]  871 	mov	a,#0x10
      005C12 24 00            [12]  872 	add	a, #0x00
      005C14 F5 83            [12]  873 	mov	dph,a
      005C16 E4               [12]  874 	clr	a
      005C17 F0               [24]  875 	movx	@dptr,a
      005C18 0F               [12]  876 	inc	r7
      005C19 BF 20 00         [24]  877 	cjne	r7,#0x20,00141$
      005C1C                        878 00141$:
      005C1C 40 EB            [24]  879 	jc	00105$
                                    880 ;	tmk_core/protocol/ch555/usb_ak820.c:129: raw_abort();
                                    881 ;	tmk_core/protocol/ch555/usb_ak820.c:130: }
      005C1E 02 5B 70         [24]  882 	ljmp	_raw_abort
                                    883 ;------------------------------------------------------------
                                    884 ;Allocation info for local variables in function 'control_stall'
                                    885 ;------------------------------------------------------------
                                    886 ;	tmk_core/protocol/ch555/usb_ak820.c:132: static void control_stall(void) {
                                    887 ;	-----------------------------------------
                                    888 ;	 function control_stall
                                    889 ;	-----------------------------------------
      005C21                        890 _control_stall:
                                    891 ;	tmk_core/protocol/ch555/usb_ak820.c:133: if (raw_state == RAW_RX) raw_state = RAW_IDLE;
      005C21 90 07 7B         [24]  892 	mov	dptr,#_raw_state
      005C24 E0               [24]  893 	movx	a,@dptr
      005C25 FF               [12]  894 	mov	r7,a
      005C26 BF 01 05         [24]  895 	cjne	r7,#0x01,00102$
      005C29 90 07 7B         [24]  896 	mov	dptr,#_raw_state
      005C2C E4               [12]  897 	clr	a
      005C2D F0               [24]  898 	movx	@dptr,a
      005C2E                        899 00102$:
                                    900 ;	tmk_core/protocol/ch555/usb_ak820.c:134: output_kind = OUTPUT_NONE;
      005C2E 90 07 CD         [24]  901 	mov	dptr,#_output_kind
      005C31 E4               [12]  902 	clr	a
      005C32 F0               [24]  903 	movx	@dptr,a
                                    904 ;	tmk_core/protocol/ch555/usb_ak820.c:135: control_phase = CTRL_IDLE;
      005C33 90 07 CC         [24]  905 	mov	dptr,#_control_phase
      005C36 F0               [24]  906 	movx	@dptr,a
                                    907 ;	tmk_core/protocol/ch555/usb_ak820.c:136: D0SetupReqCode = 0xff;
      005C37 90 07 6D         [24]  908 	mov	dptr,#_D0SetupReqCode
      005C3A 14               [12]  909 	dec	a
      005C3B F0               [24]  910 	movx	@dptr,a
                                    911 ;	tmk_core/protocol/ch555/usb_ak820.c:138: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_STALL | UEP_T_RES_STALL;
      005C3C 90 22 00         [24]  912 	mov	dptr,#0x2200
      005C3F 74 CF            [12]  913 	mov	a,#0xcf
      005C41 F0               [24]  914 	movx	@dptr,a
                                    915 ;	tmk_core/protocol/ch555/usb_ak820.c:139: }
      005C42 22               [24]  916 	ret
                                    917 ;------------------------------------------------------------
                                    918 ;Allocation info for local variables in function 'control_next'
                                    919 ;------------------------------------------------------------
                                    920 ;i             Allocated with name '_control_next_i_10000_268'
                                    921 ;length        Allocated with name '_control_next_length_10000_268'
                                    922 ;------------------------------------------------------------
                                    923 ;	tmk_core/protocol/ch555/usb_ak820.c:141: static void control_next(void) {
                                    924 ;	-----------------------------------------
                                    925 ;	 function control_next
                                    926 ;	-----------------------------------------
      005C43                        927 _control_next:
                                    928 ;	tmk_core/protocol/ch555/usb_ak820.c:143: uint8_t length = D0SetupLen > DEF_ENDP0_SIZE ? DEF_ENDP0_SIZE : D0SetupLen;
      005C43 90 07 6E         [24]  929 	mov	dptr,#_D0SetupLen
      005C46 E0               [24]  930 	movx	a,@dptr
      005C47 FE               [12]  931 	mov	r6,a
      005C48 A3               [24]  932 	inc	dptr
      005C49 E0               [24]  933 	movx	a,@dptr
      005C4A FF               [12]  934 	mov	r7,a
      005C4B C3               [12]  935 	clr	c
      005C4C 74 40            [12]  936 	mov	a,#0x40
      005C4E 9E               [12]  937 	subb	a,r6
      005C4F E4               [12]  938 	clr	a
      005C50 9F               [12]  939 	subb	a,r7
      005C51 50 04            [24]  940 	jnc	00109$
                                    941 ;	free result
      005C53 7E 40            [12]  942 	mov	r6,#0x40
      005C55 80 07            [24]  943 	sjmp	00110$
      005C57                        944 00109$:
      005C57 90 07 6E         [24]  945 	mov	dptr,#_D0SetupLen
      005C5A E0               [24]  946 	movx	a,@dptr
      005C5B FE               [12]  947 	mov	r6,a
      005C5C A3               [24]  948 	inc	dptr
      005C5D E0               [24]  949 	movx	a,@dptr
      005C5E                        950 00110$:
                                    951 ;	tmk_core/protocol/ch555/usb_ak820.c:144: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = *control_pointer++;
      005C5E 7F 00            [12]  952 	mov	r7,#0x00
      005C60                        953 00105$:
      005C60 C3               [12]  954 	clr	c
      005C61 EF               [12]  955 	mov	a,r7
      005C62 9E               [12]  956 	subb	a,r6
      005C63 50 2A            [24]  957 	jnc	00101$
      005C65 8F 04            [24]  958 	mov	ar4,r7
      005C67 74 10            [12]  959 	mov	a,#0x10
      005C69 24 00            [12]  960 	add	a, #0x00
      005C6B FD               [12]  961 	mov	r5,a
      005C6C 90 07 D0         [24]  962 	mov	dptr,#_control_pointer
      005C6F E0               [24]  963 	movx	a,@dptr
      005C70 FA               [12]  964 	mov	r2,a
      005C71 A3               [24]  965 	inc	dptr
      005C72 E0               [24]  966 	movx	a,@dptr
      005C73 FB               [12]  967 	mov	r3,a
      005C74 8A 82            [24]  968 	mov	dpl,r2
      005C76 8B 83            [24]  969 	mov	dph,r3
      005C78 E4               [12]  970 	clr	a
      005C79 93               [24]  971 	movc	a,@a+dptr
      005C7A F9               [12]  972 	mov	r1,a
      005C7B 90 07 D0         [24]  973 	mov	dptr,#_control_pointer
      005C7E 74 01            [12]  974 	mov	a,#0x01
      005C80 2A               [12]  975 	add	a, r2
      005C81 F0               [24]  976 	movx	@dptr,a
      005C82 E4               [12]  977 	clr	a
      005C83 3B               [12]  978 	addc	a, r3
      005C84 A3               [24]  979 	inc	dptr
      005C85 F0               [24]  980 	movx	@dptr,a
      005C86 8C 82            [24]  981 	mov	dpl,r4
      005C88 8D 83            [24]  982 	mov	dph,r5
      005C8A E9               [12]  983 	mov	a,r1
      005C8B F0               [24]  984 	movx	@dptr,a
      005C8C 0F               [12]  985 	inc	r7
      005C8D 80 D1            [24]  986 	sjmp	00105$
      005C8F                        987 00101$:
                                    988 ;	tmk_core/protocol/ch555/usb_ak820.c:145: D0SetupLen -= length;
      005C8F 8E 05            [24]  989 	mov	ar5,r6
      005C91 7F 00            [12]  990 	mov	r7,#0x00
      005C93 90 07 6E         [24]  991 	mov	dptr,#_D0SetupLen
      005C96 E0               [24]  992 	movx	a,@dptr
      005C97 FB               [12]  993 	mov	r3,a
      005C98 A3               [24]  994 	inc	dptr
      005C99 E0               [24]  995 	movx	a,@dptr
      005C9A FC               [12]  996 	mov	r4,a
      005C9B EB               [12]  997 	mov	a,r3
      005C9C C3               [12]  998 	clr	c
      005C9D 9D               [12]  999 	subb	a,r5
      005C9E FB               [12] 1000 	mov	r3,a
      005C9F EC               [12] 1001 	mov	a,r4
      005CA0 9F               [12] 1002 	subb	a,r7
      005CA1 FC               [12] 1003 	mov	r4,a
      005CA2 90 07 6E         [24] 1004 	mov	dptr,#_D0SetupLen
      005CA5 EB               [12] 1005 	mov	a,r3
      005CA6 F0               [24] 1006 	movx	@dptr,a
      005CA7 EC               [12] 1007 	mov	a,r4
      005CA8 A3               [24] 1008 	inc	dptr
      005CA9 F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	tmk_core/protocol/ch555/usb_ak820.c:146: if (!length) control_zlp = 0;
      005CAA EE               [12] 1011 	mov	a,r6
      005CAB 70 05            [24] 1012 	jnz	00103$
      005CAD 90 07 CF         [24] 1013 	mov	dptr,#_control_zlp
      005CB0 E4               [12] 1014 	clr	a
      005CB1 F0               [24] 1015 	movx	@dptr,a
      005CB2                       1016 00103$:
                                   1017 ;	tmk_core/protocol/ch555/usb_ak820.c:147: D0_EP0T_L = length;
      005CB2 90 22 08         [24] 1018 	mov	dptr,#0x2208
      005CB5 EE               [12] 1019 	mov	a,r6
      005CB6 F0               [24] 1020 	movx	@dptr,a
                                   1021 ;	tmk_core/protocol/ch555/usb_ak820.c:148: D0_EP0RES = (D0_EP0RES & (bUEP_T_TOG | bUEP_R_TOG)) | UEP_T_RES_ACK | UEP_R_RES_ACK;
      005CB7 90 22 00         [24] 1022 	mov	dptr,#0x2200
      005CBA E0               [24] 1023 	movx	a,@dptr
      005CBB 54 C0            [12] 1024 	anl	a,#0xc0
      005CBD F0               [24] 1025 	movx	@dptr,a
                                   1026 ;	tmk_core/protocol/ch555/usb_ak820.c:149: }
      005CBE 22               [24] 1027 	ret
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'descriptor_select'
                                   1030 ;------------------------------------------------------------
                                   1031 ;index         Allocated with name '_descriptor_select_PARM_2'
                                   1032 ;interface     Allocated with name '_descriptor_select_PARM_3'
                                   1033 ;type          Allocated with name '_descriptor_select_type_10000_271'
                                   1034 ;hid           Allocated with name '_descriptor_select_hid_30000_284'
                                   1035 ;------------------------------------------------------------
                                   1036 ;	tmk_core/protocol/ch555/usb_ak820.c:166: static uint16_t descriptor_select(uint8_t type, uint8_t index, uint16_t interface) {
                                   1037 ;	-----------------------------------------
                                   1038 ;	 function descriptor_select
                                   1039 ;	-----------------------------------------
      005CBF                       1040 _descriptor_select:
      005CBF E5 82            [12] 1041 	mov	a,dpl
      005CC1 90 07 D5         [24] 1042 	mov	dptr,#_descriptor_select_type_10000_271
      005CC4 F0               [24] 1043 	movx	@dptr,a
                                   1044 ;	tmk_core/protocol/ch555/usb_ak820.c:167: if (type == USB_DESCR_TYP_DEVICE && !index && !interface) {
      005CC5 E0               [24] 1045 	movx	a,@dptr
      005CC6 FF               [12] 1046 	mov	r7,a
      005CC7 BF 01 20         [24] 1047 	cjne	r7,#0x01,00102$
      005CCA 90 07 D2         [24] 1048 	mov	dptr,#_descriptor_select_PARM_2
      005CCD E0               [24] 1049 	movx	a,@dptr
      005CCE 70 1A            [24] 1050 	jnz	00102$
      005CD0 90 07 D3         [24] 1051 	mov	dptr,#_descriptor_select_PARM_3
      005CD3 E0               [24] 1052 	movx	a,@dptr
      005CD4 F5 F0            [12] 1053 	mov	b,a
      005CD6 A3               [24] 1054 	inc	dptr
      005CD7 E0               [24] 1055 	movx	a,@dptr
      005CD8 45 F0            [12] 1056 	orl	a,b
      005CDA 70 0E            [24] 1057 	jnz	00102$
                                   1058 ;	tmk_core/protocol/ch555/usb_ak820.c:168: control_pointer = (const uint8_t __code *)&DeviceDescriptor;
      005CDC 90 07 D0         [24] 1059 	mov	dptr,#_control_pointer
      005CDF 74 9B            [12] 1060 	mov	a,#_DeviceDescriptor
      005CE1 F0               [24] 1061 	movx	@dptr,a
      005CE2 74 C2            [12] 1062 	mov	a,#(_DeviceDescriptor >> 8)
      005CE4 A3               [24] 1063 	inc	dptr
      005CE5 F0               [24] 1064 	movx	@dptr,a
                                   1065 ;	tmk_core/protocol/ch555/usb_ak820.c:169: return sizeof(DeviceDescriptor);
      005CE6 90 00 12         [24] 1066 	mov	dptr,#0x0012
      005CE9 22               [24] 1067 	ret
      005CEA                       1068 00102$:
                                   1069 ;	tmk_core/protocol/ch555/usb_ak820.c:171: if (type == USB_DESCR_TYP_CONFIG && !index && !interface) {
      005CEA 90 07 D5         [24] 1070 	mov	dptr,#_descriptor_select_type_10000_271
      005CED E0               [24] 1071 	movx	a,@dptr
      005CEE FF               [12] 1072 	mov	r7,a
      005CEF BF 02 20         [24] 1073 	cjne	r7,#0x02,00106$
      005CF2 90 07 D2         [24] 1074 	mov	dptr,#_descriptor_select_PARM_2
      005CF5 E0               [24] 1075 	movx	a,@dptr
      005CF6 70 1A            [24] 1076 	jnz	00106$
      005CF8 90 07 D3         [24] 1077 	mov	dptr,#_descriptor_select_PARM_3
      005CFB E0               [24] 1078 	movx	a,@dptr
      005CFC F5 F0            [12] 1079 	mov	b,a
      005CFE A3               [24] 1080 	inc	dptr
      005CFF E0               [24] 1081 	movx	a,@dptr
      005D00 45 F0            [12] 1082 	orl	a,b
      005D02 70 0E            [24] 1083 	jnz	00106$
                                   1084 ;	tmk_core/protocol/ch555/usb_ak820.c:172: control_pointer = (const uint8_t __code *)&ConfigurationDescriptor;
      005D04 90 07 D0         [24] 1085 	mov	dptr,#_control_pointer
      005D07 74 AD            [12] 1086 	mov	a,#_ConfigurationDescriptor
      005D09 F0               [24] 1087 	movx	@dptr,a
      005D0A 74 C2            [12] 1088 	mov	a,#(_ConfigurationDescriptor >> 8)
      005D0C A3               [24] 1089 	inc	dptr
      005D0D F0               [24] 1090 	movx	@dptr,a
                                   1091 ;	tmk_core/protocol/ch555/usb_ak820.c:173: return sizeof(ConfigurationDescriptor);
      005D0E 90 00 54         [24] 1092 	mov	dptr,#0x0054
      005D11 22               [24] 1093 	ret
      005D12                       1094 00106$:
                                   1095 ;	tmk_core/protocol/ch555/usb_ak820.c:175: if (type == USB_DESCR_TYP_STRING) {
      005D12 90 07 D5         [24] 1096 	mov	dptr,#_descriptor_select_type_10000_271
      005D15 E0               [24] 1097 	movx	a,@dptr
      005D16 FF               [12] 1098 	mov	r7,a
      005D17 BF 03 02         [24] 1099 	cjne	r7,#0x03,00238$
      005D1A 80 03            [24] 1100 	sjmp	00239$
      005D1C                       1101 00238$:
      005D1C 02 5D B6         [24] 1102 	ljmp	00119$
      005D1F                       1103 00239$:
                                   1104 ;	tmk_core/protocol/ch555/usb_ak820.c:176: if (interface != 0 && interface != 0x0409) return 0;
      005D1F 90 07 D3         [24] 1105 	mov	dptr,#_descriptor_select_PARM_3
      005D22 E0               [24] 1106 	movx	a,@dptr
      005D23 FD               [12] 1107 	mov	r5,a
      005D24 A3               [24] 1108 	inc	dptr
      005D25 E0               [24] 1109 	movx	a,@dptr
      005D26 FE               [12] 1110 	mov	r6,a
      005D27 90 07 D3         [24] 1111 	mov	dptr,#_descriptor_select_PARM_3
      005D2A E0               [24] 1112 	movx	a,@dptr
      005D2B F5 F0            [12] 1113 	mov	b,a
      005D2D A3               [24] 1114 	inc	dptr
      005D2E E0               [24] 1115 	movx	a,@dptr
      005D2F 45 F0            [12] 1116 	orl	a,b
      005D31 60 0C            [24] 1117 	jz	00110$
      005D33 BD 09 05         [24] 1118 	cjne	r5,#0x09,00241$
      005D36 BE 04 02         [24] 1119 	cjne	r6,#0x04,00241$
      005D39 80 04            [24] 1120 	sjmp	00110$
      005D3B                       1121 00241$:
      005D3B 90 00 00         [24] 1122 	mov	dptr,#0x0000
      005D3E 22               [24] 1123 	ret
      005D3F                       1124 00110$:
                                   1125 ;	tmk_core/protocol/ch555/usb_ak820.c:177: switch (index) {
      005D3F 90 07 D2         [24] 1126 	mov	dptr,#_descriptor_select_PARM_2
      005D42 E0               [24] 1127 	movx	a,@dptr
      005D43 FE               [12] 1128 	mov  r6,a
      005D44 24 FC            [12] 1129 	add	a,#0xff - 0x03
      005D46 40 6A            [24] 1130 	jc	00116$
                                   1131 ;	free result
      005D48 EE               [12] 1132 	mov	a,r6
      005D49 2E               [12] 1133 	add	a,r6
                                   1134 ;	tmk_core/protocol/ch555/usb_ak820.c:178: case 0: control_pointer = (const uint8_t __code *)&LanguageString; return LanguageString.Header.Size;
      005D4A 90 5D 4E         [24] 1135 	mov	dptr,#00243$
      005D4D 73               [24] 1136 	jmp	@a+dptr
      005D4E                       1137 00243$:
      005D4E 80 06            [24] 1138 	sjmp	00112$
      005D50 80 1B            [24] 1139 	sjmp	00113$
      005D52 80 30            [24] 1140 	sjmp	00114$
      005D54 80 45            [24] 1141 	sjmp	00115$
      005D56                       1142 00112$:
      005D56 90 07 D0         [24] 1143 	mov	dptr,#_control_pointer
      005D59 74 01            [12] 1144 	mov	a,#_LanguageString
      005D5B F0               [24] 1145 	movx	@dptr,a
      005D5C 74 C3            [12] 1146 	mov	a,#(_LanguageString >> 8)
      005D5E A3               [24] 1147 	inc	dptr
      005D5F F0               [24] 1148 	movx	@dptr,a
      005D60 90 C3 01         [24] 1149 	mov	dptr,#_LanguageString
      005D63 E4               [12] 1150 	clr	a
      005D64 93               [24] 1151 	movc	a,@a+dptr
      005D65 FE               [12] 1152 	mov	r6,a
      005D66 7D 00            [12] 1153 	mov	r5,#0x00
      005D68 8E 82            [24] 1154 	mov	dpl, r6
      005D6A 8D 83            [24] 1155 	mov	dph, r5
      005D6C 22               [24] 1156 	ret
                                   1157 ;	tmk_core/protocol/ch555/usb_ak820.c:179: case 1: control_pointer = (const uint8_t __code *)&ManufacturerString; return ManufacturerString.Header.Size;
      005D6D                       1158 00113$:
      005D6D 90 07 D0         [24] 1159 	mov	dptr,#_control_pointer
      005D70 74 05            [12] 1160 	mov	a,#_ManufacturerString
      005D72 F0               [24] 1161 	movx	@dptr,a
      005D73 74 C3            [12] 1162 	mov	a,#(_ManufacturerString >> 8)
      005D75 A3               [24] 1163 	inc	dptr
      005D76 F0               [24] 1164 	movx	@dptr,a
      005D77 90 C3 05         [24] 1165 	mov	dptr,#_ManufacturerString
      005D7A E4               [12] 1166 	clr	a
      005D7B 93               [24] 1167 	movc	a,@a+dptr
      005D7C FE               [12] 1168 	mov	r6,a
      005D7D 7D 00            [12] 1169 	mov	r5,#0x00
      005D7F 8E 82            [24] 1170 	mov	dpl, r6
      005D81 8D 83            [24] 1171 	mov	dph, r5
      005D83 22               [24] 1172 	ret
                                   1173 ;	tmk_core/protocol/ch555/usb_ak820.c:180: case 2: control_pointer = (const uint8_t __code *)&ProductString; return ProductString.Header.Size;
      005D84                       1174 00114$:
      005D84 90 07 D0         [24] 1175 	mov	dptr,#_control_pointer
      005D87 74 13            [12] 1176 	mov	a,#_ProductString
      005D89 F0               [24] 1177 	movx	@dptr,a
      005D8A 74 C3            [12] 1178 	mov	a,#(_ProductString >> 8)
      005D8C A3               [24] 1179 	inc	dptr
      005D8D F0               [24] 1180 	movx	@dptr,a
      005D8E 90 C3 13         [24] 1181 	mov	dptr,#_ProductString
      005D91 E4               [12] 1182 	clr	a
      005D92 93               [24] 1183 	movc	a,@a+dptr
      005D93 FE               [12] 1184 	mov	r6,a
      005D94 7D 00            [12] 1185 	mov	r5,#0x00
      005D96 8E 82            [24] 1186 	mov	dpl, r6
      005D98 8D 83            [24] 1187 	mov	dph, r5
      005D9A 22               [24] 1188 	ret
                                   1189 ;	tmk_core/protocol/ch555/usb_ak820.c:182: case 3: control_pointer = (const uint8_t __code *)&SerialNumberString; return SerialNumberString.Header.Size;
      005D9B                       1190 00115$:
      005D9B 90 07 D0         [24] 1191 	mov	dptr,#_control_pointer
      005D9E 74 4B            [12] 1192 	mov	a,#_SerialNumberString
      005DA0 F0               [24] 1193 	movx	@dptr,a
      005DA1 74 C3            [12] 1194 	mov	a,#(_SerialNumberString >> 8)
      005DA3 A3               [24] 1195 	inc	dptr
      005DA4 F0               [24] 1196 	movx	@dptr,a
      005DA5 90 C3 4B         [24] 1197 	mov	dptr,#_SerialNumberString
      005DA8 E4               [12] 1198 	clr	a
      005DA9 93               [24] 1199 	movc	a,@a+dptr
      005DAA FE               [12] 1200 	mov	r6,a
      005DAB 7D 00            [12] 1201 	mov	r5,#0x00
      005DAD 8E 82            [24] 1202 	mov	dpl, r6
      005DAF 8D 83            [24] 1203 	mov	dph, r5
      005DB1 22               [24] 1204 	ret
                                   1205 ;	tmk_core/protocol/ch555/usb_ak820.c:184: default: return 0;
      005DB2                       1206 00116$:
      005DB2 90 00 00         [24] 1207 	mov	dptr,#0x0000
      005DB5 22               [24] 1208 	ret
                                   1209 ;	tmk_core/protocol/ch555/usb_ak820.c:185: }
      005DB6                       1210 00119$:
                                   1211 ;	tmk_core/protocol/ch555/usb_ak820.c:187: if (index || interface >= TOTAL_INTERFACES) return 0;
      005DB6 90 07 D2         [24] 1212 	mov	dptr,#_descriptor_select_PARM_2
      005DB9 E0               [24] 1213 	movx	a,@dptr
      005DBA 70 11            [24] 1214 	jnz	00120$
      005DBC 90 07 D3         [24] 1215 	mov	dptr,#_descriptor_select_PARM_3
      005DBF E0               [24] 1216 	movx	a,@dptr
      005DC0 FD               [12] 1217 	mov	r5,a
      005DC1 A3               [24] 1218 	inc	dptr
      005DC2 E0               [24] 1219 	movx	a,@dptr
      005DC3 FE               [12] 1220 	mov	r6,a
      005DC4 C3               [12] 1221 	clr	c
      005DC5 ED               [12] 1222 	mov	a,r5
      005DC6 94 03            [12] 1223 	subb	a,#0x03
      005DC8 EE               [12] 1224 	mov	a,r6
      005DC9 94 00            [12] 1225 	subb	a,#0x00
      005DCB 40 04            [24] 1226 	jc	00121$
      005DCD                       1227 00120$:
      005DCD 90 00 00         [24] 1228 	mov	dptr,#0x0000
      005DD0 22               [24] 1229 	ret
      005DD1                       1230 00121$:
                                   1231 ;	tmk_core/protocol/ch555/usb_ak820.c:188: if (type == USB_DESCR_TYP_REPORT || type == USB_DESCR_TYP_HID) {
      005DD1 BF 22 02         [24] 1232 	cjne	r7,#0x22,00246$
      005DD4 80 03            [24] 1233 	sjmp	00127$
      005DD6                       1234 00246$:
      005DD6 BF 21 5D         [24] 1235 	cjne	r7,#0x21,00128$
      005DD9                       1236 00127$:
                                   1237 ;	tmk_core/protocol/ch555/usb_ak820.c:189: const USB_HID_Descriptor_HID_t __code *hid = interface_descriptors[(uint8_t)interface].hid;
      005DD9 ED               [12] 1238 	mov	a,r5
      005DDA 75 F0 04         [24] 1239 	mov	b,#0x04
      005DDD A4               [48] 1240 	mul	ab
      005DDE 24 24            [12] 1241 	add	a, #_interface_descriptors
      005DE0 FE               [12] 1242 	mov	r6,a
      005DE1 74 BC            [12] 1243 	mov	a,#(_interface_descriptors >> 8)
      005DE3 35 F0            [12] 1244 	addc	a, b
      005DE5 FF               [12] 1245 	mov	r7,a
      005DE6 8E 82            [24] 1246 	mov	dpl,r6
      005DE8 8F 83            [24] 1247 	mov	dph,r7
      005DEA A3               [24] 1248 	inc	dptr
      005DEB A3               [24] 1249 	inc	dptr
      005DEC E4               [12] 1250 	clr	a
      005DED 93               [24] 1251 	movc	a,@a+dptr
      005DEE FC               [12] 1252 	mov	r4,a
      005DEF A3               [24] 1253 	inc	dptr
      005DF0 E4               [12] 1254 	clr	a
      005DF1 93               [24] 1255 	movc	a,@a+dptr
                                   1256 ;	tmk_core/protocol/ch555/usb_ak820.c:190: if (!hid) return 0;
      005DF2 FD               [12] 1257 	mov	r5,a
      005DF3 4C               [12] 1258 	orl	a,r4
      005DF4 70 04            [24] 1259 	jnz	00124$
      005DF6 90 00 00         [24] 1260 	mov	dptr,#0x0000
      005DF9 22               [24] 1261 	ret
      005DFA                       1262 00124$:
                                   1263 ;	tmk_core/protocol/ch555/usb_ak820.c:191: if (type == USB_DESCR_TYP_REPORT) {
      005DFA 90 07 D5         [24] 1264 	mov	dptr,#_descriptor_select_type_10000_271
      005DFD E0               [24] 1265 	movx	a,@dptr
      005DFE FB               [12] 1266 	mov	r3,a
      005DFF BB 22 28         [24] 1267 	cjne	r3,#0x22,00126$
                                   1268 ;	tmk_core/protocol/ch555/usb_ak820.c:192: control_pointer = interface_descriptors[(uint8_t)interface].report;
      005E02 8E 82            [24] 1269 	mov	dpl,r6
      005E04 8F 83            [24] 1270 	mov	dph,r7
      005E06 E4               [12] 1271 	clr	a
      005E07 93               [24] 1272 	movc	a,@a+dptr
      005E08 FE               [12] 1273 	mov	r6,a
      005E09 A3               [24] 1274 	inc	dptr
      005E0A E4               [12] 1275 	clr	a
      005E0B 93               [24] 1276 	movc	a,@a+dptr
      005E0C FF               [12] 1277 	mov	r7,a
      005E0D 90 07 D0         [24] 1278 	mov	dptr,#_control_pointer
      005E10 EE               [12] 1279 	mov	a,r6
      005E11 F0               [24] 1280 	movx	@dptr,a
      005E12 EF               [12] 1281 	mov	a,r7
      005E13 A3               [24] 1282 	inc	dptr
      005E14 F0               [24] 1283 	movx	@dptr,a
                                   1284 ;	tmk_core/protocol/ch555/usb_ak820.c:193: return hid->HIDReportLength;
      005E15 74 07            [12] 1285 	mov	a,#0x07
      005E17 2C               [12] 1286 	add	a, r4
      005E18 F5 82            [12] 1287 	mov	dpl,a
      005E1A E4               [12] 1288 	clr	a
      005E1B 3D               [12] 1289 	addc	a, r5
      005E1C F5 83            [12] 1290 	mov	dph,a
      005E1E E4               [12] 1291 	clr	a
      005E1F 93               [24] 1292 	movc	a,@a+dptr
      005E20 FE               [12] 1293 	mov	r6,a
      005E21 A3               [24] 1294 	inc	dptr
      005E22 E4               [12] 1295 	clr	a
      005E23 93               [24] 1296 	movc	a,@a+dptr
      005E24 FF               [12] 1297 	mov	r7,a
      005E25 8E 82            [24] 1298 	mov	dpl, r6
      005E27 8F 83            [24] 1299 	mov	dph, r7
      005E29 22               [24] 1300 	ret
      005E2A                       1301 00126$:
                                   1302 ;	tmk_core/protocol/ch555/usb_ak820.c:195: control_pointer = (const uint8_t __code *)hid;
      005E2A 90 07 D0         [24] 1303 	mov	dptr,#_control_pointer
      005E2D EC               [12] 1304 	mov	a,r4
      005E2E F0               [24] 1305 	movx	@dptr,a
      005E2F ED               [12] 1306 	mov	a,r5
      005E30 A3               [24] 1307 	inc	dptr
      005E31 F0               [24] 1308 	movx	@dptr,a
                                   1309 ;	tmk_core/protocol/ch555/usb_ak820.c:196: return 9;
      005E32 90 00 09         [24] 1310 	mov	dptr,#0x0009
      005E35 22               [24] 1311 	ret
      005E36                       1312 00128$:
                                   1313 ;	tmk_core/protocol/ch555/usb_ak820.c:198: return 0;
      005E36 90 00 00         [24] 1314 	mov	dptr,#0x0000
                                   1315 ;	tmk_core/protocol/ch555/usb_ak820.c:199: }
      005E39 22               [24] 1316 	ret
                                   1317 ;------------------------------------------------------------
                                   1318 ;Allocation info for local variables in function 'control_setup'
                                   1319 ;------------------------------------------------------------
                                   1320 ;sloc1         Allocated with name '_control_setup_sloc1_1_0'
                                   1321 ;sloc3         Allocated with name '_control_setup_sloc3_1_0'
                                   1322 ;sloc4         Allocated with name '_control_setup_sloc4_1_0'
                                   1323 ;type          Allocated with name '_control_setup_type_10000_289'
                                   1324 ;value         Allocated with name '_control_setup_value_10000_289'
                                   1325 ;index         Allocated with name '_control_setup_index_10000_289'
                                   1326 ;length        Allocated with name '_control_setup_length_10000_289'
                                   1327 ;endpoint      Allocated with name '_control_setup_endpoint_10000_289'
                                   1328 ;i             Allocated with name '_control_setup_i_10000_289'
                                   1329 ;offset        Allocated with name '_control_setup_offset_10000_289'
                                   1330 ;report_id     Allocated with name '_control_setup_report_id_10000_289'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	tmk_core/protocol/ch555/usb_ak820.c:201: static void control_setup(void) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function control_setup
                                   1335 ;	-----------------------------------------
      005E3A                       1336 _control_setup:
                                   1337 ;	tmk_core/protocol/ch555/usb_ak820.c:202: uint8_t type = pD0_SETUP_REQ->bRequestType;
      005E3A 90 10 00         [24] 1338 	mov	dptr,#0x1000
      005E3D E0               [24] 1339 	movx	a,@dptr
      005E3E FF               [12] 1340 	mov	r7,a
                                   1341 ;	tmk_core/protocol/ch555/usb_ak820.c:203: uint16_t value = pD0_SETUP_REQ->wValueL | ((uint16_t)pD0_SETUP_REQ->wValueH << 8);
      005E3F A3               [24] 1342 	inc	dptr
      005E40 A3               [24] 1343 	inc	dptr
      005E41 E0               [24] 1344 	movx	a,@dptr
      005E42 FE               [12] 1345 	mov	r6,a
      005E43 A3               [24] 1346 	inc	dptr
      005E44 E0               [24] 1347 	movx	a,@dptr
      005E45 FC               [12] 1348 	mov	r4,a
      005E46 7D 00            [12] 1349 	mov	r5,#0x00
      005E48 8E 03            [24] 1350 	mov	ar3,r6
      005E4A 7E 00            [12] 1351 	mov	r6,#0x00
      005E4C ED               [12] 1352 	mov	a,r5
      005E4D 4B               [12] 1353 	orl	a,r3
      005E4E FD               [12] 1354 	mov	r5,a
      005E4F EC               [12] 1355 	mov	a,r4
      005E50 4E               [12] 1356 	orl	a,r6
      005E51 FE               [12] 1357 	mov	r6,a
                                   1358 ;	tmk_core/protocol/ch555/usb_ak820.c:204: uint16_t index = pD0_SETUP_REQ->wIndexL | ((uint16_t)pD0_SETUP_REQ->wIndexH << 8);
      005E52 A3               [24] 1359 	inc	dptr
      005E53 E0               [24] 1360 	movx	a,@dptr
      005E54 FC               [12] 1361 	mov	r4,a
      005E55 A3               [24] 1362 	inc	dptr
      005E56 E0               [24] 1363 	movx	a,@dptr
      005E57 FA               [12] 1364 	mov	r2,a
      005E58 7B 00            [12] 1365 	mov	r3,#0x00
      005E5A 8C 01            [24] 1366 	mov	ar1,r4
      005E5C 7C 00            [12] 1367 	mov	r4,#0x00
      005E5E EB               [12] 1368 	mov	a,r3
      005E5F 49               [12] 1369 	orl	a,r1
      005E60 FB               [12] 1370 	mov	r3,a
      005E61 EA               [12] 1371 	mov	a,r2
      005E62 4C               [12] 1372 	orl	a,r4
      005E63 FC               [12] 1373 	mov	r4,a
                                   1374 ;	tmk_core/protocol/ch555/usb_ak820.c:208: __bit valid_interface = index < TOTAL_INTERFACES;
      005E64 C3               [12] 1375 	clr	c
      005E65 EB               [12] 1376 	mov	a,r3
      005E66 94 03            [12] 1377 	subb	a,#0x03
      005E68 EC               [12] 1378 	mov	a,r4
      005E69 94 00            [12] 1379 	subb	a,#0x00
      005E6B 92 16            [24] 1380 	mov	_control_setup_valid_interface_10000_289,c
                                   1381 ;	tmk_core/protocol/ch555/usb_ak820.c:209: __bit zero_index = !index;
      005E6D EB               [12] 1382 	mov	a,r3
      005E6E 4C               [12] 1383 	orl	a,r4
      005E6F B4 01 00         [24] 1384 	cjne	a,#0x01,01201$
      005E72                       1385 01201$:
      005E72 92 17            [24] 1386 	mov	_control_setup_zero_index_10000_289,c
                                   1387 ;	tmk_core/protocol/ch555/usb_ak820.c:210: __bit zero_value = !value;
      005E74 ED               [12] 1388 	mov	a,r5
      005E75 4E               [12] 1389 	orl	a,r6
      005E76 B4 01 00         [24] 1390 	cjne	a,#0x01,01202$
      005E79                       1391 01202$:
                                   1392 ;	assignBit
      005E79 92 1A            [24] 1393 	mov  _control_setup_sloc0_1_0,c
      005E7B 92 18            [24] 1394 	mov	_control_setup_zero_value_10000_289,c
                                   1395 ;	tmk_core/protocol/ch555/usb_ak820.c:214: uint8_t offset = 0;
      005E7D 90 07 D8         [24] 1396 	mov	dptr,#_control_setup_offset_10000_289
      005E80 E4               [12] 1397 	clr	a
      005E81 F0               [24] 1398 	movx	@dptr,a
                                   1399 ;	tmk_core/protocol/ch555/usb_ak820.c:216: if (raw_state == RAW_RX) raw_state = RAW_IDLE; /* abort only unfinished OUT */
      005E82 90 07 7B         [24] 1400 	mov	dptr,#_raw_state
      005E85 E0               [24] 1401 	movx	a,@dptr
      005E86 FA               [12] 1402 	mov	r2,a
      005E87 BA 01 05         [24] 1403 	cjne	r2,#0x01,00102$
      005E8A 90 07 7B         [24] 1404 	mov	dptr,#_raw_state
      005E8D E4               [12] 1405 	clr	a
      005E8E F0               [24] 1406 	movx	@dptr,a
      005E8F                       1407 00102$:
                                   1408 ;	tmk_core/protocol/ch555/usb_ak820.c:217: output_kind = OUTPUT_NONE;
      005E8F C0 07            [24] 1409 	push	ar7
      005E91 90 07 CD         [24] 1410 	mov	dptr,#_output_kind
      005E94 E4               [12] 1411 	clr	a
      005E95 F0               [24] 1412 	movx	@dptr,a
                                   1413 ;	tmk_core/protocol/ch555/usb_ak820.c:218: control_phase = CTRL_IDLE;
      005E96 90 07 CC         [24] 1414 	mov	dptr,#_control_phase
      005E99 F0               [24] 1415 	movx	@dptr,a
                                   1416 ;	tmk_core/protocol/ch555/usb_ak820.c:219: control_zlp = 0;
      005E9A 90 07 CF         [24] 1417 	mov	dptr,#_control_zlp
      005E9D F0               [24] 1418 	movx	@dptr,a
                                   1419 ;	tmk_core/protocol/ch555/usb_ak820.c:220: D0SetupReqCode = pD0_SETUP_REQ->bRequest;
      005E9E 90 10 01         [24] 1420 	mov	dptr,#0x1001
      005EA1 E0               [24] 1421 	movx	a,@dptr
      005EA2 90 07 6D         [24] 1422 	mov	dptr,#_D0SetupReqCode
      005EA5 F0               [24] 1423 	movx	@dptr,a
                                   1424 ;	tmk_core/protocol/ch555/usb_ak820.c:221: D0SetupLen = pD0_SETUP_REQ->wLengthL | ((uint16_t)pD0_SETUP_REQ->wLengthH << 8);
      005EA6 90 10 06         [24] 1425 	mov	dptr,#0x1006
      005EA9 E0               [24] 1426 	movx	a,@dptr
      005EAA FA               [12] 1427 	mov	r2,a
      005EAB A3               [24] 1428 	inc	dptr
      005EAC E0               [24] 1429 	movx	a,@dptr
      005EAD F9               [12] 1430 	mov	r1,a
      005EAE 78 00            [12] 1431 	mov	r0,#0x00
      005EB0 7F 00            [12] 1432 	mov	r7,#0x00
      005EB2 90 07 6E         [24] 1433 	mov	dptr,#_D0SetupLen
      005EB5 E8               [12] 1434 	mov	a,r0
      005EB6 4A               [12] 1435 	orl	a,r2
      005EB7 F0               [24] 1436 	movx	@dptr,a
      005EB8 E9               [12] 1437 	mov	a,r1
      005EB9 4F               [12] 1438 	orl	a,r7
      005EBA A3               [24] 1439 	inc	dptr
      005EBB F0               [24] 1440 	movx	@dptr,a
                                   1441 ;	tmk_core/protocol/ch555/usb_ak820.c:222: zero_length = !D0SetupLen;
      005EBC 90 07 6E         [24] 1442 	mov	dptr,#_D0SetupLen
      005EBF E0               [24] 1443 	movx	a,@dptr
      005EC0 FA               [12] 1444 	mov	r2,a
      005EC1 A3               [24] 1445 	inc	dptr
      005EC2 E0               [24] 1446 	movx	a,@dptr
      005EC3 4A               [12] 1447 	orl	a,r2
      005EC4 B4 01 00         [24] 1448 	cjne	a,#0x01,01205$
      005EC7                       1449 01205$:
      005EC7 92 19            [24] 1450 	mov	_control_setup_zero_length_10000_289,c
                                   1451 ;	tmk_core/protocol/ch555/usb_ak820.c:223: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      005EC9 90 22 00         [24] 1452 	mov	dptr,#0x2200
      005ECC 74 C2            [12] 1453 	mov	a,#0xc2
      005ECE F0               [24] 1454 	movx	@dptr,a
                                   1455 ;	tmk_core/protocol/ch555/usb_ak820.c:224: D0_EP0T_L = 0;
      005ECF 90 22 08         [24] 1456 	mov	dptr,#0x2208
      005ED2 E4               [12] 1457 	clr	a
      005ED3 F0               [24] 1458 	movx	@dptr,a
                                   1459 ;	tmk_core/protocol/ch555/usb_ak820.c:228: switch (D0SetupReqCode) {
      005ED4 90 07 6D         [24] 1460 	mov	dptr,#_D0SetupReqCode
      005ED7 E0               [24] 1461 	movx	a,@dptr
      005ED8 F5 16            [12] 1462 	mov	_control_setup_sloc1_1_0,a
      005EDA C3               [12] 1463 	clr	c
      005EDB 74 0B            [12] 1464 	mov	a,#0x0b
      005EDD 95 16            [12] 1465 	subb	a,_control_setup_sloc1_1_0
      005EDF D0 07            [24] 1466 	pop	ar7
      005EE1 50 03            [24] 1467 	jnc	01206$
      005EE3 02 5C 21         [24] 1468 	ljmp	_control_stall
      005EE6                       1469 01206$:
                                   1470 ;	free result
      005EE6 E5 16            [12] 1471 	mov	a,_control_setup_sloc1_1_0
      005EE8 F5 F0            [12] 1472 	mov	b,a
      005EEA 24 0B            [12] 1473 	add	a,#(01207$-3-.)
      005EEC 83               [24] 1474 	movc	a,@a+pc
      005EED F5 82            [12] 1475 	mov	dpl,a
      005EEF E5 F0            [12] 1476 	mov	a,b
      005EF1 24 10            [12] 1477 	add	a,#(01208$-3-.)
      005EF3 83               [24] 1478 	movc	a,@a+pc
      005EF4 F5 83            [12] 1479 	mov	dph,a
      005EF6 E4               [12] 1480 	clr	a
      005EF7 73               [24] 1481 	jmp	@a+dptr
      005EF8                       1482 01207$:
      005EF8 A0                    1483 	.db	00188$
      005EF9 46                    1484 	.db	00205$
      005EFA 89                    1485 	.db	00282$
      005EFB 46                    1486 	.db	00205$
      005EFC CD                    1487 	.db	00290$
      005EFD CA                    1488 	.db	00116$
      005EFE 10                    1489 	.db	00103$
      005EFF CD                    1490 	.db	00290$
      005F00 CF                    1491 	.db	00150$
      005F01 F3                    1492 	.db	00123$
      005F02 FF                    1493 	.db	00157$
      005F03 52                    1494 	.db	00173$
      005F04                       1495 01208$:
      005F04 61                    1496 	.db	00188$>>8
      005F05 62                    1497 	.db	00205$>>8
      005F06 65                    1498 	.db	00282$>>8
      005F07 62                    1499 	.db	00205$>>8
      005F08 65                    1500 	.db	00290$>>8
      005F09 5F                    1501 	.db	00116$>>8
      005F0A 5F                    1502 	.db	00103$>>8
      005F0B 65                    1503 	.db	00290$>>8
      005F0C 60                    1504 	.db	00150$>>8
      005F0D 5F                    1505 	.db	00123$>>8
      005F0E 60                    1506 	.db	00157$>>8
      005F0F 61                    1507 	.db	00173$>>8
                                   1508 ;	tmk_core/protocol/ch555/usb_ak820.c:229: case USB_GET_DESCRIPTOR:
      005F10                       1509 00103$:
                                   1510 ;	tmk_core/protocol/ch555/usb_ak820.c:230: if (type == 0x80 || type == 0x81) {
      005F10 BF 80 02         [24] 1511 	cjne	r7,#0x80,01209$
      005F13 80 08            [24] 1512 	sjmp	00112$
      005F15                       1513 01209$:
      005F15 BF 81 02         [24] 1514 	cjne	r7,#0x81,01210$
      005F18 80 03            [24] 1515 	sjmp	01211$
      005F1A                       1516 01210$:
      005F1A 02 5C 21         [24] 1517 	ljmp	_control_stall
      005F1D                       1518 01211$:
      005F1D                       1519 00112$:
                                   1520 ;	tmk_core/protocol/ch555/usb_ak820.c:231: if (((value >> 8) == USB_DESCR_TYP_HID || (value >> 8) == USB_DESCR_TYP_REPORT) != (type == 0x81)) {
      005F1D 8E 01            [24] 1521 	mov	ar1,r6
      005F1F B9 21 02         [24] 1522 	cjne	r1,#0x21,01212$
      005F22 80 09            [24] 1523 	sjmp	00301$
      005F24                       1524 01212$:
      005F24 B9 22 02         [24] 1525 	cjne	r1,#0x22,01213$
      005F27 80 04            [24] 1526 	sjmp	00301$
      005F29                       1527 01213$:
                                   1528 ;	assignBit
      005F29 C2 1B            [12] 1529 	clr	_control_setup_sloc2_1_0
      005F2B 80 02            [24] 1530 	sjmp	00302$
      005F2D                       1531 00301$:
                                   1532 ;	assignBit
      005F2D D2 1B            [12] 1533 	setb	_control_setup_sloc2_1_0
      005F2F                       1534 00302$:
      005F2F E4               [12] 1535 	clr	a
      005F30 BF 81 01         [24] 1536 	cjne	r7,#0x81,01214$
      005F33 04               [12] 1537 	inc	a
      005F34                       1538 01214$:
      005F34 FA               [12] 1539 	mov	r2,a
      005F35 A2 1B            [12] 1540 	mov	c,_control_setup_sloc2_1_0
      005F37 E4               [12] 1541 	clr	a
      005F38 33               [12] 1542 	rlc	a
      005F39 B5 02 02         [24] 1543 	cjne	a,ar2,01216$
      005F3C 80 03            [24] 1544 	sjmp	00105$
      005F3E                       1545 01216$:
                                   1546 ;	tmk_core/protocol/ch555/usb_ak820.c:232: control_stall(); return;
      005F3E 02 5C 21         [24] 1547 	ljmp	_control_stall
      005F41                       1548 00105$:
                                   1549 ;	tmk_core/protocol/ch555/usb_ak820.c:234: length = descriptor_select(value >> 8, value, index);
      005F41 8E 02            [24] 1550 	mov	ar2,r6
      005F43 90 07 D2         [24] 1551 	mov	dptr,#_descriptor_select_PARM_2
      005F46 ED               [12] 1552 	mov	a,r5
      005F47 F0               [24] 1553 	movx	@dptr,a
      005F48 90 07 D3         [24] 1554 	mov	dptr,#_descriptor_select_PARM_3
      005F4B EB               [12] 1555 	mov	a,r3
      005F4C F0               [24] 1556 	movx	@dptr,a
      005F4D EC               [12] 1557 	mov	a,r4
      005F4E A3               [24] 1558 	inc	dptr
      005F4F F0               [24] 1559 	movx	@dptr,a
      005F50 8A 82            [24] 1560 	mov	dpl, r2
      005F52 12 5C BF         [24] 1561 	lcall	_descriptor_select
      005F55 85 82 17         [24] 1562 	mov	_control_setup_sloc3_1_0,dpl
      005F58 85 83 18         [24] 1563 	mov	(_control_setup_sloc3_1_0 + 1),dph
                                   1564 ;	tmk_core/protocol/ch555/usb_ak820.c:235: if (!length) { control_stall(); return; }
      005F5B E5 17            [12] 1565 	mov	a,_control_setup_sloc3_1_0
      005F5D 45 18            [12] 1566 	orl	a,(_control_setup_sloc3_1_0 + 1)
      005F5F 70 03            [24] 1567 	jnz	00107$
      005F61 02 5C 21         [24] 1568 	ljmp	_control_stall
      005F64                       1569 00107$:
                                   1570 ;	tmk_core/protocol/ch555/usb_ak820.c:236: control_zlp = length < D0SetupLen && !(length & (DEF_ENDP0_SIZE - 1));
      005F64 90 07 6E         [24] 1571 	mov	dptr,#_D0SetupLen
      005F67 E0               [24] 1572 	movx	a,@dptr
      005F68 F8               [12] 1573 	mov	r0,a
      005F69 A3               [24] 1574 	inc	dptr
      005F6A E0               [24] 1575 	movx	a,@dptr
      005F6B FA               [12] 1576 	mov	r2,a
      005F6C C3               [12] 1577 	clr	c
      005F6D E5 17            [12] 1578 	mov	a,_control_setup_sloc3_1_0
      005F6F 98               [12] 1579 	subb	a,r0
      005F70 E5 18            [12] 1580 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005F72 9A               [12] 1581 	subb	a,r2
      005F73 50 06            [24] 1582 	jnc	00303$
      005F75 E5 17            [12] 1583 	mov	a,_control_setup_sloc3_1_0
      005F77 54 3F            [12] 1584 	anl	a,#0x3f
      005F79 60 04            [24] 1585 	jz	00304$
      005F7B                       1586 00303$:
                                   1587 ;	assignBit
      005F7B C2 1B            [12] 1588 	clr	_control_setup_sloc2_1_0
      005F7D 80 02            [24] 1589 	sjmp	00305$
      005F7F                       1590 00304$:
                                   1591 ;	assignBit
      005F7F D2 1B            [12] 1592 	setb	_control_setup_sloc2_1_0
      005F81                       1593 00305$:
      005F81 90 07 CF         [24] 1594 	mov	dptr,#_control_zlp
      005F84 A2 1B            [12] 1595 	mov	c,_control_setup_sloc2_1_0
      005F86 E4               [12] 1596 	clr	a
      005F87 33               [12] 1597 	rlc	a
      005F88 F0               [24] 1598 	movx	@dptr,a
                                   1599 ;	tmk_core/protocol/ch555/usb_ak820.c:237: if (D0SetupLen > length) D0SetupLen = length;
      005F89 90 07 6E         [24] 1600 	mov	dptr,#_D0SetupLen
      005F8C E0               [24] 1601 	movx	a,@dptr
      005F8D F9               [12] 1602 	mov	r1,a
      005F8E A3               [24] 1603 	inc	dptr
      005F8F E0               [24] 1604 	movx	a,@dptr
      005F90 FA               [12] 1605 	mov	r2,a
      005F91 C3               [12] 1606 	clr	c
      005F92 E5 17            [12] 1607 	mov	a,_control_setup_sloc3_1_0
      005F94 99               [12] 1608 	subb	a,r1
      005F95 E5 18            [12] 1609 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005F97 9A               [12] 1610 	subb	a,r2
      005F98 50 0A            [24] 1611 	jnc	00109$
                                   1612 ;	free result
      005F9A 90 07 6E         [24] 1613 	mov	dptr,#_D0SetupLen
      005F9D E5 17            [12] 1614 	mov	a,_control_setup_sloc3_1_0
      005F9F F0               [24] 1615 	movx	@dptr,a
      005FA0 E5 18            [12] 1616 	mov	a,(_control_setup_sloc3_1_0 + 1)
      005FA2 A3               [24] 1617 	inc	dptr
      005FA3 F0               [24] 1618 	movx	@dptr,a
      005FA4                       1619 00109$:
                                   1620 ;	tmk_core/protocol/ch555/usb_ak820.c:238: control_phase = D0SetupLen ? CTRL_DATA_IN : CTRL_STATUS_OUT;
      005FA4 90 07 6E         [24] 1621 	mov	dptr,#_D0SetupLen
      005FA7 E0               [24] 1622 	movx	a,@dptr
      005FA8 F9               [12] 1623 	mov	r1,a
      005FA9 A3               [24] 1624 	inc	dptr
      005FAA E0               [24] 1625 	movx	a,@dptr
      005FAB 49               [12] 1626 	orl	a,r1
      005FAC 60 04            [24] 1627 	jz	00306$
      005FAE 7A 01            [12] 1628 	mov	r2,#0x01
      005FB0 80 02            [24] 1629 	sjmp	00307$
      005FB2                       1630 00306$:
      005FB2 7A 02            [12] 1631 	mov	r2,#0x02
      005FB4                       1632 00307$:
      005FB4 90 07 CC         [24] 1633 	mov	dptr,#_control_phase
      005FB7 EA               [12] 1634 	mov	a,r2
      005FB8 F0               [24] 1635 	movx	@dptr,a
                                   1636 ;	tmk_core/protocol/ch555/usb_ak820.c:239: if (D0SetupLen) control_next();
      005FB9 90 07 6E         [24] 1637 	mov	dptr,#_D0SetupLen
      005FBC E0               [24] 1638 	movx	a,@dptr
      005FBD F9               [12] 1639 	mov	r1,a
      005FBE A3               [24] 1640 	inc	dptr
      005FBF E0               [24] 1641 	movx	a,@dptr
      005FC0 49               [12] 1642 	orl	a,r1
      005FC1 60 03            [24] 1643 	jz	00111$
                                   1644 ;	tmk_core/protocol/ch555/usb_ak820.c:240: return;
      005FC3 02 5C 43         [24] 1645 	ljmp	_control_next
      005FC6                       1646 00111$:
      005FC6 22               [24] 1647 	ret
                                   1648 ;	tmk_core/protocol/ch555/usb_ak820.c:241: } else { control_stall(); return; }
      005FC7 02 5C 21         [24] 1649 	ljmp	_control_stall
                                   1650 ;	tmk_core/protocol/ch555/usb_ak820.c:242: case USB_SET_ADDRESS:
      005FCA                       1651 00116$:
                                   1652 ;	tmk_core/protocol/ch555/usb_ak820.c:243: if (type == 0x00 && zero_index && zero_length && value <= 127) {
      005FCA EF               [12] 1653 	mov	a,r7
      005FCB 70 23            [24] 1654 	jnz	00118$
      005FCD 30 17 20         [24] 1655 	jnb	_control_setup_zero_index_10000_289,00118$
      005FD0 30 19 1D         [24] 1656 	jnb	_control_setup_zero_length_10000_289,00118$
      005FD3 8D 01            [24] 1657 	mov	ar1,r5
      005FD5 8E 02            [24] 1658 	mov	ar2,r6
      005FD7 C3               [12] 1659 	clr	c
      005FD8 74 7F            [12] 1660 	mov	a,#0x7f
      005FDA 99               [12] 1661 	subb	a,r1
      005FDB E4               [12] 1662 	clr	a
      005FDC 9A               [12] 1663 	subb	a,r2
      005FDD 40 11            [24] 1664 	jc	00118$
                                   1665 ;	free result
                                   1666 ;	tmk_core/protocol/ch555/usb_ak820.c:244: D0SetupLen = value; /* applied after status-IN ACK */
      005FDF 90 07 6E         [24] 1667 	mov	dptr,#_D0SetupLen
      005FE2 ED               [12] 1668 	mov	a,r5
      005FE3 F0               [24] 1669 	movx	@dptr,a
      005FE4 EE               [12] 1670 	mov	a,r6
      005FE5 A3               [24] 1671 	inc	dptr
      005FE6 F0               [24] 1672 	movx	@dptr,a
                                   1673 ;	tmk_core/protocol/ch555/usb_ak820.c:245: control_phase = CTRL_STATUS_IN;
      005FE7 90 07 CC         [24] 1674 	mov	dptr,#_control_phase
      005FEA 74 03            [12] 1675 	mov	a,#0x03
      005FEC F0               [24] 1676 	movx	@dptr,a
      005FED 02 65 D0         [24] 1677 	ljmp	00291$
      005FF0                       1678 00118$:
                                   1679 ;	tmk_core/protocol/ch555/usb_ak820.c:246: } else { control_stall(); return; }
      005FF0 02 5C 21         [24] 1680 	ljmp	_control_stall
                                   1681 ;	tmk_core/protocol/ch555/usb_ak820.c:248: case USB_SET_CONFIGURATION: /* HID_SET_REPORT has the same request byte. */
      005FF3                       1682 00123$:
                                   1683 ;	tmk_core/protocol/ch555/usb_ak820.c:249: if (type == 0x00 && zero_index && zero_length && value <= 1) {
      005FF3 EF               [12] 1684 	mov	a,r7
      005FF4 70 3C            [24] 1685 	jnz	00145$
      005FF6 30 17 39         [24] 1686 	jnb	_control_setup_zero_index_10000_289,00145$
      005FF9 30 19 36         [24] 1687 	jnb	_control_setup_zero_length_10000_289,00145$
      005FFC 8D 01            [24] 1688 	mov	ar1,r5
      005FFE 8E 02            [24] 1689 	mov	ar2,r6
      006000 C3               [12] 1690 	clr	c
      006001 74 01            [12] 1691 	mov	a,#0x01
      006003 99               [12] 1692 	subb	a,r1
      006004 E4               [12] 1693 	clr	a
      006005 9A               [12] 1694 	subb	a,r2
      006006 40 2A            [24] 1695 	jc	00145$
                                   1696 ;	free result
                                   1697 ;	tmk_core/protocol/ch555/usb_ak820.c:250: endpoints_reset();
      006008 C0 06            [24] 1698 	push	ar6
      00600A C0 05            [24] 1699 	push	ar5
      00600C 12 5B C6         [24] 1700 	lcall	_endpoints_reset
      00600F D0 05            [24] 1701 	pop	ar5
      006011 D0 06            [24] 1702 	pop	ar6
                                   1703 ;	tmk_core/protocol/ch555/usb_ak820.c:251: D0UsbConfig = value;
      006013 90 07 73         [24] 1704 	mov	dptr,#_D0UsbConfig
      006016 ED               [12] 1705 	mov	a,r5
      006017 F0               [24] 1706 	movx	@dptr,a
                                   1707 ;	tmk_core/protocol/ch555/usb_ak820.c:252: USB_EnumStatus = value != 0;
      006018 A2 1A            [12] 1708 	mov	c,_control_setup_sloc0_1_0
      00601A B3               [12] 1709 	cpl	c
      00601B 92 1B            [24] 1710 	mov	_control_setup_sloc2_1_0,c
      00601D 90 07 74         [24] 1711 	mov	dptr,#_USB_EnumStatus
      006020 E4               [12] 1712 	clr	a
      006021 33               [12] 1713 	rlc	a
      006022 F0               [24] 1714 	movx	@dptr,a
                                   1715 ;	tmk_core/protocol/ch555/usb_ak820.c:253: keyboard_reset = 1;
      006023 90 07 9D         [24] 1716 	mov	dptr,#_keyboard_reset
      006026 74 01            [12] 1717 	mov	a,#0x01
      006028 F0               [24] 1718 	movx	@dptr,a
                                   1719 ;	tmk_core/protocol/ch555/usb_ak820.c:254: control_phase = CTRL_STATUS_IN;
      006029 90 07 CC         [24] 1720 	mov	dptr,#_control_phase
      00602C 74 03            [12] 1721 	mov	a,#0x03
      00602E F0               [24] 1722 	movx	@dptr,a
      00602F 02 65 D0         [24] 1723 	ljmp	00291$
      006032                       1724 00145$:
                                   1725 ;	tmk_core/protocol/ch555/usb_ak820.c:255: } else if (type == 0x21 && D0UsbConfig) {
      006032 BF 21 02         [24] 1726 	cjne	r7,#0x21,01231$
      006035 80 03            [24] 1727 	sjmp	01232$
      006037                       1728 01231$:
      006037 02 5C 21         [24] 1729 	ljmp	_control_stall
      00603A                       1730 01232$:
      00603A 90 07 73         [24] 1731 	mov	dptr,#_D0UsbConfig
      00603D E0               [24] 1732 	movx	a,@dptr
      00603E 70 03            [24] 1733 	jnz	01233$
      006040 02 5C 21         [24] 1734 	ljmp	_control_stall
      006043                       1735 01233$:
                                   1736 ;	tmk_core/protocol/ch555/usb_ak820.c:256: if (index == RAW_INTERFACE && value == 0x0200 && D0SetupLen == RAW_EPSIZE && raw_state == RAW_IDLE) {
      006043 BB 01 2D         [24] 1737 	cjne	r3,#0x01,00135$
      006046 BC 00 2A         [24] 1738 	cjne	r4,#0x00,00135$
      006049 8D 01            [24] 1739 	mov	ar1,r5
      00604B 8E 02            [24] 1740 	mov	ar2,r6
      00604D B9 00 23         [24] 1741 	cjne	r1,#0x00,00135$
      006050 BA 02 20         [24] 1742 	cjne	r2,#0x02,00135$
      006053 90 07 6E         [24] 1743 	mov	dptr,#_D0SetupLen
      006056 E0               [24] 1744 	movx	a,@dptr
      006057 F9               [12] 1745 	mov	r1,a
      006058 A3               [24] 1746 	inc	dptr
      006059 E0               [24] 1747 	movx	a,@dptr
      00605A FA               [12] 1748 	mov	r2,a
      00605B B9 20 15         [24] 1749 	cjne	r1,#0x20,00135$
      00605E BA 00 12         [24] 1750 	cjne	r2,#0x00,00135$
      006061 90 07 7B         [24] 1751 	mov	dptr,#_raw_state
      006064 E0               [24] 1752 	movx	a,@dptr
      006065 70 0C            [24] 1753 	jnz	00135$
                                   1754 ;	tmk_core/protocol/ch555/usb_ak820.c:257: raw_state = RAW_RX;
      006067 90 07 7B         [24] 1755 	mov	dptr,#_raw_state
      00606A 74 01            [12] 1756 	mov	a,#0x01
      00606C F0               [24] 1757 	movx	@dptr,a
                                   1758 ;	tmk_core/protocol/ch555/usb_ak820.c:258: output_kind = OUTPUT_RAW;
      00606D 90 07 CD         [24] 1759 	mov	dptr,#_output_kind
      006070 F0               [24] 1760 	movx	@dptr,a
      006071 80 52            [24] 1761 	sjmp	00136$
      006073                       1762 00135$:
                                   1763 ;	tmk_core/protocol/ch555/usb_ak820.c:259: } else if (index == KEYBOARD_INTERFACE && value == 0x0200 && D0SetupLen == 1) {
      006073 EB               [12] 1764 	mov	a,r3
      006074 4C               [12] 1765 	orl	a,r4
      006075 70 20            [24] 1766 	jnz	00130$
      006077 8D 01            [24] 1767 	mov	ar1,r5
      006079 8E 02            [24] 1768 	mov	ar2,r6
      00607B B9 00 19         [24] 1769 	cjne	r1,#0x00,00130$
      00607E BA 02 16         [24] 1770 	cjne	r2,#0x02,00130$
      006081 90 07 6E         [24] 1771 	mov	dptr,#_D0SetupLen
      006084 E0               [24] 1772 	movx	a,@dptr
      006085 F9               [12] 1773 	mov	r1,a
      006086 A3               [24] 1774 	inc	dptr
      006087 E0               [24] 1775 	movx	a,@dptr
      006088 FA               [12] 1776 	mov	r2,a
      006089 B9 01 0B         [24] 1777 	cjne	r1,#0x01,00130$
      00608C BA 00 08         [24] 1778 	cjne	r2,#0x00,00130$
                                   1779 ;	tmk_core/protocol/ch555/usb_ak820.c:260: output_kind = OUTPUT_LED;
      00608F 90 07 CD         [24] 1780 	mov	dptr,#_output_kind
      006092 74 02            [12] 1781 	mov	a,#0x02
      006094 F0               [24] 1782 	movx	@dptr,a
      006095 80 2E            [24] 1783 	sjmp	00136$
      006097                       1784 00130$:
                                   1785 ;	tmk_core/protocol/ch555/usb_ak820.c:262: } else if (index == SHARED_INTERFACE && value == (0x0200 | REPORT_ID_NKRO) && D0SetupLen == 2) {
      006097 BB 02 28         [24] 1786 	cjne	r3,#0x02,00125$
      00609A BC 00 25         [24] 1787 	cjne	r4,#0x00,00125$
      00609D 8D 01            [24] 1788 	mov	ar1,r5
      00609F 8E 02            [24] 1789 	mov	ar2,r6
      0060A1 B9 06 1E         [24] 1790 	cjne	r1,#0x06,00125$
      0060A4 BA 02 1B         [24] 1791 	cjne	r2,#0x02,00125$
      0060A7 90 07 6E         [24] 1792 	mov	dptr,#_D0SetupLen
      0060AA E0               [24] 1793 	movx	a,@dptr
      0060AB F9               [12] 1794 	mov	r1,a
      0060AC A3               [24] 1795 	inc	dptr
      0060AD E0               [24] 1796 	movx	a,@dptr
      0060AE FA               [12] 1797 	mov	r2,a
      0060AF B9 02 10         [24] 1798 	cjne	r1,#0x02,00125$
      0060B2 BA 00 0D         [24] 1799 	cjne	r2,#0x00,00125$
                                   1800 ;	tmk_core/protocol/ch555/usb_ak820.c:263: output_kind = OUTPUT_SHARED_LED;
      0060B5 90 07 CD         [24] 1801 	mov	dptr,#_output_kind
      0060B8 74 03            [12] 1802 	mov	a,#0x03
      0060BA F0               [24] 1803 	movx	@dptr,a
                                   1804 ;	tmk_core/protocol/ch555/usb_ak820.c:264: output_report_id = REPORT_ID_NKRO;
      0060BB 90 07 CE         [24] 1805 	mov	dptr,#_output_report_id
      0060BE 23               [12] 1806 	rl	a
      0060BF F0               [24] 1807 	movx	@dptr,a
      0060C0 80 03            [24] 1808 	sjmp	00136$
      0060C2                       1809 00125$:
                                   1810 ;	tmk_core/protocol/ch555/usb_ak820.c:266: } else { control_stall(); return; }
      0060C2 02 5C 21         [24] 1811 	ljmp	_control_stall
      0060C5                       1812 00136$:
                                   1813 ;	tmk_core/protocol/ch555/usb_ak820.c:267: control_phase = CTRL_DATA_OUT;
      0060C5 90 07 CC         [24] 1814 	mov	dptr,#_control_phase
      0060C8 74 04            [12] 1815 	mov	a,#0x04
      0060CA F0               [24] 1816 	movx	@dptr,a
                                   1817 ;	tmk_core/protocol/ch555/usb_ak820.c:268: return; /* OUT data must arrive before status-IN becomes ACK */
      0060CB 22               [24] 1818 	ret
                                   1819 ;	tmk_core/protocol/ch555/usb_ak820.c:269: } else { control_stall(); return; }
      0060CC 02 5C 21         [24] 1820 	ljmp	_control_stall
                                   1821 ;	tmk_core/protocol/ch555/usb_ak820.c:271: case USB_GET_CONFIGURATION:
      0060CF                       1822 00150$:
                                   1823 ;	tmk_core/protocol/ch555/usb_ak820.c:272: if (type == 0x80 && zero_index && zero_value && D0SetupLen == 1) {
      0060CF BF 80 2A         [24] 1824 	cjne	r7,#0x80,00152$
      0060D2 30 17 27         [24] 1825 	jnb	_control_setup_zero_index_10000_289,00152$
      0060D5 30 18 24         [24] 1826 	jnb	_control_setup_zero_value_10000_289,00152$
      0060D8 90 07 6E         [24] 1827 	mov	dptr,#_D0SetupLen
      0060DB E0               [24] 1828 	movx	a,@dptr
      0060DC F9               [12] 1829 	mov	r1,a
      0060DD A3               [24] 1830 	inc	dptr
      0060DE E0               [24] 1831 	movx	a,@dptr
      0060DF FA               [12] 1832 	mov	r2,a
      0060E0 B9 01 19         [24] 1833 	cjne	r1,#0x01,00152$
      0060E3 BA 00 16         [24] 1834 	cjne	r2,#0x00,00152$
                                   1835 ;	tmk_core/protocol/ch555/usb_ak820.c:273: pD0_EP0_BUF[0] = D0UsbConfig;
      0060E6 90 07 73         [24] 1836 	mov	dptr,#_D0UsbConfig
      0060E9 E0               [24] 1837 	movx	a,@dptr
      0060EA 90 10 00         [24] 1838 	mov	dptr,#0x1000
      0060ED F0               [24] 1839 	movx	@dptr,a
                                   1840 ;	tmk_core/protocol/ch555/usb_ak820.c:274: D0_EP0T_L = 1;
      0060EE 90 22 08         [24] 1841 	mov	dptr,#0x2208
      0060F1 74 01            [12] 1842 	mov	a,#0x01
      0060F3 F0               [24] 1843 	movx	@dptr,a
                                   1844 ;	tmk_core/protocol/ch555/usb_ak820.c:275: control_phase = CTRL_STATUS_OUT;
      0060F4 90 07 CC         [24] 1845 	mov	dptr,#_control_phase
      0060F7 04               [12] 1846 	inc	a
      0060F8 F0               [24] 1847 	movx	@dptr,a
      0060F9 02 65 D0         [24] 1848 	ljmp	00291$
      0060FC                       1849 00152$:
                                   1850 ;	tmk_core/protocol/ch555/usb_ak820.c:276: } else { control_stall(); return; }
      0060FC 02 5C 21         [24] 1851 	ljmp	_control_stall
                                   1852 ;	tmk_core/protocol/ch555/usb_ak820.c:278: case USB_GET_INTERFACE: /* DEF_USB_SET_IDLE has the same request byte. */
      0060FF                       1853 00157$:
                                   1854 ;	tmk_core/protocol/ch555/usb_ak820.c:279: if (type == 0x81 && valid_interface && zero_value && D0SetupLen == 1 && D0UsbConfig) {
      0060FF BF 81 2C         [24] 1855 	cjne	r7,#0x81,00167$
      006102 30 16 29         [24] 1856 	jnb	_control_setup_valid_interface_10000_289,00167$
      006105 30 18 26         [24] 1857 	jnb	_control_setup_zero_value_10000_289,00167$
      006108 90 07 6E         [24] 1858 	mov	dptr,#_D0SetupLen
      00610B E0               [24] 1859 	movx	a,@dptr
      00610C F9               [12] 1860 	mov	r1,a
      00610D A3               [24] 1861 	inc	dptr
      00610E E0               [24] 1862 	movx	a,@dptr
      00610F FA               [12] 1863 	mov	r2,a
      006110 B9 01 1B         [24] 1864 	cjne	r1,#0x01,00167$
      006113 BA 00 18         [24] 1865 	cjne	r2,#0x00,00167$
      006116 90 07 73         [24] 1866 	mov	dptr,#_D0UsbConfig
      006119 E0               [24] 1867 	movx	a,@dptr
      00611A 60 12            [24] 1868 	jz	00167$
                                   1869 ;	tmk_core/protocol/ch555/usb_ak820.c:280: pD0_EP0_BUF[0] = 0;
      00611C 90 10 00         [24] 1870 	mov	dptr,#0x1000
      00611F E4               [12] 1871 	clr	a
      006120 F0               [24] 1872 	movx	@dptr,a
                                   1873 ;	tmk_core/protocol/ch555/usb_ak820.c:281: D0_EP0T_L = 1;
      006121 90 22 08         [24] 1874 	mov	dptr,#0x2208
      006124 04               [12] 1875 	inc	a
      006125 F0               [24] 1876 	movx	@dptr,a
                                   1877 ;	tmk_core/protocol/ch555/usb_ak820.c:282: control_phase = CTRL_STATUS_OUT;
      006126 90 07 CC         [24] 1878 	mov	dptr,#_control_phase
      006129 04               [12] 1879 	inc	a
      00612A F0               [24] 1880 	movx	@dptr,a
      00612B 02 65 D0         [24] 1881 	ljmp	00291$
      00612E                       1882 00167$:
                                   1883 ;	tmk_core/protocol/ch555/usb_ak820.c:283: } else if (valid_interface && D0UsbConfig && type == 0x21 && zero_length) {
      00612E 30 16 1E         [24] 1884 	jnb	_control_setup_valid_interface_10000_289,00161$
      006131 90 07 73         [24] 1885 	mov	dptr,#_D0UsbConfig
      006134 E0               [24] 1886 	movx	a,@dptr
      006135 60 18            [24] 1887 	jz	00161$
      006137 BF 21 15         [24] 1888 	cjne	r7,#0x21,00161$
      00613A 30 19 12         [24] 1889 	jnb	_control_setup_zero_length_10000_289,00161$
                                   1890 ;	tmk_core/protocol/ch555/usb_ak820.c:284: if (index == KEYBOARD_INTERFACE) keyboard_idle = value >> 8;
      00613D EB               [12] 1891 	mov	a,r3
      00613E 4C               [12] 1892 	orl	a,r4
      00613F 70 05            [24] 1893 	jnz	00159$
      006141 90 06 4B         [24] 1894 	mov	dptr,#_keyboard_idle
      006144 EE               [12] 1895 	mov	a,r6
      006145 F0               [24] 1896 	movx	@dptr,a
      006146                       1897 00159$:
                                   1898 ;	tmk_core/protocol/ch555/usb_ak820.c:285: control_phase = CTRL_STATUS_IN;
      006146 90 07 CC         [24] 1899 	mov	dptr,#_control_phase
      006149 74 03            [12] 1900 	mov	a,#0x03
      00614B F0               [24] 1901 	movx	@dptr,a
      00614C 02 65 D0         [24] 1902 	ljmp	00291$
      00614F                       1903 00161$:
                                   1904 ;	tmk_core/protocol/ch555/usb_ak820.c:286: } else { control_stall(); return; }
      00614F 02 5C 21         [24] 1905 	ljmp	_control_stall
                                   1906 ;	tmk_core/protocol/ch555/usb_ak820.c:288: case USB_SET_INTERFACE: /* DEF_USB_SET_PROTOCOL has the same request byte. */
      006152                       1907 00173$:
                                   1908 ;	tmk_core/protocol/ch555/usb_ak820.c:289: if (type == 0x01 && valid_interface && zero_value && zero_length && D0UsbConfig) {
      006152 BF 01 18         [24] 1909 	cjne	r7,#0x01,00182$
      006155 30 16 15         [24] 1910 	jnb	_control_setup_valid_interface_10000_289,00182$
      006158 30 18 12         [24] 1911 	jnb	_control_setup_zero_value_10000_289,00182$
      00615B 30 19 0F         [24] 1912 	jnb	_control_setup_zero_length_10000_289,00182$
      00615E 90 07 73         [24] 1913 	mov	dptr,#_D0UsbConfig
      006161 E0               [24] 1914 	movx	a,@dptr
      006162 60 09            [24] 1915 	jz	00182$
                                   1916 ;	tmk_core/protocol/ch555/usb_ak820.c:290: control_phase = CTRL_STATUS_IN;
      006164 90 07 CC         [24] 1917 	mov	dptr,#_control_phase
      006167 74 03            [12] 1918 	mov	a,#0x03
      006169 F0               [24] 1919 	movx	@dptr,a
      00616A 02 65 D0         [24] 1920 	ljmp	00291$
      00616D                       1921 00182$:
                                   1922 ;	tmk_core/protocol/ch555/usb_ak820.c:291: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0x21 && zero_length && value <= 1) {
      00616D EB               [12] 1923 	mov	a,r3
      00616E 4C               [12] 1924 	orl	a,r4
      00616F 70 2C            [24] 1925 	jnz	00175$
      006171 90 07 73         [24] 1926 	mov	dptr,#_D0UsbConfig
      006174 E0               [24] 1927 	movx	a,@dptr
      006175 60 26            [24] 1928 	jz	00175$
      006177 BF 21 23         [24] 1929 	cjne	r7,#0x21,00175$
      00617A 30 19 20         [24] 1930 	jnb	_control_setup_zero_length_10000_289,00175$
      00617D 8D 01            [24] 1931 	mov	ar1,r5
      00617F 8E 02            [24] 1932 	mov	ar2,r6
      006181 C3               [12] 1933 	clr	c
      006182 74 01            [12] 1934 	mov	a,#0x01
      006184 99               [12] 1935 	subb	a,r1
      006185 E4               [12] 1936 	clr	a
      006186 9A               [12] 1937 	subb	a,r2
      006187 40 14            [24] 1938 	jc	00175$
                                   1939 ;	free result
                                   1940 ;	tmk_core/protocol/ch555/usb_ak820.c:292: keyboard_protocol = value;
      006189 90 0D BB         [24] 1941 	mov	dptr,#_keyboard_protocol
      00618C ED               [12] 1942 	mov	a,r5
      00618D F0               [24] 1943 	movx	@dptr,a
                                   1944 ;	tmk_core/protocol/ch555/usb_ak820.c:293: keyboard_reset = 1;
      00618E 90 07 9D         [24] 1945 	mov	dptr,#_keyboard_reset
      006191 74 01            [12] 1946 	mov	a,#0x01
      006193 F0               [24] 1947 	movx	@dptr,a
                                   1948 ;	tmk_core/protocol/ch555/usb_ak820.c:294: control_phase = CTRL_STATUS_IN;
      006194 90 07 CC         [24] 1949 	mov	dptr,#_control_phase
      006197 74 03            [12] 1950 	mov	a,#0x03
      006199 F0               [24] 1951 	movx	@dptr,a
      00619A 02 65 D0         [24] 1952 	ljmp	00291$
      00619D                       1953 00175$:
                                   1954 ;	tmk_core/protocol/ch555/usb_ak820.c:295: } else { control_stall(); return; }
      00619D 02 5C 21         [24] 1955 	ljmp	_control_stall
                                   1956 ;	tmk_core/protocol/ch555/usb_ak820.c:297: case USB_GET_STATUS:
      0061A0                       1957 00188$:
                                   1958 ;	tmk_core/protocol/ch555/usb_ak820.c:298: if (zero_value && D0SetupLen == 2 &&
      0061A0 20 18 03         [24] 1959 	jb	_control_setup_zero_value_10000_289,01283$
      0061A3 02 5C 21         [24] 1960 	ljmp	_control_stall
      0061A6                       1961 01283$:
      0061A6 90 07 6E         [24] 1962 	mov	dptr,#_D0SetupLen
      0061A9 E0               [24] 1963 	movx	a,@dptr
      0061AA F9               [12] 1964 	mov	r1,a
      0061AB A3               [24] 1965 	inc	dptr
      0061AC E0               [24] 1966 	movx	a,@dptr
      0061AD FA               [12] 1967 	mov	r2,a
      0061AE B9 02 05         [24] 1968 	cjne	r1,#0x02,01284$
      0061B1 BA 00 02         [24] 1969 	cjne	r2,#0x00,01284$
      0061B4 80 03            [24] 1970 	sjmp	01285$
      0061B6                       1971 01284$:
      0061B6 02 5C 21         [24] 1972 	ljmp	_control_stall
      0061B9                       1973 01285$:
                                   1974 ;	tmk_core/protocol/ch555/usb_ak820.c:299: ((type == 0x80 && zero_index) || (type == 0x81 && valid_interface && D0UsbConfig) ||
      0061B9 E4               [12] 1975 	clr	a
      0061BA BF 80 01         [24] 1976 	cjne	r7,#0x80,01286$
      0061BD 04               [12] 1977 	inc	a
      0061BE                       1978 01286$:
      0061BE FA               [12] 1979 	mov	r2,a
      0061BF 60 03            [24] 1980 	jz	00196$
      0061C1 20 17 35         [24] 1981 	jb	_control_setup_zero_index_10000_289,00189$
      0061C4                       1982 00196$:
      0061C4 BF 81 09         [24] 1983 	cjne	r7,#0x81,00202$
      0061C7 30 16 06         [24] 1984 	jnb	_control_setup_valid_interface_10000_289,00202$
      0061CA 90 07 73         [24] 1985 	mov	dptr,#_D0UsbConfig
      0061CD E0               [24] 1986 	movx	a,@dptr
      0061CE 70 29            [24] 1987 	jnz	00189$
      0061D0                       1988 00202$:
                                   1989 ;	tmk_core/protocol/ch555/usb_ak820.c:300: (type == 0x82 && D0UsbConfig && (index == 0 || index == 0x80 || (index >= 0x81 && index <= 0x83))))) {
      0061D0 BF 82 70         [24] 1990 	cjne	r7,#0x82,00190$
      0061D3 90 07 73         [24] 1991 	mov	dptr,#_D0UsbConfig
      0061D6 E0               [24] 1992 	movx	a,@dptr
      0061D7 60 6A            [24] 1993 	jz	00190$
      0061D9 EB               [12] 1994 	mov	a,r3
      0061DA 4C               [12] 1995 	orl	a,r4
      0061DB 60 1C            [24] 1996 	jz	00189$
      0061DD 8B 00            [24] 1997 	mov	ar0,r3
      0061DF 8C 01            [24] 1998 	mov	ar1,r4
      0061E1 B8 80 05         [24] 1999 	cjne	r0,#0x80,01298$
      0061E4 B9 00 02         [24] 2000 	cjne	r1,#0x00,01298$
      0061E7 80 10            [24] 2001 	sjmp	00189$
      0061E9                       2002 01298$:
      0061E9 C3               [12] 2003 	clr	c
      0061EA E8               [12] 2004 	mov	a,r0
      0061EB 94 81            [12] 2005 	subb	a,#0x81
      0061ED E9               [12] 2006 	mov	a,r1
      0061EE 94 00            [12] 2007 	subb	a,#0x00
      0061F0 40 51            [24] 2008 	jc	00190$
      0061F2 74 83            [12] 2009 	mov	a,#0x83
      0061F4 98               [12] 2010 	subb	a,r0
      0061F5 E4               [12] 2011 	clr	a
      0061F6 99               [12] 2012 	subb	a,r1
      0061F7 40 4A            [24] 2013 	jc	00190$
                                   2014 ;	free result
      0061F9                       2015 00189$:
                                   2016 ;	tmk_core/protocol/ch555/usb_ak820.c:301: endpoint = index & 7;
      0061F9 8B 01            [24] 2017 	mov	ar1,r3
      0061FB 53 01 07         [24] 2018 	anl	ar1,#0x07
                                   2019 ;	tmk_core/protocol/ch555/usb_ak820.c:302: pD0_EP0_BUF[0] = type == 0x80 ? ((USB_SleepStatus & 1) << 1) :
      0061FE EA               [12] 2020 	mov	a,r2
      0061FF 60 0B            [24] 2021 	jz	00308$
      006201 90 07 75         [24] 2022 	mov	dptr,#_USB_SleepStatus
      006204 E0               [24] 2023 	movx	a,@dptr
      006205 54 01            [12] 2024 	anl	a,#0x01
      006207 25 E0            [12] 2025 	add	a,acc
      006209 FA               [12] 2026 	mov	r2,a
      00620A 80 22            [24] 2027 	sjmp	00309$
      00620C                       2028 00308$:
                                   2029 ;	tmk_core/protocol/ch555/usb_ak820.c:303: ((type == 0x82 && endpoint && (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_STALL) ? 1 : 0);
      00620C BF 82 1B         [24] 2030 	cjne	r7,#0x82,00310$
      00620F E9               [12] 2031 	mov	a,r1
      006210 60 18            [24] 2032 	jz	00310$
      006212 89 00            [24] 2033 	mov	ar0,r1
      006214 79 00            [12] 2034 	mov	r1,#0x00
      006216 74 22            [12] 2035 	mov	a,#0x22
      006218 29               [12] 2036 	add	a, r1
      006219 F9               [12] 2037 	mov	r1,a
      00621A 88 82            [24] 2038 	mov	dpl,r0
      00621C 89 83            [24] 2039 	mov	dph,r1
      00621E E0               [24] 2040 	movx	a,@dptr
      00621F F9               [12] 2041 	mov	r1,a
      006220 53 01 03         [24] 2042 	anl	ar1,#0x03
      006223 B9 03 04         [24] 2043 	cjne	r1,#0x03,00310$
      006226 79 01            [12] 2044 	mov	r1,#0x01
      006228 80 02            [24] 2045 	sjmp	00311$
      00622A                       2046 00310$:
      00622A 79 00            [12] 2047 	mov	r1,#0x00
      00622C                       2048 00311$:
      00622C 89 02            [24] 2049 	mov	ar2,r1
      00622E                       2050 00309$:
      00622E 90 10 00         [24] 2051 	mov	dptr,#0x1000
      006231 EA               [12] 2052 	mov	a,r2
      006232 F0               [24] 2053 	movx	@dptr,a
                                   2054 ;	tmk_core/protocol/ch555/usb_ak820.c:304: pD0_EP0_BUF[1] = 0;
      006233 A3               [24] 2055 	inc	dptr
      006234 E4               [12] 2056 	clr	a
      006235 F0               [24] 2057 	movx	@dptr,a
                                   2058 ;	tmk_core/protocol/ch555/usb_ak820.c:305: D0_EP0T_L = 2;
      006236 90 22 08         [24] 2059 	mov	dptr,#0x2208
      006239 74 02            [12] 2060 	mov	a,#0x02
      00623B F0               [24] 2061 	movx	@dptr,a
                                   2062 ;	tmk_core/protocol/ch555/usb_ak820.c:306: control_phase = CTRL_STATUS_OUT;
      00623C 90 07 CC         [24] 2063 	mov	dptr,#_control_phase
      00623F F0               [24] 2064 	movx	@dptr,a
      006240 02 65 D0         [24] 2065 	ljmp	00291$
      006243                       2066 00190$:
                                   2067 ;	tmk_core/protocol/ch555/usb_ak820.c:307: } else { control_stall(); return; }
      006243 02 5C 21         [24] 2068 	ljmp	_control_stall
                                   2069 ;	tmk_core/protocol/ch555/usb_ak820.c:310: case USB_SET_FEATURE: /* DEF_USB_GET_PROTOCOL has the same request byte. */
      006246                       2070 00205$:
                                   2071 ;	tmk_core/protocol/ch555/usb_ak820.c:311: if (zero_length && D0UsbConfig) {
      006246 20 19 03         [24] 2072 	jb	_control_setup_zero_length_10000_289,01307$
      006249 02 62 D9         [24] 2073 	ljmp	00279$
      00624C                       2074 01307$:
      00624C 90 07 73         [24] 2075 	mov	dptr,#_D0UsbConfig
      00624F E0               [24] 2076 	movx	a,@dptr
      006250 70 03            [24] 2077 	jnz	01308$
      006252 02 62 D9         [24] 2078 	ljmp	00279$
      006255                       2079 01308$:
                                   2080 ;	tmk_core/protocol/ch555/usb_ak820.c:312: if (type == 0x00 && value == 1 && zero_index) {
      006255 EF               [12] 2081 	mov	a,r7
      006256 70 29            [24] 2082 	jnz	00218$
      006258 8D 01            [24] 2083 	mov	ar1,r5
      00625A 8E 02            [24] 2084 	mov	ar2,r6
      00625C B9 01 22         [24] 2085 	cjne	r1,#0x01,00218$
      00625F BA 00 1F         [24] 2086 	cjne	r2,#0x00,00218$
      006262 30 17 1C         [24] 2087 	jnb	_control_setup_zero_index_10000_289,00218$
                                   2088 ;	tmk_core/protocol/ch555/usb_ak820.c:313: if (D0SetupReqCode == USB_SET_FEATURE) USB_SleepStatus |= 1;
      006265 90 07 6D         [24] 2089 	mov	dptr,#_D0SetupReqCode
      006268 E0               [24] 2090 	movx	a,@dptr
      006269 FA               [12] 2091 	mov	r2,a
      00626A BA 03 0A         [24] 2092 	cjne	r2,#0x03,00207$
      00626D 90 07 75         [24] 2093 	mov	dptr,#_USB_SleepStatus
      006270 E0               [24] 2094 	movx	a,@dptr
      006271 43 E0 01         [24] 2095 	orl	acc,#0x01
      006274 F0               [24] 2096 	movx	@dptr,a
      006275 80 59            [24] 2097 	sjmp	00219$
      006277                       2098 00207$:
                                   2099 ;	tmk_core/protocol/ch555/usb_ak820.c:314: else USB_SleepStatus &= ~1;
      006277 90 07 75         [24] 2100 	mov	dptr,#_USB_SleepStatus
      00627A E0               [24] 2101 	movx	a,@dptr
      00627B 53 E0 FE         [24] 2102 	anl	acc,#0xfe
      00627E F0               [24] 2103 	movx	@dptr,a
      00627F 80 4F            [24] 2104 	sjmp	00219$
      006281                       2105 00218$:
                                   2106 ;	tmk_core/protocol/ch555/usb_ak820.c:315: } else if (type == 0x02 && zero_value && index >= 0x81 && index <= 0x83) {
      006281 BF 02 49         [24] 2107 	cjne	r7,#0x02,00212$
      006284 30 18 46         [24] 2108 	jnb	_control_setup_zero_value_10000_289,00212$
      006287 8B 01            [24] 2109 	mov	ar1,r3
      006289 8C 02            [24] 2110 	mov	ar2,r4
      00628B C3               [12] 2111 	clr	c
      00628C E9               [12] 2112 	mov	a,r1
      00628D 94 81            [12] 2113 	subb	a,#0x81
      00628F EA               [12] 2114 	mov	a,r2
      006290 94 00            [12] 2115 	subb	a,#0x00
      006292 40 39            [24] 2116 	jc	00212$
      006294 74 83            [12] 2117 	mov	a,#0x83
      006296 99               [12] 2118 	subb	a,r1
      006297 E4               [12] 2119 	clr	a
      006298 9A               [12] 2120 	subb	a,r2
      006299 40 32            [24] 2121 	jc	00212$
                                   2122 ;	free result
                                   2123 ;	tmk_core/protocol/ch555/usb_ak820.c:316: endpoint = index & 7;
      00629B 8B 02            [24] 2124 	mov	ar2,r3
      00629D 53 02 07         [24] 2125 	anl	ar2,#0x07
                                   2126 ;	tmk_core/protocol/ch555/usb_ak820.c:318: EP_RESPONSE(endpoint) = bUEP_X_AUTO_TOG | (D0SetupReqCode == USB_SET_FEATURE ? UEP_X_RES_STALL : UEP_X_RES_NAK);
      0062A0 8A 00            [24] 2127 	mov	ar0,r2
      0062A2 79 00            [12] 2128 	mov	r1,#0x00
      0062A4 74 22            [12] 2129 	mov	a,#0x22
      0062A6 29               [12] 2130 	add	a, r1
      0062A7 F9               [12] 2131 	mov	r1,a
      0062A8 88 17            [24] 2132 	mov	_control_setup_sloc3_1_0,r0
      0062AA 89 18            [24] 2133 	mov	(_control_setup_sloc3_1_0 + 1),r1
      0062AC 90 07 6D         [24] 2134 	mov	dptr,#_D0SetupReqCode
      0062AF E0               [24] 2135 	movx	a,@dptr
      0062B0 F9               [12] 2136 	mov	r1,a
      0062B1 B9 03 04         [24] 2137 	cjne	r1,#0x03,00318$
      0062B4 79 03            [12] 2138 	mov	r1,#0x03
      0062B6 80 02            [24] 2139 	sjmp	00319$
      0062B8                       2140 00318$:
      0062B8 79 02            [12] 2141 	mov	r1,#0x02
      0062BA                       2142 00319$:
      0062BA 43 01 10         [24] 2143 	orl	ar1,#0x10
      0062BD 85 17 82         [24] 2144 	mov	dpl,_control_setup_sloc3_1_0
      0062C0 85 18 83         [24] 2145 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      0062C3 E9               [12] 2146 	mov	a,r1
      0062C4 F0               [24] 2147 	movx	@dptr,a
                                   2148 ;	tmk_core/protocol/ch555/usb_ak820.c:319: if (endpoint == RAW_IN_EPNUM) raw_complete();
      0062C5 BA 03 08         [24] 2149 	cjne	r2,#0x03,00219$
      0062C8 12 5B A9         [24] 2150 	lcall	_raw_complete
      0062CB 80 03            [24] 2151 	sjmp	00219$
      0062CD                       2152 00212$:
                                   2153 ;	tmk_core/protocol/ch555/usb_ak820.c:320: } else { control_stall(); return; }
      0062CD 02 5C 21         [24] 2154 	ljmp	_control_stall
      0062D0                       2155 00219$:
                                   2156 ;	tmk_core/protocol/ch555/usb_ak820.c:321: control_phase = CTRL_STATUS_IN;
      0062D0 90 07 CC         [24] 2157 	mov	dptr,#_control_phase
      0062D3 74 03            [12] 2158 	mov	a,#0x03
      0062D5 F0               [24] 2159 	movx	@dptr,a
      0062D6 02 65 D0         [24] 2160 	ljmp	00291$
      0062D9                       2161 00279$:
                                   2162 ;	tmk_core/protocol/ch555/usb_ak820.c:322: } else if (type == 0xa1 && D0SetupReqCode == HID_GET_REPORT && D0UsbConfig && D0SetupLen) {
      0062D9 E4               [12] 2163 	clr	a
      0062DA BF A1 01         [24] 2164 	cjne	r7,#0xa1,01324$
      0062DD 04               [12] 2165 	inc	a
      0062DE                       2166 01324$:
      0062DE FA               [12] 2167 	mov	r2,a
      0062DF 70 03            [24] 2168 	jnz	01326$
      0062E1 02 65 4B         [24] 2169 	ljmp	00273$
      0062E4                       2170 01326$:
      0062E4 90 07 6D         [24] 2171 	mov	dptr,#_D0SetupReqCode
      0062E7 E0               [24] 2172 	movx	a,@dptr
      0062E8 F9               [12] 2173 	mov	r1,a
      0062E9 B9 01 02         [24] 2174 	cjne	r1,#0x01,01327$
      0062EC 80 03            [24] 2175 	sjmp	01328$
      0062EE                       2176 01327$:
      0062EE 02 65 4B         [24] 2177 	ljmp	00273$
      0062F1                       2178 01328$:
      0062F1 90 07 73         [24] 2179 	mov	dptr,#_D0UsbConfig
      0062F4 E0               [24] 2180 	movx	a,@dptr
      0062F5 70 03            [24] 2181 	jnz	01329$
      0062F7 02 65 4B         [24] 2182 	ljmp	00273$
      0062FA                       2183 01329$:
      0062FA 90 07 6E         [24] 2184 	mov	dptr,#_D0SetupLen
      0062FD E0               [24] 2185 	movx	a,@dptr
      0062FE F8               [12] 2186 	mov	r0,a
      0062FF A3               [24] 2187 	inc	dptr
      006300 E0               [24] 2188 	movx	a,@dptr
      006301 48               [12] 2189 	orl	a,r0
      006302 70 03            [24] 2190 	jnz	01330$
      006304 02 65 4B         [24] 2191 	ljmp	00273$
      006307                       2192 01330$:
                                   2193 ;	tmk_core/protocol/ch555/usb_ak820.c:323: report_id = value;
      006307 C0 03            [24] 2194 	push	ar3
      006309 C0 04            [24] 2195 	push	ar4
      00630B 8D 01            [24] 2196 	mov	ar1,r5
                                   2197 ;	tmk_core/protocol/ch555/usb_ak820.c:324: if ((value >> 8) == 1 && index == KEYBOARD_INTERFACE && !report_id) {
      00630D 8E 00            [24] 2198 	mov	ar0,r6
      00630F B8 01 03         [24] 2199 	cjne	r0,#0x01,01331$
      006312 E8               [12] 2200 	mov	a,r0
      006313 80 01            [24] 2201 	sjmp	01332$
      006315                       2202 01331$:
      006315 E4               [12] 2203 	clr	a
      006316                       2204 01332$:
      006316 F5 17            [12] 2205 	mov	_control_setup_sloc3_1_0,a
      006318 D0 04            [24] 2206 	pop	ar4
      00631A D0 03            [24] 2207 	pop	ar3
      00631C E5 17            [12] 2208 	mov	a,_control_setup_sloc3_1_0
      00631E 60 17            [24] 2209 	jz	00251$
      006320 EB               [12] 2210 	mov	a,r3
      006321 4C               [12] 2211 	orl	a,r4
      006322 70 13            [24] 2212 	jnz	00251$
      006324 E9               [12] 2213 	mov	a,r1
      006325 70 10            [24] 2214 	jnz	00251$
                                   2215 ;	tmk_core/protocol/ch555/usb_ak820.c:325: length = KEYBOARD_EPSIZE;
      006327 90 07 D6         [24] 2216 	mov	dptr,#_control_setup_length_10000_289
      00632A 74 08            [12] 2217 	mov	a,#0x08
      00632C F0               [24] 2218 	movx	@dptr,a
      00632D E4               [12] 2219 	clr	a
      00632E A3               [24] 2220 	inc	dptr
      00632F F0               [24] 2221 	movx	@dptr,a
                                   2222 ;	tmk_core/protocol/ch555/usb_ak820.c:326: offset = SNAPSHOT_KEYBOARD;
      006330 90 07 D8         [24] 2223 	mov	dptr,#_control_setup_offset_10000_289
      006333 F0               [24] 2224 	movx	@dptr,a
      006334 02 64 BB         [24] 2225 	ljmp	00252$
      006337                       2226 00251$:
                                   2227 ;	tmk_core/protocol/ch555/usb_ak820.c:327: } else if ((value >> 8) == 1 && index == SHARED_INTERFACE &&
      006337 E5 17            [12] 2228 	mov	a,_control_setup_sloc3_1_0
      006339 60 27            [24] 2229 	jz	00245$
      00633B BB 02 24         [24] 2230 	cjne	r3,#0x02,00245$
      00633E BC 00 21         [24] 2231 	cjne	r4,#0x00,00245$
                                   2232 ;	tmk_core/protocol/ch555/usb_ak820.c:328: report_id < sizeof(shared_lengths) && shared_lengths[report_id]) {
      006341 B9 07 00         [24] 2233 	cjne	r1,#0x07,01339$
      006344                       2234 01339$:
      006344 50 1C            [24] 2235 	jnc	00245$
      006346 E9               [12] 2236 	mov	a,r1
      006347 90 BC 1D         [24] 2237 	mov	dptr,#_shared_lengths
      00634A 93               [24] 2238 	movc	a,@a+dptr
      00634B F8               [12] 2239 	mov	r0,a
      00634C 60 14            [24] 2240 	jz	00245$
                                   2241 ;	tmk_core/protocol/ch555/usb_ak820.c:329: length = shared_lengths[report_id];
      00634E 90 07 D6         [24] 2242 	mov	dptr,#_control_setup_length_10000_289
      006351 E8               [12] 2243 	mov	a,r0
      006352 F0               [24] 2244 	movx	@dptr,a
      006353 E4               [12] 2245 	clr	a
      006354 A3               [24] 2246 	inc	dptr
      006355 F0               [24] 2247 	movx	@dptr,a
                                   2248 ;	tmk_core/protocol/ch555/usb_ak820.c:330: offset = shared_offsets[report_id];
      006356 E9               [12] 2249 	mov	a,r1
      006357 90 BC 16         [24] 2250 	mov	dptr,#_shared_offsets
      00635A 93               [24] 2251 	movc	a,@a+dptr
      00635B 90 07 D8         [24] 2252 	mov	dptr,#_control_setup_offset_10000_289
      00635E F0               [24] 2253 	movx	@dptr,a
      00635F 02 64 BB         [24] 2254 	ljmp	00252$
      006362                       2255 00245$:
                                   2256 ;	tmk_core/protocol/ch555/usb_ak820.c:331: } else if ((value >> 8) == 1 && index == RAW_INTERFACE && !report_id) {
      006362 E5 17            [12] 2257 	mov	a,_control_setup_sloc3_1_0
      006364 60 7A            [24] 2258 	jz	00240$
      006366 BB 01 77         [24] 2259 	cjne	r3,#0x01,00240$
      006369 BC 00 74         [24] 2260 	cjne	r4,#0x00,00240$
      00636C E9               [12] 2261 	mov	a,r1
      00636D 70 71            [24] 2262 	jnz	00240$
                                   2263 ;	tmk_core/protocol/ch555/usb_ak820.c:332: length = D0SetupLen < RAW_EPSIZE ? D0SetupLen : RAW_EPSIZE;
      00636F 90 07 6E         [24] 2264 	mov	dptr,#_D0SetupLen
      006372 E0               [24] 2265 	movx	a,@dptr
      006373 F8               [12] 2266 	mov	r0,a
      006374 A3               [24] 2267 	inc	dptr
      006375 E0               [24] 2268 	movx	a,@dptr
      006376 F9               [12] 2269 	mov	r1,a
      006377 C3               [12] 2270 	clr	c
      006378 E8               [12] 2271 	mov	a,r0
      006379 94 20            [12] 2272 	subb	a,#0x20
      00637B E9               [12] 2273 	mov	a,r1
      00637C 94 00            [12] 2274 	subb	a,#0x00
      00637E 50 0A            [24] 2275 	jnc	00320$
      006380 90 07 6E         [24] 2276 	mov	dptr,#_D0SetupLen
      006383 E0               [24] 2277 	movx	a,@dptr
      006384 F8               [12] 2278 	mov	r0,a
      006385 A3               [24] 2279 	inc	dptr
      006386 E0               [24] 2280 	movx	a,@dptr
      006387 F9               [12] 2281 	mov	r1,a
      006388 80 04            [24] 2282 	sjmp	00321$
      00638A                       2283 00320$:
      00638A 78 20            [12] 2284 	mov	r0,#0x20
      00638C 79 00            [12] 2285 	mov	r1,#0x00
      00638E                       2286 00321$:
                                   2287 ;	tmk_core/protocol/ch555/usb_ak820.c:333: for (i = 0; i < length; ++i) pD0_EP0_BUF[i] = pUSB_BUF_DEV0[UX_EP3_ADDR + i];
      00638E 75 17 00         [24] 2288 	mov	_control_setup_sloc3_1_0,#0x00
      006391                       2289 00293$:
      006391 C0 03            [24] 2290 	push	ar3
      006393 C0 04            [24] 2291 	push	ar4
      006395 AB 17            [24] 2292 	mov	r3,_control_setup_sloc3_1_0
      006397 7C 00            [12] 2293 	mov	r4,#0x00
      006399 C3               [12] 2294 	clr	c
      00639A EB               [12] 2295 	mov	a,r3
      00639B 98               [12] 2296 	subb	a,r0
      00639C EC               [12] 2297 	mov	a,r4
      00639D 99               [12] 2298 	subb	a,r1
      00639E D0 04            [24] 2299 	pop	ar4
      0063A0 D0 03            [24] 2300 	pop	ar3
      0063A2 50 32            [24] 2301 	jnc	00222$
      0063A4 C0 00            [24] 2302 	push	ar0
      0063A6 C0 01            [24] 2303 	push	ar1
      0063A8 85 17 19         [24] 2304 	mov	_control_setup_sloc4_1_0,_control_setup_sloc3_1_0
      0063AB 74 10            [12] 2305 	mov	a,#0x10
      0063AD 24 00            [12] 2306 	add	a, #0x00
      0063AF F5 1A            [12] 2307 	mov	(_control_setup_sloc4_1_0 + 1),a
      0063B1 A8 17            [24] 2308 	mov	r0,_control_setup_sloc3_1_0
      0063B3 79 00            [12] 2309 	mov	r1,#0x00
      0063B5 74 C0            [12] 2310 	mov	a,#0xc0
      0063B7 28               [12] 2311 	add	a, r0
      0063B8 F8               [12] 2312 	mov	r0,a
      0063B9 E4               [12] 2313 	clr	a
      0063BA 39               [12] 2314 	addc	a, r1
      0063BB F9               [12] 2315 	mov	r1,a
      0063BC 88 82            [24] 2316 	mov	dpl,r0
      0063BE 74 10            [12] 2317 	mov	a,#0x10
      0063C0 29               [12] 2318 	add	a, r1
      0063C1 F5 83            [12] 2319 	mov	dph,a
      0063C3 E0               [24] 2320 	movx	a,@dptr
      0063C4 85 19 82         [24] 2321 	mov	dpl,_control_setup_sloc4_1_0
      0063C7 85 1A 83         [24] 2322 	mov	dph,(_control_setup_sloc4_1_0 + 1)
      0063CA F0               [24] 2323 	movx	@dptr,a
      0063CB E5 17            [12] 2324 	mov	a,_control_setup_sloc3_1_0
      0063CD 04               [12] 2325 	inc	a
      0063CE F5 17            [12] 2326 	mov	_control_setup_sloc3_1_0,a
      0063D0 D0 01            [24] 2327 	pop	ar1
      0063D2 D0 00            [24] 2328 	pop	ar0
      0063D4 80 BB            [24] 2329 	sjmp	00293$
      0063D6                       2330 00222$:
                                   2331 ;	tmk_core/protocol/ch555/usb_ak820.c:334: length = 0; /* data already copied */
      0063D6 90 07 D6         [24] 2332 	mov	dptr,#_control_setup_length_10000_289
      0063D9 E4               [12] 2333 	clr	a
      0063DA F0               [24] 2334 	movx	@dptr,a
      0063DB A3               [24] 2335 	inc	dptr
      0063DC F0               [24] 2336 	movx	@dptr,a
      0063DD 02 64 BB         [24] 2337 	ljmp	00252$
      0063E0                       2338 00240$:
                                   2339 ;	tmk_core/protocol/ch555/usb_ak820.c:335: } else if (value == 0x0200 && index == KEYBOARD_INTERFACE) {
      0063E0 8D 00            [24] 2340 	mov	ar0,r5
      0063E2 8E 01            [24] 2341 	mov	ar1,r6
      0063E4 B8 00 21         [24] 2342 	cjne	r0,#0x00,00236$
      0063E7 B9 02 1E         [24] 2343 	cjne	r1,#0x02,00236$
      0063EA EB               [12] 2344 	mov	a,r3
      0063EB 4C               [12] 2345 	orl	a,r4
      0063EC 70 1A            [24] 2346 	jnz	00236$
                                   2347 ;	tmk_core/protocol/ch555/usb_ak820.c:336: pD0_EP0_BUF[0] = KB_USB_SetReport;
      0063EE 90 07 78         [24] 2348 	mov	dptr,#_KB_USB_SetReport
      0063F1 E0               [24] 2349 	movx	a,@dptr
      0063F2 90 10 00         [24] 2350 	mov	dptr,#0x1000
      0063F5 F0               [24] 2351 	movx	@dptr,a
                                   2352 ;	tmk_core/protocol/ch555/usb_ak820.c:337: length = 0;
      0063F6 90 07 D6         [24] 2353 	mov	dptr,#_control_setup_length_10000_289
      0063F9 E4               [12] 2354 	clr	a
      0063FA F0               [24] 2355 	movx	@dptr,a
      0063FB A3               [24] 2356 	inc	dptr
      0063FC F0               [24] 2357 	movx	@dptr,a
                                   2358 ;	tmk_core/protocol/ch555/usb_ak820.c:338: D0SetupLen = 1;
      0063FD 90 07 6E         [24] 2359 	mov	dptr,#_D0SetupLen
      006400 04               [12] 2360 	inc	a
      006401 F0               [24] 2361 	movx	@dptr,a
      006402 E4               [12] 2362 	clr	a
      006403 A3               [24] 2363 	inc	dptr
      006404 F0               [24] 2364 	movx	@dptr,a
      006405 02 64 BB         [24] 2365 	ljmp	00252$
      006408                       2366 00236$:
                                   2367 ;	tmk_core/protocol/ch555/usb_ak820.c:339: } else if (value == (0x0200 | REPORT_ID_NKRO) && index == SHARED_INTERFACE) {
      006408 B8 06 41         [24] 2368 	cjne	r0,#0x06,00232$
      00640B B9 02 3E         [24] 2369 	cjne	r1,#0x02,00232$
      00640E BB 02 3B         [24] 2370 	cjne	r3,#0x02,00232$
      006411 BC 00 38         [24] 2371 	cjne	r4,#0x00,00232$
                                   2372 ;	tmk_core/protocol/ch555/usb_ak820.c:340: pD0_EP0_BUF[0] = REPORT_ID_NKRO;
      006414 C0 03            [24] 2373 	push	ar3
      006416 C0 04            [24] 2374 	push	ar4
      006418 90 10 00         [24] 2375 	mov	dptr,#0x1000
      00641B 74 06            [12] 2376 	mov	a,#0x06
      00641D F0               [24] 2377 	movx	@dptr,a
                                   2378 ;	tmk_core/protocol/ch555/usb_ak820.c:341: pD0_EP0_BUF[1] = KB_USB_SetReport;
      00641E 90 07 78         [24] 2379 	mov	dptr,#_KB_USB_SetReport
      006421 E0               [24] 2380 	movx	a,@dptr
      006422 90 10 01         [24] 2381 	mov	dptr,#0x1001
      006425 F0               [24] 2382 	movx	@dptr,a
                                   2383 ;	tmk_core/protocol/ch555/usb_ak820.c:342: length = 0;
      006426 90 07 D6         [24] 2384 	mov	dptr,#_control_setup_length_10000_289
      006429 E4               [12] 2385 	clr	a
      00642A F0               [24] 2386 	movx	@dptr,a
      00642B A3               [24] 2387 	inc	dptr
      00642C F0               [24] 2388 	movx	@dptr,a
                                   2389 ;	tmk_core/protocol/ch555/usb_ak820.c:343: if (D0SetupLen > 2) D0SetupLen = 2;
      00642D 90 07 6E         [24] 2390 	mov	dptr,#_D0SetupLen
      006430 E0               [24] 2391 	movx	a,@dptr
      006431 FB               [12] 2392 	mov	r3,a
      006432 A3               [24] 2393 	inc	dptr
      006433 E0               [24] 2394 	movx	a,@dptr
      006434 FC               [12] 2395 	mov	r4,a
      006435 C3               [12] 2396 	clr	c
      006436 74 02            [12] 2397 	mov	a,#0x02
      006438 9B               [12] 2398 	subb	a,r3
      006439 E4               [12] 2399 	clr	a
      00643A 9C               [12] 2400 	subb	a,r4
      00643B D0 04            [24] 2401 	pop	ar4
      00643D D0 03            [24] 2402 	pop	ar3
      00643F 50 7A            [24] 2403 	jnc	00252$
                                   2404 ;	free result
      006441 90 07 6E         [24] 2405 	mov	dptr,#_D0SetupLen
      006444 74 02            [12] 2406 	mov	a,#0x02
      006446 F0               [24] 2407 	movx	@dptr,a
      006447 E4               [12] 2408 	clr	a
      006448 A3               [24] 2409 	inc	dptr
      006449 F0               [24] 2410 	movx	@dptr,a
      00644A 80 6F            [24] 2411 	sjmp	00252$
      00644C                       2412 00232$:
                                   2413 ;	tmk_core/protocol/ch555/usb_ak820.c:344: } else if (value == 0x0300 && index == RAW_INTERFACE) {
      00644C B8 00 69         [24] 2414 	cjne	r0,#0x00,00228$
      00644F B9 03 66         [24] 2415 	cjne	r1,#0x03,00228$
      006452 BB 01 63         [24] 2416 	cjne	r3,#0x01,00228$
      006455 BC 00 60         [24] 2417 	cjne	r4,#0x00,00228$
                                   2418 ;	tmk_core/protocol/ch555/usb_ak820.c:347: pD0_EP0_BUF[0] = 'A';
      006458 90 10 00         [24] 2419 	mov	dptr,#0x1000
      00645B 74 41            [12] 2420 	mov	a,#0x41
      00645D F0               [24] 2421 	movx	@dptr,a
                                   2422 ;	tmk_core/protocol/ch555/usb_ak820.c:348: pD0_EP0_BUF[1] = 'K';
      00645E A3               [24] 2423 	inc	dptr
      00645F 74 4B            [12] 2424 	mov	a,#0x4b
      006461 F0               [24] 2425 	movx	@dptr,a
                                   2426 ;	tmk_core/protocol/ch555/usb_ak820.c:349: pD0_EP0_BUF[2] = 'B';
      006462 A3               [24] 2427 	inc	dptr
      006463 74 42            [12] 2428 	mov	a,#0x42
      006465 F0               [24] 2429 	movx	@dptr,a
                                   2430 ;	tmk_core/protocol/ch555/usb_ak820.c:350: pD0_EP0_BUF[3] = 'T';
      006466 A3               [24] 2431 	inc	dptr
      006467 74 54            [12] 2432 	mov	a,#0x54
      006469 F0               [24] 2433 	movx	@dptr,a
                                   2434 ;	tmk_core/protocol/ch555/usb_ak820.c:351: pD0_EP0_BUF[4] = 1;
      00646A A3               [24] 2435 	inc	dptr
      00646B 74 01            [12] 2436 	mov	a,#0x01
      00646D F0               [24] 2437 	movx	@dptr,a
                                   2438 ;	tmk_core/protocol/ch555/usb_ak820.c:352: pD0_EP0_BUF[5] = ak820_boot_stage;
      00646E 90 07 79         [24] 2439 	mov	dptr,#_ak820_boot_stage
      006471 E0               [24] 2440 	movx	a,@dptr
      006472 90 10 05         [24] 2441 	mov	dptr,#0x1005
      006475 F0               [24] 2442 	movx	@dptr,a
                                   2443 ;	tmk_core/protocol/ch555/usb_ak820.c:353: pD0_EP0_BUF[6] = ak820_main_heartbeat;
      006476 90 07 7A         [24] 2444 	mov	dptr,#_ak820_main_heartbeat
      006479 E0               [24] 2445 	movx	a,@dptr
      00647A 90 10 06         [24] 2446 	mov	dptr,#0x1006
      00647D F0               [24] 2447 	movx	@dptr,a
                                   2448 ;	tmk_core/protocol/ch555/usb_ak820.c:354: pD0_EP0_BUF[7] = (USB_EnumStatus ? 1 : 0) | (USB_SleepStatus & 2);
      00647E 90 07 74         [24] 2449 	mov	dptr,#_USB_EnumStatus
      006481 E0               [24] 2450 	movx	a,@dptr
      006482 60 02            [24] 2451 	jz	00322$
      006484 74 01            [12] 2452 	mov	a,#0x01
      006486                       2453 00322$:
      006486 F9               [12] 2454 	mov	r1,a
      006487 90 07 75         [24] 2455 	mov	dptr,#_USB_SleepStatus
      00648A E0               [24] 2456 	movx	a,@dptr
      00648B 54 02            [12] 2457 	anl	a,#0x02
      00648D F8               [12] 2458 	mov	r0,a
      00648E E9               [12] 2459 	mov	a,r1
      00648F 42 00            [12] 2460 	orl	ar0,a
      006491 90 10 07         [24] 2461 	mov	dptr,#0x1007
      006494 E8               [12] 2462 	mov	a,r0
      006495 F0               [24] 2463 	movx	@dptr,a
                                   2464 ;	tmk_core/protocol/ch555/usb_ak820.c:355: length = 0;
      006496 90 07 D6         [24] 2465 	mov	dptr,#_control_setup_length_10000_289
      006499 E4               [12] 2466 	clr	a
      00649A F0               [24] 2467 	movx	@dptr,a
      00649B A3               [24] 2468 	inc	dptr
      00649C F0               [24] 2469 	movx	@dptr,a
                                   2470 ;	tmk_core/protocol/ch555/usb_ak820.c:356: if (D0SetupLen > 8) D0SetupLen = 8;
      00649D 90 07 6E         [24] 2471 	mov	dptr,#_D0SetupLen
      0064A0 E0               [24] 2472 	movx	a,@dptr
      0064A1 F8               [12] 2473 	mov	r0,a
      0064A2 A3               [24] 2474 	inc	dptr
      0064A3 E0               [24] 2475 	movx	a,@dptr
      0064A4 F9               [12] 2476 	mov	r1,a
      0064A5 C3               [12] 2477 	clr	c
      0064A6 74 08            [12] 2478 	mov	a,#0x08
      0064A8 98               [12] 2479 	subb	a,r0
      0064A9 E4               [12] 2480 	clr	a
      0064AA 99               [12] 2481 	subb	a,r1
      0064AB 50 0E            [24] 2482 	jnc	00252$
                                   2483 ;	free result
      0064AD 90 07 6E         [24] 2484 	mov	dptr,#_D0SetupLen
      0064B0 74 08            [12] 2485 	mov	a,#0x08
      0064B2 F0               [24] 2486 	movx	@dptr,a
      0064B3 E4               [12] 2487 	clr	a
      0064B4 A3               [24] 2488 	inc	dptr
      0064B5 F0               [24] 2489 	movx	@dptr,a
      0064B6 80 03            [24] 2490 	sjmp	00252$
      0064B8                       2491 00228$:
                                   2492 ;	tmk_core/protocol/ch555/usb_ak820.c:357: } else { control_stall(); return; }
      0064B8 02 5C 21         [24] 2493 	ljmp	_control_stall
      0064BB                       2494 00252$:
                                   2495 ;	tmk_core/protocol/ch555/usb_ak820.c:358: if (length) {
      0064BB 90 07 D6         [24] 2496 	mov	dptr,#_control_setup_length_10000_289
      0064BE E0               [24] 2497 	movx	a,@dptr
      0064BF F5 19            [12] 2498 	mov	_control_setup_sloc4_1_0,a
      0064C1 A3               [24] 2499 	inc	dptr
      0064C2 E0               [24] 2500 	movx	a,@dptr
      0064C3 F5 1A            [12] 2501 	mov	(_control_setup_sloc4_1_0 + 1),a
      0064C5 E5 19            [12] 2502 	mov	a,_control_setup_sloc4_1_0
      0064C7 45 1A            [12] 2503 	orl	a,(_control_setup_sloc4_1_0 + 1)
      0064C9 60 50            [24] 2504 	jz	00262$
                                   2505 ;	tmk_core/protocol/ch555/usb_ak820.c:359: if (D0SetupLen > length) D0SetupLen = length;
      0064CB 90 07 6E         [24] 2506 	mov	dptr,#_D0SetupLen
      0064CE E0               [24] 2507 	movx	a,@dptr
      0064CF F8               [12] 2508 	mov	r0,a
      0064D0 A3               [24] 2509 	inc	dptr
      0064D1 E0               [24] 2510 	movx	a,@dptr
      0064D2 F9               [12] 2511 	mov	r1,a
      0064D3 C3               [12] 2512 	clr	c
      0064D4 E5 19            [12] 2513 	mov	a,_control_setup_sloc4_1_0
      0064D6 98               [12] 2514 	subb	a,r0
      0064D7 E5 1A            [12] 2515 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0064D9 99               [12] 2516 	subb	a,r1
      0064DA 50 0A            [24] 2517 	jnc	00559$
                                   2518 ;	free result
      0064DC 90 07 6E         [24] 2519 	mov	dptr,#_D0SetupLen
      0064DF E5 19            [12] 2520 	mov	a,_control_setup_sloc4_1_0
      0064E1 F0               [24] 2521 	movx	@dptr,a
      0064E2 E5 1A            [12] 2522 	mov	a,(_control_setup_sloc4_1_0 + 1)
      0064E4 A3               [24] 2523 	inc	dptr
      0064E5 F0               [24] 2524 	movx	@dptr,a
                                   2525 ;	tmk_core/protocol/ch555/usb_ak820.c:362: for (i = 0; i < (uint8_t)D0SetupLen; ++i) pD0_EP0_BUF[i] = input_snapshot[offset + i];
      0064E6                       2526 00559$:
      0064E6 75 19 00         [24] 2527 	mov	_control_setup_sloc4_1_0,#0x00
      0064E9                       2528 00296$:
      0064E9 90 07 6E         [24] 2529 	mov	dptr,#_D0SetupLen
      0064EC E0               [24] 2530 	movx	a,@dptr
      0064ED F8               [12] 2531 	mov	r0,a
      0064EE C3               [12] 2532 	clr	c
      0064EF E5 19            [12] 2533 	mov	a,_control_setup_sloc4_1_0
      0064F1 98               [12] 2534 	subb	a,r0
      0064F2 50 46            [24] 2535 	jnc	00263$
      0064F4 85 19 17         [24] 2536 	mov	_control_setup_sloc3_1_0,_control_setup_sloc4_1_0
      0064F7 74 10            [12] 2537 	mov	a,#0x10
      0064F9 24 00            [12] 2538 	add	a, #0x00
      0064FB F5 18            [12] 2539 	mov	(_control_setup_sloc3_1_0 + 1),a
      0064FD 90 07 D8         [24] 2540 	mov	dptr,#_control_setup_offset_10000_289
      006500 E0               [24] 2541 	movx	a,@dptr
      006501 25 19            [12] 2542 	add	a, _control_setup_sloc4_1_0
      006503 24 9E            [12] 2543 	add	a, #_input_snapshot
      006505 F5 82            [12] 2544 	mov	dpl,a
      006507 E4               [12] 2545 	clr	a
      006508 34 07            [12] 2546 	addc	a,#(_input_snapshot >> 8)
      00650A F5 83            [12] 2547 	mov	dph,a
      00650C E0               [24] 2548 	movx	a,@dptr
      00650D 85 17 82         [24] 2549 	mov	dpl,_control_setup_sloc3_1_0
      006510 85 18 83         [24] 2550 	mov	dph,(_control_setup_sloc3_1_0 + 1)
      006513 F0               [24] 2551 	movx	@dptr,a
      006514 E5 19            [12] 2552 	mov	a,_control_setup_sloc4_1_0
      006516 04               [12] 2553 	inc	a
      006517 F5 19            [12] 2554 	mov	_control_setup_sloc4_1_0,a
      006519 80 CE            [24] 2555 	sjmp	00296$
      00651B                       2556 00262$:
                                   2557 ;	tmk_core/protocol/ch555/usb_ak820.c:363: } else if (index == RAW_INTERFACE && D0SetupLen > RAW_EPSIZE) D0SetupLen = RAW_EPSIZE;
      00651B BB 01 1C         [24] 2558 	cjne	r3,#0x01,00263$
      00651E BC 00 19         [24] 2559 	cjne	r4,#0x00,00263$
      006521 90 07 6E         [24] 2560 	mov	dptr,#_D0SetupLen
      006524 E0               [24] 2561 	movx	a,@dptr
      006525 F8               [12] 2562 	mov	r0,a
      006526 A3               [24] 2563 	inc	dptr
      006527 E0               [24] 2564 	movx	a,@dptr
      006528 F9               [12] 2565 	mov	r1,a
      006529 C3               [12] 2566 	clr	c
      00652A 74 20            [12] 2567 	mov	a,#0x20
      00652C 98               [12] 2568 	subb	a,r0
      00652D E4               [12] 2569 	clr	a
      00652E 99               [12] 2570 	subb	a,r1
      00652F 50 09            [24] 2571 	jnc	00263$
                                   2572 ;	free result
      006531 90 07 6E         [24] 2573 	mov	dptr,#_D0SetupLen
      006534 74 20            [12] 2574 	mov	a,#0x20
      006536 F0               [24] 2575 	movx	@dptr,a
      006537 E4               [12] 2576 	clr	a
      006538 A3               [24] 2577 	inc	dptr
      006539 F0               [24] 2578 	movx	@dptr,a
      00653A                       2579 00263$:
                                   2580 ;	tmk_core/protocol/ch555/usb_ak820.c:364: D0_EP0T_L = D0SetupLen;
      00653A 90 07 6E         [24] 2581 	mov	dptr,#_D0SetupLen
      00653D E0               [24] 2582 	movx	a,@dptr
      00653E 90 22 08         [24] 2583 	mov	dptr,#0x2208
      006541 F0               [24] 2584 	movx	@dptr,a
                                   2585 ;	tmk_core/protocol/ch555/usb_ak820.c:365: control_phase = CTRL_STATUS_OUT;
      006542 90 07 CC         [24] 2586 	mov	dptr,#_control_phase
      006545 74 02            [12] 2587 	mov	a,#0x02
      006547 F0               [24] 2588 	movx	@dptr,a
      006548 02 65 D0         [24] 2589 	ljmp	00291$
      00654B                       2590 00273$:
                                   2591 ;	tmk_core/protocol/ch555/usb_ak820.c:366: } else if (index == KEYBOARD_INTERFACE && D0UsbConfig && type == 0xa1 && D0SetupReqCode == DEF_USB_GET_PROTOCOL && zero_value && D0SetupLen == 1) {
      00654B EB               [12] 2592 	mov	a,r3
      00654C 4C               [12] 2593 	orl	a,r4
      00654D 70 37            [24] 2594 	jnz	00265$
      00654F 90 07 73         [24] 2595 	mov	dptr,#_D0UsbConfig
      006552 E0               [24] 2596 	movx	a,@dptr
      006553 60 31            [24] 2597 	jz	00265$
      006555 EA               [12] 2598 	mov	a,r2
      006556 60 2E            [24] 2599 	jz	00265$
      006558 90 07 6D         [24] 2600 	mov	dptr,#_D0SetupReqCode
      00655B E0               [24] 2601 	movx	a,@dptr
      00655C FA               [12] 2602 	mov	r2,a
      00655D BA 03 26         [24] 2603 	cjne	r2,#0x03,00265$
      006560 30 18 23         [24] 2604 	jnb	_control_setup_zero_value_10000_289,00265$
      006563 90 07 6E         [24] 2605 	mov	dptr,#_D0SetupLen
      006566 E0               [24] 2606 	movx	a,@dptr
      006567 F9               [12] 2607 	mov	r1,a
      006568 A3               [24] 2608 	inc	dptr
      006569 E0               [24] 2609 	movx	a,@dptr
      00656A FA               [12] 2610 	mov	r2,a
      00656B B9 01 18         [24] 2611 	cjne	r1,#0x01,00265$
      00656E BA 00 15         [24] 2612 	cjne	r2,#0x00,00265$
                                   2613 ;	tmk_core/protocol/ch555/usb_ak820.c:367: pD0_EP0_BUF[0] = keyboard_protocol;
      006571 90 0D BB         [24] 2614 	mov	dptr,#_keyboard_protocol
      006574 E0               [24] 2615 	movx	a,@dptr
      006575 90 10 00         [24] 2616 	mov	dptr,#0x1000
      006578 F0               [24] 2617 	movx	@dptr,a
                                   2618 ;	tmk_core/protocol/ch555/usb_ak820.c:368: D0_EP0T_L = 1;
      006579 90 22 08         [24] 2619 	mov	dptr,#0x2208
      00657C 74 01            [12] 2620 	mov	a,#0x01
      00657E F0               [24] 2621 	movx	@dptr,a
                                   2622 ;	tmk_core/protocol/ch555/usb_ak820.c:369: control_phase = CTRL_STATUS_OUT;
      00657F 90 07 CC         [24] 2623 	mov	dptr,#_control_phase
      006582 04               [12] 2624 	inc	a
      006583 F0               [24] 2625 	movx	@dptr,a
      006584 80 4A            [24] 2626 	sjmp	00291$
      006586                       2627 00265$:
                                   2628 ;	tmk_core/protocol/ch555/usb_ak820.c:370: } else { control_stall(); return; }
                                   2629 ;	tmk_core/protocol/ch555/usb_ak820.c:372: case DEF_USB_GET_IDLE:
      006586 02 5C 21         [24] 2630 	ljmp	_control_stall
      006589                       2631 00282$:
                                   2632 ;	tmk_core/protocol/ch555/usb_ak820.c:373: if (valid_interface && D0UsbConfig && type == 0xa1 && !(value >> 8) && D0SetupLen == 1) {
      006589 30 16 3E         [24] 2633 	jnb	_control_setup_valid_interface_10000_289,00284$
      00658C 90 07 73         [24] 2634 	mov	dptr,#_D0UsbConfig
      00658F E0               [24] 2635 	movx	a,@dptr
      006590 60 38            [24] 2636 	jz	00284$
      006592 BF A1 35         [24] 2637 	cjne	r7,#0xa1,00284$
      006595 8E 05            [24] 2638 	mov	ar5,r6
      006597 7E 00            [12] 2639 	mov	r6,#0x00
      006599 ED               [12] 2640 	mov	a,r5
      00659A 4E               [12] 2641 	orl	a,r6
      00659B 70 2D            [24] 2642 	jnz	00284$
      00659D 90 07 6E         [24] 2643 	mov	dptr,#_D0SetupLen
      0065A0 E0               [24] 2644 	movx	a,@dptr
      0065A1 FE               [12] 2645 	mov	r6,a
      0065A2 A3               [24] 2646 	inc	dptr
      0065A3 E0               [24] 2647 	movx	a,@dptr
      0065A4 FF               [12] 2648 	mov	r7,a
      0065A5 BE 01 22         [24] 2649 	cjne	r6,#0x01,00284$
      0065A8 BF 00 1F         [24] 2650 	cjne	r7,#0x00,00284$
                                   2651 ;	tmk_core/protocol/ch555/usb_ak820.c:374: pD0_EP0_BUF[0] = index == KEYBOARD_INTERFACE ? keyboard_idle : 0;
      0065AB EB               [12] 2652 	mov	a,r3
      0065AC 4C               [12] 2653 	orl	a,r4
      0065AD 70 07            [24] 2654 	jnz	00324$
      0065AF 90 06 4B         [24] 2655 	mov	dptr,#_keyboard_idle
      0065B2 E0               [24] 2656 	movx	a,@dptr
      0065B3 FF               [12] 2657 	mov	r7,a
      0065B4 80 02            [24] 2658 	sjmp	00325$
      0065B6                       2659 00324$:
      0065B6 7F 00            [12] 2660 	mov	r7,#0x00
      0065B8                       2661 00325$:
      0065B8 90 10 00         [24] 2662 	mov	dptr,#0x1000
      0065BB EF               [12] 2663 	mov	a,r7
      0065BC F0               [24] 2664 	movx	@dptr,a
                                   2665 ;	tmk_core/protocol/ch555/usb_ak820.c:375: D0_EP0T_L = 1;
      0065BD 90 22 08         [24] 2666 	mov	dptr,#0x2208
      0065C0 74 01            [12] 2667 	mov	a,#0x01
      0065C2 F0               [24] 2668 	movx	@dptr,a
                                   2669 ;	tmk_core/protocol/ch555/usb_ak820.c:376: control_phase = CTRL_STATUS_OUT;
      0065C3 90 07 CC         [24] 2670 	mov	dptr,#_control_phase
      0065C6 04               [12] 2671 	inc	a
      0065C7 F0               [24] 2672 	movx	@dptr,a
      0065C8 80 06            [24] 2673 	sjmp	00291$
      0065CA                       2674 00284$:
                                   2675 ;	tmk_core/protocol/ch555/usb_ak820.c:377: } else { control_stall(); return; }
                                   2676 ;	tmk_core/protocol/ch555/usb_ak820.c:379: default: control_stall(); return;
      0065CA 02 5C 21         [24] 2677 	ljmp	_control_stall
      0065CD                       2678 00290$:
                                   2679 ;	tmk_core/protocol/ch555/usb_ak820.c:380: }
      0065CD 02 5C 21         [24] 2680 	ljmp	_control_stall
      0065D0                       2681 00291$:
                                   2682 ;	tmk_core/protocol/ch555/usb_ak820.c:381: D0_EP0RES = bUEP_R_TOG | bUEP_T_TOG | UEP_R_RES_ACK | UEP_T_RES_ACK;
      0065D0 90 22 00         [24] 2683 	mov	dptr,#0x2200
      0065D3 74 C0            [12] 2684 	mov	a,#0xc0
      0065D5 F0               [24] 2685 	movx	@dptr,a
                                   2686 ;	tmk_core/protocol/ch555/usb_ak820.c:382: }
      0065D6 22               [24] 2687 	ret
                                   2688 ;------------------------------------------------------------
                                   2689 ;Allocation info for local variables in function 'control_out'
                                   2690 ;------------------------------------------------------------
                                   2691 ;i             Allocated with name '_control_out_i_10000_373'
                                   2692 ;------------------------------------------------------------
                                   2693 ;	tmk_core/protocol/ch555/usb_ak820.c:384: static void control_out(void) {
                                   2694 ;	-----------------------------------------
                                   2695 ;	 function control_out
                                   2696 ;	-----------------------------------------
      0065D7                       2697 _control_out:
                                   2698 ;	tmk_core/protocol/ch555/usb_ak820.c:386: if (!(D0_STATUS & bUXS_TOG_OK)) return; /* duplicate OUT is not a new request */
      0065D7 90 22 0F         [24] 2699 	mov	dptr,#0x220f
      0065DA E0               [24] 2700 	movx	a,@dptr
      0065DB 20 E6 01         [24] 2701 	jb	acc.6,00102$
      0065DE 22               [24] 2702 	ret
      0065DF                       2703 00102$:
                                   2704 ;	tmk_core/protocol/ch555/usb_ak820.c:387: if (control_phase == CTRL_STATUS_OUT && D0_RX_LEN == 0) {
      0065DF 90 07 CC         [24] 2705 	mov	dptr,#_control_phase
      0065E2 E0               [24] 2706 	movx	a,@dptr
      0065E3 FF               [12] 2707 	mov	r7,a
      0065E4 BF 02 12         [24] 2708 	cjne	r7,#0x02,00104$
      0065E7 90 22 0E         [24] 2709 	mov	dptr,#0x220e
      0065EA E0               [24] 2710 	movx	a,@dptr
      0065EB 70 0C            [24] 2711 	jnz	00104$
                                   2712 ;	tmk_core/protocol/ch555/usb_ak820.c:388: control_phase = CTRL_IDLE;
      0065ED 90 07 CC         [24] 2713 	mov	dptr,#_control_phase
      0065F0 E4               [12] 2714 	clr	a
      0065F1 F0               [24] 2715 	movx	@dptr,a
                                   2716 ;	tmk_core/protocol/ch555/usb_ak820.c:389: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      0065F2 90 22 00         [24] 2717 	mov	dptr,#0x2200
      0065F5 74 02            [12] 2718 	mov	a,#0x02
      0065F7 F0               [24] 2719 	movx	@dptr,a
                                   2720 ;	tmk_core/protocol/ch555/usb_ak820.c:390: return;
      0065F8 22               [24] 2721 	ret
      0065F9                       2722 00104$:
                                   2723 ;	tmk_core/protocol/ch555/usb_ak820.c:392: if (control_phase != CTRL_DATA_OUT || D0_RX_LEN != D0SetupLen) { control_stall(); return; }
      0065F9 BF 04 19         [24] 2724 	cjne	r7,#0x04,00106$
      0065FC 90 22 0E         [24] 2725 	mov	dptr,#0x220e
      0065FF E0               [24] 2726 	movx	a,@dptr
      006600 FF               [12] 2727 	mov	r7,a
      006601 90 07 6E         [24] 2728 	mov	dptr,#_D0SetupLen
      006604 E0               [24] 2729 	movx	a,@dptr
      006605 FD               [12] 2730 	mov	r5,a
      006606 A3               [24] 2731 	inc	dptr
      006607 E0               [24] 2732 	movx	a,@dptr
      006608 FE               [12] 2733 	mov	r6,a
      006609 7C 00            [12] 2734 	mov	r4,#0x00
      00660B EF               [12] 2735 	mov	a,r7
      00660C B5 05 06         [24] 2736 	cjne	a,ar5,00209$
      00660F EC               [12] 2737 	mov	a,r4
      006610 B5 06 02         [24] 2738 	cjne	a,ar6,00209$
      006613 80 03            [24] 2739 	sjmp	00107$
      006615                       2740 00209$:
      006615                       2741 00106$:
      006615 02 5C 21         [24] 2742 	ljmp	_control_stall
      006618                       2743 00107$:
                                   2744 ;	tmk_core/protocol/ch555/usb_ak820.c:393: if (output_kind == OUTPUT_RAW && raw_state == RAW_RX) {
      006618 90 07 CD         [24] 2745 	mov	dptr,#_output_kind
      00661B E0               [24] 2746 	movx	a,@dptr
      00661C FF               [12] 2747 	mov	r7,a
      00661D BF 01 2E         [24] 2748 	cjne	r7,#0x01,00118$
      006620 90 07 7B         [24] 2749 	mov	dptr,#_raw_state
      006623 E0               [24] 2750 	movx	a,@dptr
      006624 FE               [12] 2751 	mov	r6,a
      006625 BE 01 26         [24] 2752 	cjne	r6,#0x01,00118$
                                   2753 ;	tmk_core/protocol/ch555/usb_ak820.c:394: for (i = 0; i < RAW_EPSIZE; ++i) raw_buffer[i] = pD0_EP0_BUF[i];
      006628 7E 00            [12] 2754 	mov	r6,#0x00
      00662A                       2755 00121$:
      00662A EE               [12] 2756 	mov	a,r6
      00662B 24 7C            [12] 2757 	add	a, #_raw_buffer
      00662D FC               [12] 2758 	mov	r4,a
      00662E E4               [12] 2759 	clr	a
      00662F 34 07            [12] 2760 	addc	a, #(_raw_buffer >> 8)
      006631 FD               [12] 2761 	mov	r5,a
      006632 8E 82            [24] 2762 	mov	dpl,r6
      006634 74 10            [12] 2763 	mov	a,#0x10
      006636 24 00            [12] 2764 	add	a, #0x00
      006638 F5 83            [12] 2765 	mov	dph,a
      00663A E0               [24] 2766 	movx	a,@dptr
      00663B 8C 82            [24] 2767 	mov	dpl,r4
      00663D 8D 83            [24] 2768 	mov	dph,r5
      00663F F0               [24] 2769 	movx	@dptr,a
      006640 0E               [12] 2770 	inc	r6
      006641 BE 20 00         [24] 2771 	cjne	r6,#0x20,00214$
      006644                       2772 00214$:
      006644 40 E4            [24] 2773 	jc	00121$
                                   2774 ;	tmk_core/protocol/ch555/usb_ak820.c:395: raw_state = RAW_READY; /* publish only after the entire packet is copied */
      006646 90 07 7B         [24] 2775 	mov	dptr,#_raw_state
      006649 74 02            [12] 2776 	mov	a,#0x02
      00664B F0               [24] 2777 	movx	@dptr,a
      00664C 80 2B            [24] 2778 	sjmp	00119$
      00664E                       2779 00118$:
                                   2780 ;	tmk_core/protocol/ch555/usb_ak820.c:396: } else if (output_kind == OUTPUT_LED) {
      00664E BF 02 0A         [24] 2781 	cjne	r7,#0x02,00115$
                                   2782 ;	tmk_core/protocol/ch555/usb_ak820.c:397: KB_USB_SetReport = pD0_EP0_BUF[0];
      006651 90 10 00         [24] 2783 	mov	dptr,#0x1000
      006654 E0               [24] 2784 	movx	a,@dptr
      006655 90 07 78         [24] 2785 	mov	dptr,#_KB_USB_SetReport
      006658 F0               [24] 2786 	movx	@dptr,a
      006659 80 1E            [24] 2787 	sjmp	00119$
      00665B                       2788 00115$:
                                   2789 ;	tmk_core/protocol/ch555/usb_ak820.c:398: } else if (output_kind == OUTPUT_SHARED_LED && pD0_EP0_BUF[0] == output_report_id) {
      00665B BF 03 18         [24] 2790 	cjne	r7,#0x03,00111$
      00665E 90 10 00         [24] 2791 	mov	dptr,#0x1000
      006661 E0               [24] 2792 	movx	a,@dptr
      006662 FF               [12] 2793 	mov	r7,a
      006663 90 07 CE         [24] 2794 	mov	dptr,#_output_report_id
      006666 E0               [24] 2795 	movx	a,@dptr
      006667 FE               [12] 2796 	mov	r6,a
      006668 EF               [12] 2797 	mov	a,r7
      006669 B5 06 0A         [24] 2798 	cjne	a,ar6,00111$
                                   2799 ;	tmk_core/protocol/ch555/usb_ak820.c:399: KB_USB_SetReport = pD0_EP0_BUF[1];
      00666C 90 10 01         [24] 2800 	mov	dptr,#0x1001
      00666F E0               [24] 2801 	movx	a,@dptr
      006670 90 07 78         [24] 2802 	mov	dptr,#_KB_USB_SetReport
      006673 F0               [24] 2803 	movx	@dptr,a
      006674 80 03            [24] 2804 	sjmp	00119$
      006676                       2805 00111$:
                                   2806 ;	tmk_core/protocol/ch555/usb_ak820.c:400: } else { control_stall(); return; }
      006676 02 5C 21         [24] 2807 	ljmp	_control_stall
      006679                       2808 00119$:
                                   2809 ;	tmk_core/protocol/ch555/usb_ak820.c:401: output_kind = OUTPUT_NONE;
      006679 90 07 CD         [24] 2810 	mov	dptr,#_output_kind
      00667C E4               [12] 2811 	clr	a
      00667D F0               [24] 2812 	movx	@dptr,a
                                   2813 ;	tmk_core/protocol/ch555/usb_ak820.c:402: D0SetupLen = 0;
      00667E 90 07 6E         [24] 2814 	mov	dptr,#_D0SetupLen
      006681 F0               [24] 2815 	movx	@dptr,a
      006682 A3               [24] 2816 	inc	dptr
      006683 F0               [24] 2817 	movx	@dptr,a
                                   2818 ;	tmk_core/protocol/ch555/usb_ak820.c:403: control_phase = CTRL_STATUS_IN;
      006684 90 07 CC         [24] 2819 	mov	dptr,#_control_phase
      006687 74 03            [12] 2820 	mov	a,#0x03
      006689 F0               [24] 2821 	movx	@dptr,a
                                   2822 ;	tmk_core/protocol/ch555/usb_ak820.c:404: D0_EP0T_L = 0;
      00668A 90 22 08         [24] 2823 	mov	dptr,#0x2208
      00668D E4               [12] 2824 	clr	a
      00668E F0               [24] 2825 	movx	@dptr,a
                                   2826 ;	tmk_core/protocol/ch555/usb_ak820.c:405: D0_EP0RES = bUEP_T_TOG | UEP_R_RES_NAK | UEP_T_RES_ACK;
      00668F F5 82            [12] 2827 	mov	dpl,a
      006691 74 48            [12] 2828 	mov	a,#0x48
      006693 F0               [24] 2829 	movx	@dptr,a
                                   2830 ;	tmk_core/protocol/ch555/usb_ak820.c:406: }
      006694 22               [24] 2831 	ret
                                   2832 ;------------------------------------------------------------
                                   2833 ;Allocation info for local variables in function 'control_in'
                                   2834 ;------------------------------------------------------------
                                   2835 ;	tmk_core/protocol/ch555/usb_ak820.c:408: static void control_in(void) {
                                   2836 ;	-----------------------------------------
                                   2837 ;	 function control_in
                                   2838 ;	-----------------------------------------
      006695                       2839 _control_in:
                                   2840 ;	tmk_core/protocol/ch555/usb_ak820.c:409: if (control_phase == CTRL_DATA_IN) {
      006695 90 07 CC         [24] 2841 	mov	dptr,#_control_phase
      006698 E0               [24] 2842 	movx	a,@dptr
      006699 FF               [12] 2843 	mov	r7,a
      00669A BF 01 22         [24] 2844 	cjne	r7,#0x01,00109$
                                   2845 ;	tmk_core/protocol/ch555/usb_ak820.c:410: if (D0SetupLen || control_zlp) {
      00669D 90 07 6E         [24] 2846 	mov	dptr,#_D0SetupLen
      0066A0 E0               [24] 2847 	movx	a,@dptr
      0066A1 FD               [12] 2848 	mov	r5,a
      0066A2 A3               [24] 2849 	inc	dptr
      0066A3 E0               [24] 2850 	movx	a,@dptr
      0066A4 4D               [12] 2851 	orl	a,r5
      0066A5 70 06            [24] 2852 	jnz	00101$
      0066A7 90 07 CF         [24] 2853 	mov	dptr,#_control_zlp
      0066AA E0               [24] 2854 	movx	a,@dptr
      0066AB 60 0A            [24] 2855 	jz	00102$
      0066AD                       2856 00101$:
                                   2857 ;	tmk_core/protocol/ch555/usb_ak820.c:411: D0_EP0RES ^= bUEP_T_TOG;
      0066AD 90 22 00         [24] 2858 	mov	dptr,#0x2200
      0066B0 E0               [24] 2859 	movx	a,@dptr
      0066B1 64 40            [12] 2860 	xrl	a,#0x40
      0066B3 F0               [24] 2861 	movx	@dptr,a
                                   2862 ;	tmk_core/protocol/ch555/usb_ak820.c:412: control_next();
                                   2863 ;	tmk_core/protocol/ch555/usb_ak820.c:413: return;
      0066B4 02 5C 43         [24] 2864 	ljmp	_control_next
      0066B7                       2865 00102$:
                                   2866 ;	tmk_core/protocol/ch555/usb_ak820.c:415: control_phase = CTRL_STATUS_OUT;
      0066B7 90 07 CC         [24] 2867 	mov	dptr,#_control_phase
      0066BA 74 02            [12] 2868 	mov	a,#0x02
      0066BC F0               [24] 2869 	movx	@dptr,a
      0066BD 80 18            [24] 2870 	sjmp	00110$
      0066BF                       2871 00109$:
                                   2872 ;	tmk_core/protocol/ch555/usb_ak820.c:416: } else if (control_phase == CTRL_STATUS_IN) {
      0066BF BF 03 15         [24] 2873 	cjne	r7,#0x03,00110$
                                   2874 ;	tmk_core/protocol/ch555/usb_ak820.c:417: if (D0SetupReqCode == USB_SET_ADDRESS) D0_ADDR = D0SetupLen;
      0066C2 90 07 6D         [24] 2875 	mov	dptr,#_D0SetupReqCode
      0066C5 E0               [24] 2876 	movx	a,@dptr
      0066C6 FF               [12] 2877 	mov	r7,a
      0066C7 BF 05 08         [24] 2878 	cjne	r7,#0x05,00105$
      0066CA 90 07 6E         [24] 2879 	mov	dptr,#_D0SetupLen
      0066CD E0               [24] 2880 	movx	a,@dptr
      0066CE 90 22 07         [24] 2881 	mov	dptr,#0x2207
      0066D1 F0               [24] 2882 	movx	@dptr,a
      0066D2                       2883 00105$:
                                   2884 ;	tmk_core/protocol/ch555/usb_ak820.c:418: control_phase = CTRL_IDLE;
      0066D2 90 07 CC         [24] 2885 	mov	dptr,#_control_phase
      0066D5 E4               [12] 2886 	clr	a
      0066D6 F0               [24] 2887 	movx	@dptr,a
      0066D7                       2888 00110$:
                                   2889 ;	tmk_core/protocol/ch555/usb_ak820.c:420: D0_EP0RES = bUEP_R_TOG | UEP_R_RES_ACK | UEP_T_RES_NAK;
      0066D7 90 22 00         [24] 2890 	mov	dptr,#0x2200
      0066DA 74 82            [12] 2891 	mov	a,#0x82
      0066DC F0               [24] 2892 	movx	@dptr,a
                                   2893 ;	tmk_core/protocol/ch555/usb_ak820.c:421: }
      0066DD 22               [24] 2894 	ret
                                   2895 ;------------------------------------------------------------
                                   2896 ;Allocation info for local variables in function 'USB_DeviceInterrupt'
                                   2897 ;------------------------------------------------------------
                                   2898 ;status        Allocated with name '_USB_DeviceInterrupt_status_10000_397'
                                   2899 ;endpoint      Allocated with name '_USB_DeviceInterrupt_endpoint_10000_397'
                                   2900 ;------------------------------------------------------------
                                   2901 ;	tmk_core/protocol/ch555/usb_ak820.c:423: void USB_DeviceInterrupt(void) {
                                   2902 ;	-----------------------------------------
                                   2903 ;	 function USB_DeviceInterrupt
                                   2904 ;	-----------------------------------------
      0066DE                       2905 _USB_DeviceInterrupt:
                                   2906 ;	tmk_core/protocol/ch555/usb_ak820.c:426: do {
      0066DE                       2907 00129$:
                                   2908 ;	tmk_core/protocol/ch555/usb_ak820.c:428: if (USB_IF & bUX_IF_BUS_RST) {
      0066DE 90 22 3D         [24] 2909 	mov	dptr,#0x223d
      0066E1 E0               [24] 2910 	movx	a,@dptr
      0066E2 30 E0 4B         [24] 2911 	jnb	acc.0,00127$
                                   2912 ;	tmk_core/protocol/ch555/usb_ak820.c:429: endpoints_reset();
      0066E5 12 5B C6         [24] 2913 	lcall	_endpoints_reset
                                   2914 ;	tmk_core/protocol/ch555/usb_ak820.c:430: D0_ADDR = 0;
      0066E8 90 22 07         [24] 2915 	mov	dptr,#0x2207
      0066EB E4               [12] 2916 	clr	a
      0066EC F0               [24] 2917 	movx	@dptr,a
                                   2918 ;	tmk_core/protocol/ch555/usb_ak820.c:431: D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0066ED 90 07 75         [24] 2919 	mov	dptr,#_USB_SleepStatus
      0066F0 F0               [24] 2920 	movx	@dptr,a
      0066F1 90 07 74         [24] 2921 	mov	dptr,#_USB_EnumStatus
      0066F4 F0               [24] 2922 	movx	@dptr,a
      0066F5 90 07 73         [24] 2923 	mov	dptr,#_D0UsbConfig
      0066F8 F0               [24] 2924 	movx	@dptr,a
                                   2925 ;	tmk_core/protocol/ch555/usb_ak820.c:432: KB_USB_SetReport = 0;
      0066F9 90 07 78         [24] 2926 	mov	dptr,#_KB_USB_SetReport
      0066FC F0               [24] 2927 	movx	@dptr,a
                                   2928 ;	tmk_core/protocol/ch555/usb_ak820.c:433: keyboard_protocol = 1;
      0066FD 90 0D BB         [24] 2929 	mov	dptr,#_keyboard_protocol
      006700 04               [12] 2930 	inc	a
      006701 F0               [24] 2931 	movx	@dptr,a
                                   2932 ;	tmk_core/protocol/ch555/usb_ak820.c:434: keyboard_idle = 0;
      006702 90 06 4B         [24] 2933 	mov	dptr,#_keyboard_idle
      006705 E4               [12] 2934 	clr	a
      006706 F0               [24] 2935 	movx	@dptr,a
                                   2936 ;	tmk_core/protocol/ch555/usb_ak820.c:435: keyboard_reset = 1;
      006707 90 07 9D         [24] 2937 	mov	dptr,#_keyboard_reset
      00670A 04               [12] 2938 	inc	a
      00670B F0               [24] 2939 	movx	@dptr,a
                                   2940 ;	tmk_core/protocol/ch555/usb_ak820.c:436: D0SetupReqCode = 0xff;
      00670C 90 07 6D         [24] 2941 	mov	dptr,#_D0SetupReqCode
      00670F 74 FF            [12] 2942 	mov	a,#0xff
      006711 F0               [24] 2943 	movx	@dptr,a
                                   2944 ;	tmk_core/protocol/ch555/usb_ak820.c:437: D0SetupLen = 0;
      006712 90 07 6E         [24] 2945 	mov	dptr,#_D0SetupLen
      006715 E4               [12] 2946 	clr	a
      006716 F0               [24] 2947 	movx	@dptr,a
      006717 A3               [24] 2948 	inc	dptr
      006718 F0               [24] 2949 	movx	@dptr,a
                                   2950 ;	tmk_core/protocol/ch555/usb_ak820.c:438: control_phase = CTRL_IDLE;
      006719 90 07 CC         [24] 2951 	mov	dptr,#_control_phase
      00671C F0               [24] 2952 	movx	@dptr,a
                                   2953 ;	tmk_core/protocol/ch555/usb_ak820.c:439: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00671D 90 22 00         [24] 2954 	mov	dptr,#0x2200
      006720 74 02            [12] 2955 	mov	a,#0x02
      006722 F0               [24] 2956 	movx	@dptr,a
                                   2957 ;	tmk_core/protocol/ch555/usb_ak820.c:440: ACK_TRANSFER();
      006723 90 22 0F         [24] 2958 	mov	dptr,#0x220f
      006726 E4               [12] 2959 	clr	a
      006727 F0               [24] 2960 	movx	@dptr,a
                                   2961 ;	tmk_core/protocol/ch555/usb_ak820.c:441: ACK_RESET();
      006728 90 22 3D         [24] 2962 	mov	dptr,#0x223d
      00672B 04               [12] 2963 	inc	a
      00672C F0               [24] 2964 	movx	@dptr,a
      00672D 02 67 C8         [24] 2965 	ljmp	00130$
      006730                       2966 00127$:
                                   2967 ;	tmk_core/protocol/ch555/usb_ak820.c:442: } else if (USB_IF & bUX_IF_D0_TRANS) {
      006730 90 22 3D         [24] 2968 	mov	dptr,#0x223d
      006733 E0               [24] 2969 	movx	a,@dptr
      006734 30 E5 60         [24] 2970 	jnb	acc.5,00124$
                                   2971 ;	tmk_core/protocol/ch555/usb_ak820.c:443: status = D0_STATUS;
      006737 90 22 0F         [24] 2972 	mov	dptr,#0x220f
      00673A E0               [24] 2973 	movx	a,@dptr
      00673B FF               [12] 2974 	mov	r7,a
                                   2975 ;	tmk_core/protocol/ch555/usb_ak820.c:444: endpoint = status & MASK_UXS_ENDP;
      00673C 74 07            [12] 2976 	mov	a,#0x07
      00673E 5F               [12] 2977 	anl	a,r7
      00673F FE               [12] 2978 	mov	r6,a
                                   2979 ;	tmk_core/protocol/ch555/usb_ak820.c:448: if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_OUT && !endpoint) {
      006740 EF               [12] 2980 	mov	a,r7
      006741 54 18            [12] 2981 	anl	a,#0x18
      006743 70 08            [24] 2982 	jnz	00115$
      006745 EE               [12] 2983 	mov	a,r6
      006746 70 05            [24] 2984 	jnz	00115$
                                   2985 ;	tmk_core/protocol/ch555/usb_ak820.c:449: control_out();
      006748 12 65 D7         [24] 2986 	lcall	_control_out
      00674B 80 43            [24] 2987 	sjmp	00116$
      00674D                       2988 00115$:
                                   2989 ;	tmk_core/protocol/ch555/usb_ak820.c:450: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_IN) {
      00674D 8F 05            [24] 2990 	mov	ar5,r7
      00674F 74 18            [12] 2991 	mov	a,#0x18
      006751 5D               [12] 2992 	anl	a,r5
      006752 FC               [12] 2993 	mov	r4,a
      006753 BC 10 2D         [24] 2994 	cjne	r4,#0x10,00112$
                                   2995 ;	tmk_core/protocol/ch555/usb_ak820.c:451: if (!endpoint) control_in();
      006756 EE               [12] 2996 	mov	a,r6
      006757 70 05            [24] 2997 	jnz	00106$
      006759 12 66 95         [24] 2998 	lcall	_control_in
      00675C 80 32            [24] 2999 	sjmp	00116$
      00675E                       3000 00106$:
                                   3001 ;	tmk_core/protocol/ch555/usb_ak820.c:452: else if (endpoint <= 3) {
      00675E EE               [12] 3002 	mov	a,r6
      00675F 24 FC            [12] 3003 	add	a,#0xff - 0x03
      006761 40 2D            [24] 3004 	jc	00116$
                                   3005 ;	free result
                                   3006 ;	tmk_core/protocol/ch555/usb_ak820.c:453: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_NAK;
      006763 8E 04            [24] 3007 	mov	ar4,r6
      006765 7B 00            [12] 3008 	mov	r3,#0x00
      006767 74 22            [12] 3009 	mov	a,#0x22
      006769 2B               [12] 3010 	add	a, r3
      00676A FB               [12] 3011 	mov	r3,a
      00676B 8C 82            [24] 3012 	mov	dpl,r4
      00676D 8B 83            [24] 3013 	mov	dph,r3
      00676F E0               [24] 3014 	movx	a,@dptr
      006770 FA               [12] 3015 	mov	r2,a
      006771 74 FC            [12] 3016 	mov	a,#0xfc
      006773 5A               [12] 3017 	anl	a,r2
      006774 44 02            [12] 3018 	orl	a,#0x02
      006776 8C 82            [24] 3019 	mov	dpl,r4
      006778 8B 83            [24] 3020 	mov	dph,r3
      00677A F0               [24] 3021 	movx	@dptr,a
                                   3022 ;	tmk_core/protocol/ch555/usb_ak820.c:454: if (endpoint == RAW_IN_EPNUM) raw_complete();
      00677B BE 03 12         [24] 3023 	cjne	r6,#0x03,00116$
      00677E 12 5B A9         [24] 3024 	lcall	_raw_complete
      006781 80 0D            [24] 3025 	sjmp	00116$
      006783                       3026 00112$:
                                   3027 ;	tmk_core/protocol/ch555/usb_ak820.c:456: } else if ((status & MASK_UXS_TOKEN) == UXS_TOKEN_FREE && (status & bUXS_SETUP_ACT)) {
      006783 53 05 18         [24] 3028 	anl	ar5,#0x18
      006786 BD 18 07         [24] 3029 	cjne	r5,#0x18,00116$
      006789 EF               [12] 3030 	mov	a,r7
      00678A 30 E5 03         [24] 3031 	jnb	acc.5,00116$
                                   3032 ;	tmk_core/protocol/ch555/usb_ak820.c:457: control_setup();
      00678D 12 5E 3A         [24] 3033 	lcall	_control_setup
      006790                       3034 00116$:
                                   3035 ;	tmk_core/protocol/ch555/usb_ak820.c:459: ACK_TRANSFER();
      006790 90 22 0F         [24] 3036 	mov	dptr,#0x220f
      006793 E4               [12] 3037 	clr	a
      006794 F0               [24] 3038 	movx	@dptr,a
      006795 80 31            [24] 3039 	sjmp	00130$
      006797                       3040 00124$:
                                   3041 ;	tmk_core/protocol/ch555/usb_ak820.c:460: } else if (USB_IF & bUX_IF_SUSPEND) {
      006797 90 22 3D         [24] 3042 	mov	dptr,#0x223d
      00679A E0               [24] 3043 	movx	a,@dptr
      00679B 30 E2 2A         [24] 3044 	jnb	acc.2,00130$
                                   3045 ;	tmk_core/protocol/ch555/usb_ak820.c:462: ak820_os_indicator_mode = AK820_OS_NORMAL;
      00679E 90 05 9E         [24] 3046 	mov	dptr,#_ak820_os_indicator_mode
      0067A1 E4               [12] 3047 	clr	a
      0067A2 F0               [24] 3048 	movx	@dptr,a
                                   3049 ;	tmk_core/protocol/ch555/usb_ak820.c:464: if (USB_IF & bUX_SUSPEND) USB_SleepStatus |= 2;
      0067A3 90 22 3D         [24] 3050 	mov	dptr,#0x223d
      0067A6 E0               [24] 3051 	movx	a,@dptr
      0067A7 30 E3 0A         [24] 3052 	jnb	acc.3,00119$
      0067AA 90 07 75         [24] 3053 	mov	dptr,#_USB_SleepStatus
      0067AD E0               [24] 3054 	movx	a,@dptr
      0067AE 43 E0 02         [24] 3055 	orl	acc,#0x02
      0067B1 F0               [24] 3056 	movx	@dptr,a
      0067B2 80 0E            [24] 3057 	sjmp	00120$
      0067B4                       3058 00119$:
                                   3059 ;	tmk_core/protocol/ch555/usb_ak820.c:466: USB_SleepStatus &= ~2;
      0067B4 90 07 75         [24] 3060 	mov	dptr,#_USB_SleepStatus
      0067B7 E0               [24] 3061 	movx	a,@dptr
      0067B8 53 E0 FD         [24] 3062 	anl	acc,#0xfd
      0067BB F0               [24] 3063 	movx	@dptr,a
                                   3064 ;	tmk_core/protocol/ch555/usb_ak820.c:467: keyboard_reset = 1;
      0067BC 90 07 9D         [24] 3065 	mov	dptr,#_keyboard_reset
      0067BF 74 01            [12] 3066 	mov	a,#0x01
      0067C1 F0               [24] 3067 	movx	@dptr,a
      0067C2                       3068 00120$:
                                   3069 ;	tmk_core/protocol/ch555/usb_ak820.c:469: ACK_SUSPEND();
      0067C2 90 22 3D         [24] 3070 	mov	dptr,#0x223d
      0067C5 74 04            [12] 3071 	mov	a,#0x04
      0067C7 F0               [24] 3072 	movx	@dptr,a
      0067C8                       3073 00130$:
                                   3074 ;	tmk_core/protocol/ch555/usb_ak820.c:471: } while (USB_IF & (bUX_IF_BUS_RST | bUX_IF_D0_TRANS | bUX_IF_SUSPEND));
      0067C8 90 22 3D         [24] 3075 	mov	dptr,#0x223d
      0067CB E0               [24] 3076 	movx	a,@dptr
      0067CC 54 25            [12] 3077 	anl	a,#0x25
      0067CE 60 03            [24] 3078 	jz	00242$
      0067D0 02 66 DE         [24] 3079 	ljmp	00129$
      0067D3                       3080 00242$:
                                   3081 ;	tmk_core/protocol/ch555/usb_ak820.c:472: }
      0067D3 22               [24] 3082 	ret
                                   3083 ;------------------------------------------------------------
                                   3084 ;Allocation info for local variables in function 'USB_Device_Init'
                                   3085 ;------------------------------------------------------------
                                   3086 ;	tmk_core/protocol/ch555/usb_ak820.c:475: void USB_Device_Init(void) {
                                   3087 ;	-----------------------------------------
                                   3088 ;	 function USB_Device_Init
                                   3089 ;	-----------------------------------------
      0067D4                       3090 _USB_Device_Init:
                                   3091 ;	tmk_core/protocol/ch555/usb_ak820.c:476: IE_USB = 0;
                                   3092 ;	assignBit
      0067D4 C2 E9            [12] 3093 	clr	_IE_USB
                                   3094 ;	tmk_core/protocol/ch555/usb_ak820.c:477: USB_CTRL = 0;
      0067D6 90 22 3C         [24] 3095 	mov	dptr,#0x223c
      0067D9 E4               [12] 3096 	clr	a
      0067DA F0               [24] 3097 	movx	@dptr,a
                                   3098 ;	tmk_core/protocol/ch555/usb_ak820.c:478: raw_state = RAW_IDLE;
      0067DB 90 07 7B         [24] 3099 	mov	dptr,#_raw_state
      0067DE F0               [24] 3100 	movx	@dptr,a
                                   3101 ;	tmk_core/protocol/ch555/usb_ak820.c:479: endpoints_reset();
      0067DF 12 5B C6         [24] 3102 	lcall	_endpoints_reset
                                   3103 ;	tmk_core/protocol/ch555/usb_ak820.c:480: D0_ADDR = D0UsbConfig = USB_EnumStatus = USB_SleepStatus = 0;
      0067E2 90 07 75         [24] 3104 	mov	dptr,#_USB_SleepStatus
      0067E5 E4               [12] 3105 	clr	a
      0067E6 F0               [24] 3106 	movx	@dptr,a
      0067E7 90 07 74         [24] 3107 	mov	dptr,#_USB_EnumStatus
      0067EA F0               [24] 3108 	movx	@dptr,a
      0067EB 90 07 73         [24] 3109 	mov	dptr,#_D0UsbConfig
      0067EE F0               [24] 3110 	movx	@dptr,a
      0067EF 90 22 07         [24] 3111 	mov	dptr,#0x2207
      0067F2 F0               [24] 3112 	movx	@dptr,a
                                   3113 ;	tmk_core/protocol/ch555/usb_ak820.c:481: KB_USB_SetReport = KB_USB_UpStatus = MCU_Sleep_Operate = 0;
      0067F3 90 07 76         [24] 3114 	mov	dptr,#_MCU_Sleep_Operate
      0067F6 F0               [24] 3115 	movx	@dptr,a
      0067F7 90 07 77         [24] 3116 	mov	dptr,#_KB_USB_UpStatus
      0067FA F0               [24] 3117 	movx	@dptr,a
      0067FB 90 07 78         [24] 3118 	mov	dptr,#_KB_USB_SetReport
      0067FE F0               [24] 3119 	movx	@dptr,a
                                   3120 ;	tmk_core/protocol/ch555/usb_ak820.c:482: keyboard_protocol = 1;
      0067FF 90 0D BB         [24] 3121 	mov	dptr,#_keyboard_protocol
      006802 04               [12] 3122 	inc	a
      006803 F0               [24] 3123 	movx	@dptr,a
                                   3124 ;	tmk_core/protocol/ch555/usb_ak820.c:483: keyboard_idle = 0;
      006804 90 06 4B         [24] 3125 	mov	dptr,#_keyboard_idle
      006807 E4               [12] 3126 	clr	a
      006808 F0               [24] 3127 	movx	@dptr,a
                                   3128 ;	tmk_core/protocol/ch555/usb_ak820.c:484: keyboard_reset = 0;
      006809 90 07 9D         [24] 3129 	mov	dptr,#_keyboard_reset
      00680C F0               [24] 3130 	movx	@dptr,a
                                   3131 ;	tmk_core/protocol/ch555/usb_ak820.c:485: control_phase = CTRL_IDLE;
      00680D 90 07 CC         [24] 3132 	mov	dptr,#_control_phase
      006810 F0               [24] 3133 	movx	@dptr,a
                                   3134 ;	tmk_core/protocol/ch555/usb_ak820.c:486: D0SetupReqCode = 0xff;
      006811 90 07 6D         [24] 3135 	mov	dptr,#_D0SetupReqCode
      006814 14               [12] 3136 	dec	a
      006815 F0               [24] 3137 	movx	@dptr,a
                                   3138 ;	tmk_core/protocol/ch555/usb_ak820.c:487: D0SetupLen = 0;
      006816 90 07 6E         [24] 3139 	mov	dptr,#_D0SetupLen
      006819 E4               [12] 3140 	clr	a
      00681A F0               [24] 3141 	movx	@dptr,a
      00681B A3               [24] 3142 	inc	dptr
      00681C F0               [24] 3143 	movx	@dptr,a
                                   3144 ;	tmk_core/protocol/ch555/usb_ak820.c:488: D0_EP0RES = UEP_R_RES_ACK | UEP_T_RES_NAK;
      00681D 90 22 00         [24] 3145 	mov	dptr,#0x2200
      006820 74 02            [12] 3146 	mov	a,#0x02
      006822 F0               [24] 3147 	movx	@dptr,a
                                   3148 ;	tmk_core/protocol/ch555/usb_ak820.c:489: HB_ADDR = 0x7f;
      006823 90 22 37         [24] 3149 	mov	dptr,#0x2237
      006826 74 7F            [12] 3150 	mov	a,#0x7f
      006828 F0               [24] 3151 	movx	@dptr,a
                                   3152 ;	tmk_core/protocol/ch555/usb_ak820.c:490: ACK_ALL();
      006829 90 22 3D         [24] 3153 	mov	dptr,#0x223d
      00682C 74 FF            [12] 3154 	mov	a,#0xff
      00682E F0               [24] 3155 	movx	@dptr,a
                                   3156 ;	tmk_core/protocol/ch555/usb_ak820.c:491: USB_IE = bUX_IE_SUSPEND | bUX_IE_TRANSFER | bUX_IE_BUS_RST;
      00682F 90 22 3B         [24] 3157 	mov	dptr,#0x223b
      006832 74 07            [12] 3158 	mov	a,#0x07
      006834 F0               [24] 3159 	movx	@dptr,a
                                   3160 ;	tmk_core/protocol/ch555/usb_ak820.c:492: USB_CTRL = bUX_DP_PU_EN;
      006835 A3               [24] 3161 	inc	dptr
      006836 74 80            [12] 3162 	mov	a,#0x80
      006838 F0               [24] 3163 	movx	@dptr,a
                                   3164 ;	tmk_core/protocol/ch555/usb_ak820.c:493: IE_USB = 1;
                                   3165 ;	assignBit
      006839 D2 E9            [12] 3166 	setb	_IE_USB
                                   3167 ;	tmk_core/protocol/ch555/usb_ak820.c:494: }
      00683B 22               [24] 3168 	ret
                                   3169 ;------------------------------------------------------------
                                   3170 ;Allocation info for local variables in function 'USB_WakeUp_PC'
                                   3171 ;------------------------------------------------------------
                                   3172 ;saved         Allocated with name '_USB_WakeUp_PC_saved_10000_420'
                                   3173 ;i             Allocated with name '_USB_WakeUp_PC_i_30000_423'
                                   3174 ;------------------------------------------------------------
                                   3175 ;	tmk_core/protocol/ch555/usb_ak820.c:496: void USB_WakeUp_PC(void) {
                                   3176 ;	-----------------------------------------
                                   3177 ;	 function USB_WakeUp_PC
                                   3178 ;	-----------------------------------------
      00683C                       3179 _USB_WakeUp_PC:
                                   3180 ;	tmk_core/protocol/ch555/usb_ak820.c:498: if (USB_SleepStatus != 3) return;
      00683C 90 07 75         [24] 3181 	mov	dptr,#_USB_SleepStatus
      00683F E0               [24] 3182 	movx	a,@dptr
      006840 FF               [12] 3183 	mov	r7,a
      006841 BF 03 22         [24] 3184 	cjne	r7,#0x03,00110$
                                   3185 ;	tmk_core/protocol/ch555/usb_ak820.c:499: saved = USB_CTRL;
      006844 90 22 3C         [24] 3186 	mov	dptr,#0x223c
      006847 E0               [24] 3187 	movx	a,@dptr
      006848 FF               [12] 3188 	mov	r7,a
                                   3189 ;	tmk_core/protocol/ch555/usb_ak820.c:500: USB_CTRL ^= bUX_DP_PU_EN | bUX_DM_PU_EN;
      006849 E0               [24] 3190 	movx	a,@dptr
      00684A FE               [12] 3191 	mov	r6,a
      00684B 63 06 C0         [24] 3192 	xrl	ar6,#0xc0
      00684E 90 22 3C         [24] 3193 	mov	dptr,#0x223c
      006851 EE               [12] 3194 	mov	a,r6
      006852 F0               [24] 3195 	movx	@dptr,a
                                   3196 ;	tmk_core/protocol/ch555/usb_ak820.c:501: wait_ms(10);
      006853 7E 0A            [12] 3197 	mov	r6,#0x0a
      006855                       3198 00108$:
      006855 EE               [12] 3199 	mov	a,r6
      006856 60 09            [24] 3200 	jz	00105$
      006858 90 00 01         [24] 3201 	mov	dptr,#0x0001
      00685B 12 5A 0D         [24] 3202 	lcall	_mDelaymS
      00685E 1E               [12] 3203 	dec	r6
      00685F 80 F4            [24] 3204 	sjmp	00108$
      006861                       3205 00105$:
                                   3206 ;	tmk_core/protocol/ch555/usb_ak820.c:502: USB_CTRL = saved;
      006861 90 22 3C         [24] 3207 	mov	dptr,#0x223c
      006864 EF               [12] 3208 	mov	a,r7
      006865 F0               [24] 3209 	movx	@dptr,a
      006866                       3210 00110$:
                                   3211 ;	tmk_core/protocol/ch555/usb_ak820.c:503: }
      006866 22               [24] 3212 	ret
                                   3213 ;------------------------------------------------------------
                                   3214 ;Allocation info for local variables in function 'ak820_usb_send'
                                   3215 ;------------------------------------------------------------
                                   3216 ;sloc0         Allocated with name '_ak820_usb_send_sloc0_1_0'
                                   3217 ;sloc1         Allocated with name '_ak820_usb_send_sloc1_1_0'
                                   3218 ;report        Allocated with name '_ak820_usb_send_PARM_2'
                                   3219 ;length        Allocated with name '_ak820_usb_send_PARM_3'
                                   3220 ;endpoint      Allocated with name '_ak820_usb_send_endpoint_10000_425'
                                   3221 ;saved_ea      Allocated with name '_ak820_usb_send_saved_ea_10000_426'
                                   3222 ;i             Allocated with name '_ak820_usb_send_i_10000_426'
                                   3223 ;timeout       Allocated with name '_ak820_usb_send_timeout_10000_426'
                                   3224 ;offset        Allocated with name '_ak820_usb_send_offset_10000_426'
                                   3225 ;report_id     Allocated with name '_ak820_usb_send_report_id_10000_426'
                                   3226 ;i             Allocated with name '_ak820_usb_send_i_30000_438'
                                   3227 ;------------------------------------------------------------
                                   3228 ;	tmk_core/protocol/ch555/usb_ak820.c:505: bool ak820_usb_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3229 ;	-----------------------------------------
                                   3230 ;	 function ak820_usb_send
                                   3231 ;	-----------------------------------------
      006867                       3232 _ak820_usb_send:
      006867 E5 82            [12] 3233 	mov	a,dpl
      006869 90 07 DC         [24] 3234 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      00686C F0               [24] 3235 	movx	@dptr,a
                                   3236 ;	tmk_core/protocol/ch555/usb_ak820.c:509: uint8_t offset = SNAPSHOT_SIZE;
      00686D 90 07 DD         [24] 3237 	mov	dptr,#_ak820_usb_send_offset_10000_426
      006870 74 2E            [12] 3238 	mov	a,#0x2e
      006872 F0               [24] 3239 	movx	@dptr,a
                                   3240 ;	tmk_core/protocol/ch555/usb_ak820.c:511: if (endpoint < 1 || endpoint > 3 || length > 64 || !USB_EnumStatus) return false;
      006873 90 07 DC         [24] 3241 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      006876 E0               [24] 3242 	movx	a,@dptr
      006877 FF               [12] 3243 	mov	r7,a
      006878 BF 01 00         [24] 3244 	cjne	r7,#0x01,00306$
      00687B                       3245 00306$:
      00687B 40 14            [24] 3246 	jc	00101$
      00687D EF               [12] 3247 	mov	a,r7
      00687E 24 FC            [12] 3248 	add	a,#0xff - 0x03
      006880 40 0F            [24] 3249 	jc	00101$
                                   3250 ;	free result
      006882 90 07 DB         [24] 3251 	mov	dptr,#_ak820_usb_send_PARM_3
      006885 E0               [24] 3252 	movx	a,@dptr
      006886 FE               [12] 3253 	mov  r6,a
      006887 24 BF            [12] 3254 	add	a,#0xff - 0x40
      006889 40 06            [24] 3255 	jc	00101$
                                   3256 ;	free result
      00688B 90 07 74         [24] 3257 	mov	dptr,#_USB_EnumStatus
      00688E E0               [24] 3258 	movx	a,@dptr
      00688F 70 04            [24] 3259 	jnz	00102$
      006891                       3260 00101$:
      006891 75 82 00         [24] 3261 	mov	dpl, #0x00
      006894 22               [24] 3262 	ret
      006895                       3263 00102$:
                                   3264 ;	tmk_core/protocol/ch555/usb_ak820.c:512: if (endpoint == KEYBOARD_IN_EPNUM) {
      006895 BF 01 10         [24] 3265 	cjne	r7,#0x01,00118$
                                   3266 ;	tmk_core/protocol/ch555/usb_ak820.c:513: if (length != KEYBOARD_EPSIZE) return false;
      006898 BE 08 02         [24] 3267 	cjne	r6,#0x08,00313$
      00689B 80 04            [24] 3268 	sjmp	00107$
      00689D                       3269 00313$:
      00689D 75 82 00         [24] 3270 	mov	dpl, #0x00
      0068A0 22               [24] 3271 	ret
      0068A1                       3272 00107$:
                                   3273 ;	tmk_core/protocol/ch555/usb_ak820.c:514: offset = SNAPSHOT_KEYBOARD;
      0068A1 90 07 DD         [24] 3274 	mov	dptr,#_ak820_usb_send_offset_10000_426
      0068A4 E4               [12] 3275 	clr	a
      0068A5 F0               [24] 3276 	movx	@dptr,a
      0068A6 80 3C            [24] 3277 	sjmp	00119$
      0068A8                       3278 00118$:
                                   3279 ;	tmk_core/protocol/ch555/usb_ak820.c:515: } else if (endpoint == SHARED_IN_EPNUM) {
      0068A8 BF 02 30         [24] 3280 	cjne	r7,#0x02,00115$
                                   3281 ;	tmk_core/protocol/ch555/usb_ak820.c:516: report_id = report[0];
      0068AB 90 07 D9         [24] 3282 	mov	dptr,#_ak820_usb_send_PARM_2
      0068AE E0               [24] 3283 	movx	a,@dptr
      0068AF FD               [12] 3284 	mov	r5,a
      0068B0 A3               [24] 3285 	inc	dptr
      0068B1 E0               [24] 3286 	movx	a,@dptr
      0068B2 FF               [12] 3287 	mov	r7,a
      0068B3 8D 82            [24] 3288 	mov	dpl,r5
      0068B5 8F 83            [24] 3289 	mov	dph,r7
      0068B7 E0               [24] 3290 	movx	a,@dptr
      0068B8 FF               [12] 3291 	mov	r7,a
                                   3292 ;	tmk_core/protocol/ch555/usb_ak820.c:517: if (report_id >= sizeof(shared_lengths) || !shared_lengths[report_id] || length != shared_lengths[report_id]) return false;
      0068B9 BF 07 00         [24] 3293 	cjne	r7,#0x07,00316$
      0068BC                       3294 00316$:
      0068BC 50 0E            [24] 3295 	jnc	00108$
      0068BE EF               [12] 3296 	mov	a,r7
      0068BF 90 BC 1D         [24] 3297 	mov	dptr,#_shared_lengths
      0068C2 93               [24] 3298 	movc	a,@a+dptr
      0068C3 FD               [12] 3299 	mov	r5,a
      0068C4 60 06            [24] 3300 	jz	00108$
      0068C6 EE               [12] 3301 	mov	a,r6
      0068C7 B5 05 02         [24] 3302 	cjne	a,ar5,00319$
      0068CA 80 04            [24] 3303 	sjmp	00109$
      0068CC                       3304 00319$:
      0068CC                       3305 00108$:
      0068CC 75 82 00         [24] 3306 	mov	dpl, #0x00
      0068CF 22               [24] 3307 	ret
      0068D0                       3308 00109$:
                                   3309 ;	tmk_core/protocol/ch555/usb_ak820.c:518: offset = shared_offsets[report_id];
      0068D0 EF               [12] 3310 	mov	a,r7
      0068D1 90 BC 16         [24] 3311 	mov	dptr,#_shared_offsets
      0068D4 93               [24] 3312 	movc	a,@a+dptr
      0068D5 90 07 DD         [24] 3313 	mov	dptr,#_ak820_usb_send_offset_10000_426
      0068D8 F0               [24] 3314 	movx	@dptr,a
      0068D9 80 09            [24] 3315 	sjmp	00119$
      0068DB                       3316 00115$:
                                   3317 ;	tmk_core/protocol/ch555/usb_ak820.c:519: } else if (length != RAW_EPSIZE) return false;
      0068DB BE 20 02         [24] 3318 	cjne	r6,#0x20,00320$
      0068DE 80 04            [24] 3319 	sjmp	00119$
      0068E0                       3320 00320$:
      0068E0 75 82 00         [24] 3321 	mov	dpl, #0x00
      0068E3 22               [24] 3322 	ret
      0068E4                       3323 00119$:
                                   3324 ;	tmk_core/protocol/ch555/usb_ak820.c:520: if (USB_SleepStatus & 2) { USB_WakeUp_PC(); return false; }
      0068E4 90 07 75         [24] 3325 	mov	dptr,#_USB_SleepStatus
      0068E7 E0               [24] 3326 	movx	a,@dptr
      0068E8 30 E1 07         [24] 3327 	jnb	acc.1,00184$
      0068EB 12 68 3C         [24] 3328 	lcall	_USB_WakeUp_PC
      0068EE 75 82 00         [24] 3329 	mov	dpl, #0x00
      0068F1 22               [24] 3330 	ret
                                   3331 ;	tmk_core/protocol/ch555/usb_ak820.c:521: while ((EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_ACK && timeout--) wait_us(40);
      0068F2                       3332 00184$:
      0068F2 7F FA            [12] 3333 	mov	r7,#0xfa
      0068F4                       3334 00127$:
      0068F4 90 07 DC         [24] 3335 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      0068F7 E0               [24] 3336 	movx	a,@dptr
      0068F8 FC               [12] 3337 	mov	r4,a
      0068F9 7D 00            [12] 3338 	mov	r5,#0x00
      0068FB 8C 02            [24] 3339 	mov	ar2,r4
      0068FD 74 22            [12] 3340 	mov	a,#0x22
      0068FF 2D               [12] 3341 	add	a, r5
      006900 FB               [12] 3342 	mov	r3,a
      006901 8A 82            [24] 3343 	mov	dpl,r2
      006903 8B 83            [24] 3344 	mov	dph,r3
      006905 E0               [24] 3345 	movx	a,@dptr
      006906 54 03            [12] 3346 	anl	a,#0x03
      006908 70 14            [24] 3347 	jnz	00129$
      00690A 8F 03            [24] 3348 	mov	ar3,r7
      00690C 1F               [12] 3349 	dec	r7
      00690D EB               [12] 3350 	mov	a,r3
      00690E 60 0E            [24] 3351 	jz	00129$
      006910 7B 28            [12] 3352 	mov	r3,#0x28
      006912                       3353 00141$:
      006912 EB               [12] 3354 	mov	a,r3
      006913 60 DF            [24] 3355 	jz	00127$
      006915 90 00 01         [24] 3356 	mov	dptr,#0x0001
      006918 12 59 C9         [24] 3357 	lcall	_mDelayuS
      00691B 1B               [12] 3358 	dec	r3
      00691C 80 F4            [24] 3359 	sjmp	00141$
      00691E                       3360 00129$:
                                   3361 ;	tmk_core/protocol/ch555/usb_ak820.c:522: saved_ea = EA;
      00691E A2 AF            [12] 3362 	mov	c,_EA
      006920 E4               [12] 3363 	clr	a
      006921 33               [12] 3364 	rlc	a
      006922 FF               [12] 3365 	mov	r7,a
                                   3366 ;	tmk_core/protocol/ch555/usb_ak820.c:523: EA = 0;
                                   3367 ;	assignBit
      006923 C2 AF            [12] 3368 	clr	_EA
                                   3369 ;	tmk_core/protocol/ch555/usb_ak820.c:524: if (!USB_EnumStatus || (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) != UEP_X_RES_NAK ||
      006925 90 07 74         [24] 3370 	mov	dptr,#_USB_EnumStatus
      006928 E0               [24] 3371 	movx	a,@dptr
      006929 60 25            [24] 3372 	jz	00130$
      00692B 90 07 DC         [24] 3373 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      00692E E0               [24] 3374 	movx	a,@dptr
      00692F FB               [12] 3375 	mov	r3,a
      006930 F9               [12] 3376 	mov	r1,a
      006931 7A 00            [12] 3377 	mov	r2,#0x00
      006933 74 22            [12] 3378 	mov	a,#0x22
      006935 2A               [12] 3379 	add	a, r2
      006936 FA               [12] 3380 	mov	r2,a
      006937 89 82            [24] 3381 	mov	dpl,r1
      006939 8A 83            [24] 3382 	mov	dph,r2
      00693B E0               [24] 3383 	movx	a,@dptr
      00693C FA               [12] 3384 	mov	r2,a
      00693D 53 02 03         [24] 3385 	anl	ar2,#0x03
      006940 BA 02 0D         [24] 3386 	cjne	r2,#0x02,00130$
                                   3387 ;	tmk_core/protocol/ch555/usb_ak820.c:525: (endpoint == RAW_IN_EPNUM && raw_state != RAW_WORK)) { EA = saved_ea; return false; }
      006943 BB 03 13         [24] 3388 	cjne	r3,#0x03,00192$
      006946 90 07 7B         [24] 3389 	mov	dptr,#_raw_state
      006949 E0               [24] 3390 	movx	a,@dptr
      00694A FB               [12] 3391 	mov	r3,a
      00694B BB 03 02         [24] 3392 	cjne	r3,#0x03,00331$
      00694E 80 09            [24] 3393 	sjmp	00192$
      006950                       3394 00331$:
      006950                       3395 00130$:
                                   3396 ;	assignBit
      006950 EF               [12] 3397 	mov	a,r7
      006951 24 FF            [12] 3398 	add	a,#0xff
      006953 92 AF            [24] 3399 	mov	_EA,c
      006955 75 82 00         [24] 3400 	mov	dpl, #0x00
      006958 22               [24] 3401 	ret
                                   3402 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      006959                       3403 00192$:
      006959 7B 00            [12] 3404 	mov	r3,#0x00
      00695B                       3405 00144$:
      00695B C3               [12] 3406 	clr	c
      00695C EB               [12] 3407 	mov	a,r3
      00695D 9E               [12] 3408 	subb	a,r6
      00695E 50 67            [24] 3409 	jnc	00137$
                                   3410 ;	tmk_core/protocol/ch555/usb_ak820.c:527: pUSB_BUF_DEV0[((uint16_t)endpoint << 6) + i] = report[i];
      006960 C0 07            [24] 3411 	push	ar7
      006962 90 07 DC         [24] 3412 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      006965 E0               [24] 3413 	movx	a,@dptr
      006966 F9               [12] 3414 	mov	r1,a
      006967 E4               [12] 3415 	clr	a
      006968 C3               [12] 3416 	clr	c
      006969 C9               [12] 3417 	xch	a,r1
      00696A 13               [12] 3418 	rrc	a
      00696B C9               [12] 3419 	xch	a,r1
      00696C 13               [12] 3420 	rrc	a
      00696D A2 E0            [12] 3421 	mov	c,acc.0
      00696F C9               [12] 3422 	xch	a,r1
      006970 13               [12] 3423 	rrc	a
      006971 C9               [12] 3424 	xch	a,r1
      006972 13               [12] 3425 	rrc	a
      006973 C9               [12] 3426 	xch	a,r1
      006974 FA               [12] 3427 	mov	r2,a
      006975 8B 00            [24] 3428 	mov	ar0,r3
      006977 7F 00            [12] 3429 	mov	r7,#0x00
      006979 E8               [12] 3430 	mov	a,r0
      00697A 29               [12] 3431 	add	a, r1
      00697B F9               [12] 3432 	mov	r1,a
      00697C EF               [12] 3433 	mov	a,r7
      00697D 3A               [12] 3434 	addc	a, r2
      00697E 24 10            [12] 3435 	add	a,#0x10
      006980 FA               [12] 3436 	mov	r2,a
      006981 90 07 D9         [24] 3437 	mov	dptr,#_ak820_usb_send_PARM_2
      006984 E0               [24] 3438 	movx	a,@dptr
      006985 F8               [12] 3439 	mov	r0,a
      006986 A3               [24] 3440 	inc	dptr
      006987 E0               [24] 3441 	movx	a,@dptr
      006988 FF               [12] 3442 	mov	r7,a
      006989 EB               [12] 3443 	mov	a,r3
      00698A 28               [12] 3444 	add	a, r0
      00698B F5 1B            [12] 3445 	mov	_ak820_usb_send_sloc0_1_0,a
      00698D E4               [12] 3446 	clr	a
      00698E 3F               [12] 3447 	addc	a, r7
      00698F F5 1C            [12] 3448 	mov	(_ak820_usb_send_sloc0_1_0 + 1),a
      006991 85 1B 82         [24] 3449 	mov	dpl,_ak820_usb_send_sloc0_1_0
      006994 85 1C 83         [24] 3450 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      006997 E0               [24] 3451 	movx	a,@dptr
      006998 89 82            [24] 3452 	mov	dpl,r1
      00699A 8A 83            [24] 3453 	mov	dph,r2
      00699C F0               [24] 3454 	movx	@dptr,a
                                   3455 ;	tmk_core/protocol/ch555/usb_ak820.c:528: if (offset != SNAPSHOT_SIZE) input_snapshot[offset + i] = report[i];
      00699D 90 07 DD         [24] 3456 	mov	dptr,#_ak820_usb_send_offset_10000_426
      0069A0 E0               [24] 3457 	movx	a,@dptr
      0069A1 F5 1D            [12] 3458 	mov	_ak820_usb_send_sloc1_1_0,a
      0069A3 74 2E            [12] 3459 	mov	a,#0x2e
      0069A5 B5 1D 04         [24] 3460 	cjne	a,_ak820_usb_send_sloc1_1_0,00333$
      0069A8 D0 07            [24] 3461 	pop	ar7
      0069AA 80 18            [24] 3462 	sjmp	00145$
      0069AC                       3463 00333$:
      0069AC D0 07            [24] 3464 	pop	ar7
      0069AE EB               [12] 3465 	mov	a,r3
      0069AF 25 1D            [12] 3466 	add	a, _ak820_usb_send_sloc1_1_0
      0069B1 24 9E            [12] 3467 	add	a, #_input_snapshot
      0069B3 F9               [12] 3468 	mov	r1,a
      0069B4 E4               [12] 3469 	clr	a
      0069B5 34 07            [12] 3470 	addc	a,#(_input_snapshot >> 8)
      0069B7 FA               [12] 3471 	mov	r2,a
      0069B8 85 1B 82         [24] 3472 	mov	dpl,_ak820_usb_send_sloc0_1_0
      0069BB 85 1C 83         [24] 3473 	mov	dph,(_ak820_usb_send_sloc0_1_0 + 1)
      0069BE E0               [24] 3474 	movx	a,@dptr
      0069BF 89 82            [24] 3475 	mov	dpl,r1
      0069C1 8A 83            [24] 3476 	mov	dph,r2
      0069C3 F0               [24] 3477 	movx	@dptr,a
      0069C4                       3478 00145$:
                                   3479 ;	tmk_core/protocol/ch555/usb_ak820.c:526: for (i = 0; i < length; ++i) {
      0069C4 0B               [12] 3480 	inc	r3
      0069C5 80 94            [24] 3481 	sjmp	00144$
      0069C7                       3482 00137$:
                                   3483 ;	tmk_core/protocol/ch555/usb_ak820.c:530: EP_LENGTH(endpoint) = length;
      0069C7 90 07 DC         [24] 3484 	mov	dptr,#_ak820_usb_send_endpoint_10000_425
      0069CA E0               [24] 3485 	movx	a,@dptr
      0069CB FB               [12] 3486 	mov	r3,a
      0069CC F9               [12] 3487 	mov	r1,a
      0069CD 7A 00            [12] 3488 	mov	r2,#0x00
      0069CF 74 08            [12] 3489 	mov	a,#0x08
      0069D1 29               [12] 3490 	add	a, r1
      0069D2 F9               [12] 3491 	mov	r1,a
      0069D3 74 22            [12] 3492 	mov	a,#0x22
      0069D5 3A               [12] 3493 	addc	a, r2
      0069D6 FA               [12] 3494 	mov	r2,a
      0069D7 89 82            [24] 3495 	mov	dpl,r1
      0069D9 8A 83            [24] 3496 	mov	dph,r2
      0069DB EE               [12] 3497 	mov	a,r6
      0069DC F0               [24] 3498 	movx	@dptr,a
                                   3499 ;	tmk_core/protocol/ch555/usb_ak820.c:531: if (endpoint == RAW_IN_EPNUM) raw_state = RAW_TX_ACTIVE;
      0069DD BB 03 06         [24] 3500 	cjne	r3,#0x03,00139$
      0069E0 90 07 7B         [24] 3501 	mov	dptr,#_raw_state
      0069E3 74 04            [12] 3502 	mov	a,#0x04
      0069E5 F0               [24] 3503 	movx	@dptr,a
      0069E6                       3504 00139$:
                                   3505 ;	tmk_core/protocol/ch555/usb_ak820.c:532: EP_RESPONSE(endpoint) = (EP_RESPONSE(endpoint) & ~MASK_UEP_X_RES) | UEP_X_RES_ACK;
      0069E6 74 22            [12] 3506 	mov	a,#0x22
      0069E8 2D               [12] 3507 	add	a, r5
      0069E9 FD               [12] 3508 	mov	r5,a
      0069EA 8C 82            [24] 3509 	mov	dpl,r4
      0069EC 8D 83            [24] 3510 	mov	dph,r5
      0069EE E0               [24] 3511 	movx	a,@dptr
      0069EF FE               [12] 3512 	mov	r6,a
      0069F0 53 06 FC         [24] 3513 	anl	ar6,#0xfc
      0069F3 8C 82            [24] 3514 	mov	dpl,r4
      0069F5 8D 83            [24] 3515 	mov	dph,r5
      0069F7 EE               [12] 3516 	mov	a,r6
      0069F8 F0               [24] 3517 	movx	@dptr,a
                                   3518 ;	tmk_core/protocol/ch555/usb_ak820.c:533: EA = saved_ea;
                                   3519 ;	assignBit
      0069F9 EF               [12] 3520 	mov	a,r7
      0069FA 24 FF            [12] 3521 	add	a,#0xff
      0069FC 92 AF            [24] 3522 	mov	_EA,c
                                   3523 ;	tmk_core/protocol/ch555/usb_ak820.c:534: return true;
      0069FE 75 82 01         [24] 3524 	mov	dpl, #0x01
                                   3525 ;	tmk_core/protocol/ch555/usb_ak820.c:535: }
      006A01 22               [24] 3526 	ret
                                   3527 ;------------------------------------------------------------
                                   3528 ;Allocation info for local variables in function 'ak820_usb_try_send'
                                   3529 ;------------------------------------------------------------
                                   3530 ;report        Allocated with name '_ak820_usb_try_send_PARM_2'
                                   3531 ;length        Allocated with name '_ak820_usb_try_send_PARM_3'
                                   3532 ;endpoint      Allocated with name '_ak820_usb_try_send_endpoint_10000_446'
                                   3533 ;saved_ea      Allocated with name '_ak820_usb_try_send_saved_ea_10000_447'
                                   3534 ;sent          Allocated with name '_ak820_usb_try_send_sent_10000_447'
                                   3535 ;------------------------------------------------------------
                                   3536 ;	tmk_core/protocol/ch555/usb_ak820.c:537: bool ak820_usb_try_send(uint8_t endpoint, const uint8_t __xdata *report, uint8_t length) {
                                   3537 ;	-----------------------------------------
                                   3538 ;	 function ak820_usb_try_send
                                   3539 ;	-----------------------------------------
      006A02                       3540 _ak820_usb_try_send:
      006A02 E5 82            [12] 3541 	mov	a,dpl
      006A04 90 07 E1         [24] 3542 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_446
      006A07 F0               [24] 3543 	movx	@dptr,a
                                   3544 ;	tmk_core/protocol/ch555/usb_ak820.c:538: uint8_t saved_ea = EA;
                                   3545 ;	assignBit
      006A08 A2 AF            [12] 3546 	mov	c,_EA
      006A0A 92 1C            [24] 3547 	mov	_ak820_usb_try_send_sloc0_1_0,c
                                   3548 ;	tmk_core/protocol/ch555/usb_ak820.c:539: bool sent = false;
      006A0C 90 07 E2         [24] 3549 	mov	dptr,#_ak820_usb_try_send_sent_10000_447
      006A0F E4               [12] 3550 	clr	a
      006A10 F0               [24] 3551 	movx	@dptr,a
                                   3552 ;	tmk_core/protocol/ch555/usb_ak820.c:540: EA = 0;
                                   3553 ;	assignBit
      006A11 C2 AF            [12] 3554 	clr	_EA
                                   3555 ;	tmk_core/protocol/ch555/usb_ak820.c:544: if (endpoint >= 1 && endpoint <= 2 && USB_EnumStatus &&
      006A13 90 07 E1         [24] 3556 	mov	dptr,#_ak820_usb_try_send_endpoint_10000_446
      006A16 E0               [24] 3557 	movx	a,@dptr
      006A17 FF               [12] 3558 	mov	r7,a
      006A18 BF 01 00         [24] 3559 	cjne	r7,#0x01,00152$
      006A1B                       3560 00152$:
      006A1B 40 4E            [24] 3561 	jc	00102$
      006A1D EF               [12] 3562 	mov	a,r7
      006A1E 24 FD            [12] 3563 	add	a,#0xff - 0x02
      006A20 40 49            [24] 3564 	jc	00102$
                                   3565 ;	free result
      006A22 90 07 74         [24] 3566 	mov	dptr,#_USB_EnumStatus
      006A25 E0               [24] 3567 	movx	a,@dptr
      006A26 60 43            [24] 3568 	jz	00102$
                                   3569 ;	tmk_core/protocol/ch555/usb_ak820.c:545: !(USB_SleepStatus & 2) && !keyboard_reset &&
      006A28 90 07 75         [24] 3570 	mov	dptr,#_USB_SleepStatus
      006A2B E0               [24] 3571 	movx	a,@dptr
      006A2C 20 E1 3C         [24] 3572 	jb	acc.1,00102$
      006A2F 90 07 9D         [24] 3573 	mov	dptr,#_keyboard_reset
      006A32 E0               [24] 3574 	movx	a,@dptr
                                   3575 ;	tmk_core/protocol/ch555/usb_ak820.c:546: (EP_RESPONSE(endpoint) & MASK_UEP_X_RES) == UEP_X_RES_NAK) {
      006A33 70 36            [24] 3576 	jnz	00102$
      006A35 8F 06            [24] 3577 	mov	ar6,r7
      006A37 24 22            [12] 3578 	add	a,#0x22
      006A39 FD               [12] 3579 	mov	r5,a
      006A3A 8E 82            [24] 3580 	mov	dpl,r6
      006A3C 8D 83            [24] 3581 	mov	dph,r5
      006A3E E0               [24] 3582 	movx	a,@dptr
      006A3F FE               [12] 3583 	mov	r6,a
      006A40 53 06 03         [24] 3584 	anl	ar6,#0x03
      006A43 BE 02 25         [24] 3585 	cjne	r6,#0x02,00102$
                                   3586 ;	tmk_core/protocol/ch555/usb_ak820.c:547: sent = ak820_usb_send(endpoint, report, length);
      006A46 90 07 DE         [24] 3587 	mov	dptr,#_ak820_usb_try_send_PARM_2
      006A49 E0               [24] 3588 	movx	a,@dptr
      006A4A FD               [12] 3589 	mov	r5,a
      006A4B A3               [24] 3590 	inc	dptr
      006A4C E0               [24] 3591 	movx	a,@dptr
      006A4D FE               [12] 3592 	mov	r6,a
      006A4E 90 07 E0         [24] 3593 	mov	dptr,#_ak820_usb_try_send_PARM_3
      006A51 E0               [24] 3594 	movx	a,@dptr
      006A52 FC               [12] 3595 	mov	r4,a
      006A53 90 07 D9         [24] 3596 	mov	dptr,#_ak820_usb_send_PARM_2
      006A56 ED               [12] 3597 	mov	a,r5
      006A57 F0               [24] 3598 	movx	@dptr,a
      006A58 EE               [12] 3599 	mov	a,r6
      006A59 A3               [24] 3600 	inc	dptr
      006A5A F0               [24] 3601 	movx	@dptr,a
      006A5B 90 07 DB         [24] 3602 	mov	dptr,#_ak820_usb_send_PARM_3
      006A5E EC               [12] 3603 	mov	a,r4
      006A5F F0               [24] 3604 	movx	@dptr,a
      006A60 8F 82            [24] 3605 	mov	dpl, r7
      006A62 12 68 67         [24] 3606 	lcall	_ak820_usb_send
      006A65 E5 82            [12] 3607 	mov	a, dpl
      006A67 90 07 E2         [24] 3608 	mov	dptr,#_ak820_usb_try_send_sent_10000_447
      006A6A F0               [24] 3609 	movx	@dptr,a
      006A6B                       3610 00102$:
                                   3611 ;	tmk_core/protocol/ch555/usb_ak820.c:549: EA = saved_ea;
                                   3612 ;	assignBit
      006A6B A2 1C            [12] 3613 	mov	c,_ak820_usb_try_send_sloc0_1_0
      006A6D 92 AF            [24] 3614 	mov	_EA,c
                                   3615 ;	tmk_core/protocol/ch555/usb_ak820.c:550: return sent;
      006A6F 90 07 E2         [24] 3616 	mov	dptr,#_ak820_usb_try_send_sent_10000_447
      006A72 E0               [24] 3617 	movx	a,@dptr
                                   3618 ;	tmk_core/protocol/ch555/usb_ak820.c:551: }
      006A73 F5 82            [12] 3619 	mov	dpl,a
      006A75 22               [24] 3620 	ret
                                   3621 ;------------------------------------------------------------
                                   3622 ;Allocation info for local variables in function 'raw_request_is_nonpersistent'
                                   3623 ;------------------------------------------------------------
                                   3624 ;	tmk_core/protocol/ch555/usb_ak820.c:556: static bool raw_request_is_nonpersistent(void) {
                                   3625 ;	-----------------------------------------
                                   3626 ;	 function raw_request_is_nonpersistent
                                   3627 ;	-----------------------------------------
      006A76                       3628 _raw_request_is_nonpersistent:
                                   3629 ;	tmk_core/protocol/ch555/usb_ak820.c:557: switch (raw_buffer[0]) {
      006A76 90 07 7C         [24] 3630 	mov	dptr,#_raw_buffer
      006A79 E0               [24] 3631 	movx	a,@dptr
      006A7A FF               [12] 3632 	mov	r7,a
      006A7B BF 01 02         [24] 3633 	cjne	r7,#0x01,00302$
      006A7E 80 35            [24] 3634 	sjmp	00108$
      006A80                       3635 00302$:
      006A80 BF 02 02         [24] 3636 	cjne	r7,#0x02,00303$
      006A83 80 34            [24] 3637 	sjmp	00109$
      006A85                       3638 00303$:
      006A85 BF 04 02         [24] 3639 	cjne	r7,#0x04,00304$
      006A88 80 2B            [24] 3640 	sjmp	00108$
      006A8A                       3641 00304$:
      006A8A BF 08 02         [24] 3642 	cjne	r7,#0x08,00305$
      006A8D 80 47            [24] 3643 	sjmp	00116$
      006A8F                       3644 00305$:
      006A8F BF 0B 02         [24] 3645 	cjne	r7,#0x0b,00306$
      006A92 80 21            [24] 3646 	sjmp	00108$
      006A94                       3647 00306$:
      006A94 BF 0C 02         [24] 3648 	cjne	r7,#0x0c,00307$
      006A97 80 1C            [24] 3649 	sjmp	00108$
      006A99                       3650 00307$:
      006A99 BF 0D 02         [24] 3651 	cjne	r7,#0x0d,00308$
      006A9C 80 17            [24] 3652 	sjmp	00108$
      006A9E                       3653 00308$:
      006A9E BF 0E 02         [24] 3654 	cjne	r7,#0x0e,00309$
      006AA1 80 12            [24] 3655 	sjmp	00108$
      006AA3                       3656 00309$:
      006AA3 BF 11 02         [24] 3657 	cjne	r7,#0x11,00310$
      006AA6 80 0D            [24] 3658 	sjmp	00108$
      006AA8                       3659 00310$:
      006AA8 BF 12 02         [24] 3660 	cjne	r7,#0x12,00311$
      006AAB 80 08            [24] 3661 	sjmp	00108$
      006AAD                       3662 00311$:
      006AAD BF FE 02         [24] 3663 	cjne	r7,#0xfe,00312$
      006AB0 80 46            [24] 3664 	sjmp	00124$
      006AB2                       3665 00312$:
      006AB2 02 6B 4D         [24] 3666 	ljmp	00144$
                                   3667 ;	tmk_core/protocol/ch555/usb_ak820.c:565: case id_bootloader_jump:
      006AB5                       3668 00108$:
                                   3669 ;	tmk_core/protocol/ch555/usb_ak820.c:566: return true;
      006AB5 75 82 01         [24] 3670 	mov	dpl, #0x01
      006AB8 22               [24] 3671 	ret
                                   3672 ;	tmk_core/protocol/ch555/usb_ak820.c:567: case id_get_keyboard_value:
      006AB9                       3673 00109$:
                                   3674 ;	tmk_core/protocol/ch555/usb_ak820.c:568: switch (raw_buffer[1]) {
      006AB9 12 6E 5C         [24] 3675 	lcall	_ak820_outline_0164
      006ABC BF 01 02         [24] 3676 	cjne	r7,#0x01,00313$
      006ABF 80 0D            [24] 3677 	sjmp	00113$
      006AC1                       3678 00313$:
      006AC1 BF 02 02         [24] 3679 	cjne	r7,#0x02,00314$
      006AC4 80 08            [24] 3680 	sjmp	00113$
      006AC6                       3681 00314$:
      006AC6 BF 03 02         [24] 3682 	cjne	r7,#0x03,00315$
      006AC9 80 03            [24] 3683 	sjmp	00113$
      006ACB                       3684 00315$:
      006ACB BF 04 04         [24] 3685 	cjne	r7,#0x04,00114$
                                   3686 ;	tmk_core/protocol/ch555/usb_ak820.c:572: case id_firmware_version:
      006ACE                       3687 00113$:
                                   3688 ;	tmk_core/protocol/ch555/usb_ak820.c:573: return true;
      006ACE 75 82 01         [24] 3689 	mov	dpl, #0x01
      006AD1 22               [24] 3690 	ret
                                   3691 ;	tmk_core/protocol/ch555/usb_ak820.c:574: default: return false;
      006AD2                       3692 00114$:
      006AD2 75 82 00         [24] 3693 	mov	dpl, #0x00
      006AD5 22               [24] 3694 	ret
                                   3695 ;	tmk_core/protocol/ch555/usb_ak820.c:576: case id_lighting_get_value:
      006AD6                       3696 00116$:
                                   3697 ;	tmk_core/protocol/ch555/usb_ak820.c:577: switch (raw_buffer[1]) {
      006AD6 12 6E 5C         [24] 3698 	lcall	_ak820_outline_0164
      006AD9 BF 40 02         [24] 3699 	cjne	r7,#0x40,00318$
      006ADC 80 12            [24] 3700 	sjmp	00121$
      006ADE                       3701 00318$:
      006ADE BF 41 02         [24] 3702 	cjne	r7,#0x41,00319$
      006AE1 80 0D            [24] 3703 	sjmp	00121$
      006AE3                       3704 00319$:
      006AE3 BF 42 02         [24] 3705 	cjne	r7,#0x42,00320$
      006AE6 80 08            [24] 3706 	sjmp	00121$
      006AE8                       3707 00320$:
      006AE8 BF 43 02         [24] 3708 	cjne	r7,#0x43,00321$
      006AEB 80 03            [24] 3709 	sjmp	00121$
      006AED                       3710 00321$:
      006AED BF 44 04         [24] 3711 	cjne	r7,#0x44,00122$
                                   3712 ;	tmk_core/protocol/ch555/usb_ak820.c:582: case vialrgb_get_led_info:
      006AF0                       3713 00121$:
                                   3714 ;	tmk_core/protocol/ch555/usb_ak820.c:583: return true;
      006AF0 75 82 01         [24] 3715 	mov	dpl, #0x01
                                   3716 ;	tmk_core/protocol/ch555/usb_ak820.c:584: default: return false;
      006AF3 22               [24] 3717 	ret
      006AF4                       3718 00122$:
      006AF4 75 82 00         [24] 3719 	mov	dpl, #0x00
                                   3720 ;	tmk_core/protocol/ch555/usb_ak820.c:586: case id_vial_prefix:
      006AF7 22               [24] 3721 	ret
      006AF8                       3722 00124$:
                                   3723 ;	tmk_core/protocol/ch555/usb_ak820.c:587: switch (raw_buffer[1]) {
      006AF8 12 6E 5C         [24] 3724 	lcall	_ak820_outline_0164
      006AFB 24 F2            [12] 3725 	add	a,#0xff - 0x0d
      006AFD 40 4A            [24] 3726 	jc	00142$
                                   3727 ;	free result
      006AFF EF               [12] 3728 	mov	a,r7
      006B00 24 0A            [12] 3729 	add	a,#(00325$-3-.)
      006B02 83               [24] 3730 	movc	a,@a+pc
      006B03 F5 82            [12] 3731 	mov	dpl,a
      006B05 EF               [12] 3732 	mov	a,r7
      006B06 24 12            [12] 3733 	add	a,#(00326$-3-.)
      006B08 83               [24] 3734 	movc	a,@a+pc
      006B09 F5 83            [12] 3735 	mov	dph,a
      006B0B E4               [12] 3736 	clr	a
      006B0C 73               [24] 3737 	jmp	@a+dptr
      006B0D                       3738 00325$:
      006B0D 29                    3739 	.db	00134$
      006B0E 29                    3740 	.db	00134$
      006B0F 29                    3741 	.db	00134$
      006B10 29                    3742 	.db	00134$
      006B11 49                    3743 	.db	00142$
      006B12 29                    3744 	.db	00134$
      006B13 29                    3745 	.db	00134$
      006B14 29                    3746 	.db	00134$
      006B15 29                    3747 	.db	00134$
      006B16 29                    3748 	.db	00134$
      006B17 29                    3749 	.db	00134$
      006B18 49                    3750 	.db	00142$
      006B19 49                    3751 	.db	00142$
      006B1A 2D                    3752 	.db	00135$
      006B1B                       3753 00326$:
      006B1B 6B                    3754 	.db	00134$>>8
      006B1C 6B                    3755 	.db	00134$>>8
      006B1D 6B                    3756 	.db	00134$>>8
      006B1E 6B                    3757 	.db	00134$>>8
      006B1F 6B                    3758 	.db	00142$>>8
      006B20 6B                    3759 	.db	00134$>>8
      006B21 6B                    3760 	.db	00134$>>8
      006B22 6B                    3761 	.db	00134$>>8
      006B23 6B                    3762 	.db	00134$>>8
      006B24 6B                    3763 	.db	00134$>>8
      006B25 6B                    3764 	.db	00134$>>8
      006B26 6B                    3765 	.db	00142$>>8
      006B27 6B                    3766 	.db	00142$>>8
      006B28 6B                    3767 	.db	00135$>>8
                                   3768 ;	tmk_core/protocol/ch555/usb_ak820.c:597: case vial_qmk_settings_get:
      006B29                       3769 00134$:
                                   3770 ;	tmk_core/protocol/ch555/usb_ak820.c:598: return true;
      006B29 75 82 01         [24] 3771 	mov	dpl, #0x01
                                   3772 ;	tmk_core/protocol/ch555/usb_ak820.c:599: case vial_dynamic_entry_op:
      006B2C 22               [24] 3773 	ret
      006B2D                       3774 00135$:
                                   3775 ;	tmk_core/protocol/ch555/usb_ak820.c:600: switch (raw_buffer[2]) {
      006B2D 90 07 7E         [24] 3776 	mov	dptr,#(_raw_buffer + 0x0002)
      006B30 E0               [24] 3777 	movx	a,@dptr
      006B31 FF               [12] 3778 	mov	r7,a
      006B32 60 0D            [24] 3779 	jz	00139$
      006B34 BF 01 02         [24] 3780 	cjne	r7,#0x01,00328$
      006B37 80 08            [24] 3781 	sjmp	00139$
      006B39                       3782 00328$:
      006B39 BF 03 02         [24] 3783 	cjne	r7,#0x03,00329$
      006B3C 80 03            [24] 3784 	sjmp	00139$
      006B3E                       3785 00329$:
      006B3E BF 05 04         [24] 3786 	cjne	r7,#0x05,00140$
                                   3787 ;	tmk_core/protocol/ch555/usb_ak820.c:604: case dynamic_vial_key_override_get:
      006B41                       3788 00139$:
                                   3789 ;	tmk_core/protocol/ch555/usb_ak820.c:605: return true;
      006B41 75 82 01         [24] 3790 	mov	dpl, #0x01
                                   3791 ;	tmk_core/protocol/ch555/usb_ak820.c:606: default: return false;
      006B44 22               [24] 3792 	ret
      006B45                       3793 00140$:
      006B45 75 82 00         [24] 3794 	mov	dpl, #0x00
                                   3795 ;	tmk_core/protocol/ch555/usb_ak820.c:608: default: return false;
      006B48 22               [24] 3796 	ret
      006B49                       3797 00142$:
      006B49 75 82 00         [24] 3798 	mov	dpl, #0x00
                                   3799 ;	tmk_core/protocol/ch555/usb_ak820.c:610: default: return false;
      006B4C 22               [24] 3800 	ret
      006B4D                       3801 00144$:
      006B4D 75 82 00         [24] 3802 	mov	dpl, #0x00
                                   3803 ;	tmk_core/protocol/ch555/usb_ak820.c:611: }
                                   3804 ;	tmk_core/protocol/ch555/usb_ak820.c:612: }
      006B50 22               [24] 3805 	ret
                                   3806 ;------------------------------------------------------------
                                   3807 ;Allocation info for local variables in function 'ak820_usb_raw_send'
                                   3808 ;------------------------------------------------------------
                                   3809 ;length        Allocated with name '_ak820_usb_raw_send_PARM_2'
                                   3810 ;report        Allocated with name '_ak820_usb_raw_send_report_10000_462'
                                   3811 ;------------------------------------------------------------
                                   3812 ;	tmk_core/protocol/ch555/usb_ak820.c:614: void ak820_usb_raw_send(const uint8_t *report, uint8_t length) {
                                   3813 ;	-----------------------------------------
                                   3814 ;	 function ak820_usb_raw_send
                                   3815 ;	-----------------------------------------
      006B51                       3816 _ak820_usb_raw_send:
      006B51 12 43 80         [24] 3817 	lcall	_ak820_outline_0038
      006B54 90 07 E4         [24] 3818 	mov	dptr,#_ak820_usb_raw_send_report_10000_462
      006B57 12 38 29         [24] 3819 	lcall	_ak820_outline_0018
                                   3820 ;	tmk_core/protocol/ch555/usb_ak820.c:615: if (length != RAW_EPSIZE) return;
      006B5A 90 07 E3         [24] 3821 	mov	dptr,#_ak820_usb_raw_send_PARM_2
      006B5D E0               [24] 3822 	movx	a,@dptr
      006B5E FF               [12] 3823 	mov	r7,a
      006B5F BF 20 2B         [24] 3824 	cjne	r7,#0x20,00106$
                                   3825 ;	tmk_core/protocol/ch555/usb_ak820.c:616: ak820_nvm_flush();
      006B62 C0 07            [24] 3826 	push	ar7
      006B64 12 3E 97         [24] 3827 	lcall	_ak820_nvm_flush
      006B67 D0 07            [24] 3828 	pop	ar7
                                   3829 ;	tmk_core/protocol/ch555/usb_ak820.c:617: if (raw_reply_without_nvm || ak820_nvm_ok()) ak820_usb_send(RAW_IN_EPNUM, (const uint8_t __xdata *)report, length);
      006B69 90 07 9C         [24] 3830 	mov	dptr,#_raw_reply_without_nvm
      006B6C E0               [24] 3831 	movx	a,@dptr
      006B6D 70 07            [24] 3832 	jnz	00103$
      006B6F 12 3E 88         [24] 3833 	lcall	_ak820_nvm_ok
      006B72 E5 82            [12] 3834 	mov	a, dpl
      006B74 60 17            [24] 3835 	jz	00106$
      006B76                       3836 00103$:
      006B76 90 07 E4         [24] 3837 	mov	dptr,#_ak820_usb_raw_send_report_10000_462
      006B79 12 38 64         [24] 3838 	lcall	_ak820_outline_0080
      006B7C 90 07 D9         [24] 3839 	mov	dptr,#_ak820_usb_send_PARM_2
      006B7F 12 43 EA         [24] 3840 	lcall	_ak820_outline_0162
      006B82 90 07 DB         [24] 3841 	mov	dptr,#_ak820_usb_send_PARM_3
      006B85 EF               [12] 3842 	mov	a,r7
      006B86 F0               [24] 3843 	movx	@dptr,a
      006B87 75 82 03         [24] 3844 	mov	dpl, #0x03
                                   3845 ;	tmk_core/protocol/ch555/usb_ak820.c:618: }
      006B8A 02 68 67         [24] 3846 	ljmp	_ak820_usb_send
      006B8D                       3847 00106$:
      006B8D 22               [24] 3848 	ret
                                   3849 ;------------------------------------------------------------
                                   3850 ;Allocation info for local variables in function 'ak820_usb_raw_task'
                                   3851 ;------------------------------------------------------------
                                   3852 ;sloc0         Allocated with name '_ak820_usb_raw_task_sloc0_1_0'
                                   3853 ;i             Allocated with name '_ak820_usb_raw_task_i_10000_467'
                                   3854 ;length        Allocated with name '_ak820_usb_raw_task_length_10000_467'
                                   3855 ;address       Allocated with name '_ak820_usb_raw_task_address_10000_467'
                                   3856 ;saved_ea      Allocated with name '_ak820_usb_raw_task_saved_ea_10000_467'
                                   3857 ;------------------------------------------------------------
                                   3858 ;	tmk_core/protocol/ch555/usb_ak820.c:620: void ak820_usb_raw_task(void) {
                                   3859 ;	-----------------------------------------
                                   3860 ;	 function ak820_usb_raw_task
                                   3861 ;	-----------------------------------------
      006B8E                       3862 _ak820_usb_raw_task:
                                   3863 ;	tmk_core/protocol/ch555/usb_ak820.c:624: uint8_t saved_ea = EA;
      006B8E A2 AF            [12] 3864 	mov	c,_EA
      006B90 E4               [12] 3865 	clr	a
      006B91 33               [12] 3866 	rlc	a
      006B92 FF               [12] 3867 	mov	r7,a
                                   3868 ;	tmk_core/protocol/ch555/usb_ak820.c:625: EA = 0;
                                   3869 ;	assignBit
      006B93 C2 AF            [12] 3870 	clr	_EA
                                   3871 ;	tmk_core/protocol/ch555/usb_ak820.c:626: if (!USB_EnumStatus || raw_state != RAW_READY) { EA = saved_ea; return; }
      006B95 90 07 74         [24] 3872 	mov	dptr,#_USB_EnumStatus
      006B98 E0               [24] 3873 	movx	a,@dptr
      006B99 60 0A            [24] 3874 	jz	00101$
      006B9B 90 07 7B         [24] 3875 	mov	dptr,#_raw_state
      006B9E E0               [24] 3876 	movx	a,@dptr
      006B9F FE               [12] 3877 	mov	r6,a
      006BA0 BE 02 02         [24] 3878 	cjne	r6,#0x02,00427$
      006BA3 80 06            [24] 3879 	sjmp	00102$
      006BA5                       3880 00427$:
      006BA5                       3881 00101$:
                                   3882 ;	assignBit
      006BA5 EF               [12] 3883 	mov	a,r7
      006BA6 24 FF            [12] 3884 	add	a,#0xff
      006BA8 92 AF            [24] 3885 	mov	_EA,c
      006BAA 22               [24] 3886 	ret
      006BAB                       3887 00102$:
                                   3888 ;	tmk_core/protocol/ch555/usb_ak820.c:627: raw_state = RAW_WORK;
      006BAB 90 07 7B         [24] 3889 	mov	dptr,#_raw_state
      006BAE 74 03            [12] 3890 	mov	a,#0x03
      006BB0 F0               [24] 3891 	movx	@dptr,a
                                   3892 ;	tmk_core/protocol/ch555/usb_ak820.c:628: EA = saved_ea;
                                   3893 ;	assignBit
      006BB1 EF               [12] 3894 	mov	a,r7
      006BB2 24 FF            [12] 3895 	add	a,#0xff
      006BB4 92 AF            [24] 3896 	mov	_EA,c
                                   3897 ;	tmk_core/protocol/ch555/usb_ak820.c:629: if (raw_buffer[0] == 0xfd && raw_buffer[1] == 0) {
      006BB6 90 07 7C         [24] 3898 	mov	dptr,#_raw_buffer
      006BB9 E0               [24] 3899 	movx	a,@dptr
      006BBA FF               [12] 3900 	mov	r7,a
      006BBB E4               [12] 3901 	clr	a
      006BBC BF FD 01         [24] 3902 	cjne	r7,#0xfd,00428$
      006BBF 04               [12] 3903 	inc	a
      006BC0                       3904 00428$:
      006BC0 FF               [12] 3905 	mov	r7,a
      006BC1 70 03            [24] 3906 	jnz	00430$
      006BC3 02 6C 63         [24] 3907 	ljmp	00141$
      006BC6                       3908 00430$:
      006BC6 90 07 7D         [24] 3909 	mov	dptr,#(_raw_buffer + 0x0001)
      006BC9 E0               [24] 3910 	movx	a,@dptr
      006BCA 60 03            [24] 3911 	jz	00431$
      006BCC 02 6C 63         [24] 3912 	ljmp	00141$
      006BCF                       3913 00431$:
                                   3914 ;	tmk_core/protocol/ch555/usb_ak820.c:632: address = ((uint16_t)raw_buffer[2] << 8) | raw_buffer[3];
      006BCF 90 07 7E         [24] 3915 	mov	dptr,#(_raw_buffer + 0x0002)
      006BD2 E0               [24] 3916 	movx	a,@dptr
      006BD3 FD               [12] 3917 	mov	r5,a
      006BD4 7E 00            [12] 3918 	mov	r6,#0x00
      006BD6 90 07 7F         [24] 3919 	mov	dptr,#(_raw_buffer + 0x0003)
      006BD9 E0               [24] 3920 	movx	a,@dptr
      006BDA 7B 00            [12] 3921 	mov	r3,#0x00
      006BDC 42 06            [12] 3922 	orl	ar6,a
      006BDE EB               [12] 3923 	mov	a,r3
      006BDF 42 05            [12] 3924 	orl	ar5,a
                                   3925 ;	tmk_core/protocol/ch555/usb_ak820.c:633: length = raw_buffer[4];
      006BE1 90 07 80         [24] 3926 	mov	dptr,#(_raw_buffer + 0x0004)
      006BE4 E0               [24] 3927 	movx	a,@dptr
      006BE5 FC               [12] 3928 	mov	r4,a
                                   3929 ;	tmk_core/protocol/ch555/usb_ak820.c:634: for (i = 5; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006BE6 7B 05            [12] 3930 	mov	r3,#0x05
      006BE8                       3931 00151$:
      006BE8 EB               [12] 3932 	mov	a,r3
      006BE9 12 6E 4A         [24] 3933 	lcall	_ak820_outline_0044
      006BEC 0B               [12] 3934 	inc	r3
      006BED BB 20 00         [24] 3935 	cjne	r3,#0x20,00432$
      006BF0                       3936 00432$:
      006BF0 40 F6            [24] 3937 	jc	00151$
                                   3938 ;	tmk_core/protocol/ch555/usb_ak820.c:635: if (length > RAW_EPSIZE - 5 || (length && address > 0xffffu - (length - 1))) {
      006BF2 EC               [12] 3939 	mov	a,r4
      006BF3 24 E4            [12] 3940 	add	a,#0xff - 0x1b
      006BF5 40 1C            [24] 3941 	jc	00106$
                                   3942 ;	free result
      006BF7 EC               [12] 3943 	mov	a,r4
      006BF8 60 26            [24] 3944 	jz	00212$
      006BFA 8C 03            [24] 3945 	mov	ar3,r4
      006BFC 1B               [12] 3946 	dec	r3
      006BFD 7A 00            [12] 3947 	mov	r2,#0x00
      006BFF 74 FF            [12] 3948 	mov	a,#0xff
      006C01 C3               [12] 3949 	clr	c
      006C02 9B               [12] 3950 	subb	a,r3
      006C03 FB               [12] 3951 	mov	r3,a
      006C04 74 FF            [12] 3952 	mov	a,#0xff
      006C06 9A               [12] 3953 	subb	a,r2
      006C07 FA               [12] 3954 	mov	r2,a
      006C08 8E 00            [24] 3955 	mov	ar0,r6
      006C0A 8D 01            [24] 3956 	mov	ar1,r5
      006C0C C3               [12] 3957 	clr	c
      006C0D EB               [12] 3958 	mov	a,r3
      006C0E 98               [12] 3959 	subb	a,r0
      006C0F EA               [12] 3960 	mov	a,r2
      006C10 99               [12] 3961 	subb	a,r1
      006C11 50 0D            [24] 3962 	jnc	00212$
                                   3963 ;	free result
      006C13                       3964 00106$:
                                   3965 ;	tmk_core/protocol/ch555/usb_ak820.c:636: raw_buffer[1] = 0xff;
      006C13 90 07 7D         [24] 3966 	mov	dptr,#(_raw_buffer + 0x0001)
      006C16 74 FF            [12] 3967 	mov	a,#0xff
      006C18 F0               [24] 3968 	movx	@dptr,a
                                   3969 ;	tmk_core/protocol/ch555/usb_ak820.c:637: raw_buffer[4] = 0;
      006C19 90 07 80         [24] 3970 	mov	dptr,#(_raw_buffer + 0x0004)
      006C1C E4               [12] 3971 	clr	a
      006C1D F0               [24] 3972 	movx	@dptr,a
                                   3973 ;	tmk_core/protocol/ch555/usb_ak820.c:639: for (i = 0; i < length; ++i) raw_buffer[5 + i] = READ_CODE(address + i);
      006C1E 80 3A            [24] 3974 	sjmp	00108$
      006C20                       3975 00212$:
      006C20 7B 00            [12] 3976 	mov	r3,#0x00
      006C22                       3977 00154$:
      006C22 C3               [12] 3978 	clr	c
      006C23 EB               [12] 3979 	mov	a,r3
      006C24 9C               [12] 3980 	subb	a,r4
      006C25 50 33            [24] 3981 	jnc	00108$
      006C27 C0 04            [24] 3982 	push	ar4
      006C29 8B 02            [24] 3983 	mov	ar2,r3
      006C2B 74 05            [12] 3984 	mov	a,#0x05
      006C2D 2A               [12] 3985 	add	a, r2
      006C2E F9               [12] 3986 	mov	r1,a
      006C2F 33               [12] 3987 	rlc	a
      006C30 95 E0            [12] 3988 	subb	a,acc
      006C32 FA               [12] 3989 	mov	r2,a
      006C33 E9               [12] 3990 	mov	a,r1
      006C34 24 7C            [12] 3991 	add	a, #_raw_buffer
      006C36 F9               [12] 3992 	mov	r1,a
      006C37 EA               [12] 3993 	mov	a,r2
      006C38 34 07            [12] 3994 	addc	a, #(_raw_buffer >> 8)
      006C3A FA               [12] 3995 	mov	r2,a
      006C3B 8B 1E            [24] 3996 	mov	_ak820_usb_raw_task_sloc0_1_0,r3
      006C3D 75 1F 00         [24] 3997 	mov	(_ak820_usb_raw_task_sloc0_1_0 + 1),#0x00
      006C40 8E 00            [24] 3998 	mov	ar0,r6
      006C42 8D 04            [24] 3999 	mov	ar4,r5
      006C44 E5 1E            [12] 4000 	mov	a,_ak820_usb_raw_task_sloc0_1_0
      006C46 28               [12] 4001 	add	a, r0
      006C47 F8               [12] 4002 	mov	r0,a
      006C48 E5 1F            [12] 4003 	mov	a,(_ak820_usb_raw_task_sloc0_1_0 + 1)
      006C4A 3C               [12] 4004 	addc	a, r4
      006C4B FC               [12] 4005 	mov	r4,a
      006C4C 88 82            [24] 4006 	mov	dpl,r0
      006C4E 8C 83            [24] 4007 	mov	dph,r4
      006C50 E4               [12] 4008 	clr	a
      006C51 93               [24] 4009 	movc	a,@a+dptr
      006C52 12 6E 56         [24] 4010 	lcall	_ak820_outline_0139
      006C55 0B               [12] 4011 	inc	r3
      006C56 D0 04            [24] 4012 	pop	ar4
      006C58 80 C8            [24] 4013 	sjmp	00154$
      006C5A                       4014 00108$:
                                   4015 ;	tmk_core/protocol/ch555/usb_ak820.c:643: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006C5A 12 6E 36         [24] 4016 	lcall	_ak820_outline_0007
      006C5D 12 68 67         [24] 4017 	lcall	_ak820_usb_send
      006C60 02 6D E6         [24] 4018 	ljmp	00142$
      006C63                       4019 00141$:
                                   4020 ;	tmk_core/protocol/ch555/usb_ak820.c:644: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 1) {
      006C63 EF               [12] 4021 	mov	a,r7
      006C64 70 03            [24] 4022 	jnz	00438$
      006C66 02 6C E8         [24] 4023 	ljmp	00137$
      006C69                       4024 00438$:
      006C69 90 07 7D         [24] 4025 	mov	dptr,#(_raw_buffer + 0x0001)
      006C6C E0               [24] 4026 	movx	a,@dptr
      006C6D FE               [12] 4027 	mov	r6,a
      006C6E BE 01 02         [24] 4028 	cjne	r6,#0x01,00439$
      006C71 80 03            [24] 4029 	sjmp	00440$
      006C73                       4030 00439$:
      006C73 02 6C E8         [24] 4031 	ljmp	00137$
      006C76                       4032 00440$:
                                   4033 ;	tmk_core/protocol/ch555/usb_ak820.c:647: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006C76 7E 02            [12] 4034 	mov	r6,#0x02
      006C78                       4035 00156$:
      006C78 EE               [12] 4036 	mov	a,r6
      006C79 12 6E 4A         [24] 4037 	lcall	_ak820_outline_0044
      006C7C 0E               [12] 4038 	inc	r6
      006C7D BE 20 00         [24] 4039 	cjne	r6,#0x20,00441$
      006C80                       4040 00441$:
      006C80 40 F6            [24] 4041 	jc	00156$
                                   4042 ;	tmk_core/protocol/ch555/usb_ak820.c:648: raw_buffer[2] = 1;
      006C82 90 07 7E         [24] 4043 	mov	dptr,#(_raw_buffer + 0x0002)
      006C85 74 01            [12] 4044 	mov	a,#0x01
      006C87 F0               [24] 4045 	movx	@dptr,a
                                   4046 ;	tmk_core/protocol/ch555/usb_ak820.c:649: raw_buffer[3] = 0xa8;
      006C88 90 07 7F         [24] 4047 	mov	dptr,#(_raw_buffer + 0x0003)
      006C8B 74 A8            [12] 4048 	mov	a,#0xa8
      006C8D F0               [24] 4049 	movx	@dptr,a
                                   4050 ;	tmk_core/protocol/ch555/usb_ak820.c:650: ak820_nvm_diagnostic(&raw_buffer[4]);
      006C8E 90 07 80         [24] 4051 	mov	dptr,#(_raw_buffer + 0x0004)
      006C91 12 3C 05         [24] 4052 	lcall	_ak820_nvm_diagnostic
                                   4053 ;	tmk_core/protocol/ch555/usb_ak820.c:651: for (i = 0; i < 6; ++i) raw_buffer[11 + i] = ak820_flash_diagnostic[i];
      006C94 7E 00            [12] 4054 	mov	r6,#0x00
      006C96                       4055 00158$:
      006C96 8E 05            [24] 4056 	mov	ar5,r6
      006C98 74 0B            [12] 4057 	mov	a,#0x0b
      006C9A 2D               [12] 4058 	add	a, r5
      006C9B 24 7C            [12] 4059 	add	a,#_raw_buffer
      006C9D FD               [12] 4060 	mov	r5,a
      006C9E E4               [12] 4061 	clr	a
      006C9F 34 07            [12] 4062 	addc	a, #(_raw_buffer >> 8)
      006CA1 FC               [12] 4063 	mov	r4,a
      006CA2 EE               [12] 4064 	mov	a,r6
      006CA3 24 64            [12] 4065 	add	a, #_ak820_flash_diagnostic
      006CA5 F5 82            [12] 4066 	mov	dpl,a
      006CA7 E4               [12] 4067 	clr	a
      006CA8 34 04            [12] 4068 	addc	a, #(_ak820_flash_diagnostic >> 8)
      006CAA F5 83            [12] 4069 	mov	dph,a
      006CAC E0               [24] 4070 	movx	a,@dptr
      006CAD 12 43 FA         [24] 4071 	lcall	_ak820_outline_0189
      006CB0 F0               [24] 4072 	movx	@dptr,a
      006CB1 0E               [12] 4073 	inc	r6
      006CB2 BE 06 00         [24] 4074 	cjne	r6,#0x06,00443$
      006CB5                       4075 00443$:
      006CB5 40 DF            [24] 4076 	jc	00158$
                                   4077 ;	tmk_core/protocol/ch555/usb_ak820.c:652: raw_buffer[17] = vial_unlocked;
      006CB7 90 0E 29         [24] 4078 	mov	dptr,#_vial_unlocked
      006CBA E0               [24] 4079 	movx	a,@dptr
      006CBB 90 07 8D         [24] 4080 	mov	dptr,#(_raw_buffer + 0x0011)
      006CBE F0               [24] 4081 	movx	@dptr,a
                                   4082 ;	tmk_core/protocol/ch555/usb_ak820.c:653: raw_buffer[18] = vial_unlock_in_progress;
      006CBF 90 0E 2A         [24] 4083 	mov	dptr,#_vial_unlock_in_progress
      006CC2 E0               [24] 4084 	movx	a,@dptr
      006CC3 90 07 8E         [24] 4085 	mov	dptr,#(_raw_buffer + 0x0012)
      006CC6 F0               [24] 4086 	movx	@dptr,a
                                   4087 ;	tmk_core/protocol/ch555/usb_ak820.c:654: raw_buffer[19] = USB_EnumStatus;
      006CC7 90 07 74         [24] 4088 	mov	dptr,#_USB_EnumStatus
      006CCA E0               [24] 4089 	movx	a,@dptr
      006CCB 90 07 8F         [24] 4090 	mov	dptr,#(_raw_buffer + 0x0013)
      006CCE F0               [24] 4091 	movx	@dptr,a
                                   4092 ;	tmk_core/protocol/ch555/usb_ak820.c:655: raw_buffer[20] = USB_SleepStatus;
      006CCF 90 07 75         [24] 4093 	mov	dptr,#_USB_SleepStatus
      006CD2 E0               [24] 4094 	movx	a,@dptr
      006CD3 90 07 90         [24] 4095 	mov	dptr,#(_raw_buffer + 0x0014)
      006CD6 F0               [24] 4096 	movx	@dptr,a
                                   4097 ;	tmk_core/protocol/ch555/usb_ak820.c:656: raw_buffer[21] = raw_state;
      006CD7 90 07 7B         [24] 4098 	mov	dptr,#_raw_state
      006CDA E0               [24] 4099 	movx	a,@dptr
      006CDB 90 07 91         [24] 4100 	mov	dptr,#(_raw_buffer + 0x0015)
      006CDE F0               [24] 4101 	movx	@dptr,a
                                   4102 ;	tmk_core/protocol/ch555/usb_ak820.c:657: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006CDF 12 6E 36         [24] 4103 	lcall	_ak820_outline_0007
      006CE2 12 68 67         [24] 4104 	lcall	_ak820_usb_send
      006CE5 02 6D E6         [24] 4105 	ljmp	00142$
      006CE8                       4106 00137$:
                                   4107 ;	tmk_core/protocol/ch555/usb_ak820.c:659: } else if (raw_buffer[0] == 0xfd && raw_buffer[1] == 2) {
      006CE8 EF               [12] 4108 	mov	a,r7
      006CE9 70 03            [24] 4109 	jnz	00445$
      006CEB 02 6D C3         [24] 4110 	ljmp	00133$
      006CEE                       4111 00445$:
      006CEE 12 6E 5C         [24] 4112 	lcall	_ak820_outline_0164
      006CF1 BF 02 02         [24] 4113 	cjne	r7,#0x02,00446$
      006CF4 80 03            [24] 4114 	sjmp	00447$
      006CF6                       4115 00446$:
      006CF6 02 6D C3         [24] 4116 	ljmp	00133$
      006CF9                       4117 00447$:
                                   4118 ;	tmk_core/protocol/ch555/usb_ak820.c:663: length = 1;
      006CF9 90 07 E7         [24] 4119 	mov	dptr,#_ak820_usb_raw_task_length_10000_467
      006CFC 74 01            [12] 4120 	mov	a,#0x01
      006CFE F0               [24] 4121 	movx	@dptr,a
                                   4122 ;	tmk_core/protocol/ch555/usb_ak820.c:664: if (raw_buffer[2] == 1 && raw_buffer[3] <= 1 && raw_buffer[4] <= AK820_OS_BREATHE &&
      006CFF 90 07 7E         [24] 4123 	mov	dptr,#(_raw_buffer + 0x0002)
      006D02 E0               [24] 4124 	movx	a,@dptr
      006D03 FF               [12] 4125 	mov	r7,a
      006D04 BF 01 73         [24] 4126 	cjne	r7,#0x01,00235$
      006D07 90 07 7F         [24] 4127 	mov	dptr,#(_raw_buffer + 0x0003)
      006D0A E0               [24] 4128 	movx	a,@dptr
      006D0B FF               [12] 4129 	mov  r7,a
      006D0C 24 FE            [12] 4130 	add	a,#0xff - 0x01
      006D0E 40 6A            [24] 4131 	jc	00235$
                                   4132 ;	free result
      006D10 90 07 80         [24] 4133 	mov	dptr,#(_raw_buffer + 0x0004)
      006D13 E0               [24] 4134 	movx	a,@dptr
      006D14 FE               [12] 4135 	mov  r6,a
      006D15 24 FC            [12] 4136 	add	a,#0xff - 0x03
      006D17 40 61            [24] 4137 	jc	00235$
                                   4138 ;	free result
                                   4139 ;	tmk_core/protocol/ch555/usb_ak820.c:665: (raw_buffer[3] || !raw_buffer[4])) {
      006D19 EF               [12] 4140 	mov	a,r7
      006D1A 70 03            [24] 4141 	jnz	00227$
      006D1C EE               [12] 4142 	mov	a,r6
      006D1D 70 5B            [24] 4143 	jnz	00235$
                                   4144 ;	tmk_core/protocol/ch555/usb_ak820.c:666: for (i = 5; i < RAW_EPSIZE && !raw_buffer[i]; ++i) {}
      006D1F                       4145 00227$:
      006D1F 7D 05            [12] 4146 	mov	r5,#0x05
      006D21                       4147 00162$:
      006D21 BD 20 00         [24] 4148 	cjne	r5,#0x20,00454$
      006D24                       4149 00454$:
      006D24 50 11            [24] 4150 	jnc	00113$
      006D26 ED               [12] 4151 	mov	a,r5
      006D27 24 7C            [12] 4152 	add	a, #_raw_buffer
      006D29 FB               [12] 4153 	mov	r3,a
      006D2A E4               [12] 4154 	clr	a
      006D2B 34 07            [12] 4155 	addc	a, #(_raw_buffer >> 8)
      006D2D FC               [12] 4156 	mov	r4,a
      006D2E 12 33 FC         [24] 4157 	lcall	_ak820_outline_0121
      006D31 E0               [24] 4158 	movx	a,@dptr
      006D32 70 03            [24] 4159 	jnz	00113$
      006D34 0D               [12] 4160 	inc	r5
      006D35 80 EA            [24] 4161 	sjmp	00162$
      006D37                       4162 00113$:
                                   4163 ;	tmk_core/protocol/ch555/usb_ak820.c:667: if (i == RAW_EPSIZE) {
      006D37 BD 20 40         [24] 4164 	cjne	r5,#0x20,00235$
                                   4165 ;	tmk_core/protocol/ch555/usb_ak820.c:668: saved_ea = EA;
                                   4166 ;	assignBit
      006D3A A2 AF            [12] 4167 	mov	c,_EA
      006D3C 92 1D            [24] 4168 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4169 ;	tmk_core/protocol/ch555/usb_ak820.c:669: EA = 0;
                                   4170 ;	assignBit
      006D3E C2 AF            [12] 4171 	clr	_EA
                                   4172 ;	tmk_core/protocol/ch555/usb_ak820.c:672: if (raw_state == RAW_WORK && USB_EnumStatus && D0UsbConfig &&
      006D40 90 07 7B         [24] 4173 	mov	dptr,#_raw_state
      006D43 E0               [24] 4174 	movx	a,@dptr
      006D44 FD               [12] 4175 	mov	r5,a
      006D45 BD 03 28         [24] 4176 	cjne	r5,#0x03,00117$
      006D48 90 07 74         [24] 4177 	mov	dptr,#_USB_EnumStatus
      006D4B E0               [24] 4178 	movx	a,@dptr
      006D4C 60 22            [24] 4179 	jz	00117$
      006D4E 90 07 73         [24] 4180 	mov	dptr,#_D0UsbConfig
      006D51 E0               [24] 4181 	movx	a,@dptr
      006D52 60 1C            [24] 4182 	jz	00117$
                                   4183 ;	tmk_core/protocol/ch555/usb_ak820.c:673: !(USB_SleepStatus & 2) && !vial_unlock_in_progress) {
      006D54 90 07 75         [24] 4184 	mov	dptr,#_USB_SleepStatus
      006D57 E0               [24] 4185 	movx	a,@dptr
      006D58 20 E1 15         [24] 4186 	jb	acc.1,00117$
      006D5B 90 0E 2A         [24] 4187 	mov	dptr,#_vial_unlock_in_progress
      006D5E E0               [24] 4188 	movx	a,@dptr
      006D5F 70 0F            [24] 4189 	jnz	00117$
                                   4190 ;	tmk_core/protocol/ch555/usb_ak820.c:674: if (raw_buffer[3]) ak820_os_indicator_set(raw_buffer[4]);
      006D61 EF               [12] 4191 	mov	a,r7
      006D62 60 05            [24] 4192 	jz	00115$
      006D64 8E 82            [24] 4193 	mov	dpl, r6
      006D66 12 43 FF         [24] 4194 	lcall	_ak820_os_indicator_set
      006D69                       4195 00115$:
                                   4196 ;	tmk_core/protocol/ch555/usb_ak820.c:675: length = 0;
      006D69 90 07 E7         [24] 4197 	mov	dptr,#_ak820_usb_raw_task_length_10000_467
      006D6C E4               [12] 4198 	clr	a
      006D6D F0               [24] 4199 	movx	@dptr,a
      006D6E 80 06            [24] 4200 	sjmp	00118$
      006D70                       4201 00117$:
                                   4202 ;	tmk_core/protocol/ch555/usb_ak820.c:676: } else length = 2;
      006D70 90 07 E7         [24] 4203 	mov	dptr,#_ak820_usb_raw_task_length_10000_467
      006D73 74 02            [12] 4204 	mov	a,#0x02
      006D75 F0               [24] 4205 	movx	@dptr,a
      006D76                       4206 00118$:
                                   4207 ;	tmk_core/protocol/ch555/usb_ak820.c:677: EA = saved_ea;
                                   4208 ;	assignBit
      006D76 A2 1D            [12] 4209 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006D78 92 AF            [24] 4210 	mov	_EA,c
                                   4211 ;	tmk_core/protocol/ch555/usb_ak820.c:680: for (i = 2; i < RAW_EPSIZE; ++i) raw_buffer[i] = 0;
      006D7A                       4212 00235$:
      006D7A 7F 02            [12] 4213 	mov	r7,#0x02
      006D7C                       4214 00164$:
      006D7C EF               [12] 4215 	mov	a,r7
      006D7D 12 6E 4A         [24] 4216 	lcall	_ak820_outline_0044
      006D80 0F               [12] 4217 	inc	r7
      006D81 BF 20 00         [24] 4218 	cjne	r7,#0x20,00466$
      006D84                       4219 00466$:
      006D84 40 F6            [24] 4220 	jc	00164$
                                   4221 ;	tmk_core/protocol/ch555/usb_ak820.c:681: raw_buffer[2] = 1;
      006D86 90 07 7E         [24] 4222 	mov	dptr,#(_raw_buffer + 0x0002)
      006D89 74 01            [12] 4223 	mov	a,#0x01
      006D8B F0               [24] 4224 	movx	@dptr,a
                                   4225 ;	tmk_core/protocol/ch555/usb_ak820.c:682: raw_buffer[3] = length;
      006D8C 90 07 E7         [24] 4226 	mov	dptr,#_ak820_usb_raw_task_length_10000_467
      006D8F E0               [24] 4227 	movx	a,@dptr
      006D90 90 07 7F         [24] 4228 	mov	dptr,#(_raw_buffer + 0x0003)
      006D93 F0               [24] 4229 	movx	@dptr,a
                                   4230 ;	tmk_core/protocol/ch555/usb_ak820.c:683: raw_buffer[4] = ak820_os_indicator_get();
      006D94 12 44 26         [24] 4231 	lcall	_ak820_os_indicator_get
      006D97 AF 82            [24] 4232 	mov	r7, dpl
      006D99 90 07 80         [24] 4233 	mov	dptr,#(_raw_buffer + 0x0004)
      006D9C EF               [12] 4234 	mov	a,r7
      006D9D F0               [24] 4235 	movx	@dptr,a
                                   4236 ;	tmk_core/protocol/ch555/usb_ak820.c:684: raw_buffer[5] = 0xa8;
      006D9E 90 07 81         [24] 4237 	mov	dptr,#(_raw_buffer + 0x0005)
      006DA1 74 A8            [12] 4238 	mov	a,#0xa8
      006DA3 F0               [24] 4239 	movx	@dptr,a
                                   4240 ;	tmk_core/protocol/ch555/usb_ak820.c:685: raw_buffer[6] = (uint8_t)AK820_OS_INDICATOR_LEASE_MS;
      006DA4 90 07 82         [24] 4241 	mov	dptr,#(_raw_buffer + 0x0006)
      006DA7 74 B8            [12] 4242 	mov	a,#0xb8
      006DA9 F0               [24] 4243 	movx	@dptr,a
                                   4244 ;	tmk_core/protocol/ch555/usb_ak820.c:686: raw_buffer[7] = (uint8_t)(AK820_OS_INDICATOR_LEASE_MS >> 8);
      006DAA 90 07 83         [24] 4245 	mov	dptr,#(_raw_buffer + 0x0007)
      006DAD 74 0B            [12] 4246 	mov	a,#0x0b
      006DAF F0               [24] 4247 	movx	@dptr,a
                                   4248 ;	tmk_core/protocol/ch555/usb_ak820.c:687: raw_buffer[8] = (uint8_t)AK820_OS_INDICATOR_PERIOD_MS;
      006DB0 90 07 84         [24] 4249 	mov	dptr,#(_raw_buffer + 0x0008)
      006DB3 E4               [12] 4250 	clr	a
      006DB4 F0               [24] 4251 	movx	@dptr,a
                                   4252 ;	tmk_core/protocol/ch555/usb_ak820.c:688: raw_buffer[9] = (uint8_t)(AK820_OS_INDICATOR_PERIOD_MS >> 8);
      006DB5 90 07 85         [24] 4253 	mov	dptr,#(_raw_buffer + 0x0009)
      006DB8 74 10            [12] 4254 	mov	a,#0x10
      006DBA F0               [24] 4255 	movx	@dptr,a
                                   4256 ;	tmk_core/protocol/ch555/usb_ak820.c:689: ak820_usb_send(RAW_IN_EPNUM, raw_buffer, RAW_EPSIZE);
      006DBB 12 6E 36         [24] 4257 	lcall	_ak820_outline_0007
      006DBE 12 68 67         [24] 4258 	lcall	_ak820_usb_send
      006DC1 80 23            [24] 4259 	sjmp	00142$
      006DC3                       4260 00133$:
                                   4261 ;	tmk_core/protocol/ch555/usb_ak820.c:692: raw_reply_without_nvm = raw_request_is_nonpersistent();
      006DC3 12 6A 76         [24] 4262 	lcall	_raw_request_is_nonpersistent
      006DC6 E5 82            [12] 4263 	mov	a, dpl
      006DC8 90 07 9C         [24] 4264 	mov	dptr,#_raw_reply_without_nvm
      006DCB F0               [24] 4265 	movx	@dptr,a
                                   4266 ;	tmk_core/protocol/ch555/usb_ak820.c:693: ak820_nvm_begin();
      006DCC 12 3F E9         [24] 4267 	lcall	_ak820_nvm_begin
                                   4268 ;	tmk_core/protocol/ch555/usb_ak820.c:694: raw_hid_receive(raw_buffer, RAW_EPSIZE);
      006DCF 90 0C 5B         [24] 4269 	mov	dptr,#_raw_hid_receive_PARM_2
      006DD2 74 20            [12] 4270 	mov	a,#0x20
      006DD4 F0               [24] 4271 	movx	@dptr,a
      006DD5 90 07 7C         [24] 4272 	mov	dptr,#_raw_buffer
      006DD8 75 F0 00         [24] 4273 	mov	b, #0x00
      006DDB 12 A9 44         [24] 4274 	lcall	_raw_hid_receive
                                   4275 ;	tmk_core/protocol/ch555/usb_ak820.c:695: ak820_nvm_end();
      006DDE 12 3F FE         [24] 4276 	lcall	_ak820_nvm_end
                                   4277 ;	tmk_core/protocol/ch555/usb_ak820.c:696: raw_reply_without_nvm = false;
      006DE1 90 07 9C         [24] 4278 	mov	dptr,#_raw_reply_without_nvm
      006DE4 E4               [12] 4279 	clr	a
      006DE5 F0               [24] 4280 	movx	@dptr,a
      006DE6                       4281 00142$:
                                   4282 ;	tmk_core/protocol/ch555/usb_ak820.c:698: saved_ea = EA;
                                   4283 ;	assignBit
      006DE6 A2 AF            [12] 4284 	mov	c,_EA
      006DE8 92 1D            [24] 4285 	mov	_ak820_usb_raw_task_sloc1_1_0,c
                                   4286 ;	tmk_core/protocol/ch555/usb_ak820.c:699: EA = 0;
                                   4287 ;	assignBit
      006DEA C2 AF            [12] 4288 	clr	_EA
                                   4289 ;	tmk_core/protocol/ch555/usb_ak820.c:701: if (raw_state == RAW_TX_ACTIVE) raw_state = RAW_TX_WAIT;
      006DEC 12 6E 62         [24] 4290 	lcall	_ak820_outline_0166
      006DEF BF 04 08         [24] 4291 	cjne	r7,#0x04,00149$
      006DF2 90 07 7B         [24] 4292 	mov	dptr,#_raw_state
      006DF5 74 05            [12] 4293 	mov	a,#0x05
      006DF7 F0               [24] 4294 	movx	@dptr,a
      006DF8 80 1B            [24] 4295 	sjmp	00150$
      006DFA                       4296 00149$:
                                   4297 ;	tmk_core/protocol/ch555/usb_ak820.c:702: else if (raw_state == RAW_WORK || raw_state == RAW_DRAINED || raw_state == RAW_CANCELLED) raw_state = RAW_IDLE;
      006DFA 12 6E 62         [24] 4298 	lcall	_ak820_outline_0166
      006DFD BF 03 02         [24] 4299 	cjne	r7,#0x03,00470$
      006E00 80 0E            [24] 4300 	sjmp	00144$
      006E02                       4301 00470$:
      006E02 12 6E 62         [24] 4302 	lcall	_ak820_outline_0166
      006E05 BF 06 02         [24] 4303 	cjne	r7,#0x06,00471$
      006E08 80 06            [24] 4304 	sjmp	00144$
      006E0A                       4305 00471$:
      006E0A 12 6E 62         [24] 4306 	lcall	_ak820_outline_0166
      006E0D BF 07 05         [24] 4307 	cjne	r7,#0x07,00150$
      006E10                       4308 00144$:
      006E10 90 07 7B         [24] 4309 	mov	dptr,#_raw_state
      006E13 E4               [12] 4310 	clr	a
      006E14 F0               [24] 4311 	movx	@dptr,a
      006E15                       4312 00150$:
                                   4313 ;	tmk_core/protocol/ch555/usb_ak820.c:703: EA = saved_ea;
                                   4314 ;	assignBit
      006E15 A2 1D            [12] 4315 	mov	c,_ak820_usb_raw_task_sloc1_1_0
      006E17 92 AF            [24] 4316 	mov	_EA,c
                                   4317 ;	tmk_core/protocol/ch555/usb_ak820.c:704: }
      006E19 22               [24] 4318 	ret
                                   4319 ;------------------------------------------------------------
                                   4320 ;Allocation info for local variables in function 'ak820_usb_take_keyboard_reset'
                                   4321 ;------------------------------------------------------------
                                   4322 ;result        Allocated with name '_ak820_usb_take_keyboard_reset_result_10000_497'
                                   4323 ;saved_ea      Allocated with name '_ak820_usb_take_keyboard_reset_saved_ea_10000_497'
                                   4324 ;------------------------------------------------------------
                                   4325 ;	tmk_core/protocol/ch555/usb_ak820.c:712: bool ak820_usb_take_keyboard_reset(void) {
                                   4326 ;	-----------------------------------------
                                   4327 ;	 function ak820_usb_take_keyboard_reset
                                   4328 ;	-----------------------------------------
      006E1A                       4329 _ak820_usb_take_keyboard_reset:
                                   4330 ;	tmk_core/protocol/ch555/usb_ak820.c:714: uint8_t saved_ea = EA;
                                   4331 ;	assignBit
      006E1A A2 AF            [12] 4332 	mov	c,_EA
      006E1C 92 1E            [24] 4333 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
                                   4334 ;	tmk_core/protocol/ch555/usb_ak820.c:715: EA = 0;
                                   4335 ;	assignBit
      006E1E C2 AF            [12] 4336 	clr	_EA
                                   4337 ;	tmk_core/protocol/ch555/usb_ak820.c:716: result = keyboard_reset;
      006E20 90 07 9D         [24] 4338 	mov	dptr,#_keyboard_reset
      006E23 E0               [24] 4339 	movx	a,@dptr
      006E24 FF               [12] 4340 	mov	r7,a
                                   4341 ;	tmk_core/protocol/ch555/usb_ak820.c:717: keyboard_reset = 0;
      006E25 E4               [12] 4342 	clr	a
      006E26 F0               [24] 4343 	movx	@dptr,a
                                   4344 ;	tmk_core/protocol/ch555/usb_ak820.c:718: EA = saved_ea;
                                   4345 ;	assignBit
      006E27 A2 1E            [12] 4346 	mov	c,_ak820_usb_take_keyboard_reset_sloc0_1_0
      006E29 92 AF            [24] 4347 	mov	_EA,c
                                   4348 ;	tmk_core/protocol/ch555/usb_ak820.c:719: return result != 0;
      006E2B EF               [12] 4349 	mov	a,r7
      006E2C B4 01 00         [24] 4350 	cjne	a,#0x01,00103$
      006E2F                       4351 00103$:
      006E2F B3               [12] 4352 	cpl	c
      006E30 92 1E            [24] 4353 	mov	_ak820_usb_take_keyboard_reset_sloc0_1_0,c
      006E32 12 38 B1         [24] 4354 	lcall	_ak820_outline_0156
                                   4355 ;	tmk_core/protocol/ch555/usb_ak820.c:720: }
      006E35 22               [24] 4356 	ret
                                   4357 	.area CSEG    (CODE)
                                   4358 	.area CONST   (CODE)
                                   4359 	.area CONST   (CODE)
      00BC16                       4360 _shared_offsets:
      00BC16 00                    4361 	.db #0x00	; 0
      00BC17 00                    4362 	.db #0x00	; 0
      00BC18 28                    4363 	.db #0x28	; 40
      00BC19 28                    4364 	.db #0x28	; 40
      00BC1A 2B                    4365 	.db #0x2b	; 43
      00BC1B 00                    4366 	.db #0x00	; 0
      00BC1C 08                    4367 	.db #0x08	; 8
                                   4368 	.area CSEG    (CODE)
                                   4369 	.area CONST   (CODE)
      00BC1D                       4370 _shared_lengths:
      00BC1D 00                    4371 	.db #0x00	; 0
      00BC1E 00                    4372 	.db #0x00	; 0
      00BC1F 00                    4373 	.db #0x00	; 0
      00BC20 03                    4374 	.db #0x03	; 3
      00BC21 03                    4375 	.db #0x03	; 3
      00BC22 00                    4376 	.db #0x00	; 0
      00BC23 20                    4377 	.db #0x20	; 32
                                   4378 	.area CSEG    (CODE)
                                   4379 	.area CONST   (CODE)
      00BC24                       4380 _interface_descriptors:
      00BC24 BF C1                 4381 	.byte _KeyboardReport, (_KeyboardReport >> 8)
      00BC26 BF C2                 4382 	.byte (_ConfigurationDescriptor + 18), ((_ConfigurationDescriptor + 18) >> 8)
      00BC28 72 C2                 4383 	.byte _RawReport, (_RawReport >> 8)
      00BC2A D8 C2                 4384 	.byte (_ConfigurationDescriptor + 43), ((_ConfigurationDescriptor + 43) >> 8)
      00BC2C 04 C2                 4385 	.byte _SharedReport, (_SharedReport >> 8)
      00BC2E F1 C2                 4386 	.byte (_ConfigurationDescriptor + 68), ((_ConfigurationDescriptor + 68) >> 8)
                                   4387 	.area CSEG    (CODE)
                                   4388 	.area XINIT   (CODE)
                                   4389 	.area CABS    (ABS,CODE)
                                   4390 
                                   4391 ; Experimental exact instruction outlining.
                                   4392 	.globl _ak820_outline_0007
                                   4393 	.globl _ak820_outline_0018
                                   4394 	.globl _ak820_outline_0038
                                   4395 	.globl _ak820_outline_0044
                                   4396 	.globl _ak820_outline_0080
                                   4397 	.globl _ak820_outline_0121
                                   4398 	.globl _ak820_outline_0139
                                   4399 	.globl _ak820_outline_0156
                                   4400 	.globl _ak820_outline_0162
                                   4401 	.globl _ak820_outline_0164
                                   4402 	.globl _ak820_outline_0166
                                   4403 	.globl _ak820_outline_0189
                                   4404 
                                   4405 	.area CSEG (CODE)
                                   4406 ; function ak820_outline_0007
      006E36                       4407 _ak820_outline_0007:
      006E36 90 07 D9         [24] 4408 	mov	dptr,#_ak820_usb_send_PARM_2
      006E39 74 7C            [12] 4409 	mov	a,#_raw_buffer
      006E3B F0               [24] 4410 	movx	@dptr,a
      006E3C 74 07            [12] 4411 	mov	a,#(_raw_buffer>>8)
      006E3E A3               [24] 4412 	inc	dptr
      006E3F F0               [24] 4413 	movx	@dptr,a
      006E40 90 07 DB         [24] 4414 	mov	dptr,#_ak820_usb_send_PARM_3
      006E43 74 20            [12] 4415 	mov	a,#0x20
      006E45 F0               [24] 4416 	movx	@dptr,a
      006E46 75 82 03         [24] 4417 	mov	dpl,#0x03
      006E49 22               [24] 4418 	ret
                                   4419 
                                   4420 	.area CSEG (CODE)
                                   4421 ; function ak820_outline_0044
      006E4A                       4422 _ak820_outline_0044:
      006E4A 24 7C            [12] 4423 	add	a,#_raw_buffer
      006E4C F5 82            [12] 4424 	mov	dpl,a
      006E4E E4               [12] 4425 	clr	a
      006E4F 34 07            [12] 4426 	addc	a,#(_raw_buffer>>8)
      006E51 F5 83            [12] 4427 	mov	dph,a
      006E53 E4               [12] 4428 	clr	a
      006E54 F0               [24] 4429 	movx	@dptr,a
      006E55 22               [24] 4430 	ret
                                   4431 
                                   4432 	.area CSEG (CODE)
                                   4433 ; function ak820_outline_0139
      006E56                       4434 _ak820_outline_0139:
      006E56 89 82            [24] 4435 	mov	dpl,r1
      006E58 8A 83            [24] 4436 	mov	dph,r2
      006E5A F0               [24] 4437 	movx	@dptr,a
      006E5B 22               [24] 4438 	ret
                                   4439 
                                   4440 	.area CSEG (CODE)
                                   4441 ; function ak820_outline_0164
      006E5C                       4442 _ak820_outline_0164:
      006E5C 90 07 7D         [24] 4443 	mov	dptr,#(_raw_buffer+0x0001)
      006E5F E0               [24] 4444 	movx	a,@dptr
      006E60 FF               [12] 4445 	mov	r7,a
      006E61 22               [24] 4446 	ret
                                   4447 
                                   4448 	.area CSEG (CODE)
                                   4449 ; function ak820_outline_0166
      006E62                       4450 _ak820_outline_0166:
      006E62 90 07 7B         [24] 4451 	mov	dptr,#_raw_state
      006E65 E0               [24] 4452 	movx	a,@dptr
      006E66 FF               [12] 4453 	mov	r7,a
      006E67 22               [24] 4454 	ret
