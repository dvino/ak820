                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00051D                        109 _page_data:
      00051D                        110 	.ds 64
      00055D                        111 _cached_page:
      00055D                        112 	.ds 1
      00055E                        113 _batch_depth:
      00055E                        114 	.ds 1
      00055F                        115 _first_failure_stage:
      00055F                        116 	.ds 1
      000560                        117 _nvm_fail_stage_10000_20:
      000560                        118 	.ds 1
      000561                        119 _ak820_nvm_diagnostic_out_10000_23:
      000561                        120 	.ds 2
      000563                        121 _crc_byte_PARM_2:
      000563                        122 	.ds 1
      000564                        123 _crc_byte_crc_10000_25:
      000564                        124 	.ds 2
      000566                        125 _page_crc_crc_10000_30:
      000566                        126 	.ds 2
      000568                        127 _write_page_address_10000_32:
      000568                        128 	.ds 2
      00056A                        129 _journal_header_valid_header_10000_39:
      00056A                        130 	.ds 2
      00056C                        131 _recover_journal_header_10000_46:
      00056C                        132 	.ds 9
      000575                        133 _ak820_nvm_flush_header_10000_62:
      000575                        134 	.ds 9
      00057E                        135 _ak820_nvm_flush_stage_10000_62:
      00057E                        136 	.ds 1
      00057F                        137 _load_page_page_10000_87:
      00057F                        138 	.ds 1
      000580                        139 _read_offset_offset_10000_93:
      000580                        140 	.ds 2
      000582                        141 _eeprom_read_byte_addr_10000_97:
      000582                        142 	.ds 3
      000585                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000585                        144 	.ds 3
      000588                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000588                        146 	.ds 2
      00058A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00058A                        148 	.ds 2
      00058C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00058C                        150 	.ds 2
      00058E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058E                        152 	.ds 3
      000591                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      000591                        154 	.ds 2
      000593                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000593                        156 	.ds 2
      000595                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000595                        158 	.ds 3
      000598                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000598                        160 	.ds 2
      00059A                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      00059A                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003BF1                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003BF1 E5 82            [12]  215 	mov	a,dpl
      003BF3 90 05 60         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003BF6 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003BF7 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003BFA 90 05 60         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003BFD E0               [24]  221 	movx	a,@dptr
      003BFE 90 05 5F         [24]  222 	mov	dptr,#_first_failure_stage
      003C01 F0               [24]  223 	movx	@dptr,a
      003C02                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003C02 D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003C04 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003C05                        239 _ak820_nvm_diagnostic:
      003C05 12 38 82         [24]  240 	lcall	_ak820_outline_0107
      003C08 90 05 61         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003C0B 12 38 87         [24]  242 	lcall	_ak820_outline_0108
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003C0E 90 05 61         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003C11 12 38 41         [24]  245 	lcall	_ak820_outline_0052
      003C14 A2 0B            [12]  246 	mov	c,_storage_failed
      003C16 E4               [12]  247 	clr	a
      003C17 33               [12]  248 	rlc	a
      003C18 12 38 8C         [24]  249 	lcall	_ak820_outline_0118
      003C1B 12 43 AB         [24]  250 	lcall	_ak820_outline_0072
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003C1E A3               [24]  252 	inc	dptr
      003C1F A2 09            [12]  253 	mov	c,_page_valid
      003C21 E4               [12]  254 	clr	a
      003C22 33               [12]  255 	rlc	a
      003C23 12 43 78         [24]  256 	lcall	_ak820_outline_0032
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003C26 A2 0A            [12]  258 	mov	c,_page_dirty
      003C28 E4               [12]  259 	clr	a
      003C29 33               [12]  260 	rlc	a
      003C2A F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003C2B 74 03            [12]  263 	mov	a,#0x03
      003C2D 12 43 E4         [24]  264 	lcall	_ak820_outline_0161
      003C30 90 05 5E         [24]  265 	mov	dptr,#_batch_depth
      003C33 E0               [24]  266 	movx	a,@dptr
      003C34 12 38 97         [24]  267 	lcall	_ak820_outline_0124
      003C37 F0               [24]  268 	movx	@dptr,a
                                    269 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003C38 74 04            [12]  270 	mov	a,#0x04
      003C3A 12 43 E4         [24]  271 	lcall	_ak820_outline_0161
      003C3D 90 05 5D         [24]  272 	mov	dptr,#_cached_page
      003C40 E0               [24]  273 	movx	a,@dptr
      003C41 12 38 97         [24]  274 	lcall	_ak820_outline_0124
      003C44 F0               [24]  275 	movx	@dptr,a
                                    276 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003C45 12 43 6E         [24]  277 	lcall	_ak820_outline_0012
      003C48 E4               [12]  278 	clr	a
      003C49 F0               [24]  279 	movx	@dptr,a
                                    280 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003C4A 74 06            [12]  281 	mov	a,#0x06
      003C4C 12 43 CE         [24]  282 	lcall	_ak820_outline_0137
      003C4F 90 05 5F         [24]  283 	mov	dptr,#_first_failure_stage
      003C52 E0               [24]  284 	movx	a,@dptr
      003C53 12 38 8C         [24]  285 	lcall	_ak820_outline_0118
      003C56 F0               [24]  286 	movx	@dptr,a
                                    287 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003C57 22               [24]  288 	ret
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'crc_byte'
                                    291 ;------------------------------------------------------------
                                    292 ;value         Allocated with name '_crc_byte_PARM_2'
                                    293 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    294 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    295 ;------------------------------------------------------------
                                    296 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    297 ;	-----------------------------------------
                                    298 ;	 function crc_byte
                                    299 ;	-----------------------------------------
      003C58                        300 _crc_byte:
      003C58 12 38 82         [24]  301 	lcall	_ak820_outline_0107
      003C5B 90 05 64         [24]  302 	mov	dptr,#_crc_byte_crc_10000_25
      003C5E 12 38 87         [24]  303 	lcall	_ak820_outline_0108
                                    304 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003C61 90 05 63         [24]  305 	mov	dptr,#_crc_byte_PARM_2
      003C64 E0               [24]  306 	movx	a,@dptr
      003C65 FF               [12]  307 	mov	r7,a
      003C66 7E 00            [12]  308 	mov	r6,#0x00
      003C68 90 05 64         [24]  309 	mov	dptr,#_crc_byte_crc_10000_25
      003C6B E0               [24]  310 	movx	a,@dptr
      003C6C 6E               [12]  311 	xrl	a,r6
      003C6D F0               [24]  312 	movx	@dptr,a
      003C6E A3               [24]  313 	inc	dptr
      003C6F E0               [24]  314 	movx	a,@dptr
      003C70 6F               [12]  315 	xrl	a,r7
      003C71 F0               [24]  316 	movx	@dptr,a
                                    317 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C72 7F 00            [12]  318 	mov	r7,#0x00
      003C74                        319 00102$:
                                    320 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003C74 90 05 64         [24]  321 	mov	dptr,#_crc_byte_crc_10000_25
      003C77 12 38 64         [24]  322 	lcall	_ak820_outline_0080
      003C7A 30 E7 0E         [24]  323 	jnb	acc.7,00106$
      003C7D ED               [12]  324 	mov	a,r5
      003C7E 2D               [12]  325 	add	a,r5
      003C7F FB               [12]  326 	mov	r3,a
      003C80 EE               [12]  327 	mov	a,r6
      003C81 33               [12]  328 	rlc	a
      003C82 FC               [12]  329 	mov	r4,a
      003C83 63 03 21         [24]  330 	xrl	ar3,#0x21
      003C86 63 04 10         [24]  331 	xrl	ar4,#0x10
      003C89 80 06            [24]  332 	sjmp	00107$
      003C8B                        333 00106$:
      003C8B ED               [12]  334 	mov	a,r5
      003C8C 2D               [12]  335 	add	a,r5
      003C8D FB               [12]  336 	mov	r3,a
      003C8E EE               [12]  337 	mov	a,r6
      003C8F 33               [12]  338 	rlc	a
      003C90 FC               [12]  339 	mov	r4,a
      003C91                        340 00107$:
      003C91 90 05 64         [24]  341 	mov	dptr,#_crc_byte_crc_10000_25
      003C94 12 38 6A         [24]  342 	lcall	_ak820_outline_0086
                                    343 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C97 0F               [12]  344 	inc	r7
      003C98 BF 08 D9         [24]  345 	cjne	r7,#0x08,00102$
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C9B 12 33 FC         [24]  347 	lcall	_ak820_outline_0121
                                    348 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C9E 22               [24]  349 	ret
                                    350 ;------------------------------------------------------------
                                    351 ;Allocation info for local variables in function 'page_crc'
                                    352 ;------------------------------------------------------------
                                    353 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    354 ;i             Allocated with name '_page_crc_i_10000_30'
                                    355 ;------------------------------------------------------------
                                    356 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    357 ;	-----------------------------------------
                                    358 ;	 function page_crc
                                    359 ;	-----------------------------------------
      003C9F                        360 _page_crc:
                                    361 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C9F 90 05 66         [24]  362 	mov	dptr,#_page_crc_crc_10000_30
      003CA2 74 FF            [12]  363 	mov	a,#0xff
      003CA4 F0               [24]  364 	movx	@dptr,a
      003CA5 A3               [24]  365 	inc	dptr
      003CA6 F0               [24]  366 	movx	@dptr,a
                                    367 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003CA7 7F 00            [12]  368 	mov	r7,#0x00
      003CA9                        369 00102$:
      003CA9 90 05 66         [24]  370 	mov	dptr,#_page_crc_crc_10000_30
      003CAC 12 38 64         [24]  371 	lcall	_ak820_outline_0080
      003CAF 12 43 BD         [24]  372 	lcall	_ak820_outline_0105
      003CB2 90 05 63         [24]  373 	mov	dptr,#_crc_byte_PARM_2
      003CB5 F0               [24]  374 	movx	@dptr,a
      003CB6 12 38 A1         [24]  375 	lcall	_ak820_outline_0135
      003CB9 C0 07            [24]  376 	push	ar7
      003CBB 12 3C 58         [24]  377 	lcall	_crc_byte
      003CBE AD 82            [24]  378 	mov	r5, dpl
      003CC0 AE 83            [24]  379 	mov	r6, dph
      003CC2 D0 07            [24]  380 	pop	ar7
      003CC4 90 05 66         [24]  381 	mov	dptr,#_page_crc_crc_10000_30
      003CC7 12 43 EA         [24]  382 	lcall	_ak820_outline_0162
      003CCA 0F               [12]  383 	inc	r7
      003CCB BF 40 DB         [24]  384 	cjne	r7,#0x40,00102$
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003CCE 12 38 A1         [24]  386 	lcall	_ak820_outline_0135
                                    387 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003CD1 22               [24]  388 	ret
                                    389 ;------------------------------------------------------------
                                    390 ;Allocation info for local variables in function 'write_page'
                                    391 ;------------------------------------------------------------
                                    392 ;address       Allocated with name '_write_page_address_10000_32'
                                    393 ;i             Allocated with name '_write_page_i_10000_33'
                                    394 ;------------------------------------------------------------
                                    395 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    396 ;	-----------------------------------------
                                    397 ;	 function write_page
                                    398 ;	-----------------------------------------
      003CD2                        399 _write_page:
      003CD2 12 38 82         [24]  400 	lcall	_ak820_outline_0107
      003CD5 90 05 68         [24]  401 	mov	dptr,#_write_page_address_10000_32
      003CD8 12 38 87         [24]  402 	lcall	_ak820_outline_0108
                                    403 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003CDB 90 05 68         [24]  404 	mov	dptr,#_write_page_address_10000_32
      003CDE 12 37 F4         [24]  405 	lcall	_ak820_outline_0005
      003CE1 C0 07            [24]  406 	push	ar7
      003CE3 C0 06            [24]  407 	push	ar6
      003CE5 12 39 FC         [24]  408 	lcall	_ak820_flash_erase
      003CE8 E5 82            [12]  409 	mov	a, dpl
      003CEA D0 06            [24]  410 	pop	ar6
      003CEC D0 07            [24]  411 	pop	ar7
      003CEE 70 03            [24]  412 	jnz	00102$
      003CF0 F5 82            [12]  413 	mov	dpl,a
      003CF2 22               [24]  414 	ret
      003CF3                        415 00102$:
                                    416 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003CF3 90 04 F9         [24]  417 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003CF6 74 1D            [12]  418 	mov	a,#_page_data
      003CF8 F0               [24]  419 	movx	@dptr,a
      003CF9 74 05            [12]  420 	mov	a,#(_page_data >> 8)
      003CFB A3               [24]  421 	inc	dptr
      003CFC 12 43 AB         [24]  422 	lcall	_ak820_outline_0072
      003CFF 12 3B 10         [24]  423 	lcall	_ak820_flash_program_page
      003D02 E5 82            [12]  424 	mov	a, dpl
      003D04 70 03            [24]  425 	jnz	00120$
      003D06 F5 82            [12]  426 	mov	dpl,a
                                    427 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003D08 22               [24]  428 	ret
      003D09                        429 00120$:
      003D09 7F 00            [12]  430 	mov	r7,#0x00
      003D0B                        431 00108$:
                                    432 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003D0B 8F 05            [24]  433 	mov	ar5,r7
      003D0D 7E 00            [12]  434 	mov	r6,#0x00
      003D0F 90 05 68         [24]  435 	mov	dptr,#_write_page_address_10000_32
      003D12 12 38 91         [24]  436 	lcall	_ak820_outline_0123
      003D15 ED               [12]  437 	mov	a,r5
      003D16 2B               [12]  438 	add	a, r3
      003D17 FB               [12]  439 	mov	r3,a
      003D18 EE               [12]  440 	mov	a,r6
      003D19 3C               [12]  441 	addc	a, r4
      003D1A FC               [12]  442 	mov	r4,a
      003D1B 12 33 FC         [24]  443 	lcall	_ak820_outline_0121
      003D1E 12 38 EF         [24]  444 	lcall	_ak820_flash_read
      003D21 AE 82            [24]  445 	mov	r6, dpl
      003D23 12 43 BD         [24]  446 	lcall	_ak820_outline_0105
      003D26 FD               [12]  447 	mov	r5,a
      003D27 EE               [12]  448 	mov	a,r6
      003D28 B5 05 02         [24]  449 	cjne	a,ar5,00149$
      003D2B 80 04            [24]  450 	sjmp	00109$
      003D2D                        451 00149$:
      003D2D 75 82 00         [24]  452 	mov	dpl, #0x00
      003D30 22               [24]  453 	ret
      003D31                        454 00109$:
                                    455 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003D31 0F               [12]  456 	inc	r7
      003D32 BF 40 D6         [24]  457 	cjne	r7,#0x40,00108$
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003D35 75 82 01         [24]  459 	mov	dpl, #0x01
                                    460 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003D38 22               [24]  461 	ret
                                    462 ;------------------------------------------------------------
                                    463 ;Allocation info for local variables in function 'journal_header_valid'
                                    464 ;------------------------------------------------------------
                                    465 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    466 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    467 ;------------------------------------------------------------
                                    468 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    469 ;	-----------------------------------------
                                    470 ;	 function journal_header_valid
                                    471 ;	-----------------------------------------
      003D39                        472 _journal_header_valid:
      003D39 12 38 82         [24]  473 	lcall	_ak820_outline_0107
      003D3C 90 05 6A         [24]  474 	mov	dptr,#_journal_header_valid_header_10000_39
      003D3F 12 38 87         [24]  475 	lcall	_ak820_outline_0108
                                    476 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003D42 90 05 6A         [24]  477 	mov	dptr,#_journal_header_valid_header_10000_39
      003D45 12 37 F4         [24]  478 	lcall	_ak820_outline_0005
      003D48 E0               [24]  479 	movx	a,@dptr
      003D49 FD               [12]  480 	mov	r5,a
      003D4A BD A5 02         [24]  481 	cjne	r5,#0xa5,00138$
      003D4D 80 04            [24]  482 	sjmp	00116$
      003D4F                        483 00138$:
      003D4F 75 82 00         [24]  484 	mov	dpl, #0x00
                                    485 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D52 22               [24]  486 	ret
      003D53                        487 00116$:
      003D53 7D 01            [12]  488 	mov	r5,#0x01
      003D55                        489 00106$:
                                    490 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003D55 ED               [12]  491 	mov	a,r5
      003D56 12 38 31         [24]  492 	lcall	_ak820_outline_0023
      003D59 E0               [24]  493 	movx	a,@dptr
      003D5A FC               [12]  494 	mov	r4,a
      003D5B 8D 02            [24]  495 	mov	ar2,r5
      003D5D 7B 00            [12]  496 	mov	r3,#0x00
      003D5F 74 04            [12]  497 	mov	a,#0x04
      003D61 2A               [12]  498 	add	a, r2
      003D62 FA               [12]  499 	mov	r2,a
      003D63 E4               [12]  500 	clr	a
      003D64 3B               [12]  501 	addc	a, r3
      003D65 FB               [12]  502 	mov	r3,a
      003D66 EA               [12]  503 	mov	a,r2
      003D67 2E               [12]  504 	add	a, r6
      003D68 F5 82            [12]  505 	mov	dpl,a
      003D6A EB               [12]  506 	mov	a,r3
      003D6B 3F               [12]  507 	addc	a, r7
      003D6C F5 83            [12]  508 	mov	dph,a
      003D6E E0               [24]  509 	movx	a,@dptr
      003D6F 62 04            [12]  510 	xrl	ar4,a
      003D71 BC FF 02         [24]  511 	cjne	r4,#0xff,00139$
      003D74 80 04            [24]  512 	sjmp	00107$
      003D76                        513 00139$:
      003D76 75 82 00         [24]  514 	mov	dpl, #0x00
      003D79 22               [24]  515 	ret
      003D7A                        516 00107$:
                                    517 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D7A 0D               [12]  518 	inc	r5
      003D7B BD 05 D7         [24]  519 	cjne	r5,#0x05,00106$
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D7E 75 82 01         [24]  521 	mov	dpl, #0x01
                                    522 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D81 22               [24]  523 	ret
                                    524 ;------------------------------------------------------------
                                    525 ;Allocation info for local variables in function 'recover_journal'
                                    526 ;------------------------------------------------------------
                                    527 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    528 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    529 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    530 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    531 ;------------------------------------------------------------
                                    532 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    533 ;	-----------------------------------------
                                    534 ;	 function recover_journal
                                    535 ;	-----------------------------------------
      003D82                        536 _recover_journal:
                                    537 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D82 7F 00            [12]  538 	mov	r7,#0x00
      003D84                        539 00115$:
      003D84 EF               [12]  540 	mov	a,r7
      003D85 24 6C            [12]  541 	add	a, #_recover_journal_header_10000_46
      003D87 FD               [12]  542 	mov	r5,a
      003D88 E4               [12]  543 	clr	a
      003D89 34 05            [12]  544 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D8B FE               [12]  545 	mov	r6,a
      003D8C 8F 04            [24]  546 	mov	ar4,r7
      003D8E 7B 00            [12]  547 	mov	r3,#0x00
      003D90 74 40            [12]  548 	mov	a,#0x40
      003D92 2C               [12]  549 	add	a, r4
      003D93 FC               [12]  550 	mov	r4,a
      003D94 74 EF            [12]  551 	mov	a,#0xef
      003D96 3B               [12]  552 	addc	a, r3
      003D97 FB               [12]  553 	mov	r3,a
      003D98 12 43 F5         [24]  554 	lcall	_ak820_outline_0184
      003D9B 12 38 EF         [24]  555 	lcall	_ak820_flash_read
      003D9E AC 82            [24]  556 	mov	r4, dpl
      003DA0 12 43 A4         [24]  557 	lcall	_ak820_outline_0064
      003DA3 0F               [12]  558 	inc	r7
      003DA4 BF 09 DD         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003DA7 90 05 6C         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003DAA 12 3D 39         [24]  562 	lcall	_journal_header_valid
      003DAD E5 82            [12]  563 	mov	a, dpl
      003DAF 70 01            [24]  564 	jnz	00103$
      003DB1 22               [24]  565 	ret
      003DB2                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003DB2 90 05 6D         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003DB5 E0               [24]  569 	movx	a,@dptr
      003DB6 FF               [12]  570 	mov	r7,a
      003DB7 7E 00            [12]  571 	mov	r6,#0x00
      003DB9 90 05 6E         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003DBC E0               [24]  573 	movx	a,@dptr
      003DBD FC               [12]  574 	mov	r4,a
      003DBE E4               [12]  575 	clr	a
      003DBF 42 07            [12]  576 	orl	ar7,a
      003DC1 EC               [12]  577 	mov	a,r4
      003DC2 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003DC4 90 05 6F         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003DC7 E0               [24]  581 	movx	a,@dptr
      003DC8 FD               [12]  582 	mov	r5,a
      003DC9 7C 00            [12]  583 	mov	r4,#0x00
      003DCB 90 05 70         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003DCE E0               [24]  585 	movx	a,@dptr
      003DCF FA               [12]  586 	mov	r2,a
      003DD0 E4               [12]  587 	clr	a
      003DD1 12 43 D4         [24]  588 	lcall	_ak820_outline_0142
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003DD4 C3               [12]  590 	clr	c
      003DD5 EF               [12]  591 	mov	a,r7
      003DD6 94 A0            [12]  592 	subb	a,#0xa0
      003DD8 EE               [12]  593 	mov	a,r6
      003DD9 94 00            [12]  594 	subb	a,#0x00
      003DDB 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003DDD 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003DE0 02 3B F1         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003DE3                        601 00134$:
      003DE3 7B 00            [12]  602 	mov	r3,#0x00
      003DE5                        603 00117$:
      003DE5 C0 05            [24]  604 	push	ar5
      003DE7 C0 04            [24]  605 	push	ar4
      003DE9 EB               [12]  606 	mov	a,r3
      003DEA 24 1D            [12]  607 	add	a, #_page_data
      003DEC F9               [12]  608 	mov	r1,a
      003DED E4               [12]  609 	clr	a
      003DEE 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003DF0 FA               [12]  611 	mov	r2,a
      003DF1 8B 00            [24]  612 	mov	ar0,r3
      003DF3 7D 00            [12]  613 	mov	r5,#0x00
      003DF5 74 EF            [12]  614 	mov	a,#0xef
      003DF7 2D               [12]  615 	add	a, r5
      003DF8 FD               [12]  616 	mov	r5,a
      003DF9 88 82            [24]  617 	mov	dpl, r0
      003DFB 8D 83            [24]  618 	mov	dph, r5
      003DFD 12 38 EF         [24]  619 	lcall	_ak820_flash_read
      003E00 AD 82            [24]  620 	mov	r5, dpl
      003E02 12 43 F0         [24]  621 	lcall	_ak820_outline_0183
      003E05 ED               [12]  622 	mov	a,r5
      003E06 F0               [24]  623 	movx	@dptr,a
      003E07 0B               [12]  624 	inc	r3
      003E08 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      003E0B 80 06            [24]  626 	sjmp	00191$
      003E0D                        627 00190$:
      003E0D D0 04            [24]  628 	pop	ar4
      003E0F D0 05            [24]  629 	pop	ar5
      003E11 80 D2            [24]  630 	sjmp	00117$
      003E13                        631 00191$:
      003E13 D0 04            [24]  632 	pop	ar4
      003E15 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003E17 C0 07            [24]  635 	push	ar7
      003E19 C0 06            [24]  636 	push	ar6
      003E1B C0 05            [24]  637 	push	ar5
      003E1D C0 04            [24]  638 	push	ar4
      003E1F 12 3C 9F         [24]  639 	lcall	_page_crc
      003E22 AA 82            [24]  640 	mov	r2, dpl
      003E24 AB 83            [24]  641 	mov	r3, dph
      003E26 D0 04            [24]  642 	pop	ar4
      003E28 D0 05            [24]  643 	pop	ar5
      003E2A D0 06            [24]  644 	pop	ar6
      003E2C D0 07            [24]  645 	pop	ar7
      003E2E EA               [12]  646 	mov	a,r2
      003E2F B5 05 06         [24]  647 	cjne	a,ar5,00192$
      003E32 EB               [12]  648 	mov	a,r3
      003E33 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      003E36 80 06            [24]  650 	sjmp	00113$
      003E38                        651 00192$:
      003E38 75 82 02         [24]  652 	mov	dpl, #0x02
      003E3B 02 3B F1         [24]  653 	ljmp	_nvm_fail
      003E3E                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003E3E EE               [12]  656 	mov	a,r6
      003E3F 54 03            [12]  657 	anl	a,#0x03
      003E41 A2 E0            [12]  658 	mov	c,acc.0
      003E43 CF               [12]  659 	xch	a,r7
      003E44 13               [12]  660 	rrc	a
      003E45 CF               [12]  661 	xch	a,r7
      003E46 13               [12]  662 	rrc	a
      003E47 A2 E0            [12]  663 	mov	c,acc.0
      003E49 CF               [12]  664 	xch	a,r7
      003E4A 13               [12]  665 	rrc	a
      003E4B CF               [12]  666 	xch	a,r7
      003E4C 13               [12]  667 	rrc	a
      003E4D CF               [12]  668 	xch	a,r7
      003E4E 24 C7            [12]  669 	add	a,#0xc7
      003E50 FE               [12]  670 	mov	r6,a
      003E51 12 43 DF         [24]  671 	lcall	_ak820_outline_0158
      003E54 12 3C D2         [24]  672 	lcall	_write_page
      003E57 E5 82            [12]  673 	mov	a, dpl
      003E59 70 06            [24]  674 	jnz	00110$
      003E5B 75 82 03         [24]  675 	mov	dpl, #0x03
      003E5E 02 3B F1         [24]  676 	ljmp	_nvm_fail
      003E61                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003E61 90 EF 40         [24]  679 	mov	dptr,#0xef40
      003E64 12 39 FC         [24]  680 	lcall	_ak820_flash_erase
      003E67 E5 82            [12]  681 	mov	a, dpl
      003E69 70 06            [24]  682 	jnz	00119$
      003E6B 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003E6E 02 3B F1         [24]  685 	ljmp	_nvm_fail
      003E71                        686 00119$:
      003E71 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      003E72                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      003E72 C2 0B            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E74 90 05 5F         [24]  700 	mov	dptr,#_first_failure_stage
      003E77 E4               [12]  701 	clr	a
      003E78 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      003E79 C2 0A            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      003E7B C2 09            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E7D 90 05 5E         [24]  709 	mov	dptr,#_batch_depth
      003E80 E4               [12]  710 	clr	a
      003E81 F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E82 12 3D 82         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E85 02 2A 6B         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      003E88                        724 _ak820_nvm_ok:
      003E88 A2 0B            [12]  725 	mov	c,_storage_failed
      003E8A B3               [12]  726 	cpl	c
      003E8B 92 0C            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E8D 12 38 B1         [24]  728 	lcall	_ak820_outline_0156
      003E90 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      003E91                        737 _ak820_nvm_schema_fault:
      003E91 75 82 10         [24]  738 	mov	dpl, #0x10
      003E94 02 3B F1         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      003E97                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E97 30 0A 03         [24]  754 	jnb	_page_dirty,00101$
      003E9A 30 0B 01         [24]  755 	jnb	_storage_failed,00102$
      003E9D                        756 00101$:
      003E9D 22               [24]  757 	ret
      003E9E                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E9E 12 3C 9F         [24]  760 	lcall	_page_crc
      003EA1 12 43 C9         [24]  761 	lcall	_ak820_outline_0133
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003EA4 90 05 75         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003EA7 74 A5            [12]  764 	mov	a,#0xa5
      003EA9 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003EAA 90 05 5D         [24]  767 	mov	dptr,#_cached_page
      003EAD E0               [24]  768 	movx	a,@dptr
      003EAE 90 05 76         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003EB1 F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003EB2 90 05 77         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003EB5 E4               [12]  773 	clr	a
      003EB6 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003EB7 8E 05            [24]  776 	mov	ar5,r6
      003EB9 90 05 78         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003EBC ED               [12]  778 	mov	a,r5
      003EBD F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003EBE 8F 06            [24]  781 	mov	ar6,r7
      003EC0 90 05 79         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003EC3 EE               [12]  783 	mov	a,r6
      003EC4 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003EC5 7F 01            [12]  786 	mov	r7,#0x01
      003EC7                        787 00128$:
      003EC7 8F 06            [24]  788 	mov	ar6,r7
      003EC9 EE               [12]  789 	mov	a,r6
      003ECA 24 04            [12]  790 	add	a,#0x04
      003ECC FE               [12]  791 	mov	r6,a
      003ECD 33               [12]  792 	rlc	a
      003ECE 95 E0            [12]  793 	subb	a,acc
      003ED0 FD               [12]  794 	mov	r5,a
      003ED1 EE               [12]  795 	mov	a,r6
      003ED2 24 75            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      003ED4 FE               [12]  797 	mov	r6,a
      003ED5 ED               [12]  798 	mov	a,r5
      003ED6 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003ED8 FD               [12]  800 	mov	r5,a
      003ED9 12 43 87         [24]  801 	lcall	_ak820_outline_0045
      003EDC FC               [12]  802 	mov	r4,a
      003EDD 63 04 FF         [24]  803 	xrl	ar4,#0xff
      003EE0 8E 82            [24]  804 	mov	dpl,r6
      003EE2 8D 83            [24]  805 	mov	dph,r5
      003EE4 EC               [12]  806 	mov	a,r4
      003EE5 F0               [24]  807 	movx	@dptr,a
      003EE6 0F               [12]  808 	inc	r7
      003EE7 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003EEA 90 05 7E         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EED 74 05            [12]  812 	mov	a,#0x05
      003EEF F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003EF0 90 EF 40         [24]  815 	mov	dptr,#0xef40
      003EF3 12 39 FC         [24]  816 	lcall	_ak820_flash_erase
      003EF6 E5 82            [12]  817 	mov	a, dpl
      003EF8 70 03            [24]  818 	jnz	00269$
      003EFA 02 3F E0         [24]  819 	ljmp	00127$
      003EFD                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003EFD 90 05 7E         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F00 74 06            [12]  823 	mov	a,#0x06
      003F02 F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F03 7F 00            [12]  826 	mov	r7,#0x00
      003F05                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003F05 12 43 93         [24]  829 	lcall	_ak820_outline_0053
      003F08 12 38 EF         [24]  830 	lcall	_ak820_flash_read
      003F0B E5 82            [12]  831 	mov	a, dpl
      003F0D 60 03            [24]  832 	jz	00270$
      003F0F 02 3F E0         [24]  833 	ljmp	00127$
      003F12                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003F12 0F               [12]  836 	inc	r7
      003F13 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003F16 90 05 7E         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F19 74 07            [12]  840 	mov	a,#0x07
      003F1B F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003F1C 90 EF 00         [24]  843 	mov	dptr,#0xef00
      003F1F 12 3C D2         [24]  844 	lcall	_write_page
      003F22 E5 82            [12]  845 	mov	a, dpl
      003F24 70 03            [24]  846 	jnz	00273$
      003F26 02 3F E0         [24]  847 	ljmp	00127$
      003F29                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003F29 90 05 7E         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F2C 74 08            [12]  851 	mov	a,#0x08
      003F2E F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003F2F 7F 01            [12]  854 	mov	r7,#0x01
      003F31                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003F31 12 43 87         [24]  857 	lcall	_ak820_outline_0045
      003F34 FE               [12]  858 	mov	r6,a
      003F35 60 22            [24]  859 	jz	00133$
      003F37 8F 05            [24]  860 	mov	ar5,r7
      003F39 7C 00            [12]  861 	mov	r4,#0x00
      003F3B 74 40            [12]  862 	mov	a,#0x40
      003F3D 2D               [12]  863 	add	a, r5
      003F3E FD               [12]  864 	mov	r5,a
      003F3F 74 EF            [12]  865 	mov	a,#0xef
      003F41 3C               [12]  866 	addc	a, r4
      003F42 FC               [12]  867 	mov	r4,a
      003F43 90 04 F6         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      003F46 EE               [12]  869 	mov	a,r6
      003F47 F0               [24]  870 	movx	@dptr,a
      003F48 12 43 FA         [24]  871 	lcall	_ak820_outline_0189
      003F4B C0 07            [24]  872 	push	ar7
      003F4D 12 3A 5C         [24]  873 	lcall	_ak820_flash_program
      003F50 E5 82            [12]  874 	mov	a, dpl
      003F52 D0 07            [24]  875 	pop	ar7
      003F54 70 03            [24]  876 	jnz	00275$
      003F56 02 3F E0         [24]  877 	ljmp	00127$
      003F59                        878 00275$:
      003F59                        879 00133$:
                                    880 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003F59 0F               [12]  881 	inc	r7
      003F5A BF 09 D4         [24]  882 	cjne	r7,#0x09,00132$
                                    883 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003F5D 90 05 7E         [24]  884 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F60 74 09            [12]  885 	mov	a,#0x09
      003F62 F0               [24]  886 	movx	@dptr,a
                                    887 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F63 7F 01            [12]  888 	mov	r7,#0x01
      003F65                        889 00134$:
                                    890 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003F65 12 43 93         [24]  891 	lcall	_ak820_outline_0053
      003F68 12 38 EF         [24]  892 	lcall	_ak820_flash_read
      003F6B AE 82            [24]  893 	mov	r6, dpl
      003F6D 12 43 87         [24]  894 	lcall	_ak820_outline_0045
      003F70 FD               [12]  895 	mov	r5,a
      003F71 EE               [12]  896 	mov	a,r6
      003F72 B5 05 6B         [24]  897 	cjne	a,ar5,00127$
                                    898 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F75 0F               [12]  899 	inc	r7
      003F76 BF 09 EC         [24]  900 	cjne	r7,#0x09,00134$
                                    901 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F79 90 05 7E         [24]  902 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F7C 74 0A            [12]  903 	mov	a,#0x0a
      003F7E F0               [24]  904 	movx	@dptr,a
                                    905 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F7F 90 05 75         [24]  906 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F82 E0               [24]  907 	movx	a,@dptr
      003F83 90 04 F6         [24]  908 	mov	dptr,#_ak820_flash_program_PARM_2
      003F86 F0               [24]  909 	movx	@dptr,a
      003F87 90 EF 40         [24]  910 	mov	dptr,#0xef40
      003F8A 12 3A 5C         [24]  911 	lcall	_ak820_flash_program
      003F8D E5 82            [12]  912 	mov	a, dpl
      003F8F 60 4F            [24]  913 	jz	00127$
                                    914 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F91 90 05 7E         [24]  915 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F94 74 0B            [12]  916 	mov	a,#0x0b
      003F96 F0               [24]  917 	movx	@dptr,a
                                    918 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F97 90 EF 40         [24]  919 	mov	dptr,#0xef40
      003F9A 12 38 EF         [24]  920 	lcall	_ak820_flash_read
      003F9D AF 82            [24]  921 	mov	r7, dpl
      003F9F 90 05 75         [24]  922 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003FA2 E0               [24]  923 	movx	a,@dptr
      003FA3 FE               [12]  924 	mov	r6,a
      003FA4 EF               [12]  925 	mov	a,r7
      003FA5 B5 06 38         [24]  926 	cjne	a,ar6,00127$
                                    927 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003FA8 90 05 7E         [24]  928 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FAB 74 0C            [12]  929 	mov	a,#0x0c
      003FAD F0               [24]  930 	movx	@dptr,a
                                    931 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003FAE 90 05 5D         [24]  932 	mov	dptr,#_cached_page
      003FB1 E0               [24]  933 	movx	a,@dptr
      003FB2 FE               [12]  934 	mov	r6,a
      003FB3 E4               [12]  935 	clr	a
      003FB4 C3               [12]  936 	clr	c
      003FB5 CE               [12]  937 	xch	a,r6
      003FB6 13               [12]  938 	rrc	a
      003FB7 CE               [12]  939 	xch	a,r6
      003FB8 13               [12]  940 	rrc	a
      003FB9 A2 E0            [12]  941 	mov	c,acc.0
      003FBB CE               [12]  942 	xch	a,r6
      003FBC 13               [12]  943 	rrc	a
      003FBD CE               [12]  944 	xch	a,r6
      003FBE 13               [12]  945 	rrc	a
      003FBF CE               [12]  946 	xch	a,r6
      003FC0 24 C7            [12]  947 	add	a,#0xc7
      003FC2 FF               [12]  948 	mov	r7,a
      003FC3 12 38 8C         [24]  949 	lcall	_ak820_outline_0118
      003FC6 12 3C D2         [24]  950 	lcall	_write_page
      003FC9 E5 82            [12]  951 	mov	a, dpl
      003FCB 60 13            [24]  952 	jz	00127$
                                    953 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003FCD 90 05 7E         [24]  954 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FD0 74 0D            [12]  955 	mov	a,#0x0d
      003FD2 F0               [24]  956 	movx	@dptr,a
                                    957 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003FD3 90 EF 40         [24]  958 	mov	dptr,#0xef40
      003FD6 12 39 FC         [24]  959 	lcall	_ak820_flash_erase
      003FD9 E5 82            [12]  960 	mov	a, dpl
      003FDB 60 03            [24]  961 	jz	00127$
                                    962 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    963 ;	assignBit
      003FDD C2 0A            [12]  964 	clr	_page_dirty
                                    965 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003FDF 22               [24]  967 	ret
      003FE0                        968 00127$:
                                    969 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003FE0 90 05 7E         [24]  970 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003FE3 E0               [24]  971 	movx	a,@dptr
      003FE4 F5 82            [12]  972 	mov	dpl,a
                                    973 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003FE6 02 3B F1         [24]  974 	ljmp	_nvm_fail
                                    975 ;------------------------------------------------------------
                                    976 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    977 ;------------------------------------------------------------
                                    978 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function ak820_nvm_begin
                                    981 ;	-----------------------------------------
      003FE9                        982 _ak820_nvm_begin:
                                    983 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003FE9 90 05 5E         [24]  984 	mov	dptr,#_batch_depth
      003FEC E0               [24]  985 	movx	a,@dptr
      003FED FF               [12]  986 	mov	r7,a
      003FEE BF FF 06         [24]  987 	cjne	r7,#0xff,00102$
      003FF1 75 82 0F         [24]  988 	mov	dpl, #0x0f
      003FF4 02 3B F1         [24]  989 	ljmp	_nvm_fail
      003FF7                        990 00102$:
                                    991 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003FF7 90 05 5E         [24]  992 	mov	dptr,#_batch_depth
      003FFA EF               [12]  993 	mov	a,r7
      003FFB 04               [12]  994 	inc	a
      003FFC F0               [24]  995 	movx	@dptr,a
                                    996 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003FFD 22               [24]  997 	ret
                                    998 ;------------------------------------------------------------
                                    999 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1000 ;------------------------------------------------------------
                                   1001 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1002 ;	-----------------------------------------
                                   1003 ;	 function ak820_nvm_end
                                   1004 ;	-----------------------------------------
      003FFE                       1005 _ak820_nvm_end:
                                   1006 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003FFE 90 05 5E         [24] 1007 	mov	dptr,#_batch_depth
      004001 E0               [24] 1008 	movx	a,@dptr
      004002 FF               [12] 1009 	mov	r7,a
      004003 E0               [24] 1010 	movx	a,@dptr
      004004 60 06            [24] 1011 	jz	00102$
      004006 EF               [12] 1012 	mov	a,r7
      004007 14               [12] 1013 	dec	a
      004008 90 05 5E         [24] 1014 	mov	dptr,#_batch_depth
      00400B F0               [24] 1015 	movx	@dptr,a
      00400C                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      00400C 90 05 5E         [24] 1018 	mov	dptr,#_batch_depth
      00400F E0               [24] 1019 	movx	a,@dptr
      004010 70 03            [24] 1020 	jnz	00105$
                                   1021 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      004012 02 3E 97         [24] 1022 	ljmp	_ak820_nvm_flush
      004015                       1023 00105$:
      004015 22               [24] 1024 	ret
                                   1025 ;------------------------------------------------------------
                                   1026 ;Allocation info for local variables in function 'load_page'
                                   1027 ;------------------------------------------------------------
                                   1028 ;page          Allocated with name '_load_page_page_10000_87'
                                   1029 ;i             Allocated with name '_load_page_i_10000_88'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function load_page
                                   1034 ;	-----------------------------------------
      004016                       1035 _load_page:
      004016 E5 82            [12] 1036 	mov	a,dpl
      004018 90 05 7F         [24] 1037 	mov	dptr,#_load_page_page_10000_87
      00401B F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      00401C 30 09 17         [24] 1040 	jnb	_page_valid,00102$
      00401F 90 05 5D         [24] 1041 	mov	dptr,#_cached_page
      004022 E0               [24] 1042 	movx	a,@dptr
      004023 FF               [12] 1043 	mov	r7,a
      004024 90 05 7F         [24] 1044 	mov	dptr,#_load_page_page_10000_87
      004027 E0               [24] 1045 	movx	a,@dptr
      004028 FE               [12] 1046 	mov	r6,a
      004029 EF               [12] 1047 	mov	a,r7
      00402A B5 06 09         [24] 1048 	cjne	a,ar6,00102$
      00402D A2 0B            [12] 1049 	mov	c,_storage_failed
      00402F B3               [12] 1050 	cpl	c
      004030 92 0D            [24] 1051 	mov  _load_page_sloc0_1_0,c
      004032 12 38 B1         [24] 1052 	lcall	_ak820_outline_0156
      004035 22               [24] 1053 	ret
      004036                       1054 00102$:
                                   1055 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      004036 12 3E 97         [24] 1056 	lcall	_ak820_nvm_flush
                                   1057 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      004039 30 0B 04         [24] 1058 	jnb	_storage_failed,00119$
      00403C 75 82 00         [24] 1059 	mov	dpl, #0x00
                                   1060 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00403F 22               [24] 1061 	ret
      004040                       1062 00119$:
      004040 7F 00            [12] 1063 	mov	r7,#0x00
      004042                       1064 00107$:
                                   1065 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      004042 EF               [12] 1066 	mov	a,r7
      004043 24 1D            [12] 1067 	add	a, #_page_data
      004045 FD               [12] 1068 	mov	r5,a
      004046 E4               [12] 1069 	clr	a
      004047 34 05            [12] 1070 	addc	a, #(_page_data >> 8)
      004049 FE               [12] 1071 	mov	r6,a
      00404A 90 05 7F         [24] 1072 	mov	dptr,#_load_page_page_10000_87
      00404D E0               [24] 1073 	movx	a,@dptr
      00404E FC               [12] 1074 	mov	r4,a
      00404F FA               [12] 1075 	mov	r2,a
      004050 E4               [12] 1076 	clr	a
      004051 C3               [12] 1077 	clr	c
      004052 CA               [12] 1078 	xch	a,r2
      004053 13               [12] 1079 	rrc	a
      004054 CA               [12] 1080 	xch	a,r2
      004055 13               [12] 1081 	rrc	a
      004056 A2 E0            [12] 1082 	mov	c,acc.0
      004058 CA               [12] 1083 	xch	a,r2
      004059 13               [12] 1084 	rrc	a
      00405A CA               [12] 1085 	xch	a,r2
      00405B 13               [12] 1086 	rrc	a
      00405C CA               [12] 1087 	xch	a,r2
      00405D 24 C7            [12] 1088 	add	a,#0xc7
      00405F FB               [12] 1089 	mov	r3,a
      004060 8F 01            [24] 1090 	mov	ar1,r7
      004062 89 00            [24] 1091 	mov	ar0,r1
      004064 79 00            [12] 1092 	mov	r1,#0x00
      004066 E8               [12] 1093 	mov	a,r0
      004067 2A               [12] 1094 	add	a, r2
      004068 FA               [12] 1095 	mov	r2,a
      004069 E9               [12] 1096 	mov	a,r1
      00406A 3B               [12] 1097 	addc	a, r3
      00406B FB               [12] 1098 	mov	r3,a
      00406C 12 38 AC         [24] 1099 	lcall	_ak820_outline_0143
      00406F 12 38 EF         [24] 1100 	lcall	_ak820_flash_read
      004072 AB 82            [24] 1101 	mov	r3, dpl
      004074 12 38 A1         [24] 1102 	lcall	_ak820_outline_0135
      004077 EB               [12] 1103 	mov	a,r3
      004078 F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004079 0F               [12] 1106 	inc	r7
      00407A BF 40 C5         [24] 1107 	cjne	r7,#0x40,00107$
                                   1108 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00407D 90 05 5D         [24] 1109 	mov	dptr,#_cached_page
      004080 EC               [12] 1110 	mov	a,r4
      004081 F0               [24] 1111 	movx	@dptr,a
                                   1112 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1113 ;	assignBit
      004082 D2 09            [12] 1114 	setb	_page_valid
                                   1115 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004084 75 82 01         [24] 1116 	mov	dpl, #0x01
                                   1117 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004087 22               [24] 1118 	ret
                                   1119 ;------------------------------------------------------------
                                   1120 ;Allocation info for local variables in function 'read_offset'
                                   1121 ;------------------------------------------------------------
                                   1122 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1123 ;------------------------------------------------------------
                                   1124 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1125 ;	-----------------------------------------
                                   1126 ;	 function read_offset
                                   1127 ;	-----------------------------------------
      004088                       1128 _read_offset:
      004088 12 38 82         [24] 1129 	lcall	_ak820_outline_0107
      00408B 90 05 80         [24] 1130 	mov	dptr,#_read_offset_offset_10000_93
      00408E 12 38 87         [24] 1131 	lcall	_ak820_outline_0108
                                   1132 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      004091 90 05 80         [24] 1133 	mov	dptr,#_read_offset_offset_10000_93
      004094 12 38 41         [24] 1134 	lcall	_ak820_outline_0052
      004097 C3               [12] 1135 	clr	c
      004098 94 28            [12] 1136 	subb	a,#0x28
      00409A 40 04            [24] 1137 	jc	00102$
      00409C 75 82 00         [24] 1138 	mov	dpl, #0x00
      00409F 22               [24] 1139 	ret
      0040A0                       1140 00102$:
                                   1141 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      0040A0 30 09 34         [24] 1142 	jnb	_page_valid,00104$
      0040A3 8E 04            [24] 1143 	mov	ar4,r6
      0040A5 EF               [12] 1144 	mov	a,r7
      0040A6 A2 E7            [12] 1145 	mov	c,acc.7
      0040A8 CC               [12] 1146 	xch	a,r4
      0040A9 33               [12] 1147 	rlc	a
      0040AA CC               [12] 1148 	xch	a,r4
      0040AB 33               [12] 1149 	rlc	a
      0040AC A2 E7            [12] 1150 	mov	c,acc.7
      0040AE CC               [12] 1151 	xch	a,r4
      0040AF 33               [12] 1152 	rlc	a
      0040B0 CC               [12] 1153 	xch	a,r4
      0040B1 33               [12] 1154 	rlc	a
      0040B2 CC               [12] 1155 	xch	a,r4
      0040B3 54 03            [12] 1156 	anl	a,#0x03
      0040B5 FD               [12] 1157 	mov	r5,a
      0040B6 90 05 5D         [24] 1158 	mov	dptr,#_cached_page
      0040B9 E0               [24] 1159 	movx	a,@dptr
      0040BA FA               [12] 1160 	mov	r2,a
      0040BB 7B 00            [12] 1161 	mov	r3,#0x00
      0040BD EC               [12] 1162 	mov	a,r4
      0040BE B5 02 16         [24] 1163 	cjne	a,ar2,00104$
      0040C1 ED               [12] 1164 	mov	a,r5
      0040C2 B5 03 12         [24] 1165 	cjne	a,ar3,00104$
                                   1166 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      0040C5 74 3F            [12] 1167 	mov	a,#0x3f
      0040C7 5E               [12] 1168 	anl	a,r6
      0040C8 7D 00            [12] 1169 	mov	r5,#0x00
      0040CA 24 1D            [12] 1170 	add	a, #_page_data
      0040CC F5 82            [12] 1171 	mov	dpl,a
      0040CE ED               [12] 1172 	mov	a,r5
      0040CF 34 05            [12] 1173 	addc	a, #(_page_data >> 8)
      0040D1 F5 83            [12] 1174 	mov	dph,a
      0040D3 E0               [24] 1175 	movx	a,@dptr
      0040D4 F5 82            [12] 1176 	mov	dpl,a
      0040D6 22               [24] 1177 	ret
      0040D7                       1178 00104$:
                                   1179 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      0040D7 74 C7            [12] 1180 	mov	a,#0xc7
      0040D9 2F               [12] 1181 	add	a, r7
      0040DA FF               [12] 1182 	mov	r7,a
      0040DB 12 38 8C         [24] 1183 	lcall	_ak820_outline_0118
                                   1184 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      0040DE 02 38 EF         [24] 1185 	ljmp	_ak820_flash_read
                                   1186 ;------------------------------------------------------------
                                   1187 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1188 ;------------------------------------------------------------
                                   1189 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1190 ;------------------------------------------------------------
                                   1191 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1192 ;	-----------------------------------------
                                   1193 ;	 function eeprom_read_byte
                                   1194 ;	-----------------------------------------
      0040E1                       1195 _eeprom_read_byte:
      0040E1 C0 07            [24] 1196 	push	ar7
      0040E3 C0 06            [24] 1197 	push	ar6
      0040E5 12 43 80         [24] 1198 	lcall	_ak820_outline_0038
      0040E8 90 05 82         [24] 1199 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040EB 12 38 29         [24] 1200 	lcall	_ak820_outline_0018
                                   1201 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      0040EE 90 05 82         [24] 1202 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      0040F1 12 37 F4         [24] 1203 	lcall	_ak820_outline_0005
      0040F4 C0 06            [24] 1204 	push	ar6
      0040F6 C0 05            [24] 1205 	push	ar5
      0040F8 C0 04            [24] 1206 	push	ar4
      0040FA C0 03            [24] 1207 	push	ar3
      0040FC C0 02            [24] 1208 	push	ar2
      0040FE C0 01            [24] 1209 	push	ar1
      004100 C0 00            [24] 1210 	push	ar0
      004102 12 40 88         [24] 1211 	lcall	_read_offset
      004105 AF 82            [24] 1212 	mov	r7, dpl
      004107 D0 00            [24] 1213 	pop	ar0
      004109 D0 01            [24] 1214 	pop	ar1
      00410B D0 02            [24] 1215 	pop	ar2
      00410D D0 03            [24] 1216 	pop	ar3
      00410F D0 04            [24] 1217 	pop	ar4
      004111 D0 05            [24] 1218 	pop	ar5
      004113 D0 06            [24] 1219 	pop	ar6
      004115 8F 82            [24] 1220 	mov	dpl, r7
                                   1221 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      004117 D0 06            [24] 1222 	pop	ar6
      004119 D0 07            [24] 1223 	pop	ar7
      00411B 22               [24] 1224 	ret
                                   1225 ;------------------------------------------------------------
                                   1226 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1227 ;------------------------------------------------------------
                                   1228 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1229 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1230 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1231 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1232 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1233 ;------------------------------------------------------------
                                   1234 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1235 ;	-----------------------------------------
                                   1236 ;	 function ak820_eeprom_read_block_xdata
                                   1237 ;	-----------------------------------------
      00411C                       1238 _ak820_eeprom_read_block_xdata:
      00411C 12 38 82         [24] 1239 	lcall	_ak820_outline_0107
      00411F 90 05 8A         [24] 1240 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      004122 12 38 87         [24] 1241 	lcall	_ak820_outline_0108
                                   1242 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004125 90 05 85         [24] 1243 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004128 12 38 41         [24] 1244 	lcall	_ak820_outline_0052
                                   1245 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      00412B 90 05 8A         [24] 1246 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      00412E 12 38 58         [24] 1247 	lcall	_ak820_outline_0060
      004131 90 05 8C         [24] 1248 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004134 12 38 5E         [24] 1249 	lcall	_ak820_outline_0073
                                   1250 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      004137 90 05 88         [24] 1251 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      00413A 12 38 58         [24] 1252 	lcall	_ak820_outline_0060
      00413D                       1253 00103$:
      00413D 8C 02            [24] 1254 	mov	ar2,r4
      00413F 8D 03            [24] 1255 	mov	ar3,r5
      004141 1C               [12] 1256 	dec	r4
      004142 BC FF 01         [24] 1257 	cjne	r4,#0xff,00130$
      004145 1D               [12] 1258 	dec	r5
      004146                       1259 00130$:
      004146 EA               [12] 1260 	mov	a,r2
      004147 4B               [12] 1261 	orl	a,r3
      004148 60 5D            [24] 1262 	jz	00106$
                                   1263 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      00414A 8E 02            [24] 1264 	mov	ar2,r6
      00414C 8F 03            [24] 1265 	mov	ar3,r7
      00414E 74 D8            [12] 1266 	mov	a,#0x100 - 0x28
      004150 2B               [12] 1267 	add	a,r3
      004151 50 17            [24] 1268 	jnc	00102$
      004153 90 05 8C         [24] 1269 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004156 12 43 B7         [24] 1270 	lcall	_ak820_outline_0104
      004159 12 38 AC         [24] 1271 	lcall	_ak820_outline_0143
      00415C E4               [12] 1272 	clr	a
      00415D F0               [24] 1273 	movx	@dptr,a
      00415E 90 05 8C         [24] 1274 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004161 04               [12] 1275 	inc	a
      004162 2A               [12] 1276 	add	a, r2
      004163 F0               [24] 1277 	movx	@dptr,a
      004164 E4               [12] 1278 	clr	a
      004165 3B               [12] 1279 	addc	a, r3
      004166 A3               [24] 1280 	inc	dptr
      004167 F0               [24] 1281 	movx	@dptr,a
      004168 80 D3            [24] 1282 	sjmp	00103$
      00416A                       1283 00102$:
                                   1284 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      00416A 90 05 8C         [24] 1285 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      00416D 12 43 B7         [24] 1286 	lcall	_ak820_outline_0104
      004170 12 38 8C         [24] 1287 	lcall	_ak820_outline_0118
      004173 C0 07            [24] 1288 	push	ar7
      004175 C0 06            [24] 1289 	push	ar6
      004177 C0 05            [24] 1290 	push	ar5
      004179 C0 04            [24] 1291 	push	ar4
      00417B C0 03            [24] 1292 	push	ar3
      00417D C0 02            [24] 1293 	push	ar2
      00417F 12 40 88         [24] 1294 	lcall	_read_offset
      004182 A9 82            [24] 1295 	mov	r1, dpl
      004184 D0 02            [24] 1296 	pop	ar2
      004186 D0 03            [24] 1297 	pop	ar3
      004188 D0 04            [24] 1298 	pop	ar4
      00418A D0 05            [24] 1299 	pop	ar5
      00418C D0 06            [24] 1300 	pop	ar6
      00418E D0 07            [24] 1301 	pop	ar7
      004190 12 38 AC         [24] 1302 	lcall	_ak820_outline_0143
      004193 E9               [12] 1303 	mov	a,r1
      004194 F0               [24] 1304 	movx	@dptr,a
      004195 90 05 8C         [24] 1305 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004198 74 01            [12] 1306 	mov	a,#0x01
      00419A 2A               [12] 1307 	add	a, r2
      00419B F0               [24] 1308 	movx	@dptr,a
      00419C E4               [12] 1309 	clr	a
      00419D 3B               [12] 1310 	addc	a, r3
      00419E A3               [24] 1311 	inc	dptr
      00419F F0               [24] 1312 	movx	@dptr,a
                                   1313 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      0041A0 0E               [12] 1314 	inc	r6
      0041A1 BE 00 99         [24] 1315 	cjne	r6,#0x00,00103$
      0041A4 0F               [12] 1316 	inc	r7
      0041A5 80 96            [24] 1317 	sjmp	00103$
      0041A7                       1318 00106$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      0041A7 22               [24] 1320 	ret
                                   1321 ;------------------------------------------------------------
                                   1322 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1323 ;------------------------------------------------------------
                                   1324 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1325 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1326 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1327 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1328 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1329 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1330 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_eeprom_write_block_xdata
                                   1335 ;	-----------------------------------------
      0041A8                       1336 _ak820_eeprom_write_block_xdata:
      0041A8 12 38 82         [24] 1337 	lcall	_ak820_outline_0107
      0041AB 90 05 93         [24] 1338 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0041AE 12 38 87         [24] 1339 	lcall	_ak820_outline_0108
                                   1340 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0041B1 90 05 8E         [24] 1341 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      0041B4 12 38 41         [24] 1342 	lcall	_ak820_outline_0052
                                   1343 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      0041B7 90 05 93         [24] 1344 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      0041BA 12 38 58         [24] 1345 	lcall	_ak820_outline_0060
                                   1346 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      0041BD 8E 02            [24] 1347 	mov	ar2,r6
      0041BF 8F 03            [24] 1348 	mov	ar3,r7
      0041C1 C3               [12] 1349 	clr	c
      0041C2 E4               [12] 1350 	clr	a
      0041C3 9A               [12] 1351 	subb	a,r2
      0041C4 74 28            [12] 1352 	mov	a,#0x28
      0041C6 9B               [12] 1353 	subb	a,r3
      0041C7 40 15            [24] 1354 	jc	00101$
                                   1355 ;	free result
      0041C9 E4               [12] 1356 	clr	a
      0041CA C3               [12] 1357 	clr	c
      0041CB 9E               [12] 1358 	subb	a,r6
      0041CC FA               [12] 1359 	mov	r2,a
      0041CD 74 28            [12] 1360 	mov	a,#0x28
      0041CF 9F               [12] 1361 	subb	a,r7
      0041D0 FB               [12] 1362 	mov	r3,a
      0041D1 90 05 91         [24] 1363 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0041D4 12 38 7C         [24] 1364 	lcall	_ak820_outline_0103
      0041D7 C3               [12] 1365 	clr	c
      0041D8 EA               [12] 1366 	mov	a,r2
      0041D9 98               [12] 1367 	subb	a,r0
      0041DA EB               [12] 1368 	mov	a,r3
      0041DB 99               [12] 1369 	subb	a,r1
      0041DC 50 06            [24] 1370 	jnc	00125$
                                   1371 ;	free result
      0041DE                       1372 00101$:
                                   1373 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      0041DE 75 82 0E         [24] 1374 	mov	dpl, #0x0e
                                   1375 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      0041E1 02 3B F1         [24] 1376 	ljmp	_nvm_fail
                                   1377 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      0041E4                       1378 00125$:
      0041E4 90 05 91         [24] 1379 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0041E7 12 43 B7         [24] 1380 	lcall	_ak820_outline_0104
      0041EA                       1381 00108$:
      0041EA 8A 00            [24] 1382 	mov	ar0,r2
      0041EC 8B 01            [24] 1383 	mov	ar1,r3
      0041EE 1A               [12] 1384 	dec	r2
      0041EF BA FF 01         [24] 1385 	cjne	r2,#0xff,00159$
      0041F2 1B               [12] 1386 	dec	r3
      0041F3                       1387 00159$:
      0041F3 E8               [12] 1388 	mov	a,r0
      0041F4 49               [12] 1389 	orl	a,r1
      0041F5 70 03            [24] 1390 	jnz	00160$
      0041F7 02 42 81         [24] 1391 	ljmp	00110$
      0041FA                       1392 00160$:
                                   1393 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      0041FA C0 02            [24] 1394 	push	ar2
      0041FC C0 03            [24] 1395 	push	ar3
      0041FE 12 43 B1         [24] 1396 	lcall	_ak820_outline_0096
      004201 F9               [12] 1397 	mov	r1,a
      004202 A3               [24] 1398 	inc	dptr
      004203 12 43 DA         [24] 1399 	lcall	_ak820_outline_0149
                                   1400 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004206 8E 0C            [24] 1401 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004208 8F 0D            [24] 1402 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      00420A A8 0C            [24] 1403 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00420C E5 0D            [12] 1404 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00420E A2 E7            [12] 1405 	mov	c,acc.7
      004210 C8               [12] 1406 	xch	a,r0
      004211 33               [12] 1407 	rlc	a
      004212 C8               [12] 1408 	xch	a,r0
      004213 33               [12] 1409 	rlc	a
      004214 A2 E7            [12] 1410 	mov	c,acc.7
      004216 C8               [12] 1411 	xch	a,r0
      004217 33               [12] 1412 	rlc	a
      004218 C8               [12] 1413 	xch	a,r0
      004219 33               [12] 1414 	rlc	a
      00421A C8               [12] 1415 	xch	a,r0
      00421B 54 03            [12] 1416 	anl	a,#0x03
      00421D FB               [12] 1417 	mov	r3,a
      00421E 88 82            [24] 1418 	mov	dpl, r0
      004220 C0 07            [24] 1419 	push	ar7
      004222 C0 06            [24] 1420 	push	ar6
      004224 C0 05            [24] 1421 	push	ar5
      004226 C0 04            [24] 1422 	push	ar4
      004228 C0 03            [24] 1423 	push	ar3
      00422A C0 02            [24] 1424 	push	ar2
      00422C C0 01            [24] 1425 	push	ar1
      00422E 12 40 16         [24] 1426 	lcall	_load_page
      004231 E5 82            [12] 1427 	mov	a, dpl
      004233 D0 01            [24] 1428 	pop	ar1
      004235 D0 02            [24] 1429 	pop	ar2
      004237 D0 03            [24] 1430 	pop	ar3
      004239 D0 04            [24] 1431 	pop	ar4
      00423B D0 05            [24] 1432 	pop	ar5
      00423D D0 06            [24] 1433 	pop	ar6
      00423F D0 07            [24] 1434 	pop	ar7
      004241 D0 03            [24] 1435 	pop	ar3
      004243 D0 02            [24] 1436 	pop	ar2
      004245 70 01            [24] 1437 	jnz	00105$
      004247 22               [24] 1438 	ret
      004248                       1439 00105$:
                                   1440 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      004248 C0 06            [24] 1441 	push	ar6
      00424A C0 07            [24] 1442 	push	ar7
      00424C 74 3F            [12] 1443 	mov	a,#0x3f
      00424E 55 0C            [12] 1444 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004250 7F 00            [12] 1445 	mov	r7,#0x00
      004252 24 1D            [12] 1446 	add	a, #_page_data
      004254 F5 0C            [12] 1447 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      004256 EF               [12] 1448 	mov	a,r7
      004257 34 05            [12] 1449 	addc	a, #(_page_data >> 8)
      004259 F5 0D            [12] 1450 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      00425B 85 0C 82         [24] 1451 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00425E 85 0D 83         [24] 1452 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004261 E0               [24] 1453 	movx	a,@dptr
      004262 B5 01 06         [24] 1454 	cjne	a,ar1,00162$
      004265 D0 07            [24] 1455 	pop	ar7
      004267 D0 06            [24] 1456 	pop	ar6
      004269 80 0E            [24] 1457 	sjmp	00107$
      00426B                       1458 00162$:
      00426B D0 07            [24] 1459 	pop	ar7
      00426D D0 06            [24] 1460 	pop	ar6
                                   1461 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      00426F 85 0C 82         [24] 1462 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004272 85 0D 83         [24] 1463 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004275 E9               [12] 1464 	mov	a,r1
      004276 F0               [24] 1465 	movx	@dptr,a
                                   1466 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1467 ;	assignBit
      004277 D2 0A            [12] 1468 	setb	_page_dirty
      004279                       1469 00107$:
                                   1470 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004279 0E               [12] 1471 	inc	r6
      00427A BE 00 01         [24] 1472 	cjne	r6,#0x00,00163$
      00427D 0F               [12] 1473 	inc	r7
      00427E                       1474 00163$:
      00427E 02 41 EA         [24] 1475 	ljmp	00108$
      004281                       1476 00110$:
                                   1477 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      004281 90 05 5E         [24] 1478 	mov	dptr,#_batch_depth
      004284 E0               [24] 1479 	movx	a,@dptr
      004285 70 03            [24] 1480 	jnz	00113$
                                   1481 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004287 02 3E 97         [24] 1482 	ljmp	_ak820_nvm_flush
      00428A                       1483 00113$:
      00428A 22               [24] 1484 	ret
                                   1485 ;------------------------------------------------------------
                                   1486 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1487 ;------------------------------------------------------------
                                   1488 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1489 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1490 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1491 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1492 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1493 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1494 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1495 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1496 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1497 ;------------------------------------------------------------
                                   1498 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1499 ;	-----------------------------------------
                                   1500 ;	 function ak820_eeprom_update_block_xdata
                                   1501 ;	-----------------------------------------
      00428B                       1502 _ak820_eeprom_update_block_xdata:
      00428B 12 38 82         [24] 1503 	lcall	_ak820_outline_0107
      00428E 90 05 9A         [24] 1504 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004291 12 38 87         [24] 1505 	lcall	_ak820_outline_0108
                                   1506 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004294 90 05 9A         [24] 1507 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004297 12 38 41         [24] 1508 	lcall	_ak820_outline_0052
                                   1509 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00429A 90 05 95         [24] 1510 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00429D E0               [24] 1511 	movx	a,@dptr
      00429E F5 12            [12] 1512 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      0042A0 A3               [24] 1513 	inc	dptr
      0042A1 E0               [24] 1514 	movx	a,@dptr
      0042A2 F5 13            [12] 1515 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      0042A4 A3               [24] 1516 	inc	dptr
      0042A5 E0               [24] 1517 	movx	a,@dptr
      0042A6 F5 14            [12] 1518 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      0042A8 A9 12            [24] 1519 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      0042AA AA 13            [24] 1520 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1521 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042AC E4               [12] 1522 	clr	a
      0042AD F5 0E            [12] 1523 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      0042AF F5 0F            [12] 1524 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      0042B1                       1525 00105$:
      0042B1 90 05 98         [24] 1526 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      0042B4 E0               [24] 1527 	movx	a,@dptr
      0042B5 F5 10            [12] 1528 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      0042B7 A3               [24] 1529 	inc	dptr
      0042B8 E0               [24] 1530 	movx	a,@dptr
      0042B9 F5 11            [12] 1531 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      0042BB C3               [12] 1532 	clr	c
      0042BC E5 0E            [12] 1533 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042BE 95 10            [12] 1534 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042C0 E5 0F            [12] 1535 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042C2 95 11            [12] 1536 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042C4 50 68            [24] 1537 	jnc	00107$
                                   1538 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      0042C6 89 00            [24] 1539 	mov	ar0,r1
      0042C8 8A 05            [24] 1540 	mov	ar5,r2
      0042CA E5 0E            [12] 1541 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042CC 28               [12] 1542 	add	a, r0
      0042CD F8               [12] 1543 	mov	r0,a
      0042CE E5 0F            [12] 1544 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042D0 3D               [12] 1545 	addc	a, r5
      0042D1 FD               [12] 1546 	mov	r5,a
      0042D2 88 82            [24] 1547 	mov	dpl, r0
      0042D4 8D 83            [24] 1548 	mov	dph, r5
      0042D6 C0 07            [24] 1549 	push	ar7
      0042D8 C0 06            [24] 1550 	push	ar6
      0042DA C0 02            [24] 1551 	push	ar2
      0042DC C0 01            [24] 1552 	push	ar1
      0042DE 12 40 88         [24] 1553 	lcall	_read_offset
      0042E1 AD 82            [24] 1554 	mov	r5, dpl
      0042E3 D0 01            [24] 1555 	pop	ar1
      0042E5 D0 02            [24] 1556 	pop	ar2
      0042E7 D0 06            [24] 1557 	pop	ar6
      0042E9 D0 07            [24] 1558 	pop	ar7
      0042EB E5 0E            [12] 1559 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042ED 2E               [12] 1560 	add	a, r6
      0042EE F5 82            [12] 1561 	mov	dpl,a
      0042F0 E5 0F            [12] 1562 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042F2 3F               [12] 1563 	addc	a, r7
      0042F3 F5 83            [12] 1564 	mov	dph,a
      0042F5 E0               [24] 1565 	movx	a,@dptr
      0042F6 FC               [12] 1566 	mov	r4,a
      0042F7 ED               [12] 1567 	mov	a,r5
      0042F8 B5 04 02         [24] 1568 	cjne	a,ar4,00131$
      0042FB 80 27            [24] 1569 	sjmp	00106$
      0042FD                       1570 00131$:
                                   1571 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      0042FD 90 05 9A         [24] 1572 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004300 E0               [24] 1573 	movx	a,@dptr
      004301 F8               [12] 1574 	mov	r0,a
      004302 A3               [24] 1575 	inc	dptr
      004303 E0               [24] 1576 	movx	a,@dptr
      004304 FD               [12] 1577 	mov	r5,a
      004305 90 05 8E         [24] 1578 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004308 E5 12            [12] 1579 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      00430A F0               [24] 1580 	movx	@dptr,a
      00430B E5 13            [12] 1581 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00430D A3               [24] 1582 	inc	dptr
      00430E F0               [24] 1583 	movx	@dptr,a
      00430F E5 14            [12] 1584 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      004311 A3               [24] 1585 	inc	dptr
      004312 F0               [24] 1586 	movx	@dptr,a
      004313 90 05 91         [24] 1587 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004316 E5 10            [12] 1588 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      004318 F0               [24] 1589 	movx	@dptr,a
      004319 E5 11            [12] 1590 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      00431B A3               [24] 1591 	inc	dptr
      00431C F0               [24] 1592 	movx	@dptr,a
      00431D 88 82            [24] 1593 	mov	dpl, r0
      00431F 8D 83            [24] 1594 	mov	dph, r5
                                   1595 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      004321 02 41 A8         [24] 1596 	ljmp	_ak820_eeprom_write_block_xdata
      004324                       1597 00106$:
                                   1598 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      004324 05 0E            [12] 1599 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      004326 E4               [12] 1600 	clr	a
      004327 B5 0E 87         [24] 1601 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      00432A 05 0F            [12] 1602 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00432C 80 83            [24] 1603 	sjmp	00105$
      00432E                       1604 00107$:
                                   1605 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      00432E 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1609 ;------------------------------------------------------------
                                   1610 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1611 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1612 ;------------------------------------------------------------
                                   1613 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1614 ;	-----------------------------------------
                                   1615 ;	 function eeprom_driver_erase
                                   1616 ;	-----------------------------------------
      00432F                       1617 _eeprom_driver_erase:
                                   1618 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      00432F 12 3E 97         [24] 1619 	lcall	_ak820_nvm_flush
                                   1620 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      004332 7F 00            [12] 1621 	mov	r7,#0x00
      004334                       1622 00111$:
      004334 BF A0 01         [24] 1623 	cjne	r7,#0xa0,00165$
      004337 22               [24] 1624 	ret
      004338                       1625 00165$:
      004338 20 0B 32         [24] 1626 	jb	_storage_failed,00113$
                                   1627 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      00433B 8F 82            [24] 1628 	mov	dpl, r7
      00433D C0 07            [24] 1629 	push	ar7
      00433F 12 40 16         [24] 1630 	lcall	_load_page
      004342 E5 82            [12] 1631 	mov	a, dpl
      004344 D0 07            [24] 1632 	pop	ar7
      004346 70 01            [24] 1633 	jnz	00126$
                                   1634 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004348 22               [24] 1635 	ret
      004349                       1636 00126$:
      004349 7E 00            [12] 1637 	mov	r6,#0x00
      00434B                       1638 00107$:
                                   1639 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      00434B EE               [12] 1640 	mov	a,r6
      00434C 24 1D            [12] 1641 	add	a, #_page_data
      00434E FC               [12] 1642 	mov	r4,a
      00434F E4               [12] 1643 	clr	a
      004350 34 05            [12] 1644 	addc	a, #(_page_data >> 8)
      004352 FD               [12] 1645 	mov	r5,a
      004353 12 43 B1         [24] 1646 	lcall	_ak820_outline_0096
      004356 60 07            [24] 1647 	jz	00108$
      004358 12 38 97         [24] 1648 	lcall	_ak820_outline_0124
      00435B E4               [12] 1649 	clr	a
      00435C F0               [24] 1650 	movx	@dptr,a
                                   1651 ;	assignBit
      00435D D2 0A            [12] 1652 	setb	_page_dirty
      00435F                       1653 00108$:
                                   1654 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      00435F 0E               [12] 1655 	inc	r6
      004360 BE 40 E8         [24] 1656 	cjne	r6,#0x40,00107$
                                   1657 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      004363 C0 07            [24] 1658 	push	ar7
      004365 12 3E 97         [24] 1659 	lcall	_ak820_nvm_flush
      004368 D0 07            [24] 1660 	pop	ar7
                                   1661 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      00436A 0F               [12] 1662 	inc	r7
      00436B 80 C7            [24] 1663 	sjmp	00111$
      00436D                       1664 00113$:
                                   1665 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      00436D 22               [24] 1666 	ret
                                   1667 	.area CSEG    (CODE)
                                   1668 	.area CONST   (CODE)
                                   1669 	.area XINIT   (CODE)
                                   1670 	.area CABS    (ABS,CODE)
                                   1671 
                                   1672 ; Experimental exact instruction outlining.
                                   1673 	.globl _ak820_outline_0005
                                   1674 	.globl _ak820_outline_0012
                                   1675 	.globl _ak820_outline_0018
                                   1676 	.globl _ak820_outline_0023
                                   1677 	.globl _ak820_outline_0032
                                   1678 	.globl _ak820_outline_0038
                                   1679 	.globl _ak820_outline_0045
                                   1680 	.globl _ak820_outline_0052
                                   1681 	.globl _ak820_outline_0053
                                   1682 	.globl _ak820_outline_0060
                                   1683 	.globl _ak820_outline_0064
                                   1684 	.globl _ak820_outline_0072
                                   1685 	.globl _ak820_outline_0073
                                   1686 	.globl _ak820_outline_0080
                                   1687 	.globl _ak820_outline_0086
                                   1688 	.globl _ak820_outline_0096
                                   1689 	.globl _ak820_outline_0103
                                   1690 	.globl _ak820_outline_0104
                                   1691 	.globl _ak820_outline_0105
                                   1692 	.globl _ak820_outline_0107
                                   1693 	.globl _ak820_outline_0108
                                   1694 	.globl _ak820_outline_0118
                                   1695 	.globl _ak820_outline_0121
                                   1696 	.globl _ak820_outline_0123
                                   1697 	.globl _ak820_outline_0124
                                   1698 	.globl _ak820_outline_0133
                                   1699 	.globl _ak820_outline_0135
                                   1700 	.globl _ak820_outline_0137
                                   1701 	.globl _ak820_outline_0142
                                   1702 	.globl _ak820_outline_0143
                                   1703 	.globl _ak820_outline_0149
                                   1704 	.globl _ak820_outline_0156
                                   1705 	.globl _ak820_outline_0158
                                   1706 	.globl _ak820_outline_0161
                                   1707 	.globl _ak820_outline_0162
                                   1708 	.globl _ak820_outline_0183
                                   1709 	.globl _ak820_outline_0184
                                   1710 	.globl _ak820_outline_0189
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0012
      00436E                       1714 _ak820_outline_0012:
      00436E 8E 82            [24] 1715 	mov	dpl,r6
      004370 8F 83            [24] 1716 	mov	dph,r7
      004372 A3               [24] 1717 	inc	dptr
      004373 A3               [24] 1718 	inc	dptr
      004374 A3               [24] 1719 	inc	dptr
      004375 A3               [24] 1720 	inc	dptr
      004376 A3               [24] 1721 	inc	dptr
      004377 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0032
      004378                       1726 _ak820_outline_0032:
      004378 F0               [24] 1727 	movx	@dptr,a
      004379 8E 82            [24] 1728 	mov	dpl,r6
      00437B 8F 83            [24] 1729 	mov	dph,r7
      00437D A3               [24] 1730 	inc	dptr
      00437E A3               [24] 1731 	inc	dptr
      00437F 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0038
      004380                       1736 _ak820_outline_0038:
      004380 AF F0            [24] 1737 	mov	r7,b
      004382 AE 83            [24] 1738 	mov	r6,dph
      004384 E5 82            [12] 1739 	mov	a,dpl
      004386 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0045
      004387                       1744 _ak820_outline_0045:
      004387 EF               [12] 1745 	mov	a,r7
      004388 24 75            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      00438A F5 82            [12] 1747 	mov	dpl,a
      00438C E4               [12] 1748 	clr	a
      00438D 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00438F F5 83            [12] 1750 	mov	dph,a
      004391 E0               [24] 1751 	movx	a,@dptr
      004392 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0053
      004393                       1756 _ak820_outline_0053:
      004393 8F 06            [24] 1757 	mov	ar6,r7
      004395 7D 00            [12] 1758 	mov	r5,#0x00
      004397 74 40            [12] 1759 	mov	a,#0x40
      004399 2E               [12] 1760 	add	a,r6
      00439A FE               [12] 1761 	mov	r6,a
      00439B 74 EF            [12] 1762 	mov	a,#0xef
      00439D 3D               [12] 1763 	addc	a,r5
      00439E FD               [12] 1764 	mov	r5,a
      00439F 8E 82            [24] 1765 	mov	dpl,r6
      0043A1 8D 83            [24] 1766 	mov	dph,r5
      0043A3 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0064
      0043A4                       1771 _ak820_outline_0064:
      0043A4 8D 82            [24] 1772 	mov	dpl,r5
      0043A6 8E 83            [24] 1773 	mov	dph,r6
      0043A8 EC               [12] 1774 	mov	a,r4
      0043A9 F0               [24] 1775 	movx	@dptr,a
      0043AA 22               [24] 1776 	ret
                                   1777 
                                   1778 	.area CSEG (CODE)
                                   1779 ; function ak820_outline_0072
      0043AB                       1780 _ak820_outline_0072:
      0043AB F0               [24] 1781 	movx	@dptr,a
      0043AC 8E 82            [24] 1782 	mov	dpl,r6
      0043AE 8F 83            [24] 1783 	mov	dph,r7
      0043B0 22               [24] 1784 	ret
                                   1785 
                                   1786 	.area CSEG (CODE)
                                   1787 ; function ak820_outline_0096
      0043B1                       1788 _ak820_outline_0096:
      0043B1 8C 82            [24] 1789 	mov	dpl,r4
      0043B3 8D 83            [24] 1790 	mov	dph,r5
      0043B5 E0               [24] 1791 	movx	a,@dptr
      0043B6 22               [24] 1792 	ret
                                   1793 
                                   1794 	.area CSEG (CODE)
                                   1795 ; function ak820_outline_0104
      0043B7                       1796 _ak820_outline_0104:
      0043B7 E0               [24] 1797 	movx	a,@dptr
      0043B8 FA               [12] 1798 	mov	r2,a
      0043B9 A3               [24] 1799 	inc	dptr
      0043BA E0               [24] 1800 	movx	a,@dptr
      0043BB FB               [12] 1801 	mov	r3,a
      0043BC 22               [24] 1802 	ret
                                   1803 
                                   1804 	.area CSEG (CODE)
                                   1805 ; function ak820_outline_0105
      0043BD                       1806 _ak820_outline_0105:
      0043BD EF               [12] 1807 	mov	a,r7
      0043BE 24 1D            [12] 1808 	add	a,#_page_data
      0043C0 F5 82            [12] 1809 	mov	dpl,a
      0043C2 E4               [12] 1810 	clr	a
      0043C3 34 05            [12] 1811 	addc	a,#(_page_data>>8)
      0043C5 F5 83            [12] 1812 	mov	dph,a
      0043C7 E0               [24] 1813 	movx	a,@dptr
      0043C8 22               [24] 1814 	ret
                                   1815 
                                   1816 	.area CSEG (CODE)
                                   1817 ; function ak820_outline_0133
      0043C9                       1818 _ak820_outline_0133:
      0043C9 AE 82            [24] 1819 	mov	r6,dpl
      0043CB AF 83            [24] 1820 	mov	r7,dph
      0043CD 22               [24] 1821 	ret
                                   1822 
                                   1823 	.area CSEG (CODE)
                                   1824 ; function ak820_outline_0137
      0043CE                       1825 _ak820_outline_0137:
      0043CE 2E               [12] 1826 	add	a,r6
      0043CF FE               [12] 1827 	mov	r6,a
      0043D0 E4               [12] 1828 	clr	a
      0043D1 3F               [12] 1829 	addc	a,r7
      0043D2 FF               [12] 1830 	mov	r7,a
      0043D3 22               [24] 1831 	ret
                                   1832 
                                   1833 	.area CSEG (CODE)
                                   1834 ; function ak820_outline_0142
      0043D4                       1835 _ak820_outline_0142:
      0043D4 42 05            [12] 1836 	orl	ar5,a
      0043D6 EA               [12] 1837 	mov	a,r2
      0043D7 42 04            [12] 1838 	orl	ar4,a
      0043D9 22               [24] 1839 	ret
                                   1840 
                                   1841 	.area CSEG (CODE)
                                   1842 ; function ak820_outline_0149
      0043DA                       1843 _ak820_outline_0149:
      0043DA AC 82            [24] 1844 	mov	r4,dpl
      0043DC AD 83            [24] 1845 	mov	r5,dph
      0043DE 22               [24] 1846 	ret
                                   1847 
                                   1848 	.area CSEG (CODE)
                                   1849 ; function ak820_outline_0158
      0043DF                       1850 _ak820_outline_0158:
      0043DF 8F 82            [24] 1851 	mov	dpl,r7
      0043E1 8E 83            [24] 1852 	mov	dph,r6
      0043E3 22               [24] 1853 	ret
                                   1854 
                                   1855 	.area CSEG (CODE)
                                   1856 ; function ak820_outline_0161
      0043E4                       1857 _ak820_outline_0161:
      0043E4 2E               [12] 1858 	add	a,r6
      0043E5 FC               [12] 1859 	mov	r4,a
      0043E6 E4               [12] 1860 	clr	a
      0043E7 3F               [12] 1861 	addc	a,r7
      0043E8 FD               [12] 1862 	mov	r5,a
      0043E9 22               [24] 1863 	ret
                                   1864 
                                   1865 	.area CSEG (CODE)
                                   1866 ; function ak820_outline_0162
      0043EA                       1867 _ak820_outline_0162:
      0043EA ED               [12] 1868 	mov	a,r5
      0043EB F0               [24] 1869 	movx	@dptr,a
      0043EC EE               [12] 1870 	mov	a,r6
      0043ED A3               [24] 1871 	inc	dptr
      0043EE F0               [24] 1872 	movx	@dptr,a
      0043EF 22               [24] 1873 	ret
                                   1874 
                                   1875 	.area CSEG (CODE)
                                   1876 ; function ak820_outline_0183
      0043F0                       1877 _ak820_outline_0183:
      0043F0 89 82            [24] 1878 	mov	dpl,r1
      0043F2 8A 83            [24] 1879 	mov	dph,r2
      0043F4 22               [24] 1880 	ret
                                   1881 
                                   1882 	.area CSEG (CODE)
                                   1883 ; function ak820_outline_0184
      0043F5                       1884 _ak820_outline_0184:
      0043F5 8C 82            [24] 1885 	mov	dpl,r4
      0043F7 8B 83            [24] 1886 	mov	dph,r3
      0043F9 22               [24] 1887 	ret
                                   1888 
                                   1889 	.area CSEG (CODE)
                                   1890 ; function ak820_outline_0189
      0043FA                       1891 _ak820_outline_0189:
      0043FA 8D 82            [24] 1892 	mov	dpl,r5
      0043FC 8C 83            [24] 1893 	mov	dph,r4
      0043FE 22               [24] 1894 	ret
