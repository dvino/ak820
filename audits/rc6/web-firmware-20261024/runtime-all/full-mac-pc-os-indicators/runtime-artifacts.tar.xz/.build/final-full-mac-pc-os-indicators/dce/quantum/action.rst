                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_oneshot_cancel
                                     14 	.globl _ak820_oneshot_post
                                     15 	.globl _ak820_oneshot_process
                                     16 	.globl _ak820_tapping_source
                                     17 	.globl _ak820_tapping_cancel
                                     18 	.globl _ak820_tapping_process
                                     19 	.globl _ak820_tapping_before
                                     20 	.globl _pre_process_record_quantum
                                     21 	.globl _get_record_keycode
                                     22 	.globl _repeat_key_cancel
                                     23 	.globl _clear_owned_usages
                                     24 	.globl _owned_usage_key
                                     25 	.globl _clear_owned_keys
                                     26 	.globl _del_owned_key
                                     27 	.globl _add_owned_key
                                     28 	.globl _clear_owned_mods
                                     29 	.globl _del_owned_weak_mods
                                     30 	.globl _add_owned_weak_mods
                                     31 	.globl _del_owned_mods
                                     32 	.globl _add_owned_mods
                                     33 	.globl _clear_weak_mods
                                     34 	.globl _clear_mods
                                     35 	.globl _send_keyboard_report
                                     36 	.globl _layer_hold_clear
                                     37 	.globl _layer_hold_off
                                     38 	.globl _layer_hold_on
                                     39 	.globl _ak820_resolve_key
                                     40 	.globl _layer_xor
                                     41 	.globl _layer_and
                                     42 	.globl _layer_or
                                     43 	.globl _layer_off
                                     44 	.globl _layer_on
                                     45 	.globl _layer_move
                                     46 	.globl _layer_clear
                                     47 	.globl _layer_state_set
                                     48 	.globl _default_layer_xor
                                     49 	.globl _default_layer_and
                                     50 	.globl _default_layer_or
                                     51 	.globl _default_layer_set
                                     52 	.globl _post_process_record_quantum
                                     53 	.globl _process_record_quantum
                                     54 	.globl _action_for_keycode
                                     55 	.globl _mDelaymS
                                     56 	.globl _host_consumer_send
                                     57 	.globl _host_system_send
                                     58 	.globl _host_keyboard_leds
                                     59 	.globl _led_set
                                     60 	.globl _clear_keys_from_report
                                     61 	.globl ___memcpy
                                     62 	.globl _ADC_START
                                     63 	.globl _S0_R_FIFO
                                     64 	.globl _S0_T_FIFO
                                     65 	.globl _S0_FREE
                                     66 	.globl _S0_IF_BYTE
                                     67 	.globl _S0_IF_FIRST
                                     68 	.globl _S0_IF_OV
                                     69 	.globl _S0_FST_ACT
                                     70 	.globl _CP_RL2
                                     71 	.globl _C_T2
                                     72 	.globl _TR2
                                     73 	.globl _EXEN2
                                     74 	.globl _TCLK
                                     75 	.globl _RCLK
                                     76 	.globl _EXF2
                                     77 	.globl _CAP1F
                                     78 	.globl _TF2
                                     79 	.globl _RI
                                     80 	.globl _TI
                                     81 	.globl _RB8
                                     82 	.globl _TB8
                                     83 	.globl _REN
                                     84 	.globl _SM2
                                     85 	.globl _SM1
                                     86 	.globl _SM0
                                     87 	.globl _IT0
                                     88 	.globl _IE0
                                     89 	.globl _IT1
                                     90 	.globl _IE1
                                     91 	.globl _TR0
                                     92 	.globl _TF0
                                     93 	.globl _TR1
                                     94 	.globl _TF1
                                     95 	.globl _P4_0
                                     96 	.globl _P4_1
                                     97 	.globl _P4_2
                                     98 	.globl _P4_3
                                     99 	.globl _P4_4
                                    100 	.globl _P4_5
                                    101 	.globl _P4_6
                                    102 	.globl _RXD
                                    103 	.globl _TXD
                                    104 	.globl _INT0
                                    105 	.globl _INT1
                                    106 	.globl _T0
                                    107 	.globl _T1
                                    108 	.globl _MOSI1
                                    109 	.globl _MISO1
                                    110 	.globl _SCK1
                                    111 	.globl _P3_0
                                    112 	.globl _P3_1
                                    113 	.globl _P3_2
                                    114 	.globl _P3_3
                                    115 	.globl _P3_4
                                    116 	.globl _P3_5
                                    117 	.globl _P3_6
                                    118 	.globl _P3_7
                                    119 	.globl _CAP1_
                                    120 	.globl _T2_
                                    121 	.globl _CAP2_
                                    122 	.globl _T2EX_
                                    123 	.globl _RXD1
                                    124 	.globl _TXD1
                                    125 	.globl _P2_0
                                    126 	.globl _P2_1
                                    127 	.globl _P2_2
                                    128 	.globl _P2_3
                                    129 	.globl _P2_4
                                    130 	.globl _P2_5
                                    131 	.globl _P2_6
                                    132 	.globl _P2_7
                                    133 	.globl _AIN0
                                    134 	.globl _AIN1
                                    135 	.globl _AIN2
                                    136 	.globl _AIN3
                                    137 	.globl _AIN4
                                    138 	.globl _AIN5
                                    139 	.globl _AIN6
                                    140 	.globl _AIN7
                                    141 	.globl _CAP1
                                    142 	.globl _T2
                                    143 	.globl _CAP2
                                    144 	.globl _T2EX
                                    145 	.globl _INT0_
                                    146 	.globl _SCS
                                    147 	.globl _MOSI
                                    148 	.globl _MISO
                                    149 	.globl _SCK
                                    150 	.globl _RXD1_
                                    151 	.globl _TXD1_
                                    152 	.globl _P1_0
                                    153 	.globl _P1_1
                                    154 	.globl _P1_2
                                    155 	.globl _P1_3
                                    156 	.globl _P1_4
                                    157 	.globl _P1_5
                                    158 	.globl _P1_6
                                    159 	.globl _P1_7
                                    160 	.globl _AIN8
                                    161 	.globl _AIN9
                                    162 	.globl _AIN10
                                    163 	.globl _AIN11
                                    164 	.globl _AIN12
                                    165 	.globl _AIN13
                                    166 	.globl _RXD_
                                    167 	.globl _TXD_
                                    168 	.globl _SCL0
                                    169 	.globl _SDA0
                                    170 	.globl _P0_0
                                    171 	.globl _P0_1
                                    172 	.globl _P0_2
                                    173 	.globl _P0_3
                                    174 	.globl _P0_4
                                    175 	.globl _P0_5
                                    176 	.globl _P0_6
                                    177 	.globl _P0_7
                                    178 	.globl _IE_SPI0
                                    179 	.globl _IE_USB
                                    180 	.globl _IE_ADC
                                    181 	.globl _IE_UART1
                                    182 	.globl _IE_PWM_I2C
                                    183 	.globl _IE_GPIO
                                    184 	.globl _IE_WDOG
                                    185 	.globl _PX0
                                    186 	.globl _PT0
                                    187 	.globl _PX1
                                    188 	.globl _PT1
                                    189 	.globl _PS
                                    190 	.globl _PT2
                                    191 	.globl _PL_FLAG
                                    192 	.globl _PH_FLAG
                                    193 	.globl _EX0
                                    194 	.globl _ET0
                                    195 	.globl _EX1
                                    196 	.globl _ET1
                                    197 	.globl _ES
                                    198 	.globl _ET2
                                    199 	.globl _E_DIS
                                    200 	.globl _EA
                                    201 	.globl _P
                                    202 	.globl _F1
                                    203 	.globl _OV
                                    204 	.globl _RS0
                                    205 	.globl _RS1
                                    206 	.globl _F0
                                    207 	.globl _AC
                                    208 	.globl _CY
                                    209 	.globl _I2CS_INT_ST
                                    210 	.globl _I2CX_INT
                                    211 	.globl _LED_STATUS
                                    212 	.globl _LED_DMA_H
                                    213 	.globl _LED_DMA_L
                                    214 	.globl _LED_DMA
                                    215 	.globl _LED_PWM_OE
                                    216 	.globl _LED_COMMON
                                    217 	.globl _ADC_CHAN
                                    218 	.globl _ADC_DAT_H
                                    219 	.globl _ADC_DAT_L
                                    220 	.globl _ADC_DAT
                                    221 	.globl _ADC_CTRL
                                    222 	.globl _SPI1_CK_SE
                                    223 	.globl _SPI1_CTRL
                                    224 	.globl _SPI1_DATA
                                    225 	.globl _SPI1_STAT
                                    226 	.globl _SIF1
                                    227 	.globl _SBAUD1
                                    228 	.globl _SBUF1
                                    229 	.globl _SCON1
                                    230 	.globl _SPI0_SETUP
                                    231 	.globl _SPI0_CK_SE
                                    232 	.globl _SPI0_CTRL
                                    233 	.globl _SPI0_DATA
                                    234 	.globl _SPI0_STAT
                                    235 	.globl _T2CAP1H
                                    236 	.globl _T2CAP1L
                                    237 	.globl _T2CAP1
                                    238 	.globl _TH2
                                    239 	.globl _TL2
                                    240 	.globl _T2COUNT
                                    241 	.globl _RCAP2H
                                    242 	.globl _RCAP2L
                                    243 	.globl _RCAP2
                                    244 	.globl _T2MOD
                                    245 	.globl _T2CON
                                    246 	.globl _SBUF
                                    247 	.globl _SCON
                                    248 	.globl _TH1
                                    249 	.globl _TH0
                                    250 	.globl _TL1
                                    251 	.globl _TL0
                                    252 	.globl _TMOD
                                    253 	.globl _TCON
                                    254 	.globl _XBUS_AUX
                                    255 	.globl _P7
                                    256 	.globl _P6_DIR
                                    257 	.globl _P6_OUT_PU
                                    258 	.globl _P6_IN
                                    259 	.globl _P5_DIR
                                    260 	.globl _P5_OUT_PU
                                    261 	.globl _P5_IN
                                    262 	.globl _P4_LED_KEY
                                    263 	.globl _P4_DIR_PU
                                    264 	.globl _P4_MOD_OC
                                    265 	.globl _P4
                                    266 	.globl _P3_DIR_PU
                                    267 	.globl _P3_MOD_OC
                                    268 	.globl _P3
                                    269 	.globl _P2_DIR_PU
                                    270 	.globl _P2_MOD_OC
                                    271 	.globl _P2
                                    272 	.globl _P1_DIR_PU
                                    273 	.globl _P1_MOD_OC
                                    274 	.globl _P1
                                    275 	.globl _P0_DIR_PU
                                    276 	.globl _P0_MOD_OC
                                    277 	.globl _P0
                                    278 	.globl _ROM_CTRL
                                    279 	.globl _ROM_DATA_HH
                                    280 	.globl _ROM_DATA_HL
                                    281 	.globl _ROM_DATA_HI
                                    282 	.globl _ROM_ADDR_H
                                    283 	.globl _ROM_ADDR_L
                                    284 	.globl _ROM_ADDR
                                    285 	.globl _GPIO_IE
                                    286 	.globl _IP_EX
                                    287 	.globl _IE_EX
                                    288 	.globl _IP
                                    289 	.globl _IE
                                    290 	.globl _WDOG_COUNT
                                    291 	.globl _RESET_KEEP
                                    292 	.globl _WAKE_CTRL
                                    293 	.globl _CLOCK_CFG
                                    294 	.globl _POWER_CFG
                                    295 	.globl _PCON
                                    296 	.globl _GLOBAL_CFG
                                    297 	.globl _SAFE_MOD
                                    298 	.globl _DPH
                                    299 	.globl _DPL
                                    300 	.globl _SP
                                    301 	.globl _A_INV
                                    302 	.globl _B
                                    303 	.globl _ACC
                                    304 	.globl _PSW
                                    305 	.globl _disable_action_cache
                                    306 	.globl _tap_code_delay_PARM_2
                                    307 	.globl _process_action_PARM_2
                                    308 	.globl _action_exec_PARM_1
                                    309 	.globl _tp_buttons
                                    310 	.globl _action_exec
                                    311 	.globl _ak820_action_exec
                                    312 	.globl _process_record
                                    313 	.globl _process_record_handler
                                    314 	.globl _process_action
                                    315 	.globl _register_code
                                    316 	.globl _unregister_code
                                    317 	.globl _tap_code_delay
                                    318 	.globl _tap_code
                                    319 	.globl _register_mods
                                    320 	.globl _unregister_mods
                                    321 	.globl _register_weak_mods
                                    322 	.globl _unregister_weak_mods
                                    323 	.globl _clear_keyboard
                                    324 	.globl _clear_keyboard_but_mods
                                    325 	.globl _clear_keyboard_but_mods_and_keys
                                    326 ;--------------------------------------------------------
                                    327 ; special function registers
                                    328 ;--------------------------------------------------------
                                    329 	.area RSEG    (ABS,DATA)
      000000                        330 	.org 0x0000
                           0000D0   331 _PSW	=	0x00d0
                           0000E0   332 _ACC	=	0x00e0
                           0000F0   333 _B	=	0x00f0
                           0000FD   334 _A_INV	=	0x00fd
                           000081   335 _SP	=	0x0081
                           000082   336 _DPL	=	0x0082
                           000083   337 _DPH	=	0x0083
                           0000A1   338 _SAFE_MOD	=	0x00a1
                           0000B1   339 _GLOBAL_CFG	=	0x00b1
                           000087   340 _PCON	=	0x0087
                           0000BA   341 _POWER_CFG	=	0x00ba
                           0000B9   342 _CLOCK_CFG	=	0x00b9
                           0000A9   343 _WAKE_CTRL	=	0x00a9
                           0000FE   344 _RESET_KEEP	=	0x00fe
                           0000FF   345 _WDOG_COUNT	=	0x00ff
                           0000A8   346 _IE	=	0x00a8
                           0000B8   347 _IP	=	0x00b8
                           0000E8   348 _IE_EX	=	0x00e8
                           0000E9   349 _IP_EX	=	0x00e9
                           0000B2   350 _GPIO_IE	=	0x00b2
                           008584   351 _ROM_ADDR	=	0x8584
                           000084   352 _ROM_ADDR_L	=	0x0084
                           000085   353 _ROM_ADDR_H	=	0x0085
                           008F8E   354 _ROM_DATA_HI	=	0x8f8e
                           00008E   355 _ROM_DATA_HL	=	0x008e
                           00008F   356 _ROM_DATA_HH	=	0x008f
                           000086   357 _ROM_CTRL	=	0x0086
                           000080   358 _P0	=	0x0080
                           0000C4   359 _P0_MOD_OC	=	0x00c4
                           0000C5   360 _P0_DIR_PU	=	0x00c5
                           000090   361 _P1	=	0x0090
                           000092   362 _P1_MOD_OC	=	0x0092
                           000093   363 _P1_DIR_PU	=	0x0093
                           0000A0   364 _P2	=	0x00a0
                           000094   365 _P2_MOD_OC	=	0x0094
                           000095   366 _P2_DIR_PU	=	0x0095
                           0000B0   367 _P3	=	0x00b0
                           000096   368 _P3_MOD_OC	=	0x0096
                           000097   369 _P3_DIR_PU	=	0x0097
                           0000C0   370 _P4	=	0x00c0
                           0000C2   371 _P4_MOD_OC	=	0x00c2
                           0000C3   372 _P4_DIR_PU	=	0x00c3
                           0000C1   373 _P4_LED_KEY	=	0x00c1
                           0000AA   374 _P5_IN	=	0x00aa
                           0000AB   375 _P5_OUT_PU	=	0x00ab
                           0000AC   376 _P5_DIR	=	0x00ac
                           0000AD   377 _P6_IN	=	0x00ad
                           0000AE   378 _P6_OUT_PU	=	0x00ae
                           0000AF   379 _P6_DIR	=	0x00af
                           0000F1   380 _P7	=	0x00f1
                           0000A2   381 _XBUS_AUX	=	0x00a2
                           000088   382 _TCON	=	0x0088
                           000089   383 _TMOD	=	0x0089
                           00008A   384 _TL0	=	0x008a
                           00008B   385 _TL1	=	0x008b
                           00008C   386 _TH0	=	0x008c
                           00008D   387 _TH1	=	0x008d
                           000098   388 _SCON	=	0x0098
                           000099   389 _SBUF	=	0x0099
                           0000C8   390 _T2CON	=	0x00c8
                           0000C9   391 _T2MOD	=	0x00c9
                           00CBCA   392 _RCAP2	=	0xcbca
                           0000CA   393 _RCAP2L	=	0x00ca
                           0000CB   394 _RCAP2H	=	0x00cb
                           00CDCC   395 _T2COUNT	=	0xcdcc
                           0000CC   396 _TL2	=	0x00cc
                           0000CD   397 _TH2	=	0x00cd
                           00CFCE   398 _T2CAP1	=	0xcfce
                           0000CE   399 _T2CAP1L	=	0x00ce
                           0000CF   400 _T2CAP1H	=	0x00cf
                           0000F8   401 _SPI0_STAT	=	0x00f8
                           0000F9   402 _SPI0_DATA	=	0x00f9
                           0000FA   403 _SPI0_CTRL	=	0x00fa
                           0000FB   404 _SPI0_CK_SE	=	0x00fb
                           0000FC   405 _SPI0_SETUP	=	0x00fc
                           0000BC   406 _SCON1	=	0x00bc
                           0000BD   407 _SBUF1	=	0x00bd
                           0000BE   408 _SBAUD1	=	0x00be
                           0000BF   409 _SIF1	=	0x00bf
                           0000B4   410 _SPI1_STAT	=	0x00b4
                           0000B5   411 _SPI1_DATA	=	0x00b5
                           0000B6   412 _SPI1_CTRL	=	0x00b6
                           0000B7   413 _SPI1_CK_SE	=	0x00b7
                           0000F3   414 _ADC_CTRL	=	0x00f3
                           00F5F4   415 _ADC_DAT	=	0xf5f4
                           0000F4   416 _ADC_DAT_L	=	0x00f4
                           0000F5   417 _ADC_DAT_H	=	0x00f5
                           0000F6   418 _ADC_CHAN	=	0x00f6
                           0000A6   419 _LED_COMMON	=	0x00a6
                           0000A7   420 _LED_PWM_OE	=	0x00a7
                           00C7C6   421 _LED_DMA	=	0xc7c6
                           0000C6   422 _LED_DMA_L	=	0x00c6
                           0000C7   423 _LED_DMA_H	=	0x00c7
                           0000F7   424 _LED_STATUS	=	0x00f7
                           0000B3   425 _I2CX_INT	=	0x00b3
                           0000BB   426 _I2CS_INT_ST	=	0x00bb
                                    427 ;--------------------------------------------------------
                                    428 ; special function bits
                                    429 ;--------------------------------------------------------
                                    430 	.area RSEG    (ABS,DATA)
      000000                        431 	.org 0x0000
                           0000D7   432 _CY	=	0x00d7
                           0000D6   433 _AC	=	0x00d6
                           0000D5   434 _F0	=	0x00d5
                           0000D4   435 _RS1	=	0x00d4
                           0000D3   436 _RS0	=	0x00d3
                           0000D2   437 _OV	=	0x00d2
                           0000D1   438 _F1	=	0x00d1
                           0000D0   439 _P	=	0x00d0
                           0000AF   440 _EA	=	0x00af
                           0000AE   441 _E_DIS	=	0x00ae
                           0000AD   442 _ET2	=	0x00ad
                           0000AC   443 _ES	=	0x00ac
                           0000AB   444 _ET1	=	0x00ab
                           0000AA   445 _EX1	=	0x00aa
                           0000A9   446 _ET0	=	0x00a9
                           0000A8   447 _EX0	=	0x00a8
                           0000BF   448 _PH_FLAG	=	0x00bf
                           0000BE   449 _PL_FLAG	=	0x00be
                           0000BD   450 _PT2	=	0x00bd
                           0000BC   451 _PS	=	0x00bc
                           0000BB   452 _PT1	=	0x00bb
                           0000BA   453 _PX1	=	0x00ba
                           0000B9   454 _PT0	=	0x00b9
                           0000B8   455 _PX0	=	0x00b8
                           0000EF   456 _IE_WDOG	=	0x00ef
                           0000EE   457 _IE_GPIO	=	0x00ee
                           0000ED   458 _IE_PWM_I2C	=	0x00ed
                           0000EC   459 _IE_UART1	=	0x00ec
                           0000EB   460 _IE_ADC	=	0x00eb
                           0000E9   461 _IE_USB	=	0x00e9
                           0000E8   462 _IE_SPI0	=	0x00e8
                           000087   463 _P0_7	=	0x0087
                           000086   464 _P0_6	=	0x0086
                           000085   465 _P0_5	=	0x0085
                           000084   466 _P0_4	=	0x0084
                           000083   467 _P0_3	=	0x0083
                           000082   468 _P0_2	=	0x0082
                           000081   469 _P0_1	=	0x0081
                           000080   470 _P0_0	=	0x0080
                           000081   471 _SDA0	=	0x0081
                           000080   472 _SCL0	=	0x0080
                           000083   473 _TXD_	=	0x0083
                           000082   474 _RXD_	=	0x0082
                           000085   475 _AIN13	=	0x0085
                           000084   476 _AIN12	=	0x0084
                           000083   477 _AIN11	=	0x0083
                           000082   478 _AIN10	=	0x0082
                           000081   479 _AIN9	=	0x0081
                           000080   480 _AIN8	=	0x0080
                           000097   481 _P1_7	=	0x0097
                           000096   482 _P1_6	=	0x0096
                           000095   483 _P1_5	=	0x0095
                           000094   484 _P1_4	=	0x0094
                           000093   485 _P1_3	=	0x0093
                           000092   486 _P1_2	=	0x0092
                           000091   487 _P1_1	=	0x0091
                           000090   488 _P1_0	=	0x0090
                           000097   489 _TXD1_	=	0x0097
                           000096   490 _RXD1_	=	0x0096
                           000097   491 _SCK	=	0x0097
                           000096   492 _MISO	=	0x0096
                           000095   493 _MOSI	=	0x0095
                           000094   494 _SCS	=	0x0094
                           000092   495 _INT0_	=	0x0092
                           000091   496 _T2EX	=	0x0091
                           000091   497 _CAP2	=	0x0091
                           000090   498 _T2	=	0x0090
                           000090   499 _CAP1	=	0x0090
                           000097   500 _AIN7	=	0x0097
                           000096   501 _AIN6	=	0x0096
                           000095   502 _AIN5	=	0x0095
                           000094   503 _AIN4	=	0x0094
                           000093   504 _AIN3	=	0x0093
                           000092   505 _AIN2	=	0x0092
                           000091   506 _AIN1	=	0x0091
                           000090   507 _AIN0	=	0x0090
                           0000A7   508 _P2_7	=	0x00a7
                           0000A6   509 _P2_6	=	0x00a6
                           0000A5   510 _P2_5	=	0x00a5
                           0000A4   511 _P2_4	=	0x00a4
                           0000A3   512 _P2_3	=	0x00a3
                           0000A2   513 _P2_2	=	0x00a2
                           0000A1   514 _P2_1	=	0x00a1
                           0000A0   515 _P2_0	=	0x00a0
                           0000A7   516 _TXD1	=	0x00a7
                           0000A6   517 _RXD1	=	0x00a6
                           0000A5   518 _T2EX_	=	0x00a5
                           0000A5   519 _CAP2_	=	0x00a5
                           0000A4   520 _T2_	=	0x00a4
                           0000A4   521 _CAP1_	=	0x00a4
                           0000B7   522 _P3_7	=	0x00b7
                           0000B6   523 _P3_6	=	0x00b6
                           0000B5   524 _P3_5	=	0x00b5
                           0000B4   525 _P3_4	=	0x00b4
                           0000B3   526 _P3_3	=	0x00b3
                           0000B2   527 _P3_2	=	0x00b2
                           0000B1   528 _P3_1	=	0x00b1
                           0000B0   529 _P3_0	=	0x00b0
                           0000B7   530 _SCK1	=	0x00b7
                           0000B6   531 _MISO1	=	0x00b6
                           0000B5   532 _MOSI1	=	0x00b5
                           0000B5   533 _T1	=	0x00b5
                           0000B4   534 _T0	=	0x00b4
                           0000B3   535 _INT1	=	0x00b3
                           0000B2   536 _INT0	=	0x00b2
                           0000B1   537 _TXD	=	0x00b1
                           0000B0   538 _RXD	=	0x00b0
                           0000C6   539 _P4_6	=	0x00c6
                           0000C5   540 _P4_5	=	0x00c5
                           0000C4   541 _P4_4	=	0x00c4
                           0000C3   542 _P4_3	=	0x00c3
                           0000C2   543 _P4_2	=	0x00c2
                           0000C1   544 _P4_1	=	0x00c1
                           0000C0   545 _P4_0	=	0x00c0
                           00008F   546 _TF1	=	0x008f
                           00008E   547 _TR1	=	0x008e
                           00008D   548 _TF0	=	0x008d
                           00008C   549 _TR0	=	0x008c
                           00008B   550 _IE1	=	0x008b
                           00008A   551 _IT1	=	0x008a
                           000089   552 _IE0	=	0x0089
                           000088   553 _IT0	=	0x0088
                           00009F   554 _SM0	=	0x009f
                           00009E   555 _SM1	=	0x009e
                           00009D   556 _SM2	=	0x009d
                           00009C   557 _REN	=	0x009c
                           00009B   558 _TB8	=	0x009b
                           00009A   559 _RB8	=	0x009a
                           000099   560 _TI	=	0x0099
                           000098   561 _RI	=	0x0098
                           0000CF   562 _TF2	=	0x00cf
                           0000CF   563 _CAP1F	=	0x00cf
                           0000CE   564 _EXF2	=	0x00ce
                           0000CD   565 _RCLK	=	0x00cd
                           0000CC   566 _TCLK	=	0x00cc
                           0000CB   567 _EXEN2	=	0x00cb
                           0000CA   568 _TR2	=	0x00ca
                           0000C9   569 _C_T2	=	0x00c9
                           0000C8   570 _CP_RL2	=	0x00c8
                           0000FF   571 _S0_FST_ACT	=	0x00ff
                           0000FE   572 _S0_IF_OV	=	0x00fe
                           0000FD   573 _S0_IF_FIRST	=	0x00fd
                           0000FC   574 _S0_IF_BYTE	=	0x00fc
                           0000FB   575 _S0_FREE	=	0x00fb
                           0000FA   576 _S0_T_FIFO	=	0x00fa
                           0000F8   577 _S0_R_FIFO	=	0x00f8
                           0000F7   578 _ADC_START	=	0x00f7
                                    579 ;--------------------------------------------------------
                                    580 ; overlayable register banks
                                    581 ;--------------------------------------------------------
                                    582 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        583 	.ds 8
                                    584 ;--------------------------------------------------------
                                    585 ; internal ram data
                                    586 ;--------------------------------------------------------
                                    587 	.area DSEG    (DATA)
      000027                        588 _process_action_sloc0_1_0:
      000027                        589 	.ds 1
                                    590 ;--------------------------------------------------------
                                    591 ; overlayable items in internal ram
                                    592 ;--------------------------------------------------------
                                    593 ;--------------------------------------------------------
                                    594 ; indirectly addressable internal ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area ISEG    (DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; absolute internal ram data
                                    599 ;--------------------------------------------------------
                                    600 	.area IABS    (ABS,DATA)
                                    601 	.area IABS    (ABS,DATA)
                                    602 ;--------------------------------------------------------
                                    603 ; bit data
                                    604 ;--------------------------------------------------------
                                    605 	.area BSEG    (BIT)
      00001F                        606 _process_action_sloc1_1_0:
      00001F                        607 	.ds 1
                                    608 ;--------------------------------------------------------
                                    609 ; paged external ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area PSEG    (PAG,XDATA)
                                    612 ;--------------------------------------------------------
                                    613 ; uninitialized external ram data
                                    614 ;--------------------------------------------------------
                                    615 	.area XSEG    (XDATA)
      000817                        616 _tp_buttons::
      000817                        617 	.ds 2
      000819                        618 _action_exec_PARM_1:
      000819                        619 	.ds 6
      00081F                        620 _action_exec_record_10001_625:
      00081F                        621 	.ds 9
      000828                        622 _ak820_action_exec_event_10000_629:
      000828                        623 	.ds 2
      00082A                        624 _ak820_action_exec_snapshot_10000_630:
      00082A                        625 	.ds 6
      000830                        626 _process_record_record_10000_633:
      000830                        627 	.ds 3
      000833                        628 _process_record_handler_record_argument_10000_641:
      000833                        629 	.ds 3
      000836                        630 _process_record_handler_action_10000_642:
      000836                        631 	.ds 2
      000838                        632 _process_action_PARM_2:
      000838                        633 	.ds 2
      00083A                        634 _process_action_record_argument_10000_653:
      00083A                        635 	.ds 3
      00083D                        636 _process_action_on_40000_676:
      00083D                        637 	.ds 1
      00083E                        638 _register_code_code_10000_710:
      00083E                        639 	.ds 1
      00083F                        640 _unregister_code_code_10000_724:
      00083F                        641 	.ds 1
      000840                        642 _tap_code_delay_PARM_2:
      000840                        643 	.ds 2
      000842                        644 _tap_code_delay_code_10000_737:
      000842                        645 	.ds 1
      000843                        646 _tap_code_code_10000_744:
      000843                        647 	.ds 1
      000844                        648 _register_mods_mods_10000_746:
      000844                        649 	.ds 1
      000845                        650 _unregister_mods_mods_10000_750:
      000845                        651 	.ds 1
      000846                        652 _register_weak_mods_mods_10000_754:
      000846                        653 	.ds 1
      000847                        654 _unregister_weak_mods_mods_10000_758:
      000847                        655 	.ds 1
                                    656 ;--------------------------------------------------------
                                    657 ; absolute external ram data
                                    658 ;--------------------------------------------------------
                                    659 	.area XABS    (ABS,XDATA)
                                    660 ;--------------------------------------------------------
                                    661 ; initialized external ram data
                                    662 ;--------------------------------------------------------
                                    663 	.area XISEG   (XDATA)
      000DC9                        664 _disable_action_cache::
      000DC9                        665 	.ds 1
                                    666 	.area HOME    (CODE)
                                    667 	.area GSINIT0 (CODE)
                                    668 	.area GSINIT1 (CODE)
                                    669 	.area GSINIT2 (CODE)
                                    670 	.area GSINIT3 (CODE)
                                    671 	.area GSINIT4 (CODE)
                                    672 	.area GSINIT5 (CODE)
                                    673 	.area GSINIT  (CODE)
                                    674 	.area GSFINAL (CODE)
                                    675 	.area CSEG    (CODE)
                                    676 ;--------------------------------------------------------
                                    677 ; global & static initialisations
                                    678 ;--------------------------------------------------------
                                    679 	.area HOME    (CODE)
                                    680 	.area GSINIT  (CODE)
                                    681 	.area GSFINAL (CODE)
                                    682 	.area GSINIT  (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; Home
                                    685 ;--------------------------------------------------------
                                    686 	.area HOME    (CODE)
                                    687 	.area HOME    (CODE)
                                    688 ;--------------------------------------------------------
                                    689 ; code
                                    690 ;--------------------------------------------------------
                                    691 	.area CSEG    (CODE)
                                    692 ;------------------------------------------------------------
                                    693 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    694 ;------------------------------------------------------------
                                    695 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    696 ;------------------------------------------------------------
                                    697 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    698 ;	-----------------------------------------
                           000007   699 	ar7 = 0x07
                           000006   700 	ar6 = 0x06
                           000005   701 	ar5 = 0x05
                           000004   702 	ar4 = 0x04
                           000003   703 	ar3 = 0x03
                           000002   704 	ar2 = 0x02
                           000001   705 	ar1 = 0x01
                           000000   706 	ar0 = 0x00
                                    707 ;	 function action_exec
                                    708 ;	-----------------------------------------
      00722B                        709 _action_exec:
                                    710 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      00722B 90 08 1B         [24]  711 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      00722E 12 37 F4         [24]  712 	lcall	_ak820_outline_0005
      007231 12 36 04         [24]  713 	lcall	_ak820_combo_tick
                                    714 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      007234 90 08 19         [24]  715 	mov	dptr,#_action_exec_PARM_1
      007237 12 45 85         [24]  716 	lcall	_ak820_tapping_before
      00723A E5 82            [12]  717 	mov	a, dpl
      00723C 70 01            [24]  718 	jnz	00102$
      00723E 22               [24]  719 	ret
      00723F                        720 00102$:
                                    721 ;	quantum/action.c:116: if (event.pressed) {
      00723F 90 08 1E         [24]  722 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007242 E0               [24]  723 	movx	a,@dptr
      007243 60 03            [24]  724 	jz	00104$
                                    725 ;	quantum/action.c:118: clear_weak_mods();
      007245 12 82 FD         [24]  726 	lcall	_clear_weak_mods
      007248                        727 00104$:
                                    728 ;	quantum/action.c:130: record.event = event;
      007248 90 0D A9         [24]  729 	mov	dptr,#___memcpy_PARM_2
      00724B 74 19            [12]  730 	mov	a,#_action_exec_PARM_1
      00724D F0               [24]  731 	movx	@dptr,a
      00724E 74 08            [12]  732 	mov	a,#(_action_exec_PARM_1 >> 8)
      007250 12 38 70         [24]  733 	lcall	_ak820_outline_0094
      007253 12 78 FA         [24]  734 	lcall	_ak820_outline_0071
      007256 90 08 1F         [24]  735 	mov	dptr,#_action_exec_record_10001_625
      007259 F5 F0            [12]  736 	mov	b,a
      00725B 12 BA AB         [24]  737 	lcall	___memcpy
                                    738 ;	quantum/action.c:132: record.tap.count = 0;
      00725E 90 08 25         [24]  739 	mov	dptr,#(_action_exec_record_10001_625 + 0x0006)
      007261 E0               [24]  740 	movx	a,@dptr
      007262 54 0F            [12]  741 	anl	a,#0x0f
      007264 F0               [24]  742 	movx	@dptr,a
                                    743 ;	quantum/action.c:137: record.keycode = 0;
      007265 90 08 26         [24]  744 	mov	dptr,#(_action_exec_record_10001_625 + 0x0007)
      007268 12 50 8C         [24]  745 	lcall	_ak820_outline_0182
                                    746 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00726B 90 08 23         [24]  747 	mov	dptr,#(_action_exec_record_10001_625 + 0x0004)
      00726E E0               [24]  748 	movx	a,@dptr
      00726F 60 0D            [24]  749 	jz	00107$
      007271 90 08 1F         [24]  750 	mov	dptr,#_action_exec_record_10001_625
      007274 75 F0 00         [24]  751 	mov	b, #0x00
      007277 12 A0 DC         [24]  752 	lcall	_pre_process_record_quantum
      00727A E5 82            [12]  753 	mov	a, dpl
      00727C 60 14            [24]  754 	jz	00110$
      00727E                        755 00107$:
                                    756 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      00727E 90 08 1F         [24]  757 	mov	dptr,#_action_exec_record_10001_625
      007281 12 46 6C         [24]  758 	lcall	_ak820_tapping_process
      007284 E5 82            [12]  759 	mov	a, dpl
      007286 70 01            [24]  760 	jnz	00106$
      007288 22               [24]  761 	ret
      007289                        762 00106$:
                                    763 ;	quantum/action.c:175: process_record(&record);
      007289 90 08 1F         [24]  764 	mov	dptr,#_action_exec_record_10001_625
      00728C 75 F0 00         [24]  765 	mov	b, #0x00
                                    766 ;	quantum/action.c:190: }
      00728F 02 72 CF         [24]  767 	ljmp	_process_record
      007292                        768 00110$:
      007292 22               [24]  769 	ret
                                    770 ;------------------------------------------------------------
                                    771 ;Allocation info for local variables in function 'ak820_action_exec'
                                    772 ;------------------------------------------------------------
                                    773 ;event         Allocated with name '_ak820_action_exec_event_10000_629'
                                    774 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_630'
                                    775 ;------------------------------------------------------------
                                    776 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    777 ;	-----------------------------------------
                                    778 ;	 function ak820_action_exec
                                    779 ;	-----------------------------------------
      007293                        780 _ak820_action_exec:
      007293 12 38 82         [24]  781 	lcall	_ak820_outline_0107
      007296 90 08 28         [24]  782 	mov	dptr,#_ak820_action_exec_event_10000_629
      007299 12 38 87         [24]  783 	lcall	_ak820_outline_0108
                                    784 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      00729C 90 08 28         [24]  785 	mov	dptr,#_ak820_action_exec_event_10000_629
      00729F 12 38 64         [24]  786 	lcall	_ak820_outline_0080
      0072A2 7F 00            [12]  787 	mov	r7,#0x00
      0072A4 90 0D A9         [24]  788 	mov	dptr,#___memcpy_PARM_2
      0072A7 ED               [12]  789 	mov	a,r5
      0072A8 12 38 29         [24]  790 	lcall	_ak820_outline_0018
      0072AB 12 78 FA         [24]  791 	lcall	_ak820_outline_0071
      0072AE 90 08 2A         [24]  792 	mov	dptr,#_ak820_action_exec_snapshot_10000_630
      0072B1 F5 F0            [12]  793 	mov	b,a
      0072B3 12 BA AB         [24]  794 	lcall	___memcpy
                                    795 ;	quantum/action.c:197: action_exec(snapshot);
      0072B6 90 0D A9         [24]  796 	mov	dptr,#___memcpy_PARM_2
      0072B9 74 2A            [12]  797 	mov	a,#_ak820_action_exec_snapshot_10000_630
      0072BB F0               [24]  798 	movx	@dptr,a
      0072BC 74 08            [12]  799 	mov	a,#(_ak820_action_exec_snapshot_10000_630 >> 8)
      0072BE 12 38 70         [24]  800 	lcall	_ak820_outline_0094
      0072C1 12 78 FA         [24]  801 	lcall	_ak820_outline_0071
      0072C4 90 08 19         [24]  802 	mov	dptr,#_action_exec_PARM_1
      0072C7 F5 F0            [12]  803 	mov	b,a
      0072C9 12 BA AB         [24]  804 	lcall	___memcpy
                                    805 ;	quantum/action.c:198: }
      0072CC 02 72 2B         [24]  806 	ljmp	_action_exec
                                    807 ;------------------------------------------------------------
                                    808 ;Allocation info for local variables in function 'process_record_nocache'
                                    809 ;------------------------------------------------------------
                                    810 ;record        Allocated with name '_process_record_nocache_record_10000_631'
                                    811 ;------------------------------------------------------------
                                    812 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    813 ;	-----------------------------------------
                                    814 ;	 function process_record
                                    815 ;	-----------------------------------------
      0072CF                        816 _process_record:
      0072CF 12 43 80         [24]  817 	lcall	_ak820_outline_0038
      0072D2 90 08 30         [24]  818 	mov	dptr,#_process_record_record_10000_633
      0072D5 12 38 29         [24]  819 	lcall	_ak820_outline_0018
                                    820 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      0072D8 90 08 30         [24]  821 	mov	dptr,#_process_record_record_10000_633
      0072DB 12 50 39         [24]  822 	lcall	_ak820_outline_0013
      0072DE 74 04            [12]  823 	mov	a,#0x04
      0072E0 12 78 CD         [24]  824 	lcall	_ak820_outline_0015
      0072E3 12 BB 84         [24]  825 	lcall	__gptrget
      0072E6 70 01            [24]  826 	jnz	00102$
                                    827 ;	quantum/action.c:338: return;
      0072E8 22               [24]  828 	ret
      0072E9                        829 00102$:
                                    830 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      0072E9 8D 02            [24]  831 	mov	ar2,r5
      0072EB 8E 03            [24]  832 	mov	ar3,r6
      0072ED 8F 04            [24]  833 	mov	ar4,r7
      0072EF 90 0D A9         [24]  834 	mov	dptr,#___memcpy_PARM_2
      0072F2 EA               [12]  835 	mov	a,r2
      0072F3 12 79 41         [24]  836 	lcall	_ak820_outline_0187
      0072F6 EC               [12]  837 	mov	a,r4
      0072F7 A3               [24]  838 	inc	dptr
      0072F8 F0               [24]  839 	movx	@dptr,a
      0072F9 90 0D AC         [24]  840 	mov	dptr,#___memcpy_PARM_3
      0072FC 12 50 7E         [24]  841 	lcall	_ak820_outline_0110
      0072FF 90 06 2C         [24]  842 	mov	dptr,#_ak820_tapping_source_PARM_1
      007302 F5 F0            [12]  843 	mov	b,a
      007304 C0 07            [24]  844 	push	ar7
      007306 C0 06            [24]  845 	push	ar6
      007308 C0 05            [24]  846 	push	ar5
      00730A 12 BA AB         [24]  847 	lcall	___memcpy
      00730D 12 44 BF         [24]  848 	lcall	_ak820_tapping_source
      007310 AC 82            [24]  849 	mov	r4, dpl
      007312 D0 05            [24]  850 	pop	ar5
      007314 D0 06            [24]  851 	pop	ar6
      007316 D0 07            [24]  852 	pop	ar7
                                    853 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      007318 74 05            [12]  854 	mov	a,#0x05
      00731A 12 78 BF         [24]  855 	lcall	_ak820_outline_0014
      00731D 12 BB 84         [24]  856 	lcall	__gptrget
      007320 FB               [12]  857 	mov	r3,a
                                    858 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      007321 12 79 26         [24]  859 	lcall	_ak820_outline_0146
      007324 90 0C 00         [24]  860 	mov	dptr,#_get_record_keycode_PARM_2
      007327 74 01            [12]  861 	mov	a,#0x01
      007329 12 50 42         [24]  862 	lcall	_ak820_outline_0035
      00732C C0 04            [24]  863 	push	ar4
      00732E C0 03            [24]  864 	push	ar3
      007330 C0 02            [24]  865 	push	ar2
      007332 C0 01            [24]  866 	push	ar1
      007334 C0 00            [24]  867 	push	ar0
      007336 12 A0 9F         [24]  868 	lcall	_get_record_keycode
      007339 12 43 C9         [24]  869 	lcall	_ak820_outline_0133
      00733C D0 00            [24]  870 	pop	ar0
      00733E D0 01            [24]  871 	pop	ar1
      007340 D0 02            [24]  872 	pop	ar2
      007342 D0 03            [24]  873 	pop	ar3
      007344 D0 04            [24]  874 	pop	ar4
      007346 12 4A 02         [24]  875 	lcall	_ak820_outline_0112
      007349 EE               [12]  876 	mov	a,r6
      00734A 12 BB 49         [24]  877 	lcall	__gptrput
      00734D A3               [24]  878 	inc	dptr
      00734E EF               [12]  879 	mov	a,r7
      00734F 12 BB 49         [24]  880 	lcall	__gptrput
                                    881 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      007352 90 08 30         [24]  882 	mov	dptr,#_process_record_record_10000_633
      007355 12 50 39         [24]  883 	lcall	_ak820_outline_0013
      007358 12 79 26         [24]  884 	lcall	_ak820_outline_0146
      00735B 12 4A 02         [24]  885 	lcall	_ak820_outline_0112
      00735E 12 BB 84         [24]  886 	lcall	__gptrget
      007361 F8               [12]  887 	mov	r0,a
      007362 A3               [24]  888 	inc	dptr
      007363 12 BB 84         [24]  889 	lcall	__gptrget
      007366 F9               [12]  890 	mov	r1,a
      007367 90 06 3C         [24]  891 	mov	dptr,#_ak820_oneshot_process_PARM_2
      00736A EC               [12]  892 	mov	a,r4
      00736B F0               [24]  893 	movx	@dptr,a
      00736C 90 06 3D         [24]  894 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00736F EB               [12]  895 	mov	a,r3
      007370 F0               [24]  896 	movx	@dptr,a
      007371 12 38 B6         [24]  897 	lcall	_ak820_outline_0157
      007374 C0 07            [24]  898 	push	ar7
      007376 C0 06            [24]  899 	push	ar6
      007378 C0 05            [24]  900 	push	ar5
      00737A C0 04            [24]  901 	push	ar4
      00737C C0 03            [24]  902 	push	ar3
      00737E 12 48 1E         [24]  903 	lcall	_ak820_oneshot_process
      007381 E5 82            [12]  904 	mov	a, dpl
      007383 D0 03            [24]  905 	pop	ar3
      007385 D0 04            [24]  906 	pop	ar4
      007387 D0 05            [24]  907 	pop	ar5
      007389 D0 06            [24]  908 	pop	ar6
      00738B D0 07            [24]  909 	pop	ar7
      00738D 70 01            [24]  910 	jnz	00104$
      00738F 22               [24]  911 	ret
      007390                        912 00104$:
                                    913 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      007390 12 6F 8F         [24]  914 	lcall	_ak820_outline_0058
      007393 C0 04            [24]  915 	push	ar4
      007395 C0 03            [24]  916 	push	ar3
      007397 12 A1 68         [24]  917 	lcall	_process_record_quantum
      00739A E5 82            [12]  918 	mov	a, dpl
      00739C D0 03            [24]  919 	pop	ar3
      00739E D0 04            [24]  920 	pop	ar4
      0073A0 70 0A            [24]  921 	jnz	00106$
                                    922 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0073A2 90 05 9C         [24]  923 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0073A5 EB               [12]  924 	mov	a,r3
      0073A6 F0               [24]  925 	movx	@dptr,a
      0073A7 8C 82            [24]  926 	mov	dpl, r4
                                    927 ;	quantum/action.c:360: return;
      0073A9 02 2E 6F         [24]  928 	ljmp	_ak820_oneshot_post
      0073AC                        929 00106$:
                                    930 ;	quantum/action.c:366: process_record_handler(record);
      0073AC 90 08 30         [24]  931 	mov	dptr,#_process_record_record_10000_633
      0073AF 12 50 13         [24]  932 	lcall	_ak820_outline_0001
      0073B2 C0 04            [24]  933 	push	ar4
      0073B4 C0 03            [24]  934 	push	ar3
      0073B6 12 73 D0         [24]  935 	lcall	_process_record_handler
                                    936 ;	quantum/action.c:370: post_process_record_quantum(record);
      0073B9 90 08 30         [24]  937 	mov	dptr,#_process_record_record_10000_633
      0073BC 12 50 13         [24]  938 	lcall	_ak820_outline_0001
      0073BF 12 A1 3D         [24]  939 	lcall	_post_process_record_quantum
      0073C2 D0 03            [24]  940 	pop	ar3
      0073C4 D0 04            [24]  941 	pop	ar4
                                    942 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0073C6 90 05 9C         [24]  943 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0073C9 EB               [12]  944 	mov	a,r3
      0073CA F0               [24]  945 	movx	@dptr,a
      0073CB 8C 82            [24]  946 	mov	dpl, r4
                                    947 ;	quantum/action.c:374: }
      0073CD 02 2E 6F         [24]  948 	ljmp	_ak820_oneshot_post
                                    949 ;------------------------------------------------------------
                                    950 ;Allocation info for local variables in function 'process_record_handler'
                                    951 ;------------------------------------------------------------
                                    952 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_641'
                                    953 ;record        Allocated with name '_process_record_handler_record_10000_642'
                                    954 ;action        Allocated with name '_process_record_handler_action_10000_642'
                                    955 ;------------------------------------------------------------
                                    956 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                    957 ;	-----------------------------------------
                                    958 ;	 function process_record_handler
                                    959 ;	-----------------------------------------
      0073D0                        960 _process_record_handler:
      0073D0 12 43 80         [24]  961 	lcall	_ak820_outline_0038
      0073D3 90 08 33         [24]  962 	mov	dptr,#_process_record_handler_record_argument_10000_641
      0073D6 12 38 29         [24]  963 	lcall	_ak820_outline_0018
                                    964 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      0073D9 90 08 33         [24]  965 	mov	dptr,#_process_record_handler_record_argument_10000_641
      0073DC 12 37 FE         [24]  966 	lcall	_ak820_outline_0008
                                    967 ;	quantum/action.c:387: if (record->keycode) {
      0073DF 4C               [12]  968 	orl	a,r4
      0073E0 60 19            [24]  969 	jz	00102$
                                    970 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      0073E2 12 38 97         [24]  971 	lcall	_ak820_outline_0124
      0073E5 C0 07            [24]  972 	push	ar7
      0073E7 C0 06            [24]  973 	push	ar6
      0073E9 12 96 DC         [24]  974 	lcall	_action_for_keycode
      0073EC 12 43 DA         [24]  975 	lcall	_ak820_outline_0149
      0073EF D0 06            [24]  976 	pop	ar6
      0073F1 D0 07            [24]  977 	pop	ar7
      0073F3 90 08 36         [24]  978 	mov	dptr,#_process_record_handler_action_10000_642
      0073F6 12 38 5E         [24]  979 	lcall	_ak820_outline_0073
      0073F9 80 2A            [24]  980 	sjmp	00104$
      0073FB                        981 00102$:
                                    982 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      0073FB 12 78 DB         [24]  983 	lcall	_ak820_outline_0022
      0073FE 7A 00            [12]  984 	mov	r2,#0x00
      007400 12 43 D4         [24]  985 	lcall	_ak820_outline_0142
      007403 12 43 6E         [24]  986 	lcall	_ak820_outline_0012
      007406 E0               [24]  987 	movx	a,@dptr
      007407 90 09 72         [24]  988 	mov	dptr,#_ak820_resolve_key_PARM_2
      00740A F0               [24]  989 	movx	@dptr,a
      00740B 12 43 FA         [24]  990 	lcall	_ak820_outline_0189
      00740E C0 07            [24]  991 	push	ar7
      007410 C0 06            [24]  992 	push	ar6
      007412 12 7C 82         [24]  993 	lcall	_ak820_resolve_key
      007415 12 96 DC         [24]  994 	lcall	_action_for_keycode
      007418 12 43 DA         [24]  995 	lcall	_ak820_outline_0149
      00741B D0 06            [24]  996 	pop	ar6
      00741D D0 07            [24]  997 	pop	ar7
      00741F 90 08 36         [24]  998 	mov	dptr,#_process_record_handler_action_10000_642
      007422 12 38 5E         [24]  999 	lcall	_ak820_outline_0073
                                   1000 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      007425                       1001 00104$:
                                   1002 ;	quantum/action.c:411: process_action(record, action);
      007425 7D 00            [12] 1003 	mov	r5,#0x00
      007427 90 0D A9         [24] 1004 	mov	dptr,#___memcpy_PARM_2
      00742A 74 36            [12] 1005 	mov	a,#_process_record_handler_action_10000_642
      00742C F0               [24] 1006 	movx	@dptr,a
      00742D 74 08            [12] 1007 	mov	a,#(_process_record_handler_action_10000_642 >> 8)
      00742F 12 38 70         [24] 1008 	lcall	_ak820_outline_0094
      007432 90 0D AC         [24] 1009 	mov	dptr,#___memcpy_PARM_3
      007435 12 50 7E         [24] 1010 	lcall	_ak820_outline_0110
      007438 90 08 38         [24] 1011 	mov	dptr,#_process_action_PARM_2
      00743B F5 F0            [12] 1012 	mov	b,a
      00743D C0 07            [24] 1013 	push	ar7
      00743F C0 06            [24] 1014 	push	ar6
      007441 C0 05            [24] 1015 	push	ar5
      007443 12 BA AB         [24] 1016 	lcall	___memcpy
      007446 D0 05            [24] 1017 	pop	ar5
      007448 D0 06            [24] 1018 	pop	ar6
      00744A D0 07            [24] 1019 	pop	ar7
      00744C 12 71 A3         [24] 1020 	lcall	_ak820_outline_0065
                                   1021 ;	quantum/action.c:412: }
      00744F 02 74 52         [24] 1022 	ljmp	_process_action
                                   1023 ;------------------------------------------------------------
                                   1024 ;Allocation info for local variables in function 'register_mouse'
                                   1025 ;------------------------------------------------------------
                                   1026 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1027 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_650'
                                   1028 ;------------------------------------------------------------
                                   1029 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1030 ;	-----------------------------------------
                                   1031 ;	 function process_action
                                   1032 ;	-----------------------------------------
      007452                       1033 _process_action:
      007452 12 43 80         [24] 1034 	lcall	_ak820_outline_0038
      007455 90 08 3A         [24] 1035 	mov	dptr,#_process_action_record_argument_10000_653
      007458 12 38 29         [24] 1036 	lcall	_ak820_outline_0018
                                   1037 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00745B 90 08 3A         [24] 1038 	mov	dptr,#_process_action_record_argument_10000_653
      00745E 12 37 F4         [24] 1039 	lcall	_ak820_outline_0005
                                   1040 ;	quantum/action.c:483: pressed = record->event.pressed;
      007461 A3               [24] 1041 	inc	dptr
      007462 A3               [24] 1042 	inc	dptr
      007463 A3               [24] 1043 	inc	dptr
      007464 A3               [24] 1044 	inc	dptr
      007465 A3               [24] 1045 	inc	dptr
      007466 E0               [24] 1046 	movx	a,@dptr
      007467 F5 27            [12] 1047 	mov	_process_action_sloc0_1_0,a
                                   1048 ;	quantum/action.c:507: switch (action.kind.id) {
      007469 90 08 39         [24] 1049 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00746C E0               [24] 1050 	movx	a,@dptr
      00746D C4               [12] 1051 	swap	a
      00746E 54 0F            [12] 1052 	anl	a,#0x0f
      007470 FD               [12] 1053 	mov  r5,a
      007471 24 F4            [12] 1054 	add	a,#0xff - 0x0b
      007473 50 03            [24] 1055 	jnc	00434$
      007475 02 76 F3         [24] 1056 	ljmp	00181$
      007478                       1057 00434$:
                                   1058 ;	free result
      007478 ED               [12] 1059 	mov	a,r5
      007479 24 0A            [12] 1060 	add	a,#(00435$-3-.)
      00747B 83               [24] 1061 	movc	a,@a+pc
      00747C F5 82            [12] 1062 	mov	dpl,a
      00747E ED               [12] 1063 	mov	a,r5
      00747F 24 10            [12] 1064 	add	a,#(00436$-3-.)
      007481 83               [24] 1065 	movc	a,@a+pc
      007482 F5 83            [12] 1066 	mov	dph,a
      007484 E4               [12] 1067 	clr	a
      007485 73               [24] 1068 	jmp	@a+dptr
      007486                       1069 00435$:
      007486 9E                    1070 	.db	00102$
      007487 9E                    1071 	.db	00102$
      007488 F3                    1072 	.db	00181$
      007489 F3                    1073 	.db	00181$
      00748A 28                    1074 	.db	00123$
      00748B F3                    1075 	.db	00181$
      00748C F3                    1076 	.db	00181$
      00748D F3                    1077 	.db	00181$
      00748E 88                    1078 	.db	00131$
      00748F 5A                    1079 	.db	00147$
      007490 80                    1080 	.db	00152$
      007491 80                    1081 	.db	00152$
      007492                       1082 00436$:
      007492 74                    1083 	.db	00102$>>8
      007493 74                    1084 	.db	00102$>>8
      007494 76                    1085 	.db	00181$>>8
      007495 76                    1086 	.db	00181$>>8
      007496 75                    1087 	.db	00123$>>8
      007497 76                    1088 	.db	00181$>>8
      007498 76                    1089 	.db	00181$>>8
      007499 76                    1090 	.db	00181$>>8
      00749A 75                    1091 	.db	00131$>>8
      00749B 76                    1092 	.db	00147$>>8
      00749C 76                    1093 	.db	00152$>>8
      00749D 76                    1094 	.db	00152$>>8
                                   1095 ;	quantum/action.c:510: case ACT_RMODS: {
      00749E                       1096 00102$:
                                   1097 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      00749E 90 08 39         [24] 1098 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074A1 E0               [24] 1099 	movx	a,@dptr
      0074A2 54 F0            [12] 1100 	anl	a,#0xf0
      0074A4 70 06            [24] 1101 	jnz	00194$
      0074A6 12 79 14         [24] 1102 	lcall	_ak820_outline_0113
      0074A9 FD               [12] 1103 	mov	r5,a
      0074AA 80 07            [24] 1104 	sjmp	00195$
      0074AC                       1105 00194$:
      0074AC 12 79 14         [24] 1106 	lcall	_ak820_outline_0113
      0074AF C4               [12] 1107 	swap	a
      0074B0 54 F0            [12] 1108 	anl	a,#0xf0
      0074B2 FD               [12] 1109 	mov	r5,a
      0074B3                       1110 00195$:
                                   1111 ;	quantum/action.c:513: if (pressed) {
      0074B3 E5 27            [12] 1112 	mov	a,_process_action_sloc0_1_0
      0074B5 60 35            [24] 1113 	jz	00119$
                                   1114 ;	quantum/action.c:514: if (mods) {
      0074B7 ED               [12] 1115 	mov	a,r5
      0074B8 60 29            [24] 1116 	jz	00110$
                                   1117 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0074BA 12 79 30         [24] 1118 	lcall	_ak820_outline_0159
      0074BD FC               [12] 1119 	mov	r4,a
      0074BE BC E0 00         [24] 1120 	cjne	r4,#0xe0,00440$
      0074C1                       1121 00440$:
      0074C1 40 07            [24] 1122 	jc	00108$
      0074C3 12 79 30         [24] 1123 	lcall	_ak820_outline_0159
      0074C6 24 18            [12] 1124 	add	a,#0xff - 0xe7
      0074C8 50 0A            [24] 1125 	jnc	00104$
                                   1126 ;	free result
      0074CA                       1127 00108$:
      0074CA 7B 38            [12] 1128 	mov	r3,#_process_action_PARM_2
      0074CC 7C 08            [12] 1129 	mov	r4,#(_process_action_PARM_2 >> 8)
      0074CE 12 33 FC         [24] 1130 	lcall	_ak820_outline_0121
      0074D1 E0               [24] 1131 	movx	a,@dptr
      0074D2 70 07            [24] 1132 	jnz	00105$
      0074D4                       1133 00104$:
                                   1134 ;	quantum/action.c:519: add_owned_mods(mods);
      0074D4 8D 82            [24] 1135 	mov	dpl, r5
      0074D6 12 7E EC         [24] 1136 	lcall	_add_owned_mods
      0074D9 80 05            [24] 1137 	sjmp	00106$
      0074DB                       1138 00105$:
                                   1139 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      0074DB 8D 82            [24] 1140 	mov	dpl, r5
      0074DD 12 7F 0B         [24] 1141 	lcall	_add_owned_weak_mods
      0074E0                       1142 00106$:
                                   1143 ;	quantum/action.c:523: send_keyboard_report();
      0074E0 12 82 26         [24] 1144 	lcall	_send_keyboard_report
      0074E3                       1145 00110$:
                                   1146 ;	quantum/action.c:525: register_code(action.key.code);
      0074E3 12 79 04         [24] 1147 	lcall	_ak820_outline_0079
      0074E6 12 77 0A         [24] 1148 	lcall	_register_code
      0074E9 02 76 F3         [24] 1149 	ljmp	00181$
      0074EC                       1150 00119$:
                                   1151 ;	quantum/action.c:527: unregister_code(action.key.code);
      0074EC 12 79 04         [24] 1152 	lcall	_ak820_outline_0079
      0074EF C0 05            [24] 1153 	push	ar5
      0074F1 12 77 77         [24] 1154 	lcall	_unregister_code
      0074F4 D0 05            [24] 1155 	pop	ar5
                                   1156 ;	quantum/action.c:528: if (mods) {
      0074F6 ED               [12] 1157 	mov	a,r5
      0074F7 70 03            [24] 1158 	jnz	00444$
      0074F9 02 76 F3         [24] 1159 	ljmp	00181$
      0074FC                       1160 00444$:
                                   1161 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0074FC 12 79 30         [24] 1162 	lcall	_ak820_outline_0159
      0074FF FC               [12] 1163 	mov	r4,a
      007500 BC E0 00         [24] 1164 	cjne	r4,#0xe0,00445$
      007503                       1165 00445$:
      007503 40 07            [24] 1166 	jc	00115$
      007505 12 79 30         [24] 1167 	lcall	_ak820_outline_0159
      007508 24 18            [12] 1168 	add	a,#0xff - 0xe7
      00750A 50 0A            [24] 1169 	jnc	00111$
                                   1170 ;	free result
      00750C                       1171 00115$:
      00750C 7B 38            [12] 1172 	mov	r3,#_process_action_PARM_2
      00750E 7C 08            [12] 1173 	mov	r4,#(_process_action_PARM_2 >> 8)
      007510 12 33 FC         [24] 1174 	lcall	_ak820_outline_0121
      007513 E0               [24] 1175 	movx	a,@dptr
      007514 70 07            [24] 1176 	jnz	00112$
      007516                       1177 00111$:
                                   1178 ;	quantum/action.c:530: del_owned_mods(mods);
      007516 8D 82            [24] 1179 	mov	dpl, r5
      007518 12 7E FC         [24] 1180 	lcall	_del_owned_mods
      00751B 80 05            [24] 1181 	sjmp	00113$
      00751D                       1182 00112$:
                                   1183 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      00751D 8D 82            [24] 1184 	mov	dpl, r5
      00751F 12 7F 1B         [24] 1185 	lcall	_del_owned_weak_mods
      007522                       1186 00113$:
                                   1187 ;	quantum/action.c:534: send_keyboard_report();
      007522 12 82 26         [24] 1188 	lcall	_send_keyboard_report
                                   1189 ;	quantum/action.c:537: } break;
      007525 02 76 F3         [24] 1190 	ljmp	00181$
                                   1191 ;	quantum/action.c:614: case ACT_USAGE:
      007528                       1192 00123$:
                                   1193 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007528 74 07            [12] 1194 	mov	a,#0x07
      00752A 12 38 31         [24] 1195 	lcall	_ak820_outline_0023
      00752D 12 49 76         [24] 1196 	lcall	_ak820_outline_0009
      007530 C3               [12] 1197 	clr	c
      007531 EC               [12] 1198 	mov	a,r4
      007532 94 A5            [12] 1199 	subb	a,#0xa5
      007534 ED               [12] 1200 	mov	a,r5
      007535 94 00            [12] 1201 	subb	a,#0x00
      007537 40 15            [24] 1202 	jc	00125$
      007539 74 C2            [12] 1203 	mov	a,#0xc2
      00753B 9C               [12] 1204 	subb	a,r4
      00753C E4               [12] 1205 	clr	a
      00753D 9D               [12] 1206 	subb	a,r5
      00753E 40 0E            [24] 1207 	jc	00125$
                                   1208 ;	free result
                                   1209 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      007540 90 0A 9C         [24] 1210 	mov	dptr,#_owned_usage_key_PARM_2
      007543 E5 27            [12] 1211 	mov	a,_process_action_sloc0_1_0
      007545 F0               [24] 1212 	movx	@dptr,a
      007546 8E 82            [24] 1213 	mov	dpl, r6
      007548 12 80 D1         [24] 1214 	lcall	_owned_usage_key
                                   1215 ;	quantum/action.c:622: break;
      00754B 02 76 F3         [24] 1216 	ljmp	00181$
      00754E                       1217 00125$:
                                   1218 ;	quantum/action.c:625: switch (action.usage.page) {
      00754E 12 79 0B         [24] 1219 	lcall	_ak820_outline_0090
      007551 FF               [12] 1220 	mov	r7,a
      007552 60 08            [24] 1221 	jz	00127$
      007554 BF 01 02         [24] 1222 	cjne	r7,#0x01,00452$
      007557 80 19            [24] 1223 	sjmp	00128$
      007559                       1224 00452$:
      007559 02 76 F3         [24] 1225 	ljmp	00181$
                                   1226 ;	quantum/action.c:626: case PAGE_SYSTEM:
      00755C                       1227 00127$:
                                   1228 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      00755C E5 27            [12] 1229 	mov	a,_process_action_sloc0_1_0
      00755E 60 05            [24] 1230 	jz	00196$
      007560 12 79 1B         [24] 1231 	lcall	_ak820_outline_0130
      007563 80 04            [24] 1232 	sjmp	00197$
      007565                       1233 00196$:
      007565 7E 00            [12] 1234 	mov	r6,#0x00
      007567 7F 00            [12] 1235 	mov	r7,#0x00
      007569                       1236 00197$:
      007569 12 38 8C         [24] 1237 	lcall	_ak820_outline_0118
      00756C 12 6F 19         [24] 1238 	lcall	_host_system_send
                                   1239 ;	quantum/action.c:628: break;
      00756F 02 76 F3         [24] 1240 	ljmp	00181$
                                   1241 ;	quantum/action.c:629: case PAGE_CONSUMER:
      007572                       1242 00128$:
                                   1243 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      007572 E5 27            [12] 1244 	mov	a,_process_action_sloc0_1_0
      007574 60 05            [24] 1245 	jz	00198$
      007576 12 79 1B         [24] 1246 	lcall	_ak820_outline_0130
      007579 80 04            [24] 1247 	sjmp	00199$
      00757B                       1248 00198$:
      00757B 7E 00            [12] 1249 	mov	r6,#0x00
      00757D 7F 00            [12] 1250 	mov	r7,#0x00
      00757F                       1251 00199$:
      00757F 12 38 8C         [24] 1252 	lcall	_ak820_outline_0118
      007582 12 6F 49         [24] 1253 	lcall	_host_consumer_send
                                   1254 ;	quantum/action.c:633: break;
      007585 02 76 F3         [24] 1255 	ljmp	00181$
                                   1256 ;	quantum/action.c:640: case ACT_LAYER: {
      007588                       1257 00131$:
                                   1258 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      007588 90 08 39         [24] 1259 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00758B E0               [24] 1260 	movx	a,@dptr
      00758C 54 03            [12] 1261 	anl	a,#0x03
      00758E 90 08 3D         [24] 1262 	mov	dptr,#_process_action_on_40000_676
      007591 F0               [24] 1263 	movx	@dptr,a
                                   1264 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      007592 E0               [24] 1265 	movx	a,@dptr
      007593 FF               [12] 1266 	mov	r7,a
      007594 60 11            [24] 1267 	jz	00200$
      007596 E5 27            [12] 1268 	mov	a,_process_action_sloc0_1_0
      007598 60 07            [24] 1269 	jz	00202$
      00759A 8F 06            [24] 1270 	mov	ar6,r7
      00759C 53 06 01         [24] 1271 	anl	ar6,#0x01
      00759F 80 10            [24] 1272 	sjmp	00201$
      0075A1                       1273 00202$:
      0075A1 74 02            [12] 1274 	mov	a,#0x02
      0075A3 5F               [12] 1275 	anl	a,r7
      0075A4 FE               [12] 1276 	mov	r6,a
      0075A5 80 0A            [24] 1277 	sjmp	00201$
      0075A7                       1278 00200$:
      0075A7 E5 27            [12] 1279 	mov	a,_process_action_sloc0_1_0
      0075A9 B4 01 00         [24] 1280 	cjne	a,#0x01,00457$
      0075AC                       1281 00457$:
      0075AC 92 1F            [24] 1282 	mov  _process_action_sloc1_1_0,c
      0075AE E4               [12] 1283 	clr	a
      0075AF 33               [12] 1284 	rlc	a
      0075B0 FE               [12] 1285 	mov	r6,a
      0075B1                       1286 00201$:
      0075B1 EE               [12] 1287 	mov	a,r6
      0075B2 70 03            [24] 1288 	jnz	00458$
      0075B4 02 76 F3         [24] 1289 	ljmp	00181$
      0075B7                       1290 00458$:
                                   1291 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      0075B7 12 79 30         [24] 1292 	lcall	_ak820_outline_0159
      0075BA C4               [12] 1293 	swap	a
      0075BB 03               [12] 1294 	rr	a
      0075BC 54 07            [12] 1295 	anl	a,#0x07
      0075BE 25 E0            [12] 1296 	add	a,acc
      0075C0 25 E0            [12] 1297 	add	a,acc
      0075C2 FF               [12] 1298 	mov	r7,a
                                   1299 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0075C3 12 79 30         [24] 1300 	lcall	_ak820_outline_0159
      0075C6 54 0F            [12] 1301 	anl	a,#0x0f
      0075C8 FE               [12] 1302 	mov	r6,a
      0075C9 8F F0            [24] 1303 	mov	b,r7
      0075CB 05 F0            [12] 1304 	inc	b
      0075CD EE               [12] 1305 	mov	a,r6
      0075CE 80 02            [24] 1306 	sjmp	00460$
      0075D0                       1307 00459$:
      0075D0 25 E0            [12] 1308 	add	a,acc
      0075D2                       1309 00460$:
      0075D2 D5 F0 FB         [24] 1310 	djnz	b,00459$
      0075D5 FE               [12] 1311 	mov	r6,a
                                   1312 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      0075D6 12 79 30         [24] 1313 	lcall	_ak820_outline_0159
      0075D9 30 E4 11         [24] 1314 	jnb	acc.4,00204$
      0075DC 8F F0            [24] 1315 	mov	b,r7
      0075DE 05 F0            [12] 1316 	inc	b
      0075E0 74 0F            [12] 1317 	mov	a,#0x0f
      0075E2 80 02            [24] 1318 	sjmp	00463$
      0075E4                       1319 00462$:
      0075E4 25 E0            [12] 1320 	add	a,acc
      0075E6                       1321 00463$:
      0075E6 D5 F0 FB         [24] 1322 	djnz	b,00462$
      0075E9 F4               [12] 1323 	cpl	a
      0075EA FF               [12] 1324 	mov	r7,a
      0075EB 80 02            [24] 1325 	sjmp	00205$
      0075ED                       1326 00204$:
      0075ED 7F 00            [12] 1327 	mov	r7,#0x00
      0075EF                       1328 00205$:
                                   1329 ;	quantum/action.c:648: bits |= mask;
      0075EF EE               [12] 1330 	mov	a,r6
      0075F0 42 07            [12] 1331 	orl	ar7,a
                                   1332 ;	quantum/action.c:649: if (!on) {
      0075F2 90 08 3D         [24] 1333 	mov	dptr,#_process_action_on_40000_676
      0075F5 E0               [24] 1334 	movx	a,@dptr
      0075F6 70 31            [24] 1335 	jnz	00143$
                                   1336 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      0075F8 12 79 0B         [24] 1337 	lcall	_ak820_outline_0090
      0075FB FE               [12] 1338 	mov	r6,a
      0075FC 2E               [12] 1339 	add	a,r6
                                   1340 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      0075FD 90 76 01         [24] 1341 	mov	dptr,#00465$
      007600 73               [24] 1342 	jmp	@a+dptr
      007601                       1343 00465$:
      007601 80 06            [24] 1344 	sjmp	00132$
      007603 80 0C            [24] 1345 	sjmp	00133$
      007605 80 12            [24] 1346 	sjmp	00134$
      007607 80 18            [24] 1347 	sjmp	00135$
      007609                       1348 00132$:
      007609 8F 82            [24] 1349 	mov	dpl, r7
      00760B 12 79 90         [24] 1350 	lcall	_default_layer_and
      00760E 02 76 F3         [24] 1351 	ljmp	00181$
                                   1352 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      007611                       1353 00133$:
      007611 8F 82            [24] 1354 	mov	dpl, r7
      007613 12 79 7F         [24] 1355 	lcall	_default_layer_or
      007616 02 76 F3         [24] 1356 	ljmp	00181$
                                   1357 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      007619                       1358 00134$:
      007619 8F 82            [24] 1359 	mov	dpl, r7
      00761B 12 79 A6         [24] 1360 	lcall	_default_layer_xor
      00761E 02 76 F3         [24] 1361 	ljmp	00181$
                                   1362 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      007621                       1363 00135$:
      007621 8F 82            [24] 1364 	mov	dpl, r7
      007623 12 79 74         [24] 1365 	lcall	_default_layer_set
                                   1366 ;	quantum/action.c:655: }
      007626 02 76 F3         [24] 1367 	ljmp	00181$
      007629                       1368 00143$:
                                   1369 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      007629 12 79 0B         [24] 1370 	lcall	_ak820_outline_0090
      00762C FE               [12] 1371 	mov	r6,a
      00762D 2E               [12] 1372 	add	a,r6
                                   1373 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      00762E 90 76 32         [24] 1374 	mov	dptr,#00466$
      007631 73               [24] 1375 	jmp	@a+dptr
      007632                       1376 00466$:
      007632 80 06            [24] 1377 	sjmp	00137$
      007634 80 0C            [24] 1378 	sjmp	00138$
      007636 80 12            [24] 1379 	sjmp	00139$
      007638 80 18            [24] 1380 	sjmp	00140$
      00763A                       1381 00137$:
      00763A 8F 82            [24] 1382 	mov	dpl, r7
      00763C 12 7B 2A         [24] 1383 	lcall	_layer_and
      00763F 02 76 F3         [24] 1384 	ljmp	00181$
                                   1385 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      007642                       1386 00138$:
      007642 8F 82            [24] 1387 	mov	dpl, r7
      007644 12 7B 19         [24] 1388 	lcall	_layer_or
      007647 02 76 F3         [24] 1389 	ljmp	00181$
                                   1390 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      00764A                       1391 00139$:
      00764A 8F 82            [24] 1392 	mov	dpl, r7
      00764C 12 7B 40         [24] 1393 	lcall	_layer_xor
      00764F 02 76 F3         [24] 1394 	ljmp	00181$
                                   1395 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      007652                       1396 00140$:
      007652 8F 82            [24] 1397 	mov	dpl, r7
      007654 12 7A B6         [24] 1398 	lcall	_layer_state_set
                                   1399 ;	quantum/action.c:665: break;
      007657 02 76 F3         [24] 1400 	ljmp	00181$
                                   1401 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      00765A                       1402 00147$:
                                   1403 ;	quantum/action.c:668: if (pressed) {
      00765A E5 27            [12] 1404 	mov	a,_process_action_sloc0_1_0
      00765C 60 11            [24] 1405 	jz	00149$
                                   1406 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      00765E 12 79 14         [24] 1407 	lcall	_ak820_outline_0113
      007661 F5 82            [12] 1408 	mov	dpl,a
      007663 12 7A 16         [24] 1409 	lcall	_layer_hold_on
                                   1410 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      007666 12 79 04         [24] 1411 	lcall	_ak820_outline_0079
      007669 12 78 2D         [24] 1412 	lcall	_register_mods
      00766C 02 76 F3         [24] 1413 	ljmp	00181$
      00766F                       1414 00149$:
                                   1415 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      00766F 12 79 04         [24] 1416 	lcall	_ak820_outline_0079
      007672 12 78 41         [24] 1417 	lcall	_unregister_mods
                                   1418 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      007675 12 79 14         [24] 1419 	lcall	_ak820_outline_0113
      007678 F5 82            [12] 1420 	mov	dpl,a
      00767A 12 7A 4E         [24] 1421 	lcall	_layer_hold_off
                                   1422 ;	quantum/action.c:675: break;
      00767D 02 76 F3         [24] 1423 	ljmp	00181$
                                   1424 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      007680                       1425 00152$:
                                   1426 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      007680 12 79 30         [24] 1427 	lcall	_ak820_outline_0159
      007683 FF               [12] 1428 	mov	r7,a
      007684 BF F1 02         [24] 1429 	cjne	r7,#0xf1,00468$
      007687 80 0A            [24] 1430 	sjmp	00154$
      007689                       1431 00468$:
      007689 BF F2 02         [24] 1432 	cjne	r7,#0xf2,00469$
      00768C 80 19            [24] 1433 	sjmp	00155$
      00768E                       1434 00469$:
                                   1435 ;	quantum/action.c:694: momentary_layer_action:
      00768E BF F3 3B         [24] 1436 	cjne	r7,#0xf3,00160$
      007691 80 28            [24] 1437 	sjmp	00156$
      007693                       1438 00154$:
                                   1439 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      007693 E5 27            [12] 1440 	mov	a,_process_action_sloc0_1_0
      007695 60 08            [24] 1441 	jz	00206$
      007697 12 78 EA         [24] 1442 	lcall	_ak820_outline_0043
      00769A 12 7A 16         [24] 1443 	lcall	_layer_hold_on
      00769D 80 54            [24] 1444 	sjmp	00181$
      00769F                       1445 00206$:
      00769F 12 78 EA         [24] 1446 	lcall	_ak820_outline_0043
      0076A2 12 7A 4E         [24] 1447 	lcall	_layer_hold_off
                                   1448 ;	quantum/action.c:696: break;
                                   1449 ;	quantum/action.c:697: case OP_OFF_ON:
      0076A5 80 4C            [24] 1450 	sjmp	00181$
      0076A7                       1451 00155$:
                                   1452 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0076A7 E5 27            [12] 1453 	mov	a,_process_action_sloc0_1_0
      0076A9 60 08            [24] 1454 	jz	00208$
      0076AB 12 78 EA         [24] 1455 	lcall	_ak820_outline_0043
      0076AE 12 7A FB         [24] 1456 	lcall	_layer_off
      0076B1 80 40            [24] 1457 	sjmp	00181$
      0076B3                       1458 00208$:
      0076B3 12 78 EA         [24] 1459 	lcall	_ak820_outline_0043
      0076B6 12 7A E0         [24] 1460 	lcall	_layer_on
                                   1461 ;	quantum/action.c:699: break;
                                   1462 ;	quantum/action.c:700: case OP_SET_CLEAR:
      0076B9 80 38            [24] 1463 	sjmp	00181$
      0076BB                       1464 00156$:
                                   1465 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0076BB E5 27            [12] 1466 	mov	a,_process_action_sloc0_1_0
      0076BD 60 08            [24] 1467 	jz	00210$
      0076BF 12 78 EA         [24] 1468 	lcall	_ak820_outline_0043
      0076C2 12 7A CA         [24] 1469 	lcall	_layer_move
      0076C5 80 2C            [24] 1470 	sjmp	00181$
      0076C7                       1471 00210$:
      0076C7 12 7A C4         [24] 1472 	lcall	_layer_clear
                                   1473 ;	quantum/action.c:702: break;
                                   1474 ;	quantum/action.c:748: default:
      0076CA 80 27            [24] 1475 	sjmp	00181$
      0076CC                       1476 00160$:
                                   1477 ;	quantum/action.c:755: if (pressed) {
      0076CC E5 27            [12] 1478 	mov	a,_process_action_sloc0_1_0
      0076CE 60 08            [24] 1479 	jz	00163$
                                   1480 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      0076D0 12 79 04         [24] 1481 	lcall	_ak820_outline_0079
      0076D3 12 77 0A         [24] 1482 	lcall	_register_code
                                   1483 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      0076D6 80 1B            [24] 1484 	sjmp	00181$
      0076D8                       1485 00163$:
                                   1486 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      0076D8 12 79 30         [24] 1487 	lcall	_ak820_outline_0159
      0076DB FF               [12] 1488 	mov	r7,a
      0076DC BF 39 0E         [24] 1489 	cjne	r7,#0x39,00175$
                                   1490 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      0076DF 7F 50            [12] 1491 	mov	r7,#0x50
      0076E1                       1492 00187$:
      0076E1 EF               [12] 1493 	mov	a,r7
      0076E2 60 09            [24] 1494 	jz	00175$
      0076E4 90 00 01         [24] 1495 	mov	dptr,#0x0001
      0076E7 12 5A 0D         [24] 1496 	lcall	_mDelaymS
      0076EA 1F               [12] 1497 	dec	r7
                                   1498 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      0076EB 80 F4            [24] 1499 	sjmp	00187$
      0076ED                       1500 00175$:
                                   1501 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      0076ED 12 79 04         [24] 1502 	lcall	_ak820_outline_0079
      0076F0 12 77 77         [24] 1503 	lcall	_unregister_code
                                   1504 ;	quantum/action.c:848: }
      0076F3                       1505 00181$:
                                   1506 ;	quantum/action.c:869: switch (action.kind.id) {
      0076F3 90 08 39         [24] 1507 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0076F6 E0               [24] 1508 	movx	a,@dptr
      0076F7 C4               [12] 1509 	swap	a
      0076F8 54 0F            [12] 1510 	anl	a,#0x0f
      0076FA FF               [12] 1511 	mov	r7,a
      0076FB BF 08 02         [24] 1512 	cjne	r7,#0x08,00478$
      0076FE 80 03            [24] 1513 	sjmp	00183$
      007700                       1514 00478$:
      007700 BF 09 06         [24] 1515 	cjne	r7,#0x09,00192$
                                   1516 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      007703                       1517 00183$:
                                   1518 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      007703 12 6E 7E         [24] 1519 	lcall	_host_keyboard_leds
                                   1520 ;	quantum/action.c:880: }
                                   1521 ;	quantum/action.c:933: }
      007706 02 99 91         [24] 1522 	ljmp	_led_set
      007709                       1523 00192$:
      007709 22               [24] 1524 	ret
                                   1525 ;------------------------------------------------------------
                                   1526 ;Allocation info for local variables in function 'register_code'
                                   1527 ;------------------------------------------------------------
                                   1528 ;code          Allocated with name '_register_code_code_10000_710'
                                   1529 ;------------------------------------------------------------
                                   1530 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1531 ;	-----------------------------------------
                                   1532 ;	 function register_code
                                   1533 ;	-----------------------------------------
      00770A                       1534 _register_code:
      00770A E5 82            [12] 1535 	mov	a,dpl
      00770C 90 08 3E         [24] 1536 	mov	dptr,#_register_code_code_10000_710
      00770F F0               [24] 1537 	movx	@dptr,a
                                   1538 ;	quantum/action.c:940: if (code == KC_NO) {
      007710 E0               [24] 1539 	movx	a,@dptr
      007711 FF               [12] 1540 	mov	r7,a
      007712 70 01            [24] 1541 	jnz	00123$
                                   1542 ;	quantum/action.c:941: return;
      007714 22               [24] 1543 	ret
      007715                       1544 00123$:
                                   1545 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      007715 BF 04 00         [24] 1546 	cjne	r7,#0x04,00186$
      007718                       1547 00186$:
      007718 40 12            [24] 1548 	jc	00119$
      00771A EF               [12] 1549 	mov	a,r7
      00771B 24 5B            [12] 1550 	add	a,#0xff - 0xa4
      00771D 40 0D            [24] 1551 	jc	00119$
                                   1552 ;	free result
                                   1553 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      00771F 8F 82            [24] 1554 	mov	dpl, r7
      007721 12 7F 90         [24] 1555 	lcall	_add_owned_key
      007724 E5 82            [12] 1556 	mov	a, dpl
      007726 70 01            [24] 1557 	jnz	00104$
      007728 22               [24] 1558 	ret
      007729                       1559 00104$:
                                   1560 ;	quantum/action.c:995: send_keyboard_report();
      007729 02 82 26         [24] 1561 	ljmp	_send_keyboard_report
      00772C                       1562 00119$:
                                   1563 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      00772C 12 79 35         [24] 1564 	lcall	_ak820_outline_0167
      00772F BF E0 00         [24] 1565 	cjne	r7,#0xe0,00190$
      007732                       1566 00190$:
      007732 40 1A            [24] 1567 	jc	00115$
      007734 EF               [12] 1568 	mov	a,r7
      007735 24 18            [12] 1569 	add	a,#0xff - 0xe7
      007737 40 15            [24] 1570 	jc	00115$
                                   1571 ;	free result
                                   1572 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      007739 74 07            [12] 1573 	mov	a,#0x07
      00773B 5F               [12] 1574 	anl	a,r7
      00773C 12 78 F3         [24] 1575 	lcall	_ak820_outline_0062
      00773F 80 02            [24] 1576 	sjmp	00194$
      007741                       1577 00193$:
      007741 25 E0            [12] 1578 	add	a,acc
      007743                       1579 00194$:
      007743 D5 F0 FB         [24] 1580 	djnz	b,00193$
      007746 F5 82            [12] 1581 	mov	dpl,a
      007748 12 7E EC         [24] 1582 	lcall	_add_owned_mods
                                   1583 ;	quantum/action.c:998: send_keyboard_report();
      00774B 02 82 26         [24] 1584 	ljmp	_send_keyboard_report
      00774E                       1585 00115$:
                                   1586 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00774E 12 79 35         [24] 1587 	lcall	_ak820_outline_0167
      007751 BF A5 00         [24] 1588 	cjne	r7,#0xa5,00195$
      007754                       1589 00195$:
      007754 40 05            [24] 1590 	jc	00113$
      007756 EF               [12] 1591 	mov	a,r7
      007757 24 58            [12] 1592 	add	a,#0xff - 0xa7
      007759 50 0D            [24] 1593 	jnc	00108$
                                   1594 ;	free result
      00775B                       1595 00113$:
      00775B 12 79 35         [24] 1596 	lcall	_ak820_outline_0167
      00775E BF A8 00         [24] 1597 	cjne	r7,#0xa8,00198$
      007761                       1598 00198$:
      007761 40 13            [24] 1599 	jc	00125$
      007763 EF               [12] 1600 	mov	a,r7
      007764 24 3D            [12] 1601 	add	a,#0xff - 0xc2
      007766 40 0E            [24] 1602 	jc	00125$
                                   1603 ;	free result
      007768                       1604 00108$:
                                   1605 ;	quantum/action.c:1003: owned_usage_key(code, true);
      007768 12 79 35         [24] 1606 	lcall	_ak820_outline_0167
      00776B 90 0A 9C         [24] 1607 	mov	dptr,#_owned_usage_key_PARM_2
      00776E 74 01            [12] 1608 	mov	a,#0x01
      007770 F0               [24] 1609 	movx	@dptr,a
      007771 8F 82            [24] 1610 	mov	dpl, r7
                                   1611 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1612 ;	quantum/action.c:1013: }
      007773 02 80 D1         [24] 1613 	ljmp	_owned_usage_key
      007776                       1614 00125$:
      007776 22               [24] 1615 	ret
                                   1616 ;------------------------------------------------------------
                                   1617 ;Allocation info for local variables in function 'unregister_code'
                                   1618 ;------------------------------------------------------------
                                   1619 ;code          Allocated with name '_unregister_code_code_10000_724'
                                   1620 ;------------------------------------------------------------
                                   1621 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1622 ;	-----------------------------------------
                                   1623 ;	 function unregister_code
                                   1624 ;	-----------------------------------------
      007777                       1625 _unregister_code:
      007777 E5 82            [12] 1626 	mov	a,dpl
      007779 90 08 3F         [24] 1627 	mov	dptr,#_unregister_code_code_10000_724
      00777C F0               [24] 1628 	movx	@dptr,a
                                   1629 ;	quantum/action.c:1020: if (code == KC_NO) {
      00777D E0               [24] 1630 	movx	a,@dptr
      00777E FF               [12] 1631 	mov	r7,a
      00777F 70 01            [24] 1632 	jnz	00121$
                                   1633 ;	quantum/action.c:1021: return;
      007781 22               [24] 1634 	ret
      007782                       1635 00121$:
                                   1636 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      007782 BF 04 00         [24] 1637 	cjne	r7,#0x04,00184$
      007785                       1638 00184$:
      007785 40 12            [24] 1639 	jc	00117$
      007787 EF               [12] 1640 	mov	a,r7
      007788 24 5B            [12] 1641 	add	a,#0xff - 0xa4
      00778A 40 0D            [24] 1642 	jc	00117$
                                   1643 ;	free result
                                   1644 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      00778C 8F 82            [24] 1645 	mov	dpl, r7
      00778E 12 80 0A         [24] 1646 	lcall	_del_owned_key
      007791 E5 82            [12] 1647 	mov	a, dpl
      007793 70 01            [24] 1648 	jnz	00102$
      007795 22               [24] 1649 	ret
      007796                       1650 00102$:
                                   1651 ;	quantum/action.c:1062: send_keyboard_report();
      007796 02 82 26         [24] 1652 	ljmp	_send_keyboard_report
      007799                       1653 00117$:
                                   1654 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      007799 12 79 3B         [24] 1655 	lcall	_ak820_outline_0168
      00779C BF E0 00         [24] 1656 	cjne	r7,#0xe0,00188$
      00779F                       1657 00188$:
      00779F 40 1A            [24] 1658 	jc	00113$
      0077A1 EF               [12] 1659 	mov	a,r7
      0077A2 24 18            [12] 1660 	add	a,#0xff - 0xe7
      0077A4 40 15            [24] 1661 	jc	00113$
                                   1662 ;	free result
                                   1663 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      0077A6 74 07            [12] 1664 	mov	a,#0x07
      0077A8 5F               [12] 1665 	anl	a,r7
      0077A9 12 78 F3         [24] 1666 	lcall	_ak820_outline_0062
      0077AC 80 02            [24] 1667 	sjmp	00192$
      0077AE                       1668 00191$:
      0077AE 25 E0            [12] 1669 	add	a,acc
      0077B0                       1670 00192$:
      0077B0 D5 F0 FB         [24] 1671 	djnz	b,00191$
      0077B3 F5 82            [12] 1672 	mov	dpl,a
      0077B5 12 7E FC         [24] 1673 	lcall	_del_owned_mods
                                   1674 ;	quantum/action.c:1065: send_keyboard_report();
      0077B8 02 82 26         [24] 1675 	ljmp	_send_keyboard_report
      0077BB                       1676 00113$:
                                   1677 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0077BB 12 79 3B         [24] 1678 	lcall	_ak820_outline_0168
      0077BE BF A5 00         [24] 1679 	cjne	r7,#0xa5,00193$
      0077C1                       1680 00193$:
      0077C1 40 05            [24] 1681 	jc	00111$
      0077C3 EF               [12] 1682 	mov	a,r7
      0077C4 24 58            [12] 1683 	add	a,#0xff - 0xa7
      0077C6 50 0D            [24] 1684 	jnc	00106$
                                   1685 ;	free result
      0077C8                       1686 00111$:
      0077C8 12 79 3B         [24] 1687 	lcall	_ak820_outline_0168
      0077CB BF A8 00         [24] 1688 	cjne	r7,#0xa8,00196$
      0077CE                       1689 00196$:
      0077CE 40 12            [24] 1690 	jc	00123$
      0077D0 EF               [12] 1691 	mov	a,r7
      0077D1 24 3D            [12] 1692 	add	a,#0xff - 0xc2
      0077D3 40 0D            [24] 1693 	jc	00123$
                                   1694 ;	free result
      0077D5                       1695 00106$:
                                   1696 ;	quantum/action.c:1070: owned_usage_key(code, false);
      0077D5 12 79 3B         [24] 1697 	lcall	_ak820_outline_0168
      0077D8 90 0A 9C         [24] 1698 	mov	dptr,#_owned_usage_key_PARM_2
      0077DB E4               [12] 1699 	clr	a
      0077DC F0               [24] 1700 	movx	@dptr,a
      0077DD 8F 82            [24] 1701 	mov	dpl, r7
                                   1702 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1703 ;	quantum/action.c:1080: }
      0077DF 02 80 D1         [24] 1704 	ljmp	_owned_usage_key
      0077E2                       1705 00123$:
      0077E2 22               [24] 1706 	ret
                                   1707 ;------------------------------------------------------------
                                   1708 ;Allocation info for local variables in function 'tap_code_delay'
                                   1709 ;------------------------------------------------------------
                                   1710 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1711 ;code          Allocated with name '_tap_code_delay_code_10000_737'
                                   1712 ;i             Allocated with name '_tap_code_delay_i_20000_739'
                                   1713 ;i             Allocated with name '_tap_code_delay_i_50000_742'
                                   1714 ;------------------------------------------------------------
                                   1715 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1716 ;	-----------------------------------------
                                   1717 ;	 function tap_code_delay
                                   1718 ;	-----------------------------------------
      0077E3                       1719 _tap_code_delay:
      0077E3 E5 82            [12] 1720 	mov	a,dpl
      0077E5 90 08 42         [24] 1721 	mov	dptr,#_tap_code_delay_code_10000_737
      0077E8 F0               [24] 1722 	movx	@dptr,a
                                   1723 ;	quantum/action.c:1088: register_code(code);
      0077E9 E0               [24] 1724 	movx	a,@dptr
      0077EA FF               [12] 1725 	mov	r7,a
      0077EB F5 82            [12] 1726 	mov	dpl,a
      0077ED C0 07            [24] 1727 	push	ar7
      0077EF 12 77 0A         [24] 1728 	lcall	_register_code
      0077F2 D0 07            [24] 1729 	pop	ar7
                                   1730 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      0077F4 90 08 40         [24] 1731 	mov	dptr,#_tap_code_delay_PARM_2
      0077F7 12 38 64         [24] 1732 	lcall	_ak820_outline_0080
      0077FA                       1733 00110$:
      0077FA ED               [12] 1734 	mov	a,r5
      0077FB 4E               [12] 1735 	orl	a,r6
      0077FC 60 0D            [24] 1736 	jz	00105$
                                   1737 ;	quantum/action.c:1090: wait_ms(1);
      0077FE 90 00 01         [24] 1738 	mov	dptr,#0x0001
      007801 12 5A 0D         [24] 1739 	lcall	_mDelaymS
                                   1740 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007804 1D               [12] 1741 	dec	r5
      007805 BD FF 01         [24] 1742 	cjne	r5,#0xff,00141$
      007808 1E               [12] 1743 	dec	r6
      007809                       1744 00141$:
      007809 80 EF            [24] 1745 	sjmp	00110$
      00780B                       1746 00105$:
                                   1747 ;	quantum/action.c:1092: unregister_code(code);
      00780B 8F 82            [24] 1748 	mov	dpl, r7
                                   1749 ;	quantum/action.c:1093: }
      00780D 02 77 77         [24] 1750 	ljmp	_unregister_code
                                   1751 ;------------------------------------------------------------
                                   1752 ;Allocation info for local variables in function 'tap_code'
                                   1753 ;------------------------------------------------------------
                                   1754 ;code          Allocated with name '_tap_code_code_10000_744'
                                   1755 ;------------------------------------------------------------
                                   1756 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1757 ;	-----------------------------------------
                                   1758 ;	 function tap_code
                                   1759 ;	-----------------------------------------
      007810                       1760 _tap_code:
      007810 E5 82            [12] 1761 	mov	a,dpl
      007812 90 08 43         [24] 1762 	mov	dptr,#_tap_code_code_10000_744
      007815 F0               [24] 1763 	movx	@dptr,a
                                   1764 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007816 E0               [24] 1765 	movx	a,@dptr
      007817 FF               [12] 1766 	mov	r7,a
      007818 BF 39 04         [24] 1767 	cjne	r7,#0x39,00103$
      00781B 7E 50            [12] 1768 	mov	r6,#0x50
      00781D 80 02            [24] 1769 	sjmp	00104$
      00781F                       1770 00103$:
      00781F 7E 00            [12] 1771 	mov	r6,#0x00
      007821                       1772 00104$:
      007821 90 08 40         [24] 1773 	mov	dptr,#_tap_code_delay_PARM_2
      007824 EE               [12] 1774 	mov	a,r6
      007825 12 38 9C         [24] 1775 	lcall	_ak820_outline_0134
      007828 8F 82            [24] 1776 	mov	dpl, r7
                                   1777 ;	quantum/action.c:1101: }
      00782A 02 77 E3         [24] 1778 	ljmp	_tap_code_delay
                                   1779 ;------------------------------------------------------------
                                   1780 ;Allocation info for local variables in function 'register_mods'
                                   1781 ;------------------------------------------------------------
                                   1782 ;mods          Allocated with name '_register_mods_mods_10000_746'
                                   1783 ;------------------------------------------------------------
                                   1784 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1785 ;	-----------------------------------------
                                   1786 ;	 function register_mods
                                   1787 ;	-----------------------------------------
      00782D                       1788 _register_mods:
      00782D E5 82            [12] 1789 	mov	a,dpl
      00782F 90 08 44         [24] 1790 	mov	dptr,#_register_mods_mods_10000_746
      007832 F0               [24] 1791 	movx	@dptr,a
                                   1792 ;	quantum/action.c:1108: if (mods) {
      007833 E0               [24] 1793 	movx	a,@dptr
      007834 FF               [12] 1794 	mov	r7,a
      007835 E0               [24] 1795 	movx	a,@dptr
      007836 60 08            [24] 1796 	jz	00103$
                                   1797 ;	quantum/action.c:1109: add_owned_mods(mods);
      007838 8F 82            [24] 1798 	mov	dpl, r7
      00783A 12 7E EC         [24] 1799 	lcall	_add_owned_mods
                                   1800 ;	quantum/action.c:1110: send_keyboard_report();
                                   1801 ;	quantum/action.c:1112: }
      00783D 02 82 26         [24] 1802 	ljmp	_send_keyboard_report
      007840                       1803 00103$:
      007840 22               [24] 1804 	ret
                                   1805 ;------------------------------------------------------------
                                   1806 ;Allocation info for local variables in function 'unregister_mods'
                                   1807 ;------------------------------------------------------------
                                   1808 ;mods          Allocated with name '_unregister_mods_mods_10000_750'
                                   1809 ;------------------------------------------------------------
                                   1810 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1811 ;	-----------------------------------------
                                   1812 ;	 function unregister_mods
                                   1813 ;	-----------------------------------------
      007841                       1814 _unregister_mods:
      007841 E5 82            [12] 1815 	mov	a,dpl
      007843 90 08 45         [24] 1816 	mov	dptr,#_unregister_mods_mods_10000_750
      007846 F0               [24] 1817 	movx	@dptr,a
                                   1818 ;	quantum/action.c:1119: if (mods) {
      007847 E0               [24] 1819 	movx	a,@dptr
      007848 FF               [12] 1820 	mov	r7,a
      007849 E0               [24] 1821 	movx	a,@dptr
      00784A 60 08            [24] 1822 	jz	00103$
                                   1823 ;	quantum/action.c:1120: del_owned_mods(mods);
      00784C 8F 82            [24] 1824 	mov	dpl, r7
      00784E 12 7E FC         [24] 1825 	lcall	_del_owned_mods
                                   1826 ;	quantum/action.c:1121: send_keyboard_report();
                                   1827 ;	quantum/action.c:1123: }
      007851 02 82 26         [24] 1828 	ljmp	_send_keyboard_report
      007854                       1829 00103$:
      007854 22               [24] 1830 	ret
                                   1831 ;------------------------------------------------------------
                                   1832 ;Allocation info for local variables in function 'register_weak_mods'
                                   1833 ;------------------------------------------------------------
                                   1834 ;mods          Allocated with name '_register_weak_mods_mods_10000_754'
                                   1835 ;------------------------------------------------------------
                                   1836 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1837 ;	-----------------------------------------
                                   1838 ;	 function register_weak_mods
                                   1839 ;	-----------------------------------------
      007855                       1840 _register_weak_mods:
      007855 E5 82            [12] 1841 	mov	a,dpl
      007857 90 08 46         [24] 1842 	mov	dptr,#_register_weak_mods_mods_10000_754
      00785A F0               [24] 1843 	movx	@dptr,a
                                   1844 ;	quantum/action.c:1130: if (mods) {
      00785B E0               [24] 1845 	movx	a,@dptr
      00785C FF               [12] 1846 	mov	r7,a
      00785D E0               [24] 1847 	movx	a,@dptr
      00785E 60 08            [24] 1848 	jz	00103$
                                   1849 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      007860 8F 82            [24] 1850 	mov	dpl, r7
      007862 12 7F 0B         [24] 1851 	lcall	_add_owned_weak_mods
                                   1852 ;	quantum/action.c:1132: send_keyboard_report();
                                   1853 ;	quantum/action.c:1134: }
      007865 02 82 26         [24] 1854 	ljmp	_send_keyboard_report
      007868                       1855 00103$:
      007868 22               [24] 1856 	ret
                                   1857 ;------------------------------------------------------------
                                   1858 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1859 ;------------------------------------------------------------
                                   1860 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_758'
                                   1861 ;------------------------------------------------------------
                                   1862 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1863 ;	-----------------------------------------
                                   1864 ;	 function unregister_weak_mods
                                   1865 ;	-----------------------------------------
      007869                       1866 _unregister_weak_mods:
      007869 E5 82            [12] 1867 	mov	a,dpl
      00786B 90 08 47         [24] 1868 	mov	dptr,#_unregister_weak_mods_mods_10000_758
      00786E F0               [24] 1869 	movx	@dptr,a
                                   1870 ;	quantum/action.c:1141: if (mods) {
      00786F E0               [24] 1871 	movx	a,@dptr
      007870 FF               [12] 1872 	mov	r7,a
      007871 E0               [24] 1873 	movx	a,@dptr
      007872 60 08            [24] 1874 	jz	00103$
                                   1875 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      007874 8F 82            [24] 1876 	mov	dpl, r7
      007876 12 7F 1B         [24] 1877 	lcall	_del_owned_weak_mods
                                   1878 ;	quantum/action.c:1143: send_keyboard_report();
                                   1879 ;	quantum/action.c:1145: }
      007879 02 82 26         [24] 1880 	ljmp	_send_keyboard_report
      00787C                       1881 00103$:
      00787C 22               [24] 1882 	ret
                                   1883 ;------------------------------------------------------------
                                   1884 ;Allocation info for local variables in function 'clear_keyboard'
                                   1885 ;------------------------------------------------------------
                                   1886 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   1887 ;	-----------------------------------------
                                   1888 ;	 function clear_keyboard
                                   1889 ;	-----------------------------------------
      00787D                       1890 _clear_keyboard:
                                   1891 ;	quantum/action.c:1152: clear_mods();
      00787D 12 82 C8         [24] 1892 	lcall	_clear_mods
                                   1893 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   1894 ;	quantum/action.c:1154: }
      007880 02 78 83         [24] 1895 	ljmp	_clear_keyboard_but_mods
                                   1896 ;------------------------------------------------------------
                                   1897 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1898 ;------------------------------------------------------------
                                   1899 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   1900 ;	-----------------------------------------
                                   1901 ;	 function clear_keyboard_but_mods
                                   1902 ;	-----------------------------------------
      007883                       1903 _clear_keyboard_but_mods:
                                   1904 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      007883 90 0D CE         [24] 1905 	mov	dptr,#_actual_keyboard_report
      007886 12 71 44         [24] 1906 	lcall	_clear_keys_from_report
                                   1907 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   1908 ;	quantum/action.c:1163: }
      007889 02 78 8C         [24] 1909 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1910 ;------------------------------------------------------------
                                   1911 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1912 ;------------------------------------------------------------
                                   1913 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   1914 ;	-----------------------------------------
                                   1915 ;	 function clear_keyboard_but_mods_and_keys
                                   1916 ;	-----------------------------------------
      00788C                       1917 _clear_keyboard_but_mods_and_keys:
                                   1918 ;	quantum/action.c:1171: ak820_tapping_cancel();
      00788C 12 47 FD         [24] 1919 	lcall	_ak820_tapping_cancel
                                   1920 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      00788F 12 2E A4         [24] 1921 	lcall	_ak820_oneshot_cancel
                                   1922 ;	quantum/action.c:1185: ak820_combo_cancel();
      007892 12 35 70         [24] 1923 	lcall	_ak820_combo_cancel
                                   1924 ;	quantum/action.c:1188: repeat_key_cancel();
      007895 12 A3 FC         [24] 1925 	lcall	_repeat_key_cancel
                                   1926 ;	quantum/action.c:1190: clear_owned_mods();
      007898 12 7F 2B         [24] 1927 	lcall	_clear_owned_mods
                                   1928 ;	quantum/action.c:1191: clear_owned_keys();
      00789B 12 7F 63         [24] 1929 	lcall	_clear_owned_keys
                                   1930 ;	quantum/action.c:1192: clear_owned_usages();
      00789E 12 80 99         [24] 1931 	lcall	_clear_owned_usages
                                   1932 ;	quantum/action.c:1193: layer_hold_clear();
      0078A1 12 7A 87         [24] 1933 	lcall	_layer_hold_clear
                                   1934 ;	quantum/action.c:1195: clear_macro_tri_layer();
      0078A4 12 9E 46         [24] 1935 	lcall	_clear_macro_tri_layer
                                   1936 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0078A7 90 0D CE         [24] 1937 	mov	dptr,#_actual_keyboard_report
      0078AA 12 71 44         [24] 1938 	lcall	_clear_keys_from_report
                                   1939 ;	quantum/action.c:1200: host_system_send(0);
      0078AD 90 00 00         [24] 1940 	mov	dptr,#0x0000
      0078B0 12 6F 19         [24] 1941 	lcall	_host_system_send
                                   1942 ;	quantum/action.c:1201: host_consumer_send(0);
      0078B3 90 00 00         [24] 1943 	mov	dptr,#0x0000
      0078B6 12 6F 49         [24] 1944 	lcall	_host_consumer_send
                                   1945 ;	quantum/action.c:1203: clear_weak_mods();
      0078B9 12 82 FD         [24] 1946 	lcall	_clear_weak_mods
                                   1947 ;	quantum/action.c:1204: send_keyboard_report();
                                   1948 ;	quantum/action.c:1212: }
      0078BC 02 82 26         [24] 1949 	ljmp	_send_keyboard_report
                                   1950 ;------------------------------------------------------------
                                   1951 ;Allocation info for local variables in function 'is_tap_record'
                                   1952 ;------------------------------------------------------------
                                   1953 ;record        Allocated with name '_is_tap_record_record_10000_774'
                                   1954 ;action        Allocated with name '_is_tap_record_action_10001_778'
                                   1955 ;------------------------------------------------------------
                                   1956 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   1957 ;	-----------------------------------------
                                   1958 	.area CSEG    (CODE)
                                   1959 	.area CONST   (CODE)
                                   1960 	.area XINIT   (CODE)
      00C37B                       1961 __xinit__disable_action_cache:
      00C37B 00                    1962 	.db #0x00	;  0
                                   1963 	.area CABS    (ABS,CODE)
                                   1964 
                                   1965 ; Experimental exact instruction outlining.
                                   1966 	.globl _ak820_outline_0001
                                   1967 	.globl _ak820_outline_0005
                                   1968 	.globl _ak820_outline_0008
                                   1969 	.globl _ak820_outline_0009
                                   1970 	.globl _ak820_outline_0012
                                   1971 	.globl _ak820_outline_0013
                                   1972 	.globl _ak820_outline_0014
                                   1973 	.globl _ak820_outline_0015
                                   1974 	.globl _ak820_outline_0018
                                   1975 	.globl _ak820_outline_0022
                                   1976 	.globl _ak820_outline_0023
                                   1977 	.globl _ak820_outline_0035
                                   1978 	.globl _ak820_outline_0038
                                   1979 	.globl _ak820_outline_0043
                                   1980 	.globl _ak820_outline_0058
                                   1981 	.globl _ak820_outline_0062
                                   1982 	.globl _ak820_outline_0065
                                   1983 	.globl _ak820_outline_0071
                                   1984 	.globl _ak820_outline_0073
                                   1985 	.globl _ak820_outline_0079
                                   1986 	.globl _ak820_outline_0080
                                   1987 	.globl _ak820_outline_0090
                                   1988 	.globl _ak820_outline_0094
                                   1989 	.globl _ak820_outline_0107
                                   1990 	.globl _ak820_outline_0108
                                   1991 	.globl _ak820_outline_0110
                                   1992 	.globl _ak820_outline_0112
                                   1993 	.globl _ak820_outline_0113
                                   1994 	.globl _ak820_outline_0118
                                   1995 	.globl _ak820_outline_0121
                                   1996 	.globl _ak820_outline_0124
                                   1997 	.globl _ak820_outline_0130
                                   1998 	.globl _ak820_outline_0133
                                   1999 	.globl _ak820_outline_0134
                                   2000 	.globl _ak820_outline_0142
                                   2001 	.globl _ak820_outline_0146
                                   2002 	.globl _ak820_outline_0149
                                   2003 	.globl _ak820_outline_0157
                                   2004 	.globl _ak820_outline_0159
                                   2005 	.globl _ak820_outline_0167
                                   2006 	.globl _ak820_outline_0168
                                   2007 	.globl _ak820_outline_0182
                                   2008 	.globl _ak820_outline_0187
                                   2009 	.globl _ak820_outline_0189
                                   2010 
                                   2011 	.area CSEG (CODE)
                                   2012 ; function ak820_outline_0014
      0078BF                       2013 _ak820_outline_0014:
      0078BF 2D               [12] 2014 	add	a,r5
      0078C0 F9               [12] 2015 	mov	r1,a
      0078C1 E4               [12] 2016 	clr	a
      0078C2 3E               [12] 2017 	addc	a,r6
      0078C3 FA               [12] 2018 	mov	r2,a
      0078C4 8F 03            [24] 2019 	mov	ar3,r7
      0078C6 89 82            [24] 2020 	mov	dpl,r1
      0078C8 8A 83            [24] 2021 	mov	dph,r2
      0078CA 8B F0            [24] 2022 	mov	b,r3
      0078CC 22               [24] 2023 	ret
                                   2024 
                                   2025 	.area CSEG (CODE)
                                   2026 ; function ak820_outline_0015
      0078CD                       2027 _ak820_outline_0015:
      0078CD 2D               [12] 2028 	add	a,r5
      0078CE FA               [12] 2029 	mov	r2,a
      0078CF E4               [12] 2030 	clr	a
      0078D0 3E               [12] 2031 	addc	a,r6
      0078D1 FB               [12] 2032 	mov	r3,a
      0078D2 8F 04            [24] 2033 	mov	ar4,r7
      0078D4 8A 82            [24] 2034 	mov	dpl,r2
      0078D6 8B 83            [24] 2035 	mov	dph,r3
      0078D8 8C F0            [24] 2036 	mov	b,r4
      0078DA 22               [24] 2037 	ret
                                   2038 
                                   2039 	.area CSEG (CODE)
                                   2040 ; function ak820_outline_0022
      0078DB                       2041 _ak820_outline_0022:
      0078DB 8E 82            [24] 2042 	mov	dpl,r6
      0078DD 8F 83            [24] 2043 	mov	dph,r7
      0078DF A3               [24] 2044 	inc	dptr
      0078E0 E0               [24] 2045 	movx	a,@dptr
      0078E1 FC               [12] 2046 	mov	r4,a
      0078E2 7D 00            [12] 2047 	mov	r5,#0x00
      0078E4 8E 82            [24] 2048 	mov	dpl,r6
      0078E6 8F 83            [24] 2049 	mov	dph,r7
      0078E8 E0               [24] 2050 	movx	a,@dptr
      0078E9 22               [24] 2051 	ret
                                   2052 
                                   2053 	.area CSEG (CODE)
                                   2054 ; function ak820_outline_0043
      0078EA                       2055 _ak820_outline_0043:
      0078EA 90 08 39         [24] 2056 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0078ED E0               [24] 2057 	movx	a,@dptr
      0078EE 54 1F            [12] 2058 	anl	a,#0x1f
      0078F0 F5 82            [12] 2059 	mov	dpl,a
      0078F2 22               [24] 2060 	ret
                                   2061 
                                   2062 	.area CSEG (CODE)
                                   2063 ; function ak820_outline_0062
      0078F3                       2064 _ak820_outline_0062:
      0078F3 F5 F0            [12] 2065 	mov	b,a
      0078F5 05 F0            [12] 2066 	inc	b
      0078F7 74 01            [12] 2067 	mov	a,#0x01
      0078F9 22               [24] 2068 	ret
                                   2069 
                                   2070 	.area CSEG (CODE)
                                   2071 ; function ak820_outline_0071
      0078FA                       2072 _ak820_outline_0071:
      0078FA 90 0D AC         [24] 2073 	mov	dptr,#___memcpy_PARM_3
      0078FD 74 06            [12] 2074 	mov	a,#0x06
      0078FF F0               [24] 2075 	movx	@dptr,a
      007900 E4               [12] 2076 	clr	a
      007901 A3               [24] 2077 	inc	dptr
      007902 F0               [24] 2078 	movx	@dptr,a
      007903 22               [24] 2079 	ret
                                   2080 
                                   2081 	.area CSEG (CODE)
                                   2082 ; function ak820_outline_0079
      007904                       2083 _ak820_outline_0079:
      007904 90 08 38         [24] 2084 	mov	dptr,#_process_action_PARM_2
      007907 E0               [24] 2085 	movx	a,@dptr
      007908 F5 82            [12] 2086 	mov	dpl,a
      00790A 22               [24] 2087 	ret
                                   2088 
                                   2089 	.area CSEG (CODE)
                                   2090 ; function ak820_outline_0090
      00790B                       2091 _ak820_outline_0090:
      00790B 90 08 39         [24] 2092 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00790E E0               [24] 2093 	movx	a,@dptr
      00790F 03               [12] 2094 	rr	a
      007910 03               [12] 2095 	rr	a
      007911 54 03            [12] 2096 	anl	a,#0x03
      007913 22               [24] 2097 	ret
                                   2098 
                                   2099 	.area CSEG (CODE)
                                   2100 ; function ak820_outline_0113
      007914                       2101 _ak820_outline_0113:
      007914 90 08 39         [24] 2102 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007917 E0               [24] 2103 	movx	a,@dptr
      007918 54 0F            [12] 2104 	anl	a,#0x0f
      00791A 22               [24] 2105 	ret
                                   2106 
                                   2107 	.area CSEG (CODE)
                                   2108 ; function ak820_outline_0130
      00791B                       2109 _ak820_outline_0130:
      00791B 90 08 38         [24] 2110 	mov	dptr,#_process_action_PARM_2
      00791E E0               [24] 2111 	movx	a,@dptr
      00791F FE               [12] 2112 	mov	r6,a
      007920 A3               [24] 2113 	inc	dptr
      007921 E0               [24] 2114 	movx	a,@dptr
      007922 54 03            [12] 2115 	anl	a,#0x03
      007924 FF               [12] 2116 	mov	r7,a
      007925 22               [24] 2117 	ret
                                   2118 
                                   2119 	.area CSEG (CODE)
                                   2120 ; function ak820_outline_0146
      007926                       2121 _ak820_outline_0146:
      007926 74 07            [12] 2122 	mov	a,#0x07
      007928 2D               [12] 2123 	add	a,r5
      007929 F8               [12] 2124 	mov	r0,a
      00792A E4               [12] 2125 	clr	a
      00792B 3E               [12] 2126 	addc	a,r6
      00792C F9               [12] 2127 	mov	r1,a
      00792D 8F 02            [24] 2128 	mov	ar2,r7
      00792F 22               [24] 2129 	ret
                                   2130 
                                   2131 	.area CSEG (CODE)
                                   2132 ; function ak820_outline_0159
      007930                       2133 _ak820_outline_0159:
      007930 90 08 38         [24] 2134 	mov	dptr,#_process_action_PARM_2
      007933 E0               [24] 2135 	movx	a,@dptr
      007934 22               [24] 2136 	ret
                                   2137 
                                   2138 	.area CSEG (CODE)
                                   2139 ; function ak820_outline_0167
      007935                       2140 _ak820_outline_0167:
      007935 90 08 3E         [24] 2141 	mov	dptr,#_register_code_code_10000_710
      007938 E0               [24] 2142 	movx	a,@dptr
      007939 FF               [12] 2143 	mov	r7,a
      00793A 22               [24] 2144 	ret
                                   2145 
                                   2146 	.area CSEG (CODE)
                                   2147 ; function ak820_outline_0168
      00793B                       2148 _ak820_outline_0168:
      00793B 90 08 3F         [24] 2149 	mov	dptr,#_unregister_code_code_10000_724
      00793E E0               [24] 2150 	movx	a,@dptr
      00793F FF               [12] 2151 	mov	r7,a
      007940 22               [24] 2152 	ret
                                   2153 
                                   2154 	.area CSEG (CODE)
                                   2155 ; function ak820_outline_0187
      007941                       2156 _ak820_outline_0187:
      007941 F0               [24] 2157 	movx	@dptr,a
      007942 EB               [12] 2158 	mov	a,r3
      007943 A3               [24] 2159 	inc	dptr
      007944 F0               [24] 2160 	movx	@dptr,a
      007945 22               [24] 2161 	ret
