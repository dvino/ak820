                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _ak820_gui_process
                                     22 	.globl _mcu_reset
                                     23 	.globl _bootloader_jump
                                     24 	.globl _ak820_resolve_key
                                     25 	.globl _default_layer_set
                                     26 	.globl _clear_keyboard
                                     27 	.globl _unregister_weak_mods
                                     28 	.globl _register_weak_mods
                                     29 	.globl _unregister_mods
                                     30 	.globl _register_mods
                                     31 	.globl _unregister_code
                                     32 	.globl _register_code
                                     33 	.globl _eeconfig_disable
                                     34 	.globl _rgb_matrix_set_suspend_state
                                     35 	.globl _rgb_matrix_task
                                     36 	.globl _mDelaymS
                                     37 	.globl _ADC_START
                                     38 	.globl _S0_R_FIFO
                                     39 	.globl _S0_T_FIFO
                                     40 	.globl _S0_FREE
                                     41 	.globl _S0_IF_BYTE
                                     42 	.globl _S0_IF_FIRST
                                     43 	.globl _S0_IF_OV
                                     44 	.globl _S0_FST_ACT
                                     45 	.globl _CP_RL2
                                     46 	.globl _C_T2
                                     47 	.globl _TR2
                                     48 	.globl _EXEN2
                                     49 	.globl _TCLK
                                     50 	.globl _RCLK
                                     51 	.globl _EXF2
                                     52 	.globl _CAP1F
                                     53 	.globl _TF2
                                     54 	.globl _RI
                                     55 	.globl _TI
                                     56 	.globl _RB8
                                     57 	.globl _TB8
                                     58 	.globl _REN
                                     59 	.globl _SM2
                                     60 	.globl _SM1
                                     61 	.globl _SM0
                                     62 	.globl _IT0
                                     63 	.globl _IE0
                                     64 	.globl _IT1
                                     65 	.globl _IE1
                                     66 	.globl _TR0
                                     67 	.globl _TF0
                                     68 	.globl _TR1
                                     69 	.globl _TF1
                                     70 	.globl _P4_0
                                     71 	.globl _P4_1
                                     72 	.globl _P4_2
                                     73 	.globl _P4_3
                                     74 	.globl _P4_4
                                     75 	.globl _P4_5
                                     76 	.globl _P4_6
                                     77 	.globl _RXD
                                     78 	.globl _TXD
                                     79 	.globl _INT0
                                     80 	.globl _INT1
                                     81 	.globl _T0
                                     82 	.globl _T1
                                     83 	.globl _MOSI1
                                     84 	.globl _MISO1
                                     85 	.globl _SCK1
                                     86 	.globl _P3_0
                                     87 	.globl _P3_1
                                     88 	.globl _P3_2
                                     89 	.globl _P3_3
                                     90 	.globl _P3_4
                                     91 	.globl _P3_5
                                     92 	.globl _P3_6
                                     93 	.globl _P3_7
                                     94 	.globl _CAP1_
                                     95 	.globl _T2_
                                     96 	.globl _CAP2_
                                     97 	.globl _T2EX_
                                     98 	.globl _RXD1
                                     99 	.globl _TXD1
                                    100 	.globl _P2_0
                                    101 	.globl _P2_1
                                    102 	.globl _P2_2
                                    103 	.globl _P2_3
                                    104 	.globl _P2_4
                                    105 	.globl _P2_5
                                    106 	.globl _P2_6
                                    107 	.globl _P2_7
                                    108 	.globl _AIN0
                                    109 	.globl _AIN1
                                    110 	.globl _AIN2
                                    111 	.globl _AIN3
                                    112 	.globl _AIN4
                                    113 	.globl _AIN5
                                    114 	.globl _AIN6
                                    115 	.globl _AIN7
                                    116 	.globl _CAP1
                                    117 	.globl _T2
                                    118 	.globl _CAP2
                                    119 	.globl _T2EX
                                    120 	.globl _INT0_
                                    121 	.globl _SCS
                                    122 	.globl _MOSI
                                    123 	.globl _MISO
                                    124 	.globl _SCK
                                    125 	.globl _RXD1_
                                    126 	.globl _TXD1_
                                    127 	.globl _P1_0
                                    128 	.globl _P1_1
                                    129 	.globl _P1_2
                                    130 	.globl _P1_3
                                    131 	.globl _P1_4
                                    132 	.globl _P1_5
                                    133 	.globl _P1_6
                                    134 	.globl _P1_7
                                    135 	.globl _AIN8
                                    136 	.globl _AIN9
                                    137 	.globl _AIN10
                                    138 	.globl _AIN11
                                    139 	.globl _AIN12
                                    140 	.globl _AIN13
                                    141 	.globl _RXD_
                                    142 	.globl _TXD_
                                    143 	.globl _SCL0
                                    144 	.globl _SDA0
                                    145 	.globl _P0_0
                                    146 	.globl _P0_1
                                    147 	.globl _P0_2
                                    148 	.globl _P0_3
                                    149 	.globl _P0_4
                                    150 	.globl _P0_5
                                    151 	.globl _P0_6
                                    152 	.globl _P0_7
                                    153 	.globl _IE_SPI0
                                    154 	.globl _IE_USB
                                    155 	.globl _IE_ADC
                                    156 	.globl _IE_UART1
                                    157 	.globl _IE_PWM_I2C
                                    158 	.globl _IE_GPIO
                                    159 	.globl _IE_WDOG
                                    160 	.globl _PX0
                                    161 	.globl _PT0
                                    162 	.globl _PX1
                                    163 	.globl _PT1
                                    164 	.globl _PS
                                    165 	.globl _PT2
                                    166 	.globl _PL_FLAG
                                    167 	.globl _PH_FLAG
                                    168 	.globl _EX0
                                    169 	.globl _ET0
                                    170 	.globl _EX1
                                    171 	.globl _ET1
                                    172 	.globl _ES
                                    173 	.globl _ET2
                                    174 	.globl _E_DIS
                                    175 	.globl _EA
                                    176 	.globl _P
                                    177 	.globl _F1
                                    178 	.globl _OV
                                    179 	.globl _RS0
                                    180 	.globl _RS1
                                    181 	.globl _F0
                                    182 	.globl _AC
                                    183 	.globl _CY
                                    184 	.globl _I2CS_INT_ST
                                    185 	.globl _I2CX_INT
                                    186 	.globl _LED_STATUS
                                    187 	.globl _LED_DMA_H
                                    188 	.globl _LED_DMA_L
                                    189 	.globl _LED_DMA
                                    190 	.globl _LED_PWM_OE
                                    191 	.globl _LED_COMMON
                                    192 	.globl _ADC_CHAN
                                    193 	.globl _ADC_DAT_H
                                    194 	.globl _ADC_DAT_L
                                    195 	.globl _ADC_DAT
                                    196 	.globl _ADC_CTRL
                                    197 	.globl _SPI1_CK_SE
                                    198 	.globl _SPI1_CTRL
                                    199 	.globl _SPI1_DATA
                                    200 	.globl _SPI1_STAT
                                    201 	.globl _SIF1
                                    202 	.globl _SBAUD1
                                    203 	.globl _SBUF1
                                    204 	.globl _SCON1
                                    205 	.globl _SPI0_SETUP
                                    206 	.globl _SPI0_CK_SE
                                    207 	.globl _SPI0_CTRL
                                    208 	.globl _SPI0_DATA
                                    209 	.globl _SPI0_STAT
                                    210 	.globl _T2CAP1H
                                    211 	.globl _T2CAP1L
                                    212 	.globl _T2CAP1
                                    213 	.globl _TH2
                                    214 	.globl _TL2
                                    215 	.globl _T2COUNT
                                    216 	.globl _RCAP2H
                                    217 	.globl _RCAP2L
                                    218 	.globl _RCAP2
                                    219 	.globl _T2MOD
                                    220 	.globl _T2CON
                                    221 	.globl _SBUF
                                    222 	.globl _SCON
                                    223 	.globl _TH1
                                    224 	.globl _TH0
                                    225 	.globl _TL1
                                    226 	.globl _TL0
                                    227 	.globl _TMOD
                                    228 	.globl _TCON
                                    229 	.globl _XBUS_AUX
                                    230 	.globl _P7
                                    231 	.globl _P6_DIR
                                    232 	.globl _P6_OUT_PU
                                    233 	.globl _P6_IN
                                    234 	.globl _P5_DIR
                                    235 	.globl _P5_OUT_PU
                                    236 	.globl _P5_IN
                                    237 	.globl _P4_LED_KEY
                                    238 	.globl _P4_DIR_PU
                                    239 	.globl _P4_MOD_OC
                                    240 	.globl _P4
                                    241 	.globl _P3_DIR_PU
                                    242 	.globl _P3_MOD_OC
                                    243 	.globl _P3
                                    244 	.globl _P2_DIR_PU
                                    245 	.globl _P2_MOD_OC
                                    246 	.globl _P2
                                    247 	.globl _P1_DIR_PU
                                    248 	.globl _P1_MOD_OC
                                    249 	.globl _P1
                                    250 	.globl _P0_DIR_PU
                                    251 	.globl _P0_MOD_OC
                                    252 	.globl _P0
                                    253 	.globl _ROM_CTRL
                                    254 	.globl _ROM_DATA_HH
                                    255 	.globl _ROM_DATA_HL
                                    256 	.globl _ROM_DATA_HI
                                    257 	.globl _ROM_ADDR_H
                                    258 	.globl _ROM_ADDR_L
                                    259 	.globl _ROM_ADDR
                                    260 	.globl _GPIO_IE
                                    261 	.globl _IP_EX
                                    262 	.globl _IE_EX
                                    263 	.globl _IP
                                    264 	.globl _IE
                                    265 	.globl _WDOG_COUNT
                                    266 	.globl _RESET_KEEP
                                    267 	.globl _WAKE_CTRL
                                    268 	.globl _CLOCK_CFG
                                    269 	.globl _POWER_CFG
                                    270 	.globl _PCON
                                    271 	.globl _GLOBAL_CFG
                                    272 	.globl _SAFE_MOD
                                    273 	.globl _DPH
                                    274 	.globl _DPL
                                    275 	.globl _SP
                                    276 	.globl _A_INV
                                    277 	.globl _B
                                    278 	.globl _ACC
                                    279 	.globl _PSW
                                    280 	.globl _process_record_quantum_helper_PARM_2
                                    281 	.globl _get_record_keycode_PARM_2
                                    282 	.globl _post_process_record_user_PARM_2
                                    283 	.globl _post_process_record_kb_PARM_2
                                    284 	.globl _process_record_user_PARM_2
                                    285 	.globl _process_record_kb_PARM_2
                                    286 	.globl _pre_process_record_user_PARM_2
                                    287 	.globl _pre_process_record_kb_PARM_2
                                    288 	.globl _register_code16
                                    289 	.globl _unregister_code16
                                    290 	.globl _pre_process_record_kb
                                    291 	.globl _pre_process_record_user
                                    292 	.globl _process_action_kb
                                    293 	.globl _process_record_kb
                                    294 	.globl _process_record_user
                                    295 	.globl _post_process_record_kb
                                    296 	.globl _post_process_record_user
                                    297 	.globl _reset_keyboard
                                    298 	.globl _soft_reset_keyboard
                                    299 	.globl _get_record_keycode
                                    300 	.globl _pre_process_record_quantum
                                    301 	.globl _post_process_record_quantum
                                    302 	.globl _process_record_quantum
                                    303 	.globl _process_record_quantum_helper
                                    304 	.globl _shutdown_user
                                    305 ;--------------------------------------------------------
                                    306 ; special function registers
                                    307 ;--------------------------------------------------------
                                    308 	.area RSEG    (ABS,DATA)
      000000                        309 	.org 0x0000
                           0000D0   310 _PSW	=	0x00d0
                           0000E0   311 _ACC	=	0x00e0
                           0000F0   312 _B	=	0x00f0
                           0000FD   313 _A_INV	=	0x00fd
                           000081   314 _SP	=	0x0081
                           000082   315 _DPL	=	0x0082
                           000083   316 _DPH	=	0x0083
                           0000A1   317 _SAFE_MOD	=	0x00a1
                           0000B1   318 _GLOBAL_CFG	=	0x00b1
                           000087   319 _PCON	=	0x0087
                           0000BA   320 _POWER_CFG	=	0x00ba
                           0000B9   321 _CLOCK_CFG	=	0x00b9
                           0000A9   322 _WAKE_CTRL	=	0x00a9
                           0000FE   323 _RESET_KEEP	=	0x00fe
                           0000FF   324 _WDOG_COUNT	=	0x00ff
                           0000A8   325 _IE	=	0x00a8
                           0000B8   326 _IP	=	0x00b8
                           0000E8   327 _IE_EX	=	0x00e8
                           0000E9   328 _IP_EX	=	0x00e9
                           0000B2   329 _GPIO_IE	=	0x00b2
                           008584   330 _ROM_ADDR	=	0x8584
                           000084   331 _ROM_ADDR_L	=	0x0084
                           000085   332 _ROM_ADDR_H	=	0x0085
                           008F8E   333 _ROM_DATA_HI	=	0x8f8e
                           00008E   334 _ROM_DATA_HL	=	0x008e
                           00008F   335 _ROM_DATA_HH	=	0x008f
                           000086   336 _ROM_CTRL	=	0x0086
                           000080   337 _P0	=	0x0080
                           0000C4   338 _P0_MOD_OC	=	0x00c4
                           0000C5   339 _P0_DIR_PU	=	0x00c5
                           000090   340 _P1	=	0x0090
                           000092   341 _P1_MOD_OC	=	0x0092
                           000093   342 _P1_DIR_PU	=	0x0093
                           0000A0   343 _P2	=	0x00a0
                           000094   344 _P2_MOD_OC	=	0x0094
                           000095   345 _P2_DIR_PU	=	0x0095
                           0000B0   346 _P3	=	0x00b0
                           000096   347 _P3_MOD_OC	=	0x0096
                           000097   348 _P3_DIR_PU	=	0x0097
                           0000C0   349 _P4	=	0x00c0
                           0000C2   350 _P4_MOD_OC	=	0x00c2
                           0000C3   351 _P4_DIR_PU	=	0x00c3
                           0000C1   352 _P4_LED_KEY	=	0x00c1
                           0000AA   353 _P5_IN	=	0x00aa
                           0000AB   354 _P5_OUT_PU	=	0x00ab
                           0000AC   355 _P5_DIR	=	0x00ac
                           0000AD   356 _P6_IN	=	0x00ad
                           0000AE   357 _P6_OUT_PU	=	0x00ae
                           0000AF   358 _P6_DIR	=	0x00af
                           0000F1   359 _P7	=	0x00f1
                           0000A2   360 _XBUS_AUX	=	0x00a2
                           000088   361 _TCON	=	0x0088
                           000089   362 _TMOD	=	0x0089
                           00008A   363 _TL0	=	0x008a
                           00008B   364 _TL1	=	0x008b
                           00008C   365 _TH0	=	0x008c
                           00008D   366 _TH1	=	0x008d
                           000098   367 _SCON	=	0x0098
                           000099   368 _SBUF	=	0x0099
                           0000C8   369 _T2CON	=	0x00c8
                           0000C9   370 _T2MOD	=	0x00c9
                           00CBCA   371 _RCAP2	=	0xcbca
                           0000CA   372 _RCAP2L	=	0x00ca
                           0000CB   373 _RCAP2H	=	0x00cb
                           00CDCC   374 _T2COUNT	=	0xcdcc
                           0000CC   375 _TL2	=	0x00cc
                           0000CD   376 _TH2	=	0x00cd
                           00CFCE   377 _T2CAP1	=	0xcfce
                           0000CE   378 _T2CAP1L	=	0x00ce
                           0000CF   379 _T2CAP1H	=	0x00cf
                           0000F8   380 _SPI0_STAT	=	0x00f8
                           0000F9   381 _SPI0_DATA	=	0x00f9
                           0000FA   382 _SPI0_CTRL	=	0x00fa
                           0000FB   383 _SPI0_CK_SE	=	0x00fb
                           0000FC   384 _SPI0_SETUP	=	0x00fc
                           0000BC   385 _SCON1	=	0x00bc
                           0000BD   386 _SBUF1	=	0x00bd
                           0000BE   387 _SBAUD1	=	0x00be
                           0000BF   388 _SIF1	=	0x00bf
                           0000B4   389 _SPI1_STAT	=	0x00b4
                           0000B5   390 _SPI1_DATA	=	0x00b5
                           0000B6   391 _SPI1_CTRL	=	0x00b6
                           0000B7   392 _SPI1_CK_SE	=	0x00b7
                           0000F3   393 _ADC_CTRL	=	0x00f3
                           00F5F4   394 _ADC_DAT	=	0xf5f4
                           0000F4   395 _ADC_DAT_L	=	0x00f4
                           0000F5   396 _ADC_DAT_H	=	0x00f5
                           0000F6   397 _ADC_CHAN	=	0x00f6
                           0000A6   398 _LED_COMMON	=	0x00a6
                           0000A7   399 _LED_PWM_OE	=	0x00a7
                           00C7C6   400 _LED_DMA	=	0xc7c6
                           0000C6   401 _LED_DMA_L	=	0x00c6
                           0000C7   402 _LED_DMA_H	=	0x00c7
                           0000F7   403 _LED_STATUS	=	0x00f7
                           0000B3   404 _I2CX_INT	=	0x00b3
                           0000BB   405 _I2CS_INT_ST	=	0x00bb
                                    406 ;--------------------------------------------------------
                                    407 ; special function bits
                                    408 ;--------------------------------------------------------
                                    409 	.area RSEG    (ABS,DATA)
      000000                        410 	.org 0x0000
                           0000D7   411 _CY	=	0x00d7
                           0000D6   412 _AC	=	0x00d6
                           0000D5   413 _F0	=	0x00d5
                           0000D4   414 _RS1	=	0x00d4
                           0000D3   415 _RS0	=	0x00d3
                           0000D2   416 _OV	=	0x00d2
                           0000D1   417 _F1	=	0x00d1
                           0000D0   418 _P	=	0x00d0
                           0000AF   419 _EA	=	0x00af
                           0000AE   420 _E_DIS	=	0x00ae
                           0000AD   421 _ET2	=	0x00ad
                           0000AC   422 _ES	=	0x00ac
                           0000AB   423 _ET1	=	0x00ab
                           0000AA   424 _EX1	=	0x00aa
                           0000A9   425 _ET0	=	0x00a9
                           0000A8   426 _EX0	=	0x00a8
                           0000BF   427 _PH_FLAG	=	0x00bf
                           0000BE   428 _PL_FLAG	=	0x00be
                           0000BD   429 _PT2	=	0x00bd
                           0000BC   430 _PS	=	0x00bc
                           0000BB   431 _PT1	=	0x00bb
                           0000BA   432 _PX1	=	0x00ba
                           0000B9   433 _PT0	=	0x00b9
                           0000B8   434 _PX0	=	0x00b8
                           0000EF   435 _IE_WDOG	=	0x00ef
                           0000EE   436 _IE_GPIO	=	0x00ee
                           0000ED   437 _IE_PWM_I2C	=	0x00ed
                           0000EC   438 _IE_UART1	=	0x00ec
                           0000EB   439 _IE_ADC	=	0x00eb
                           0000E9   440 _IE_USB	=	0x00e9
                           0000E8   441 _IE_SPI0	=	0x00e8
                           000087   442 _P0_7	=	0x0087
                           000086   443 _P0_6	=	0x0086
                           000085   444 _P0_5	=	0x0085
                           000084   445 _P0_4	=	0x0084
                           000083   446 _P0_3	=	0x0083
                           000082   447 _P0_2	=	0x0082
                           000081   448 _P0_1	=	0x0081
                           000080   449 _P0_0	=	0x0080
                           000081   450 _SDA0	=	0x0081
                           000080   451 _SCL0	=	0x0080
                           000083   452 _TXD_	=	0x0083
                           000082   453 _RXD_	=	0x0082
                           000085   454 _AIN13	=	0x0085
                           000084   455 _AIN12	=	0x0084
                           000083   456 _AIN11	=	0x0083
                           000082   457 _AIN10	=	0x0082
                           000081   458 _AIN9	=	0x0081
                           000080   459 _AIN8	=	0x0080
                           000097   460 _P1_7	=	0x0097
                           000096   461 _P1_6	=	0x0096
                           000095   462 _P1_5	=	0x0095
                           000094   463 _P1_4	=	0x0094
                           000093   464 _P1_3	=	0x0093
                           000092   465 _P1_2	=	0x0092
                           000091   466 _P1_1	=	0x0091
                           000090   467 _P1_0	=	0x0090
                           000097   468 _TXD1_	=	0x0097
                           000096   469 _RXD1_	=	0x0096
                           000097   470 _SCK	=	0x0097
                           000096   471 _MISO	=	0x0096
                           000095   472 _MOSI	=	0x0095
                           000094   473 _SCS	=	0x0094
                           000092   474 _INT0_	=	0x0092
                           000091   475 _T2EX	=	0x0091
                           000091   476 _CAP2	=	0x0091
                           000090   477 _T2	=	0x0090
                           000090   478 _CAP1	=	0x0090
                           000097   479 _AIN7	=	0x0097
                           000096   480 _AIN6	=	0x0096
                           000095   481 _AIN5	=	0x0095
                           000094   482 _AIN4	=	0x0094
                           000093   483 _AIN3	=	0x0093
                           000092   484 _AIN2	=	0x0092
                           000091   485 _AIN1	=	0x0091
                           000090   486 _AIN0	=	0x0090
                           0000A7   487 _P2_7	=	0x00a7
                           0000A6   488 _P2_6	=	0x00a6
                           0000A5   489 _P2_5	=	0x00a5
                           0000A4   490 _P2_4	=	0x00a4
                           0000A3   491 _P2_3	=	0x00a3
                           0000A2   492 _P2_2	=	0x00a2
                           0000A1   493 _P2_1	=	0x00a1
                           0000A0   494 _P2_0	=	0x00a0
                           0000A7   495 _TXD1	=	0x00a7
                           0000A6   496 _RXD1	=	0x00a6
                           0000A5   497 _T2EX_	=	0x00a5
                           0000A5   498 _CAP2_	=	0x00a5
                           0000A4   499 _T2_	=	0x00a4
                           0000A4   500 _CAP1_	=	0x00a4
                           0000B7   501 _P3_7	=	0x00b7
                           0000B6   502 _P3_6	=	0x00b6
                           0000B5   503 _P3_5	=	0x00b5
                           0000B4   504 _P3_4	=	0x00b4
                           0000B3   505 _P3_3	=	0x00b3
                           0000B2   506 _P3_2	=	0x00b2
                           0000B1   507 _P3_1	=	0x00b1
                           0000B0   508 _P3_0	=	0x00b0
                           0000B7   509 _SCK1	=	0x00b7
                           0000B6   510 _MISO1	=	0x00b6
                           0000B5   511 _MOSI1	=	0x00b5
                           0000B5   512 _T1	=	0x00b5
                           0000B4   513 _T0	=	0x00b4
                           0000B3   514 _INT1	=	0x00b3
                           0000B2   515 _INT0	=	0x00b2
                           0000B1   516 _TXD	=	0x00b1
                           0000B0   517 _RXD	=	0x00b0
                           0000C6   518 _P4_6	=	0x00c6
                           0000C5   519 _P4_5	=	0x00c5
                           0000C4   520 _P4_4	=	0x00c4
                           0000C3   521 _P4_3	=	0x00c3
                           0000C2   522 _P4_2	=	0x00c2
                           0000C1   523 _P4_1	=	0x00c1
                           0000C0   524 _P4_0	=	0x00c0
                           00008F   525 _TF1	=	0x008f
                           00008E   526 _TR1	=	0x008e
                           00008D   527 _TF0	=	0x008d
                           00008C   528 _TR0	=	0x008c
                           00008B   529 _IE1	=	0x008b
                           00008A   530 _IT1	=	0x008a
                           000089   531 _IE0	=	0x0089
                           000088   532 _IT0	=	0x0088
                           00009F   533 _SM0	=	0x009f
                           00009E   534 _SM1	=	0x009e
                           00009D   535 _SM2	=	0x009d
                           00009C   536 _REN	=	0x009c
                           00009B   537 _TB8	=	0x009b
                           00009A   538 _RB8	=	0x009a
                           000099   539 _TI	=	0x0099
                           000098   540 _RI	=	0x0098
                           0000CF   541 _TF2	=	0x00cf
                           0000CF   542 _CAP1F	=	0x00cf
                           0000CE   543 _EXF2	=	0x00ce
                           0000CD   544 _RCLK	=	0x00cd
                           0000CC   545 _TCLK	=	0x00cc
                           0000CB   546 _EXEN2	=	0x00cb
                           0000CA   547 _TR2	=	0x00ca
                           0000C9   548 _C_T2	=	0x00c9
                           0000C8   549 _CP_RL2	=	0x00c8
                           0000FF   550 _S0_FST_ACT	=	0x00ff
                           0000FE   551 _S0_IF_OV	=	0x00fe
                           0000FD   552 _S0_IF_FIRST	=	0x00fd
                           0000FC   553 _S0_IF_BYTE	=	0x00fc
                           0000FB   554 _S0_FREE	=	0x00fb
                           0000FA   555 _S0_T_FIFO	=	0x00fa
                           0000F8   556 _S0_R_FIFO	=	0x00f8
                           0000F7   557 _ADC_START	=	0x00f7
                                    558 ;--------------------------------------------------------
                                    559 ; overlayable register banks
                                    560 ;--------------------------------------------------------
                                    561 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        562 	.ds 8
                                    563 ;--------------------------------------------------------
                                    564 ; internal ram data
                                    565 ;--------------------------------------------------------
                                    566 	.area DSEG    (DATA)
                                    567 ;--------------------------------------------------------
                                    568 ; overlayable items in internal ram
                                    569 ;--------------------------------------------------------
                                    570 ;--------------------------------------------------------
                                    571 ; indirectly addressable internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area ISEG    (DATA)
                                    574 ;--------------------------------------------------------
                                    575 ; absolute internal ram data
                                    576 ;--------------------------------------------------------
                                    577 	.area IABS    (ABS,DATA)
                                    578 	.area IABS    (ABS,DATA)
                                    579 ;--------------------------------------------------------
                                    580 ; bit data
                                    581 ;--------------------------------------------------------
                                    582 	.area BSEG    (BIT)
      000027                        583 _get_record_keycode_sloc0_1_0:
      000027                        584 	.ds 1
      000028                        585 _pre_process_record_quantum_sloc0_1_0:
      000028                        586 	.ds 1
      000029                        587 _process_ak820_nkro_sloc0_1_0:
      000029                        588 	.ds 1
                                    589 ;--------------------------------------------------------
                                    590 ; paged external ram data
                                    591 ;--------------------------------------------------------
                                    592 	.area PSEG    (PAG,XDATA)
                                    593 ;--------------------------------------------------------
                                    594 ; uninitialized external ram data
                                    595 ;--------------------------------------------------------
                                    596 	.area XSEG    (XDATA)
      000BE2                        597 _extract_mod_bits_code_10000_600:
      000BE2                        598 	.ds 2
      000BE4                        599 _register_code16_code_10000_606:
      000BE4                        600 	.ds 2
      000BE6                        601 _unregister_code16_code_10000_611:
      000BE6                        602 	.ds 2
      000BE8                        603 _pre_process_record_kb_PARM_2:
      000BE8                        604 	.ds 3
      000BEB                        605 _pre_process_record_kb_keycode_10000_625:
      000BEB                        606 	.ds 2
      000BED                        607 _pre_process_record_user_PARM_2:
      000BED                        608 	.ds 3
      000BF0                        609 _process_record_kb_PARM_2:
      000BF0                        610 	.ds 3
      000BF3                        611 _process_record_kb_keycode_10000_631:
      000BF3                        612 	.ds 2
      000BF5                        613 _process_record_user_PARM_2:
      000BF5                        614 	.ds 3
      000BF8                        615 _post_process_record_kb_PARM_2:
      000BF8                        616 	.ds 3
      000BFB                        617 _post_process_record_kb_keycode_10000_635:
      000BFB                        618 	.ds 2
      000BFD                        619 _post_process_record_user_PARM_2:
      000BFD                        620 	.ds 3
      000C00                        621 _get_record_keycode_PARM_2:
      000C00                        622 	.ds 1
      000C01                        623 _get_record_keycode_record_argument_10000_649:
      000C01                        624 	.ds 3
      000C04                        625 _pre_process_record_quantum_record_argument_10000_655:
      000C04                        626 	.ds 3
      000C07                        627 _post_process_record_quantum_record_10000_657:
      000C07                        628 	.ds 3
      000C0A                        629 _process_record_quantum_record_10000_659:
      000C0A                        630 	.ds 3
      000C0D                        631 _process_ak820_nkro_PARM_2:
      000C0D                        632 	.ds 3
      000C10                        633 _process_ak820_nkro_keycode_10000_661:
      000C10                        634 	.ds 2
      000C12                        635 _process_record_quantum_helper_PARM_2:
      000C12                        636 	.ds 3
      000C15                        637 _process_record_quantum_helper_keycode_10000_666:
      000C15                        638 	.ds 2
      000C17                        639 _get_u8_str_last_num_10000_692:
      000C17                        640 	.ds 1
      000C18                        641 _get_u16_str_last_num_10000_696:
      000C18                        642 	.ds 2
                                    643 ;--------------------------------------------------------
                                    644 ; absolute external ram data
                                    645 ;--------------------------------------------------------
                                    646 	.area XABS    (ABS,XDATA)
                                    647 ;--------------------------------------------------------
                                    648 ; initialized external ram data
                                    649 ;--------------------------------------------------------
                                    650 	.area XISEG   (XDATA)
                                    651 	.area HOME    (CODE)
                                    652 	.area GSINIT0 (CODE)
                                    653 	.area GSINIT1 (CODE)
                                    654 	.area GSINIT2 (CODE)
                                    655 	.area GSINIT3 (CODE)
                                    656 	.area GSINIT4 (CODE)
                                    657 	.area GSINIT5 (CODE)
                                    658 	.area GSINIT  (CODE)
                                    659 	.area GSFINAL (CODE)
                                    660 	.area CSEG    (CODE)
                                    661 ;--------------------------------------------------------
                                    662 ; global & static initialisations
                                    663 ;--------------------------------------------------------
                                    664 	.area HOME    (CODE)
                                    665 	.area GSINIT  (CODE)
                                    666 	.area GSFINAL (CODE)
                                    667 	.area GSINIT  (CODE)
                                    668 ;------------------------------------------------------------
                                    669 ;Allocation info for local variables in function 'get_u8_str'
                                    670 ;------------------------------------------------------------
                                    671 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    672 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_691'
                                    673 ;buf           Allocated with name '_get_u8_str_buf_10000_692'
                                    674 ;last_num      Allocated with name '_get_u8_str_last_num_10000_692'
                                    675 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_692'
                                    676 ;------------------------------------------------------------
                                    677 ;	quantum/quantum.c:750: static uint8_t last_num = 0xFF;
      0030F3 90 0C 17         [24]  678 	mov	dptr,#_get_u8_str_last_num_10000_692
      0030F6 74 FF            [12]  679 	mov	a,#0xff
      0030F8 F0               [24]  680 	movx	@dptr,a
                                    681 ;------------------------------------------------------------
                                    682 ;Allocation info for local variables in function 'get_u16_str'
                                    683 ;------------------------------------------------------------
                                    684 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    685 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_695'
                                    686 ;buf           Allocated with name '_get_u16_str_buf_10000_696'
                                    687 ;last_num      Allocated with name '_get_u16_str_last_num_10000_696'
                                    688 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_696'
                                    689 ;------------------------------------------------------------
                                    690 ;	quantum/quantum.c:770: static uint16_t last_num = 0xFF;
      0030F9 90 0C 18         [24]  691 	mov	dptr,#_get_u16_str_last_num_10000_696
      0030FC 74 FF            [12]  692 	mov	a,#0xff
      0030FE F0               [24]  693 	movx	@dptr,a
      0030FF E4               [12]  694 	clr	a
      003100 A3               [24]  695 	inc	dptr
      003101 F0               [24]  696 	movx	@dptr,a
                                    697 ;--------------------------------------------------------
                                    698 ; Home
                                    699 ;--------------------------------------------------------
                                    700 	.area HOME    (CODE)
                                    701 	.area HOME    (CODE)
                                    702 ;--------------------------------------------------------
                                    703 ; code
                                    704 ;--------------------------------------------------------
                                    705 	.area CSEG    (CODE)
                                    706 ;------------------------------------------------------------
                                    707 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    708 ;------------------------------------------------------------
                                    709 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    710 ;------------------------------------------------------------
                                    711 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    712 ;	-----------------------------------------
                           000007   713 	ar7 = 0x07
                           000006   714 	ar6 = 0x06
                           000005   715 	ar5 = 0x05
                           000004   716 	ar4 = 0x04
                           000003   717 	ar3 = 0x03
                           000002   718 	ar2 = 0x02
                           000001   719 	ar1 = 0x01
                           000000   720 	ar0 = 0x00
                                    721 ;	 function extract_mod_bits
                                    722 ;	-----------------------------------------
      009F5E                        723 _extract_mod_bits:
      009F5E 12 38 82         [24]  724 	lcall	_ak820_outline_0107
      009F61 90 0B E2         [24]  725 	mov	dptr,#_extract_mod_bits_code_10000_600
      009F64 12 38 87         [24]  726 	lcall	_ak820_outline_0108
                                    727 ;	quantum/quantum.c:107: uint8_t mods = (uint8_t)(code >> 8);
      009F67 90 0B E2         [24]  728 	mov	dptr,#_extract_mod_bits_code_10000_600
      009F6A E0               [24]  729 	movx	a,@dptr
      009F6B A3               [24]  730 	inc	dptr
      009F6C E0               [24]  731 	movx	a,@dptr
                                    732 ;	quantum/quantum.c:108: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009F6D FF               [12]  733 	mov	r7,a
      009F6E 60 05            [24]  734 	jz	00101$
      009F70 EF               [12]  735 	mov	a,r7
      009F71 24 E0            [12]  736 	add	a,#0xff - 0x1f
      009F73 50 04            [24]  737 	jnc	00102$
                                    738 ;	free result
      009F75                        739 00101$:
      009F75 75 82 00         [24]  740 	mov	dpl, #0x00
      009F78 22               [24]  741 	ret
      009F79                        742 00102$:
                                    743 ;	quantum/quantum.c:109: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009F79 EF               [12]  744 	mov	a,r7
      009F7A 30 E4 07         [24]  745 	jnb	acc.4,00106$
      009F7D EF               [12]  746 	mov	a,r7
      009F7E C4               [12]  747 	swap	a
      009F7F 54 F0            [12]  748 	anl	a,#0xf0
      009F81 FE               [12]  749 	mov	r6,a
      009F82 80 02            [24]  750 	sjmp	00107$
      009F84                        751 00106$:
      009F84 8F 06            [24]  752 	mov	ar6,r7
      009F86                        753 00107$:
      009F86 8E 82            [24]  754 	mov	dpl, r6
                                    755 ;	quantum/quantum.c:137: }
      009F88 22               [24]  756 	ret
                                    757 ;------------------------------------------------------------
                                    758 ;Allocation info for local variables in function 'do_code16'
                                    759 ;------------------------------------------------------------
                                    760 ;f             Allocated with name '_do_code16_PARM_2'
                                    761 ;code          Allocated with name '_do_code16_code_10000_603'
                                    762 ;------------------------------------------------------------
                                    763 ;	quantum/quantum.c:139: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    764 ;	-----------------------------------------
                                    765 ;	 function register_code16
                                    766 ;	-----------------------------------------
      009F89                        767 _register_code16:
      009F89 12 38 82         [24]  768 	lcall	_ak820_outline_0107
      009F8C 90 0B E4         [24]  769 	mov	dptr,#_register_code16_code_10000_606
      009F8F 12 38 87         [24]  770 	lcall	_ak820_outline_0108
                                    771 ;	quantum/quantum.c:145: uint8_t mods = extract_mod_bits(code);
      009F92 90 0B E4         [24]  772 	mov	dptr,#_register_code16_code_10000_606
      009F95 12 37 F4         [24]  773 	lcall	_ak820_outline_0005
      009F98 C0 07            [24]  774 	push	ar7
      009F9A C0 06            [24]  775 	push	ar6
      009F9C 12 9F 5E         [24]  776 	lcall	_extract_mod_bits
      009F9F AD 82            [24]  777 	mov	r5, dpl
      009FA1 D0 06            [24]  778 	pop	ar6
      009FA3 D0 07            [24]  779 	pop	ar7
                                    780 ;	quantum/quantum.c:146: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009FA5 12 9D 98         [24]  781 	lcall	_ak820_outline_0119
      009FA8 40 07            [24]  782 	jc	00105$
      009FAA 74 E7            [12]  783 	mov	a,#0xe7
      009FAC 9E               [12]  784 	subb	a,r6
      009FAD E4               [12]  785 	clr	a
      009FAE 9F               [12]  786 	subb	a,r7
      009FAF 50 08            [24]  787 	jnc	00101$
                                    788 ;	free result
      009FB1                        789 00105$:
      009FB1 90 0B E4         [24]  790 	mov	dptr,#_register_code16_code_10000_606
      009FB4 12 6F 87         [24]  791 	lcall	_ak820_outline_0041
      009FB7 70 07            [24]  792 	jnz	00102$
      009FB9                        793 00101$:
                                    794 ;	quantum/quantum.c:147: register_mods(mods);
      009FB9 8D 82            [24]  795 	mov	dpl, r5
      009FBB 12 78 2D         [24]  796 	lcall	_register_mods
      009FBE 80 05            [24]  797 	sjmp	00103$
      009FC0                        798 00102$:
                                    799 ;	quantum/quantum.c:149: register_weak_mods(mods);
      009FC0 8D 82            [24]  800 	mov	dpl, r5
      009FC2 12 78 55         [24]  801 	lcall	_register_weak_mods
      009FC5                        802 00103$:
                                    803 ;	quantum/quantum.c:151: register_code(code);
      009FC5 90 0B E4         [24]  804 	mov	dptr,#_register_code16_code_10000_606
      009FC8 E0               [24]  805 	movx	a,@dptr
      009FC9 F5 82            [12]  806 	mov	dpl,a
                                    807 ;	quantum/quantum.c:161: }
      009FCB 02 77 0A         [24]  808 	ljmp	_register_code
                                    809 ;------------------------------------------------------------
                                    810 ;Allocation info for local variables in function 'unregister_code16'
                                    811 ;------------------------------------------------------------
                                    812 ;code          Allocated with name '_unregister_code16_code_10000_611'
                                    813 ;mods          Allocated with name '_unregister_code16_mods_10000_612'
                                    814 ;------------------------------------------------------------
                                    815 ;	quantum/quantum.c:163: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    816 ;	-----------------------------------------
                                    817 ;	 function unregister_code16
                                    818 ;	-----------------------------------------
      009FCE                        819 _unregister_code16:
      009FCE 12 38 82         [24]  820 	lcall	_ak820_outline_0107
      009FD1 90 0B E6         [24]  821 	mov	dptr,#_unregister_code16_code_10000_611
      009FD4 12 38 87         [24]  822 	lcall	_ak820_outline_0108
                                    823 ;	quantum/quantum.c:165: uint8_t mods = extract_mod_bits(code);
      009FD7 90 0B E6         [24]  824 	mov	dptr,#_unregister_code16_code_10000_611
      009FDA 12 37 F4         [24]  825 	lcall	_ak820_outline_0005
      009FDD C0 07            [24]  826 	push	ar7
      009FDF C0 06            [24]  827 	push	ar6
      009FE1 12 9F 5E         [24]  828 	lcall	_extract_mod_bits
      009FE4 AD 82            [24]  829 	mov	r5, dpl
      009FE6 D0 06            [24]  830 	pop	ar6
                                    831 ;	quantum/quantum.c:166: unregister_code(code);
      009FE8 8E 04            [24]  832 	mov	ar4,r6
      009FEA 8C 82            [24]  833 	mov	dpl, r4
      009FEC C0 06            [24]  834 	push	ar6
      009FEE C0 05            [24]  835 	push	ar5
      009FF0 12 77 77         [24]  836 	lcall	_unregister_code
      009FF3 D0 05            [24]  837 	pop	ar5
      009FF5 D0 06            [24]  838 	pop	ar6
      009FF7 D0 07            [24]  839 	pop	ar7
                                    840 ;	quantum/quantum.c:167: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009FF9 12 9D 98         [24]  841 	lcall	_ak820_outline_0119
      009FFC 40 07            [24]  842 	jc	00105$
      009FFE 74 E7            [12]  843 	mov	a,#0xe7
      00A000 9E               [12]  844 	subb	a,r6
      00A001 E4               [12]  845 	clr	a
      00A002 9F               [12]  846 	subb	a,r7
      00A003 50 08            [24]  847 	jnc	00101$
                                    848 ;	free result
      00A005                        849 00105$:
      00A005 90 0B E6         [24]  850 	mov	dptr,#_unregister_code16_code_10000_611
      00A008 12 6F 87         [24]  851 	lcall	_ak820_outline_0041
      00A00B 70 05            [24]  852 	jnz	00102$
      00A00D                        853 00101$:
                                    854 ;	quantum/quantum.c:168: unregister_mods(mods);
      00A00D 8D 82            [24]  855 	mov	dpl, r5
      00A00F 02 78 41         [24]  856 	ljmp	_unregister_mods
      00A012                        857 00102$:
                                    858 ;	quantum/quantum.c:170: unregister_weak_mods(mods);
      00A012 8D 82            [24]  859 	mov	dpl, r5
                                    860 ;	quantum/quantum.c:181: }
      00A014 02 78 69         [24]  861 	ljmp	_unregister_weak_mods
                                    862 ;------------------------------------------------------------
                                    863 ;Allocation info for local variables in function 'tap_code16_delay'
                                    864 ;------------------------------------------------------------
                                    865 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    866 ;code          Allocated with name '_tap_code16_delay_code_10000_616'
                                    867 ;i             Allocated with name '_tap_code16_delay_i_20000_618'
                                    868 ;i             Allocated with name '_tap_code16_delay_i_50000_621'
                                    869 ;------------------------------------------------------------
                                    870 ;	quantum/quantum.c:188: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    871 ;	-----------------------------------------
                                    872 ;	 function pre_process_record_kb
                                    873 ;	-----------------------------------------
      00A017                        874 _pre_process_record_kb:
      00A017 12 38 82         [24]  875 	lcall	_ak820_outline_0107
      00A01A 90 0B EB         [24]  876 	mov	dptr,#_pre_process_record_kb_keycode_10000_625
      00A01D 12 38 87         [24]  877 	lcall	_ak820_outline_0108
                                    878 ;	quantum/quantum.c:205: return pre_process_record_user(keycode, record);
      00A020 90 0B EB         [24]  879 	mov	dptr,#_pre_process_record_kb_keycode_10000_625
      00A023 12 38 41         [24]  880 	lcall	_ak820_outline_0052
      00A026 90 0B E8         [24]  881 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A029 12 9D 8F         [24]  882 	lcall	_ak820_outline_0027
      00A02C 90 0B ED         [24]  883 	mov	dptr,#_pre_process_record_user_PARM_2
      00A02F 12 A3 EF         [24]  884 	lcall	_ak820_outline_0011
                                    885 ;	quantum/quantum.c:206: }
      00A032 02 A0 35         [24]  886 	ljmp	_pre_process_record_user
                                    887 ;------------------------------------------------------------
                                    888 ;Allocation info for local variables in function 'pre_process_record_user'
                                    889 ;------------------------------------------------------------
                                    890 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    891 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_627'
                                    892 ;------------------------------------------------------------
                                    893 ;	quantum/quantum.c:208: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    894 ;	-----------------------------------------
                                    895 ;	 function pre_process_record_user
                                    896 ;	-----------------------------------------
      00A035                        897 _pre_process_record_user:
                                    898 ;	quantum/quantum.c:209: return true;
      00A035 75 82 01         [24]  899 	mov	dpl, #0x01
                                    900 ;	quantum/quantum.c:210: }
      00A038 22               [24]  901 	ret
                                    902 ;------------------------------------------------------------
                                    903 ;Allocation info for local variables in function 'process_action_kb'
                                    904 ;------------------------------------------------------------
                                    905 ;record        Allocated with name '_process_action_kb_record_10000_629'
                                    906 ;------------------------------------------------------------
                                    907 ;	quantum/quantum.c:212: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    908 ;	-----------------------------------------
                                    909 ;	 function process_action_kb
                                    910 ;	-----------------------------------------
      00A039                        911 _process_action_kb:
                                    912 ;	quantum/quantum.c:213: return true;
      00A039 75 82 01         [24]  913 	mov	dpl, #0x01
                                    914 ;	quantum/quantum.c:214: }
      00A03C 22               [24]  915 	ret
                                    916 ;------------------------------------------------------------
                                    917 ;Allocation info for local variables in function 'process_record_kb'
                                    918 ;------------------------------------------------------------
                                    919 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    920 ;keycode       Allocated with name '_process_record_kb_keycode_10000_631'
                                    921 ;------------------------------------------------------------
                                    922 ;	quantum/quantum.c:216: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    923 ;	-----------------------------------------
                                    924 ;	 function process_record_kb
                                    925 ;	-----------------------------------------
      00A03D                        926 _process_record_kb:
      00A03D 12 38 82         [24]  927 	lcall	_ak820_outline_0107
      00A040 90 0B F3         [24]  928 	mov	dptr,#_process_record_kb_keycode_10000_631
      00A043 12 38 87         [24]  929 	lcall	_ak820_outline_0108
                                    930 ;	quantum/quantum.c:217: return process_record_user(keycode, record);
      00A046 90 0B F3         [24]  931 	mov	dptr,#_process_record_kb_keycode_10000_631
      00A049 12 38 41         [24]  932 	lcall	_ak820_outline_0052
      00A04C 90 0B F0         [24]  933 	mov	dptr,#_process_record_kb_PARM_2
      00A04F 12 9D 8F         [24]  934 	lcall	_ak820_outline_0027
      00A052 90 0B F5         [24]  935 	mov	dptr,#_process_record_user_PARM_2
      00A055 12 A3 EF         [24]  936 	lcall	_ak820_outline_0011
                                    937 ;	quantum/quantum.c:218: }
      00A058 02 A0 5B         [24]  938 	ljmp	_process_record_user
                                    939 ;------------------------------------------------------------
                                    940 ;Allocation info for local variables in function 'process_record_user'
                                    941 ;------------------------------------------------------------
                                    942 ;record        Allocated with name '_process_record_user_PARM_2'
                                    943 ;keycode       Allocated with name '_process_record_user_keycode_10000_633'
                                    944 ;------------------------------------------------------------
                                    945 ;	quantum/quantum.c:220: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    946 ;	-----------------------------------------
                                    947 ;	 function process_record_user
                                    948 ;	-----------------------------------------
      00A05B                        949 _process_record_user:
                                    950 ;	quantum/quantum.c:221: return true;
      00A05B 75 82 01         [24]  951 	mov	dpl, #0x01
                                    952 ;	quantum/quantum.c:222: }
      00A05E 22               [24]  953 	ret
                                    954 ;------------------------------------------------------------
                                    955 ;Allocation info for local variables in function 'post_process_record_kb'
                                    956 ;------------------------------------------------------------
                                    957 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    958 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_635'
                                    959 ;------------------------------------------------------------
                                    960 ;	quantum/quantum.c:224: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    961 ;	-----------------------------------------
                                    962 ;	 function post_process_record_kb
                                    963 ;	-----------------------------------------
      00A05F                        964 _post_process_record_kb:
      00A05F 12 38 82         [24]  965 	lcall	_ak820_outline_0107
      00A062 90 0B FB         [24]  966 	mov	dptr,#_post_process_record_kb_keycode_10000_635
      00A065 12 38 87         [24]  967 	lcall	_ak820_outline_0108
                                    968 ;	quantum/quantum.c:225: post_process_record_user(keycode, record);
      00A068 90 0B FB         [24]  969 	mov	dptr,#_post_process_record_kb_keycode_10000_635
      00A06B 12 38 41         [24]  970 	lcall	_ak820_outline_0052
      00A06E 90 0B F8         [24]  971 	mov	dptr,#_post_process_record_kb_PARM_2
      00A071 12 9D 8F         [24]  972 	lcall	_ak820_outline_0027
      00A074 90 0B FD         [24]  973 	mov	dptr,#_post_process_record_user_PARM_2
      00A077 12 A3 EF         [24]  974 	lcall	_ak820_outline_0011
                                    975 ;	quantum/quantum.c:226: }
      00A07A 02 A0 7D         [24]  976 	ljmp	_post_process_record_user
                                    977 ;------------------------------------------------------------
                                    978 ;Allocation info for local variables in function 'post_process_record_user'
                                    979 ;------------------------------------------------------------
                                    980 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    981 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_637'
                                    982 ;------------------------------------------------------------
                                    983 ;	quantum/quantum.c:228: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    984 ;	-----------------------------------------
                                    985 ;	 function post_process_record_user
                                    986 ;	-----------------------------------------
      00A07D                        987 _post_process_record_user:
      00A07D 22               [24]  988 	ret
                                    989 ;------------------------------------------------------------
                                    990 ;Allocation info for local variables in function 'shutdown_quantum'
                                    991 ;------------------------------------------------------------
                                    992 ;i             Allocated with name '_shutdown_quantum_i_30000_643'
                                    993 ;------------------------------------------------------------
                                    994 ;	quantum/quantum.c:230: void shutdown_quantum(void) {
                                    995 ;	-----------------------------------------
                                    996 ;	 function shutdown_quantum
                                    997 ;	-----------------------------------------
      00A07E                        998 _shutdown_quantum:
                                    999 ;	quantum/quantum.c:231: clear_keyboard();
      00A07E 12 78 7D         [24] 1000 	lcall	_clear_keyboard
                                   1001 ;	quantum/quantum.c:246: shutdown_user();
      00A081 12 A3 E1         [24] 1002 	lcall	_shutdown_user
                                   1003 ;	quantum/quantum.c:247: wait_ms(250);
      00A084 7F FA            [12] 1004 	mov	r7,#0xfa
      00A086                       1005 00106$:
      00A086 EF               [12] 1006 	mov	a,r7
      00A087 60 09            [24] 1007 	jz	00108$
      00A089 90 00 01         [24] 1008 	mov	dptr,#0x0001
      00A08C 12 5A 0D         [24] 1009 	lcall	_mDelaymS
      00A08F 1F               [12] 1010 	dec	r7
      00A090 80 F4            [24] 1011 	sjmp	00106$
      00A092                       1012 00108$:
                                   1013 ;	quantum/quantum.c:252: }
      00A092 22               [24] 1014 	ret
                                   1015 ;------------------------------------------------------------
                                   1016 ;Allocation info for local variables in function 'reset_keyboard'
                                   1017 ;------------------------------------------------------------
                                   1018 ;	quantum/quantum.c:254: void reset_keyboard(void) {
                                   1019 ;	-----------------------------------------
                                   1020 ;	 function reset_keyboard
                                   1021 ;	-----------------------------------------
      00A093                       1022 _reset_keyboard:
                                   1023 ;	quantum/quantum.c:255: shutdown_quantum();
      00A093 12 A0 7E         [24] 1024 	lcall	_shutdown_quantum
                                   1025 ;	quantum/quantum.c:256: bootloader_jump();
                                   1026 ;	quantum/quantum.c:257: }
      00A096 02 34 0E         [24] 1027 	ljmp	_bootloader_jump
                                   1028 ;------------------------------------------------------------
                                   1029 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1030 ;------------------------------------------------------------
                                   1031 ;	quantum/quantum.c:259: void soft_reset_keyboard(void) {
                                   1032 ;	-----------------------------------------
                                   1033 ;	 function soft_reset_keyboard
                                   1034 ;	-----------------------------------------
      00A099                       1035 _soft_reset_keyboard:
                                   1036 ;	quantum/quantum.c:260: shutdown_quantum();
      00A099 12 A0 7E         [24] 1037 	lcall	_shutdown_quantum
                                   1038 ;	quantum/quantum.c:261: mcu_reset();
                                   1039 ;	quantum/quantum.c:262: }
      00A09C 02 34 01         [24] 1040 	ljmp	_mcu_reset
                                   1041 ;------------------------------------------------------------
                                   1042 ;Allocation info for local variables in function 'get_record_keycode'
                                   1043 ;------------------------------------------------------------
                                   1044 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1045 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_649'
                                   1046 ;record        Allocated with name '_get_record_keycode_record_10000_650'
                                   1047 ;------------------------------------------------------------
                                   1048 ;	quantum/quantum.c:265: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1049 ;	-----------------------------------------
                                   1050 ;	 function get_record_keycode
                                   1051 ;	-----------------------------------------
      00A09F                       1052 _get_record_keycode:
      00A09F 12 43 80         [24] 1053 	lcall	_ak820_outline_0038
      00A0A2 90 0C 01         [24] 1054 	mov	dptr,#_get_record_keycode_record_argument_10000_649
      00A0A5 12 38 29         [24] 1055 	lcall	_ak820_outline_0018
                                   1056 ;	quantum/quantum.c:267: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A0A8 90 0C 01         [24] 1057 	mov	dptr,#_get_record_keycode_record_argument_10000_649
      00A0AB 12 37 FE         [24] 1058 	lcall	_ak820_outline_0008
                                   1059 ;	quantum/quantum.c:272: if (record->keycode) {
      00A0AE 4C               [12] 1060 	orl	a,r4
      00A0AF 60 04            [24] 1061 	jz	00102$
                                   1062 ;	quantum/quantum.c:273: return record->keycode;
      00A0B1 12 38 97         [24] 1063 	lcall	_ak820_outline_0124
      00A0B4 22               [24] 1064 	ret
      00A0B5                       1065 00102$:
                                   1066 ;	quantum/quantum.c:277: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A0B5 12 78 DB         [24] 1067 	lcall	_ak820_outline_0022
      00A0B8 7A 00            [12] 1068 	mov	r2,#0x00
      00A0BA 12 43 D4         [24] 1069 	lcall	_ak820_outline_0142
      00A0BD 12 38 12         [24] 1070 	lcall	_ak820_outline_0010
      00A0C0 60 06            [24] 1071 	jz	00105$
      00A0C2 90 0C 00         [24] 1072 	mov	dptr,#_get_record_keycode_PARM_2
      00A0C5 E0               [24] 1073 	movx	a,@dptr
      00A0C6 70 04            [24] 1074 	jnz	00106$
      00A0C8                       1075 00105$:
                                   1076 ;	assignBit
      00A0C8 C2 27            [12] 1077 	clr	_get_record_keycode_sloc0_1_0
      00A0CA 80 02            [24] 1078 	sjmp	00107$
      00A0CC                       1079 00106$:
                                   1080 ;	assignBit
      00A0CC D2 27            [12] 1081 	setb	_get_record_keycode_sloc0_1_0
      00A0CE                       1082 00107$:
      00A0CE 90 09 72         [24] 1083 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A0D1 A2 27            [12] 1084 	mov	c,_get_record_keycode_sloc0_1_0
      00A0D3 E4               [12] 1085 	clr	a
      00A0D4 33               [12] 1086 	rlc	a
      00A0D5 F0               [24] 1087 	movx	@dptr,a
      00A0D6 12 43 FA         [24] 1088 	lcall	_ak820_outline_0189
                                   1089 ;	quantum/quantum.c:281: }
      00A0D9 02 7C 82         [24] 1090 	ljmp	_ak820_resolve_key
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'get_event_keycode'
                                   1093 ;------------------------------------------------------------
                                   1094 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1095 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_653'
                                   1096 ;------------------------------------------------------------
                                   1097 ;	quantum/quantum.c:289: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1098 ;	-----------------------------------------
                                   1099 ;	 function pre_process_record_quantum
                                   1100 ;	-----------------------------------------
      00A0DC                       1101 _pre_process_record_quantum:
      00A0DC 12 43 80         [24] 1102 	lcall	_ak820_outline_0038
      00A0DF 90 0C 04         [24] 1103 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_655
      00A0E2 12 38 29         [24] 1104 	lcall	_ak820_outline_0018
                                   1105 ;	quantum/quantum.c:322: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A0E5 90 0C 04         [24] 1106 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_655
      00A0E8 12 38 41         [24] 1107 	lcall	_ak820_outline_0052
                                   1108 ;	quantum/quantum.c:326: uint16_t keycode = get_record_keycode(record, true);
      00A0EB 8E 03            [24] 1109 	mov	ar3,r6
      00A0ED 8F 04            [24] 1110 	mov	ar4,r7
      00A0EF 7D 00            [12] 1111 	mov	r5,#0x00
      00A0F1 90 0C 00         [24] 1112 	mov	dptr,#_get_record_keycode_PARM_2
      00A0F4 74 01            [12] 1113 	mov	a,#0x01
      00A0F6 F0               [24] 1114 	movx	@dptr,a
      00A0F7 12 33 FC         [24] 1115 	lcall	_ak820_outline_0121
      00A0FA 8D F0            [24] 1116 	mov	b, r5
      00A0FC C0 07            [24] 1117 	push	ar7
      00A0FE C0 06            [24] 1118 	push	ar6
      00A100 12 A0 9F         [24] 1119 	lcall	_get_record_keycode
      00A103 12 43 DA         [24] 1120 	lcall	_ak820_outline_0149
      00A106 D0 06            [24] 1121 	pop	ar6
      00A108 D0 07            [24] 1122 	pop	ar7
                                   1123 ;	quantum/quantum.c:328: record->keycode = keycode;
      00A10A 74 07            [12] 1124 	mov	a,#0x07
      00A10C 12 38 31         [24] 1125 	lcall	_ak820_outline_0023
      00A10F 12 38 5E         [24] 1126 	lcall	_ak820_outline_0073
                                   1127 ;	quantum/quantum.c:338: return pre_process_record_kb(keycode, record) &&
      00A112 90 0B E8         [24] 1128 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A115 12 A3 E2         [24] 1129 	lcall	_ak820_outline_0002
      00A118 C0 07            [24] 1130 	push	ar7
      00A11A C0 06            [24] 1131 	push	ar6
      00A11C 12 A0 17         [24] 1132 	lcall	_pre_process_record_kb
      00A11F E5 82            [12] 1133 	mov	a, dpl
      00A121 D0 06            [24] 1134 	pop	ar6
      00A123 D0 07            [24] 1135 	pop	ar7
      00A125 60 0A            [24] 1136 	jz	00103$
                                   1137 ;	quantum/quantum.c:341: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A127 12 38 8C         [24] 1138 	lcall	_ak820_outline_0118
      00A12A 12 36 3B         [24] 1139 	lcall	_ak820_combo_process
      00A12D E5 82            [12] 1140 	mov	a, dpl
      00A12F 70 04            [24] 1141 	jnz	00104$
                                   1142 ;	quantum/quantum.c:346: true;
      00A131                       1143 00103$:
                                   1144 ;	assignBit
      00A131 C2 28            [12] 1145 	clr	_pre_process_record_quantum_sloc0_1_0
      00A133 80 02            [24] 1146 	sjmp	00105$
      00A135                       1147 00104$:
                                   1148 ;	assignBit
      00A135 D2 28            [12] 1149 	setb	_pre_process_record_quantum_sloc0_1_0
      00A137                       1150 00105$:
      00A137 A2 28            [12] 1151 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A139 12 38 B1         [24] 1152 	lcall	_ak820_outline_0156
                                   1153 ;	quantum/quantum.c:347: }
      00A13C 22               [24] 1154 	ret
                                   1155 ;------------------------------------------------------------
                                   1156 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1157 ;------------------------------------------------------------
                                   1158 ;record        Allocated with name '_post_process_record_quantum_record_10000_657'
                                   1159 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_658'
                                   1160 ;------------------------------------------------------------
                                   1161 ;	quantum/quantum.c:350: void post_process_record_quantum(keyrecord_t *record) {
                                   1162 ;	-----------------------------------------
                                   1163 ;	 function post_process_record_quantum
                                   1164 ;	-----------------------------------------
      00A13D                       1165 _post_process_record_quantum:
      00A13D 12 43 80         [24] 1166 	lcall	_ak820_outline_0038
      00A140 90 0C 07         [24] 1167 	mov	dptr,#_post_process_record_quantum_record_10000_657
      00A143 12 38 29         [24] 1168 	lcall	_ak820_outline_0018
                                   1169 ;	quantum/quantum.c:351: uint16_t keycode = get_record_keycode(record, false);
      00A146 90 0C 07         [24] 1170 	mov	dptr,#_post_process_record_quantum_record_10000_657
      00A149 12 50 39         [24] 1171 	lcall	_ak820_outline_0013
      00A14C 90 0C 00         [24] 1172 	mov	dptr,#_get_record_keycode_PARM_2
      00A14F E4               [12] 1173 	clr	a
      00A150 12 50 42         [24] 1174 	lcall	_ak820_outline_0035
      00A153 12 A0 9F         [24] 1175 	lcall	_get_record_keycode
      00A156 12 43 C9         [24] 1176 	lcall	_ak820_outline_0133
                                   1177 ;	quantum/quantum.c:352: post_process_record_kb(keycode, record);
      00A159 90 0C 07         [24] 1178 	mov	dptr,#_post_process_record_quantum_record_10000_657
      00A15C 12 9D 8F         [24] 1179 	lcall	_ak820_outline_0027
      00A15F 90 0B F8         [24] 1180 	mov	dptr,#_post_process_record_kb_PARM_2
      00A162 12 A3 EF         [24] 1181 	lcall	_ak820_outline_0011
                                   1182 ;	quantum/quantum.c:353: }
      00A165 02 A0 5F         [24] 1183 	ljmp	_post_process_record_kb
                                   1184 ;------------------------------------------------------------
                                   1185 ;Allocation info for local variables in function 'process_record_quantum'
                                   1186 ;------------------------------------------------------------
                                   1187 ;record        Allocated with name '_process_record_quantum_record_10000_659'
                                   1188 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_660'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	quantum/quantum.c:355: bool process_record_quantum(keyrecord_t *record) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function process_record_quantum
                                   1193 ;	-----------------------------------------
      00A168                       1194 _process_record_quantum:
      00A168 12 43 80         [24] 1195 	lcall	_ak820_outline_0038
      00A16B 90 0C 0A         [24] 1196 	mov	dptr,#_process_record_quantum_record_10000_659
      00A16E 12 38 29         [24] 1197 	lcall	_ak820_outline_0018
                                   1198 ;	quantum/quantum.c:357: uint16_t keycode = get_record_keycode(record, false);
      00A171 90 0C 0A         [24] 1199 	mov	dptr,#_process_record_quantum_record_10000_659
      00A174 12 50 39         [24] 1200 	lcall	_ak820_outline_0013
      00A177 90 0C 00         [24] 1201 	mov	dptr,#_get_record_keycode_PARM_2
      00A17A E4               [12] 1202 	clr	a
      00A17B 12 50 42         [24] 1203 	lcall	_ak820_outline_0035
      00A17E 12 A0 9F         [24] 1204 	lcall	_get_record_keycode
      00A181 12 43 C9         [24] 1205 	lcall	_ak820_outline_0133
                                   1206 ;	quantum/quantum.c:361: return process_record_quantum_helper(keycode, record);
      00A184 90 0C 0A         [24] 1207 	mov	dptr,#_process_record_quantum_record_10000_659
      00A187 12 9D 8F         [24] 1208 	lcall	_ak820_outline_0027
      00A18A 90 0C 12         [24] 1209 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A18D 12 A3 EF         [24] 1210 	lcall	_ak820_outline_0011
                                   1211 ;	quantum/quantum.c:362: }
      00A190 02 A1 FE         [24] 1212 	ljmp	_process_record_quantum_helper
                                   1213 ;------------------------------------------------------------
                                   1214 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1215 ;------------------------------------------------------------
                                   1216 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1217 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_661'
                                   1218 ;record        Allocated with name '_process_ak820_nkro_record_10000_662'
                                   1219 ;------------------------------------------------------------
                                   1220 ;	quantum/quantum.c:369: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1221 ;	-----------------------------------------
                                   1222 ;	 function process_ak820_nkro
                                   1223 ;	-----------------------------------------
      00A193                       1224 _process_ak820_nkro:
      00A193 12 38 82         [24] 1225 	lcall	_ak820_outline_0107
      00A196 90 0C 10         [24] 1226 	mov	dptr,#_process_ak820_nkro_keycode_10000_661
      00A199 12 38 87         [24] 1227 	lcall	_ak820_outline_0108
                                   1228 ;	quantum/quantum.c:371: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A19C 90 0C 0D         [24] 1229 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A19F 12 38 41         [24] 1230 	lcall	_ak820_outline_0052
                                   1231 ;	quantum/quantum.c:375: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A1A2 90 0C 10         [24] 1232 	mov	dptr,#_process_ak820_nkro_keycode_10000_661
      00A1A5 12 38 58         [24] 1233 	lcall	_ak820_outline_0060
      00A1A8 C3               [12] 1234 	clr	c
      00A1A9 EC               [12] 1235 	mov	a,r4
      00A1AA 94 11            [12] 1236 	subb	a,#0x11
      00A1AC ED               [12] 1237 	mov	a,r5
      00A1AD 94 70            [12] 1238 	subb	a,#0x70
      00A1AF 40 08            [24] 1239 	jc	00101$
      00A1B1 74 13            [12] 1240 	mov	a,#0x13
      00A1B3 9C               [12] 1241 	subb	a,r4
      00A1B4 74 70            [12] 1242 	mov	a,#0x70
      00A1B6 9D               [12] 1243 	subb	a,r5
      00A1B7 50 04            [24] 1244 	jnc	00102$
                                   1245 ;	free result
      00A1B9                       1246 00101$:
      00A1B9 75 82 01         [24] 1247 	mov	dpl, #0x01
      00A1BC 22               [24] 1248 	ret
      00A1BD                       1249 00102$:
                                   1250 ;	quantum/quantum.c:376: if (record->event.pressed) {
      00A1BD 12 38 12         [24] 1251 	lcall	_ak820_outline_0010
      00A1C0 60 38            [24] 1252 	jz	00105$
                                   1253 ;	quantum/quantum.c:377: clear_keyboard();
      00A1C2 C0 05            [24] 1254 	push	ar5
      00A1C4 C0 04            [24] 1255 	push	ar4
      00A1C6 12 78 7D         [24] 1256 	lcall	_clear_keyboard
      00A1C9 D0 04            [24] 1257 	pop	ar4
      00A1CB D0 05            [24] 1258 	pop	ar5
                                   1259 ;	quantum/quantum.c:378: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A1CD BC 13 14         [24] 1260 	cjne	r4,#0x13,00108$
      00A1D0 BD 70 11         [24] 1261 	cjne	r5,#0x70,00108$
      00A1D3 90 0A C7         [24] 1262 	mov	dptr,#_keymap_config
      00A1D6 E0               [24] 1263 	movx	a,@dptr
      00A1D7 23               [12] 1264 	rl	a
      00A1D8 54 01            [12] 1265 	anl	a,#0x01
      00A1DA B4 01 00         [24] 1266 	cjne	a,#0x01,00136$
      00A1DD                       1267 00136$:
      00A1DD 92 29            [24] 1268 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A1DF E4               [12] 1269 	clr	a
      00A1E0 33               [12] 1270 	rlc	a
      00A1E1 FF               [12] 1271 	mov	r7,a
      00A1E2 80 09            [24] 1272 	sjmp	00109$
      00A1E4                       1273 00108$:
      00A1E4 E4               [12] 1274 	clr	a
      00A1E5 BC 11 04         [24] 1275 	cjne	r4,#0x11,00137$
      00A1E8 BD 70 01         [24] 1276 	cjne	r5,#0x70,00137$
      00A1EB 04               [12] 1277 	inc	a
      00A1EC                       1278 00137$:
      00A1EC FF               [12] 1279 	mov	r7,a
      00A1ED                       1280 00109$:
                                   1281 ;	assignBit
      00A1ED EF               [12] 1282 	mov	a,r7
      00A1EE 24 FF            [12] 1283 	add	a,#0xff
      00A1F0 E4               [12] 1284 	clr	a
      00A1F1 33               [12] 1285 	rlc	a
      00A1F2 90 0A C7         [24] 1286 	mov	dptr,#_keymap_config
      00A1F5 13               [12] 1287 	rrc	a
      00A1F6 E0               [24] 1288 	movx	a,@dptr
      00A1F7 92 E7            [24] 1289 	mov	acc.7,c
      00A1F9 F0               [24] 1290 	movx	@dptr,a
      00A1FA                       1291 00105$:
                                   1292 ;	quantum/quantum.c:380: return false;
      00A1FA 75 82 00         [24] 1293 	mov	dpl, #0x00
                                   1294 ;	quantum/quantum.c:381: }
      00A1FD 22               [24] 1295 	ret
                                   1296 ;------------------------------------------------------------
                                   1297 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1298 ;------------------------------------------------------------
                                   1299 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1300 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_666'
                                   1301 ;record        Allocated with name '_process_record_quantum_helper_record_10000_667'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/quantum.c:384: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function process_record_quantum_helper
                                   1306 ;	-----------------------------------------
      00A1FE                       1307 _process_record_quantum_helper:
      00A1FE 12 38 82         [24] 1308 	lcall	_ak820_outline_0107
      00A201 90 0C 15         [24] 1309 	mov	dptr,#_process_record_quantum_helper_keycode_10000_666
      00A204 12 38 87         [24] 1310 	lcall	_ak820_outline_0108
                                   1311 ;	quantum/quantum.c:386: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A207 90 0C 12         [24] 1312 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A20A 12 38 41         [24] 1313 	lcall	_ak820_outline_0052
                                   1314 ;	quantum/quantum.c:426: ak820_gui_process(keycode, record->event.pressed) &&
      00A20D 90 0C 15         [24] 1315 	mov	dptr,#_process_record_quantum_helper_keycode_10000_666
      00A210 12 38 58         [24] 1316 	lcall	_ak820_outline_0060
      00A213 74 05            [12] 1317 	mov	a,#0x05
      00A215 12 49 B5         [24] 1318 	lcall	_ak820_outline_0033
      00A218 90 09 78         [24] 1319 	mov	dptr,#_ak820_gui_process_PARM_2
      00A21B 12 38 76         [24] 1320 	lcall	_ak820_outline_0101
      00A21E C0 07            [24] 1321 	push	ar7
      00A220 C0 06            [24] 1322 	push	ar6
      00A222 C0 05            [24] 1323 	push	ar5
      00A224 C0 04            [24] 1324 	push	ar4
      00A226 C0 03            [24] 1325 	push	ar3
      00A228 C0 02            [24] 1326 	push	ar2
      00A22A 12 7D 61         [24] 1327 	lcall	_ak820_gui_process
      00A22D E5 82            [12] 1328 	mov	a, dpl
      00A22F D0 02            [24] 1329 	pop	ar2
      00A231 D0 03            [24] 1330 	pop	ar3
      00A233 D0 04            [24] 1331 	pop	ar4
      00A235 D0 05            [24] 1332 	pop	ar5
      00A237 D0 06            [24] 1333 	pop	ar6
      00A239 D0 07            [24] 1334 	pop	ar7
      00A23B 70 03            [24] 1335 	jnz	00212$
      00A23D 02 A3 9F         [24] 1336 	ljmp	00101$
      00A240                       1337 00212$:
                                   1338 ;	quantum/quantum.c:429: process_ak820_nkro(keycode, record) &&
      00A240 90 0C 0D         [24] 1339 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A243 12 A3 E2         [24] 1340 	lcall	_ak820_outline_0002
      00A246 C0 07            [24] 1341 	push	ar7
      00A248 C0 06            [24] 1342 	push	ar6
      00A24A C0 05            [24] 1343 	push	ar5
      00A24C C0 04            [24] 1344 	push	ar4
      00A24E C0 03            [24] 1345 	push	ar3
      00A250 C0 02            [24] 1346 	push	ar2
      00A252 12 A1 93         [24] 1347 	lcall	_process_ak820_nkro
      00A255 E5 82            [12] 1348 	mov	a, dpl
      00A257 D0 02            [24] 1349 	pop	ar2
      00A259 D0 03            [24] 1350 	pop	ar3
      00A25B D0 04            [24] 1351 	pop	ar4
      00A25D D0 05            [24] 1352 	pop	ar5
      00A25F D0 06            [24] 1353 	pop	ar6
      00A261 D0 07            [24] 1354 	pop	ar7
      00A263 70 03            [24] 1355 	jnz	00213$
      00A265 02 A3 9F         [24] 1356 	ljmp	00101$
      00A268                       1357 00213$:
                                   1358 ;	quantum/quantum.c:440: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A268 90 0B CB         [24] 1359 	mov	dptr,#_process_last_key_PARM_2
      00A26B 12 A3 E2         [24] 1360 	lcall	_ak820_outline_0002
      00A26E C0 07            [24] 1361 	push	ar7
      00A270 C0 06            [24] 1362 	push	ar6
      00A272 C0 05            [24] 1363 	push	ar5
      00A274 C0 04            [24] 1364 	push	ar4
      00A276 C0 03            [24] 1365 	push	ar3
      00A278 C0 02            [24] 1366 	push	ar2
      00A27A 12 9C C8         [24] 1367 	lcall	_process_last_key
      00A27D E5 82            [12] 1368 	mov	a, dpl
      00A27F D0 02            [24] 1369 	pop	ar2
      00A281 D0 03            [24] 1370 	pop	ar3
      00A283 D0 04            [24] 1371 	pop	ar4
      00A285 D0 05            [24] 1372 	pop	ar5
      00A287 D0 06            [24] 1373 	pop	ar6
      00A289 D0 07            [24] 1374 	pop	ar7
      00A28B 70 03            [24] 1375 	jnz	00214$
      00A28D 02 A3 9F         [24] 1376 	ljmp	00101$
      00A290                       1377 00214$:
      00A290 90 0B D1         [24] 1378 	mov	dptr,#_process_repeat_key_PARM_2
      00A293 12 A3 E2         [24] 1379 	lcall	_ak820_outline_0002
      00A296 C0 07            [24] 1380 	push	ar7
      00A298 C0 06            [24] 1381 	push	ar6
      00A29A C0 05            [24] 1382 	push	ar5
      00A29C C0 04            [24] 1383 	push	ar4
      00A29E C0 03            [24] 1384 	push	ar3
      00A2A0 C0 02            [24] 1385 	push	ar2
      00A2A2 12 9D 46         [24] 1386 	lcall	_process_repeat_key
      00A2A5 E5 82            [12] 1387 	mov	a, dpl
      00A2A7 D0 02            [24] 1388 	pop	ar2
      00A2A9 D0 03            [24] 1389 	pop	ar3
      00A2AB D0 04            [24] 1390 	pop	ar4
      00A2AD D0 05            [24] 1391 	pop	ar5
      00A2AF D0 06            [24] 1392 	pop	ar6
      00A2B1 D0 07            [24] 1393 	pop	ar7
      00A2B3 70 03            [24] 1394 	jnz	00215$
      00A2B5 02 A3 9F         [24] 1395 	ljmp	00101$
      00A2B8                       1396 00215$:
                                   1397 ;	quantum/quantum.c:449: process_record_via(keycode, record) &&
      00A2B8 90 0C 52         [24] 1398 	mov	dptr,#_process_record_via_PARM_2
      00A2BB 12 A3 E2         [24] 1399 	lcall	_ak820_outline_0002
      00A2BE C0 07            [24] 1400 	push	ar7
      00A2C0 C0 06            [24] 1401 	push	ar6
      00A2C2 C0 05            [24] 1402 	push	ar5
      00A2C4 C0 04            [24] 1403 	push	ar4
      00A2C6 C0 03            [24] 1404 	push	ar3
      00A2C8 C0 02            [24] 1405 	push	ar2
      00A2CA 12 A8 F3         [24] 1406 	lcall	_process_record_via
      00A2CD E5 82            [12] 1407 	mov	a, dpl
      00A2CF D0 02            [24] 1408 	pop	ar2
      00A2D1 D0 03            [24] 1409 	pop	ar3
      00A2D3 D0 04            [24] 1410 	pop	ar4
      00A2D5 D0 05            [24] 1411 	pop	ar5
      00A2D7 D0 06            [24] 1412 	pop	ar6
      00A2D9 D0 07            [24] 1413 	pop	ar7
      00A2DB 70 03            [24] 1414 	jnz	00216$
      00A2DD 02 A3 9F         [24] 1415 	ljmp	00101$
      00A2E0                       1416 00216$:
                                   1417 ;	quantum/quantum.c:459: process_record_kb(keycode, record) &&
      00A2E0 90 0B F0         [24] 1418 	mov	dptr,#_process_record_kb_PARM_2
      00A2E3 12 A3 E2         [24] 1419 	lcall	_ak820_outline_0002
      00A2E6 C0 07            [24] 1420 	push	ar7
      00A2E8 C0 06            [24] 1421 	push	ar6
      00A2EA C0 05            [24] 1422 	push	ar5
      00A2EC C0 04            [24] 1423 	push	ar4
      00A2EE C0 03            [24] 1424 	push	ar3
      00A2F0 C0 02            [24] 1425 	push	ar2
      00A2F2 12 A0 3D         [24] 1426 	lcall	_process_record_kb
      00A2F5 E5 82            [12] 1427 	mov	a, dpl
      00A2F7 D0 02            [24] 1428 	pop	ar2
      00A2F9 D0 03            [24] 1429 	pop	ar3
      00A2FB D0 04            [24] 1430 	pop	ar4
      00A2FD D0 05            [24] 1431 	pop	ar5
      00A2FF D0 06            [24] 1432 	pop	ar6
      00A301 D0 07            [24] 1433 	pop	ar7
      00A303 70 03            [24] 1434 	jnz	00217$
      00A305 02 A3 9F         [24] 1435 	ljmp	00101$
      00A308                       1436 00217$:
                                   1437 ;	quantum/quantum.c:482: process_caps_word(keycode, record) &&
      00A308 90 0B B3         [24] 1438 	mov	dptr,#_process_caps_word_PARM_2
      00A30B 12 A3 E2         [24] 1439 	lcall	_ak820_outline_0002
      00A30E C0 07            [24] 1440 	push	ar7
      00A310 C0 06            [24] 1441 	push	ar6
      00A312 C0 05            [24] 1442 	push	ar5
      00A314 C0 04            [24] 1443 	push	ar4
      00A316 C0 03            [24] 1444 	push	ar3
      00A318 C0 02            [24] 1445 	push	ar2
      00A31A 12 9A 50         [24] 1446 	lcall	_process_caps_word
      00A31D E5 82            [12] 1447 	mov	a, dpl
      00A31F D0 02            [24] 1448 	pop	ar2
      00A321 D0 03            [24] 1449 	pop	ar3
      00A323 D0 04            [24] 1450 	pop	ar4
      00A325 D0 05            [24] 1451 	pop	ar5
      00A327 D0 06            [24] 1452 	pop	ar6
      00A329 D0 07            [24] 1453 	pop	ar7
      00A32B 70 03            [24] 1454 	jnz	00218$
      00A32D 02 A3 9F         [24] 1455 	ljmp	00101$
      00A330                       1456 00218$:
                                   1457 ;	quantum/quantum.c:509: process_grave_esc(keycode, record) &&
      00A330 90 0B B8         [24] 1458 	mov	dptr,#_process_grave_esc_PARM_2
      00A333 12 A3 E2         [24] 1459 	lcall	_ak820_outline_0002
      00A336 C0 07            [24] 1460 	push	ar7
      00A338 C0 06            [24] 1461 	push	ar6
      00A33A C0 05            [24] 1462 	push	ar5
      00A33C C0 04            [24] 1463 	push	ar4
      00A33E C0 03            [24] 1464 	push	ar3
      00A340 C0 02            [24] 1465 	push	ar2
      00A342 12 9B 63         [24] 1466 	lcall	_process_grave_esc
      00A345 E5 82            [12] 1467 	mov	a, dpl
      00A347 D0 02            [24] 1468 	pop	ar2
      00A349 D0 03            [24] 1469 	pop	ar3
      00A34B D0 04            [24] 1470 	pop	ar4
      00A34D D0 05            [24] 1471 	pop	ar5
      00A34F D0 06            [24] 1472 	pop	ar6
      00A351 D0 07            [24] 1473 	pop	ar7
      00A353 60 4A            [24] 1474 	jz	00101$
                                   1475 ;	quantum/quantum.c:512: process_rgb(keycode, record) &&
      00A355 90 0B D6         [24] 1476 	mov	dptr,#_process_rgb_PARM_2
      00A358 12 A3 E2         [24] 1477 	lcall	_ak820_outline_0002
      00A35B C0 07            [24] 1478 	push	ar7
      00A35D C0 06            [24] 1479 	push	ar6
      00A35F C0 05            [24] 1480 	push	ar5
      00A361 C0 04            [24] 1481 	push	ar4
      00A363 C0 03            [24] 1482 	push	ar3
      00A365 C0 02            [24] 1483 	push	ar2
      00A367 12 9D A0         [24] 1484 	lcall	_process_rgb
      00A36A E5 82            [12] 1485 	mov	a, dpl
      00A36C D0 02            [24] 1486 	pop	ar2
      00A36E D0 03            [24] 1487 	pop	ar3
      00A370 D0 04            [24] 1488 	pop	ar4
      00A372 D0 05            [24] 1489 	pop	ar5
      00A374 D0 06            [24] 1490 	pop	ar6
      00A376 D0 07            [24] 1491 	pop	ar7
      00A378 60 25            [24] 1492 	jz	00101$
                                   1493 ;	quantum/quantum.c:524: process_tri_layer(keycode, record) &&
      00A37A 90 0B DC         [24] 1494 	mov	dptr,#_process_tri_layer_PARM_2
      00A37D 12 A3 E2         [24] 1495 	lcall	_ak820_outline_0002
      00A380 C0 07            [24] 1496 	push	ar7
      00A382 C0 06            [24] 1497 	push	ar6
      00A384 C0 05            [24] 1498 	push	ar5
      00A386 C0 04            [24] 1499 	push	ar4
      00A388 C0 03            [24] 1500 	push	ar3
      00A38A C0 02            [24] 1501 	push	ar2
      00A38C 12 9E 51         [24] 1502 	lcall	_process_tri_layer
      00A38F E5 82            [12] 1503 	mov	a, dpl
      00A391 D0 02            [24] 1504 	pop	ar2
      00A393 D0 03            [24] 1505 	pop	ar3
      00A395 D0 04            [24] 1506 	pop	ar4
      00A397 D0 05            [24] 1507 	pop	ar5
      00A399 D0 06            [24] 1508 	pop	ar6
      00A39B D0 07            [24] 1509 	pop	ar7
      00A39D 70 04            [24] 1510 	jnz	00102$
                                   1511 ;	quantum/quantum.c:526: true)) {
      00A39F                       1512 00101$:
                                   1513 ;	quantum/quantum.c:527: return false;
      00A39F 75 82 00         [24] 1514 	mov	dpl, #0x00
      00A3A2 22               [24] 1515 	ret
      00A3A3                       1516 00102$:
                                   1517 ;	quantum/quantum.c:530: if (record->event.pressed) {
      00A3A3 12 38 AC         [24] 1518 	lcall	_ak820_outline_0143
      00A3A6 E0               [24] 1519 	movx	a,@dptr
      00A3A7 60 30            [24] 1520 	jz	00118$
                                   1521 ;	quantum/quantum.c:531: switch (keycode) {
      00A3A9 BC 00 05         [24] 1522 	cjne	r4,#0x00,00223$
      00A3AC BD 7C 02         [24] 1523 	cjne	r5,#0x7c,00223$
      00A3AF 80 10            [24] 1524 	sjmp	00113$
      00A3B1                       1525 00223$:
      00A3B1 BC 01 05         [24] 1526 	cjne	r4,#0x01,00224$
      00A3B4 BD 7C 02         [24] 1527 	cjne	r5,#0x7c,00224$
      00A3B7 80 0F            [24] 1528 	sjmp	00114$
      00A3B9                       1529 00224$:
                                   1530 ;	quantum/quantum.c:533: case QK_BOOTLOADER:
      00A3B9 BC 03 1D         [24] 1531 	cjne	r4,#0x03,00118$
      00A3BC BD 7C 1A         [24] 1532 	cjne	r5,#0x7c,00118$
      00A3BF 80 0E            [24] 1533 	sjmp	00115$
      00A3C1                       1534 00113$:
                                   1535 ;	quantum/quantum.c:534: reset_keyboard();
      00A3C1 12 A0 93         [24] 1536 	lcall	_reset_keyboard
                                   1537 ;	quantum/quantum.c:535: return false;
      00A3C4 75 82 00         [24] 1538 	mov	dpl, #0x00
                                   1539 ;	quantum/quantum.c:536: case QK_REBOOT:
      00A3C7 22               [24] 1540 	ret
      00A3C8                       1541 00114$:
                                   1542 ;	quantum/quantum.c:537: soft_reset_keyboard();
      00A3C8 12 A0 99         [24] 1543 	lcall	_soft_reset_keyboard
                                   1544 ;	quantum/quantum.c:538: return false;
      00A3CB 75 82 00         [24] 1545 	mov	dpl, #0x00
                                   1546 ;	quantum/quantum.c:550: case QK_CLEAR_EEPROM:
      00A3CE 22               [24] 1547 	ret
      00A3CF                       1548 00115$:
                                   1549 ;	quantum/quantum.c:557: eeconfig_disable();
      00A3CF 12 91 BC         [24] 1550 	lcall	_eeconfig_disable
                                   1551 ;	quantum/quantum.c:558: soft_reset_keyboard();
      00A3D2 12 A0 99         [24] 1552 	lcall	_soft_reset_keyboard
                                   1553 ;	quantum/quantum.c:560: return false;
      00A3D5 75 82 00         [24] 1554 	mov	dpl, #0x00
                                   1555 ;	quantum/quantum.c:615: }
      00A3D8 22               [24] 1556 	ret
      00A3D9                       1557 00118$:
                                   1558 ;	quantum/quantum.c:618: return process_action_kb(record);
      00A3D9 7D 00            [12] 1559 	mov	r5,#0x00
      00A3DB 12 71 A3         [24] 1560 	lcall	_ak820_outline_0065
                                   1561 ;	quantum/quantum.c:619: }
      00A3DE 02 A0 39         [24] 1562 	ljmp	_process_action_kb
                                   1563 ;------------------------------------------------------------
                                   1564 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1565 ;------------------------------------------------------------
                                   1566 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_674'
                                   1567 ;------------------------------------------------------------
                                   1568 ;	quantum/quantum.c:621: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1569 ;	-----------------------------------------
                                   1570 ;	 function shutdown_user
                                   1571 ;	-----------------------------------------
      00A3E1                       1572 _shutdown_user:
      00A3E1 22               [24] 1573 	ret
                                   1574 ;------------------------------------------------------------
                                   1575 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1576 ;------------------------------------------------------------
                                   1577 ;	quantum/quantum.c:637: void suspend_power_down_quantum(void) {
                                   1578 ;	-----------------------------------------
                                   1579 	.area CSEG    (CODE)
                                   1580 	.area CONST   (CODE)
                                   1581 	.area XINIT   (CODE)
                                   1582 	.area CABS    (ABS,CODE)
                                   1583 
                                   1584 ; Experimental exact instruction outlining.
                                   1585 	.globl _ak820_outline_0002
                                   1586 	.globl _ak820_outline_0005
                                   1587 	.globl _ak820_outline_0008
                                   1588 	.globl _ak820_outline_0010
                                   1589 	.globl _ak820_outline_0011
                                   1590 	.globl _ak820_outline_0013
                                   1591 	.globl _ak820_outline_0018
                                   1592 	.globl _ak820_outline_0022
                                   1593 	.globl _ak820_outline_0023
                                   1594 	.globl _ak820_outline_0027
                                   1595 	.globl _ak820_outline_0033
                                   1596 	.globl _ak820_outline_0035
                                   1597 	.globl _ak820_outline_0038
                                   1598 	.globl _ak820_outline_0041
                                   1599 	.globl _ak820_outline_0052
                                   1600 	.globl _ak820_outline_0060
                                   1601 	.globl _ak820_outline_0065
                                   1602 	.globl _ak820_outline_0073
                                   1603 	.globl _ak820_outline_0101
                                   1604 	.globl _ak820_outline_0107
                                   1605 	.globl _ak820_outline_0108
                                   1606 	.globl _ak820_outline_0118
                                   1607 	.globl _ak820_outline_0119
                                   1608 	.globl _ak820_outline_0121
                                   1609 	.globl _ak820_outline_0124
                                   1610 	.globl _ak820_outline_0133
                                   1611 	.globl _ak820_outline_0142
                                   1612 	.globl _ak820_outline_0143
                                   1613 	.globl _ak820_outline_0149
                                   1614 	.globl _ak820_outline_0156
                                   1615 	.globl _ak820_outline_0189
                                   1616 
                                   1617 	.area CSEG (CODE)
                                   1618 ; function ak820_outline_0002
      00A3E2                       1619 _ak820_outline_0002:
      00A3E2 EE               [12] 1620 	mov	a,r6
      00A3E3 F0               [24] 1621 	movx	@dptr,a
      00A3E4 EF               [12] 1622 	mov	a,r7
      00A3E5 A3               [24] 1623 	inc	dptr
      00A3E6 F0               [24] 1624 	movx	@dptr,a
      00A3E7 E4               [12] 1625 	clr	a
      00A3E8 A3               [24] 1626 	inc	dptr
      00A3E9 F0               [24] 1627 	movx	@dptr,a
      00A3EA 8C 82            [24] 1628 	mov	dpl,r4
      00A3EC 8D 83            [24] 1629 	mov	dph,r5
      00A3EE 22               [24] 1630 	ret
                                   1631 
                                   1632 	.area CSEG (CODE)
                                   1633 ; function ak820_outline_0011
      00A3EF                       1634 _ak820_outline_0011:
      00A3EF EB               [12] 1635 	mov	a,r3
      00A3F0 F0               [24] 1636 	movx	@dptr,a
      00A3F1 EC               [12] 1637 	mov	a,r4
      00A3F2 A3               [24] 1638 	inc	dptr
      00A3F3 F0               [24] 1639 	movx	@dptr,a
      00A3F4 ED               [12] 1640 	mov	a,r5
      00A3F5 A3               [24] 1641 	inc	dptr
      00A3F6 F0               [24] 1642 	movx	@dptr,a
      00A3F7 8E 82            [24] 1643 	mov	dpl,r6
      00A3F9 8F 83            [24] 1644 	mov	dph,r7
      00A3FB 22               [24] 1645 	ret
