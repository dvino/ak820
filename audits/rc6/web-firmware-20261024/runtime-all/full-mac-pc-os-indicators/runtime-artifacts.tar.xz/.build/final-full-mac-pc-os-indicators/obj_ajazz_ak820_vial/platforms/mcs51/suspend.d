suspend.o: platforms/mcs51/suspend.c keyboards/ajazz/ak820/config.h \
 .build/final-full-mac-pc-os-indicators/obj_ajazz_ak820_vial/src/info_config.h \
 keyboards/ajazz/ak820/keymaps/vial/config.h \
 quantum/rgb_matrix/post_config.h
