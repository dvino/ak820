                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_os_indicators
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _timer_elapsed32
                                     12 	.globl _timer_read32
                                     13 	.globl _timer_read
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _ak820_os_indicator_mode
                                    258 	.globl _ak820_os_indicator_set
                                    259 	.globl _ak820_os_indicator_get
                                    260 	.globl _ak820_os_indicator_value
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
                                    523 ;--------------------------------------------------------
                                    524 ; overlayable items in internal ram
                                    525 ;--------------------------------------------------------
                                    526 ;--------------------------------------------------------
                                    527 ; indirectly addressable internal ram data
                                    528 ;--------------------------------------------------------
                                    529 	.area ISEG    (DATA)
                                    530 ;--------------------------------------------------------
                                    531 ; absolute internal ram data
                                    532 ;--------------------------------------------------------
                                    533 	.area IABS    (ABS,DATA)
                                    534 	.area IABS    (ABS,DATA)
                                    535 ;--------------------------------------------------------
                                    536 ; bit data
                                    537 ;--------------------------------------------------------
                                    538 	.area BSEG    (BIT)
                                    539 ;--------------------------------------------------------
                                    540 ; paged external ram data
                                    541 ;--------------------------------------------------------
                                    542 	.area PSEG    (PAG,XDATA)
                                    543 ;--------------------------------------------------------
                                    544 ; uninitialized external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area XSEG    (XDATA)
      00059E                        547 _ak820_os_indicator_mode::
      00059E                        548 	.ds 1
      00059F                        549 _os_indicator_refreshed:
      00059F                        550 	.ds 4
      0005A3                        551 _ak820_os_indicator_set_mode_10000_177:
      0005A3                        552 	.ds 1
      0005A4                        553 _ak820_os_indicator_value_normal_10000_182:
      0005A4                        554 	.ds 1
      0005A5                        555 _ak820_os_indicator_value_phase_10000_183:
      0005A5                        556 	.ds 1
                                    557 ;--------------------------------------------------------
                                    558 ; absolute external ram data
                                    559 ;--------------------------------------------------------
                                    560 	.area XABS    (ABS,XDATA)
                                    561 ;--------------------------------------------------------
                                    562 ; initialized external ram data
                                    563 ;--------------------------------------------------------
                                    564 	.area XISEG   (XDATA)
                                    565 	.area HOME    (CODE)
                                    566 	.area GSINIT0 (CODE)
                                    567 	.area GSINIT1 (CODE)
                                    568 	.area GSINIT2 (CODE)
                                    569 	.area GSINIT3 (CODE)
                                    570 	.area GSINIT4 (CODE)
                                    571 	.area GSINIT5 (CODE)
                                    572 	.area GSINIT  (CODE)
                                    573 	.area GSFINAL (CODE)
                                    574 	.area CSEG    (CODE)
                                    575 ;--------------------------------------------------------
                                    576 ; global & static initialisations
                                    577 ;--------------------------------------------------------
                                    578 	.area HOME    (CODE)
                                    579 	.area GSINIT  (CODE)
                                    580 	.area GSFINAL (CODE)
                                    581 	.area GSINIT  (CODE)
                                    582 ;--------------------------------------------------------
                                    583 ; Home
                                    584 ;--------------------------------------------------------
                                    585 	.area HOME    (CODE)
                                    586 	.area HOME    (CODE)
                                    587 ;--------------------------------------------------------
                                    588 ; code
                                    589 ;--------------------------------------------------------
                                    590 	.area CSEG    (CODE)
                                    591 ;------------------------------------------------------------
                                    592 ;Allocation info for local variables in function 'ak820_os_indicator_set'
                                    593 ;------------------------------------------------------------
                                    594 ;mode          Allocated with name '_ak820_os_indicator_set_mode_10000_177'
                                    595 ;------------------------------------------------------------
                                    596 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:9: void ak820_os_indicator_set(uint8_t mode) {
                                    597 ;	-----------------------------------------
                                    598 ;	 function ak820_os_indicator_set
                                    599 ;	-----------------------------------------
      0043FF                        600 _ak820_os_indicator_set:
                           000007   601 	ar7 = 0x07
                           000006   602 	ar6 = 0x06
                           000005   603 	ar5 = 0x05
                           000004   604 	ar4 = 0x04
                           000003   605 	ar3 = 0x03
                           000002   606 	ar2 = 0x02
                           000001   607 	ar1 = 0x01
                           000000   608 	ar0 = 0x00
      0043FF E5 82            [12]  609 	mov	a,dpl
      004401 90 05 A3         [24]  610 	mov	dptr,#_ak820_os_indicator_set_mode_10000_177
      004404 F0               [24]  611 	movx	@dptr,a
                                    612 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:10: os_indicator_refreshed = timer_read32();
      004405 12 4A 55         [24]  613 	lcall	_timer_read32
      004408 AC 82            [24]  614 	mov	r4, dpl
      00440A AD 83            [24]  615 	mov	r5, dph
      00440C AE F0            [24]  616 	mov	r6, b
      00440E FF               [12]  617 	mov	r7, a
      00440F 90 05 9F         [24]  618 	mov	dptr,#_os_indicator_refreshed
      004412 EC               [12]  619 	mov	a,r4
      004413 F0               [24]  620 	movx	@dptr,a
      004414 ED               [12]  621 	mov	a,r5
      004415 A3               [24]  622 	inc	dptr
      004416 F0               [24]  623 	movx	@dptr,a
      004417 EE               [12]  624 	mov	a,r6
      004418 A3               [24]  625 	inc	dptr
      004419 F0               [24]  626 	movx	@dptr,a
      00441A EF               [12]  627 	mov	a,r7
      00441B A3               [24]  628 	inc	dptr
      00441C F0               [24]  629 	movx	@dptr,a
                                    630 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:11: ak820_os_indicator_mode = mode;
      00441D 90 05 A3         [24]  631 	mov	dptr,#_ak820_os_indicator_set_mode_10000_177
      004420 E0               [24]  632 	movx	a,@dptr
      004421 90 05 9E         [24]  633 	mov	dptr,#_ak820_os_indicator_mode
      004424 F0               [24]  634 	movx	@dptr,a
                                    635 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:12: }
      004425 22               [24]  636 	ret
                                    637 ;------------------------------------------------------------
                                    638 ;Allocation info for local variables in function 'ak820_os_indicator_get'
                                    639 ;------------------------------------------------------------
                                    640 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:14: uint8_t ak820_os_indicator_get(void) {
                                    641 ;	-----------------------------------------
                                    642 ;	 function ak820_os_indicator_get
                                    643 ;	-----------------------------------------
      004426                        644 _ak820_os_indicator_get:
                                    645 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:17: if (ak820_os_indicator_mode &&
      004426 90 05 9E         [24]  646 	mov	dptr,#_ak820_os_indicator_mode
      004429 E0               [24]  647 	movx	a,@dptr
      00442A 60 37            [24]  648 	jz	00102$
                                    649 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:18: (vial_unlock_in_progress || timer_elapsed32(os_indicator_refreshed) >= AK820_OS_INDICATOR_LEASE_MS))
      00442C 90 0E 2A         [24]  650 	mov	dptr,#_vial_unlock_in_progress
      00442F E0               [24]  651 	movx	a,@dptr
      004430 70 2C            [24]  652 	jnz	00101$
      004432 90 05 9F         [24]  653 	mov	dptr,#_os_indicator_refreshed
      004435 E0               [24]  654 	movx	a,@dptr
      004436 FC               [12]  655 	mov	r4,a
      004437 A3               [24]  656 	inc	dptr
      004438 E0               [24]  657 	movx	a,@dptr
      004439 FD               [12]  658 	mov	r5,a
      00443A A3               [24]  659 	inc	dptr
      00443B E0               [24]  660 	movx	a,@dptr
      00443C FE               [12]  661 	mov	r6,a
      00443D A3               [24]  662 	inc	dptr
      00443E E0               [24]  663 	movx	a,@dptr
      00443F 8C 82            [24]  664 	mov	dpl,r4
      004441 8D 83            [24]  665 	mov	dph,r5
      004443 8E F0            [24]  666 	mov	b,r6
      004445 12 4A AE         [24]  667 	lcall	_timer_elapsed32
      004448 AC 82            [24]  668 	mov	r4, dpl
      00444A AD 83            [24]  669 	mov	r5, dph
      00444C AE F0            [24]  670 	mov	r6, b
      00444E FF               [12]  671 	mov	r7, a
      00444F C3               [12]  672 	clr	c
      004450 EC               [12]  673 	mov	a,r4
      004451 94 B8            [12]  674 	subb	a,#0xb8
      004453 ED               [12]  675 	mov	a,r5
      004454 94 0B            [12]  676 	subb	a,#0x0b
      004456 EE               [12]  677 	mov	a,r6
      004457 94 00            [12]  678 	subb	a,#0x00
      004459 EF               [12]  679 	mov	a,r7
      00445A 94 00            [12]  680 	subb	a,#0x00
      00445C 40 05            [24]  681 	jc	00102$
      00445E                        682 00101$:
                                    683 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:19: ak820_os_indicator_mode = AK820_OS_NORMAL;
      00445E 90 05 9E         [24]  684 	mov	dptr,#_ak820_os_indicator_mode
      004461 E4               [12]  685 	clr	a
      004462 F0               [24]  686 	movx	@dptr,a
      004463                        687 00102$:
                                    688 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:20: return ak820_os_indicator_mode;
      004463 90 05 9E         [24]  689 	mov	dptr,#_ak820_os_indicator_mode
      004466 E0               [24]  690 	movx	a,@dptr
                                    691 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:21: }
      004467 F5 82            [12]  692 	mov	dpl,a
      004469 22               [24]  693 	ret
                                    694 ;------------------------------------------------------------
                                    695 ;Allocation info for local variables in function 'ak820_os_indicator_value'
                                    696 ;------------------------------------------------------------
                                    697 ;normal        Allocated with name '_ak820_os_indicator_value_normal_10000_182'
                                    698 ;phase         Allocated with name '_ak820_os_indicator_value_phase_10000_183'
                                    699 ;------------------------------------------------------------
                                    700 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:23: uint8_t ak820_os_indicator_value(uint8_t normal) {
                                    701 ;	-----------------------------------------
                                    702 ;	 function ak820_os_indicator_value
                                    703 ;	-----------------------------------------
      00446A                        704 _ak820_os_indicator_value:
      00446A E5 82            [12]  705 	mov	a,dpl
      00446C 90 05 A4         [24]  706 	mov	dptr,#_ak820_os_indicator_value_normal_10000_182
      00446F F0               [24]  707 	movx	@dptr,a
                                    708 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:25: switch (ak820_os_indicator_get()) {
      004470 12 44 26         [24]  709 	lcall	_ak820_os_indicator_get
      004473 AF 82            [24]  710 	mov	r7, dpl
      004475 BF 01 02         [24]  711 	cjne	r7,#0x01,00138$
      004478 80 0A            [24]  712 	sjmp	00101$
      00447A                        713 00138$:
      00447A BF 02 02         [24]  714 	cjne	r7,#0x02,00139$
      00447D 80 09            [24]  715 	sjmp	00102$
      00447F                        716 00139$:
                                    717 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:26: case AK820_OS_OFF: return 0;
      00447F BF 03 36         [24]  718 	cjne	r7,#0x03,00106$
      004482 80 08            [24]  719 	sjmp	00103$
      004484                        720 00101$:
      004484 75 82 00         [24]  721 	mov	dpl, #0x00
                                    722 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:27: case AK820_OS_ON: return 255;
      004487 22               [24]  723 	ret
      004488                        724 00102$:
      004488 75 82 FF         [24]  725 	mov	dpl, #0xff
                                    726 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:28: case AK820_OS_BREATHE:
      00448B 22               [24]  727 	ret
      00448C                        728 00103$:
                                    729 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:30: phase = (uint8_t)(timer_read() >> 4);
      00448C 12 4A 86         [24]  730 	lcall	_timer_read
      00448F AE 82            [24]  731 	mov	r6, dpl
      004491 E5 83            [12]  732 	mov	a,dph
      004493 C4               [12]  733 	swap	a
      004494 CE               [12]  734 	xch	a,r6
      004495 C4               [12]  735 	swap	a
      004496 54 0F            [12]  736 	anl	a,#0x0f
      004498 6E               [12]  737 	xrl	a,r6
      004499 CE               [12]  738 	xch	a,r6
      00449A 54 0F            [12]  739 	anl	a,#0x0f
      00449C CE               [12]  740 	xch	a,r6
      00449D 6E               [12]  741 	xrl	a,r6
      00449E CE               [12]  742 	xch	a,r6
      00449F 90 05 A5         [24]  743 	mov	dptr,#_ak820_os_indicator_value_phase_10000_183
      0044A2 EE               [12]  744 	mov	a,r6
      0044A3 F0               [24]  745 	movx	@dptr,a
                                    746 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:31: if (phase & 0x80) phase = (uint8_t)~phase;
      0044A4 EE               [12]  747 	mov	a,r6
      0044A5 30 E7 07         [24]  748 	jnb	acc.7,00105$
      0044A8 90 05 A5         [24]  749 	mov	dptr,#_ak820_os_indicator_value_phase_10000_183
      0044AB 74 FF            [12]  750 	mov	a,#0xff
      0044AD 6E               [12]  751 	xrl	a,r6
      0044AE F0               [24]  752 	movx	@dptr,a
      0044AF                        753 00105$:
                                    754 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:32: return (uint8_t)(phase << 1);
      0044AF 90 05 A5         [24]  755 	mov	dptr,#_ak820_os_indicator_value_phase_10000_183
      0044B2 E0               [24]  756 	movx	a,@dptr
      0044B3 25 E0            [12]  757 	add	a,acc
      0044B5 F5 82            [12]  758 	mov	dpl,a
                                    759 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:33: default: return normal;
      0044B7 22               [24]  760 	ret
      0044B8                        761 00106$:
      0044B8 90 05 A4         [24]  762 	mov	dptr,#_ak820_os_indicator_value_normal_10000_182
      0044BB E0               [24]  763 	movx	a,@dptr
                                    764 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:34: }
                                    765 ;	keyboards/ajazz/ak820/ak820_os_indicators.c:35: }
      0044BC F5 82            [12]  766 	mov	dpl,a
      0044BE 22               [24]  767 	ret
                                    768 	.area CSEG    (CODE)
                                    769 	.area CONST   (CODE)
                                    770 	.area XINIT   (CODE)
                                    771 	.area CABS    (ABS,CODE)
