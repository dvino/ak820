                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_tapping_cancel
                                     14 	.globl _ak820_tapping_process
                                     15 	.globl _ak820_tapping_before
                                     16 	.globl _pre_process_record_quantum
                                     17 	.globl _repeat_key_cancel
                                     18 	.globl _clear_owned_usages
                                     19 	.globl _owned_usage_key
                                     20 	.globl _clear_owned_keys
                                     21 	.globl _del_owned_key
                                     22 	.globl _add_owned_key
                                     23 	.globl _clear_owned_mods
                                     24 	.globl _del_owned_weak_mods
                                     25 	.globl _add_owned_weak_mods
                                     26 	.globl _del_owned_mods
                                     27 	.globl _add_owned_mods
                                     28 	.globl _clear_weak_mods
                                     29 	.globl _clear_mods
                                     30 	.globl _send_keyboard_report
                                     31 	.globl _layer_hold_clear
                                     32 	.globl _layer_hold_off
                                     33 	.globl _layer_hold_on
                                     34 	.globl _ak820_resolve_key
                                     35 	.globl _layer_xor
                                     36 	.globl _layer_and
                                     37 	.globl _layer_or
                                     38 	.globl _layer_off
                                     39 	.globl _layer_on
                                     40 	.globl _layer_move
                                     41 	.globl _layer_clear
                                     42 	.globl _layer_state_set
                                     43 	.globl _default_layer_xor
                                     44 	.globl _default_layer_and
                                     45 	.globl _default_layer_or
                                     46 	.globl _default_layer_set
                                     47 	.globl _post_process_record_quantum
                                     48 	.globl _process_record_quantum
                                     49 	.globl _action_for_keycode
                                     50 	.globl _mDelaymS
                                     51 	.globl _host_consumer_send
                                     52 	.globl _host_system_send
                                     53 	.globl _host_keyboard_leds
                                     54 	.globl _led_set
                                     55 	.globl _clear_keys_from_report
                                     56 	.globl ___memcpy
                                     57 	.globl _ADC_START
                                     58 	.globl _S0_R_FIFO
                                     59 	.globl _S0_T_FIFO
                                     60 	.globl _S0_FREE
                                     61 	.globl _S0_IF_BYTE
                                     62 	.globl _S0_IF_FIRST
                                     63 	.globl _S0_IF_OV
                                     64 	.globl _S0_FST_ACT
                                     65 	.globl _CP_RL2
                                     66 	.globl _C_T2
                                     67 	.globl _TR2
                                     68 	.globl _EXEN2
                                     69 	.globl _TCLK
                                     70 	.globl _RCLK
                                     71 	.globl _EXF2
                                     72 	.globl _CAP1F
                                     73 	.globl _TF2
                                     74 	.globl _RI
                                     75 	.globl _TI
                                     76 	.globl _RB8
                                     77 	.globl _TB8
                                     78 	.globl _REN
                                     79 	.globl _SM2
                                     80 	.globl _SM1
                                     81 	.globl _SM0
                                     82 	.globl _IT0
                                     83 	.globl _IE0
                                     84 	.globl _IT1
                                     85 	.globl _IE1
                                     86 	.globl _TR0
                                     87 	.globl _TF0
                                     88 	.globl _TR1
                                     89 	.globl _TF1
                                     90 	.globl _P4_0
                                     91 	.globl _P4_1
                                     92 	.globl _P4_2
                                     93 	.globl _P4_3
                                     94 	.globl _P4_4
                                     95 	.globl _P4_5
                                     96 	.globl _P4_6
                                     97 	.globl _RXD
                                     98 	.globl _TXD
                                     99 	.globl _INT0
                                    100 	.globl _INT1
                                    101 	.globl _T0
                                    102 	.globl _T1
                                    103 	.globl _MOSI1
                                    104 	.globl _MISO1
                                    105 	.globl _SCK1
                                    106 	.globl _P3_0
                                    107 	.globl _P3_1
                                    108 	.globl _P3_2
                                    109 	.globl _P3_3
                                    110 	.globl _P3_4
                                    111 	.globl _P3_5
                                    112 	.globl _P3_6
                                    113 	.globl _P3_7
                                    114 	.globl _CAP1_
                                    115 	.globl _T2_
                                    116 	.globl _CAP2_
                                    117 	.globl _T2EX_
                                    118 	.globl _RXD1
                                    119 	.globl _TXD1
                                    120 	.globl _P2_0
                                    121 	.globl _P2_1
                                    122 	.globl _P2_2
                                    123 	.globl _P2_3
                                    124 	.globl _P2_4
                                    125 	.globl _P2_5
                                    126 	.globl _P2_6
                                    127 	.globl _P2_7
                                    128 	.globl _AIN0
                                    129 	.globl _AIN1
                                    130 	.globl _AIN2
                                    131 	.globl _AIN3
                                    132 	.globl _AIN4
                                    133 	.globl _AIN5
                                    134 	.globl _AIN6
                                    135 	.globl _AIN7
                                    136 	.globl _CAP1
                                    137 	.globl _T2
                                    138 	.globl _CAP2
                                    139 	.globl _T2EX
                                    140 	.globl _INT0_
                                    141 	.globl _SCS
                                    142 	.globl _MOSI
                                    143 	.globl _MISO
                                    144 	.globl _SCK
                                    145 	.globl _RXD1_
                                    146 	.globl _TXD1_
                                    147 	.globl _P1_0
                                    148 	.globl _P1_1
                                    149 	.globl _P1_2
                                    150 	.globl _P1_3
                                    151 	.globl _P1_4
                                    152 	.globl _P1_5
                                    153 	.globl _P1_6
                                    154 	.globl _P1_7
                                    155 	.globl _AIN8
                                    156 	.globl _AIN9
                                    157 	.globl _AIN10
                                    158 	.globl _AIN11
                                    159 	.globl _AIN12
                                    160 	.globl _AIN13
                                    161 	.globl _RXD_
                                    162 	.globl _TXD_
                                    163 	.globl _SCL0
                                    164 	.globl _SDA0
                                    165 	.globl _P0_0
                                    166 	.globl _P0_1
                                    167 	.globl _P0_2
                                    168 	.globl _P0_3
                                    169 	.globl _P0_4
                                    170 	.globl _P0_5
                                    171 	.globl _P0_6
                                    172 	.globl _P0_7
                                    173 	.globl _IE_SPI0
                                    174 	.globl _IE_USB
                                    175 	.globl _IE_ADC
                                    176 	.globl _IE_UART1
                                    177 	.globl _IE_PWM_I2C
                                    178 	.globl _IE_GPIO
                                    179 	.globl _IE_WDOG
                                    180 	.globl _PX0
                                    181 	.globl _PT0
                                    182 	.globl _PX1
                                    183 	.globl _PT1
                                    184 	.globl _PS
                                    185 	.globl _PT2
                                    186 	.globl _PL_FLAG
                                    187 	.globl _PH_FLAG
                                    188 	.globl _EX0
                                    189 	.globl _ET0
                                    190 	.globl _EX1
                                    191 	.globl _ET1
                                    192 	.globl _ES
                                    193 	.globl _ET2
                                    194 	.globl _E_DIS
                                    195 	.globl _EA
                                    196 	.globl _P
                                    197 	.globl _F1
                                    198 	.globl _OV
                                    199 	.globl _RS0
                                    200 	.globl _RS1
                                    201 	.globl _F0
                                    202 	.globl _AC
                                    203 	.globl _CY
                                    204 	.globl _I2CS_INT_ST
                                    205 	.globl _I2CX_INT
                                    206 	.globl _LED_STATUS
                                    207 	.globl _LED_DMA_H
                                    208 	.globl _LED_DMA_L
                                    209 	.globl _LED_DMA
                                    210 	.globl _LED_PWM_OE
                                    211 	.globl _LED_COMMON
                                    212 	.globl _ADC_CHAN
                                    213 	.globl _ADC_DAT_H
                                    214 	.globl _ADC_DAT_L
                                    215 	.globl _ADC_DAT
                                    216 	.globl _ADC_CTRL
                                    217 	.globl _SPI1_CK_SE
                                    218 	.globl _SPI1_CTRL
                                    219 	.globl _SPI1_DATA
                                    220 	.globl _SPI1_STAT
                                    221 	.globl _SIF1
                                    222 	.globl _SBAUD1
                                    223 	.globl _SBUF1
                                    224 	.globl _SCON1
                                    225 	.globl _SPI0_SETUP
                                    226 	.globl _SPI0_CK_SE
                                    227 	.globl _SPI0_CTRL
                                    228 	.globl _SPI0_DATA
                                    229 	.globl _SPI0_STAT
                                    230 	.globl _T2CAP1H
                                    231 	.globl _T2CAP1L
                                    232 	.globl _T2CAP1
                                    233 	.globl _TH2
                                    234 	.globl _TL2
                                    235 	.globl _T2COUNT
                                    236 	.globl _RCAP2H
                                    237 	.globl _RCAP2L
                                    238 	.globl _RCAP2
                                    239 	.globl _T2MOD
                                    240 	.globl _T2CON
                                    241 	.globl _SBUF
                                    242 	.globl _SCON
                                    243 	.globl _TH1
                                    244 	.globl _TH0
                                    245 	.globl _TL1
                                    246 	.globl _TL0
                                    247 	.globl _TMOD
                                    248 	.globl _TCON
                                    249 	.globl _XBUS_AUX
                                    250 	.globl _P7
                                    251 	.globl _P6_DIR
                                    252 	.globl _P6_OUT_PU
                                    253 	.globl _P6_IN
                                    254 	.globl _P5_DIR
                                    255 	.globl _P5_OUT_PU
                                    256 	.globl _P5_IN
                                    257 	.globl _P4_LED_KEY
                                    258 	.globl _P4_DIR_PU
                                    259 	.globl _P4_MOD_OC
                                    260 	.globl _P4
                                    261 	.globl _P3_DIR_PU
                                    262 	.globl _P3_MOD_OC
                                    263 	.globl _P3
                                    264 	.globl _P2_DIR_PU
                                    265 	.globl _P2_MOD_OC
                                    266 	.globl _P2
                                    267 	.globl _P1_DIR_PU
                                    268 	.globl _P1_MOD_OC
                                    269 	.globl _P1
                                    270 	.globl _P0_DIR_PU
                                    271 	.globl _P0_MOD_OC
                                    272 	.globl _P0
                                    273 	.globl _ROM_CTRL
                                    274 	.globl _ROM_DATA_HH
                                    275 	.globl _ROM_DATA_HL
                                    276 	.globl _ROM_DATA_HI
                                    277 	.globl _ROM_ADDR_H
                                    278 	.globl _ROM_ADDR_L
                                    279 	.globl _ROM_ADDR
                                    280 	.globl _GPIO_IE
                                    281 	.globl _IP_EX
                                    282 	.globl _IE_EX
                                    283 	.globl _IP
                                    284 	.globl _IE
                                    285 	.globl _WDOG_COUNT
                                    286 	.globl _RESET_KEEP
                                    287 	.globl _WAKE_CTRL
                                    288 	.globl _CLOCK_CFG
                                    289 	.globl _POWER_CFG
                                    290 	.globl _PCON
                                    291 	.globl _GLOBAL_CFG
                                    292 	.globl _SAFE_MOD
                                    293 	.globl _DPH
                                    294 	.globl _DPL
                                    295 	.globl _SP
                                    296 	.globl _A_INV
                                    297 	.globl _B
                                    298 	.globl _ACC
                                    299 	.globl _PSW
                                    300 	.globl _disable_action_cache
                                    301 	.globl _tap_code_delay_PARM_2
                                    302 	.globl _process_action_PARM_2
                                    303 	.globl _action_exec_PARM_1
                                    304 	.globl _tp_buttons
                                    305 	.globl _action_exec
                                    306 	.globl _ak820_action_exec
                                    307 	.globl _process_record
                                    308 	.globl _process_record_handler
                                    309 	.globl _process_action
                                    310 	.globl _register_code
                                    311 	.globl _unregister_code
                                    312 	.globl _tap_code_delay
                                    313 	.globl _tap_code
                                    314 	.globl _register_mods
                                    315 	.globl _unregister_mods
                                    316 	.globl _register_weak_mods
                                    317 	.globl _unregister_weak_mods
                                    318 	.globl _clear_keyboard
                                    319 	.globl _clear_keyboard_but_mods
                                    320 	.globl _clear_keyboard_but_mods_and_keys
                                    321 ;--------------------------------------------------------
                                    322 ; special function registers
                                    323 ;--------------------------------------------------------
                                    324 	.area RSEG    (ABS,DATA)
      000000                        325 	.org 0x0000
                           0000D0   326 _PSW	=	0x00d0
                           0000E0   327 _ACC	=	0x00e0
                           0000F0   328 _B	=	0x00f0
                           0000FD   329 _A_INV	=	0x00fd
                           000081   330 _SP	=	0x0081
                           000082   331 _DPL	=	0x0082
                           000083   332 _DPH	=	0x0083
                           0000A1   333 _SAFE_MOD	=	0x00a1
                           0000B1   334 _GLOBAL_CFG	=	0x00b1
                           000087   335 _PCON	=	0x0087
                           0000BA   336 _POWER_CFG	=	0x00ba
                           0000B9   337 _CLOCK_CFG	=	0x00b9
                           0000A9   338 _WAKE_CTRL	=	0x00a9
                           0000FE   339 _RESET_KEEP	=	0x00fe
                           0000FF   340 _WDOG_COUNT	=	0x00ff
                           0000A8   341 _IE	=	0x00a8
                           0000B8   342 _IP	=	0x00b8
                           0000E8   343 _IE_EX	=	0x00e8
                           0000E9   344 _IP_EX	=	0x00e9
                           0000B2   345 _GPIO_IE	=	0x00b2
                           008584   346 _ROM_ADDR	=	0x8584
                           000084   347 _ROM_ADDR_L	=	0x0084
                           000085   348 _ROM_ADDR_H	=	0x0085
                           008F8E   349 _ROM_DATA_HI	=	0x8f8e
                           00008E   350 _ROM_DATA_HL	=	0x008e
                           00008F   351 _ROM_DATA_HH	=	0x008f
                           000086   352 _ROM_CTRL	=	0x0086
                           000080   353 _P0	=	0x0080
                           0000C4   354 _P0_MOD_OC	=	0x00c4
                           0000C5   355 _P0_DIR_PU	=	0x00c5
                           000090   356 _P1	=	0x0090
                           000092   357 _P1_MOD_OC	=	0x0092
                           000093   358 _P1_DIR_PU	=	0x0093
                           0000A0   359 _P2	=	0x00a0
                           000094   360 _P2_MOD_OC	=	0x0094
                           000095   361 _P2_DIR_PU	=	0x0095
                           0000B0   362 _P3	=	0x00b0
                           000096   363 _P3_MOD_OC	=	0x0096
                           000097   364 _P3_DIR_PU	=	0x0097
                           0000C0   365 _P4	=	0x00c0
                           0000C2   366 _P4_MOD_OC	=	0x00c2
                           0000C3   367 _P4_DIR_PU	=	0x00c3
                           0000C1   368 _P4_LED_KEY	=	0x00c1
                           0000AA   369 _P5_IN	=	0x00aa
                           0000AB   370 _P5_OUT_PU	=	0x00ab
                           0000AC   371 _P5_DIR	=	0x00ac
                           0000AD   372 _P6_IN	=	0x00ad
                           0000AE   373 _P6_OUT_PU	=	0x00ae
                           0000AF   374 _P6_DIR	=	0x00af
                           0000F1   375 _P7	=	0x00f1
                           0000A2   376 _XBUS_AUX	=	0x00a2
                           000088   377 _TCON	=	0x0088
                           000089   378 _TMOD	=	0x0089
                           00008A   379 _TL0	=	0x008a
                           00008B   380 _TL1	=	0x008b
                           00008C   381 _TH0	=	0x008c
                           00008D   382 _TH1	=	0x008d
                           000098   383 _SCON	=	0x0098
                           000099   384 _SBUF	=	0x0099
                           0000C8   385 _T2CON	=	0x00c8
                           0000C9   386 _T2MOD	=	0x00c9
                           00CBCA   387 _RCAP2	=	0xcbca
                           0000CA   388 _RCAP2L	=	0x00ca
                           0000CB   389 _RCAP2H	=	0x00cb
                           00CDCC   390 _T2COUNT	=	0xcdcc
                           0000CC   391 _TL2	=	0x00cc
                           0000CD   392 _TH2	=	0x00cd
                           00CFCE   393 _T2CAP1	=	0xcfce
                           0000CE   394 _T2CAP1L	=	0x00ce
                           0000CF   395 _T2CAP1H	=	0x00cf
                           0000F8   396 _SPI0_STAT	=	0x00f8
                           0000F9   397 _SPI0_DATA	=	0x00f9
                           0000FA   398 _SPI0_CTRL	=	0x00fa
                           0000FB   399 _SPI0_CK_SE	=	0x00fb
                           0000FC   400 _SPI0_SETUP	=	0x00fc
                           0000BC   401 _SCON1	=	0x00bc
                           0000BD   402 _SBUF1	=	0x00bd
                           0000BE   403 _SBAUD1	=	0x00be
                           0000BF   404 _SIF1	=	0x00bf
                           0000B4   405 _SPI1_STAT	=	0x00b4
                           0000B5   406 _SPI1_DATA	=	0x00b5
                           0000B6   407 _SPI1_CTRL	=	0x00b6
                           0000B7   408 _SPI1_CK_SE	=	0x00b7
                           0000F3   409 _ADC_CTRL	=	0x00f3
                           00F5F4   410 _ADC_DAT	=	0xf5f4
                           0000F4   411 _ADC_DAT_L	=	0x00f4
                           0000F5   412 _ADC_DAT_H	=	0x00f5
                           0000F6   413 _ADC_CHAN	=	0x00f6
                           0000A6   414 _LED_COMMON	=	0x00a6
                           0000A7   415 _LED_PWM_OE	=	0x00a7
                           00C7C6   416 _LED_DMA	=	0xc7c6
                           0000C6   417 _LED_DMA_L	=	0x00c6
                           0000C7   418 _LED_DMA_H	=	0x00c7
                           0000F7   419 _LED_STATUS	=	0x00f7
                           0000B3   420 _I2CX_INT	=	0x00b3
                           0000BB   421 _I2CS_INT_ST	=	0x00bb
                                    422 ;--------------------------------------------------------
                                    423 ; special function bits
                                    424 ;--------------------------------------------------------
                                    425 	.area RSEG    (ABS,DATA)
      000000                        426 	.org 0x0000
                           0000D7   427 _CY	=	0x00d7
                           0000D6   428 _AC	=	0x00d6
                           0000D5   429 _F0	=	0x00d5
                           0000D4   430 _RS1	=	0x00d4
                           0000D3   431 _RS0	=	0x00d3
                           0000D2   432 _OV	=	0x00d2
                           0000D1   433 _F1	=	0x00d1
                           0000D0   434 _P	=	0x00d0
                           0000AF   435 _EA	=	0x00af
                           0000AE   436 _E_DIS	=	0x00ae
                           0000AD   437 _ET2	=	0x00ad
                           0000AC   438 _ES	=	0x00ac
                           0000AB   439 _ET1	=	0x00ab
                           0000AA   440 _EX1	=	0x00aa
                           0000A9   441 _ET0	=	0x00a9
                           0000A8   442 _EX0	=	0x00a8
                           0000BF   443 _PH_FLAG	=	0x00bf
                           0000BE   444 _PL_FLAG	=	0x00be
                           0000BD   445 _PT2	=	0x00bd
                           0000BC   446 _PS	=	0x00bc
                           0000BB   447 _PT1	=	0x00bb
                           0000BA   448 _PX1	=	0x00ba
                           0000B9   449 _PT0	=	0x00b9
                           0000B8   450 _PX0	=	0x00b8
                           0000EF   451 _IE_WDOG	=	0x00ef
                           0000EE   452 _IE_GPIO	=	0x00ee
                           0000ED   453 _IE_PWM_I2C	=	0x00ed
                           0000EC   454 _IE_UART1	=	0x00ec
                           0000EB   455 _IE_ADC	=	0x00eb
                           0000E9   456 _IE_USB	=	0x00e9
                           0000E8   457 _IE_SPI0	=	0x00e8
                           000087   458 _P0_7	=	0x0087
                           000086   459 _P0_6	=	0x0086
                           000085   460 _P0_5	=	0x0085
                           000084   461 _P0_4	=	0x0084
                           000083   462 _P0_3	=	0x0083
                           000082   463 _P0_2	=	0x0082
                           000081   464 _P0_1	=	0x0081
                           000080   465 _P0_0	=	0x0080
                           000081   466 _SDA0	=	0x0081
                           000080   467 _SCL0	=	0x0080
                           000083   468 _TXD_	=	0x0083
                           000082   469 _RXD_	=	0x0082
                           000085   470 _AIN13	=	0x0085
                           000084   471 _AIN12	=	0x0084
                           000083   472 _AIN11	=	0x0083
                           000082   473 _AIN10	=	0x0082
                           000081   474 _AIN9	=	0x0081
                           000080   475 _AIN8	=	0x0080
                           000097   476 _P1_7	=	0x0097
                           000096   477 _P1_6	=	0x0096
                           000095   478 _P1_5	=	0x0095
                           000094   479 _P1_4	=	0x0094
                           000093   480 _P1_3	=	0x0093
                           000092   481 _P1_2	=	0x0092
                           000091   482 _P1_1	=	0x0091
                           000090   483 _P1_0	=	0x0090
                           000097   484 _TXD1_	=	0x0097
                           000096   485 _RXD1_	=	0x0096
                           000097   486 _SCK	=	0x0097
                           000096   487 _MISO	=	0x0096
                           000095   488 _MOSI	=	0x0095
                           000094   489 _SCS	=	0x0094
                           000092   490 _INT0_	=	0x0092
                           000091   491 _T2EX	=	0x0091
                           000091   492 _CAP2	=	0x0091
                           000090   493 _T2	=	0x0090
                           000090   494 _CAP1	=	0x0090
                           000097   495 _AIN7	=	0x0097
                           000096   496 _AIN6	=	0x0096
                           000095   497 _AIN5	=	0x0095
                           000094   498 _AIN4	=	0x0094
                           000093   499 _AIN3	=	0x0093
                           000092   500 _AIN2	=	0x0092
                           000091   501 _AIN1	=	0x0091
                           000090   502 _AIN0	=	0x0090
                           0000A7   503 _P2_7	=	0x00a7
                           0000A6   504 _P2_6	=	0x00a6
                           0000A5   505 _P2_5	=	0x00a5
                           0000A4   506 _P2_4	=	0x00a4
                           0000A3   507 _P2_3	=	0x00a3
                           0000A2   508 _P2_2	=	0x00a2
                           0000A1   509 _P2_1	=	0x00a1
                           0000A0   510 _P2_0	=	0x00a0
                           0000A7   511 _TXD1	=	0x00a7
                           0000A6   512 _RXD1	=	0x00a6
                           0000A5   513 _T2EX_	=	0x00a5
                           0000A5   514 _CAP2_	=	0x00a5
                           0000A4   515 _T2_	=	0x00a4
                           0000A4   516 _CAP1_	=	0x00a4
                           0000B7   517 _P3_7	=	0x00b7
                           0000B6   518 _P3_6	=	0x00b6
                           0000B5   519 _P3_5	=	0x00b5
                           0000B4   520 _P3_4	=	0x00b4
                           0000B3   521 _P3_3	=	0x00b3
                           0000B2   522 _P3_2	=	0x00b2
                           0000B1   523 _P3_1	=	0x00b1
                           0000B0   524 _P3_0	=	0x00b0
                           0000B7   525 _SCK1	=	0x00b7
                           0000B6   526 _MISO1	=	0x00b6
                           0000B5   527 _MOSI1	=	0x00b5
                           0000B5   528 _T1	=	0x00b5
                           0000B4   529 _T0	=	0x00b4
                           0000B3   530 _INT1	=	0x00b3
                           0000B2   531 _INT0	=	0x00b2
                           0000B1   532 _TXD	=	0x00b1
                           0000B0   533 _RXD	=	0x00b0
                           0000C6   534 _P4_6	=	0x00c6
                           0000C5   535 _P4_5	=	0x00c5
                           0000C4   536 _P4_4	=	0x00c4
                           0000C3   537 _P4_3	=	0x00c3
                           0000C2   538 _P4_2	=	0x00c2
                           0000C1   539 _P4_1	=	0x00c1
                           0000C0   540 _P4_0	=	0x00c0
                           00008F   541 _TF1	=	0x008f
                           00008E   542 _TR1	=	0x008e
                           00008D   543 _TF0	=	0x008d
                           00008C   544 _TR0	=	0x008c
                           00008B   545 _IE1	=	0x008b
                           00008A   546 _IT1	=	0x008a
                           000089   547 _IE0	=	0x0089
                           000088   548 _IT0	=	0x0088
                           00009F   549 _SM0	=	0x009f
                           00009E   550 _SM1	=	0x009e
                           00009D   551 _SM2	=	0x009d
                           00009C   552 _REN	=	0x009c
                           00009B   553 _TB8	=	0x009b
                           00009A   554 _RB8	=	0x009a
                           000099   555 _TI	=	0x0099
                           000098   556 _RI	=	0x0098
                           0000CF   557 _TF2	=	0x00cf
                           0000CF   558 _CAP1F	=	0x00cf
                           0000CE   559 _EXF2	=	0x00ce
                           0000CD   560 _RCLK	=	0x00cd
                           0000CC   561 _TCLK	=	0x00cc
                           0000CB   562 _EXEN2	=	0x00cb
                           0000CA   563 _TR2	=	0x00ca
                           0000C9   564 _C_T2	=	0x00c9
                           0000C8   565 _CP_RL2	=	0x00c8
                           0000FF   566 _S0_FST_ACT	=	0x00ff
                           0000FE   567 _S0_IF_OV	=	0x00fe
                           0000FD   568 _S0_IF_FIRST	=	0x00fd
                           0000FC   569 _S0_IF_BYTE	=	0x00fc
                           0000FB   570 _S0_FREE	=	0x00fb
                           0000FA   571 _S0_T_FIFO	=	0x00fa
                           0000F8   572 _S0_R_FIFO	=	0x00f8
                           0000F7   573 _ADC_START	=	0x00f7
                                    574 ;--------------------------------------------------------
                                    575 ; overlayable register banks
                                    576 ;--------------------------------------------------------
                                    577 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        578 	.ds 8
                                    579 ;--------------------------------------------------------
                                    580 ; internal ram data
                                    581 ;--------------------------------------------------------
                                    582 	.area DSEG    (DATA)
      000027                        583 _process_action_sloc0_1_0:
      000027                        584 	.ds 1
                                    585 ;--------------------------------------------------------
                                    586 ; overlayable items in internal ram
                                    587 ;--------------------------------------------------------
                                    588 ;--------------------------------------------------------
                                    589 ; indirectly addressable internal ram data
                                    590 ;--------------------------------------------------------
                                    591 	.area ISEG    (DATA)
                                    592 ;--------------------------------------------------------
                                    593 ; absolute internal ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area IABS    (ABS,DATA)
                                    596 	.area IABS    (ABS,DATA)
                                    597 ;--------------------------------------------------------
                                    598 ; bit data
                                    599 ;--------------------------------------------------------
                                    600 	.area BSEG    (BIT)
      00001F                        601 _process_action_sloc1_1_0:
      00001F                        602 	.ds 1
                                    603 ;--------------------------------------------------------
                                    604 ; paged external ram data
                                    605 ;--------------------------------------------------------
                                    606 	.area PSEG    (PAG,XDATA)
                                    607 ;--------------------------------------------------------
                                    608 ; uninitialized external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XSEG    (XDATA)
      000805                        611 _tp_buttons::
      000805                        612 	.ds 2
      000807                        613 _action_exec_PARM_1:
      000807                        614 	.ds 6
      00080D                        615 _action_exec_record_10001_620:
      00080D                        616 	.ds 9
      000816                        617 _ak820_action_exec_event_10000_624:
      000816                        618 	.ds 2
      000818                        619 _ak820_action_exec_snapshot_10000_625:
      000818                        620 	.ds 6
      00081E                        621 _process_record_record_10000_628:
      00081E                        622 	.ds 3
      000821                        623 _process_record_handler_record_argument_10000_634:
      000821                        624 	.ds 3
      000824                        625 _process_record_handler_action_10000_635:
      000824                        626 	.ds 2
      000826                        627 _process_action_PARM_2:
      000826                        628 	.ds 2
      000828                        629 _process_action_record_argument_10000_646:
      000828                        630 	.ds 3
      00082B                        631 _process_action_on_40000_669:
      00082B                        632 	.ds 1
      00082C                        633 _register_code_code_10000_703:
      00082C                        634 	.ds 1
      00082D                        635 _unregister_code_code_10000_717:
      00082D                        636 	.ds 1
      00082E                        637 _tap_code_delay_PARM_2:
      00082E                        638 	.ds 2
      000830                        639 _tap_code_delay_code_10000_730:
      000830                        640 	.ds 1
      000831                        641 _tap_code_code_10000_737:
      000831                        642 	.ds 1
      000832                        643 _register_mods_mods_10000_739:
      000832                        644 	.ds 1
      000833                        645 _unregister_mods_mods_10000_743:
      000833                        646 	.ds 1
      000834                        647 _register_weak_mods_mods_10000_747:
      000834                        648 	.ds 1
      000835                        649 _unregister_weak_mods_mods_10000_751:
      000835                        650 	.ds 1
                                    651 ;--------------------------------------------------------
                                    652 ; absolute external ram data
                                    653 ;--------------------------------------------------------
                                    654 	.area XABS    (ABS,XDATA)
                                    655 ;--------------------------------------------------------
                                    656 ; initialized external ram data
                                    657 ;--------------------------------------------------------
                                    658 	.area XISEG   (XDATA)
      000DAE                        659 _disable_action_cache::
      000DAE                        660 	.ds 1
                                    661 	.area HOME    (CODE)
                                    662 	.area GSINIT0 (CODE)
                                    663 	.area GSINIT1 (CODE)
                                    664 	.area GSINIT2 (CODE)
                                    665 	.area GSINIT3 (CODE)
                                    666 	.area GSINIT4 (CODE)
                                    667 	.area GSINIT5 (CODE)
                                    668 	.area GSINIT  (CODE)
                                    669 	.area GSFINAL (CODE)
                                    670 	.area CSEG    (CODE)
                                    671 ;--------------------------------------------------------
                                    672 ; global & static initialisations
                                    673 ;--------------------------------------------------------
                                    674 	.area HOME    (CODE)
                                    675 	.area GSINIT  (CODE)
                                    676 	.area GSFINAL (CODE)
                                    677 	.area GSINIT  (CODE)
                                    678 ;--------------------------------------------------------
                                    679 ; Home
                                    680 ;--------------------------------------------------------
                                    681 	.area HOME    (CODE)
                                    682 	.area HOME    (CODE)
                                    683 ;--------------------------------------------------------
                                    684 ; code
                                    685 ;--------------------------------------------------------
                                    686 	.area CSEG    (CODE)
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    689 ;------------------------------------------------------------
                                    690 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    691 ;------------------------------------------------------------
                                    692 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    693 ;	-----------------------------------------
                           000007   694 	ar7 = 0x07
                           000006   695 	ar6 = 0x06
                           000005   696 	ar5 = 0x05
                           000004   697 	ar4 = 0x04
                           000003   698 	ar3 = 0x03
                           000002   699 	ar2 = 0x02
                           000001   700 	ar1 = 0x01
                           000000   701 	ar0 = 0x00
                                    702 ;	 function action_exec
                                    703 ;	-----------------------------------------
      006EA2                        704 _action_exec:
                                    705 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      006EA2 90 08 09         [24]  706 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      006EA5 12 37 F5         [24]  707 	lcall	_ak820_outline_0005
      006EA8 12 36 04         [24]  708 	lcall	_ak820_combo_tick
                                    709 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      006EAB 90 08 07         [24]  710 	mov	dptr,#_action_exec_PARM_1
      006EAE 12 44 4D         [24]  711 	lcall	_ak820_tapping_before
      006EB1 E5 82            [12]  712 	mov	a, dpl
      006EB3 70 01            [24]  713 	jnz	00102$
      006EB5 22               [24]  714 	ret
      006EB6                        715 00102$:
                                    716 ;	quantum/action.c:116: if (event.pressed) {
      006EB6 90 08 0C         [24]  717 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      006EB9 E0               [24]  718 	movx	a,@dptr
      006EBA 60 03            [24]  719 	jz	00104$
                                    720 ;	quantum/action.c:118: clear_weak_mods();
      006EBC 12 7E 20         [24]  721 	lcall	_clear_weak_mods
      006EBF                        722 00104$:
                                    723 ;	quantum/action.c:130: record.event = event;
      006EBF 90 0D 8F         [24]  724 	mov	dptr,#___memcpy_PARM_2
      006EC2 74 07            [12]  725 	mov	a,#_action_exec_PARM_1
      006EC4 F0               [24]  726 	movx	@dptr,a
      006EC5 74 08            [12]  727 	mov	a,#(_action_exec_PARM_1 >> 8)
      006EC7 12 38 6B         [24]  728 	lcall	_ak820_outline_0089
      006ECA 12 74 A2         [24]  729 	lcall	_ak820_outline_0069
      006ECD 90 08 0D         [24]  730 	mov	dptr,#_action_exec_record_10001_620
      006ED0 F5 F0            [12]  731 	mov	b,a
      006ED2 12 B4 F5         [24]  732 	lcall	___memcpy
                                    733 ;	quantum/action.c:132: record.tap.count = 0;
      006ED5 90 08 13         [24]  734 	mov	dptr,#(_action_exec_record_10001_620 + 0x0006)
      006ED8 E0               [24]  735 	movx	a,@dptr
      006ED9 54 0F            [12]  736 	anl	a,#0x0f
      006EDB F0               [24]  737 	movx	@dptr,a
                                    738 ;	quantum/action.c:137: record.keycode = 0;
      006EDC 90 08 14         [24]  739 	mov	dptr,#(_action_exec_record_10001_620 + 0x0007)
      006EDF 12 4D E7         [24]  740 	lcall	_ak820_outline_0163
                                    741 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      006EE2 90 08 11         [24]  742 	mov	dptr,#(_action_exec_record_10001_620 + 0x0004)
      006EE5 E0               [24]  743 	movx	a,@dptr
      006EE6 60 0D            [24]  744 	jz	00107$
      006EE8 90 08 0D         [24]  745 	mov	dptr,#_action_exec_record_10001_620
      006EEB 75 F0 00         [24]  746 	mov	b, #0x00
      006EEE 12 9C 24         [24]  747 	lcall	_pre_process_record_quantum
      006EF1 E5 82            [12]  748 	mov	a, dpl
      006EF3 60 14            [24]  749 	jz	00110$
      006EF5                        750 00107$:
                                    751 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      006EF5 90 08 0D         [24]  752 	mov	dptr,#_action_exec_record_10001_620
      006EF8 12 45 3B         [24]  753 	lcall	_ak820_tapping_process
      006EFB E5 82            [12]  754 	mov	a, dpl
      006EFD 70 01            [24]  755 	jnz	00106$
      006EFF 22               [24]  756 	ret
      006F00                        757 00106$:
                                    758 ;	quantum/action.c:175: process_record(&record);
      006F00 90 08 0D         [24]  759 	mov	dptr,#_action_exec_record_10001_620
      006F03 75 F0 00         [24]  760 	mov	b, #0x00
                                    761 ;	quantum/action.c:190: }
      006F06 02 6F 46         [24]  762 	ljmp	_process_record
      006F09                        763 00110$:
      006F09 22               [24]  764 	ret
                                    765 ;------------------------------------------------------------
                                    766 ;Allocation info for local variables in function 'ak820_action_exec'
                                    767 ;------------------------------------------------------------
                                    768 ;event         Allocated with name '_ak820_action_exec_event_10000_624'
                                    769 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_625'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function ak820_action_exec
                                    774 ;	-----------------------------------------
      006F0A                        775 _ak820_action_exec:
      006F0A 12 38 7D         [24]  776 	lcall	_ak820_outline_0103
      006F0D 90 08 16         [24]  777 	mov	dptr,#_ak820_action_exec_event_10000_624
      006F10 12 38 82         [24]  778 	lcall	_ak820_outline_0104
                                    779 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      006F13 90 08 16         [24]  780 	mov	dptr,#_ak820_action_exec_event_10000_624
      006F16 12 38 71         [24]  781 	lcall	_ak820_outline_0092
      006F19 7F 00            [12]  782 	mov	r7,#0x00
      006F1B 90 0D 8F         [24]  783 	mov	dptr,#___memcpy_PARM_2
      006F1E ED               [12]  784 	mov	a,r5
      006F1F 12 38 2A         [24]  785 	lcall	_ak820_outline_0016
      006F22 12 74 A2         [24]  786 	lcall	_ak820_outline_0069
      006F25 90 08 18         [24]  787 	mov	dptr,#_ak820_action_exec_snapshot_10000_625
      006F28 F5 F0            [12]  788 	mov	b,a
      006F2A 12 B4 F5         [24]  789 	lcall	___memcpy
                                    790 ;	quantum/action.c:197: action_exec(snapshot);
      006F2D 90 0D 8F         [24]  791 	mov	dptr,#___memcpy_PARM_2
      006F30 74 18            [12]  792 	mov	a,#_ak820_action_exec_snapshot_10000_625
      006F32 F0               [24]  793 	movx	@dptr,a
      006F33 74 08            [12]  794 	mov	a,#(_ak820_action_exec_snapshot_10000_625 >> 8)
      006F35 12 38 6B         [24]  795 	lcall	_ak820_outline_0089
      006F38 12 74 A2         [24]  796 	lcall	_ak820_outline_0069
      006F3B 90 08 07         [24]  797 	mov	dptr,#_action_exec_PARM_1
      006F3E F5 F0            [12]  798 	mov	b,a
      006F40 12 B4 F5         [24]  799 	lcall	___memcpy
                                    800 ;	quantum/action.c:198: }
      006F43 02 6E A2         [24]  801 	ljmp	_action_exec
                                    802 ;------------------------------------------------------------
                                    803 ;Allocation info for local variables in function 'process_record_nocache'
                                    804 ;------------------------------------------------------------
                                    805 ;record        Allocated with name '_process_record_nocache_record_10000_626'
                                    806 ;------------------------------------------------------------
                                    807 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    808 ;	-----------------------------------------
                                    809 ;	 function process_record
                                    810 ;	-----------------------------------------
      006F46                        811 _process_record:
      006F46 12 43 0E         [24]  812 	lcall	_ak820_outline_0036
      006F49 90 08 1E         [24]  813 	mov	dptr,#_process_record_record_10000_628
      006F4C 12 38 2A         [24]  814 	lcall	_ak820_outline_0016
                                    815 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      006F4F 90 08 1E         [24]  816 	mov	dptr,#_process_record_record_10000_628
      006F52 12 4D 9B         [24]  817 	lcall	_ak820_outline_0012
      006F55 74 04            [12]  818 	mov	a,#0x04
      006F57 12 74 75         [24]  819 	lcall	_ak820_outline_0011
      006F5A 12 B5 CE         [24]  820 	lcall	__gptrget
      006F5D 70 01            [24]  821 	jnz	00102$
                                    822 ;	quantum/action.c:338: return;
      006F5F 22               [24]  823 	ret
      006F60                        824 00102$:
                                    825 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      006F60 12 6C 05         [24]  826 	lcall	_ak820_outline_0046
      006F63 C0 07            [24]  827 	push	ar7
      006F65 C0 06            [24]  828 	push	ar6
      006F67 C0 05            [24]  829 	push	ar5
      006F69 12 9C B0         [24]  830 	lcall	_process_record_quantum
      006F6C E5 82            [12]  831 	mov	a, dpl
      006F6E D0 05            [24]  832 	pop	ar5
      006F70 D0 06            [24]  833 	pop	ar6
      006F72 D0 07            [24]  834 	pop	ar7
      006F74 70 01            [24]  835 	jnz	00104$
                                    836 ;	quantum/action.c:360: return;
      006F76 22               [24]  837 	ret
      006F77                        838 00104$:
                                    839 ;	quantum/action.c:366: process_record_handler(record);
      006F77 12 6C 05         [24]  840 	lcall	_ak820_outline_0046
      006F7A 12 6F 86         [24]  841 	lcall	_process_record_handler
                                    842 ;	quantum/action.c:370: post_process_record_quantum(record);
      006F7D 90 08 1E         [24]  843 	mov	dptr,#_process_record_record_10000_628
      006F80 12 4D 75         [24]  844 	lcall	_ak820_outline_0001
                                    845 ;	quantum/action.c:374: }
      006F83 02 9C 85         [24]  846 	ljmp	_post_process_record_quantum
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'process_record_handler'
                                    849 ;------------------------------------------------------------
                                    850 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_634'
                                    851 ;record        Allocated with name '_process_record_handler_record_10000_635'
                                    852 ;action        Allocated with name '_process_record_handler_action_10000_635'
                                    853 ;------------------------------------------------------------
                                    854 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                    855 ;	-----------------------------------------
                                    856 ;	 function process_record_handler
                                    857 ;	-----------------------------------------
      006F86                        858 _process_record_handler:
      006F86 12 43 0E         [24]  859 	lcall	_ak820_outline_0036
      006F89 90 08 21         [24]  860 	mov	dptr,#_process_record_handler_record_argument_10000_634
      006F8C 12 38 2A         [24]  861 	lcall	_ak820_outline_0016
                                    862 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      006F8F 90 08 21         [24]  863 	mov	dptr,#_process_record_handler_record_argument_10000_634
      006F92 12 37 FF         [24]  864 	lcall	_ak820_outline_0007
                                    865 ;	quantum/action.c:387: if (record->keycode) {
      006F95 4C               [12]  866 	orl	a,r4
      006F96 60 19            [24]  867 	jz	00102$
                                    868 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      006F98 12 38 92         [24]  869 	lcall	_ak820_outline_0119
      006F9B C0 07            [24]  870 	push	ar7
      006F9D C0 06            [24]  871 	push	ar6
      006F9F 12 92 11         [24]  872 	lcall	_action_for_keycode
      006FA2 12 43 67         [24]  873 	lcall	_ak820_outline_0143
      006FA5 D0 06            [24]  874 	pop	ar6
      006FA7 D0 07            [24]  875 	pop	ar7
      006FA9 90 08 24         [24]  876 	mov	dptr,#_process_record_handler_action_10000_635
      006FAC 12 38 5F         [24]  877 	lcall	_ak820_outline_0071
      006FAF 80 2B            [24]  878 	sjmp	00104$
      006FB1                        879 00102$:
                                    880 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      006FB1 12 74 83         [24]  881 	lcall	_ak820_outline_0019
      006FB4 7A 00            [12]  882 	mov	r2,#0x00
      006FB6 12 43 61         [24]  883 	lcall	_ak820_outline_0136
      006FB9 12 42 FC         [24]  884 	lcall	_ak820_outline_0010
      006FBC E0               [24]  885 	movx	a,@dptr
      006FBD 90 09 60         [24]  886 	mov	dptr,#_ak820_resolve_key_PARM_2
      006FC0 F0               [24]  887 	movx	@dptr,a
      006FC1 8D 82            [24]  888 	mov	dpl, r5
      006FC3 8C 83            [24]  889 	mov	dph, r4
      006FC5 C0 07            [24]  890 	push	ar7
      006FC7 C0 06            [24]  891 	push	ar6
      006FC9 12 78 1B         [24]  892 	lcall	_ak820_resolve_key
      006FCC 12 92 11         [24]  893 	lcall	_action_for_keycode
      006FCF 12 43 67         [24]  894 	lcall	_ak820_outline_0143
      006FD2 D0 06            [24]  895 	pop	ar6
      006FD4 D0 07            [24]  896 	pop	ar7
      006FD6 90 08 24         [24]  897 	mov	dptr,#_process_record_handler_action_10000_635
      006FD9 12 38 5F         [24]  898 	lcall	_ak820_outline_0071
                                    899 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      006FDC                        900 00104$:
                                    901 ;	quantum/action.c:411: process_action(record, action);
      006FDC 7D 00            [12]  902 	mov	r5,#0x00
      006FDE 90 0D 8F         [24]  903 	mov	dptr,#___memcpy_PARM_2
      006FE1 74 24            [12]  904 	mov	a,#_process_record_handler_action_10000_635
      006FE3 F0               [24]  905 	movx	@dptr,a
      006FE4 74 08            [12]  906 	mov	a,#(_process_record_handler_action_10000_635 >> 8)
      006FE6 12 38 6B         [24]  907 	lcall	_ak820_outline_0089
      006FE9 90 0D 92         [24]  908 	mov	dptr,#___memcpy_PARM_3
      006FEC 74 02            [12]  909 	mov	a,#0x02
      006FEE 12 38 97         [24]  910 	lcall	_ak820_outline_0120
      006FF1 90 08 26         [24]  911 	mov	dptr,#_process_action_PARM_2
      006FF4 F5 F0            [12]  912 	mov	b,a
      006FF6 C0 07            [24]  913 	push	ar7
      006FF8 C0 06            [24]  914 	push	ar6
      006FFA C0 05            [24]  915 	push	ar5
      006FFC 12 B4 F5         [24]  916 	lcall	___memcpy
      006FFF D0 05            [24]  917 	pop	ar5
      007001 D0 06            [24]  918 	pop	ar6
      007003 D0 07            [24]  919 	pop	ar7
      007005 12 6E 1A         [24]  920 	lcall	_ak820_outline_0063
                                    921 ;	quantum/action.c:412: }
      007008 02 70 0B         [24]  922 	ljmp	_process_action
                                    923 ;------------------------------------------------------------
                                    924 ;Allocation info for local variables in function 'register_mouse'
                                    925 ;------------------------------------------------------------
                                    926 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                    927 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_643'
                                    928 ;------------------------------------------------------------
                                    929 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                    930 ;	-----------------------------------------
                                    931 ;	 function process_action
                                    932 ;	-----------------------------------------
      00700B                        933 _process_action:
      00700B 12 43 0E         [24]  934 	lcall	_ak820_outline_0036
      00700E 90 08 28         [24]  935 	mov	dptr,#_process_action_record_argument_10000_646
      007011 12 38 2A         [24]  936 	lcall	_ak820_outline_0016
                                    937 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007014 90 08 28         [24]  938 	mov	dptr,#_process_action_record_argument_10000_646
      007017 12 37 F5         [24]  939 	lcall	_ak820_outline_0005
                                    940 ;	quantum/action.c:483: pressed = record->event.pressed;
      00701A A3               [24]  941 	inc	dptr
      00701B A3               [24]  942 	inc	dptr
      00701C A3               [24]  943 	inc	dptr
      00701D A3               [24]  944 	inc	dptr
      00701E A3               [24]  945 	inc	dptr
      00701F E0               [24]  946 	movx	a,@dptr
      007020 F5 27            [12]  947 	mov	_process_action_sloc0_1_0,a
                                    948 ;	quantum/action.c:507: switch (action.kind.id) {
      007022 90 08 27         [24]  949 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007025 E0               [24]  950 	movx	a,@dptr
      007026 C4               [12]  951 	swap	a
      007027 54 0F            [12]  952 	anl	a,#0x0f
      007029 FD               [12]  953 	mov  r5,a
      00702A 24 F4            [12]  954 	add	a,#0xff - 0x0b
      00702C 50 03            [24]  955 	jnc	00434$
      00702E 02 72 AC         [24]  956 	ljmp	00181$
      007031                        957 00434$:
                                    958 ;	free result
      007031 ED               [12]  959 	mov	a,r5
      007032 24 0A            [12]  960 	add	a,#(00435$-3-.)
      007034 83               [24]  961 	movc	a,@a+pc
      007035 F5 82            [12]  962 	mov	dpl,a
      007037 ED               [12]  963 	mov	a,r5
      007038 24 10            [12]  964 	add	a,#(00436$-3-.)
      00703A 83               [24]  965 	movc	a,@a+pc
      00703B F5 83            [12]  966 	mov	dph,a
      00703D E4               [12]  967 	clr	a
      00703E 73               [24]  968 	jmp	@a+dptr
      00703F                        969 00435$:
      00703F 57                     970 	.db	00102$
      007040 57                     971 	.db	00102$
      007041 AC                     972 	.db	00181$
      007042 AC                     973 	.db	00181$
      007043 E1                     974 	.db	00123$
      007044 AC                     975 	.db	00181$
      007045 AC                     976 	.db	00181$
      007046 AC                     977 	.db	00181$
      007047 41                     978 	.db	00131$
      007048 13                     979 	.db	00147$
      007049 39                     980 	.db	00152$
      00704A 39                     981 	.db	00152$
      00704B                        982 00436$:
      00704B 70                     983 	.db	00102$>>8
      00704C 70                     984 	.db	00102$>>8
      00704D 72                     985 	.db	00181$>>8
      00704E 72                     986 	.db	00181$>>8
      00704F 70                     987 	.db	00123$>>8
      007050 72                     988 	.db	00181$>>8
      007051 72                     989 	.db	00181$>>8
      007052 72                     990 	.db	00181$>>8
      007053 71                     991 	.db	00131$>>8
      007054 72                     992 	.db	00147$>>8
      007055 72                     993 	.db	00152$>>8
      007056 72                     994 	.db	00152$>>8
                                    995 ;	quantum/action.c:510: case ACT_RMODS: {
      007057                        996 00102$:
                                    997 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      007057 90 08 27         [24]  998 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      00705A E0               [24]  999 	movx	a,@dptr
      00705B 54 F0            [12] 1000 	anl	a,#0xf0
      00705D 70 06            [24] 1001 	jnz	00194$
      00705F 12 74 BC         [24] 1002 	lcall	_ak820_outline_0107
      007062 FD               [12] 1003 	mov	r5,a
      007063 80 07            [24] 1004 	sjmp	00195$
      007065                       1005 00194$:
      007065 12 74 BC         [24] 1006 	lcall	_ak820_outline_0107
      007068 C4               [12] 1007 	swap	a
      007069 54 F0            [12] 1008 	anl	a,#0xf0
      00706B FD               [12] 1009 	mov	r5,a
      00706C                       1010 00195$:
                                   1011 ;	quantum/action.c:513: if (pressed) {
      00706C E5 27            [12] 1012 	mov	a,_process_action_sloc0_1_0
      00706E 60 35            [24] 1013 	jz	00119$
                                   1014 ;	quantum/action.c:514: if (mods) {
      007070 ED               [12] 1015 	mov	a,r5
      007071 60 29            [24] 1016 	jz	00110$
                                   1017 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007073 12 74 CE         [24] 1018 	lcall	_ak820_outline_0152
      007076 FC               [12] 1019 	mov	r4,a
      007077 BC E0 00         [24] 1020 	cjne	r4,#0xe0,00440$
      00707A                       1021 00440$:
      00707A 40 07            [24] 1022 	jc	00108$
      00707C 12 74 CE         [24] 1023 	lcall	_ak820_outline_0152
      00707F 24 18            [12] 1024 	add	a,#0xff - 0xe7
      007081 50 0A            [24] 1025 	jnc	00104$
                                   1026 ;	free result
      007083                       1027 00108$:
      007083 7B 26            [12] 1028 	mov	r3,#_process_action_PARM_2
      007085 7C 08            [12] 1029 	mov	r4,#(_process_action_PARM_2 >> 8)
      007087 12 33 FC         [24] 1030 	lcall	_ak820_outline_0118
      00708A E0               [24] 1031 	movx	a,@dptr
      00708B 70 07            [24] 1032 	jnz	00105$
      00708D                       1033 00104$:
                                   1034 ;	quantum/action.c:519: add_owned_mods(mods);
      00708D 8D 82            [24] 1035 	mov	dpl, r5
      00708F 12 7A 35         [24] 1036 	lcall	_add_owned_mods
      007092 80 05            [24] 1037 	sjmp	00106$
      007094                       1038 00105$:
                                   1039 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      007094 8D 82            [24] 1040 	mov	dpl, r5
      007096 12 7A 54         [24] 1041 	lcall	_add_owned_weak_mods
      007099                       1042 00106$:
                                   1043 ;	quantum/action.c:523: send_keyboard_report();
      007099 12 7D 71         [24] 1044 	lcall	_send_keyboard_report
      00709C                       1045 00110$:
                                   1046 ;	quantum/action.c:525: register_code(action.key.code);
      00709C 12 74 AC         [24] 1047 	lcall	_ak820_outline_0076
      00709F 12 72 C3         [24] 1048 	lcall	_register_code
      0070A2 02 72 AC         [24] 1049 	ljmp	00181$
      0070A5                       1050 00119$:
                                   1051 ;	quantum/action.c:527: unregister_code(action.key.code);
      0070A5 12 74 AC         [24] 1052 	lcall	_ak820_outline_0076
      0070A8 C0 05            [24] 1053 	push	ar5
      0070AA 12 73 30         [24] 1054 	lcall	_unregister_code
      0070AD D0 05            [24] 1055 	pop	ar5
                                   1056 ;	quantum/action.c:528: if (mods) {
      0070AF ED               [12] 1057 	mov	a,r5
      0070B0 70 03            [24] 1058 	jnz	00444$
      0070B2 02 72 AC         [24] 1059 	ljmp	00181$
      0070B5                       1060 00444$:
                                   1061 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0070B5 12 74 CE         [24] 1062 	lcall	_ak820_outline_0152
      0070B8 FC               [12] 1063 	mov	r4,a
      0070B9 BC E0 00         [24] 1064 	cjne	r4,#0xe0,00445$
      0070BC                       1065 00445$:
      0070BC 40 07            [24] 1066 	jc	00115$
      0070BE 12 74 CE         [24] 1067 	lcall	_ak820_outline_0152
      0070C1 24 18            [12] 1068 	add	a,#0xff - 0xe7
      0070C3 50 0A            [24] 1069 	jnc	00111$
                                   1070 ;	free result
      0070C5                       1071 00115$:
      0070C5 7B 26            [12] 1072 	mov	r3,#_process_action_PARM_2
      0070C7 7C 08            [12] 1073 	mov	r4,#(_process_action_PARM_2 >> 8)
      0070C9 12 33 FC         [24] 1074 	lcall	_ak820_outline_0118
      0070CC E0               [24] 1075 	movx	a,@dptr
      0070CD 70 07            [24] 1076 	jnz	00112$
      0070CF                       1077 00111$:
                                   1078 ;	quantum/action.c:530: del_owned_mods(mods);
      0070CF 8D 82            [24] 1079 	mov	dpl, r5
      0070D1 12 7A 45         [24] 1080 	lcall	_del_owned_mods
      0070D4 80 05            [24] 1081 	sjmp	00113$
      0070D6                       1082 00112$:
                                   1083 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      0070D6 8D 82            [24] 1084 	mov	dpl, r5
      0070D8 12 7A 64         [24] 1085 	lcall	_del_owned_weak_mods
      0070DB                       1086 00113$:
                                   1087 ;	quantum/action.c:534: send_keyboard_report();
      0070DB 12 7D 71         [24] 1088 	lcall	_send_keyboard_report
                                   1089 ;	quantum/action.c:537: } break;
      0070DE 02 72 AC         [24] 1090 	ljmp	00181$
                                   1091 ;	quantum/action.c:614: case ACT_USAGE:
      0070E1                       1092 00123$:
                                   1093 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      0070E1 74 07            [12] 1094 	mov	a,#0x07
      0070E3 12 38 32         [24] 1095 	lcall	_ak820_outline_0020
      0070E6 12 46 F6         [24] 1096 	lcall	_ak820_outline_0008
      0070E9 C3               [12] 1097 	clr	c
      0070EA EC               [12] 1098 	mov	a,r4
      0070EB 94 A5            [12] 1099 	subb	a,#0xa5
      0070ED ED               [12] 1100 	mov	a,r5
      0070EE 94 00            [12] 1101 	subb	a,#0x00
      0070F0 40 15            [24] 1102 	jc	00125$
      0070F2 74 C2            [12] 1103 	mov	a,#0xc2
      0070F4 9C               [12] 1104 	subb	a,r4
      0070F5 E4               [12] 1105 	clr	a
      0070F6 9D               [12] 1106 	subb	a,r5
      0070F7 40 0E            [24] 1107 	jc	00125$
                                   1108 ;	free result
                                   1109 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      0070F9 90 0A 87         [24] 1110 	mov	dptr,#_owned_usage_key_PARM_2
      0070FC E5 27            [12] 1111 	mov	a,_process_action_sloc0_1_0
      0070FE F0               [24] 1112 	movx	@dptr,a
      0070FF 8E 82            [24] 1113 	mov	dpl, r6
      007101 12 7C 1C         [24] 1114 	lcall	_owned_usage_key
                                   1115 ;	quantum/action.c:622: break;
      007104 02 72 AC         [24] 1116 	ljmp	00181$
      007107                       1117 00125$:
                                   1118 ;	quantum/action.c:625: switch (action.usage.page) {
      007107 12 74 B3         [24] 1119 	lcall	_ak820_outline_0085
      00710A FF               [12] 1120 	mov	r7,a
      00710B 60 08            [24] 1121 	jz	00127$
      00710D BF 01 02         [24] 1122 	cjne	r7,#0x01,00452$
      007110 80 19            [24] 1123 	sjmp	00128$
      007112                       1124 00452$:
      007112 02 72 AC         [24] 1125 	ljmp	00181$
                                   1126 ;	quantum/action.c:626: case PAGE_SYSTEM:
      007115                       1127 00127$:
                                   1128 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      007115 E5 27            [12] 1129 	mov	a,_process_action_sloc0_1_0
      007117 60 05            [24] 1130 	jz	00196$
      007119 12 74 C3         [24] 1131 	lcall	_ak820_outline_0126
      00711C 80 04            [24] 1132 	sjmp	00197$
      00711E                       1133 00196$:
      00711E 7E 00            [12] 1134 	mov	r6,#0x00
      007120 7F 00            [12] 1135 	mov	r7,#0x00
      007122                       1136 00197$:
      007122 12 38 87         [24] 1137 	lcall	_ak820_outline_0112
      007125 12 6B 8F         [24] 1138 	lcall	_host_system_send
                                   1139 ;	quantum/action.c:628: break;
      007128 02 72 AC         [24] 1140 	ljmp	00181$
                                   1141 ;	quantum/action.c:629: case PAGE_CONSUMER:
      00712B                       1142 00128$:
                                   1143 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      00712B E5 27            [12] 1144 	mov	a,_process_action_sloc0_1_0
      00712D 60 05            [24] 1145 	jz	00198$
      00712F 12 74 C3         [24] 1146 	lcall	_ak820_outline_0126
      007132 80 04            [24] 1147 	sjmp	00199$
      007134                       1148 00198$:
      007134 7E 00            [12] 1149 	mov	r6,#0x00
      007136 7F 00            [12] 1150 	mov	r7,#0x00
      007138                       1151 00199$:
      007138 12 38 87         [24] 1152 	lcall	_ak820_outline_0112
      00713B 12 6B BF         [24] 1153 	lcall	_host_consumer_send
                                   1154 ;	quantum/action.c:633: break;
      00713E 02 72 AC         [24] 1155 	ljmp	00181$
                                   1156 ;	quantum/action.c:640: case ACT_LAYER: {
      007141                       1157 00131$:
                                   1158 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      007141 90 08 27         [24] 1159 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007144 E0               [24] 1160 	movx	a,@dptr
      007145 54 03            [12] 1161 	anl	a,#0x03
      007147 90 08 2B         [24] 1162 	mov	dptr,#_process_action_on_40000_669
      00714A F0               [24] 1163 	movx	@dptr,a
                                   1164 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      00714B E0               [24] 1165 	movx	a,@dptr
      00714C FF               [12] 1166 	mov	r7,a
      00714D 60 11            [24] 1167 	jz	00200$
      00714F E5 27            [12] 1168 	mov	a,_process_action_sloc0_1_0
      007151 60 07            [24] 1169 	jz	00202$
      007153 8F 06            [24] 1170 	mov	ar6,r7
      007155 53 06 01         [24] 1171 	anl	ar6,#0x01
      007158 80 10            [24] 1172 	sjmp	00201$
      00715A                       1173 00202$:
      00715A 74 02            [12] 1174 	mov	a,#0x02
      00715C 5F               [12] 1175 	anl	a,r7
      00715D FE               [12] 1176 	mov	r6,a
      00715E 80 0A            [24] 1177 	sjmp	00201$
      007160                       1178 00200$:
      007160 E5 27            [12] 1179 	mov	a,_process_action_sloc0_1_0
      007162 B4 01 00         [24] 1180 	cjne	a,#0x01,00457$
      007165                       1181 00457$:
      007165 92 1F            [24] 1182 	mov  _process_action_sloc1_1_0,c
      007167 E4               [12] 1183 	clr	a
      007168 33               [12] 1184 	rlc	a
      007169 FE               [12] 1185 	mov	r6,a
      00716A                       1186 00201$:
      00716A EE               [12] 1187 	mov	a,r6
      00716B 70 03            [24] 1188 	jnz	00458$
      00716D 02 72 AC         [24] 1189 	ljmp	00181$
      007170                       1190 00458$:
                                   1191 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      007170 12 74 CE         [24] 1192 	lcall	_ak820_outline_0152
      007173 C4               [12] 1193 	swap	a
      007174 03               [12] 1194 	rr	a
      007175 54 07            [12] 1195 	anl	a,#0x07
      007177 25 E0            [12] 1196 	add	a,acc
      007179 25 E0            [12] 1197 	add	a,acc
      00717B FF               [12] 1198 	mov	r7,a
                                   1199 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      00717C 12 74 CE         [24] 1200 	lcall	_ak820_outline_0152
      00717F 54 0F            [12] 1201 	anl	a,#0x0f
      007181 FE               [12] 1202 	mov	r6,a
      007182 8F F0            [24] 1203 	mov	b,r7
      007184 05 F0            [12] 1204 	inc	b
      007186 EE               [12] 1205 	mov	a,r6
      007187 80 02            [24] 1206 	sjmp	00460$
      007189                       1207 00459$:
      007189 25 E0            [12] 1208 	add	a,acc
      00718B                       1209 00460$:
      00718B D5 F0 FB         [24] 1210 	djnz	b,00459$
      00718E FE               [12] 1211 	mov	r6,a
                                   1212 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      00718F 12 74 CE         [24] 1213 	lcall	_ak820_outline_0152
      007192 30 E4 11         [24] 1214 	jnb	acc.4,00204$
      007195 8F F0            [24] 1215 	mov	b,r7
      007197 05 F0            [12] 1216 	inc	b
      007199 74 0F            [12] 1217 	mov	a,#0x0f
      00719B 80 02            [24] 1218 	sjmp	00463$
      00719D                       1219 00462$:
      00719D 25 E0            [12] 1220 	add	a,acc
      00719F                       1221 00463$:
      00719F D5 F0 FB         [24] 1222 	djnz	b,00462$
      0071A2 F4               [12] 1223 	cpl	a
      0071A3 FF               [12] 1224 	mov	r7,a
      0071A4 80 02            [24] 1225 	sjmp	00205$
      0071A6                       1226 00204$:
      0071A6 7F 00            [12] 1227 	mov	r7,#0x00
      0071A8                       1228 00205$:
                                   1229 ;	quantum/action.c:648: bits |= mask;
      0071A8 EE               [12] 1230 	mov	a,r6
      0071A9 42 07            [12] 1231 	orl	ar7,a
                                   1232 ;	quantum/action.c:649: if (!on) {
      0071AB 90 08 2B         [24] 1233 	mov	dptr,#_process_action_on_40000_669
      0071AE E0               [24] 1234 	movx	a,@dptr
      0071AF 70 31            [24] 1235 	jnz	00143$
                                   1236 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      0071B1 12 74 B3         [24] 1237 	lcall	_ak820_outline_0085
      0071B4 FE               [12] 1238 	mov	r6,a
      0071B5 2E               [12] 1239 	add	a,r6
                                   1240 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      0071B6 90 71 BA         [24] 1241 	mov	dptr,#00465$
      0071B9 73               [24] 1242 	jmp	@a+dptr
      0071BA                       1243 00465$:
      0071BA 80 06            [24] 1244 	sjmp	00132$
      0071BC 80 0C            [24] 1245 	sjmp	00133$
      0071BE 80 12            [24] 1246 	sjmp	00134$
      0071C0 80 18            [24] 1247 	sjmp	00135$
      0071C2                       1248 00132$:
      0071C2 8F 82            [24] 1249 	mov	dpl, r7
      0071C4 12 75 29         [24] 1250 	lcall	_default_layer_and
      0071C7 02 72 AC         [24] 1251 	ljmp	00181$
                                   1252 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      0071CA                       1253 00133$:
      0071CA 8F 82            [24] 1254 	mov	dpl, r7
      0071CC 12 75 18         [24] 1255 	lcall	_default_layer_or
      0071CF 02 72 AC         [24] 1256 	ljmp	00181$
                                   1257 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      0071D2                       1258 00134$:
      0071D2 8F 82            [24] 1259 	mov	dpl, r7
      0071D4 12 75 3F         [24] 1260 	lcall	_default_layer_xor
      0071D7 02 72 AC         [24] 1261 	ljmp	00181$
                                   1262 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      0071DA                       1263 00135$:
      0071DA 8F 82            [24] 1264 	mov	dpl, r7
      0071DC 12 75 0D         [24] 1265 	lcall	_default_layer_set
                                   1266 ;	quantum/action.c:655: }
      0071DF 02 72 AC         [24] 1267 	ljmp	00181$
      0071E2                       1268 00143$:
                                   1269 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      0071E2 12 74 B3         [24] 1270 	lcall	_ak820_outline_0085
      0071E5 FE               [12] 1271 	mov	r6,a
      0071E6 2E               [12] 1272 	add	a,r6
                                   1273 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      0071E7 90 71 EB         [24] 1274 	mov	dptr,#00466$
      0071EA 73               [24] 1275 	jmp	@a+dptr
      0071EB                       1276 00466$:
      0071EB 80 06            [24] 1277 	sjmp	00137$
      0071ED 80 0C            [24] 1278 	sjmp	00138$
      0071EF 80 12            [24] 1279 	sjmp	00139$
      0071F1 80 18            [24] 1280 	sjmp	00140$
      0071F3                       1281 00137$:
      0071F3 8F 82            [24] 1282 	mov	dpl, r7
      0071F5 12 76 C3         [24] 1283 	lcall	_layer_and
      0071F8 02 72 AC         [24] 1284 	ljmp	00181$
                                   1285 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      0071FB                       1286 00138$:
      0071FB 8F 82            [24] 1287 	mov	dpl, r7
      0071FD 12 76 B2         [24] 1288 	lcall	_layer_or
      007200 02 72 AC         [24] 1289 	ljmp	00181$
                                   1290 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      007203                       1291 00139$:
      007203 8F 82            [24] 1292 	mov	dpl, r7
      007205 12 76 D9         [24] 1293 	lcall	_layer_xor
      007208 02 72 AC         [24] 1294 	ljmp	00181$
                                   1295 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      00720B                       1296 00140$:
      00720B 8F 82            [24] 1297 	mov	dpl, r7
      00720D 12 76 4F         [24] 1298 	lcall	_layer_state_set
                                   1299 ;	quantum/action.c:665: break;
      007210 02 72 AC         [24] 1300 	ljmp	00181$
                                   1301 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      007213                       1302 00147$:
                                   1303 ;	quantum/action.c:668: if (pressed) {
      007213 E5 27            [12] 1304 	mov	a,_process_action_sloc0_1_0
      007215 60 11            [24] 1305 	jz	00149$
                                   1306 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      007217 12 74 BC         [24] 1307 	lcall	_ak820_outline_0107
      00721A F5 82            [12] 1308 	mov	dpl,a
      00721C 12 75 AF         [24] 1309 	lcall	_layer_hold_on
                                   1310 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      00721F 12 74 AC         [24] 1311 	lcall	_ak820_outline_0076
      007222 12 73 E6         [24] 1312 	lcall	_register_mods
      007225 02 72 AC         [24] 1313 	ljmp	00181$
      007228                       1314 00149$:
                                   1315 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      007228 12 74 AC         [24] 1316 	lcall	_ak820_outline_0076
      00722B 12 73 FA         [24] 1317 	lcall	_unregister_mods
                                   1318 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      00722E 12 74 BC         [24] 1319 	lcall	_ak820_outline_0107
      007231 F5 82            [12] 1320 	mov	dpl,a
      007233 12 75 E7         [24] 1321 	lcall	_layer_hold_off
                                   1322 ;	quantum/action.c:675: break;
      007236 02 72 AC         [24] 1323 	ljmp	00181$
                                   1324 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      007239                       1325 00152$:
                                   1326 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      007239 12 74 CE         [24] 1327 	lcall	_ak820_outline_0152
      00723C FF               [12] 1328 	mov	r7,a
      00723D BF F1 02         [24] 1329 	cjne	r7,#0xf1,00468$
      007240 80 0A            [24] 1330 	sjmp	00154$
      007242                       1331 00468$:
      007242 BF F2 02         [24] 1332 	cjne	r7,#0xf2,00469$
      007245 80 19            [24] 1333 	sjmp	00155$
      007247                       1334 00469$:
                                   1335 ;	quantum/action.c:694: momentary_layer_action:
      007247 BF F3 3B         [24] 1336 	cjne	r7,#0xf3,00160$
      00724A 80 28            [24] 1337 	sjmp	00156$
      00724C                       1338 00154$:
                                   1339 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      00724C E5 27            [12] 1340 	mov	a,_process_action_sloc0_1_0
      00724E 60 08            [24] 1341 	jz	00206$
      007250 12 74 92         [24] 1342 	lcall	_ak820_outline_0041
      007253 12 75 AF         [24] 1343 	lcall	_layer_hold_on
      007256 80 54            [24] 1344 	sjmp	00181$
      007258                       1345 00206$:
      007258 12 74 92         [24] 1346 	lcall	_ak820_outline_0041
      00725B 12 75 E7         [24] 1347 	lcall	_layer_hold_off
                                   1348 ;	quantum/action.c:696: break;
                                   1349 ;	quantum/action.c:697: case OP_OFF_ON:
      00725E 80 4C            [24] 1350 	sjmp	00181$
      007260                       1351 00155$:
                                   1352 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      007260 E5 27            [12] 1353 	mov	a,_process_action_sloc0_1_0
      007262 60 08            [24] 1354 	jz	00208$
      007264 12 74 92         [24] 1355 	lcall	_ak820_outline_0041
      007267 12 76 94         [24] 1356 	lcall	_layer_off
      00726A 80 40            [24] 1357 	sjmp	00181$
      00726C                       1358 00208$:
      00726C 12 74 92         [24] 1359 	lcall	_ak820_outline_0041
      00726F 12 76 79         [24] 1360 	lcall	_layer_on
                                   1361 ;	quantum/action.c:699: break;
                                   1362 ;	quantum/action.c:700: case OP_SET_CLEAR:
      007272 80 38            [24] 1363 	sjmp	00181$
      007274                       1364 00156$:
                                   1365 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      007274 E5 27            [12] 1366 	mov	a,_process_action_sloc0_1_0
      007276 60 08            [24] 1367 	jz	00210$
      007278 12 74 92         [24] 1368 	lcall	_ak820_outline_0041
      00727B 12 76 63         [24] 1369 	lcall	_layer_move
      00727E 80 2C            [24] 1370 	sjmp	00181$
      007280                       1371 00210$:
      007280 12 76 5D         [24] 1372 	lcall	_layer_clear
                                   1373 ;	quantum/action.c:702: break;
                                   1374 ;	quantum/action.c:748: default:
      007283 80 27            [24] 1375 	sjmp	00181$
      007285                       1376 00160$:
                                   1377 ;	quantum/action.c:755: if (pressed) {
      007285 E5 27            [12] 1378 	mov	a,_process_action_sloc0_1_0
      007287 60 08            [24] 1379 	jz	00163$
                                   1380 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      007289 12 74 AC         [24] 1381 	lcall	_ak820_outline_0076
      00728C 12 72 C3         [24] 1382 	lcall	_register_code
                                   1383 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      00728F 80 1B            [24] 1384 	sjmp	00181$
      007291                       1385 00163$:
                                   1386 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      007291 12 74 CE         [24] 1387 	lcall	_ak820_outline_0152
      007294 FF               [12] 1388 	mov	r7,a
      007295 BF 39 0E         [24] 1389 	cjne	r7,#0x39,00175$
                                   1390 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      007298 7F 50            [12] 1391 	mov	r7,#0x50
      00729A                       1392 00187$:
      00729A EF               [12] 1393 	mov	a,r7
      00729B 60 09            [24] 1394 	jz	00175$
      00729D 90 00 01         [24] 1395 	mov	dptr,#0x0001
      0072A0 12 57 69         [24] 1396 	lcall	_mDelaymS
      0072A3 1F               [12] 1397 	dec	r7
                                   1398 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      0072A4 80 F4            [24] 1399 	sjmp	00187$
      0072A6                       1400 00175$:
                                   1401 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      0072A6 12 74 AC         [24] 1402 	lcall	_ak820_outline_0076
      0072A9 12 73 30         [24] 1403 	lcall	_unregister_code
                                   1404 ;	quantum/action.c:848: }
      0072AC                       1405 00181$:
                                   1406 ;	quantum/action.c:869: switch (action.kind.id) {
      0072AC 90 08 27         [24] 1407 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0072AF E0               [24] 1408 	movx	a,@dptr
      0072B0 C4               [12] 1409 	swap	a
      0072B1 54 0F            [12] 1410 	anl	a,#0x0f
      0072B3 FF               [12] 1411 	mov	r7,a
      0072B4 BF 08 02         [24] 1412 	cjne	r7,#0x08,00478$
      0072B7 80 03            [24] 1413 	sjmp	00183$
      0072B9                       1414 00478$:
      0072B9 BF 09 06         [24] 1415 	cjne	r7,#0x09,00192$
                                   1416 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      0072BC                       1417 00183$:
                                   1418 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      0072BC 12 6A F4         [24] 1419 	lcall	_host_keyboard_leds
                                   1420 ;	quantum/action.c:880: }
                                   1421 ;	quantum/action.c:933: }
      0072BF 02 94 C6         [24] 1422 	ljmp	_led_set
      0072C2                       1423 00192$:
      0072C2 22               [24] 1424 	ret
                                   1425 ;------------------------------------------------------------
                                   1426 ;Allocation info for local variables in function 'register_code'
                                   1427 ;------------------------------------------------------------
                                   1428 ;code          Allocated with name '_register_code_code_10000_703'
                                   1429 ;------------------------------------------------------------
                                   1430 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1431 ;	-----------------------------------------
                                   1432 ;	 function register_code
                                   1433 ;	-----------------------------------------
      0072C3                       1434 _register_code:
      0072C3 E5 82            [12] 1435 	mov	a,dpl
      0072C5 90 08 2C         [24] 1436 	mov	dptr,#_register_code_code_10000_703
      0072C8 F0               [24] 1437 	movx	@dptr,a
                                   1438 ;	quantum/action.c:940: if (code == KC_NO) {
      0072C9 E0               [24] 1439 	movx	a,@dptr
      0072CA FF               [12] 1440 	mov	r7,a
      0072CB 70 01            [24] 1441 	jnz	00123$
                                   1442 ;	quantum/action.c:941: return;
      0072CD 22               [24] 1443 	ret
      0072CE                       1444 00123$:
                                   1445 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      0072CE BF 04 00         [24] 1446 	cjne	r7,#0x04,00186$
      0072D1                       1447 00186$:
      0072D1 40 12            [24] 1448 	jc	00119$
      0072D3 EF               [12] 1449 	mov	a,r7
      0072D4 24 5B            [12] 1450 	add	a,#0xff - 0xa4
      0072D6 40 0D            [24] 1451 	jc	00119$
                                   1452 ;	free result
                                   1453 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      0072D8 8F 82            [24] 1454 	mov	dpl, r7
      0072DA 12 7A D9         [24] 1455 	lcall	_add_owned_key
      0072DD E5 82            [12] 1456 	mov	a, dpl
      0072DF 70 01            [24] 1457 	jnz	00104$
      0072E1 22               [24] 1458 	ret
      0072E2                       1459 00104$:
                                   1460 ;	quantum/action.c:995: send_keyboard_report();
      0072E2 02 7D 71         [24] 1461 	ljmp	_send_keyboard_report
      0072E5                       1462 00119$:
                                   1463 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      0072E5 12 74 D3         [24] 1464 	lcall	_ak820_outline_0160
      0072E8 BF E0 00         [24] 1465 	cjne	r7,#0xe0,00190$
      0072EB                       1466 00190$:
      0072EB 40 1A            [24] 1467 	jc	00115$
      0072ED EF               [12] 1468 	mov	a,r7
      0072EE 24 18            [12] 1469 	add	a,#0xff - 0xe7
      0072F0 40 15            [24] 1470 	jc	00115$
                                   1471 ;	free result
                                   1472 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      0072F2 74 07            [12] 1473 	mov	a,#0x07
      0072F4 5F               [12] 1474 	anl	a,r7
      0072F5 12 74 9B         [24] 1475 	lcall	_ak820_outline_0061
      0072F8 80 02            [24] 1476 	sjmp	00194$
      0072FA                       1477 00193$:
      0072FA 25 E0            [12] 1478 	add	a,acc
      0072FC                       1479 00194$:
      0072FC D5 F0 FB         [24] 1480 	djnz	b,00193$
      0072FF F5 82            [12] 1481 	mov	dpl,a
      007301 12 7A 35         [24] 1482 	lcall	_add_owned_mods
                                   1483 ;	quantum/action.c:998: send_keyboard_report();
      007304 02 7D 71         [24] 1484 	ljmp	_send_keyboard_report
      007307                       1485 00115$:
                                   1486 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007307 12 74 D3         [24] 1487 	lcall	_ak820_outline_0160
      00730A BF A5 00         [24] 1488 	cjne	r7,#0xa5,00195$
      00730D                       1489 00195$:
      00730D 40 05            [24] 1490 	jc	00113$
      00730F EF               [12] 1491 	mov	a,r7
      007310 24 58            [12] 1492 	add	a,#0xff - 0xa7
      007312 50 0D            [24] 1493 	jnc	00108$
                                   1494 ;	free result
      007314                       1495 00113$:
      007314 12 74 D3         [24] 1496 	lcall	_ak820_outline_0160
      007317 BF A8 00         [24] 1497 	cjne	r7,#0xa8,00198$
      00731A                       1498 00198$:
      00731A 40 13            [24] 1499 	jc	00125$
      00731C EF               [12] 1500 	mov	a,r7
      00731D 24 3D            [12] 1501 	add	a,#0xff - 0xc2
      00731F 40 0E            [24] 1502 	jc	00125$
                                   1503 ;	free result
      007321                       1504 00108$:
                                   1505 ;	quantum/action.c:1003: owned_usage_key(code, true);
      007321 12 74 D3         [24] 1506 	lcall	_ak820_outline_0160
      007324 90 0A 87         [24] 1507 	mov	dptr,#_owned_usage_key_PARM_2
      007327 74 01            [12] 1508 	mov	a,#0x01
      007329 F0               [24] 1509 	movx	@dptr,a
      00732A 8F 82            [24] 1510 	mov	dpl, r7
                                   1511 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1512 ;	quantum/action.c:1013: }
      00732C 02 7C 1C         [24] 1513 	ljmp	_owned_usage_key
      00732F                       1514 00125$:
      00732F 22               [24] 1515 	ret
                                   1516 ;------------------------------------------------------------
                                   1517 ;Allocation info for local variables in function 'unregister_code'
                                   1518 ;------------------------------------------------------------
                                   1519 ;code          Allocated with name '_unregister_code_code_10000_717'
                                   1520 ;------------------------------------------------------------
                                   1521 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1522 ;	-----------------------------------------
                                   1523 ;	 function unregister_code
                                   1524 ;	-----------------------------------------
      007330                       1525 _unregister_code:
      007330 E5 82            [12] 1526 	mov	a,dpl
      007332 90 08 2D         [24] 1527 	mov	dptr,#_unregister_code_code_10000_717
      007335 F0               [24] 1528 	movx	@dptr,a
                                   1529 ;	quantum/action.c:1020: if (code == KC_NO) {
      007336 E0               [24] 1530 	movx	a,@dptr
      007337 FF               [12] 1531 	mov	r7,a
      007338 70 01            [24] 1532 	jnz	00121$
                                   1533 ;	quantum/action.c:1021: return;
      00733A 22               [24] 1534 	ret
      00733B                       1535 00121$:
                                   1536 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      00733B BF 04 00         [24] 1537 	cjne	r7,#0x04,00184$
      00733E                       1538 00184$:
      00733E 40 12            [24] 1539 	jc	00117$
      007340 EF               [12] 1540 	mov	a,r7
      007341 24 5B            [12] 1541 	add	a,#0xff - 0xa4
      007343 40 0D            [24] 1542 	jc	00117$
                                   1543 ;	free result
                                   1544 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      007345 8F 82            [24] 1545 	mov	dpl, r7
      007347 12 7B 53         [24] 1546 	lcall	_del_owned_key
      00734A E5 82            [12] 1547 	mov	a, dpl
      00734C 70 01            [24] 1548 	jnz	00102$
      00734E 22               [24] 1549 	ret
      00734F                       1550 00102$:
                                   1551 ;	quantum/action.c:1062: send_keyboard_report();
      00734F 02 7D 71         [24] 1552 	ljmp	_send_keyboard_report
      007352                       1553 00117$:
                                   1554 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      007352 12 74 D9         [24] 1555 	lcall	_ak820_outline_0161
      007355 BF E0 00         [24] 1556 	cjne	r7,#0xe0,00188$
      007358                       1557 00188$:
      007358 40 1A            [24] 1558 	jc	00113$
      00735A EF               [12] 1559 	mov	a,r7
      00735B 24 18            [12] 1560 	add	a,#0xff - 0xe7
      00735D 40 15            [24] 1561 	jc	00113$
                                   1562 ;	free result
                                   1563 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      00735F 74 07            [12] 1564 	mov	a,#0x07
      007361 5F               [12] 1565 	anl	a,r7
      007362 12 74 9B         [24] 1566 	lcall	_ak820_outline_0061
      007365 80 02            [24] 1567 	sjmp	00192$
      007367                       1568 00191$:
      007367 25 E0            [12] 1569 	add	a,acc
      007369                       1570 00192$:
      007369 D5 F0 FB         [24] 1571 	djnz	b,00191$
      00736C F5 82            [12] 1572 	mov	dpl,a
      00736E 12 7A 45         [24] 1573 	lcall	_del_owned_mods
                                   1574 ;	quantum/action.c:1065: send_keyboard_report();
      007371 02 7D 71         [24] 1575 	ljmp	_send_keyboard_report
      007374                       1576 00113$:
                                   1577 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      007374 12 74 D9         [24] 1578 	lcall	_ak820_outline_0161
      007377 BF A5 00         [24] 1579 	cjne	r7,#0xa5,00193$
      00737A                       1580 00193$:
      00737A 40 05            [24] 1581 	jc	00111$
      00737C EF               [12] 1582 	mov	a,r7
      00737D 24 58            [12] 1583 	add	a,#0xff - 0xa7
      00737F 50 0D            [24] 1584 	jnc	00106$
                                   1585 ;	free result
      007381                       1586 00111$:
      007381 12 74 D9         [24] 1587 	lcall	_ak820_outline_0161
      007384 BF A8 00         [24] 1588 	cjne	r7,#0xa8,00196$
      007387                       1589 00196$:
      007387 40 12            [24] 1590 	jc	00123$
      007389 EF               [12] 1591 	mov	a,r7
      00738A 24 3D            [12] 1592 	add	a,#0xff - 0xc2
      00738C 40 0D            [24] 1593 	jc	00123$
                                   1594 ;	free result
      00738E                       1595 00106$:
                                   1596 ;	quantum/action.c:1070: owned_usage_key(code, false);
      00738E 12 74 D9         [24] 1597 	lcall	_ak820_outline_0161
      007391 90 0A 87         [24] 1598 	mov	dptr,#_owned_usage_key_PARM_2
      007394 E4               [12] 1599 	clr	a
      007395 F0               [24] 1600 	movx	@dptr,a
      007396 8F 82            [24] 1601 	mov	dpl, r7
                                   1602 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1603 ;	quantum/action.c:1080: }
      007398 02 7C 1C         [24] 1604 	ljmp	_owned_usage_key
      00739B                       1605 00123$:
      00739B 22               [24] 1606 	ret
                                   1607 ;------------------------------------------------------------
                                   1608 ;Allocation info for local variables in function 'tap_code_delay'
                                   1609 ;------------------------------------------------------------
                                   1610 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1611 ;code          Allocated with name '_tap_code_delay_code_10000_730'
                                   1612 ;i             Allocated with name '_tap_code_delay_i_20000_732'
                                   1613 ;i             Allocated with name '_tap_code_delay_i_50000_735'
                                   1614 ;------------------------------------------------------------
                                   1615 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1616 ;	-----------------------------------------
                                   1617 ;	 function tap_code_delay
                                   1618 ;	-----------------------------------------
      00739C                       1619 _tap_code_delay:
      00739C E5 82            [12] 1620 	mov	a,dpl
      00739E 90 08 30         [24] 1621 	mov	dptr,#_tap_code_delay_code_10000_730
      0073A1 F0               [24] 1622 	movx	@dptr,a
                                   1623 ;	quantum/action.c:1088: register_code(code);
      0073A2 E0               [24] 1624 	movx	a,@dptr
      0073A3 FF               [12] 1625 	mov	r7,a
      0073A4 F5 82            [12] 1626 	mov	dpl,a
      0073A6 C0 07            [24] 1627 	push	ar7
      0073A8 12 72 C3         [24] 1628 	lcall	_register_code
      0073AB D0 07            [24] 1629 	pop	ar7
                                   1630 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      0073AD 90 08 2E         [24] 1631 	mov	dptr,#_tap_code_delay_PARM_2
      0073B0 12 38 71         [24] 1632 	lcall	_ak820_outline_0092
      0073B3                       1633 00110$:
      0073B3 ED               [12] 1634 	mov	a,r5
      0073B4 4E               [12] 1635 	orl	a,r6
      0073B5 60 0D            [24] 1636 	jz	00105$
                                   1637 ;	quantum/action.c:1090: wait_ms(1);
      0073B7 90 00 01         [24] 1638 	mov	dptr,#0x0001
      0073BA 12 57 69         [24] 1639 	lcall	_mDelaymS
                                   1640 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      0073BD 1D               [12] 1641 	dec	r5
      0073BE BD FF 01         [24] 1642 	cjne	r5,#0xff,00141$
      0073C1 1E               [12] 1643 	dec	r6
      0073C2                       1644 00141$:
      0073C2 80 EF            [24] 1645 	sjmp	00110$
      0073C4                       1646 00105$:
                                   1647 ;	quantum/action.c:1092: unregister_code(code);
      0073C4 8F 82            [24] 1648 	mov	dpl, r7
                                   1649 ;	quantum/action.c:1093: }
      0073C6 02 73 30         [24] 1650 	ljmp	_unregister_code
                                   1651 ;------------------------------------------------------------
                                   1652 ;Allocation info for local variables in function 'tap_code'
                                   1653 ;------------------------------------------------------------
                                   1654 ;code          Allocated with name '_tap_code_code_10000_737'
                                   1655 ;------------------------------------------------------------
                                   1656 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1657 ;	-----------------------------------------
                                   1658 ;	 function tap_code
                                   1659 ;	-----------------------------------------
      0073C9                       1660 _tap_code:
      0073C9 E5 82            [12] 1661 	mov	a,dpl
      0073CB 90 08 31         [24] 1662 	mov	dptr,#_tap_code_code_10000_737
      0073CE F0               [24] 1663 	movx	@dptr,a
                                   1664 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      0073CF E0               [24] 1665 	movx	a,@dptr
      0073D0 FF               [12] 1666 	mov	r7,a
      0073D1 BF 39 04         [24] 1667 	cjne	r7,#0x39,00103$
      0073D4 7E 50            [12] 1668 	mov	r6,#0x50
      0073D6 80 02            [24] 1669 	sjmp	00104$
      0073D8                       1670 00103$:
      0073D8 7E 00            [12] 1671 	mov	r6,#0x00
      0073DA                       1672 00104$:
      0073DA 90 08 2E         [24] 1673 	mov	dptr,#_tap_code_delay_PARM_2
      0073DD EE               [12] 1674 	mov	a,r6
      0073DE 12 38 97         [24] 1675 	lcall	_ak820_outline_0120
      0073E1 8F 82            [24] 1676 	mov	dpl, r7
                                   1677 ;	quantum/action.c:1101: }
      0073E3 02 73 9C         [24] 1678 	ljmp	_tap_code_delay
                                   1679 ;------------------------------------------------------------
                                   1680 ;Allocation info for local variables in function 'register_mods'
                                   1681 ;------------------------------------------------------------
                                   1682 ;mods          Allocated with name '_register_mods_mods_10000_739'
                                   1683 ;------------------------------------------------------------
                                   1684 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1685 ;	-----------------------------------------
                                   1686 ;	 function register_mods
                                   1687 ;	-----------------------------------------
      0073E6                       1688 _register_mods:
      0073E6 E5 82            [12] 1689 	mov	a,dpl
      0073E8 90 08 32         [24] 1690 	mov	dptr,#_register_mods_mods_10000_739
      0073EB F0               [24] 1691 	movx	@dptr,a
                                   1692 ;	quantum/action.c:1108: if (mods) {
      0073EC E0               [24] 1693 	movx	a,@dptr
      0073ED FF               [12] 1694 	mov	r7,a
      0073EE E0               [24] 1695 	movx	a,@dptr
      0073EF 60 08            [24] 1696 	jz	00103$
                                   1697 ;	quantum/action.c:1109: add_owned_mods(mods);
      0073F1 8F 82            [24] 1698 	mov	dpl, r7
      0073F3 12 7A 35         [24] 1699 	lcall	_add_owned_mods
                                   1700 ;	quantum/action.c:1110: send_keyboard_report();
                                   1701 ;	quantum/action.c:1112: }
      0073F6 02 7D 71         [24] 1702 	ljmp	_send_keyboard_report
      0073F9                       1703 00103$:
      0073F9 22               [24] 1704 	ret
                                   1705 ;------------------------------------------------------------
                                   1706 ;Allocation info for local variables in function 'unregister_mods'
                                   1707 ;------------------------------------------------------------
                                   1708 ;mods          Allocated with name '_unregister_mods_mods_10000_743'
                                   1709 ;------------------------------------------------------------
                                   1710 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1711 ;	-----------------------------------------
                                   1712 ;	 function unregister_mods
                                   1713 ;	-----------------------------------------
      0073FA                       1714 _unregister_mods:
      0073FA E5 82            [12] 1715 	mov	a,dpl
      0073FC 90 08 33         [24] 1716 	mov	dptr,#_unregister_mods_mods_10000_743
      0073FF F0               [24] 1717 	movx	@dptr,a
                                   1718 ;	quantum/action.c:1119: if (mods) {
      007400 E0               [24] 1719 	movx	a,@dptr
      007401 FF               [12] 1720 	mov	r7,a
      007402 E0               [24] 1721 	movx	a,@dptr
      007403 60 08            [24] 1722 	jz	00103$
                                   1723 ;	quantum/action.c:1120: del_owned_mods(mods);
      007405 8F 82            [24] 1724 	mov	dpl, r7
      007407 12 7A 45         [24] 1725 	lcall	_del_owned_mods
                                   1726 ;	quantum/action.c:1121: send_keyboard_report();
                                   1727 ;	quantum/action.c:1123: }
      00740A 02 7D 71         [24] 1728 	ljmp	_send_keyboard_report
      00740D                       1729 00103$:
      00740D 22               [24] 1730 	ret
                                   1731 ;------------------------------------------------------------
                                   1732 ;Allocation info for local variables in function 'register_weak_mods'
                                   1733 ;------------------------------------------------------------
                                   1734 ;mods          Allocated with name '_register_weak_mods_mods_10000_747'
                                   1735 ;------------------------------------------------------------
                                   1736 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1737 ;	-----------------------------------------
                                   1738 ;	 function register_weak_mods
                                   1739 ;	-----------------------------------------
      00740E                       1740 _register_weak_mods:
      00740E E5 82            [12] 1741 	mov	a,dpl
      007410 90 08 34         [24] 1742 	mov	dptr,#_register_weak_mods_mods_10000_747
      007413 F0               [24] 1743 	movx	@dptr,a
                                   1744 ;	quantum/action.c:1130: if (mods) {
      007414 E0               [24] 1745 	movx	a,@dptr
      007415 FF               [12] 1746 	mov	r7,a
      007416 E0               [24] 1747 	movx	a,@dptr
      007417 60 08            [24] 1748 	jz	00103$
                                   1749 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      007419 8F 82            [24] 1750 	mov	dpl, r7
      00741B 12 7A 54         [24] 1751 	lcall	_add_owned_weak_mods
                                   1752 ;	quantum/action.c:1132: send_keyboard_report();
                                   1753 ;	quantum/action.c:1134: }
      00741E 02 7D 71         [24] 1754 	ljmp	_send_keyboard_report
      007421                       1755 00103$:
      007421 22               [24] 1756 	ret
                                   1757 ;------------------------------------------------------------
                                   1758 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1759 ;------------------------------------------------------------
                                   1760 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_751'
                                   1761 ;------------------------------------------------------------
                                   1762 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1763 ;	-----------------------------------------
                                   1764 ;	 function unregister_weak_mods
                                   1765 ;	-----------------------------------------
      007422                       1766 _unregister_weak_mods:
      007422 E5 82            [12] 1767 	mov	a,dpl
      007424 90 08 35         [24] 1768 	mov	dptr,#_unregister_weak_mods_mods_10000_751
      007427 F0               [24] 1769 	movx	@dptr,a
                                   1770 ;	quantum/action.c:1141: if (mods) {
      007428 E0               [24] 1771 	movx	a,@dptr
      007429 FF               [12] 1772 	mov	r7,a
      00742A E0               [24] 1773 	movx	a,@dptr
      00742B 60 08            [24] 1774 	jz	00103$
                                   1775 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      00742D 8F 82            [24] 1776 	mov	dpl, r7
      00742F 12 7A 64         [24] 1777 	lcall	_del_owned_weak_mods
                                   1778 ;	quantum/action.c:1143: send_keyboard_report();
                                   1779 ;	quantum/action.c:1145: }
      007432 02 7D 71         [24] 1780 	ljmp	_send_keyboard_report
      007435                       1781 00103$:
      007435 22               [24] 1782 	ret
                                   1783 ;------------------------------------------------------------
                                   1784 ;Allocation info for local variables in function 'clear_keyboard'
                                   1785 ;------------------------------------------------------------
                                   1786 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   1787 ;	-----------------------------------------
                                   1788 ;	 function clear_keyboard
                                   1789 ;	-----------------------------------------
      007436                       1790 _clear_keyboard:
                                   1791 ;	quantum/action.c:1152: clear_mods();
      007436 12 7D EB         [24] 1792 	lcall	_clear_mods
                                   1793 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   1794 ;	quantum/action.c:1154: }
      007439 02 74 3C         [24] 1795 	ljmp	_clear_keyboard_but_mods
                                   1796 ;------------------------------------------------------------
                                   1797 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1798 ;------------------------------------------------------------
                                   1799 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   1800 ;	-----------------------------------------
                                   1801 ;	 function clear_keyboard_but_mods
                                   1802 ;	-----------------------------------------
      00743C                       1803 _clear_keyboard_but_mods:
                                   1804 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00743C 90 0D B3         [24] 1805 	mov	dptr,#_actual_keyboard_report
      00743F 12 6D BB         [24] 1806 	lcall	_clear_keys_from_report
                                   1807 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   1808 ;	quantum/action.c:1163: }
      007442 02 74 45         [24] 1809 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1810 ;------------------------------------------------------------
                                   1811 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1812 ;------------------------------------------------------------
                                   1813 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   1814 ;	-----------------------------------------
                                   1815 ;	 function clear_keyboard_but_mods_and_keys
                                   1816 ;	-----------------------------------------
      007445                       1817 _clear_keyboard_but_mods_and_keys:
                                   1818 ;	quantum/action.c:1171: ak820_tapping_cancel();
      007445 12 46 CE         [24] 1819 	lcall	_ak820_tapping_cancel
                                   1820 ;	quantum/action.c:1185: ak820_combo_cancel();
      007448 12 35 70         [24] 1821 	lcall	_ak820_combo_cancel
                                   1822 ;	quantum/action.c:1188: repeat_key_cancel();
      00744B 12 9E 42         [24] 1823 	lcall	_repeat_key_cancel
                                   1824 ;	quantum/action.c:1190: clear_owned_mods();
      00744E 12 7A 74         [24] 1825 	lcall	_clear_owned_mods
                                   1826 ;	quantum/action.c:1191: clear_owned_keys();
      007451 12 7A AC         [24] 1827 	lcall	_clear_owned_keys
                                   1828 ;	quantum/action.c:1192: clear_owned_usages();
      007454 12 7B E4         [24] 1829 	lcall	_clear_owned_usages
                                   1830 ;	quantum/action.c:1193: layer_hold_clear();
      007457 12 76 20         [24] 1831 	lcall	_layer_hold_clear
                                   1832 ;	quantum/action.c:1195: clear_macro_tri_layer();
      00745A 12 99 8C         [24] 1833 	lcall	_clear_macro_tri_layer
                                   1834 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      00745D 90 0D B3         [24] 1835 	mov	dptr,#_actual_keyboard_report
      007460 12 6D BB         [24] 1836 	lcall	_clear_keys_from_report
                                   1837 ;	quantum/action.c:1200: host_system_send(0);
      007463 90 00 00         [24] 1838 	mov	dptr,#0x0000
      007466 12 6B 8F         [24] 1839 	lcall	_host_system_send
                                   1840 ;	quantum/action.c:1201: host_consumer_send(0);
      007469 90 00 00         [24] 1841 	mov	dptr,#0x0000
      00746C 12 6B BF         [24] 1842 	lcall	_host_consumer_send
                                   1843 ;	quantum/action.c:1203: clear_weak_mods();
      00746F 12 7E 20         [24] 1844 	lcall	_clear_weak_mods
                                   1845 ;	quantum/action.c:1204: send_keyboard_report();
                                   1846 ;	quantum/action.c:1212: }
      007472 02 7D 71         [24] 1847 	ljmp	_send_keyboard_report
                                   1848 ;------------------------------------------------------------
                                   1849 ;Allocation info for local variables in function 'is_tap_record'
                                   1850 ;------------------------------------------------------------
                                   1851 ;record        Allocated with name '_is_tap_record_record_10000_767'
                                   1852 ;action        Allocated with name '_is_tap_record_action_10001_771'
                                   1853 ;------------------------------------------------------------
                                   1854 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   1855 ;	-----------------------------------------
                                   1856 	.area CSEG    (CODE)
                                   1857 	.area CONST   (CODE)
                                   1858 	.area XINIT   (CODE)
      00BDC4                       1859 __xinit__disable_action_cache:
      00BDC4 00                    1860 	.db #0x00	;  0
                                   1861 	.area CABS    (ABS,CODE)
                                   1862 
                                   1863 ; Experimental exact instruction outlining.
                                   1864 	.globl _ak820_outline_0001
                                   1865 	.globl _ak820_outline_0005
                                   1866 	.globl _ak820_outline_0007
                                   1867 	.globl _ak820_outline_0008
                                   1868 	.globl _ak820_outline_0010
                                   1869 	.globl _ak820_outline_0011
                                   1870 	.globl _ak820_outline_0012
                                   1871 	.globl _ak820_outline_0016
                                   1872 	.globl _ak820_outline_0019
                                   1873 	.globl _ak820_outline_0020
                                   1874 	.globl _ak820_outline_0036
                                   1875 	.globl _ak820_outline_0041
                                   1876 	.globl _ak820_outline_0046
                                   1877 	.globl _ak820_outline_0061
                                   1878 	.globl _ak820_outline_0063
                                   1879 	.globl _ak820_outline_0069
                                   1880 	.globl _ak820_outline_0071
                                   1881 	.globl _ak820_outline_0076
                                   1882 	.globl _ak820_outline_0085
                                   1883 	.globl _ak820_outline_0089
                                   1884 	.globl _ak820_outline_0092
                                   1885 	.globl _ak820_outline_0103
                                   1886 	.globl _ak820_outline_0104
                                   1887 	.globl _ak820_outline_0107
                                   1888 	.globl _ak820_outline_0112
                                   1889 	.globl _ak820_outline_0118
                                   1890 	.globl _ak820_outline_0119
                                   1891 	.globl _ak820_outline_0120
                                   1892 	.globl _ak820_outline_0126
                                   1893 	.globl _ak820_outline_0136
                                   1894 	.globl _ak820_outline_0143
                                   1895 	.globl _ak820_outline_0152
                                   1896 	.globl _ak820_outline_0160
                                   1897 	.globl _ak820_outline_0161
                                   1898 	.globl _ak820_outline_0163
                                   1899 
                                   1900 	.area CSEG (CODE)
                                   1901 ; function ak820_outline_0011
      007475                       1902 _ak820_outline_0011:
      007475 2D               [12] 1903 	add	a,r5
      007476 FA               [12] 1904 	mov	r2,a
      007477 E4               [12] 1905 	clr	a
      007478 3E               [12] 1906 	addc	a,r6
      007479 FB               [12] 1907 	mov	r3,a
      00747A 8F 04            [24] 1908 	mov	ar4,r7
      00747C 8A 82            [24] 1909 	mov	dpl,r2
      00747E 8B 83            [24] 1910 	mov	dph,r3
      007480 8C F0            [24] 1911 	mov	b,r4
      007482 22               [24] 1912 	ret
                                   1913 
                                   1914 	.area CSEG (CODE)
                                   1915 ; function ak820_outline_0019
      007483                       1916 _ak820_outline_0019:
      007483 8E 82            [24] 1917 	mov	dpl,r6
      007485 8F 83            [24] 1918 	mov	dph,r7
      007487 A3               [24] 1919 	inc	dptr
      007488 E0               [24] 1920 	movx	a,@dptr
      007489 FC               [12] 1921 	mov	r4,a
      00748A 7D 00            [12] 1922 	mov	r5,#0x00
      00748C 8E 82            [24] 1923 	mov	dpl,r6
      00748E 8F 83            [24] 1924 	mov	dph,r7
      007490 E0               [24] 1925 	movx	a,@dptr
      007491 22               [24] 1926 	ret
                                   1927 
                                   1928 	.area CSEG (CODE)
                                   1929 ; function ak820_outline_0041
      007492                       1930 _ak820_outline_0041:
      007492 90 08 27         [24] 1931 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007495 E0               [24] 1932 	movx	a,@dptr
      007496 54 1F            [12] 1933 	anl	a,#0x1f
      007498 F5 82            [12] 1934 	mov	dpl,a
      00749A 22               [24] 1935 	ret
                                   1936 
                                   1937 	.area CSEG (CODE)
                                   1938 ; function ak820_outline_0061
      00749B                       1939 _ak820_outline_0061:
      00749B F5 F0            [12] 1940 	mov	b,a
      00749D 05 F0            [12] 1941 	inc	b
      00749F 74 01            [12] 1942 	mov	a,#0x01
      0074A1 22               [24] 1943 	ret
                                   1944 
                                   1945 	.area CSEG (CODE)
                                   1946 ; function ak820_outline_0069
      0074A2                       1947 _ak820_outline_0069:
      0074A2 90 0D 92         [24] 1948 	mov	dptr,#___memcpy_PARM_3
      0074A5 74 06            [12] 1949 	mov	a,#0x06
      0074A7 F0               [24] 1950 	movx	@dptr,a
      0074A8 E4               [12] 1951 	clr	a
      0074A9 A3               [24] 1952 	inc	dptr
      0074AA F0               [24] 1953 	movx	@dptr,a
      0074AB 22               [24] 1954 	ret
                                   1955 
                                   1956 	.area CSEG (CODE)
                                   1957 ; function ak820_outline_0076
      0074AC                       1958 _ak820_outline_0076:
      0074AC 90 08 26         [24] 1959 	mov	dptr,#_process_action_PARM_2
      0074AF E0               [24] 1960 	movx	a,@dptr
      0074B0 F5 82            [12] 1961 	mov	dpl,a
      0074B2 22               [24] 1962 	ret
                                   1963 
                                   1964 	.area CSEG (CODE)
                                   1965 ; function ak820_outline_0085
      0074B3                       1966 _ak820_outline_0085:
      0074B3 90 08 27         [24] 1967 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0074B6 E0               [24] 1968 	movx	a,@dptr
      0074B7 03               [12] 1969 	rr	a
      0074B8 03               [12] 1970 	rr	a
      0074B9 54 03            [12] 1971 	anl	a,#0x03
      0074BB 22               [24] 1972 	ret
                                   1973 
                                   1974 	.area CSEG (CODE)
                                   1975 ; function ak820_outline_0107
      0074BC                       1976 _ak820_outline_0107:
      0074BC 90 08 27         [24] 1977 	mov	dptr,#(_process_action_PARM_2+0x0001)
      0074BF E0               [24] 1978 	movx	a,@dptr
      0074C0 54 0F            [12] 1979 	anl	a,#0x0f
      0074C2 22               [24] 1980 	ret
                                   1981 
                                   1982 	.area CSEG (CODE)
                                   1983 ; function ak820_outline_0126
      0074C3                       1984 _ak820_outline_0126:
      0074C3 90 08 26         [24] 1985 	mov	dptr,#_process_action_PARM_2
      0074C6 E0               [24] 1986 	movx	a,@dptr
      0074C7 FE               [12] 1987 	mov	r6,a
      0074C8 A3               [24] 1988 	inc	dptr
      0074C9 E0               [24] 1989 	movx	a,@dptr
      0074CA 54 03            [12] 1990 	anl	a,#0x03
      0074CC FF               [12] 1991 	mov	r7,a
      0074CD 22               [24] 1992 	ret
                                   1993 
                                   1994 	.area CSEG (CODE)
                                   1995 ; function ak820_outline_0152
      0074CE                       1996 _ak820_outline_0152:
      0074CE 90 08 26         [24] 1997 	mov	dptr,#_process_action_PARM_2
      0074D1 E0               [24] 1998 	movx	a,@dptr
      0074D2 22               [24] 1999 	ret
                                   2000 
                                   2001 	.area CSEG (CODE)
                                   2002 ; function ak820_outline_0160
      0074D3                       2003 _ak820_outline_0160:
      0074D3 90 08 2C         [24] 2004 	mov	dptr,#_register_code_code_10000_703
      0074D6 E0               [24] 2005 	movx	a,@dptr
      0074D7 FF               [12] 2006 	mov	r7,a
      0074D8 22               [24] 2007 	ret
                                   2008 
                                   2009 	.area CSEG (CODE)
                                   2010 ; function ak820_outline_0161
      0074D9                       2011 _ak820_outline_0161:
      0074D9 90 08 2D         [24] 2012 	mov	dptr,#_unregister_code_code_10000_717
      0074DC E0               [24] 2013 	movx	a,@dptr
      0074DD FF               [12] 2014 	mov	r7,a
      0074DE 22               [24] 2015 	ret
