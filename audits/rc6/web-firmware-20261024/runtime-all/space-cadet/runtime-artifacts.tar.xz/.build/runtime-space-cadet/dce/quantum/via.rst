                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module via
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _raw_hid_receive_kb
                                     12 	.globl _vialrgb_save
                                     13 	.globl _vialrgb_set_value
                                     14 	.globl _vialrgb_get_value
                                     15 	.globl _ak820_nvm_schema_fault
                                     16 	.globl _raw_hid_send
                                     17 	.globl _dynamic_keymap_macro_send
                                     18 	.globl _dynamic_keymap_macro_reset
                                     19 	.globl _dynamic_keymap_macro_set_buffer
                                     20 	.globl _dynamic_keymap_macro_get_buffer
                                     21 	.globl _dynamic_keymap_macro_get_buffer_size
                                     22 	.globl _dynamic_keymap_macro_get_count
                                     23 	.globl _dynamic_keymap_set_buffer
                                     24 	.globl _dynamic_keymap_get_buffer
                                     25 	.globl _dynamic_keymap_reset
                                     26 	.globl _dynamic_keymap_set_keycode
                                     27 	.globl _dynamic_keymap_get_keycode
                                     28 	.globl _dynamic_keymap_get_layer_count
                                     29 	.globl _vial_handle_cmd
                                     30 	.globl _eeprom_update_byte
                                     31 	.globl _eeprom_read_byte
                                     32 	.globl _bootloader_jump
                                     33 	.globl _timer_read32
                                     34 	.globl _matrix_get_row
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _raw_hid_receive_PARM_2
                                    280 	.globl _raw_hid_receive_kb_PARM_2
                                    281 	.globl _process_record_via_PARM_2
                                    282 	.globl _via_eeprom_is_valid
                                    283 	.globl _via_eeprom_set_valid
                                    284 	.globl _via_init
                                    285 	.globl _eeconfig_init_via
                                    286 	.globl _via_get_layout_options
                                    287 	.globl _via_set_layout_options_kb
                                    288 	.globl _via_set_layout_options
                                    289 	.globl _process_record_via
                                    290 	.globl _raw_hid_receive
                                    291 ;--------------------------------------------------------
                                    292 ; special function registers
                                    293 ;--------------------------------------------------------
                                    294 	.area RSEG    (ABS,DATA)
      000000                        295 	.org 0x0000
                           0000D0   296 _PSW	=	0x00d0
                           0000E0   297 _ACC	=	0x00e0
                           0000F0   298 _B	=	0x00f0
                           0000FD   299 _A_INV	=	0x00fd
                           000081   300 _SP	=	0x0081
                           000082   301 _DPL	=	0x0082
                           000083   302 _DPH	=	0x0083
                           0000A1   303 _SAFE_MOD	=	0x00a1
                           0000B1   304 _GLOBAL_CFG	=	0x00b1
                           000087   305 _PCON	=	0x0087
                           0000BA   306 _POWER_CFG	=	0x00ba
                           0000B9   307 _CLOCK_CFG	=	0x00b9
                           0000A9   308 _WAKE_CTRL	=	0x00a9
                           0000FE   309 _RESET_KEEP	=	0x00fe
                           0000FF   310 _WDOG_COUNT	=	0x00ff
                           0000A8   311 _IE	=	0x00a8
                           0000B8   312 _IP	=	0x00b8
                           0000E8   313 _IE_EX	=	0x00e8
                           0000E9   314 _IP_EX	=	0x00e9
                           0000B2   315 _GPIO_IE	=	0x00b2
                           008584   316 _ROM_ADDR	=	0x8584
                           000084   317 _ROM_ADDR_L	=	0x0084
                           000085   318 _ROM_ADDR_H	=	0x0085
                           008F8E   319 _ROM_DATA_HI	=	0x8f8e
                           00008E   320 _ROM_DATA_HL	=	0x008e
                           00008F   321 _ROM_DATA_HH	=	0x008f
                           000086   322 _ROM_CTRL	=	0x0086
                           000080   323 _P0	=	0x0080
                           0000C4   324 _P0_MOD_OC	=	0x00c4
                           0000C5   325 _P0_DIR_PU	=	0x00c5
                           000090   326 _P1	=	0x0090
                           000092   327 _P1_MOD_OC	=	0x0092
                           000093   328 _P1_DIR_PU	=	0x0093
                           0000A0   329 _P2	=	0x00a0
                           000094   330 _P2_MOD_OC	=	0x0094
                           000095   331 _P2_DIR_PU	=	0x0095
                           0000B0   332 _P3	=	0x00b0
                           000096   333 _P3_MOD_OC	=	0x0096
                           000097   334 _P3_DIR_PU	=	0x0097
                           0000C0   335 _P4	=	0x00c0
                           0000C2   336 _P4_MOD_OC	=	0x00c2
                           0000C3   337 _P4_DIR_PU	=	0x00c3
                           0000C1   338 _P4_LED_KEY	=	0x00c1
                           0000AA   339 _P5_IN	=	0x00aa
                           0000AB   340 _P5_OUT_PU	=	0x00ab
                           0000AC   341 _P5_DIR	=	0x00ac
                           0000AD   342 _P6_IN	=	0x00ad
                           0000AE   343 _P6_OUT_PU	=	0x00ae
                           0000AF   344 _P6_DIR	=	0x00af
                           0000F1   345 _P7	=	0x00f1
                           0000A2   346 _XBUS_AUX	=	0x00a2
                           000088   347 _TCON	=	0x0088
                           000089   348 _TMOD	=	0x0089
                           00008A   349 _TL0	=	0x008a
                           00008B   350 _TL1	=	0x008b
                           00008C   351 _TH0	=	0x008c
                           00008D   352 _TH1	=	0x008d
                           000098   353 _SCON	=	0x0098
                           000099   354 _SBUF	=	0x0099
                           0000C8   355 _T2CON	=	0x00c8
                           0000C9   356 _T2MOD	=	0x00c9
                           00CBCA   357 _RCAP2	=	0xcbca
                           0000CA   358 _RCAP2L	=	0x00ca
                           0000CB   359 _RCAP2H	=	0x00cb
                           00CDCC   360 _T2COUNT	=	0xcdcc
                           0000CC   361 _TL2	=	0x00cc
                           0000CD   362 _TH2	=	0x00cd
                           00CFCE   363 _T2CAP1	=	0xcfce
                           0000CE   364 _T2CAP1L	=	0x00ce
                           0000CF   365 _T2CAP1H	=	0x00cf
                           0000F8   366 _SPI0_STAT	=	0x00f8
                           0000F9   367 _SPI0_DATA	=	0x00f9
                           0000FA   368 _SPI0_CTRL	=	0x00fa
                           0000FB   369 _SPI0_CK_SE	=	0x00fb
                           0000FC   370 _SPI0_SETUP	=	0x00fc
                           0000BC   371 _SCON1	=	0x00bc
                           0000BD   372 _SBUF1	=	0x00bd
                           0000BE   373 _SBAUD1	=	0x00be
                           0000BF   374 _SIF1	=	0x00bf
                           0000B4   375 _SPI1_STAT	=	0x00b4
                           0000B5   376 _SPI1_DATA	=	0x00b5
                           0000B6   377 _SPI1_CTRL	=	0x00b6
                           0000B7   378 _SPI1_CK_SE	=	0x00b7
                           0000F3   379 _ADC_CTRL	=	0x00f3
                           00F5F4   380 _ADC_DAT	=	0xf5f4
                           0000F4   381 _ADC_DAT_L	=	0x00f4
                           0000F5   382 _ADC_DAT_H	=	0x00f5
                           0000F6   383 _ADC_CHAN	=	0x00f6
                           0000A6   384 _LED_COMMON	=	0x00a6
                           0000A7   385 _LED_PWM_OE	=	0x00a7
                           00C7C6   386 _LED_DMA	=	0xc7c6
                           0000C6   387 _LED_DMA_L	=	0x00c6
                           0000C7   388 _LED_DMA_H	=	0x00c7
                           0000F7   389 _LED_STATUS	=	0x00f7
                           0000B3   390 _I2CX_INT	=	0x00b3
                           0000BB   391 _I2CS_INT_ST	=	0x00bb
                                    392 ;--------------------------------------------------------
                                    393 ; special function bits
                                    394 ;--------------------------------------------------------
                                    395 	.area RSEG    (ABS,DATA)
      000000                        396 	.org 0x0000
                           0000D7   397 _CY	=	0x00d7
                           0000D6   398 _AC	=	0x00d6
                           0000D5   399 _F0	=	0x00d5
                           0000D4   400 _RS1	=	0x00d4
                           0000D3   401 _RS0	=	0x00d3
                           0000D2   402 _OV	=	0x00d2
                           0000D1   403 _F1	=	0x00d1
                           0000D0   404 _P	=	0x00d0
                           0000AF   405 _EA	=	0x00af
                           0000AE   406 _E_DIS	=	0x00ae
                           0000AD   407 _ET2	=	0x00ad
                           0000AC   408 _ES	=	0x00ac
                           0000AB   409 _ET1	=	0x00ab
                           0000AA   410 _EX1	=	0x00aa
                           0000A9   411 _ET0	=	0x00a9
                           0000A8   412 _EX0	=	0x00a8
                           0000BF   413 _PH_FLAG	=	0x00bf
                           0000BE   414 _PL_FLAG	=	0x00be
                           0000BD   415 _PT2	=	0x00bd
                           0000BC   416 _PS	=	0x00bc
                           0000BB   417 _PT1	=	0x00bb
                           0000BA   418 _PX1	=	0x00ba
                           0000B9   419 _PT0	=	0x00b9
                           0000B8   420 _PX0	=	0x00b8
                           0000EF   421 _IE_WDOG	=	0x00ef
                           0000EE   422 _IE_GPIO	=	0x00ee
                           0000ED   423 _IE_PWM_I2C	=	0x00ed
                           0000EC   424 _IE_UART1	=	0x00ec
                           0000EB   425 _IE_ADC	=	0x00eb
                           0000E9   426 _IE_USB	=	0x00e9
                           0000E8   427 _IE_SPI0	=	0x00e8
                           000087   428 _P0_7	=	0x0087
                           000086   429 _P0_6	=	0x0086
                           000085   430 _P0_5	=	0x0085
                           000084   431 _P0_4	=	0x0084
                           000083   432 _P0_3	=	0x0083
                           000082   433 _P0_2	=	0x0082
                           000081   434 _P0_1	=	0x0081
                           000080   435 _P0_0	=	0x0080
                           000081   436 _SDA0	=	0x0081
                           000080   437 _SCL0	=	0x0080
                           000083   438 _TXD_	=	0x0083
                           000082   439 _RXD_	=	0x0082
                           000085   440 _AIN13	=	0x0085
                           000084   441 _AIN12	=	0x0084
                           000083   442 _AIN11	=	0x0083
                           000082   443 _AIN10	=	0x0082
                           000081   444 _AIN9	=	0x0081
                           000080   445 _AIN8	=	0x0080
                           000097   446 _P1_7	=	0x0097
                           000096   447 _P1_6	=	0x0096
                           000095   448 _P1_5	=	0x0095
                           000094   449 _P1_4	=	0x0094
                           000093   450 _P1_3	=	0x0093
                           000092   451 _P1_2	=	0x0092
                           000091   452 _P1_1	=	0x0091
                           000090   453 _P1_0	=	0x0090
                           000097   454 _TXD1_	=	0x0097
                           000096   455 _RXD1_	=	0x0096
                           000097   456 _SCK	=	0x0097
                           000096   457 _MISO	=	0x0096
                           000095   458 _MOSI	=	0x0095
                           000094   459 _SCS	=	0x0094
                           000092   460 _INT0_	=	0x0092
                           000091   461 _T2EX	=	0x0091
                           000091   462 _CAP2	=	0x0091
                           000090   463 _T2	=	0x0090
                           000090   464 _CAP1	=	0x0090
                           000097   465 _AIN7	=	0x0097
                           000096   466 _AIN6	=	0x0096
                           000095   467 _AIN5	=	0x0095
                           000094   468 _AIN4	=	0x0094
                           000093   469 _AIN3	=	0x0093
                           000092   470 _AIN2	=	0x0092
                           000091   471 _AIN1	=	0x0091
                           000090   472 _AIN0	=	0x0090
                           0000A7   473 _P2_7	=	0x00a7
                           0000A6   474 _P2_6	=	0x00a6
                           0000A5   475 _P2_5	=	0x00a5
                           0000A4   476 _P2_4	=	0x00a4
                           0000A3   477 _P2_3	=	0x00a3
                           0000A2   478 _P2_2	=	0x00a2
                           0000A1   479 _P2_1	=	0x00a1
                           0000A0   480 _P2_0	=	0x00a0
                           0000A7   481 _TXD1	=	0x00a7
                           0000A6   482 _RXD1	=	0x00a6
                           0000A5   483 _T2EX_	=	0x00a5
                           0000A5   484 _CAP2_	=	0x00a5
                           0000A4   485 _T2_	=	0x00a4
                           0000A4   486 _CAP1_	=	0x00a4
                           0000B7   487 _P3_7	=	0x00b7
                           0000B6   488 _P3_6	=	0x00b6
                           0000B5   489 _P3_5	=	0x00b5
                           0000B4   490 _P3_4	=	0x00b4
                           0000B3   491 _P3_3	=	0x00b3
                           0000B2   492 _P3_2	=	0x00b2
                           0000B1   493 _P3_1	=	0x00b1
                           0000B0   494 _P3_0	=	0x00b0
                           0000B7   495 _SCK1	=	0x00b7
                           0000B6   496 _MISO1	=	0x00b6
                           0000B5   497 _MOSI1	=	0x00b5
                           0000B5   498 _T1	=	0x00b5
                           0000B4   499 _T0	=	0x00b4
                           0000B3   500 _INT1	=	0x00b3
                           0000B2   501 _INT0	=	0x00b2
                           0000B1   502 _TXD	=	0x00b1
                           0000B0   503 _RXD	=	0x00b0
                           0000C6   504 _P4_6	=	0x00c6
                           0000C5   505 _P4_5	=	0x00c5
                           0000C4   506 _P4_4	=	0x00c4
                           0000C3   507 _P4_3	=	0x00c3
                           0000C2   508 _P4_2	=	0x00c2
                           0000C1   509 _P4_1	=	0x00c1
                           0000C0   510 _P4_0	=	0x00c0
                           00008F   511 _TF1	=	0x008f
                           00008E   512 _TR1	=	0x008e
                           00008D   513 _TF0	=	0x008d
                           00008C   514 _TR0	=	0x008c
                           00008B   515 _IE1	=	0x008b
                           00008A   516 _IT1	=	0x008a
                           000089   517 _IE0	=	0x0089
                           000088   518 _IT0	=	0x0088
                           00009F   519 _SM0	=	0x009f
                           00009E   520 _SM1	=	0x009e
                           00009D   521 _SM2	=	0x009d
                           00009C   522 _REN	=	0x009c
                           00009B   523 _TB8	=	0x009b
                           00009A   524 _RB8	=	0x009a
                           000099   525 _TI	=	0x0099
                           000098   526 _RI	=	0x0098
                           0000CF   527 _TF2	=	0x00cf
                           0000CF   528 _CAP1F	=	0x00cf
                           0000CE   529 _EXF2	=	0x00ce
                           0000CD   530 _RCLK	=	0x00cd
                           0000CC   531 _TCLK	=	0x00cc
                           0000CB   532 _EXEN2	=	0x00cb
                           0000CA   533 _TR2	=	0x00ca
                           0000C9   534 _C_T2	=	0x00c9
                           0000C8   535 _CP_RL2	=	0x00c8
                           0000FF   536 _S0_FST_ACT	=	0x00ff
                           0000FE   537 _S0_IF_OV	=	0x00fe
                           0000FD   538 _S0_IF_FIRST	=	0x00fd
                           0000FC   539 _S0_IF_BYTE	=	0x00fc
                           0000FB   540 _S0_FREE	=	0x00fb
                           0000FA   541 _S0_T_FIFO	=	0x00fa
                           0000F8   542 _S0_R_FIFO	=	0x00f8
                           0000F7   543 _ADC_START	=	0x00f7
                                    544 ;--------------------------------------------------------
                                    545 ; overlayable register banks
                                    546 ;--------------------------------------------------------
                                    547 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        548 	.ds 8
                                    549 ;--------------------------------------------------------
                                    550 ; internal ram data
                                    551 ;--------------------------------------------------------
                                    552 	.area DSEG    (DATA)
      000038                        553 _raw_hid_receive_sloc0_1_0:
      000038                        554 	.ds 4
      00003C                        555 _raw_hid_receive_sloc1_1_0:
      00003C                        556 	.ds 1
      00003D                        557 _raw_hid_receive_sloc2_1_0:
      00003D                        558 	.ds 1
      00003E                        559 _raw_hid_receive_sloc3_1_0:
      00003E                        560 	.ds 2
      000040                        561 _raw_hid_receive_sloc4_1_0:
      000040                        562 	.ds 2
                                    563 ;--------------------------------------------------------
                                    564 ; overlayable items in internal ram
                                    565 ;--------------------------------------------------------
                                    566 ;--------------------------------------------------------
                                    567 ; indirectly addressable internal ram data
                                    568 ;--------------------------------------------------------
                                    569 	.area ISEG    (DATA)
                                    570 ;--------------------------------------------------------
                                    571 ; absolute internal ram data
                                    572 ;--------------------------------------------------------
                                    573 	.area IABS    (ABS,DATA)
                                    574 	.area IABS    (ABS,DATA)
                                    575 ;--------------------------------------------------------
                                    576 ; bit data
                                    577 ;--------------------------------------------------------
                                    578 	.area BSEG    (BIT)
      000028                        579 _via_eeprom_is_valid_sloc0_1_0:
      000028                        580 	.ds 1
                                    581 ;--------------------------------------------------------
                                    582 ; paged external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area PSEG    (PAG,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; uninitialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XSEG    (XDATA)
      000C33                        589 _via_eeprom_set_valid_valid_10000_609:
      000C33                        590 	.ds 1
      000C34                        591 _via_set_layout_options_value_10000_625:
      000C34                        592 	.ds 4
      000C38                        593 _process_record_via_PARM_2:
      000C38                        594 	.ds 3
      000C3B                        595 _process_record_via_keycode_10000_627:
      000C3B                        596 	.ds 2
      000C3D                        597 _raw_hid_receive_kb_PARM_2:
      000C3D                        598 	.ds 1
      000C3E                        599 _raw_hid_receive_kb_data_10000_633:
      000C3E                        600 	.ds 3
      000C41                        601 _raw_hid_receive_PARM_2:
      000C41                        602 	.ds 1
      000C42                        603 _raw_hid_receive_packet_10000_635:
      000C42                        604 	.ds 3
                                    605 ;--------------------------------------------------------
                                    606 ; absolute external ram data
                                    607 ;--------------------------------------------------------
                                    608 	.area XABS    (ABS,XDATA)
                                    609 ;--------------------------------------------------------
                                    610 ; initialized external ram data
                                    611 ;--------------------------------------------------------
                                    612 	.area XISEG   (XDATA)
                                    613 	.area HOME    (CODE)
                                    614 	.area GSINIT0 (CODE)
                                    615 	.area GSINIT1 (CODE)
                                    616 	.area GSINIT2 (CODE)
                                    617 	.area GSINIT3 (CODE)
                                    618 	.area GSINIT4 (CODE)
                                    619 	.area GSINIT5 (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area CSEG    (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; global & static initialisations
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area GSINIT  (CODE)
                                    628 	.area GSFINAL (CODE)
                                    629 	.area GSINIT  (CODE)
                                    630 ;--------------------------------------------------------
                                    631 ; Home
                                    632 ;--------------------------------------------------------
                                    633 	.area HOME    (CODE)
                                    634 	.area HOME    (CODE)
                                    635 ;--------------------------------------------------------
                                    636 ; code
                                    637 ;--------------------------------------------------------
                                    638 	.area CSEG    (CODE)
                                    639 ;------------------------------------------------------------
                                    640 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    641 ;------------------------------------------------------------
                                    642 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    643 ;------------------------------------------------------------
                                    644 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    645 ;	-----------------------------------------
                           000007   646 	ar7 = 0x07
                           000006   647 	ar6 = 0x06
                           000005   648 	ar5 = 0x05
                           000004   649 	ar4 = 0x04
                           000003   650 	ar3 = 0x03
                           000002   651 	ar2 = 0x02
                           000001   652 	ar1 = 0x01
                           000000   653 	ar0 = 0x00
                                    654 ;	 function via_eeprom_is_valid
                                    655 ;	-----------------------------------------
      00A255                        656 _via_eeprom_is_valid:
                                    657 ;	quantum/via.c:103: return (eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0) == magic0 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1) == magic1 && eeprom_read_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2) == magic2);
      00A255 90 00 25         [24]  658 	mov	dptr,#0x0025
      00A258 75 F0 00         [24]  659 	mov	b, #0x00
      00A25B 12 40 6F         [24]  660 	lcall	_eeprom_read_byte
      00A25E AF 82            [24]  661 	mov	r7, dpl
      00A260 BF 02 1E         [24]  662 	cjne	r7,#0x02,00103$
      00A263 90 00 26         [24]  663 	mov	dptr,#0x0026
      00A266 75 F0 00         [24]  664 	mov	b, #0x00
      00A269 12 40 6F         [24]  665 	lcall	_eeprom_read_byte
      00A26C AF 82            [24]  666 	mov	r7, dpl
      00A26E BF 20 10         [24]  667 	cjne	r7,#0x20,00103$
      00A271 90 00 27         [24]  668 	mov	dptr,#0x0027
      00A274 75 F0 00         [24]  669 	mov	b, #0x00
      00A277 12 40 6F         [24]  670 	lcall	_eeprom_read_byte
      00A27A AF 82            [24]  671 	mov	r7, dpl
      00A27C BF 08 02         [24]  672 	cjne	r7,#0x08,00126$
      00A27F 80 04            [24]  673 	sjmp	00104$
      00A281                        674 00126$:
      00A281                        675 00103$:
                                    676 ;	assignBit
      00A281 C2 28            [12]  677 	clr	_via_eeprom_is_valid_sloc0_1_0
      00A283 80 02            [24]  678 	sjmp	00105$
      00A285                        679 00104$:
                                    680 ;	assignBit
      00A285 D2 28            [12]  681 	setb	_via_eeprom_is_valid_sloc0_1_0
      00A287                        682 00105$:
      00A287 A2 28            [12]  683 	mov	c,_via_eeprom_is_valid_sloc0_1_0
      00A289 12 38 B1         [24]  684 	lcall	_ak820_outline_0150
                                    685 ;	quantum/via.c:104: }
      00A28C 22               [24]  686 	ret
                                    687 ;------------------------------------------------------------
                                    688 ;Allocation info for local variables in function 'via_eeprom_set_valid'
                                    689 ;------------------------------------------------------------
                                    690 ;valid         Allocated with name '_via_eeprom_set_valid_valid_10000_609'
                                    691 ;magic0        Allocated with name '_via_eeprom_set_valid_magic0_10000_610'
                                    692 ;magic1        Allocated with name '_via_eeprom_set_valid_magic1_10000_610'
                                    693 ;magic2        Allocated with name '_via_eeprom_set_valid_magic2_10000_610'
                                    694 ;------------------------------------------------------------
                                    695 ;	quantum/via.c:108: void via_eeprom_set_valid(__xdata bool valid) {
                                    696 ;	-----------------------------------------
                                    697 ;	 function via_eeprom_set_valid
                                    698 ;	-----------------------------------------
      00A28D                        699 _via_eeprom_set_valid:
      00A28D E5 82            [12]  700 	mov	a,dpl
      00A28F 90 0C 33         [24]  701 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A292 F0               [24]  702 	movx	@dptr,a
                                    703 ;	quantum/via.c:120: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 0, valid ? magic0 : 0xFF);
      00A293 E0               [24]  704 	movx	a,@dptr
      00A294 60 04            [24]  705 	jz	00103$
      00A296 7F 02            [12]  706 	mov	r7,#0x02
      00A298 80 02            [24]  707 	sjmp	00104$
      00A29A                        708 00103$:
      00A29A 7F FF            [12]  709 	mov	r7,#0xff
      00A29C                        710 00104$:
      00A29C 90 06 92         [24]  711 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A29F EF               [12]  712 	mov	a,r7
      00A2A0 F0               [24]  713 	movx	@dptr,a
      00A2A1 90 00 25         [24]  714 	mov	dptr,#0x0025
      00A2A4 75 F0 00         [24]  715 	mov	b, #0x00
      00A2A7 12 4C 8E         [24]  716 	lcall	_eeprom_update_byte
                                    717 ;	quantum/via.c:121: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 1, valid ? magic1 : 0xFF);
      00A2AA 90 0C 33         [24]  718 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A2AD E0               [24]  719 	movx	a,@dptr
      00A2AE 60 04            [24]  720 	jz	00105$
      00A2B0 7F 20            [12]  721 	mov	r7,#0x20
      00A2B2 80 02            [24]  722 	sjmp	00106$
      00A2B4                        723 00105$:
      00A2B4 7F FF            [12]  724 	mov	r7,#0xff
      00A2B6                        725 00106$:
      00A2B6 90 06 92         [24]  726 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A2B9 EF               [12]  727 	mov	a,r7
      00A2BA F0               [24]  728 	movx	@dptr,a
      00A2BB 90 00 26         [24]  729 	mov	dptr,#0x0026
      00A2BE 75 F0 00         [24]  730 	mov	b, #0x00
      00A2C1 12 4C 8E         [24]  731 	lcall	_eeprom_update_byte
                                    732 ;	quantum/via.c:122: eeprom_update_byte((uint8_t *)VIA_EEPROM_MAGIC_ADDR + 2, valid ? magic2 : 0xFF);
      00A2C4 90 0C 33         [24]  733 	mov	dptr,#_via_eeprom_set_valid_valid_10000_609
      00A2C7 E0               [24]  734 	movx	a,@dptr
      00A2C8 60 04            [24]  735 	jz	00107$
      00A2CA 7F 08            [12]  736 	mov	r7,#0x08
      00A2CC 80 02            [24]  737 	sjmp	00108$
      00A2CE                        738 00107$:
      00A2CE 7F FF            [12]  739 	mov	r7,#0xff
      00A2D0                        740 00108$:
      00A2D0 90 06 92         [24]  741 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A2D3 EF               [12]  742 	mov	a,r7
      00A2D4 F0               [24]  743 	movx	@dptr,a
      00A2D5 90 00 27         [24]  744 	mov	dptr,#0x0027
      00A2D8 75 F0 00         [24]  745 	mov	b, #0x00
                                    746 ;	quantum/via.c:123: }
      00A2DB 02 4C 8E         [24]  747 	ljmp	_eeprom_update_byte
                                    748 ;------------------------------------------------------------
                                    749 ;Allocation info for local variables in function 'via_init_kb'
                                    750 ;------------------------------------------------------------
                                    751 ;	quantum/via.c:131: __attribute__((weak)) void via_init_kb(void) {}
                                    752 ;	-----------------------------------------
                                    753 ;	 function via_init
                                    754 ;	-----------------------------------------
      00A2DE                        755 _via_init:
                                    756 ;	quantum/via.c:138: via_set_layout_options_kb(via_get_layout_options());
      00A2DE 12 A3 07         [24]  757 	lcall	_via_get_layout_options
      00A2E1 12 A3 1F         [24]  758 	lcall	_via_set_layout_options_kb
                                    759 ;	quantum/via.c:142: if (!via_eeprom_is_valid()) {
      00A2E4 12 A2 55         [24]  760 	lcall	_via_eeprom_is_valid
      00A2E7 E5 82            [12]  761 	mov	a, dpl
      00A2E9 70 03            [24]  762 	jnz	00103$
                                    763 ;	quantum/via.c:147: ak820_nvm_schema_fault();
                                    764 ;	quantum/via.c:152: }
      00A2EB 02 3E 1E         [24]  765 	ljmp	_ak820_nvm_schema_fault
      00A2EE                        766 00103$:
      00A2EE 22               [24]  767 	ret
                                    768 ;------------------------------------------------------------
                                    769 ;Allocation info for local variables in function 'eeconfig_init_via'
                                    770 ;------------------------------------------------------------
                                    771 ;	quantum/via.c:154: void eeconfig_init_via(void) {
                                    772 ;	-----------------------------------------
                                    773 ;	 function eeconfig_init_via
                                    774 ;	-----------------------------------------
      00A2EF                        775 _eeconfig_init_via:
                                    776 ;	quantum/via.c:156: via_eeprom_set_valid(false);
      00A2EF 75 82 00         [24]  777 	mov	dpl, #0x00
      00A2F2 12 A2 8D         [24]  778 	lcall	_via_eeprom_set_valid
                                    779 ;	quantum/via.c:158: via_set_layout_options(VIA_EEPROM_LAYOUT_OPTIONS_DEFAULT);
      00A2F5 12 8D B0         [24]  780 	lcall	_ak820_outline_0146
      00A2F8 12 A3 20         [24]  781 	lcall	_via_set_layout_options
                                    782 ;	quantum/via.c:160: dynamic_keymap_reset();
      00A2FB 12 84 24         [24]  783 	lcall	_dynamic_keymap_reset
                                    784 ;	quantum/via.c:162: dynamic_keymap_macro_reset();
      00A2FE 12 88 96         [24]  785 	lcall	_dynamic_keymap_macro_reset
                                    786 ;	quantum/via.c:164: via_eeprom_set_valid(true);
      00A301 75 82 01         [24]  787 	mov	dpl, #0x01
                                    788 ;	quantum/via.c:165: }
      00A304 02 A2 8D         [24]  789 	ljmp	_via_eeprom_set_valid
                                    790 ;------------------------------------------------------------
                                    791 ;Allocation info for local variables in function 'via_get_layout_options'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/via.c:169: uint32_t via_get_layout_options(void) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function via_get_layout_options
                                    796 ;	-----------------------------------------
      00A307                        797 _via_get_layout_options:
                                    798 ;	quantum/via.c:173: return eeprom_read_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR);
      00A307 90 00 28         [24]  799 	mov	dptr,#0x0028
      00A30A 75 F0 00         [24]  800 	mov	b, #0x00
      00A30D 12 40 6F         [24]  801 	lcall	_eeprom_read_byte
      00A310 AF 82            [24]  802 	mov	r7, dpl
      00A312 7E 00            [12]  803 	mov	r6,#0x00
      00A314 7D 00            [12]  804 	mov	r5,#0x00
      00A316 7C 00            [12]  805 	mov	r4,#0x00
      00A318 12 43 6C         [24]  806 	lcall	_ak820_outline_0151
      00A31B 8D F0            [24]  807 	mov	b, r5
      00A31D EC               [12]  808 	mov	a, r4
                                    809 ;	quantum/via.c:185: }
      00A31E 22               [24]  810 	ret
                                    811 ;------------------------------------------------------------
                                    812 ;Allocation info for local variables in function 'via_set_layout_options_kb'
                                    813 ;------------------------------------------------------------
                                    814 ;value         Allocated with name '_via_set_layout_options_kb_value_10000_622'
                                    815 ;------------------------------------------------------------
                                    816 ;	quantum/via.c:187: __attribute__((weak)) void via_set_layout_options_kb(uint32_t value) {}
                                    817 ;	-----------------------------------------
                                    818 ;	 function via_set_layout_options_kb
                                    819 ;	-----------------------------------------
      00A31F                        820 _via_set_layout_options_kb:
      00A31F 22               [24]  821 	ret
                                    822 ;------------------------------------------------------------
                                    823 ;Allocation info for local variables in function 'via_set_layout_options'
                                    824 ;------------------------------------------------------------
                                    825 ;value         Allocated with name '_via_set_layout_options_value_10000_625'
                                    826 ;------------------------------------------------------------
                                    827 ;	quantum/via.c:189: void via_set_layout_options(uint32_t value) {
                                    828 ;	-----------------------------------------
                                    829 ;	 function via_set_layout_options
                                    830 ;	-----------------------------------------
      00A320                        831 _via_set_layout_options:
      00A320 12 8D A8         [24]  832 	lcall	_ak820_outline_0114
      00A323 90 0C 34         [24]  833 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A326 12 8D 96         [24]  834 	lcall	_ak820_outline_0043
                                    835 ;	quantum/via.c:192: eeprom_update_byte((uint8_t *)VIA_EEPROM_LAYOUT_OPTIONS_ADDR, (uint8_t)value);
      00A329 90 0C 34         [24]  836 	mov	dptr,#_via_set_layout_options_value_10000_625
      00A32C E0               [24]  837 	movx	a,@dptr
      00A32D 90 06 92         [24]  838 	mov	dptr,#_eeprom_update_byte_PARM_2
      00A330 F0               [24]  839 	movx	@dptr,a
      00A331 90 00 28         [24]  840 	mov	dptr,#0x0028
      00A334 75 F0 00         [24]  841 	mov	b, #0x00
                                    842 ;	quantum/via.c:202: }
      00A337 02 4C 8E         [24]  843 	ljmp	_eeprom_update_byte
                                    844 ;------------------------------------------------------------
                                    845 ;Allocation info for local variables in function 'process_record_via'
                                    846 ;------------------------------------------------------------
                                    847 ;record        Allocated with name '_process_record_via_PARM_2'
                                    848 ;keycode       Allocated with name '_process_record_via_keycode_10000_627'
                                    849 ;id            Allocated with name '_process_record_via_id_50000_632'
                                    850 ;------------------------------------------------------------
                                    851 ;	quantum/via.c:205: bool process_record_via(uint16_t keycode, keyrecord_t *record) {
                                    852 ;	-----------------------------------------
                                    853 ;	 function process_record_via
                                    854 ;	-----------------------------------------
      00A33A                        855 _process_record_via:
      00A33A 12 38 7D         [24]  856 	lcall	_ak820_outline_0103
      00A33D 90 0C 3B         [24]  857 	mov	dptr,#_process_record_via_keycode_10000_627
      00A340 12 38 82         [24]  858 	lcall	_ak820_outline_0104
                                    859 ;	quantum/via.c:207: if (record->event.pressed) {
      00A343 90 0C 38         [24]  860 	mov	dptr,#_process_record_via_PARM_2
      00A346 12 4D 9B         [24]  861 	lcall	_ak820_outline_0012
      00A349 74 05            [12]  862 	mov	a,#0x05
      00A34B 12 38 B6         [24]  863 	lcall	_ak820_outline_0153
      00A34E 12 6C 05         [24]  864 	lcall	_ak820_outline_0046
      00A351 12 B5 CE         [24]  865 	lcall	__gptrget
      00A354 60 1D            [24]  866 	jz	00105$
                                    867 ;	quantum/via.c:208: if (keycode >= QK_MACRO && keycode <= QK_MACRO_MAX) {
      00A356 90 0C 3B         [24]  868 	mov	dptr,#_process_record_via_keycode_10000_627
      00A359 12 46 F6         [24]  869 	lcall	_ak820_outline_0008
      00A35C 74 89            [12]  870 	mov	a,#0x100 - 0x77
      00A35E 2D               [12]  871 	add	a,r5
      00A35F 50 12            [24]  872 	jnc	00105$
      00A361 C3               [12]  873 	clr	c
      00A362 74 7F            [12]  874 	mov	a,#0x7f
      00A364 9C               [12]  875 	subb	a,r4
      00A365 74 77            [12]  876 	mov	a,#0x77
      00A367 9D               [12]  877 	subb	a,r5
      00A368 40 09            [24]  878 	jc	00105$
                                    879 ;	free result
                                    880 ;	quantum/via.c:209: uint8_t id = keycode - QK_MACRO;
                                    881 ;	quantum/via.c:210: dynamic_keymap_macro_send(id);
      00A36A 8E 82            [24]  882 	mov	dpl, r6
      00A36C 12 88 BC         [24]  883 	lcall	_dynamic_keymap_macro_send
                                    884 ;	quantum/via.c:211: return false;
      00A36F 75 82 00         [24]  885 	mov	dpl, #0x00
      00A372 22               [24]  886 	ret
      00A373                        887 00105$:
                                    888 ;	quantum/via.c:215: return true;
      00A373 75 82 01         [24]  889 	mov	dpl, #0x01
                                    890 ;	quantum/via.c:216: }
      00A376 22               [24]  891 	ret
                                    892 ;------------------------------------------------------------
                                    893 ;Allocation info for local variables in function 'raw_hid_receive_kb'
                                    894 ;------------------------------------------------------------
                                    895 ;length        Allocated with name '_raw_hid_receive_kb_PARM_2'
                                    896 ;data          Allocated with name '_raw_hid_receive_kb_data_10000_633'
                                    897 ;command_id    Allocated with name '_raw_hid_receive_kb_command_id_10000_634'
                                    898 ;------------------------------------------------------------
                                    899 ;	quantum/via.c:221: __attribute__((weak)) void raw_hid_receive_kb(uint8_t *data, uint8_t length) {
                                    900 ;	-----------------------------------------
                                    901 ;	 function raw_hid_receive_kb
                                    902 ;	-----------------------------------------
      00A377                        903 _raw_hid_receive_kb:
      00A377 12 43 0E         [24]  904 	lcall	_ak820_outline_0036
      00A37A 90 0C 3E         [24]  905 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A37D 12 38 2A         [24]  906 	lcall	_ak820_outline_0016
                                    907 ;	quantum/via.c:222: uint8_t *command_id = &(data[0]);
      00A380 90 0C 3E         [24]  908 	mov	dptr,#_raw_hid_receive_kb_data_10000_633
      00A383 12 4D 75         [24]  909 	lcall	_ak820_outline_0001
                                    910 ;	quantum/via.c:223: *command_id         = id_unhandled;
      00A386 74 FF            [12]  911 	mov	a,#0xff
                                    912 ;	quantum/via.c:224: }
      00A388 02 B5 93         [24]  913 	ljmp	__gptrput
                                    914 ;------------------------------------------------------------
                                    915 ;Allocation info for local variables in function 'raw_hid_receive'
                                    916 ;------------------------------------------------------------
                                    917 ;sloc0         Allocated with name '_raw_hid_receive_sloc0_1_0'
                                    918 ;sloc1         Allocated with name '_raw_hid_receive_sloc1_1_0'
                                    919 ;sloc2         Allocated with name '_raw_hid_receive_sloc2_1_0'
                                    920 ;sloc3         Allocated with name '_raw_hid_receive_sloc3_1_0'
                                    921 ;sloc4         Allocated with name '_raw_hid_receive_sloc4_1_0'
                                    922 ;length        Allocated with name '_raw_hid_receive_PARM_2'
                                    923 ;packet        Allocated with name '_raw_hid_receive_packet_10000_635'
                                    924 ;data          Allocated with name '_raw_hid_receive_data_10000_636'
                                    925 ;command_id    Allocated with name '_raw_hid_receive_command_id_10000_636'
                                    926 ;command_data  Allocated with name '_raw_hid_receive_command_data_10000_636'
                                    927 ;cmd           Allocated with name '_raw_hid_receive_cmd_30001_642'
                                    928 ;value         Allocated with name '_raw_hid_receive_value_70000_650'
                                    929 ;value         Allocated with name '_raw_hid_receive_value_70000_651'
                                    930 ;i             Allocated with name '_raw_hid_receive_i_70001_654'
                                    931 ;row           Allocated with name '_raw_hid_receive_row_80001_655'
                                    932 ;value         Allocated with name '_raw_hid_receive_value_90001_656'
                                    933 ;value         Allocated with name '_raw_hid_receive_value_70000_661'
                                    934 ;keycode       Allocated with name '_raw_hid_receive_keycode_40000_663'
                                    935 ;size          Allocated with name '_raw_hid_receive_size_40000_672'
                                    936 ;offset        Allocated with name '_raw_hid_receive_offset_40000_673'
                                    937 ;size          Allocated with name '_raw_hid_receive_size_40000_673'
                                    938 ;offset        Allocated with name '_raw_hid_receive_offset_40001_678'
                                    939 ;size          Allocated with name '_raw_hid_receive_size_40001_678'
                                    940 ;offset        Allocated with name '_raw_hid_receive_offset_40000_683'
                                    941 ;size          Allocated with name '_raw_hid_receive_size_40000_683'
                                    942 ;offset        Allocated with name '_raw_hid_receive_offset_40000_685'
                                    943 ;size          Allocated with name '_raw_hid_receive_size_40000_685'
                                    944 ;i             Allocated with name '_raw_hid_receive_i_60000_690'
                                    945 ;------------------------------------------------------------
                                    946 ;	quantum/via.c:233: void raw_hid_receive(uint8_t *packet, uint8_t length) {
                                    947 ;	-----------------------------------------
                                    948 ;	 function raw_hid_receive
                                    949 ;	-----------------------------------------
      00A38B                        950 _raw_hid_receive:
      00A38B 12 43 0E         [24]  951 	lcall	_ak820_outline_0036
      00A38E 90 0C 42         [24]  952 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A391 12 38 2A         [24]  953 	lcall	_ak820_outline_0016
                                    954 ;	quantum/via.c:236: uint8_t __xdata *data = (uint8_t __xdata *)packet;
      00A394 90 0C 42         [24]  955 	mov	dptr,#_raw_hid_receive_packet_10000_635
      00A397 12 38 42         [24]  956 	lcall	_ak820_outline_0051
                                    957 ;	quantum/via.c:238: uint8_t __xdata *command_data = &data[1];
      00A39A 74 01            [12]  958 	mov	a,#0x01
      00A39C 12 43 71         [24]  959 	lcall	_ak820_outline_0154
                                    960 ;	quantum/via.c:245: if (length != 32) return;
      00A39F 90 0C 41         [24]  961 	mov	dptr,#_raw_hid_receive_PARM_2
      00A3A2 E0               [24]  962 	movx	a,@dptr
      00A3A3 FB               [12]  963 	mov	r3,a
      00A3A4 BB 20 02         [24]  964 	cjne	r3,#0x20,00520$
      00A3A7 80 01            [24]  965 	sjmp	00102$
      00A3A9                        966 00520$:
      00A3A9 22               [24]  967 	ret
      00A3AA                        968 00102$:
                                    969 ;	quantum/via.c:249: if (vial_unlock_in_progress) {
      00A3AA 90 0E 0F         [24]  970 	mov	dptr,#_vial_unlock_in_progress
      00A3AD E0               [24]  971 	movx	a,@dptr
      00A3AE 60 32            [24]  972 	jz	00114$
                                    973 ;	quantum/via.c:250: if (data[0] != id_vial_prefix) {
      00A3B0 12 38 87         [24]  974 	lcall	_ak820_outline_0112
      00A3B3 E0               [24]  975 	movx	a,@dptr
      00A3B4 FA               [12]  976 	mov	r2,a
      00A3B5 BA FE 02         [24]  977 	cjne	r2,#0xfe,00522$
      00A3B8 80 01            [24]  978 	sjmp	00104$
      00A3BA                        979 00522$:
                                    980 ;	quantum/via.c:252: return;
      00A3BA 22               [24]  981 	ret
      00A3BB                        982 00104$:
                                    983 ;	quantum/via.c:257: uint8_t cmd = data[1];
      00A3BB 12 43 38         [24]  984 	lcall	_ak820_outline_0090
                                    985 ;	quantum/via.c:258: if (cmd != vial_get_keyboard_id && cmd != vial_get_size && cmd != vial_get_def && cmd != vial_get_unlock_status && cmd != vial_unlock_start && cmd != vial_unlock_poll && cmd != vial_lock)
      00A3BE FA               [12]  986 	mov	r2,a
      00A3BF 60 21            [24]  987 	jz	00114$
      00A3C1 BA 01 02         [24]  988 	cjne	r2,#0x01,00524$
      00A3C4 80 1C            [24]  989 	sjmp	00114$
      00A3C6                        990 00524$:
      00A3C6 BA 02 02         [24]  991 	cjne	r2,#0x02,00525$
      00A3C9 80 17            [24]  992 	sjmp	00114$
      00A3CB                        993 00525$:
      00A3CB BA 05 02         [24]  994 	cjne	r2,#0x05,00526$
      00A3CE 80 12            [24]  995 	sjmp	00114$
      00A3D0                        996 00526$:
      00A3D0 BA 06 02         [24]  997 	cjne	r2,#0x06,00527$
      00A3D3 80 0D            [24]  998 	sjmp	00114$
      00A3D5                        999 00527$:
      00A3D5 BA 07 02         [24] 1000 	cjne	r2,#0x07,00528$
      00A3D8 80 08            [24] 1001 	sjmp	00114$
      00A3DA                       1002 00528$:
      00A3DA BA 08 02         [24] 1003 	cjne	r2,#0x08,00529$
      00A3DD 80 03            [24] 1004 	sjmp	00530$
      00A3DF                       1005 00529$:
      00A3DF 02 A9 19         [24] 1006 	ljmp	00171$
      00A3E2                       1007 00530$:
                                   1008 ;	quantum/via.c:259: goto skip;
      00A3E2                       1009 00114$:
                                   1010 ;	quantum/via.c:263: switch (*command_id) {
      00A3E2 12 38 87         [24] 1011 	lcall	_ak820_outline_0112
      00A3E5 E0               [24] 1012 	movx	a,@dptr
      00A3E6 FA               [12] 1013 	mov	r2,a
      00A3E7 BA 01 02         [24] 1014 	cjne	r2,#0x01,00531$
      00A3EA 80 6E            [24] 1015 	sjmp	00115$
      00A3EC                       1016 00531$:
      00A3EC BA 02 02         [24] 1017 	cjne	r2,#0x02,00532$
      00A3EF 80 76            [24] 1018 	sjmp	00116$
      00A3F1                       1019 00532$:
      00A3F1 BA 03 03         [24] 1020 	cjne	r2,#0x03,00533$
      00A3F4 02 A5 29         [24] 1021 	ljmp	00125$
      00A3F7                       1022 00533$:
      00A3F7 BA 04 03         [24] 1023 	cjne	r2,#0x04,00534$
      00A3FA 02 A5 C0         [24] 1024 	ljmp	00129$
      00A3FD                       1025 00534$:
      00A3FD BA 05 03         [24] 1026 	cjne	r2,#0x05,00535$
      00A400 02 A5 FA         [24] 1027 	ljmp	00130$
      00A403                       1028 00535$:
      00A403 BA 06 03         [24] 1029 	cjne	r2,#0x06,00536$
      00A406 02 A6 66         [24] 1030 	ljmp	00135$
      00A409                       1031 00536$:
      00A409 BA 07 03         [24] 1032 	cjne	r2,#0x07,00537$
      00A40C 02 A6 78         [24] 1033 	ljmp	00136$
      00A40F                       1034 00537$:
      00A40F BA 08 03         [24] 1035 	cjne	r2,#0x08,00538$
      00A412 02 A6 93         [24] 1036 	ljmp	00137$
      00A415                       1037 00538$:
      00A415 BA 09 03         [24] 1038 	cjne	r2,#0x09,00539$
      00A418 02 A6 AE         [24] 1039 	ljmp	00138$
      00A41B                       1040 00539$:
      00A41B BA 0B 03         [24] 1041 	cjne	r2,#0x0b,00540$
      00A41E 02 A8 A7         [24] 1042 	ljmp	00161$
      00A421                       1043 00540$:
      00A421 BA 0C 03         [24] 1044 	cjne	r2,#0x0c,00541$
      00A424 02 A6 C9         [24] 1045 	ljmp	00139$
      00A427                       1046 00541$:
      00A427 BA 0D 03         [24] 1047 	cjne	r2,#0x0d,00542$
      00A42A 02 A6 EA         [24] 1048 	ljmp	00140$
      00A42D                       1049 00542$:
      00A42D BA 0E 03         [24] 1050 	cjne	r2,#0x0e,00543$
      00A430 02 A7 13         [24] 1051 	ljmp	00141$
      00A433                       1052 00543$:
      00A433 BA 0F 03         [24] 1053 	cjne	r2,#0x0f,00544$
      00A436 02 A7 5B         [24] 1054 	ljmp	00144$
      00A439                       1055 00544$:
      00A439 BA 10 03         [24] 1056 	cjne	r2,#0x10,00545$
      00A43C 02 A7 CA         [24] 1057 	ljmp	00151$
      00A43F                       1058 00545$:
      00A43F BA 11 03         [24] 1059 	cjne	r2,#0x11,00546$
      00A442 02 A7 E3         [24] 1060 	ljmp	00154$
      00A445                       1061 00546$:
      00A445 BA 12 03         [24] 1062 	cjne	r2,#0x12,00547$
      00A448 02 A8 04         [24] 1063 	ljmp	00155$
      00A44B                       1064 00547$:
      00A44B BA 13 03         [24] 1065 	cjne	r2,#0x13,00548$
      00A44E 02 A8 4C         [24] 1066 	ljmp	00158$
      00A451                       1067 00548$:
      00A451 BA FE 03         [24] 1068 	cjne	r2,#0xfe,00549$
      00A454 02 A8 E7         [24] 1069 	ljmp	00168$
      00A457                       1070 00549$:
      00A457 02 A9 01         [24] 1071 	ljmp	00169$
                                   1072 ;	quantum/via.c:264: case id_get_protocol_version: {
      00A45A                       1073 00115$:
                                   1074 ;	quantum/via.c:265: command_data[0] = VIA_PROTOCOL_VERSION >> 8;
      00A45A 12 38 92         [24] 1075 	lcall	_ak820_outline_0119
      00A45D E4               [12] 1076 	clr	a
      00A45E 12 43 06         [24] 1077 	lcall	_ak820_outline_0030
                                   1078 ;	quantum/via.c:266: command_data[1] = VIA_PROTOCOL_VERSION & 0xFF;
      00A461 74 09            [12] 1079 	mov	a,#0x09
      00A463 F0               [24] 1080 	movx	@dptr,a
                                   1081 ;	quantum/via.c:267: break;
      00A464 02 A9 19         [24] 1082 	ljmp	00171$
                                   1083 ;	quantum/via.c:269: case id_get_keyboard_value: {
      00A467                       1084 00116$:
                                   1085 ;	quantum/via.c:270: switch (command_data[0]) {
      00A467 12 43 38         [24] 1086 	lcall	_ak820_outline_0090
      00A46A FA               [12] 1087 	mov	r2,a
      00A46B BA 01 02         [24] 1088 	cjne	r2,#0x01,00550$
      00A46E 80 0E            [24] 1089 	sjmp	00117$
      00A470                       1090 00550$:
      00A470 BA 02 02         [24] 1091 	cjne	r2,#0x02,00551$
      00A473 80 34            [24] 1092 	sjmp	00118$
      00A475                       1093 00551$:
      00A475 BA 03 03         [24] 1094 	cjne	r2,#0x03,00552$
      00A478 02 A4 E4         [24] 1095 	ljmp	00119$
      00A47B                       1096 00552$:
      00A47B 02 A5 0E         [24] 1097 	ljmp	00123$
                                   1098 ;	quantum/via.c:271: case id_uptime: {
      00A47E                       1099 00117$:
                                   1100 ;	quantum/via.c:272: uint32_t value  = timer_read32();
      00A47E 12 47 B2         [24] 1101 	lcall	_timer_read32
      00A481 85 82 38         [24] 1102 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A484 85 83 39         [24] 1103 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A487 85 F0 3A         [24] 1104 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A48A F5 3B            [12] 1105 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
                                   1106 ;	quantum/via.c:273: command_data[1] = (value >> 24) & 0xFF;
      00A48C 12 38 87         [24] 1107 	lcall	_ak820_outline_0112
      00A48F A3               [24] 1108 	inc	dptr
      00A490 A3               [24] 1109 	inc	dptr
      00A491 E5 3B            [12] 1110 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A493 12 43 06         [24] 1111 	lcall	_ak820_outline_0030
                                   1112 ;	quantum/via.c:274: command_data[2] = (value >> 16) & 0xFF;
      00A496 A3               [24] 1113 	inc	dptr
      00A497 E5 3A            [12] 1114 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A499 F0               [24] 1115 	movx	@dptr,a
                                   1116 ;	quantum/via.c:275: command_data[3] = (value >> 8) & 0xFF;
      00A49A 12 A9 46         [24] 1117 	lcall	_ak820_outline_0021
      00A49D E5 39            [12] 1118 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A49F F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/via.c:276: command_data[4] = value & 0xFF;
      00A4A0 12 42 FC         [24] 1121 	lcall	_ak820_outline_0010
      00A4A3 E5 38            [12] 1122 	mov	a,_raw_hid_receive_sloc0_1_0
      00A4A5 F0               [24] 1123 	movx	@dptr,a
                                   1124 ;	quantum/via.c:277: break;
      00A4A6 02 A9 19         [24] 1125 	ljmp	00171$
                                   1126 ;	quantum/via.c:279: case id_layout_options: {
      00A4A9                       1127 00118$:
                                   1128 ;	quantum/via.c:280: uint32_t value  = via_get_layout_options();
      00A4A9 C0 03            [24] 1129 	push	ar3
      00A4AB C0 07            [24] 1130 	push	ar7
      00A4AD C0 06            [24] 1131 	push	ar6
      00A4AF C0 03            [24] 1132 	push	ar3
      00A4B1 12 A3 07         [24] 1133 	lcall	_via_get_layout_options
      00A4B4 85 82 38         [24] 1134 	mov	_raw_hid_receive_sloc0_1_0,dpl
      00A4B7 85 83 39         [24] 1135 	mov	(_raw_hid_receive_sloc0_1_0 + 1),dph
      00A4BA 85 F0 3A         [24] 1136 	mov	(_raw_hid_receive_sloc0_1_0 + 2),b
      00A4BD F5 3B            [12] 1137 	mov	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A4BF D0 03            [24] 1138 	pop	ar3
      00A4C1 D0 06            [24] 1139 	pop	ar6
      00A4C3 D0 07            [24] 1140 	pop	ar7
                                   1141 ;	quantum/via.c:281: command_data[1] = (value >> 24) & 0xFF;
      00A4C5 12 38 87         [24] 1142 	lcall	_ak820_outline_0112
      00A4C8 A3               [24] 1143 	inc	dptr
      00A4C9 A3               [24] 1144 	inc	dptr
      00A4CA E5 3B            [12] 1145 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A4CC 12 43 06         [24] 1146 	lcall	_ak820_outline_0030
                                   1147 ;	quantum/via.c:282: command_data[2] = (value >> 16) & 0xFF;
      00A4CF A3               [24] 1148 	inc	dptr
      00A4D0 E5 3A            [12] 1149 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A4D2 F0               [24] 1150 	movx	@dptr,a
                                   1151 ;	quantum/via.c:283: command_data[3] = (value >> 8) & 0xFF;
      00A4D3 12 A9 46         [24] 1152 	lcall	_ak820_outline_0021
      00A4D6 E5 39            [12] 1153 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A4D8 F0               [24] 1154 	movx	@dptr,a
                                   1155 ;	quantum/via.c:284: command_data[4] = value & 0xFF;
      00A4D9 12 42 FC         [24] 1156 	lcall	_ak820_outline_0010
      00A4DC E5 38            [12] 1157 	mov	a,_raw_hid_receive_sloc0_1_0
      00A4DE F0               [24] 1158 	movx	@dptr,a
                                   1159 ;	quantum/via.c:285: break;
      00A4DF D0 03            [24] 1160 	pop	ar3
      00A4E1 02 A9 19         [24] 1161 	ljmp	00171$
                                   1162 ;	quantum/via.c:287: case id_switch_matrix_state: {
      00A4E4                       1163 00119$:
                                   1164 ;	quantum/via.c:290: if (!vial_unlocked)
      00A4E4 90 0E 0E         [24] 1165 	mov	dptr,#_vial_unlocked
      00A4E7 E0               [24] 1166 	movx	a,@dptr
      00A4E8 70 03            [24] 1167 	jnz	00553$
      00A4EA 02 A9 19         [24] 1168 	ljmp	00171$
      00A4ED                       1169 00553$:
                                   1170 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00A4ED 7A 01            [12] 1171 	mov	r2,#0x01
      00A4EF 79 00            [12] 1172 	mov	r1,#0x00
      00A4F1                       1173 00173$:
      00A4F1 B9 10 00         [24] 1174 	cjne	r1,#0x10,00554$
      00A4F4                       1175 00554$:
      00A4F4 40 03            [24] 1176 	jc	00555$
      00A4F6 02 A9 19         [24] 1177 	ljmp	00171$
      00A4F9                       1178 00555$:
                                   1179 ;	quantum/via.c:297: matrix_row_t value = matrix_get_row(row);
      00A4F9 89 82            [24] 1180 	mov	dpl, r1
      00A4FB 12 58 2A         [24] 1181 	lcall	_matrix_get_row
      00A4FE A8 82            [24] 1182 	mov	r0, dpl
                                   1183 ;	quantum/via.c:307: command_data[i++] = value & 0xFF;
      00A500 EA               [12] 1184 	mov	a,r2
      00A501 2C               [12] 1185 	add	a, r4
      00A502 F5 82            [12] 1186 	mov	dpl,a
      00A504 E4               [12] 1187 	clr	a
      00A505 3D               [12] 1188 	addc	a, r5
      00A506 F5 83            [12] 1189 	mov	dph,a
      00A508 0A               [12] 1190 	inc	r2
      00A509 E8               [12] 1191 	mov	a,r0
      00A50A F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/via.c:296: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      00A50B 09               [12] 1194 	inc	r1
                                   1195 ;	quantum/via.c:312: default: {
      00A50C 80 E3            [24] 1196 	sjmp	00173$
      00A50E                       1197 00123$:
                                   1198 ;	quantum/via.c:313: raw_hid_receive_kb(data, length);
      00A50E 12 47 52         [24] 1199 	lcall	_ak820_outline_0075
      00A511 90 0C 3D         [24] 1200 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A514 12 A9 4F         [24] 1201 	lcall	_ak820_outline_0040
      00A517 C0 07            [24] 1202 	push	ar7
      00A519 C0 06            [24] 1203 	push	ar6
      00A51B C0 03            [24] 1204 	push	ar3
      00A51D 12 A3 77         [24] 1205 	lcall	_raw_hid_receive_kb
      00A520 D0 03            [24] 1206 	pop	ar3
      00A522 D0 06            [24] 1207 	pop	ar6
      00A524 D0 07            [24] 1208 	pop	ar7
                                   1209 ;	quantum/via.c:317: break;
      00A526 02 A9 19         [24] 1210 	ljmp	00171$
                                   1211 ;	quantum/via.c:319: case id_set_keyboard_value: {
      00A529                       1212 00125$:
                                   1213 ;	quantum/via.c:320: switch (command_data[0]) {
      00A529 12 43 38         [24] 1214 	lcall	_ak820_outline_0090
      00A52C FA               [12] 1215 	mov	r2,a
      00A52D BA 02 02         [24] 1216 	cjne	r2,#0x02,00556$
      00A530 80 03            [24] 1217 	sjmp	00557$
      00A532                       1218 00556$:
      00A532 02 A5 A5         [24] 1219 	ljmp	00127$
      00A535                       1220 00557$:
                                   1221 ;	quantum/via.c:322: uint32_t value = ((uint32_t)command_data[1] << 24) | ((uint32_t)command_data[2] << 16) | ((uint32_t)command_data[3] << 8) | (uint32_t)command_data[4];
      00A535 C0 03            [24] 1222 	push	ar3
      00A537 12 38 3A         [24] 1223 	lcall	_ak820_outline_0035
      00A53A F8               [12] 1224 	mov	r0,a
      00A53B 79 00            [12] 1225 	mov	r1,#0x00
      00A53D 7B 00            [12] 1226 	mov	r3,#0x00
      00A53F 88 3B            [24] 1227 	mov	(_raw_hid_receive_sloc0_1_0 + 3),r0
      00A541 8B 38            [24] 1228 	mov	_raw_hid_receive_sloc0_1_0,r3
      00A543 8B 39            [24] 1229 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r3
      00A545 8B 3A            [24] 1230 	mov	(_raw_hid_receive_sloc0_1_0 + 2),r3
      00A547 12 A9 3D         [24] 1231 	lcall	_ak820_outline_0017
      00A54A F8               [12] 1232 	mov	r0,a
      00A54B 89 03            [24] 1233 	mov	ar3,r1
      00A54D 88 02            [24] 1234 	mov	ar2,r0
      00A54F E4               [12] 1235 	clr	a
      00A550 42 38            [12] 1236 	orl	_raw_hid_receive_sloc0_1_0,a
      00A552 E9               [12] 1237 	mov	a,r1
      00A553 42 39            [12] 1238 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00A555 EA               [12] 1239 	mov	a,r2
      00A556 42 3A            [12] 1240 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00A558 EB               [12] 1241 	mov	a,r3
      00A559 42 3B            [12] 1242 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A55B 12 A9 46         [24] 1243 	lcall	_ak820_outline_0021
      00A55E E0               [24] 1244 	movx	a,@dptr
      00A55F F8               [12] 1245 	mov	r0,a
      00A560 79 00            [12] 1246 	mov	r1,#0x00
      00A562 7A 00            [12] 1247 	mov	r2,#0x00
      00A564 8A 03            [24] 1248 	mov	ar3,r2
      00A566 89 02            [24] 1249 	mov	ar2,r1
      00A568 88 01            [24] 1250 	mov	ar1,r0
      00A56A E4               [12] 1251 	clr	a
      00A56B 42 38            [12] 1252 	orl	_raw_hid_receive_sloc0_1_0,a
      00A56D E9               [12] 1253 	mov	a,r1
      00A56E 42 39            [12] 1254 	orl	(_raw_hid_receive_sloc0_1_0 + 1),a
      00A570 EA               [12] 1255 	mov	a,r2
      00A571 42 3A            [12] 1256 	orl	(_raw_hid_receive_sloc0_1_0 + 2),a
      00A573 EB               [12] 1257 	mov	a,r3
      00A574 42 3B            [12] 1258 	orl	(_raw_hid_receive_sloc0_1_0 + 3),a
      00A576 12 42 FC         [24] 1259 	lcall	_ak820_outline_0010
      00A579 E0               [24] 1260 	movx	a,@dptr
      00A57A F8               [12] 1261 	mov	r0,a
      00A57B E4               [12] 1262 	clr	a
      00A57C F9               [12] 1263 	mov	r1,a
      00A57D FA               [12] 1264 	mov	r2,a
      00A57E FB               [12] 1265 	mov	r3,a
      00A57F E5 39            [12] 1266 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A581 42 01            [12] 1267 	orl	ar1,a
      00A583 E5 3A            [12] 1268 	mov	a,(_raw_hid_receive_sloc0_1_0 + 2)
      00A585 42 02            [12] 1269 	orl	ar2,a
      00A587 E5 3B            [12] 1270 	mov	a,(_raw_hid_receive_sloc0_1_0 + 3)
      00A589 42 03            [12] 1271 	orl	ar3,a
                                   1272 ;	quantum/via.c:323: via_set_layout_options(value);
      00A58B 12 38 AC         [24] 1273 	lcall	_ak820_outline_0142
      00A58E 8A F0            [24] 1274 	mov	b, r2
      00A590 EB               [12] 1275 	mov	a, r3
      00A591 C0 07            [24] 1276 	push	ar7
      00A593 C0 06            [24] 1277 	push	ar6
      00A595 C0 03            [24] 1278 	push	ar3
      00A597 12 A3 20         [24] 1279 	lcall	_via_set_layout_options
      00A59A D0 03            [24] 1280 	pop	ar3
      00A59C D0 06            [24] 1281 	pop	ar6
      00A59E D0 07            [24] 1282 	pop	ar7
                                   1283 ;	quantum/via.c:324: break;
      00A5A0 D0 03            [24] 1284 	pop	ar3
      00A5A2 02 A9 19         [24] 1285 	ljmp	00171$
                                   1286 ;	quantum/via.c:326: default: {
      00A5A5                       1287 00127$:
                                   1288 ;	quantum/via.c:327: raw_hid_receive_kb(data, length);
      00A5A5 12 47 52         [24] 1289 	lcall	_ak820_outline_0075
      00A5A8 90 0C 3D         [24] 1290 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A5AB 12 A9 4F         [24] 1291 	lcall	_ak820_outline_0040
      00A5AE C0 07            [24] 1292 	push	ar7
      00A5B0 C0 06            [24] 1293 	push	ar6
      00A5B2 C0 03            [24] 1294 	push	ar3
      00A5B4 12 A3 77         [24] 1295 	lcall	_raw_hid_receive_kb
      00A5B7 D0 03            [24] 1296 	pop	ar3
      00A5B9 D0 06            [24] 1297 	pop	ar6
      00A5BB D0 07            [24] 1298 	pop	ar7
                                   1299 ;	quantum/via.c:331: break;
      00A5BD 02 A9 19         [24] 1300 	ljmp	00171$
                                   1301 ;	quantum/via.c:333: case id_dynamic_keymap_get_keycode: {
      00A5C0                       1302 00129$:
                                   1303 ;	quantum/via.c:334: uint16_t keycode = dynamic_keymap_get_keycode(command_data[0], command_data[1], command_data[2]);
      00A5C0 12 43 38         [24] 1304 	lcall	_ak820_outline_0090
      00A5C3 FA               [12] 1305 	mov	r2,a
      00A5C4 12 38 3A         [24] 1306 	lcall	_ak820_outline_0035
      00A5C7 F9               [12] 1307 	mov	r1,a
      00A5C8 12 A9 3D         [24] 1308 	lcall	_ak820_outline_0017
      00A5CB F8               [12] 1309 	mov	r0,a
      00A5CC 90 0A CF         [24] 1310 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      00A5CF E9               [12] 1311 	mov	a,r1
      00A5D0 F0               [24] 1312 	movx	@dptr,a
      00A5D1 90 0A D0         [24] 1313 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      00A5D4 E8               [12] 1314 	mov	a,r0
      00A5D5 F0               [24] 1315 	movx	@dptr,a
      00A5D6 8A 82            [24] 1316 	mov	dpl, r2
      00A5D8 C0 07            [24] 1317 	push	ar7
      00A5DA C0 06            [24] 1318 	push	ar6
      00A5DC C0 03            [24] 1319 	push	ar3
      00A5DE 12 81 50         [24] 1320 	lcall	_dynamic_keymap_get_keycode
      00A5E1 A9 82            [24] 1321 	mov	r1, dpl
      00A5E3 AA 83            [24] 1322 	mov	r2, dph
      00A5E5 D0 03            [24] 1323 	pop	ar3
      00A5E7 D0 06            [24] 1324 	pop	ar6
      00A5E9 D0 07            [24] 1325 	pop	ar7
                                   1326 ;	quantum/via.c:335: command_data[3]  = keycode >> 8;
      00A5EB 12 A9 46         [24] 1327 	lcall	_ak820_outline_0021
      00A5EE 8A 00            [24] 1328 	mov	ar0,r2
      00A5F0 E8               [12] 1329 	mov	a,r0
      00A5F1 F0               [24] 1330 	movx	@dptr,a
                                   1331 ;	quantum/via.c:336: command_data[4]  = keycode & 0xFF;
      00A5F2 12 42 FC         [24] 1332 	lcall	_ak820_outline_0010
      00A5F5 E9               [12] 1333 	mov	a,r1
      00A5F6 F0               [24] 1334 	movx	@dptr,a
                                   1335 ;	quantum/via.c:337: break;
      00A5F7 02 A9 19         [24] 1336 	ljmp	00171$
                                   1337 ;	quantum/via.c:339: case id_dynamic_keymap_set_keycode: {
      00A5FA                       1338 00130$:
                                   1339 ;	quantum/via.c:343: if (!vial_unlocked && command_data[3] == (QK_BOOT >> 8) && command_data[4] == (QK_BOOT & 0xFF)) {
      00A5FA 90 0E 0E         [24] 1340 	mov	dptr,#_vial_unlocked
      00A5FD E0               [24] 1341 	movx	a,@dptr
      00A5FE 70 19            [24] 1342 	jnz	00132$
      00A600 12 A9 46         [24] 1343 	lcall	_ak820_outline_0021
      00A603 E0               [24] 1344 	movx	a,@dptr
      00A604 FA               [12] 1345 	mov	r2,a
      00A605 BA 7C 11         [24] 1346 	cjne	r2,#0x7c,00132$
      00A608 74 05            [12] 1347 	mov	a,#0x05
      00A60A 2E               [12] 1348 	add	a, r6
      00A60B 12 38 20         [24] 1349 	lcall	_ak820_outline_0015
      00A60E 70 09            [24] 1350 	jnz	00132$
                                   1351 ;	quantum/via.c:344: *command_id = id_unhandled;
      00A610 12 38 87         [24] 1352 	lcall	_ak820_outline_0112
      00A613 74 FF            [12] 1353 	mov	a,#0xff
      00A615 F0               [24] 1354 	movx	@dptr,a
                                   1355 ;	quantum/via.c:345: break;
      00A616 02 A9 19         [24] 1356 	ljmp	00171$
      00A619                       1357 00132$:
                                   1358 ;	quantum/via.c:348: dynamic_keymap_set_keycode(command_data[0], command_data[1], command_data[2], (command_data[3] << 8) | command_data[4]);
      00A619 C0 03            [24] 1359 	push	ar3
      00A61B 12 43 38         [24] 1360 	lcall	_ak820_outline_0090
      00A61E F5 3D            [12] 1361 	mov	_raw_hid_receive_sloc2_1_0,a
      00A620 12 38 3A         [24] 1362 	lcall	_ak820_outline_0035
      00A623 F5 3C            [12] 1363 	mov	_raw_hid_receive_sloc1_1_0,a
      00A625 12 A9 3D         [24] 1364 	lcall	_ak820_outline_0017
      00A628 F5 38            [12] 1365 	mov	_raw_hid_receive_sloc0_1_0,a
      00A62A 12 A9 46         [24] 1366 	lcall	_ak820_outline_0021
      00A62D E0               [24] 1367 	movx	a,@dptr
      00A62E FB               [12] 1368 	mov	r3,a
      00A62F 78 00            [12] 1369 	mov	r0,#0x00
      00A631 12 42 FC         [24] 1370 	lcall	_ak820_outline_0010
      00A634 E0               [24] 1371 	movx	a,@dptr
      00A635 7A 00            [12] 1372 	mov	r2,#0x00
      00A637 42 00            [12] 1373 	orl	ar0,a
      00A639 EA               [12] 1374 	mov	a,r2
      00A63A 42 03            [12] 1375 	orl	ar3,a
      00A63C 90 0A D2         [24] 1376 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      00A63F E5 3C            [12] 1377 	mov	a,_raw_hid_receive_sloc1_1_0
      00A641 F0               [24] 1378 	movx	@dptr,a
      00A642 90 0A D3         [24] 1379 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00A645 E5 38            [12] 1380 	mov	a,_raw_hid_receive_sloc0_1_0
      00A647 F0               [24] 1381 	movx	@dptr,a
      00A648 90 0A D4         [24] 1382 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00A64B E8               [12] 1383 	mov	a,r0
      00A64C 12 8C 0B         [24] 1384 	lcall	_ak820_outline_0182
      00A64F 85 3D 82         [24] 1385 	mov	dpl, _raw_hid_receive_sloc2_1_0
      00A652 C0 07            [24] 1386 	push	ar7
      00A654 C0 06            [24] 1387 	push	ar6
      00A656 C0 03            [24] 1388 	push	ar3
      00A658 12 81 9E         [24] 1389 	lcall	_dynamic_keymap_set_keycode
      00A65B D0 03            [24] 1390 	pop	ar3
      00A65D D0 06            [24] 1391 	pop	ar6
      00A65F D0 07            [24] 1392 	pop	ar7
                                   1393 ;	quantum/via.c:349: break;
      00A661 D0 03            [24] 1394 	pop	ar3
      00A663 02 A9 19         [24] 1395 	ljmp	00171$
                                   1396 ;	quantum/via.c:351: case id_dynamic_keymap_reset: {
      00A666                       1397 00135$:
                                   1398 ;	quantum/via.c:352: dynamic_keymap_reset();
      00A666 C0 07            [24] 1399 	push	ar7
      00A668 C0 06            [24] 1400 	push	ar6
      00A66A C0 03            [24] 1401 	push	ar3
      00A66C 12 84 24         [24] 1402 	lcall	_dynamic_keymap_reset
      00A66F D0 03            [24] 1403 	pop	ar3
      00A671 D0 06            [24] 1404 	pop	ar6
      00A673 D0 07            [24] 1405 	pop	ar7
                                   1406 ;	quantum/via.c:353: break;
      00A675 02 A9 19         [24] 1407 	ljmp	00171$
                                   1408 ;	quantum/via.c:355: case id_lighting_set_value: {
      00A678                       1409 00136$:
                                   1410 ;	quantum/via.c:363: vialrgb_set_value(data, length);
      00A678 12 47 52         [24] 1411 	lcall	_ak820_outline_0075
      00A67B 90 0D 88         [24] 1412 	mov	dptr,#_vialrgb_set_value_PARM_2
      00A67E 12 A9 4F         [24] 1413 	lcall	_ak820_outline_0040
      00A681 C0 07            [24] 1414 	push	ar7
      00A683 C0 06            [24] 1415 	push	ar6
      00A685 C0 03            [24] 1416 	push	ar3
      00A687 12 B3 68         [24] 1417 	lcall	_vialrgb_set_value
      00A68A D0 03            [24] 1418 	pop	ar3
      00A68C D0 06            [24] 1419 	pop	ar6
      00A68E D0 07            [24] 1420 	pop	ar7
                                   1421 ;	quantum/via.c:375: break;
      00A690 02 A9 19         [24] 1422 	ljmp	00171$
                                   1423 ;	quantum/via.c:377: case id_lighting_get_value: {
      00A693                       1424 00137$:
                                   1425 ;	quantum/via.c:385: vialrgb_get_value(data, length);
      00A693 12 47 52         [24] 1426 	lcall	_ak820_outline_0075
      00A696 90 0D 84         [24] 1427 	mov	dptr,#_vialrgb_get_value_PARM_2
      00A699 12 A9 4F         [24] 1428 	lcall	_ak820_outline_0040
      00A69C C0 07            [24] 1429 	push	ar7
      00A69E C0 06            [24] 1430 	push	ar6
      00A6A0 C0 03            [24] 1431 	push	ar3
      00A6A2 12 B1 FC         [24] 1432 	lcall	_vialrgb_get_value
      00A6A5 D0 03            [24] 1433 	pop	ar3
      00A6A7 D0 06            [24] 1434 	pop	ar6
      00A6A9 D0 07            [24] 1435 	pop	ar7
                                   1436 ;	quantum/via.c:397: break;
      00A6AB 02 A9 19         [24] 1437 	ljmp	00171$
                                   1438 ;	quantum/via.c:399: case id_lighting_save: {
      00A6AE                       1439 00138$:
                                   1440 ;	quantum/via.c:407: vialrgb_save(data, length);
      00A6AE 12 47 52         [24] 1441 	lcall	_ak820_outline_0075
      00A6B1 90 0D 8C         [24] 1442 	mov	dptr,#_vialrgb_save_PARM_2
      00A6B4 12 A9 4F         [24] 1443 	lcall	_ak820_outline_0040
      00A6B7 C0 07            [24] 1444 	push	ar7
      00A6B9 C0 06            [24] 1445 	push	ar6
      00A6BB C0 03            [24] 1446 	push	ar3
      00A6BD 12 B3 F7         [24] 1447 	lcall	_vialrgb_save
      00A6C0 D0 03            [24] 1448 	pop	ar3
      00A6C2 D0 06            [24] 1449 	pop	ar6
      00A6C4 D0 07            [24] 1450 	pop	ar7
                                   1451 ;	quantum/via.c:419: break;
      00A6C6 02 A9 19         [24] 1452 	ljmp	00171$
                                   1453 ;	quantum/via.c:428: case id_dynamic_keymap_macro_get_count: {
      00A6C9                       1454 00139$:
                                   1455 ;	quantum/via.c:429: command_data[0] = dynamic_keymap_macro_get_count();
      00A6C9 C0 07            [24] 1456 	push	ar7
      00A6CB C0 06            [24] 1457 	push	ar6
      00A6CD C0 05            [24] 1458 	push	ar5
      00A6CF C0 04            [24] 1459 	push	ar4
      00A6D1 C0 03            [24] 1460 	push	ar3
      00A6D3 12 88 12         [24] 1461 	lcall	_dynamic_keymap_macro_get_count
      00A6D6 AA 82            [24] 1462 	mov	r2, dpl
      00A6D8 D0 03            [24] 1463 	pop	ar3
      00A6DA D0 04            [24] 1464 	pop	ar4
      00A6DC D0 05            [24] 1465 	pop	ar5
      00A6DE D0 06            [24] 1466 	pop	ar6
      00A6E0 D0 07            [24] 1467 	pop	ar7
      00A6E2 12 38 92         [24] 1468 	lcall	_ak820_outline_0119
      00A6E5 EA               [12] 1469 	mov	a,r2
      00A6E6 F0               [24] 1470 	movx	@dptr,a
                                   1471 ;	quantum/via.c:430: break;
      00A6E7 02 A9 19         [24] 1472 	ljmp	00171$
                                   1473 ;	quantum/via.c:432: case id_dynamic_keymap_macro_get_buffer_size: {
      00A6EA                       1474 00140$:
                                   1475 ;	quantum/via.c:433: uint16_t size   = dynamic_keymap_macro_get_buffer_size();
      00A6EA C0 07            [24] 1476 	push	ar7
      00A6EC C0 06            [24] 1477 	push	ar6
      00A6EE C0 05            [24] 1478 	push	ar5
      00A6F0 C0 04            [24] 1479 	push	ar4
      00A6F2 C0 03            [24] 1480 	push	ar3
      00A6F4 12 88 16         [24] 1481 	lcall	_dynamic_keymap_macro_get_buffer_size
      00A6F7 A9 82            [24] 1482 	mov	r1, dpl
      00A6F9 AA 83            [24] 1483 	mov	r2, dph
      00A6FB D0 03            [24] 1484 	pop	ar3
      00A6FD D0 04            [24] 1485 	pop	ar4
      00A6FF D0 05            [24] 1486 	pop	ar5
      00A701 D0 06            [24] 1487 	pop	ar6
      00A703 D0 07            [24] 1488 	pop	ar7
                                   1489 ;	quantum/via.c:434: command_data[0] = size >> 8;
      00A705 8A 00            [24] 1490 	mov	ar0,r2
      00A707 12 38 92         [24] 1491 	lcall	_ak820_outline_0119
      00A70A E8               [12] 1492 	mov	a,r0
      00A70B 12 43 06         [24] 1493 	lcall	_ak820_outline_0030
                                   1494 ;	quantum/via.c:435: command_data[1] = size & 0xFF;
      00A70E E9               [12] 1495 	mov	a,r1
      00A70F F0               [24] 1496 	movx	@dptr,a
                                   1497 ;	quantum/via.c:436: break;
      00A710 02 A9 19         [24] 1498 	ljmp	00171$
                                   1499 ;	quantum/via.c:438: case id_dynamic_keymap_macro_get_buffer: {
      00A713                       1500 00141$:
                                   1501 ;	quantum/via.c:439: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00A713 C0 03            [24] 1502 	push	ar3
      00A715 12 A9 26         [24] 1503 	lcall	_ak820_outline_0003
      00A718 89 38            [24] 1504 	mov	_raw_hid_receive_sloc0_1_0,r1
      00A71A 8A 39            [24] 1505 	mov	(_raw_hid_receive_sloc0_1_0 + 1),r2
                                   1506 ;	quantum/via.c:440: uint16_t size   = command_data[2]; // size <= 28
      00A71C 12 A9 3D         [24] 1507 	lcall	_ak820_outline_0017
      00A71F FB               [12] 1508 	mov	r3,a
                                   1509 ;	quantum/via.c:441: if (size <= 28)
      00A720 8B 3E            [24] 1510 	mov	_raw_hid_receive_sloc3_1_0,r3
      00A722 75 3F 00         [24] 1511 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00A725 C3               [12] 1512 	clr	c
      00A726 74 1C            [12] 1513 	mov	a,#0x1c
      00A728 9B               [12] 1514 	subb	a,r3
      00A729 D0 03            [24] 1515 	pop	ar3
      00A72B 50 03            [24] 1516 	jnc	00562$
      00A72D 02 A9 19         [24] 1517 	ljmp	00171$
      00A730                       1518 00562$:
                                   1519 ;	free result
                                   1520 ;	quantum/via.c:442: dynamic_keymap_macro_get_buffer(offset, size, &command_data[3]);
      00A730 12 A9 58         [24] 1521 	lcall	_ak820_outline_0067
      00A733 90 0B 21         [24] 1522 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      00A736 E5 3E            [12] 1523 	mov	a,_raw_hid_receive_sloc3_1_0
      00A738 F0               [24] 1524 	movx	@dptr,a
      00A739 E5 3F            [12] 1525 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00A73B A3               [24] 1526 	inc	dptr
      00A73C F0               [24] 1527 	movx	@dptr,a
      00A73D 90 0B 23         [24] 1528 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      00A740 12 A9 62         [24] 1529 	lcall	_ak820_outline_0083
      00A743 85 38 82         [24] 1530 	mov	dpl, _raw_hid_receive_sloc0_1_0
      00A746 85 39 83         [24] 1531 	mov	dph, (_raw_hid_receive_sloc0_1_0 + 1)
      00A749 C0 07            [24] 1532 	push	ar7
      00A74B C0 06            [24] 1533 	push	ar6
      00A74D C0 03            [24] 1534 	push	ar3
      00A74F 12 88 1A         [24] 1535 	lcall	_dynamic_keymap_macro_get_buffer
      00A752 D0 03            [24] 1536 	pop	ar3
      00A754 D0 06            [24] 1537 	pop	ar6
      00A756 D0 07            [24] 1538 	pop	ar7
                                   1539 ;	quantum/via.c:443: break;
      00A758 02 A9 19         [24] 1540 	ljmp	00171$
                                   1541 ;	quantum/via.c:445: case id_dynamic_keymap_macro_set_buffer: {
      00A75B                       1542 00144$:
                                   1543 ;	quantum/via.c:448: if (!vial_unlocked) {
      00A75B 90 0E 0E         [24] 1544 	mov	dptr,#_vial_unlocked
      00A75E E0               [24] 1545 	movx	a,@dptr
      00A75F 70 01            [24] 1546 	jnz	00146$
                                   1547 ;	quantum/via.c:450: return;
      00A761 22               [24] 1548 	ret
      00A762                       1549 00146$:
                                   1550 ;	quantum/via.c:456: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00A762 C0 03            [24] 1551 	push	ar3
      00A764 12 A9 26         [24] 1552 	lcall	_ak820_outline_0003
      00A767 89 3E            [24] 1553 	mov	_raw_hid_receive_sloc3_1_0,r1
      00A769 8A 3F            [24] 1554 	mov	(_raw_hid_receive_sloc3_1_0 + 1),r2
                                   1555 ;	quantum/via.c:457: uint16_t size   = command_data[2]; // size <= 28
      00A76B 12 A9 3D         [24] 1556 	lcall	_ak820_outline_0017
      00A76E F5 38            [12] 1557 	mov	_raw_hid_receive_sloc0_1_0, a
      00A770 75 39 00         [24] 1558 	mov	(_raw_hid_receive_sloc0_1_0 + 1),#0x00
                                   1559 ;	quantum/via.c:461: if (size > 28 || size > length - 4 || !dynamic_keymap_macro_set_buffer(offset, size, &command_data[3])) return;
      00A773 85 38 40         [24] 1560 	mov	_raw_hid_receive_sloc4_1_0,_raw_hid_receive_sloc0_1_0
      00A776 85 39 41         [24] 1561 	mov	(_raw_hid_receive_sloc4_1_0 + 1),(_raw_hid_receive_sloc0_1_0 + 1)
      00A779 C3               [12] 1562 	clr	c
      00A77A 74 1C            [12] 1563 	mov	a,#0x1c
      00A77C 95 40            [12] 1564 	subb	a,_raw_hid_receive_sloc4_1_0
      00A77E E4               [12] 1565 	clr	a
      00A77F 95 41            [12] 1566 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00A781 D0 03            [24] 1567 	pop	ar3
      00A783 40 44            [24] 1568 	jc	00147$
                                   1569 ;	free result
      00A785 8B 01            [24] 1570 	mov	ar1,r3
      00A787 7A 00            [12] 1571 	mov	r2,#0x00
      00A789 E9               [12] 1572 	mov	a,r1
      00A78A 24 FC            [12] 1573 	add	a,#0xfc
      00A78C F9               [12] 1574 	mov	r1,a
      00A78D EA               [12] 1575 	mov	a,r2
      00A78E 34 FF            [12] 1576 	addc	a,#0xff
      00A790 FA               [12] 1577 	mov	r2,a
      00A791 C3               [12] 1578 	clr	c
      00A792 E9               [12] 1579 	mov	a,r1
      00A793 95 40            [12] 1580 	subb	a,_raw_hid_receive_sloc4_1_0
      00A795 EA               [12] 1581 	mov	a,r2
      00A796 95 41            [12] 1582 	subb	a,(_raw_hid_receive_sloc4_1_0 + 1)
      00A798 40 2F            [24] 1583 	jc	00147$
                                   1584 ;	free result
      00A79A 12 A9 58         [24] 1585 	lcall	_ak820_outline_0067
      00A79D 90 0B 28         [24] 1586 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      00A7A0 E5 38            [12] 1587 	mov	a,_raw_hid_receive_sloc0_1_0
      00A7A2 F0               [24] 1588 	movx	@dptr,a
      00A7A3 E5 39            [12] 1589 	mov	a,(_raw_hid_receive_sloc0_1_0 + 1)
      00A7A5 A3               [24] 1590 	inc	dptr
      00A7A6 F0               [24] 1591 	movx	@dptr,a
      00A7A7 90 0B 2A         [24] 1592 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      00A7AA 12 A9 62         [24] 1593 	lcall	_ak820_outline_0083
      00A7AD 85 3E 82         [24] 1594 	mov	dpl, _raw_hid_receive_sloc3_1_0
      00A7B0 85 3F 83         [24] 1595 	mov	dph, (_raw_hid_receive_sloc3_1_0 + 1)
      00A7B3 C0 07            [24] 1596 	push	ar7
      00A7B5 C0 06            [24] 1597 	push	ar6
      00A7B7 C0 03            [24] 1598 	push	ar3
      00A7B9 12 88 68         [24] 1599 	lcall	_dynamic_keymap_macro_set_buffer
      00A7BC E5 82            [12] 1600 	mov	a, dpl
      00A7BE D0 03            [24] 1601 	pop	ar3
      00A7C0 D0 06            [24] 1602 	pop	ar6
      00A7C2 D0 07            [24] 1603 	pop	ar7
      00A7C4 60 03            [24] 1604 	jz	00566$
      00A7C6 02 A9 19         [24] 1605 	ljmp	00171$
      00A7C9                       1606 00566$:
      00A7C9                       1607 00147$:
      00A7C9 22               [24] 1608 	ret
                                   1609 ;	quantum/via.c:468: case id_dynamic_keymap_macro_reset: {
      00A7CA                       1610 00151$:
                                   1611 ;	quantum/via.c:470: if (!vial_unlocked) return;
      00A7CA 90 0E 0E         [24] 1612 	mov	dptr,#_vial_unlocked
      00A7CD E0               [24] 1613 	movx	a,@dptr
      00A7CE 70 01            [24] 1614 	jnz	00153$
      00A7D0 22               [24] 1615 	ret
      00A7D1                       1616 00153$:
                                   1617 ;	quantum/via.c:472: dynamic_keymap_macro_reset();
      00A7D1 C0 07            [24] 1618 	push	ar7
      00A7D3 C0 06            [24] 1619 	push	ar6
      00A7D5 C0 03            [24] 1620 	push	ar3
      00A7D7 12 88 96         [24] 1621 	lcall	_dynamic_keymap_macro_reset
      00A7DA D0 03            [24] 1622 	pop	ar3
      00A7DC D0 06            [24] 1623 	pop	ar6
      00A7DE D0 07            [24] 1624 	pop	ar7
                                   1625 ;	quantum/via.c:473: break;
      00A7E0 02 A9 19         [24] 1626 	ljmp	00171$
                                   1627 ;	quantum/via.c:475: case id_dynamic_keymap_get_layer_count: {
      00A7E3                       1628 00154$:
                                   1629 ;	quantum/via.c:476: command_data[0] = dynamic_keymap_get_layer_count();
      00A7E3 C0 07            [24] 1630 	push	ar7
      00A7E5 C0 06            [24] 1631 	push	ar6
      00A7E7 C0 05            [24] 1632 	push	ar5
      00A7E9 C0 04            [24] 1633 	push	ar4
      00A7EB C0 03            [24] 1634 	push	ar3
      00A7ED 12 81 17         [24] 1635 	lcall	_dynamic_keymap_get_layer_count
      00A7F0 AA 82            [24] 1636 	mov	r2, dpl
      00A7F2 D0 03            [24] 1637 	pop	ar3
      00A7F4 D0 04            [24] 1638 	pop	ar4
      00A7F6 D0 05            [24] 1639 	pop	ar5
      00A7F8 D0 06            [24] 1640 	pop	ar6
      00A7FA D0 07            [24] 1641 	pop	ar7
      00A7FC 12 38 92         [24] 1642 	lcall	_ak820_outline_0119
      00A7FF EA               [12] 1643 	mov	a,r2
      00A800 F0               [24] 1644 	movx	@dptr,a
                                   1645 ;	quantum/via.c:477: break;
      00A801 02 A9 19         [24] 1646 	ljmp	00171$
                                   1647 ;	quantum/via.c:479: case id_dynamic_keymap_get_buffer: {
      00A804                       1648 00155$:
                                   1649 ;	quantum/via.c:480: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00A804 C0 03            [24] 1650 	push	ar3
      00A806 12 A9 26         [24] 1651 	lcall	_ak820_outline_0003
      00A809 89 40            [24] 1652 	mov	_raw_hid_receive_sloc4_1_0,r1
      00A80B 8A 41            [24] 1653 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r2
                                   1654 ;	quantum/via.c:481: uint16_t size   = command_data[2]; // size <= 28
      00A80D 12 A9 3D         [24] 1655 	lcall	_ak820_outline_0017
      00A810 FB               [12] 1656 	mov	r3,a
                                   1657 ;	quantum/via.c:482: if (size <= 28)
      00A811 8B 3E            [24] 1658 	mov	_raw_hid_receive_sloc3_1_0,r3
      00A813 75 3F 00         [24] 1659 	mov	(_raw_hid_receive_sloc3_1_0 + 1),#0x00
      00A816 C3               [12] 1660 	clr	c
      00A817 74 1C            [12] 1661 	mov	a,#0x1c
      00A819 9B               [12] 1662 	subb	a,r3
      00A81A D0 03            [24] 1663 	pop	ar3
      00A81C 50 03            [24] 1664 	jnc	00568$
      00A81E 02 A9 19         [24] 1665 	ljmp	00171$
      00A821                       1666 00568$:
                                   1667 ;	free result
                                   1668 ;	quantum/via.c:483: dynamic_keymap_get_buffer(offset, size, &command_data[3]);
      00A821 12 A9 58         [24] 1669 	lcall	_ak820_outline_0067
      00A824 90 0B 0A         [24] 1670 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      00A827 E5 3E            [12] 1671 	mov	a,_raw_hid_receive_sloc3_1_0
      00A829 F0               [24] 1672 	movx	@dptr,a
      00A82A E5 3F            [12] 1673 	mov	a,(_raw_hid_receive_sloc3_1_0 + 1)
      00A82C A3               [24] 1674 	inc	dptr
      00A82D F0               [24] 1675 	movx	@dptr,a
      00A82E 90 0B 0C         [24] 1676 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      00A831 12 A9 62         [24] 1677 	lcall	_ak820_outline_0083
      00A834 85 40 82         [24] 1678 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00A837 85 41 83         [24] 1679 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00A83A C0 07            [24] 1680 	push	ar7
      00A83C C0 06            [24] 1681 	push	ar6
      00A83E C0 03            [24] 1682 	push	ar3
      00A840 12 85 E3         [24] 1683 	lcall	_dynamic_keymap_get_buffer
      00A843 D0 03            [24] 1684 	pop	ar3
      00A845 D0 06            [24] 1685 	pop	ar6
      00A847 D0 07            [24] 1686 	pop	ar7
                                   1687 ;	quantum/via.c:484: break;
      00A849 02 A9 19         [24] 1688 	ljmp	00171$
                                   1689 ;	quantum/via.c:486: case id_dynamic_keymap_set_buffer: {
      00A84C                       1690 00158$:
                                   1691 ;	quantum/via.c:487: uint16_t offset = (command_data[0] << 8) | command_data[1];
      00A84C 12 43 38         [24] 1692 	lcall	_ak820_outline_0090
      00A84F FD               [12] 1693 	mov	r5,a
      00A850 7C 00            [12] 1694 	mov	r4,#0x00
      00A852 12 38 3A         [24] 1695 	lcall	_ak820_outline_0035
      00A855 7A 00            [12] 1696 	mov	r2,#0x00
      00A857 42 04            [12] 1697 	orl	ar4,a
      00A859 EA               [12] 1698 	mov	a,r2
      00A85A 42 05            [12] 1699 	orl	ar5,a
      00A85C 8C 40            [24] 1700 	mov	_raw_hid_receive_sloc4_1_0,r4
      00A85E 8D 41            [24] 1701 	mov	(_raw_hid_receive_sloc4_1_0 + 1),r5
                                   1702 ;	quantum/via.c:488: uint16_t size   = command_data[2]; // size <= 28
      00A860 12 A9 3D         [24] 1703 	lcall	_ak820_outline_0017
      00A863 F9               [12] 1704 	mov	r1,a
      00A864 7A 00            [12] 1705 	mov	r2,#0x00
                                   1706 ;	quantum/via.c:489: if (size <= 28)
      00A866 89 00            [24] 1707 	mov	ar0,r1
      00A868 E8               [12] 1708 	mov	a,r0
      00A869 24 E3            [12] 1709 	add	a,#0xff - 0x1c
      00A86B 50 03            [24] 1710 	jnc	00569$
      00A86D 02 A9 19         [24] 1711 	ljmp	00171$
      00A870                       1712 00569$:
                                   1713 ;	free result
                                   1714 ;	quantum/via.c:490: dynamic_keymap_set_buffer(offset, size, &command_data[3]);
      00A870 C0 03            [24] 1715 	push	ar3
      00A872 74 04            [12] 1716 	mov	a,#0x04
      00A874 2E               [12] 1717 	add	a, r6
      00A875 F8               [12] 1718 	mov	r0,a
      00A876 E4               [12] 1719 	clr	a
      00A877 3F               [12] 1720 	addc	a, r7
      00A878 FB               [12] 1721 	mov	r3,a
      00A879 7D 00            [12] 1722 	mov	r5,#0x00
      00A87B 90 0B 11         [24] 1723 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      00A87E E9               [12] 1724 	mov	a,r1
      00A87F F0               [24] 1725 	movx	@dptr,a
      00A880 EA               [12] 1726 	mov	a,r2
      00A881 A3               [24] 1727 	inc	dptr
      00A882 F0               [24] 1728 	movx	@dptr,a
      00A883 90 0B 13         [24] 1729 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      00A886 E8               [12] 1730 	mov	a,r0
      00A887 12 8C 0B         [24] 1731 	lcall	_ak820_outline_0182
      00A88A ED               [12] 1732 	mov	a,r5
      00A88B A3               [24] 1733 	inc	dptr
      00A88C F0               [24] 1734 	movx	@dptr,a
      00A88D 85 40 82         [24] 1735 	mov	dpl, _raw_hid_receive_sloc4_1_0
      00A890 85 41 83         [24] 1736 	mov	dph, (_raw_hid_receive_sloc4_1_0 + 1)
      00A893 C0 07            [24] 1737 	push	ar7
      00A895 C0 06            [24] 1738 	push	ar6
      00A897 C0 03            [24] 1739 	push	ar3
      00A899 12 86 21         [24] 1740 	lcall	_dynamic_keymap_set_buffer
      00A89C D0 03            [24] 1741 	pop	ar3
      00A89E D0 06            [24] 1742 	pop	ar6
      00A8A0 D0 07            [24] 1743 	pop	ar7
                                   1744 ;	quantum/via.c:491: break;
      00A8A2 D0 03            [24] 1745 	pop	ar3
      00A8A4 02 A9 19         [24] 1746 	ljmp	00171$
                                   1747 ;	quantum/via.c:495: case id_bootloader_jump: {
      00A8A7                       1748 00161$:
                                   1749 ;	quantum/via.c:497: if (!vial_unlocked)
      00A8A7 90 0E 0E         [24] 1750 	mov	dptr,#_vial_unlocked
      00A8AA E0               [24] 1751 	movx	a,@dptr
      00A8AB 70 03            [24] 1752 	jnz	00570$
      00A8AD 02 A9 19         [24] 1753 	ljmp	00171$
      00A8B0                       1754 00570$:
                                   1755 ;	quantum/via.c:501: raw_hid_send(data, length);
      00A8B0 12 A9 74         [24] 1756 	lcall	_ak820_outline_0144
      00A8B3 90 06 6C         [24] 1757 	mov	dptr,#_raw_hid_send_PARM_2
      00A8B6 12 A9 6B         [24] 1758 	lcall	_ak820_outline_0084
      00A8B9 C0 07            [24] 1759 	push	ar7
      00A8BB C0 06            [24] 1760 	push	ar6
      00A8BD C0 03            [24] 1761 	push	ar3
      00A8BF 12 49 9E         [24] 1762 	lcall	_raw_hid_send
      00A8C2 D0 03            [24] 1763 	pop	ar3
      00A8C4 D0 06            [24] 1764 	pop	ar6
      00A8C6 D0 07            [24] 1765 	pop	ar7
                                   1766 ;	quantum/via.c:503: wait_ms(100);
      00A8C8 7D 64            [12] 1767 	mov	r5,#0x64
      00A8CA                       1768 00176$:
      00A8CA ED               [12] 1769 	mov	a,r5
      00A8CB 60 09            [24] 1770 	jz	00166$
      00A8CD 90 00 01         [24] 1771 	mov	dptr,#0x0001
      00A8D0 12 57 69         [24] 1772 	lcall	_mDelaymS
      00A8D3 1D               [12] 1773 	dec	r5
      00A8D4 80 F4            [24] 1774 	sjmp	00176$
      00A8D6                       1775 00166$:
                                   1776 ;	quantum/via.c:504: bootloader_jump();
      00A8D6 C0 07            [24] 1777 	push	ar7
      00A8D8 C0 06            [24] 1778 	push	ar6
      00A8DA C0 03            [24] 1779 	push	ar3
      00A8DC 12 34 0E         [24] 1780 	lcall	_bootloader_jump
      00A8DF D0 03            [24] 1781 	pop	ar3
      00A8E1 D0 06            [24] 1782 	pop	ar6
      00A8E3 D0 07            [24] 1783 	pop	ar7
                                   1784 ;	quantum/via.c:505: break;
                                   1785 ;	quantum/via.c:509: case id_vial_prefix: {
      00A8E5 80 32            [24] 1786 	sjmp	00171$
      00A8E7                       1787 00168$:
                                   1788 ;	quantum/via.c:510: vial_handle_cmd(data, length);
      00A8E7 12 A9 74         [24] 1789 	lcall	_ak820_outline_0144
      00A8EA 90 0C 4F         [24] 1790 	mov	dptr,#_vial_handle_cmd_PARM_2
      00A8ED 12 A9 6B         [24] 1791 	lcall	_ak820_outline_0084
      00A8F0 C0 07            [24] 1792 	push	ar7
      00A8F2 C0 06            [24] 1793 	push	ar6
      00A8F4 C0 03            [24] 1794 	push	ar3
      00A8F6 12 AA 61         [24] 1795 	lcall	_vial_handle_cmd
      00A8F9 D0 03            [24] 1796 	pop	ar3
      00A8FB D0 06            [24] 1797 	pop	ar6
      00A8FD D0 07            [24] 1798 	pop	ar7
                                   1799 ;	quantum/via.c:511: break;
                                   1800 ;	quantum/via.c:514: default: {
      00A8FF 80 18            [24] 1801 	sjmp	00171$
      00A901                       1802 00169$:
                                   1803 ;	quantum/via.c:516: raw_hid_receive_kb(data, length);
      00A901 12 A9 74         [24] 1804 	lcall	_ak820_outline_0144
      00A904 90 0C 3D         [24] 1805 	mov	dptr,#_raw_hid_receive_kb_PARM_2
      00A907 12 A9 6B         [24] 1806 	lcall	_ak820_outline_0084
      00A90A C0 07            [24] 1807 	push	ar7
      00A90C C0 06            [24] 1808 	push	ar6
      00A90E C0 03            [24] 1809 	push	ar3
      00A910 12 A3 77         [24] 1810 	lcall	_raw_hid_receive_kb
      00A913 D0 03            [24] 1811 	pop	ar3
      00A915 D0 06            [24] 1812 	pop	ar6
      00A917 D0 07            [24] 1813 	pop	ar7
                                   1814 ;	quantum/via.c:521: skip:
      00A919                       1815 00171$:
                                   1816 ;	quantum/via.c:525: raw_hid_send(data, length);
      00A919 7D 00            [12] 1817 	mov	r5,#0x00
      00A91B 90 06 6C         [24] 1818 	mov	dptr,#_raw_hid_send_PARM_2
      00A91E EB               [12] 1819 	mov	a,r3
      00A91F F0               [24] 1820 	movx	@dptr,a
      00A920 12 6E 1A         [24] 1821 	lcall	_ak820_outline_0063
                                   1822 ;	quantum/via.c:526: }
      00A923 02 49 9E         [24] 1823 	ljmp	_raw_hid_send
                                   1824 	.area CSEG    (CODE)
                                   1825 	.area CONST   (CODE)
                                   1826 	.area XINIT   (CODE)
                                   1827 	.area CABS    (ABS,CODE)
                                   1828 
                                   1829 ; Experimental exact instruction outlining.
                                   1830 	.globl _ak820_outline_0001
                                   1831 	.globl _ak820_outline_0003
                                   1832 	.globl _ak820_outline_0008
                                   1833 	.globl _ak820_outline_0010
                                   1834 	.globl _ak820_outline_0012
                                   1835 	.globl _ak820_outline_0015
                                   1836 	.globl _ak820_outline_0016
                                   1837 	.globl _ak820_outline_0017
                                   1838 	.globl _ak820_outline_0021
                                   1839 	.globl _ak820_outline_0030
                                   1840 	.globl _ak820_outline_0035
                                   1841 	.globl _ak820_outline_0036
                                   1842 	.globl _ak820_outline_0040
                                   1843 	.globl _ak820_outline_0043
                                   1844 	.globl _ak820_outline_0046
                                   1845 	.globl _ak820_outline_0051
                                   1846 	.globl _ak820_outline_0063
                                   1847 	.globl _ak820_outline_0067
                                   1848 	.globl _ak820_outline_0075
                                   1849 	.globl _ak820_outline_0083
                                   1850 	.globl _ak820_outline_0084
                                   1851 	.globl _ak820_outline_0090
                                   1852 	.globl _ak820_outline_0103
                                   1853 	.globl _ak820_outline_0104
                                   1854 	.globl _ak820_outline_0112
                                   1855 	.globl _ak820_outline_0114
                                   1856 	.globl _ak820_outline_0119
                                   1857 	.globl _ak820_outline_0142
                                   1858 	.globl _ak820_outline_0144
                                   1859 	.globl _ak820_outline_0146
                                   1860 	.globl _ak820_outline_0150
                                   1861 	.globl _ak820_outline_0151
                                   1862 	.globl _ak820_outline_0153
                                   1863 	.globl _ak820_outline_0154
                                   1864 	.globl _ak820_outline_0182
                                   1865 
                                   1866 	.area CSEG (CODE)
                                   1867 ; function ak820_outline_0003
      00A926                       1868 _ak820_outline_0003:
      00A926 8C 82            [24] 1869 	mov	dpl,r4
      00A928 8D 83            [24] 1870 	mov	dph,r5
      00A92A E0               [24] 1871 	movx	a,@dptr
      00A92B FA               [12] 1872 	mov	r2,a
      00A92C 79 00            [12] 1873 	mov	r1,#0x00
      00A92E 8E 82            [24] 1874 	mov	dpl,r6
      00A930 8F 83            [24] 1875 	mov	dph,r7
      00A932 A3               [24] 1876 	inc	dptr
      00A933 A3               [24] 1877 	inc	dptr
      00A934 E0               [24] 1878 	movx	a,@dptr
      00A935 7B 00            [12] 1879 	mov	r3,#0x00
      00A937 42 01            [12] 1880 	orl	ar1,a
      00A939 EB               [12] 1881 	mov	a,r3
      00A93A 42 02            [12] 1882 	orl	ar2,a
      00A93C 22               [24] 1883 	ret
                                   1884 
                                   1885 	.area CSEG (CODE)
                                   1886 ; function ak820_outline_0017
      00A93D                       1887 _ak820_outline_0017:
      00A93D 8E 82            [24] 1888 	mov	dpl,r6
      00A93F 8F 83            [24] 1889 	mov	dph,r7
      00A941 A3               [24] 1890 	inc	dptr
      00A942 A3               [24] 1891 	inc	dptr
      00A943 A3               [24] 1892 	inc	dptr
      00A944 E0               [24] 1893 	movx	a,@dptr
      00A945 22               [24] 1894 	ret
                                   1895 
                                   1896 	.area CSEG (CODE)
                                   1897 ; function ak820_outline_0021
      00A946                       1898 _ak820_outline_0021:
      00A946 8E 82            [24] 1899 	mov	dpl,r6
      00A948 8F 83            [24] 1900 	mov	dph,r7
      00A94A A3               [24] 1901 	inc	dptr
      00A94B A3               [24] 1902 	inc	dptr
      00A94C A3               [24] 1903 	inc	dptr
      00A94D A3               [24] 1904 	inc	dptr
      00A94E 22               [24] 1905 	ret
                                   1906 
                                   1907 	.area CSEG (CODE)
                                   1908 ; function ak820_outline_0040
      00A94F                       1909 _ak820_outline_0040:
      00A94F EB               [12] 1910 	mov	a,r3
      00A950 F0               [24] 1911 	movx	@dptr,a
      00A951 88 82            [24] 1912 	mov	dpl,r0
      00A953 89 83            [24] 1913 	mov	dph,r1
      00A955 8A F0            [24] 1914 	mov	b,r2
      00A957 22               [24] 1915 	ret
                                   1916 
                                   1917 	.area CSEG (CODE)
                                   1918 ; function ak820_outline_0067
      00A958                       1919 _ak820_outline_0067:
      00A958 74 04            [12] 1920 	mov	a,#0x04
      00A95A 2E               [12] 1921 	add	a,r6
      00A95B F9               [12] 1922 	mov	r1,a
      00A95C E4               [12] 1923 	clr	a
      00A95D 3F               [12] 1924 	addc	a,r7
      00A95E F8               [12] 1925 	mov	r0,a
      00A95F 7A 00            [12] 1926 	mov	r2,#0x00
      00A961 22               [24] 1927 	ret
                                   1928 
                                   1929 	.area CSEG (CODE)
                                   1930 ; function ak820_outline_0083
      00A962                       1931 _ak820_outline_0083:
      00A962 E9               [12] 1932 	mov	a,r1
      00A963 F0               [24] 1933 	movx	@dptr,a
      00A964 E8               [12] 1934 	mov	a,r0
      00A965 A3               [24] 1935 	inc	dptr
      00A966 F0               [24] 1936 	movx	@dptr,a
      00A967 EA               [12] 1937 	mov	a,r2
      00A968 A3               [24] 1938 	inc	dptr
      00A969 F0               [24] 1939 	movx	@dptr,a
      00A96A 22               [24] 1940 	ret
                                   1941 
                                   1942 	.area CSEG (CODE)
                                   1943 ; function ak820_outline_0084
      00A96B                       1944 _ak820_outline_0084:
      00A96B EB               [12] 1945 	mov	a,r3
      00A96C F0               [24] 1946 	movx	@dptr,a
      00A96D 8A 82            [24] 1947 	mov	dpl,r2
      00A96F 8C 83            [24] 1948 	mov	dph,r4
      00A971 8D F0            [24] 1949 	mov	b,r5
      00A973 22               [24] 1950 	ret
                                   1951 
                                   1952 	.area CSEG (CODE)
                                   1953 ; function ak820_outline_0144
      00A974                       1954 _ak820_outline_0144:
      00A974 8E 02            [24] 1955 	mov	ar2,r6
      00A976 8F 04            [24] 1956 	mov	ar4,r7
      00A978 7D 00            [12] 1957 	mov	r5,#0x00
      00A97A 22               [24] 1958 	ret
