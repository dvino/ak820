                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _post_process_record_user_PARM_2
                                    282 	.globl _post_process_record_kb_PARM_2
                                    283 	.globl _process_record_user_PARM_2
                                    284 	.globl _process_record_kb_PARM_2
                                    285 	.globl _pre_process_record_user_PARM_2
                                    286 	.globl _pre_process_record_kb_PARM_2
                                    287 	.globl _register_code16
                                    288 	.globl _unregister_code16
                                    289 	.globl _pre_process_record_kb
                                    290 	.globl _pre_process_record_user
                                    291 	.globl _process_action_kb
                                    292 	.globl _process_record_kb
                                    293 	.globl _process_record_user
                                    294 	.globl _post_process_record_kb
                                    295 	.globl _post_process_record_user
                                    296 	.globl _reset_keyboard
                                    297 	.globl _soft_reset_keyboard
                                    298 	.globl _get_record_keycode
                                    299 	.globl _pre_process_record_quantum
                                    300 	.globl _post_process_record_quantum
                                    301 	.globl _process_record_quantum
                                    302 	.globl _process_record_quantum_helper
                                    303 	.globl _shutdown_user
                                    304 ;--------------------------------------------------------
                                    305 ; special function registers
                                    306 ;--------------------------------------------------------
                                    307 	.area RSEG    (ABS,DATA)
      000000                        308 	.org 0x0000
                           0000D0   309 _PSW	=	0x00d0
                           0000E0   310 _ACC	=	0x00e0
                           0000F0   311 _B	=	0x00f0
                           0000FD   312 _A_INV	=	0x00fd
                           000081   313 _SP	=	0x0081
                           000082   314 _DPL	=	0x0082
                           000083   315 _DPH	=	0x0083
                           0000A1   316 _SAFE_MOD	=	0x00a1
                           0000B1   317 _GLOBAL_CFG	=	0x00b1
                           000087   318 _PCON	=	0x0087
                           0000BA   319 _POWER_CFG	=	0x00ba
                           0000B9   320 _CLOCK_CFG	=	0x00b9
                           0000A9   321 _WAKE_CTRL	=	0x00a9
                           0000FE   322 _RESET_KEEP	=	0x00fe
                           0000FF   323 _WDOG_COUNT	=	0x00ff
                           0000A8   324 _IE	=	0x00a8
                           0000B8   325 _IP	=	0x00b8
                           0000E8   326 _IE_EX	=	0x00e8
                           0000E9   327 _IP_EX	=	0x00e9
                           0000B2   328 _GPIO_IE	=	0x00b2
                           008584   329 _ROM_ADDR	=	0x8584
                           000084   330 _ROM_ADDR_L	=	0x0084
                           000085   331 _ROM_ADDR_H	=	0x0085
                           008F8E   332 _ROM_DATA_HI	=	0x8f8e
                           00008E   333 _ROM_DATA_HL	=	0x008e
                           00008F   334 _ROM_DATA_HH	=	0x008f
                           000086   335 _ROM_CTRL	=	0x0086
                           000080   336 _P0	=	0x0080
                           0000C4   337 _P0_MOD_OC	=	0x00c4
                           0000C5   338 _P0_DIR_PU	=	0x00c5
                           000090   339 _P1	=	0x0090
                           000092   340 _P1_MOD_OC	=	0x0092
                           000093   341 _P1_DIR_PU	=	0x0093
                           0000A0   342 _P2	=	0x00a0
                           000094   343 _P2_MOD_OC	=	0x0094
                           000095   344 _P2_DIR_PU	=	0x0095
                           0000B0   345 _P3	=	0x00b0
                           000096   346 _P3_MOD_OC	=	0x0096
                           000097   347 _P3_DIR_PU	=	0x0097
                           0000C0   348 _P4	=	0x00c0
                           0000C2   349 _P4_MOD_OC	=	0x00c2
                           0000C3   350 _P4_DIR_PU	=	0x00c3
                           0000C1   351 _P4_LED_KEY	=	0x00c1
                           0000AA   352 _P5_IN	=	0x00aa
                           0000AB   353 _P5_OUT_PU	=	0x00ab
                           0000AC   354 _P5_DIR	=	0x00ac
                           0000AD   355 _P6_IN	=	0x00ad
                           0000AE   356 _P6_OUT_PU	=	0x00ae
                           0000AF   357 _P6_DIR	=	0x00af
                           0000F1   358 _P7	=	0x00f1
                           0000A2   359 _XBUS_AUX	=	0x00a2
                           000088   360 _TCON	=	0x0088
                           000089   361 _TMOD	=	0x0089
                           00008A   362 _TL0	=	0x008a
                           00008B   363 _TL1	=	0x008b
                           00008C   364 _TH0	=	0x008c
                           00008D   365 _TH1	=	0x008d
                           000098   366 _SCON	=	0x0098
                           000099   367 _SBUF	=	0x0099
                           0000C8   368 _T2CON	=	0x00c8
                           0000C9   369 _T2MOD	=	0x00c9
                           00CBCA   370 _RCAP2	=	0xcbca
                           0000CA   371 _RCAP2L	=	0x00ca
                           0000CB   372 _RCAP2H	=	0x00cb
                           00CDCC   373 _T2COUNT	=	0xcdcc
                           0000CC   374 _TL2	=	0x00cc
                           0000CD   375 _TH2	=	0x00cd
                           00CFCE   376 _T2CAP1	=	0xcfce
                           0000CE   377 _T2CAP1L	=	0x00ce
                           0000CF   378 _T2CAP1H	=	0x00cf
                           0000F8   379 _SPI0_STAT	=	0x00f8
                           0000F9   380 _SPI0_DATA	=	0x00f9
                           0000FA   381 _SPI0_CTRL	=	0x00fa
                           0000FB   382 _SPI0_CK_SE	=	0x00fb
                           0000FC   383 _SPI0_SETUP	=	0x00fc
                           0000BC   384 _SCON1	=	0x00bc
                           0000BD   385 _SBUF1	=	0x00bd
                           0000BE   386 _SBAUD1	=	0x00be
                           0000BF   387 _SIF1	=	0x00bf
                           0000B4   388 _SPI1_STAT	=	0x00b4
                           0000B5   389 _SPI1_DATA	=	0x00b5
                           0000B6   390 _SPI1_CTRL	=	0x00b6
                           0000B7   391 _SPI1_CK_SE	=	0x00b7
                           0000F3   392 _ADC_CTRL	=	0x00f3
                           00F5F4   393 _ADC_DAT	=	0xf5f4
                           0000F4   394 _ADC_DAT_L	=	0x00f4
                           0000F5   395 _ADC_DAT_H	=	0x00f5
                           0000F6   396 _ADC_CHAN	=	0x00f6
                           0000A6   397 _LED_COMMON	=	0x00a6
                           0000A7   398 _LED_PWM_OE	=	0x00a7
                           00C7C6   399 _LED_DMA	=	0xc7c6
                           0000C6   400 _LED_DMA_L	=	0x00c6
                           0000C7   401 _LED_DMA_H	=	0x00c7
                           0000F7   402 _LED_STATUS	=	0x00f7
                           0000B3   403 _I2CX_INT	=	0x00b3
                           0000BB   404 _I2CS_INT_ST	=	0x00bb
                                    405 ;--------------------------------------------------------
                                    406 ; special function bits
                                    407 ;--------------------------------------------------------
                                    408 	.area RSEG    (ABS,DATA)
      000000                        409 	.org 0x0000
                           0000D7   410 _CY	=	0x00d7
                           0000D6   411 _AC	=	0x00d6
                           0000D5   412 _F0	=	0x00d5
                           0000D4   413 _RS1	=	0x00d4
                           0000D3   414 _RS0	=	0x00d3
                           0000D2   415 _OV	=	0x00d2
                           0000D1   416 _F1	=	0x00d1
                           0000D0   417 _P	=	0x00d0
                           0000AF   418 _EA	=	0x00af
                           0000AE   419 _E_DIS	=	0x00ae
                           0000AD   420 _ET2	=	0x00ad
                           0000AC   421 _ES	=	0x00ac
                           0000AB   422 _ET1	=	0x00ab
                           0000AA   423 _EX1	=	0x00aa
                           0000A9   424 _ET0	=	0x00a9
                           0000A8   425 _EX0	=	0x00a8
                           0000BF   426 _PH_FLAG	=	0x00bf
                           0000BE   427 _PL_FLAG	=	0x00be
                           0000BD   428 _PT2	=	0x00bd
                           0000BC   429 _PS	=	0x00bc
                           0000BB   430 _PT1	=	0x00bb
                           0000BA   431 _PX1	=	0x00ba
                           0000B9   432 _PT0	=	0x00b9
                           0000B8   433 _PX0	=	0x00b8
                           0000EF   434 _IE_WDOG	=	0x00ef
                           0000EE   435 _IE_GPIO	=	0x00ee
                           0000ED   436 _IE_PWM_I2C	=	0x00ed
                           0000EC   437 _IE_UART1	=	0x00ec
                           0000EB   438 _IE_ADC	=	0x00eb
                           0000E9   439 _IE_USB	=	0x00e9
                           0000E8   440 _IE_SPI0	=	0x00e8
                           000087   441 _P0_7	=	0x0087
                           000086   442 _P0_6	=	0x0086
                           000085   443 _P0_5	=	0x0085
                           000084   444 _P0_4	=	0x0084
                           000083   445 _P0_3	=	0x0083
                           000082   446 _P0_2	=	0x0082
                           000081   447 _P0_1	=	0x0081
                           000080   448 _P0_0	=	0x0080
                           000081   449 _SDA0	=	0x0081
                           000080   450 _SCL0	=	0x0080
                           000083   451 _TXD_	=	0x0083
                           000082   452 _RXD_	=	0x0082
                           000085   453 _AIN13	=	0x0085
                           000084   454 _AIN12	=	0x0084
                           000083   455 _AIN11	=	0x0083
                           000082   456 _AIN10	=	0x0082
                           000081   457 _AIN9	=	0x0081
                           000080   458 _AIN8	=	0x0080
                           000097   459 _P1_7	=	0x0097
                           000096   460 _P1_6	=	0x0096
                           000095   461 _P1_5	=	0x0095
                           000094   462 _P1_4	=	0x0094
                           000093   463 _P1_3	=	0x0093
                           000092   464 _P1_2	=	0x0092
                           000091   465 _P1_1	=	0x0091
                           000090   466 _P1_0	=	0x0090
                           000097   467 _TXD1_	=	0x0097
                           000096   468 _RXD1_	=	0x0096
                           000097   469 _SCK	=	0x0097
                           000096   470 _MISO	=	0x0096
                           000095   471 _MOSI	=	0x0095
                           000094   472 _SCS	=	0x0094
                           000092   473 _INT0_	=	0x0092
                           000091   474 _T2EX	=	0x0091
                           000091   475 _CAP2	=	0x0091
                           000090   476 _T2	=	0x0090
                           000090   477 _CAP1	=	0x0090
                           000097   478 _AIN7	=	0x0097
                           000096   479 _AIN6	=	0x0096
                           000095   480 _AIN5	=	0x0095
                           000094   481 _AIN4	=	0x0094
                           000093   482 _AIN3	=	0x0093
                           000092   483 _AIN2	=	0x0092
                           000091   484 _AIN1	=	0x0091
                           000090   485 _AIN0	=	0x0090
                           0000A7   486 _P2_7	=	0x00a7
                           0000A6   487 _P2_6	=	0x00a6
                           0000A5   488 _P2_5	=	0x00a5
                           0000A4   489 _P2_4	=	0x00a4
                           0000A3   490 _P2_3	=	0x00a3
                           0000A2   491 _P2_2	=	0x00a2
                           0000A1   492 _P2_1	=	0x00a1
                           0000A0   493 _P2_0	=	0x00a0
                           0000A7   494 _TXD1	=	0x00a7
                           0000A6   495 _RXD1	=	0x00a6
                           0000A5   496 _T2EX_	=	0x00a5
                           0000A5   497 _CAP2_	=	0x00a5
                           0000A4   498 _T2_	=	0x00a4
                           0000A4   499 _CAP1_	=	0x00a4
                           0000B7   500 _P3_7	=	0x00b7
                           0000B6   501 _P3_6	=	0x00b6
                           0000B5   502 _P3_5	=	0x00b5
                           0000B4   503 _P3_4	=	0x00b4
                           0000B3   504 _P3_3	=	0x00b3
                           0000B2   505 _P3_2	=	0x00b2
                           0000B1   506 _P3_1	=	0x00b1
                           0000B0   507 _P3_0	=	0x00b0
                           0000B7   508 _SCK1	=	0x00b7
                           0000B6   509 _MISO1	=	0x00b6
                           0000B5   510 _MOSI1	=	0x00b5
                           0000B5   511 _T1	=	0x00b5
                           0000B4   512 _T0	=	0x00b4
                           0000B3   513 _INT1	=	0x00b3
                           0000B2   514 _INT0	=	0x00b2
                           0000B1   515 _TXD	=	0x00b1
                           0000B0   516 _RXD	=	0x00b0
                           0000C6   517 _P4_6	=	0x00c6
                           0000C5   518 _P4_5	=	0x00c5
                           0000C4   519 _P4_4	=	0x00c4
                           0000C3   520 _P4_3	=	0x00c3
                           0000C2   521 _P4_2	=	0x00c2
                           0000C1   522 _P4_1	=	0x00c1
                           0000C0   523 _P4_0	=	0x00c0
                           00008F   524 _TF1	=	0x008f
                           00008E   525 _TR1	=	0x008e
                           00008D   526 _TF0	=	0x008d
                           00008C   527 _TR0	=	0x008c
                           00008B   528 _IE1	=	0x008b
                           00008A   529 _IT1	=	0x008a
                           000089   530 _IE0	=	0x0089
                           000088   531 _IT0	=	0x0088
                           00009F   532 _SM0	=	0x009f
                           00009E   533 _SM1	=	0x009e
                           00009D   534 _SM2	=	0x009d
                           00009C   535 _REN	=	0x009c
                           00009B   536 _TB8	=	0x009b
                           00009A   537 _RB8	=	0x009a
                           000099   538 _TI	=	0x0099
                           000098   539 _RI	=	0x0098
                           0000CF   540 _TF2	=	0x00cf
                           0000CF   541 _CAP1F	=	0x00cf
                           0000CE   542 _EXF2	=	0x00ce
                           0000CD   543 _RCLK	=	0x00cd
                           0000CC   544 _TCLK	=	0x00cc
                           0000CB   545 _EXEN2	=	0x00cb
                           0000CA   546 _TR2	=	0x00ca
                           0000C9   547 _C_T2	=	0x00c9
                           0000C8   548 _CP_RL2	=	0x00c8
                           0000FF   549 _S0_FST_ACT	=	0x00ff
                           0000FE   550 _S0_IF_OV	=	0x00fe
                           0000FD   551 _S0_IF_FIRST	=	0x00fd
                           0000FC   552 _S0_IF_BYTE	=	0x00fc
                           0000FB   553 _S0_FREE	=	0x00fb
                           0000FA   554 _S0_T_FIFO	=	0x00fa
                           0000F8   555 _S0_R_FIFO	=	0x00f8
                           0000F7   556 _ADC_START	=	0x00f7
                                    557 ;--------------------------------------------------------
                                    558 ; overlayable register banks
                                    559 ;--------------------------------------------------------
                                    560 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        561 	.ds 8
                                    562 ;--------------------------------------------------------
                                    563 ; internal ram data
                                    564 ;--------------------------------------------------------
                                    565 	.area DSEG    (DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; overlayable items in internal ram
                                    568 ;--------------------------------------------------------
                                    569 ;--------------------------------------------------------
                                    570 ; indirectly addressable internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area ISEG    (DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; absolute internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area IABS    (ABS,DATA)
                                    577 	.area IABS    (ABS,DATA)
                                    578 ;--------------------------------------------------------
                                    579 ; bit data
                                    580 ;--------------------------------------------------------
                                    581 	.area BSEG    (BIT)
      000025                        582 _get_record_keycode_sloc0_1_0:
      000025                        583 	.ds 1
      000026                        584 _pre_process_record_quantum_sloc0_1_0:
      000026                        585 	.ds 1
      000027                        586 _process_ak820_nkro_sloc0_1_0:
      000027                        587 	.ds 1
                                    588 ;--------------------------------------------------------
                                    589 ; paged external ram data
                                    590 ;--------------------------------------------------------
                                    591 	.area PSEG    (PAG,XDATA)
                                    592 ;--------------------------------------------------------
                                    593 ; uninitialized external ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area XSEG    (XDATA)
      000BCD                        596 _extract_mod_bits_code_10000_599:
      000BCD                        597 	.ds 2
      000BCF                        598 _register_code16_code_10000_605:
      000BCF                        599 	.ds 2
      000BD1                        600 _unregister_code16_code_10000_610:
      000BD1                        601 	.ds 2
      000BD3                        602 _pre_process_record_kb_PARM_2:
      000BD3                        603 	.ds 3
      000BD6                        604 _pre_process_record_kb_keycode_10000_624:
      000BD6                        605 	.ds 2
      000BD8                        606 _pre_process_record_user_PARM_2:
      000BD8                        607 	.ds 3
      000BDB                        608 _process_record_kb_PARM_2:
      000BDB                        609 	.ds 3
      000BDE                        610 _process_record_kb_keycode_10000_630:
      000BDE                        611 	.ds 2
      000BE0                        612 _process_record_user_PARM_2:
      000BE0                        613 	.ds 3
      000BE3                        614 _post_process_record_kb_PARM_2:
      000BE3                        615 	.ds 3
      000BE6                        616 _post_process_record_kb_keycode_10000_634:
      000BE6                        617 	.ds 2
      000BE8                        618 _post_process_record_user_PARM_2:
      000BE8                        619 	.ds 3
      000BEB                        620 _get_record_keycode_PARM_2:
      000BEB                        621 	.ds 1
      000BEC                        622 _get_record_keycode_record_argument_10000_648:
      000BEC                        623 	.ds 3
      000BEF                        624 _pre_process_record_quantum_record_argument_10000_654:
      000BEF                        625 	.ds 3
      000BF2                        626 _post_process_record_quantum_record_10000_656:
      000BF2                        627 	.ds 3
      000BF5                        628 _process_record_quantum_record_10000_658:
      000BF5                        629 	.ds 3
      000BF8                        630 _process_ak820_nkro_PARM_2:
      000BF8                        631 	.ds 3
      000BFB                        632 _process_ak820_nkro_keycode_10000_660:
      000BFB                        633 	.ds 2
      000BFD                        634 _process_record_quantum_helper_PARM_2:
      000BFD                        635 	.ds 3
      000C00                        636 _process_record_quantum_helper_keycode_10000_665:
      000C00                        637 	.ds 2
      000C02                        638 _get_u8_str_last_num_10000_691:
      000C02                        639 	.ds 1
      000C03                        640 _get_u16_str_last_num_10000_695:
      000C03                        641 	.ds 2
                                    642 ;--------------------------------------------------------
                                    643 ; absolute external ram data
                                    644 ;--------------------------------------------------------
                                    645 	.area XABS    (ABS,XDATA)
                                    646 ;--------------------------------------------------------
                                    647 ; initialized external ram data
                                    648 ;--------------------------------------------------------
                                    649 	.area XISEG   (XDATA)
                                    650 	.area HOME    (CODE)
                                    651 	.area GSINIT0 (CODE)
                                    652 	.area GSINIT1 (CODE)
                                    653 	.area GSINIT2 (CODE)
                                    654 	.area GSINIT3 (CODE)
                                    655 	.area GSINIT4 (CODE)
                                    656 	.area GSINIT5 (CODE)
                                    657 	.area GSINIT  (CODE)
                                    658 	.area GSFINAL (CODE)
                                    659 	.area CSEG    (CODE)
                                    660 ;--------------------------------------------------------
                                    661 ; global & static initialisations
                                    662 ;--------------------------------------------------------
                                    663 	.area HOME    (CODE)
                                    664 	.area GSINIT  (CODE)
                                    665 	.area GSFINAL (CODE)
                                    666 	.area GSINIT  (CODE)
                                    667 ;------------------------------------------------------------
                                    668 ;Allocation info for local variables in function 'get_u8_str'
                                    669 ;------------------------------------------------------------
                                    670 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    671 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_690'
                                    672 ;buf           Allocated with name '_get_u8_str_buf_10000_691'
                                    673 ;last_num      Allocated with name '_get_u8_str_last_num_10000_691'
                                    674 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_691'
                                    675 ;------------------------------------------------------------
                                    676 ;	quantum/quantum.c:750: static uint8_t last_num = 0xFF;
      0030F3 90 0C 02         [24]  677 	mov	dptr,#_get_u8_str_last_num_10000_691
      0030F6 74 FF            [12]  678 	mov	a,#0xff
      0030F8 F0               [24]  679 	movx	@dptr,a
                                    680 ;------------------------------------------------------------
                                    681 ;Allocation info for local variables in function 'get_u16_str'
                                    682 ;------------------------------------------------------------
                                    683 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    684 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_694'
                                    685 ;buf           Allocated with name '_get_u16_str_buf_10000_695'
                                    686 ;last_num      Allocated with name '_get_u16_str_last_num_10000_695'
                                    687 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_695'
                                    688 ;------------------------------------------------------------
                                    689 ;	quantum/quantum.c:770: static uint16_t last_num = 0xFF;
      0030F9 90 0C 03         [24]  690 	mov	dptr,#_get_u16_str_last_num_10000_695
      0030FC 74 FF            [12]  691 	mov	a,#0xff
      0030FE F0               [24]  692 	movx	@dptr,a
      0030FF E4               [12]  693 	clr	a
      003100 A3               [24]  694 	inc	dptr
      003101 F0               [24]  695 	movx	@dptr,a
                                    696 ;--------------------------------------------------------
                                    697 ; Home
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area HOME    (CODE)
                                    701 ;--------------------------------------------------------
                                    702 ; code
                                    703 ;--------------------------------------------------------
                                    704 	.area CSEG    (CODE)
                                    705 ;------------------------------------------------------------
                                    706 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    707 ;------------------------------------------------------------
                                    708 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    709 ;------------------------------------------------------------
                                    710 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    711 ;	-----------------------------------------
                           000007   712 	ar7 = 0x07
                           000006   713 	ar6 = 0x06
                           000005   714 	ar5 = 0x05
                           000004   715 	ar4 = 0x04
                           000003   716 	ar3 = 0x03
                           000002   717 	ar2 = 0x02
                           000001   718 	ar1 = 0x01
                           000000   719 	ar0 = 0x00
                                    720 ;	 function extract_mod_bits
                                    721 ;	-----------------------------------------
      009AA5                        722 _extract_mod_bits:
      009AA5 12 38 7D         [24]  723 	lcall	_ak820_outline_0103
      009AA8 90 0B CD         [24]  724 	mov	dptr,#_extract_mod_bits_code_10000_599
      009AAB 12 38 82         [24]  725 	lcall	_ak820_outline_0104
                                    726 ;	quantum/quantum.c:107: uint8_t mods = (uint8_t)(code >> 8);
      009AAE 90 0B CD         [24]  727 	mov	dptr,#_extract_mod_bits_code_10000_599
      009AB1 E0               [24]  728 	movx	a,@dptr
      009AB2 A3               [24]  729 	inc	dptr
      009AB3 E0               [24]  730 	movx	a,@dptr
                                    731 ;	quantum/quantum.c:108: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009AB4 FF               [12]  732 	mov	r7,a
      009AB5 60 05            [24]  733 	jz	00101$
      009AB7 EF               [12]  734 	mov	a,r7
      009AB8 24 E0            [12]  735 	add	a,#0xff - 0x1f
      009ABA 50 04            [24]  736 	jnc	00102$
                                    737 ;	free result
      009ABC                        738 00101$:
      009ABC 75 82 00         [24]  739 	mov	dpl, #0x00
      009ABF 22               [24]  740 	ret
      009AC0                        741 00102$:
                                    742 ;	quantum/quantum.c:109: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009AC0 EF               [12]  743 	mov	a,r7
      009AC1 30 E4 07         [24]  744 	jnb	acc.4,00106$
      009AC4 EF               [12]  745 	mov	a,r7
      009AC5 C4               [12]  746 	swap	a
      009AC6 54 F0            [12]  747 	anl	a,#0xf0
      009AC8 FE               [12]  748 	mov	r6,a
      009AC9 80 02            [24]  749 	sjmp	00107$
      009ACB                        750 00106$:
      009ACB 8F 06            [24]  751 	mov	ar6,r7
      009ACD                        752 00107$:
      009ACD 8E 82            [24]  753 	mov	dpl, r6
                                    754 ;	quantum/quantum.c:137: }
      009ACF 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'do_code16'
                                    758 ;------------------------------------------------------------
                                    759 ;f             Allocated with name '_do_code16_PARM_2'
                                    760 ;code          Allocated with name '_do_code16_code_10000_602'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/quantum.c:139: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function register_code16
                                    765 ;	-----------------------------------------
      009AD0                        766 _register_code16:
      009AD0 12 38 7D         [24]  767 	lcall	_ak820_outline_0103
      009AD3 90 0B CF         [24]  768 	mov	dptr,#_register_code16_code_10000_605
      009AD6 12 38 82         [24]  769 	lcall	_ak820_outline_0104
                                    770 ;	quantum/quantum.c:145: uint8_t mods = extract_mod_bits(code);
      009AD9 90 0B CF         [24]  771 	mov	dptr,#_register_code16_code_10000_605
      009ADC 12 37 F5         [24]  772 	lcall	_ak820_outline_0005
      009ADF C0 07            [24]  773 	push	ar7
      009AE1 C0 06            [24]  774 	push	ar6
      009AE3 12 9A A5         [24]  775 	lcall	_extract_mod_bits
      009AE6 AD 82            [24]  776 	mov	r5, dpl
      009AE8 D0 06            [24]  777 	pop	ar6
      009AEA D0 07            [24]  778 	pop	ar7
                                    779 ;	quantum/quantum.c:146: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009AEC 12 98 DE         [24]  780 	lcall	_ak820_outline_0113
      009AEF 40 07            [24]  781 	jc	00105$
      009AF1 74 E7            [12]  782 	mov	a,#0xe7
      009AF3 9E               [12]  783 	subb	a,r6
      009AF4 E4               [12]  784 	clr	a
      009AF5 9F               [12]  785 	subb	a,r7
      009AF6 50 08            [24]  786 	jnc	00101$
                                    787 ;	free result
      009AF8                        788 00105$:
      009AF8 90 0B CF         [24]  789 	mov	dptr,#_register_code16_code_10000_605
      009AFB 12 6B FD         [24]  790 	lcall	_ak820_outline_0039
      009AFE 70 07            [24]  791 	jnz	00102$
      009B00                        792 00101$:
                                    793 ;	quantum/quantum.c:147: register_mods(mods);
      009B00 8D 82            [24]  794 	mov	dpl, r5
      009B02 12 73 E6         [24]  795 	lcall	_register_mods
      009B05 80 05            [24]  796 	sjmp	00103$
      009B07                        797 00102$:
                                    798 ;	quantum/quantum.c:149: register_weak_mods(mods);
      009B07 8D 82            [24]  799 	mov	dpl, r5
      009B09 12 74 0E         [24]  800 	lcall	_register_weak_mods
      009B0C                        801 00103$:
                                    802 ;	quantum/quantum.c:151: register_code(code);
      009B0C 90 0B CF         [24]  803 	mov	dptr,#_register_code16_code_10000_605
      009B0F E0               [24]  804 	movx	a,@dptr
      009B10 F5 82            [12]  805 	mov	dpl,a
                                    806 ;	quantum/quantum.c:161: }
      009B12 02 72 C3         [24]  807 	ljmp	_register_code
                                    808 ;------------------------------------------------------------
                                    809 ;Allocation info for local variables in function 'unregister_code16'
                                    810 ;------------------------------------------------------------
                                    811 ;code          Allocated with name '_unregister_code16_code_10000_610'
                                    812 ;mods          Allocated with name '_unregister_code16_mods_10000_611'
                                    813 ;------------------------------------------------------------
                                    814 ;	quantum/quantum.c:163: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    815 ;	-----------------------------------------
                                    816 ;	 function unregister_code16
                                    817 ;	-----------------------------------------
      009B15                        818 _unregister_code16:
      009B15 12 38 7D         [24]  819 	lcall	_ak820_outline_0103
      009B18 90 0B D1         [24]  820 	mov	dptr,#_unregister_code16_code_10000_610
      009B1B 12 38 82         [24]  821 	lcall	_ak820_outline_0104
                                    822 ;	quantum/quantum.c:165: uint8_t mods = extract_mod_bits(code);
      009B1E 90 0B D1         [24]  823 	mov	dptr,#_unregister_code16_code_10000_610
      009B21 12 37 F5         [24]  824 	lcall	_ak820_outline_0005
      009B24 C0 07            [24]  825 	push	ar7
      009B26 C0 06            [24]  826 	push	ar6
      009B28 12 9A A5         [24]  827 	lcall	_extract_mod_bits
      009B2B AD 82            [24]  828 	mov	r5, dpl
      009B2D D0 06            [24]  829 	pop	ar6
                                    830 ;	quantum/quantum.c:166: unregister_code(code);
      009B2F 8E 04            [24]  831 	mov	ar4,r6
      009B31 8C 82            [24]  832 	mov	dpl, r4
      009B33 C0 06            [24]  833 	push	ar6
      009B35 C0 05            [24]  834 	push	ar5
      009B37 12 73 30         [24]  835 	lcall	_unregister_code
      009B3A D0 05            [24]  836 	pop	ar5
      009B3C D0 06            [24]  837 	pop	ar6
      009B3E D0 07            [24]  838 	pop	ar7
                                    839 ;	quantum/quantum.c:167: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009B40 12 98 DE         [24]  840 	lcall	_ak820_outline_0113
      009B43 40 07            [24]  841 	jc	00105$
      009B45 74 E7            [12]  842 	mov	a,#0xe7
      009B47 9E               [12]  843 	subb	a,r6
      009B48 E4               [12]  844 	clr	a
      009B49 9F               [12]  845 	subb	a,r7
      009B4A 50 08            [24]  846 	jnc	00101$
                                    847 ;	free result
      009B4C                        848 00105$:
      009B4C 90 0B D1         [24]  849 	mov	dptr,#_unregister_code16_code_10000_610
      009B4F 12 6B FD         [24]  850 	lcall	_ak820_outline_0039
      009B52 70 05            [24]  851 	jnz	00102$
      009B54                        852 00101$:
                                    853 ;	quantum/quantum.c:168: unregister_mods(mods);
      009B54 8D 82            [24]  854 	mov	dpl, r5
      009B56 02 73 FA         [24]  855 	ljmp	_unregister_mods
      009B59                        856 00102$:
                                    857 ;	quantum/quantum.c:170: unregister_weak_mods(mods);
      009B59 8D 82            [24]  858 	mov	dpl, r5
                                    859 ;	quantum/quantum.c:181: }
      009B5B 02 74 22         [24]  860 	ljmp	_unregister_weak_mods
                                    861 ;------------------------------------------------------------
                                    862 ;Allocation info for local variables in function 'tap_code16_delay'
                                    863 ;------------------------------------------------------------
                                    864 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    865 ;code          Allocated with name '_tap_code16_delay_code_10000_615'
                                    866 ;i             Allocated with name '_tap_code16_delay_i_20000_617'
                                    867 ;i             Allocated with name '_tap_code16_delay_i_50000_620'
                                    868 ;------------------------------------------------------------
                                    869 ;	quantum/quantum.c:188: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    870 ;	-----------------------------------------
                                    871 ;	 function pre_process_record_kb
                                    872 ;	-----------------------------------------
      009B5E                        873 _pre_process_record_kb:
      009B5E 12 38 7D         [24]  874 	lcall	_ak820_outline_0103
      009B61 90 0B D6         [24]  875 	mov	dptr,#_pre_process_record_kb_keycode_10000_624
      009B64 12 38 82         [24]  876 	lcall	_ak820_outline_0104
                                    877 ;	quantum/quantum.c:205: return pre_process_record_user(keycode, record);
      009B67 90 0B D6         [24]  878 	mov	dptr,#_pre_process_record_kb_keycode_10000_624
      009B6A 12 38 42         [24]  879 	lcall	_ak820_outline_0051
      009B6D 90 0B D3         [24]  880 	mov	dptr,#_pre_process_record_kb_PARM_2
      009B70 12 98 D5         [24]  881 	lcall	_ak820_outline_0024
      009B73 90 0B D8         [24]  882 	mov	dptr,#_pre_process_record_user_PARM_2
      009B76 12 9E C0         [24]  883 	lcall	_ak820_outline_0010
                                    884 ;	quantum/quantum.c:206: }
      009B79 02 9B 7C         [24]  885 	ljmp	_pre_process_record_user
                                    886 ;------------------------------------------------------------
                                    887 ;Allocation info for local variables in function 'pre_process_record_user'
                                    888 ;------------------------------------------------------------
                                    889 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    890 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_626'
                                    891 ;------------------------------------------------------------
                                    892 ;	quantum/quantum.c:208: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    893 ;	-----------------------------------------
                                    894 ;	 function pre_process_record_user
                                    895 ;	-----------------------------------------
      009B7C                        896 _pre_process_record_user:
                                    897 ;	quantum/quantum.c:209: return true;
      009B7C 75 82 01         [24]  898 	mov	dpl, #0x01
                                    899 ;	quantum/quantum.c:210: }
      009B7F 22               [24]  900 	ret
                                    901 ;------------------------------------------------------------
                                    902 ;Allocation info for local variables in function 'process_action_kb'
                                    903 ;------------------------------------------------------------
                                    904 ;record        Allocated with name '_process_action_kb_record_10000_628'
                                    905 ;------------------------------------------------------------
                                    906 ;	quantum/quantum.c:212: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    907 ;	-----------------------------------------
                                    908 ;	 function process_action_kb
                                    909 ;	-----------------------------------------
      009B80                        910 _process_action_kb:
                                    911 ;	quantum/quantum.c:213: return true;
      009B80 75 82 01         [24]  912 	mov	dpl, #0x01
                                    913 ;	quantum/quantum.c:214: }
      009B83 22               [24]  914 	ret
                                    915 ;------------------------------------------------------------
                                    916 ;Allocation info for local variables in function 'process_record_kb'
                                    917 ;------------------------------------------------------------
                                    918 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    919 ;keycode       Allocated with name '_process_record_kb_keycode_10000_630'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/quantum.c:216: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function process_record_kb
                                    924 ;	-----------------------------------------
      009B84                        925 _process_record_kb:
      009B84 12 38 7D         [24]  926 	lcall	_ak820_outline_0103
      009B87 90 0B DE         [24]  927 	mov	dptr,#_process_record_kb_keycode_10000_630
      009B8A 12 38 82         [24]  928 	lcall	_ak820_outline_0104
                                    929 ;	quantum/quantum.c:217: return process_record_user(keycode, record);
      009B8D 90 0B DE         [24]  930 	mov	dptr,#_process_record_kb_keycode_10000_630
      009B90 12 38 42         [24]  931 	lcall	_ak820_outline_0051
      009B93 90 0B DB         [24]  932 	mov	dptr,#_process_record_kb_PARM_2
      009B96 12 98 D5         [24]  933 	lcall	_ak820_outline_0024
      009B99 90 0B E0         [24]  934 	mov	dptr,#_process_record_user_PARM_2
      009B9C 12 9E C0         [24]  935 	lcall	_ak820_outline_0010
                                    936 ;	quantum/quantum.c:218: }
      009B9F 02 9B A2         [24]  937 	ljmp	_process_record_user
                                    938 ;------------------------------------------------------------
                                    939 ;Allocation info for local variables in function 'process_record_user'
                                    940 ;------------------------------------------------------------
                                    941 ;record        Allocated with name '_process_record_user_PARM_2'
                                    942 ;keycode       Allocated with name '_process_record_user_keycode_10000_632'
                                    943 ;------------------------------------------------------------
                                    944 ;	quantum/quantum.c:220: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    945 ;	-----------------------------------------
                                    946 ;	 function process_record_user
                                    947 ;	-----------------------------------------
      009BA2                        948 _process_record_user:
                                    949 ;	quantum/quantum.c:221: return true;
      009BA2 75 82 01         [24]  950 	mov	dpl, #0x01
                                    951 ;	quantum/quantum.c:222: }
      009BA5 22               [24]  952 	ret
                                    953 ;------------------------------------------------------------
                                    954 ;Allocation info for local variables in function 'post_process_record_kb'
                                    955 ;------------------------------------------------------------
                                    956 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    957 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_634'
                                    958 ;------------------------------------------------------------
                                    959 ;	quantum/quantum.c:224: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    960 ;	-----------------------------------------
                                    961 ;	 function post_process_record_kb
                                    962 ;	-----------------------------------------
      009BA6                        963 _post_process_record_kb:
      009BA6 12 38 7D         [24]  964 	lcall	_ak820_outline_0103
      009BA9 90 0B E6         [24]  965 	mov	dptr,#_post_process_record_kb_keycode_10000_634
      009BAC 12 38 82         [24]  966 	lcall	_ak820_outline_0104
                                    967 ;	quantum/quantum.c:225: post_process_record_user(keycode, record);
      009BAF 90 0B E6         [24]  968 	mov	dptr,#_post_process_record_kb_keycode_10000_634
      009BB2 12 38 42         [24]  969 	lcall	_ak820_outline_0051
      009BB5 90 0B E3         [24]  970 	mov	dptr,#_post_process_record_kb_PARM_2
      009BB8 12 98 D5         [24]  971 	lcall	_ak820_outline_0024
      009BBB 90 0B E8         [24]  972 	mov	dptr,#_post_process_record_user_PARM_2
      009BBE 12 9E C0         [24]  973 	lcall	_ak820_outline_0010
                                    974 ;	quantum/quantum.c:226: }
      009BC1 02 9B C4         [24]  975 	ljmp	_post_process_record_user
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'post_process_record_user'
                                    978 ;------------------------------------------------------------
                                    979 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    980 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_636'
                                    981 ;------------------------------------------------------------
                                    982 ;	quantum/quantum.c:228: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    983 ;	-----------------------------------------
                                    984 ;	 function post_process_record_user
                                    985 ;	-----------------------------------------
      009BC4                        986 _post_process_record_user:
      009BC4 22               [24]  987 	ret
                                    988 ;------------------------------------------------------------
                                    989 ;Allocation info for local variables in function 'shutdown_quantum'
                                    990 ;------------------------------------------------------------
                                    991 ;i             Allocated with name '_shutdown_quantum_i_30000_642'
                                    992 ;------------------------------------------------------------
                                    993 ;	quantum/quantum.c:230: void shutdown_quantum(void) {
                                    994 ;	-----------------------------------------
                                    995 ;	 function shutdown_quantum
                                    996 ;	-----------------------------------------
      009BC5                        997 _shutdown_quantum:
                                    998 ;	quantum/quantum.c:231: clear_keyboard();
      009BC5 12 74 36         [24]  999 	lcall	_clear_keyboard
                                   1000 ;	quantum/quantum.c:246: shutdown_user();
      009BC8 12 9E B2         [24] 1001 	lcall	_shutdown_user
                                   1002 ;	quantum/quantum.c:247: wait_ms(250);
      009BCB 7F FA            [12] 1003 	mov	r7,#0xfa
      009BCD                       1004 00106$:
      009BCD EF               [12] 1005 	mov	a,r7
      009BCE 60 09            [24] 1006 	jz	00108$
      009BD0 90 00 01         [24] 1007 	mov	dptr,#0x0001
      009BD3 12 57 69         [24] 1008 	lcall	_mDelaymS
      009BD6 1F               [12] 1009 	dec	r7
      009BD7 80 F4            [24] 1010 	sjmp	00106$
      009BD9                       1011 00108$:
                                   1012 ;	quantum/quantum.c:252: }
      009BD9 22               [24] 1013 	ret
                                   1014 ;------------------------------------------------------------
                                   1015 ;Allocation info for local variables in function 'reset_keyboard'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/quantum.c:254: void reset_keyboard(void) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function reset_keyboard
                                   1020 ;	-----------------------------------------
      009BDA                       1021 _reset_keyboard:
                                   1022 ;	quantum/quantum.c:255: shutdown_quantum();
      009BDA 12 9B C5         [24] 1023 	lcall	_shutdown_quantum
                                   1024 ;	quantum/quantum.c:256: bootloader_jump();
                                   1025 ;	quantum/quantum.c:257: }
      009BDD 02 34 0E         [24] 1026 	ljmp	_bootloader_jump
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/quantum.c:259: void soft_reset_keyboard(void) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function soft_reset_keyboard
                                   1033 ;	-----------------------------------------
      009BE0                       1034 _soft_reset_keyboard:
                                   1035 ;	quantum/quantum.c:260: shutdown_quantum();
      009BE0 12 9B C5         [24] 1036 	lcall	_shutdown_quantum
                                   1037 ;	quantum/quantum.c:261: mcu_reset();
                                   1038 ;	quantum/quantum.c:262: }
      009BE3 02 34 01         [24] 1039 	ljmp	_mcu_reset
                                   1040 ;------------------------------------------------------------
                                   1041 ;Allocation info for local variables in function 'get_record_keycode'
                                   1042 ;------------------------------------------------------------
                                   1043 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1044 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_648'
                                   1045 ;record        Allocated with name '_get_record_keycode_record_10000_649'
                                   1046 ;------------------------------------------------------------
                                   1047 ;	quantum/quantum.c:265: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1048 ;	-----------------------------------------
                                   1049 ;	 function get_record_keycode
                                   1050 ;	-----------------------------------------
      009BE6                       1051 _get_record_keycode:
      009BE6 12 43 0E         [24] 1052 	lcall	_ak820_outline_0036
      009BE9 90 0B EC         [24] 1053 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009BEC 12 38 2A         [24] 1054 	lcall	_ak820_outline_0016
                                   1055 ;	quantum/quantum.c:267: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009BEF 90 0B EC         [24] 1056 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      009BF2 12 37 FF         [24] 1057 	lcall	_ak820_outline_0007
                                   1058 ;	quantum/quantum.c:272: if (record->keycode) {
      009BF5 4C               [12] 1059 	orl	a,r4
      009BF6 60 04            [24] 1060 	jz	00102$
                                   1061 ;	quantum/quantum.c:273: return record->keycode;
      009BF8 12 38 92         [24] 1062 	lcall	_ak820_outline_0119
      009BFB 22               [24] 1063 	ret
      009BFC                       1064 00102$:
                                   1065 ;	quantum/quantum.c:277: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      009BFC 12 74 83         [24] 1066 	lcall	_ak820_outline_0019
      009BFF 7A 00            [12] 1067 	mov	r2,#0x00
      009C01 12 43 61         [24] 1068 	lcall	_ak820_outline_0136
      009C04 12 38 13         [24] 1069 	lcall	_ak820_outline_0009
      009C07 60 06            [24] 1070 	jz	00105$
      009C09 90 0B EB         [24] 1071 	mov	dptr,#_get_record_keycode_PARM_2
      009C0C E0               [24] 1072 	movx	a,@dptr
      009C0D 70 04            [24] 1073 	jnz	00106$
      009C0F                       1074 00105$:
                                   1075 ;	assignBit
      009C0F C2 25            [12] 1076 	clr	_get_record_keycode_sloc0_1_0
      009C11 80 02            [24] 1077 	sjmp	00107$
      009C13                       1078 00106$:
                                   1079 ;	assignBit
      009C13 D2 25            [12] 1080 	setb	_get_record_keycode_sloc0_1_0
      009C15                       1081 00107$:
      009C15 90 09 60         [24] 1082 	mov	dptr,#_ak820_resolve_key_PARM_2
      009C18 A2 25            [12] 1083 	mov	c,_get_record_keycode_sloc0_1_0
      009C1A E4               [12] 1084 	clr	a
      009C1B 33               [12] 1085 	rlc	a
      009C1C F0               [24] 1086 	movx	@dptr,a
      009C1D 8D 82            [24] 1087 	mov	dpl, r5
      009C1F 8C 83            [24] 1088 	mov	dph, r4
                                   1089 ;	quantum/quantum.c:281: }
      009C21 02 78 1B         [24] 1090 	ljmp	_ak820_resolve_key
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'get_event_keycode'
                                   1093 ;------------------------------------------------------------
                                   1094 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1095 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_652'
                                   1096 ;------------------------------------------------------------
                                   1097 ;	quantum/quantum.c:289: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1098 ;	-----------------------------------------
                                   1099 ;	 function pre_process_record_quantum
                                   1100 ;	-----------------------------------------
      009C24                       1101 _pre_process_record_quantum:
      009C24 12 43 0E         [24] 1102 	lcall	_ak820_outline_0036
      009C27 90 0B EF         [24] 1103 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009C2A 12 38 2A         [24] 1104 	lcall	_ak820_outline_0016
                                   1105 ;	quantum/quantum.c:322: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009C2D 90 0B EF         [24] 1106 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      009C30 12 38 42         [24] 1107 	lcall	_ak820_outline_0051
                                   1108 ;	quantum/quantum.c:326: uint16_t keycode = get_record_keycode(record, true);
      009C33 8E 03            [24] 1109 	mov	ar3,r6
      009C35 8F 04            [24] 1110 	mov	ar4,r7
      009C37 7D 00            [12] 1111 	mov	r5,#0x00
      009C39 90 0B EB         [24] 1112 	mov	dptr,#_get_record_keycode_PARM_2
      009C3C 74 01            [12] 1113 	mov	a,#0x01
      009C3E F0               [24] 1114 	movx	@dptr,a
      009C3F 12 33 FC         [24] 1115 	lcall	_ak820_outline_0118
      009C42 8D F0            [24] 1116 	mov	b, r5
      009C44 C0 07            [24] 1117 	push	ar7
      009C46 C0 06            [24] 1118 	push	ar6
      009C48 12 9B E6         [24] 1119 	lcall	_get_record_keycode
      009C4B 12 43 67         [24] 1120 	lcall	_ak820_outline_0143
      009C4E D0 06            [24] 1121 	pop	ar6
      009C50 D0 07            [24] 1122 	pop	ar7
                                   1123 ;	quantum/quantum.c:328: record->keycode = keycode;
      009C52 74 07            [12] 1124 	mov	a,#0x07
      009C54 12 38 32         [24] 1125 	lcall	_ak820_outline_0020
      009C57 12 38 5F         [24] 1126 	lcall	_ak820_outline_0071
                                   1127 ;	quantum/quantum.c:338: return pre_process_record_kb(keycode, record) &&
      009C5A 90 0B D3         [24] 1128 	mov	dptr,#_pre_process_record_kb_PARM_2
      009C5D 12 9E B3         [24] 1129 	lcall	_ak820_outline_0002
      009C60 C0 07            [24] 1130 	push	ar7
      009C62 C0 06            [24] 1131 	push	ar6
      009C64 12 9B 5E         [24] 1132 	lcall	_pre_process_record_kb
      009C67 E5 82            [12] 1133 	mov	a, dpl
      009C69 D0 06            [24] 1134 	pop	ar6
      009C6B D0 07            [24] 1135 	pop	ar7
      009C6D 60 0A            [24] 1136 	jz	00103$
                                   1137 ;	quantum/quantum.c:341: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      009C6F 12 38 87         [24] 1138 	lcall	_ak820_outline_0112
      009C72 12 36 3B         [24] 1139 	lcall	_ak820_combo_process
      009C75 E5 82            [12] 1140 	mov	a, dpl
      009C77 70 04            [24] 1141 	jnz	00104$
                                   1142 ;	quantum/quantum.c:346: true;
      009C79                       1143 00103$:
                                   1144 ;	assignBit
      009C79 C2 26            [12] 1145 	clr	_pre_process_record_quantum_sloc0_1_0
      009C7B 80 02            [24] 1146 	sjmp	00105$
      009C7D                       1147 00104$:
                                   1148 ;	assignBit
      009C7D D2 26            [12] 1149 	setb	_pre_process_record_quantum_sloc0_1_0
      009C7F                       1150 00105$:
      009C7F A2 26            [12] 1151 	mov	c,_pre_process_record_quantum_sloc0_1_0
      009C81 12 38 B1         [24] 1152 	lcall	_ak820_outline_0150
                                   1153 ;	quantum/quantum.c:347: }
      009C84 22               [24] 1154 	ret
                                   1155 ;------------------------------------------------------------
                                   1156 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1157 ;------------------------------------------------------------
                                   1158 ;record        Allocated with name '_post_process_record_quantum_record_10000_656'
                                   1159 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_657'
                                   1160 ;------------------------------------------------------------
                                   1161 ;	quantum/quantum.c:350: void post_process_record_quantum(keyrecord_t *record) {
                                   1162 ;	-----------------------------------------
                                   1163 ;	 function post_process_record_quantum
                                   1164 ;	-----------------------------------------
      009C85                       1165 _post_process_record_quantum:
      009C85 12 43 0E         [24] 1166 	lcall	_ak820_outline_0036
      009C88 90 0B F2         [24] 1167 	mov	dptr,#_post_process_record_quantum_record_10000_656
      009C8B 12 38 2A         [24] 1168 	lcall	_ak820_outline_0016
                                   1169 ;	quantum/quantum.c:351: uint16_t keycode = get_record_keycode(record, false);
      009C8E 90 0B F2         [24] 1170 	mov	dptr,#_post_process_record_quantum_record_10000_656
      009C91 12 4D 9B         [24] 1171 	lcall	_ak820_outline_0013
      009C94 90 0B EB         [24] 1172 	mov	dptr,#_get_record_keycode_PARM_2
      009C97 E4               [12] 1173 	clr	a
      009C98 12 4D A4         [24] 1174 	lcall	_ak820_outline_0038
      009C9B 12 9B E6         [24] 1175 	lcall	_get_record_keycode
      009C9E 12 43 56         [24] 1176 	lcall	_ak820_outline_0129
                                   1177 ;	quantum/quantum.c:352: post_process_record_kb(keycode, record);
      009CA1 90 0B F2         [24] 1178 	mov	dptr,#_post_process_record_quantum_record_10000_656
      009CA4 12 98 D5         [24] 1179 	lcall	_ak820_outline_0024
      009CA7 90 0B E3         [24] 1180 	mov	dptr,#_post_process_record_kb_PARM_2
      009CAA 12 9E C0         [24] 1181 	lcall	_ak820_outline_0010
                                   1182 ;	quantum/quantum.c:353: }
      009CAD 02 9B A6         [24] 1183 	ljmp	_post_process_record_kb
                                   1184 ;------------------------------------------------------------
                                   1185 ;Allocation info for local variables in function 'process_record_quantum'
                                   1186 ;------------------------------------------------------------
                                   1187 ;record        Allocated with name '_process_record_quantum_record_10000_658'
                                   1188 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_659'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	quantum/quantum.c:355: bool process_record_quantum(keyrecord_t *record) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function process_record_quantum
                                   1193 ;	-----------------------------------------
      009CB0                       1194 _process_record_quantum:
      009CB0 12 43 0E         [24] 1195 	lcall	_ak820_outline_0036
      009CB3 90 0B F5         [24] 1196 	mov	dptr,#_process_record_quantum_record_10000_658
      009CB6 12 38 2A         [24] 1197 	lcall	_ak820_outline_0016
                                   1198 ;	quantum/quantum.c:357: uint16_t keycode = get_record_keycode(record, false);
      009CB9 90 0B F5         [24] 1199 	mov	dptr,#_process_record_quantum_record_10000_658
      009CBC 12 4D 9B         [24] 1200 	lcall	_ak820_outline_0013
      009CBF 90 0B EB         [24] 1201 	mov	dptr,#_get_record_keycode_PARM_2
      009CC2 E4               [12] 1202 	clr	a
      009CC3 12 4D A4         [24] 1203 	lcall	_ak820_outline_0038
      009CC6 12 9B E6         [24] 1204 	lcall	_get_record_keycode
      009CC9 12 43 56         [24] 1205 	lcall	_ak820_outline_0129
                                   1206 ;	quantum/quantum.c:361: return process_record_quantum_helper(keycode, record);
      009CCC 90 0B F5         [24] 1207 	mov	dptr,#_process_record_quantum_record_10000_658
      009CCF 12 98 D5         [24] 1208 	lcall	_ak820_outline_0024
      009CD2 90 0B FD         [24] 1209 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009CD5 12 9E C0         [24] 1210 	lcall	_ak820_outline_0010
                                   1211 ;	quantum/quantum.c:362: }
      009CD8 02 9D 46         [24] 1212 	ljmp	_process_record_quantum_helper
                                   1213 ;------------------------------------------------------------
                                   1214 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1215 ;------------------------------------------------------------
                                   1216 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1217 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_660'
                                   1218 ;record        Allocated with name '_process_ak820_nkro_record_10000_661'
                                   1219 ;------------------------------------------------------------
                                   1220 ;	quantum/quantum.c:369: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1221 ;	-----------------------------------------
                                   1222 ;	 function process_ak820_nkro
                                   1223 ;	-----------------------------------------
      009CDB                       1224 _process_ak820_nkro:
      009CDB 12 38 7D         [24] 1225 	lcall	_ak820_outline_0103
      009CDE 90 0B FB         [24] 1226 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      009CE1 12 38 82         [24] 1227 	lcall	_ak820_outline_0104
                                   1228 ;	quantum/quantum.c:371: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009CE4 90 0B F8         [24] 1229 	mov	dptr,#_process_ak820_nkro_PARM_2
      009CE7 12 38 42         [24] 1230 	lcall	_ak820_outline_0051
                                   1231 ;	quantum/quantum.c:375: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      009CEA 90 0B FB         [24] 1232 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      009CED 12 38 59         [24] 1233 	lcall	_ak820_outline_0059
      009CF0 C3               [12] 1234 	clr	c
      009CF1 EC               [12] 1235 	mov	a,r4
      009CF2 94 11            [12] 1236 	subb	a,#0x11
      009CF4 ED               [12] 1237 	mov	a,r5
      009CF5 94 70            [12] 1238 	subb	a,#0x70
      009CF7 40 08            [24] 1239 	jc	00101$
      009CF9 74 13            [12] 1240 	mov	a,#0x13
      009CFB 9C               [12] 1241 	subb	a,r4
      009CFC 74 70            [12] 1242 	mov	a,#0x70
      009CFE 9D               [12] 1243 	subb	a,r5
      009CFF 50 04            [24] 1244 	jnc	00102$
                                   1245 ;	free result
      009D01                       1246 00101$:
      009D01 75 82 01         [24] 1247 	mov	dpl, #0x01
      009D04 22               [24] 1248 	ret
      009D05                       1249 00102$:
                                   1250 ;	quantum/quantum.c:376: if (record->event.pressed) {
      009D05 12 38 13         [24] 1251 	lcall	_ak820_outline_0009
      009D08 60 38            [24] 1252 	jz	00105$
                                   1253 ;	quantum/quantum.c:377: clear_keyboard();
      009D0A C0 05            [24] 1254 	push	ar5
      009D0C C0 04            [24] 1255 	push	ar4
      009D0E 12 74 36         [24] 1256 	lcall	_clear_keyboard
      009D11 D0 04            [24] 1257 	pop	ar4
      009D13 D0 05            [24] 1258 	pop	ar5
                                   1259 ;	quantum/quantum.c:378: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      009D15 BC 13 14         [24] 1260 	cjne	r4,#0x13,00108$
      009D18 BD 70 11         [24] 1261 	cjne	r5,#0x70,00108$
      009D1B 90 0A B2         [24] 1262 	mov	dptr,#_keymap_config
      009D1E E0               [24] 1263 	movx	a,@dptr
      009D1F 23               [12] 1264 	rl	a
      009D20 54 01            [12] 1265 	anl	a,#0x01
      009D22 B4 01 00         [24] 1266 	cjne	a,#0x01,00136$
      009D25                       1267 00136$:
      009D25 92 27            [24] 1268 	mov  _process_ak820_nkro_sloc0_1_0,c
      009D27 E4               [12] 1269 	clr	a
      009D28 33               [12] 1270 	rlc	a
      009D29 FF               [12] 1271 	mov	r7,a
      009D2A 80 09            [24] 1272 	sjmp	00109$
      009D2C                       1273 00108$:
      009D2C E4               [12] 1274 	clr	a
      009D2D BC 11 04         [24] 1275 	cjne	r4,#0x11,00137$
      009D30 BD 70 01         [24] 1276 	cjne	r5,#0x70,00137$
      009D33 04               [12] 1277 	inc	a
      009D34                       1278 00137$:
      009D34 FF               [12] 1279 	mov	r7,a
      009D35                       1280 00109$:
                                   1281 ;	assignBit
      009D35 EF               [12] 1282 	mov	a,r7
      009D36 24 FF            [12] 1283 	add	a,#0xff
      009D38 E4               [12] 1284 	clr	a
      009D39 33               [12] 1285 	rlc	a
      009D3A 90 0A B2         [24] 1286 	mov	dptr,#_keymap_config
      009D3D 13               [12] 1287 	rrc	a
      009D3E E0               [24] 1288 	movx	a,@dptr
      009D3F 92 E7            [24] 1289 	mov	acc.7,c
      009D41 F0               [24] 1290 	movx	@dptr,a
      009D42                       1291 00105$:
                                   1292 ;	quantum/quantum.c:380: return false;
      009D42 75 82 00         [24] 1293 	mov	dpl, #0x00
                                   1294 ;	quantum/quantum.c:381: }
      009D45 22               [24] 1295 	ret
                                   1296 ;------------------------------------------------------------
                                   1297 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1298 ;------------------------------------------------------------
                                   1299 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1300 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_665'
                                   1301 ;record        Allocated with name '_process_record_quantum_helper_record_10000_666'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/quantum.c:384: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function process_record_quantum_helper
                                   1306 ;	-----------------------------------------
      009D46                       1307 _process_record_quantum_helper:
      009D46 12 38 7D         [24] 1308 	lcall	_ak820_outline_0103
      009D49 90 0C 00         [24] 1309 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      009D4C 12 38 82         [24] 1310 	lcall	_ak820_outline_0104
                                   1311 ;	quantum/quantum.c:386: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      009D4F 90 0B FD         [24] 1312 	mov	dptr,#_process_record_quantum_helper_PARM_2
      009D52 12 38 42         [24] 1313 	lcall	_ak820_outline_0051
                                   1314 ;	quantum/quantum.c:429: process_ak820_nkro(keycode, record) &&
      009D55 90 0C 00         [24] 1315 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      009D58 12 38 59         [24] 1316 	lcall	_ak820_outline_0059
      009D5B 90 0B F8         [24] 1317 	mov	dptr,#_process_ak820_nkro_PARM_2
      009D5E 12 9E B3         [24] 1318 	lcall	_ak820_outline_0002
      009D61 C0 07            [24] 1319 	push	ar7
      009D63 C0 06            [24] 1320 	push	ar6
      009D65 C0 05            [24] 1321 	push	ar5
      009D67 C0 04            [24] 1322 	push	ar4
      009D69 12 9C DB         [24] 1323 	lcall	_process_ak820_nkro
      009D6C E5 82            [12] 1324 	mov	a, dpl
      009D6E D0 04            [24] 1325 	pop	ar4
      009D70 D0 05            [24] 1326 	pop	ar5
      009D72 D0 06            [24] 1327 	pop	ar6
      009D74 D0 07            [24] 1328 	pop	ar7
      009D76 70 03            [24] 1329 	jnz	00204$
      009D78 02 9E 6F         [24] 1330 	ljmp	00101$
      009D7B                       1331 00204$:
                                   1332 ;	quantum/quantum.c:440: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      009D7B 90 0B B6         [24] 1333 	mov	dptr,#_process_last_key_PARM_2
      009D7E 12 9E B3         [24] 1334 	lcall	_ak820_outline_0002
      009D81 C0 07            [24] 1335 	push	ar7
      009D83 C0 06            [24] 1336 	push	ar6
      009D85 C0 05            [24] 1337 	push	ar5
      009D87 C0 04            [24] 1338 	push	ar4
      009D89 12 98 0E         [24] 1339 	lcall	_process_last_key
      009D8C E5 82            [12] 1340 	mov	a, dpl
      009D8E D0 04            [24] 1341 	pop	ar4
      009D90 D0 05            [24] 1342 	pop	ar5
      009D92 D0 06            [24] 1343 	pop	ar6
      009D94 D0 07            [24] 1344 	pop	ar7
      009D96 70 03            [24] 1345 	jnz	00205$
      009D98 02 9E 6F         [24] 1346 	ljmp	00101$
      009D9B                       1347 00205$:
      009D9B 90 0B BC         [24] 1348 	mov	dptr,#_process_repeat_key_PARM_2
      009D9E 12 9E B3         [24] 1349 	lcall	_ak820_outline_0002
      009DA1 C0 07            [24] 1350 	push	ar7
      009DA3 C0 06            [24] 1351 	push	ar6
      009DA5 C0 05            [24] 1352 	push	ar5
      009DA7 C0 04            [24] 1353 	push	ar4
      009DA9 12 98 8C         [24] 1354 	lcall	_process_repeat_key
      009DAC E5 82            [12] 1355 	mov	a, dpl
      009DAE D0 04            [24] 1356 	pop	ar4
      009DB0 D0 05            [24] 1357 	pop	ar5
      009DB2 D0 06            [24] 1358 	pop	ar6
      009DB4 D0 07            [24] 1359 	pop	ar7
      009DB6 70 03            [24] 1360 	jnz	00206$
      009DB8 02 9E 6F         [24] 1361 	ljmp	00101$
      009DBB                       1362 00206$:
                                   1363 ;	quantum/quantum.c:449: process_record_via(keycode, record) &&
      009DBB 90 0C 3D         [24] 1364 	mov	dptr,#_process_record_via_PARM_2
      009DBE 12 9E B3         [24] 1365 	lcall	_ak820_outline_0002
      009DC1 C0 07            [24] 1366 	push	ar7
      009DC3 C0 06            [24] 1367 	push	ar6
      009DC5 C0 05            [24] 1368 	push	ar5
      009DC7 C0 04            [24] 1369 	push	ar4
      009DC9 12 A3 C5         [24] 1370 	lcall	_process_record_via
      009DCC E5 82            [12] 1371 	mov	a, dpl
      009DCE D0 04            [24] 1372 	pop	ar4
      009DD0 D0 05            [24] 1373 	pop	ar5
      009DD2 D0 06            [24] 1374 	pop	ar6
      009DD4 D0 07            [24] 1375 	pop	ar7
      009DD6 70 03            [24] 1376 	jnz	00207$
      009DD8 02 9E 6F         [24] 1377 	ljmp	00101$
      009DDB                       1378 00207$:
                                   1379 ;	quantum/quantum.c:459: process_record_kb(keycode, record) &&
      009DDB 90 0B DB         [24] 1380 	mov	dptr,#_process_record_kb_PARM_2
      009DDE 12 9E B3         [24] 1381 	lcall	_ak820_outline_0002
      009DE1 C0 07            [24] 1382 	push	ar7
      009DE3 C0 06            [24] 1383 	push	ar6
      009DE5 C0 05            [24] 1384 	push	ar5
      009DE7 C0 04            [24] 1385 	push	ar4
      009DE9 12 9B 84         [24] 1386 	lcall	_process_record_kb
      009DEC E5 82            [12] 1387 	mov	a, dpl
      009DEE D0 04            [24] 1388 	pop	ar4
      009DF0 D0 05            [24] 1389 	pop	ar5
      009DF2 D0 06            [24] 1390 	pop	ar6
      009DF4 D0 07            [24] 1391 	pop	ar7
      009DF6 70 03            [24] 1392 	jnz	00208$
      009DF8 02 9E 6F         [24] 1393 	ljmp	00101$
      009DFB                       1394 00208$:
                                   1395 ;	quantum/quantum.c:482: process_caps_word(keycode, record) &&
      009DFB 90 0B 9E         [24] 1396 	mov	dptr,#_process_caps_word_PARM_2
      009DFE 12 9E B3         [24] 1397 	lcall	_ak820_outline_0002
      009E01 C0 07            [24] 1398 	push	ar7
      009E03 C0 06            [24] 1399 	push	ar6
      009E05 C0 05            [24] 1400 	push	ar5
      009E07 C0 04            [24] 1401 	push	ar4
      009E09 12 95 85         [24] 1402 	lcall	_process_caps_word
      009E0C E5 82            [12] 1403 	mov	a, dpl
      009E0E D0 04            [24] 1404 	pop	ar4
      009E10 D0 05            [24] 1405 	pop	ar5
      009E12 D0 06            [24] 1406 	pop	ar6
      009E14 D0 07            [24] 1407 	pop	ar7
      009E16 60 57            [24] 1408 	jz	00101$
                                   1409 ;	quantum/quantum.c:509: process_grave_esc(keycode, record) &&
      009E18 90 0B A3         [24] 1410 	mov	dptr,#_process_grave_esc_PARM_2
      009E1B 12 9E B3         [24] 1411 	lcall	_ak820_outline_0002
      009E1E C0 07            [24] 1412 	push	ar7
      009E20 C0 06            [24] 1413 	push	ar6
      009E22 C0 05            [24] 1414 	push	ar5
      009E24 C0 04            [24] 1415 	push	ar4
      009E26 12 96 98         [24] 1416 	lcall	_process_grave_esc
      009E29 E5 82            [12] 1417 	mov	a, dpl
      009E2B D0 04            [24] 1418 	pop	ar4
      009E2D D0 05            [24] 1419 	pop	ar5
      009E2F D0 06            [24] 1420 	pop	ar6
      009E31 D0 07            [24] 1421 	pop	ar7
      009E33 60 3A            [24] 1422 	jz	00101$
                                   1423 ;	quantum/quantum.c:512: process_rgb(keycode, record) &&
      009E35 90 0B C1         [24] 1424 	mov	dptr,#_process_rgb_PARM_2
      009E38 12 9E B3         [24] 1425 	lcall	_ak820_outline_0002
      009E3B C0 07            [24] 1426 	push	ar7
      009E3D C0 06            [24] 1427 	push	ar6
      009E3F C0 05            [24] 1428 	push	ar5
      009E41 C0 04            [24] 1429 	push	ar4
      009E43 12 98 E6         [24] 1430 	lcall	_process_rgb
      009E46 E5 82            [12] 1431 	mov	a, dpl
      009E48 D0 04            [24] 1432 	pop	ar4
      009E4A D0 05            [24] 1433 	pop	ar5
      009E4C D0 06            [24] 1434 	pop	ar6
      009E4E D0 07            [24] 1435 	pop	ar7
      009E50 60 1D            [24] 1436 	jz	00101$
                                   1437 ;	quantum/quantum.c:524: process_tri_layer(keycode, record) &&
      009E52 90 0B C7         [24] 1438 	mov	dptr,#_process_tri_layer_PARM_2
      009E55 12 9E B3         [24] 1439 	lcall	_ak820_outline_0002
      009E58 C0 07            [24] 1440 	push	ar7
      009E5A C0 06            [24] 1441 	push	ar6
      009E5C C0 05            [24] 1442 	push	ar5
      009E5E C0 04            [24] 1443 	push	ar4
      009E60 12 99 97         [24] 1444 	lcall	_process_tri_layer
      009E63 E5 82            [12] 1445 	mov	a, dpl
      009E65 D0 04            [24] 1446 	pop	ar4
      009E67 D0 05            [24] 1447 	pop	ar5
      009E69 D0 06            [24] 1448 	pop	ar6
      009E6B D0 07            [24] 1449 	pop	ar7
      009E6D 70 04            [24] 1450 	jnz	00102$
                                   1451 ;	quantum/quantum.c:526: true)) {
      009E6F                       1452 00101$:
                                   1453 ;	quantum/quantum.c:527: return false;
      009E6F 75 82 00         [24] 1454 	mov	dpl, #0x00
      009E72 22               [24] 1455 	ret
      009E73                       1456 00102$:
                                   1457 ;	quantum/quantum.c:530: if (record->event.pressed) {
      009E73 74 05            [12] 1458 	mov	a,#0x05
      009E75 12 47 26         [24] 1459 	lcall	_ak820_outline_0031
      009E78 60 30            [24] 1460 	jz	00117$
                                   1461 ;	quantum/quantum.c:531: switch (keycode) {
      009E7A BC 00 05         [24] 1462 	cjne	r4,#0x00,00214$
      009E7D BD 7C 02         [24] 1463 	cjne	r5,#0x7c,00214$
      009E80 80 10            [24] 1464 	sjmp	00112$
      009E82                       1465 00214$:
      009E82 BC 01 05         [24] 1466 	cjne	r4,#0x01,00215$
      009E85 BD 7C 02         [24] 1467 	cjne	r5,#0x7c,00215$
      009E88 80 0F            [24] 1468 	sjmp	00113$
      009E8A                       1469 00215$:
                                   1470 ;	quantum/quantum.c:533: case QK_BOOTLOADER:
      009E8A BC 03 1D         [24] 1471 	cjne	r4,#0x03,00117$
      009E8D BD 7C 1A         [24] 1472 	cjne	r5,#0x7c,00117$
      009E90 80 0E            [24] 1473 	sjmp	00114$
      009E92                       1474 00112$:
                                   1475 ;	quantum/quantum.c:534: reset_keyboard();
      009E92 12 9B DA         [24] 1476 	lcall	_reset_keyboard
                                   1477 ;	quantum/quantum.c:535: return false;
      009E95 75 82 00         [24] 1478 	mov	dpl, #0x00
                                   1479 ;	quantum/quantum.c:536: case QK_REBOOT:
      009E98 22               [24] 1480 	ret
      009E99                       1481 00113$:
                                   1482 ;	quantum/quantum.c:537: soft_reset_keyboard();
      009E99 12 9B E0         [24] 1483 	lcall	_soft_reset_keyboard
                                   1484 ;	quantum/quantum.c:538: return false;
      009E9C 75 82 00         [24] 1485 	mov	dpl, #0x00
                                   1486 ;	quantum/quantum.c:550: case QK_CLEAR_EEPROM:
      009E9F 22               [24] 1487 	ret
      009EA0                       1488 00114$:
                                   1489 ;	quantum/quantum.c:557: eeconfig_disable();
      009EA0 12 8C F1         [24] 1490 	lcall	_eeconfig_disable
                                   1491 ;	quantum/quantum.c:558: soft_reset_keyboard();
      009EA3 12 9B E0         [24] 1492 	lcall	_soft_reset_keyboard
                                   1493 ;	quantum/quantum.c:560: return false;
      009EA6 75 82 00         [24] 1494 	mov	dpl, #0x00
                                   1495 ;	quantum/quantum.c:615: }
      009EA9 22               [24] 1496 	ret
      009EAA                       1497 00117$:
                                   1498 ;	quantum/quantum.c:618: return process_action_kb(record);
      009EAA 7D 00            [12] 1499 	mov	r5,#0x00
      009EAC 12 6E 1A         [24] 1500 	lcall	_ak820_outline_0063
                                   1501 ;	quantum/quantum.c:619: }
      009EAF 02 9B 80         [24] 1502 	ljmp	_process_action_kb
                                   1503 ;------------------------------------------------------------
                                   1504 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1505 ;------------------------------------------------------------
                                   1506 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_673'
                                   1507 ;------------------------------------------------------------
                                   1508 ;	quantum/quantum.c:621: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1509 ;	-----------------------------------------
                                   1510 ;	 function shutdown_user
                                   1511 ;	-----------------------------------------
      009EB2                       1512 _shutdown_user:
      009EB2 22               [24] 1513 	ret
                                   1514 ;------------------------------------------------------------
                                   1515 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1516 ;------------------------------------------------------------
                                   1517 ;	quantum/quantum.c:637: void suspend_power_down_quantum(void) {
                                   1518 ;	-----------------------------------------
                                   1519 	.area CSEG    (CODE)
                                   1520 	.area CONST   (CODE)
                                   1521 	.area XINIT   (CODE)
                                   1522 	.area CABS    (ABS,CODE)
                                   1523 
                                   1524 ; Experimental exact instruction outlining.
                                   1525 	.globl _ak820_outline_0002
                                   1526 	.globl _ak820_outline_0005
                                   1527 	.globl _ak820_outline_0007
                                   1528 	.globl _ak820_outline_0009
                                   1529 	.globl _ak820_outline_0010
                                   1530 	.globl _ak820_outline_0013
                                   1531 	.globl _ak820_outline_0016
                                   1532 	.globl _ak820_outline_0019
                                   1533 	.globl _ak820_outline_0020
                                   1534 	.globl _ak820_outline_0024
                                   1535 	.globl _ak820_outline_0031
                                   1536 	.globl _ak820_outline_0036
                                   1537 	.globl _ak820_outline_0038
                                   1538 	.globl _ak820_outline_0039
                                   1539 	.globl _ak820_outline_0051
                                   1540 	.globl _ak820_outline_0059
                                   1541 	.globl _ak820_outline_0063
                                   1542 	.globl _ak820_outline_0071
                                   1543 	.globl _ak820_outline_0103
                                   1544 	.globl _ak820_outline_0104
                                   1545 	.globl _ak820_outline_0112
                                   1546 	.globl _ak820_outline_0113
                                   1547 	.globl _ak820_outline_0118
                                   1548 	.globl _ak820_outline_0119
                                   1549 	.globl _ak820_outline_0129
                                   1550 	.globl _ak820_outline_0136
                                   1551 	.globl _ak820_outline_0143
                                   1552 	.globl _ak820_outline_0150
                                   1553 
                                   1554 	.area CSEG (CODE)
                                   1555 ; function ak820_outline_0002
      009EB3                       1556 _ak820_outline_0002:
      009EB3 EE               [12] 1557 	mov	a,r6
      009EB4 F0               [24] 1558 	movx	@dptr,a
      009EB5 EF               [12] 1559 	mov	a,r7
      009EB6 A3               [24] 1560 	inc	dptr
      009EB7 F0               [24] 1561 	movx	@dptr,a
      009EB8 E4               [12] 1562 	clr	a
      009EB9 A3               [24] 1563 	inc	dptr
      009EBA F0               [24] 1564 	movx	@dptr,a
      009EBB 8C 82            [24] 1565 	mov	dpl,r4
      009EBD 8D 83            [24] 1566 	mov	dph,r5
      009EBF 22               [24] 1567 	ret
                                   1568 
                                   1569 	.area CSEG (CODE)
                                   1570 ; function ak820_outline_0010
      009EC0                       1571 _ak820_outline_0010:
      009EC0 EB               [12] 1572 	mov	a,r3
      009EC1 F0               [24] 1573 	movx	@dptr,a
      009EC2 EC               [12] 1574 	mov	a,r4
      009EC3 A3               [24] 1575 	inc	dptr
      009EC4 F0               [24] 1576 	movx	@dptr,a
      009EC5 ED               [12] 1577 	mov	a,r5
      009EC6 A3               [24] 1578 	inc	dptr
      009EC7 F0               [24] 1579 	movx	@dptr,a
      009EC8 8E 82            [24] 1580 	mov	dpl,r6
      009ECA 8F 83            [24] 1581 	mov	dph,r7
      009ECC 22               [24] 1582 	ret
