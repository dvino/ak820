                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_flash
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ADC_START
                                     12 	.globl _S0_R_FIFO
                                     13 	.globl _S0_T_FIFO
                                     14 	.globl _S0_FREE
                                     15 	.globl _S0_IF_BYTE
                                     16 	.globl _S0_IF_FIRST
                                     17 	.globl _S0_IF_OV
                                     18 	.globl _S0_FST_ACT
                                     19 	.globl _CP_RL2
                                     20 	.globl _C_T2
                                     21 	.globl _TR2
                                     22 	.globl _EXEN2
                                     23 	.globl _TCLK
                                     24 	.globl _RCLK
                                     25 	.globl _EXF2
                                     26 	.globl _CAP1F
                                     27 	.globl _TF2
                                     28 	.globl _RI
                                     29 	.globl _TI
                                     30 	.globl _RB8
                                     31 	.globl _TB8
                                     32 	.globl _REN
                                     33 	.globl _SM2
                                     34 	.globl _SM1
                                     35 	.globl _SM0
                                     36 	.globl _IT0
                                     37 	.globl _IE0
                                     38 	.globl _IT1
                                     39 	.globl _IE1
                                     40 	.globl _TR0
                                     41 	.globl _TF0
                                     42 	.globl _TR1
                                     43 	.globl _TF1
                                     44 	.globl _P4_0
                                     45 	.globl _P4_1
                                     46 	.globl _P4_2
                                     47 	.globl _P4_3
                                     48 	.globl _P4_4
                                     49 	.globl _P4_5
                                     50 	.globl _P4_6
                                     51 	.globl _RXD
                                     52 	.globl _TXD
                                     53 	.globl _INT0
                                     54 	.globl _INT1
                                     55 	.globl _T0
                                     56 	.globl _T1
                                     57 	.globl _MOSI1
                                     58 	.globl _MISO1
                                     59 	.globl _SCK1
                                     60 	.globl _P3_0
                                     61 	.globl _P3_1
                                     62 	.globl _P3_2
                                     63 	.globl _P3_3
                                     64 	.globl _P3_4
                                     65 	.globl _P3_5
                                     66 	.globl _P3_6
                                     67 	.globl _P3_7
                                     68 	.globl _CAP1_
                                     69 	.globl _T2_
                                     70 	.globl _CAP2_
                                     71 	.globl _T2EX_
                                     72 	.globl _RXD1
                                     73 	.globl _TXD1
                                     74 	.globl _P2_0
                                     75 	.globl _P2_1
                                     76 	.globl _P2_2
                                     77 	.globl _P2_3
                                     78 	.globl _P2_4
                                     79 	.globl _P2_5
                                     80 	.globl _P2_6
                                     81 	.globl _P2_7
                                     82 	.globl _AIN0
                                     83 	.globl _AIN1
                                     84 	.globl _AIN2
                                     85 	.globl _AIN3
                                     86 	.globl _AIN4
                                     87 	.globl _AIN5
                                     88 	.globl _AIN6
                                     89 	.globl _AIN7
                                     90 	.globl _CAP1
                                     91 	.globl _T2
                                     92 	.globl _CAP2
                                     93 	.globl _T2EX
                                     94 	.globl _INT0_
                                     95 	.globl _SCS
                                     96 	.globl _MOSI
                                     97 	.globl _MISO
                                     98 	.globl _SCK
                                     99 	.globl _RXD1_
                                    100 	.globl _TXD1_
                                    101 	.globl _P1_0
                                    102 	.globl _P1_1
                                    103 	.globl _P1_2
                                    104 	.globl _P1_3
                                    105 	.globl _P1_4
                                    106 	.globl _P1_5
                                    107 	.globl _P1_6
                                    108 	.globl _P1_7
                                    109 	.globl _AIN8
                                    110 	.globl _AIN9
                                    111 	.globl _AIN10
                                    112 	.globl _AIN11
                                    113 	.globl _AIN12
                                    114 	.globl _AIN13
                                    115 	.globl _RXD_
                                    116 	.globl _TXD_
                                    117 	.globl _SCL0
                                    118 	.globl _SDA0
                                    119 	.globl _P0_0
                                    120 	.globl _P0_1
                                    121 	.globl _P0_2
                                    122 	.globl _P0_3
                                    123 	.globl _P0_4
                                    124 	.globl _P0_5
                                    125 	.globl _P0_6
                                    126 	.globl _P0_7
                                    127 	.globl _IE_SPI0
                                    128 	.globl _IE_USB
                                    129 	.globl _IE_ADC
                                    130 	.globl _IE_UART1
                                    131 	.globl _IE_PWM_I2C
                                    132 	.globl _IE_GPIO
                                    133 	.globl _IE_WDOG
                                    134 	.globl _PX0
                                    135 	.globl _PT0
                                    136 	.globl _PX1
                                    137 	.globl _PT1
                                    138 	.globl _PS
                                    139 	.globl _PT2
                                    140 	.globl _PL_FLAG
                                    141 	.globl _PH_FLAG
                                    142 	.globl _EX0
                                    143 	.globl _ET0
                                    144 	.globl _EX1
                                    145 	.globl _ET1
                                    146 	.globl _ES
                                    147 	.globl _ET2
                                    148 	.globl _E_DIS
                                    149 	.globl _EA
                                    150 	.globl _P
                                    151 	.globl _F1
                                    152 	.globl _OV
                                    153 	.globl _RS0
                                    154 	.globl _RS1
                                    155 	.globl _F0
                                    156 	.globl _AC
                                    157 	.globl _CY
                                    158 	.globl _I2CS_INT_ST
                                    159 	.globl _I2CX_INT
                                    160 	.globl _LED_STATUS
                                    161 	.globl _LED_DMA_H
                                    162 	.globl _LED_DMA_L
                                    163 	.globl _LED_DMA
                                    164 	.globl _LED_PWM_OE
                                    165 	.globl _LED_COMMON
                                    166 	.globl _ADC_CHAN
                                    167 	.globl _ADC_DAT_H
                                    168 	.globl _ADC_DAT_L
                                    169 	.globl _ADC_DAT
                                    170 	.globl _ADC_CTRL
                                    171 	.globl _SPI1_CK_SE
                                    172 	.globl _SPI1_CTRL
                                    173 	.globl _SPI1_DATA
                                    174 	.globl _SPI1_STAT
                                    175 	.globl _SIF1
                                    176 	.globl _SBAUD1
                                    177 	.globl _SBUF1
                                    178 	.globl _SCON1
                                    179 	.globl _SPI0_SETUP
                                    180 	.globl _SPI0_CK_SE
                                    181 	.globl _SPI0_CTRL
                                    182 	.globl _SPI0_DATA
                                    183 	.globl _SPI0_STAT
                                    184 	.globl _T2CAP1H
                                    185 	.globl _T2CAP1L
                                    186 	.globl _T2CAP1
                                    187 	.globl _TH2
                                    188 	.globl _TL2
                                    189 	.globl _T2COUNT
                                    190 	.globl _RCAP2H
                                    191 	.globl _RCAP2L
                                    192 	.globl _RCAP2
                                    193 	.globl _T2MOD
                                    194 	.globl _T2CON
                                    195 	.globl _SBUF
                                    196 	.globl _SCON
                                    197 	.globl _TH1
                                    198 	.globl _TH0
                                    199 	.globl _TL1
                                    200 	.globl _TL0
                                    201 	.globl _TMOD
                                    202 	.globl _TCON
                                    203 	.globl _XBUS_AUX
                                    204 	.globl _P7
                                    205 	.globl _P6_DIR
                                    206 	.globl _P6_OUT_PU
                                    207 	.globl _P6_IN
                                    208 	.globl _P5_DIR
                                    209 	.globl _P5_OUT_PU
                                    210 	.globl _P5_IN
                                    211 	.globl _P4_LED_KEY
                                    212 	.globl _P4_DIR_PU
                                    213 	.globl _P4_MOD_OC
                                    214 	.globl _P4
                                    215 	.globl _P3_DIR_PU
                                    216 	.globl _P3_MOD_OC
                                    217 	.globl _P3
                                    218 	.globl _P2_DIR_PU
                                    219 	.globl _P2_MOD_OC
                                    220 	.globl _P2
                                    221 	.globl _P1_DIR_PU
                                    222 	.globl _P1_MOD_OC
                                    223 	.globl _P1
                                    224 	.globl _P0_DIR_PU
                                    225 	.globl _P0_MOD_OC
                                    226 	.globl _P0
                                    227 	.globl _ROM_CTRL
                                    228 	.globl _ROM_DATA_HH
                                    229 	.globl _ROM_DATA_HL
                                    230 	.globl _ROM_DATA_HI
                                    231 	.globl _ROM_ADDR_H
                                    232 	.globl _ROM_ADDR_L
                                    233 	.globl _ROM_ADDR
                                    234 	.globl _GPIO_IE
                                    235 	.globl _IP_EX
                                    236 	.globl _IE_EX
                                    237 	.globl _IP
                                    238 	.globl _IE
                                    239 	.globl _WDOG_COUNT
                                    240 	.globl _RESET_KEEP
                                    241 	.globl _WAKE_CTRL
                                    242 	.globl _CLOCK_CFG
                                    243 	.globl _POWER_CFG
                                    244 	.globl _PCON
                                    245 	.globl _GLOBAL_CFG
                                    246 	.globl _SAFE_MOD
                                    247 	.globl _DPH
                                    248 	.globl _DPL
                                    249 	.globl _SP
                                    250 	.globl _A_INV
                                    251 	.globl _B
                                    252 	.globl _ACC
                                    253 	.globl _PSW
                                    254 	.globl _ak820_flash_program_page_PARM_2
                                    255 	.globl _ak820_flash_program_PARM_2
                                    256 	.globl _ak820_flash_diagnostic
                                    257 	.globl _ak820_flash_read
                                    258 	.globl _ak820_flash_erase
                                    259 	.globl _ak820_flash_program
                                    260 	.globl _ak820_flash_program_page
                                    261 ;--------------------------------------------------------
                                    262 ; special function registers
                                    263 ;--------------------------------------------------------
                                    264 	.area RSEG    (ABS,DATA)
      000000                        265 	.org 0x0000
                           0000D0   266 _PSW	=	0x00d0
                           0000E0   267 _ACC	=	0x00e0
                           0000F0   268 _B	=	0x00f0
                           0000FD   269 _A_INV	=	0x00fd
                           000081   270 _SP	=	0x0081
                           000082   271 _DPL	=	0x0082
                           000083   272 _DPH	=	0x0083
                           0000A1   273 _SAFE_MOD	=	0x00a1
                           0000B1   274 _GLOBAL_CFG	=	0x00b1
                           000087   275 _PCON	=	0x0087
                           0000BA   276 _POWER_CFG	=	0x00ba
                           0000B9   277 _CLOCK_CFG	=	0x00b9
                           0000A9   278 _WAKE_CTRL	=	0x00a9
                           0000FE   279 _RESET_KEEP	=	0x00fe
                           0000FF   280 _WDOG_COUNT	=	0x00ff
                           0000A8   281 _IE	=	0x00a8
                           0000B8   282 _IP	=	0x00b8
                           0000E8   283 _IE_EX	=	0x00e8
                           0000E9   284 _IP_EX	=	0x00e9
                           0000B2   285 _GPIO_IE	=	0x00b2
                           008584   286 _ROM_ADDR	=	0x8584
                           000084   287 _ROM_ADDR_L	=	0x0084
                           000085   288 _ROM_ADDR_H	=	0x0085
                           008F8E   289 _ROM_DATA_HI	=	0x8f8e
                           00008E   290 _ROM_DATA_HL	=	0x008e
                           00008F   291 _ROM_DATA_HH	=	0x008f
                           000086   292 _ROM_CTRL	=	0x0086
                           000080   293 _P0	=	0x0080
                           0000C4   294 _P0_MOD_OC	=	0x00c4
                           0000C5   295 _P0_DIR_PU	=	0x00c5
                           000090   296 _P1	=	0x0090
                           000092   297 _P1_MOD_OC	=	0x0092
                           000093   298 _P1_DIR_PU	=	0x0093
                           0000A0   299 _P2	=	0x00a0
                           000094   300 _P2_MOD_OC	=	0x0094
                           000095   301 _P2_DIR_PU	=	0x0095
                           0000B0   302 _P3	=	0x00b0
                           000096   303 _P3_MOD_OC	=	0x0096
                           000097   304 _P3_DIR_PU	=	0x0097
                           0000C0   305 _P4	=	0x00c0
                           0000C2   306 _P4_MOD_OC	=	0x00c2
                           0000C3   307 _P4_DIR_PU	=	0x00c3
                           0000C1   308 _P4_LED_KEY	=	0x00c1
                           0000AA   309 _P5_IN	=	0x00aa
                           0000AB   310 _P5_OUT_PU	=	0x00ab
                           0000AC   311 _P5_DIR	=	0x00ac
                           0000AD   312 _P6_IN	=	0x00ad
                           0000AE   313 _P6_OUT_PU	=	0x00ae
                           0000AF   314 _P6_DIR	=	0x00af
                           0000F1   315 _P7	=	0x00f1
                           0000A2   316 _XBUS_AUX	=	0x00a2
                           000088   317 _TCON	=	0x0088
                           000089   318 _TMOD	=	0x0089
                           00008A   319 _TL0	=	0x008a
                           00008B   320 _TL1	=	0x008b
                           00008C   321 _TH0	=	0x008c
                           00008D   322 _TH1	=	0x008d
                           000098   323 _SCON	=	0x0098
                           000099   324 _SBUF	=	0x0099
                           0000C8   325 _T2CON	=	0x00c8
                           0000C9   326 _T2MOD	=	0x00c9
                           00CBCA   327 _RCAP2	=	0xcbca
                           0000CA   328 _RCAP2L	=	0x00ca
                           0000CB   329 _RCAP2H	=	0x00cb
                           00CDCC   330 _T2COUNT	=	0xcdcc
                           0000CC   331 _TL2	=	0x00cc
                           0000CD   332 _TH2	=	0x00cd
                           00CFCE   333 _T2CAP1	=	0xcfce
                           0000CE   334 _T2CAP1L	=	0x00ce
                           0000CF   335 _T2CAP1H	=	0x00cf
                           0000F8   336 _SPI0_STAT	=	0x00f8
                           0000F9   337 _SPI0_DATA	=	0x00f9
                           0000FA   338 _SPI0_CTRL	=	0x00fa
                           0000FB   339 _SPI0_CK_SE	=	0x00fb
                           0000FC   340 _SPI0_SETUP	=	0x00fc
                           0000BC   341 _SCON1	=	0x00bc
                           0000BD   342 _SBUF1	=	0x00bd
                           0000BE   343 _SBAUD1	=	0x00be
                           0000BF   344 _SIF1	=	0x00bf
                           0000B4   345 _SPI1_STAT	=	0x00b4
                           0000B5   346 _SPI1_DATA	=	0x00b5
                           0000B6   347 _SPI1_CTRL	=	0x00b6
                           0000B7   348 _SPI1_CK_SE	=	0x00b7
                           0000F3   349 _ADC_CTRL	=	0x00f3
                           00F5F4   350 _ADC_DAT	=	0xf5f4
                           0000F4   351 _ADC_DAT_L	=	0x00f4
                           0000F5   352 _ADC_DAT_H	=	0x00f5
                           0000F6   353 _ADC_CHAN	=	0x00f6
                           0000A6   354 _LED_COMMON	=	0x00a6
                           0000A7   355 _LED_PWM_OE	=	0x00a7
                           00C7C6   356 _LED_DMA	=	0xc7c6
                           0000C6   357 _LED_DMA_L	=	0x00c6
                           0000C7   358 _LED_DMA_H	=	0x00c7
                           0000F7   359 _LED_STATUS	=	0x00f7
                           0000B3   360 _I2CX_INT	=	0x00b3
                           0000BB   361 _I2CS_INT_ST	=	0x00bb
                                    362 ;--------------------------------------------------------
                                    363 ; special function bits
                                    364 ;--------------------------------------------------------
                                    365 	.area RSEG    (ABS,DATA)
      000000                        366 	.org 0x0000
                           0000D7   367 _CY	=	0x00d7
                           0000D6   368 _AC	=	0x00d6
                           0000D5   369 _F0	=	0x00d5
                           0000D4   370 _RS1	=	0x00d4
                           0000D3   371 _RS0	=	0x00d3
                           0000D2   372 _OV	=	0x00d2
                           0000D1   373 _F1	=	0x00d1
                           0000D0   374 _P	=	0x00d0
                           0000AF   375 _EA	=	0x00af
                           0000AE   376 _E_DIS	=	0x00ae
                           0000AD   377 _ET2	=	0x00ad
                           0000AC   378 _ES	=	0x00ac
                           0000AB   379 _ET1	=	0x00ab
                           0000AA   380 _EX1	=	0x00aa
                           0000A9   381 _ET0	=	0x00a9
                           0000A8   382 _EX0	=	0x00a8
                           0000BF   383 _PH_FLAG	=	0x00bf
                           0000BE   384 _PL_FLAG	=	0x00be
                           0000BD   385 _PT2	=	0x00bd
                           0000BC   386 _PS	=	0x00bc
                           0000BB   387 _PT1	=	0x00bb
                           0000BA   388 _PX1	=	0x00ba
                           0000B9   389 _PT0	=	0x00b9
                           0000B8   390 _PX0	=	0x00b8
                           0000EF   391 _IE_WDOG	=	0x00ef
                           0000EE   392 _IE_GPIO	=	0x00ee
                           0000ED   393 _IE_PWM_I2C	=	0x00ed
                           0000EC   394 _IE_UART1	=	0x00ec
                           0000EB   395 _IE_ADC	=	0x00eb
                           0000E9   396 _IE_USB	=	0x00e9
                           0000E8   397 _IE_SPI0	=	0x00e8
                           000087   398 _P0_7	=	0x0087
                           000086   399 _P0_6	=	0x0086
                           000085   400 _P0_5	=	0x0085
                           000084   401 _P0_4	=	0x0084
                           000083   402 _P0_3	=	0x0083
                           000082   403 _P0_2	=	0x0082
                           000081   404 _P0_1	=	0x0081
                           000080   405 _P0_0	=	0x0080
                           000081   406 _SDA0	=	0x0081
                           000080   407 _SCL0	=	0x0080
                           000083   408 _TXD_	=	0x0083
                           000082   409 _RXD_	=	0x0082
                           000085   410 _AIN13	=	0x0085
                           000084   411 _AIN12	=	0x0084
                           000083   412 _AIN11	=	0x0083
                           000082   413 _AIN10	=	0x0082
                           000081   414 _AIN9	=	0x0081
                           000080   415 _AIN8	=	0x0080
                           000097   416 _P1_7	=	0x0097
                           000096   417 _P1_6	=	0x0096
                           000095   418 _P1_5	=	0x0095
                           000094   419 _P1_4	=	0x0094
                           000093   420 _P1_3	=	0x0093
                           000092   421 _P1_2	=	0x0092
                           000091   422 _P1_1	=	0x0091
                           000090   423 _P1_0	=	0x0090
                           000097   424 _TXD1_	=	0x0097
                           000096   425 _RXD1_	=	0x0096
                           000097   426 _SCK	=	0x0097
                           000096   427 _MISO	=	0x0096
                           000095   428 _MOSI	=	0x0095
                           000094   429 _SCS	=	0x0094
                           000092   430 _INT0_	=	0x0092
                           000091   431 _T2EX	=	0x0091
                           000091   432 _CAP2	=	0x0091
                           000090   433 _T2	=	0x0090
                           000090   434 _CAP1	=	0x0090
                           000097   435 _AIN7	=	0x0097
                           000096   436 _AIN6	=	0x0096
                           000095   437 _AIN5	=	0x0095
                           000094   438 _AIN4	=	0x0094
                           000093   439 _AIN3	=	0x0093
                           000092   440 _AIN2	=	0x0092
                           000091   441 _AIN1	=	0x0091
                           000090   442 _AIN0	=	0x0090
                           0000A7   443 _P2_7	=	0x00a7
                           0000A6   444 _P2_6	=	0x00a6
                           0000A5   445 _P2_5	=	0x00a5
                           0000A4   446 _P2_4	=	0x00a4
                           0000A3   447 _P2_3	=	0x00a3
                           0000A2   448 _P2_2	=	0x00a2
                           0000A1   449 _P2_1	=	0x00a1
                           0000A0   450 _P2_0	=	0x00a0
                           0000A7   451 _TXD1	=	0x00a7
                           0000A6   452 _RXD1	=	0x00a6
                           0000A5   453 _T2EX_	=	0x00a5
                           0000A5   454 _CAP2_	=	0x00a5
                           0000A4   455 _T2_	=	0x00a4
                           0000A4   456 _CAP1_	=	0x00a4
                           0000B7   457 _P3_7	=	0x00b7
                           0000B6   458 _P3_6	=	0x00b6
                           0000B5   459 _P3_5	=	0x00b5
                           0000B4   460 _P3_4	=	0x00b4
                           0000B3   461 _P3_3	=	0x00b3
                           0000B2   462 _P3_2	=	0x00b2
                           0000B1   463 _P3_1	=	0x00b1
                           0000B0   464 _P3_0	=	0x00b0
                           0000B7   465 _SCK1	=	0x00b7
                           0000B6   466 _MISO1	=	0x00b6
                           0000B5   467 _MOSI1	=	0x00b5
                           0000B5   468 _T1	=	0x00b5
                           0000B4   469 _T0	=	0x00b4
                           0000B3   470 _INT1	=	0x00b3
                           0000B2   471 _INT0	=	0x00b2
                           0000B1   472 _TXD	=	0x00b1
                           0000B0   473 _RXD	=	0x00b0
                           0000C6   474 _P4_6	=	0x00c6
                           0000C5   475 _P4_5	=	0x00c5
                           0000C4   476 _P4_4	=	0x00c4
                           0000C3   477 _P4_3	=	0x00c3
                           0000C2   478 _P4_2	=	0x00c2
                           0000C1   479 _P4_1	=	0x00c1
                           0000C0   480 _P4_0	=	0x00c0
                           00008F   481 _TF1	=	0x008f
                           00008E   482 _TR1	=	0x008e
                           00008D   483 _TF0	=	0x008d
                           00008C   484 _TR0	=	0x008c
                           00008B   485 _IE1	=	0x008b
                           00008A   486 _IT1	=	0x008a
                           000089   487 _IE0	=	0x0089
                           000088   488 _IT0	=	0x0088
                           00009F   489 _SM0	=	0x009f
                           00009E   490 _SM1	=	0x009e
                           00009D   491 _SM2	=	0x009d
                           00009C   492 _REN	=	0x009c
                           00009B   493 _TB8	=	0x009b
                           00009A   494 _RB8	=	0x009a
                           000099   495 _TI	=	0x0099
                           000098   496 _RI	=	0x0098
                           0000CF   497 _TF2	=	0x00cf
                           0000CF   498 _CAP1F	=	0x00cf
                           0000CE   499 _EXF2	=	0x00ce
                           0000CD   500 _RCLK	=	0x00cd
                           0000CC   501 _TCLK	=	0x00cc
                           0000CB   502 _EXEN2	=	0x00cb
                           0000CA   503 _TR2	=	0x00ca
                           0000C9   504 _C_T2	=	0x00c9
                           0000C8   505 _CP_RL2	=	0x00c8
                           0000FF   506 _S0_FST_ACT	=	0x00ff
                           0000FE   507 _S0_IF_OV	=	0x00fe
                           0000FD   508 _S0_IF_FIRST	=	0x00fd
                           0000FC   509 _S0_IF_BYTE	=	0x00fc
                           0000FB   510 _S0_FREE	=	0x00fb
                           0000FA   511 _S0_T_FIFO	=	0x00fa
                           0000F8   512 _S0_R_FIFO	=	0x00f8
                           0000F7   513 _ADC_START	=	0x00f7
                                    514 ;--------------------------------------------------------
                                    515 ; overlayable register banks
                                    516 ;--------------------------------------------------------
                                    517 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        518 	.ds 8
                                    519 ;--------------------------------------------------------
                                    520 ; internal ram data
                                    521 ;--------------------------------------------------------
                                    522 	.area DSEG    (DATA)
      000008                        523 _ak820_flash_program_sloc0_1_0:
      000008                        524 	.ds 2
                                    525 ;--------------------------------------------------------
                                    526 ; overlayable items in internal ram
                                    527 ;--------------------------------------------------------
                                    528 ;--------------------------------------------------------
                                    529 ; indirectly addressable internal ram data
                                    530 ;--------------------------------------------------------
                                    531 	.area ISEG    (DATA)
                                    532 ;--------------------------------------------------------
                                    533 ; absolute internal ram data
                                    534 ;--------------------------------------------------------
                                    535 	.area IABS    (ABS,DATA)
                                    536 	.area IABS    (ABS,DATA)
                                    537 ;--------------------------------------------------------
                                    538 ; bit data
                                    539 ;--------------------------------------------------------
                                    540 	.area BSEG    (BIT)
      000004                        541 _flash_operation_sloc0_1_0:
      000004                        542 	.ds 1
                                    543 ;--------------------------------------------------------
                                    544 ; paged external ram data
                                    545 ;--------------------------------------------------------
                                    546 	.area PSEG    (PAG,XDATA)
                                    547 ;--------------------------------------------------------
                                    548 ; uninitialized external ram data
                                    549 ;--------------------------------------------------------
                                    550 	.area XSEG    (XDATA)
      000464                        551 _ak820_flash_diagnostic::
      000464                        552 	.ds 6
      00046A                        553 _block_storage:
      00046A                        554 	.ds 127
      0004E9                        555 _block_data:
      0004E9                        556 	.ds 2
      0004EB                        557 _ak820_flash_read_address_10000_19:
      0004EB                        558 	.ds 2
      0004ED                        559 _flash_operation_PARM_2:
      0004ED                        560 	.ds 1
      0004EE                        561 _flash_operation_PARM_3:
      0004EE                        562 	.ds 1
      0004EF                        563 _flash_operation_address_10000_21:
      0004EF                        564 	.ds 2
      0004F1                        565 _flash_operation_previous_ie_10000_22:
      0004F1                        566 	.ds 1
      0004F2                        567 _flash_operation_before_10000_22:
      0004F2                        568 	.ds 1
      0004F3                        569 _flash_operation_status_10000_22:
      0004F3                        570 	.ds 1
      0004F4                        571 _ak820_flash_erase_address_10000_27:
      0004F4                        572 	.ds 2
      0004F6                        573 _ak820_flash_program_PARM_2:
      0004F6                        574 	.ds 1
      0004F7                        575 _ak820_flash_program_address_10000_34:
      0004F7                        576 	.ds 2
      0004F9                        577 _ak820_flash_program_page_PARM_2:
      0004F9                        578 	.ds 2
      0004FB                        579 _ak820_flash_program_page_address_10000_38:
      0004FB                        580 	.ds 2
                                    581 ;--------------------------------------------------------
                                    582 ; absolute external ram data
                                    583 ;--------------------------------------------------------
                                    584 	.area XABS    (ABS,XDATA)
                                    585 ;--------------------------------------------------------
                                    586 ; initialized external ram data
                                    587 ;--------------------------------------------------------
                                    588 	.area XISEG   (XDATA)
                                    589 	.area HOME    (CODE)
                                    590 	.area GSINIT0 (CODE)
                                    591 	.area GSINIT1 (CODE)
                                    592 	.area GSINIT2 (CODE)
                                    593 	.area GSINIT3 (CODE)
                                    594 	.area GSINIT4 (CODE)
                                    595 	.area GSINIT5 (CODE)
                                    596 	.area GSINIT  (CODE)
                                    597 	.area GSFINAL (CODE)
                                    598 	.area CSEG    (CODE)
                                    599 ;--------------------------------------------------------
                                    600 ; global & static initialisations
                                    601 ;--------------------------------------------------------
                                    602 	.area HOME    (CODE)
                                    603 	.area GSINIT  (CODE)
                                    604 	.area GSFINAL (CODE)
                                    605 	.area GSINIT  (CODE)
                                    606 ;--------------------------------------------------------
                                    607 ; Home
                                    608 ;--------------------------------------------------------
                                    609 	.area HOME    (CODE)
                                    610 	.area HOME    (CODE)
                                    611 ;--------------------------------------------------------
                                    612 ; code
                                    613 ;--------------------------------------------------------
                                    614 	.area CSEG    (CODE)
                                    615 ;------------------------------------------------------------
                                    616 ;Allocation info for local variables in function 'program_block'
                                    617 ;------------------------------------------------------------
                                    618 ;data          Allocated with name '_program_block_data_10000_15'
                                    619 ;------------------------------------------------------------
                                    620 ;	keyboards/ajazz/ak820/ak820_flash.c:19: static uint16_t program_block(const uint8_t __xdata *data) __naked {
                                    621 ;	-----------------------------------------
                                    622 ;	 function program_block
                                    623 ;	-----------------------------------------
      0038C6                        624 _program_block:
                                    625 ;	naked function: no prologue.
                                    626 ;	keyboards/ajazz/ak820/ak820_flash.c:31: __endasm;
      0038C6 E5 86            [12]  627 	mov a, _ROM_CTRL
      0038C8 F5 F0            [12]  628 	mov b, a
      0038CA 30 E6 05         [24]  629 	jnb acc.6, 00001$
      0038CD 75 86 9A         [24]  630 	mov _ROM_CTRL, #0x9a
      0038D0 E5 86            [12]  631 	mov a, _ROM_CTRL
      0038D2                        632 00001$:
      0038D2 F5 82            [12]  633 	mov dpl, a
      0038D4 85 F0 83         [24]  634 	mov dph, b
      0038D7 22               [24]  635 	ret
                                    636 ;	keyboards/ajazz/ak820/ak820_flash.c:32: }
                                    637 ;	naked function: no epilogue.
                                    638 ;------------------------------------------------------------
                                    639 ;Allocation info for local variables in function 'erase_page'
                                    640 ;------------------------------------------------------------
                                    641 ;	keyboards/ajazz/ak820/ak820_flash.c:39: static uint16_t erase_page(void) __naked {
                                    642 ;	-----------------------------------------
                                    643 ;	 function erase_page
                                    644 ;	-----------------------------------------
      0038D8                        645 _erase_page:
                                    646 ;	naked function: no prologue.
                                    647 ;	keyboards/ajazz/ak820/ak820_flash.c:50: __endasm;
      0038D8 E5 86            [12]  648 	mov a, _ROM_CTRL
      0038DA F5 F0            [12]  649 	mov b, a
      0038DC 30 E6 05         [24]  650 	jnb acc.6, 00002$
      0038DF 75 86 A6         [24]  651 	mov _ROM_CTRL, #0xa6
      0038E2 E5 86            [12]  652 	mov a, _ROM_CTRL
      0038E4                        653 00002$:
      0038E4 F5 82            [12]  654 	mov dpl, a
      0038E6 85 F0 83         [24]  655 	mov dph, b
      0038E9 22               [24]  656 	ret
                                    657 ;	keyboards/ajazz/ak820/ak820_flash.c:51: }
                                    658 ;	naked function: no epilogue.
                                    659 ;------------------------------------------------------------
                                    660 ;Allocation info for local variables in function 'ak820_flash_read'
                                    661 ;------------------------------------------------------------
                                    662 ;address       Allocated with name '_ak820_flash_read_address_10000_19'
                                    663 ;------------------------------------------------------------
                                    664 ;	keyboards/ajazz/ak820/ak820_flash.c:53: uint8_t ak820_flash_read(uint16_t address) {
                                    665 ;	-----------------------------------------
                                    666 ;	 function ak820_flash_read
                                    667 ;	-----------------------------------------
      0038EA                        668 _ak820_flash_read:
                           000007   669 	ar7 = 0x07
                           000006   670 	ar6 = 0x06
                           000005   671 	ar5 = 0x05
                           000004   672 	ar4 = 0x04
                           000003   673 	ar3 = 0x03
                           000002   674 	ar2 = 0x02
                           000001   675 	ar1 = 0x01
                           000000   676 	ar0 = 0x00
      0038EA C0 07            [24]  677 	push	ar7
      0038EC C0 06            [24]  678 	push	ar6
      0038EE AF 83            [24]  679 	mov	r7,dph
      0038F0 E5 82            [12]  680 	mov	a,dpl
      0038F2 90 04 EB         [24]  681 	mov	dptr,#_ak820_flash_read_address_10000_19
      0038F5 F0               [24]  682 	movx	@dptr,a
      0038F6 EF               [12]  683 	mov	a,r7
      0038F7 A3               [24]  684 	inc	dptr
      0038F8 F0               [24]  685 	movx	@dptr,a
                                    686 ;	keyboards/ajazz/ak820/ak820_flash.c:54: return *((const __code uint8_t *)address);
      0038F9 90 04 EB         [24]  687 	mov	dptr,#_ak820_flash_read_address_10000_19
      0038FC E0               [24]  688 	movx	a,@dptr
      0038FD FE               [12]  689 	mov	r6,a
      0038FE A3               [24]  690 	inc	dptr
      0038FF E0               [24]  691 	movx	a,@dptr
      003900 FF               [12]  692 	mov	r7,a
      003901 8E 82            [24]  693 	mov	dpl,r6
      003903 8F 83            [24]  694 	mov	dph,r7
      003905 E4               [12]  695 	clr	a
      003906 93               [24]  696 	movc	a,@a+dptr
      003907 F5 82            [12]  697 	mov	dpl,a
                                    698 ;	keyboards/ajazz/ak820/ak820_flash.c:55: }
      003909 D0 06            [24]  699 	pop	ar6
      00390B D0 07            [24]  700 	pop	ar7
      00390D 22               [24]  701 	ret
                                    702 ;------------------------------------------------------------
                                    703 ;Allocation info for local variables in function 'flash_operation'
                                    704 ;------------------------------------------------------------
                                    705 ;value         Allocated with name '_flash_operation_PARM_2'
                                    706 ;operation     Allocated with name '_flash_operation_PARM_3'
                                    707 ;address       Allocated with name '_flash_operation_address_10000_21'
                                    708 ;previous_ie   Allocated with name '_flash_operation_previous_ie_10000_22'
                                    709 ;before        Allocated with name '_flash_operation_before_10000_22'
                                    710 ;status        Allocated with name '_flash_operation_status_10000_22'
                                    711 ;states        Allocated with name '_flash_operation_states_30000_25'
                                    712 ;states        Allocated with name '_flash_operation_states_30000_26'
                                    713 ;------------------------------------------------------------
                                    714 ;	keyboards/ajazz/ak820/ak820_flash.c:57: static bool flash_operation(uint16_t address, uint8_t value, uint8_t operation) {
                                    715 ;	-----------------------------------------
                                    716 ;	 function flash_operation
                                    717 ;	-----------------------------------------
      00390E                        718 _flash_operation:
      00390E AF 83            [24]  719 	mov	r7,dph
      003910 E5 82            [12]  720 	mov	a,dpl
      003912 90 04 EF         [24]  721 	mov	dptr,#_flash_operation_address_10000_21
      003915 F0               [24]  722 	movx	@dptr,a
      003916 EF               [12]  723 	mov	a,r7
      003917 A3               [24]  724 	inc	dptr
      003918 F0               [24]  725 	movx	@dptr,a
                                    726 ;	keyboards/ajazz/ak820/ak820_flash.c:59: if (address < AK820_NVM_BASE || address >= AK820_NVM_WRITE_END) return false;
      003919 90 04 EF         [24]  727 	mov	dptr,#_flash_operation_address_10000_21
      00391C E0               [24]  728 	movx	a,@dptr
      00391D FE               [12]  729 	mov	r6,a
      00391E A3               [24]  730 	inc	dptr
      00391F E0               [24]  731 	movx	a,@dptr
      003920 FF               [12]  732 	mov	r7,a
      003921 C3               [12]  733 	clr	c
      003922 94 C7            [12]  734 	subb	a,#0xc7
      003924 40 08            [24]  735 	jc	00101$
      003926 EE               [12]  736 	mov	a,r6
      003927 94 80            [12]  737 	subb	a,#0x80
      003929 EF               [12]  738 	mov	a,r7
      00392A 94 EF            [12]  739 	subb	a,#0xef
      00392C 40 04            [24]  740 	jc	00102$
      00392E                        741 00101$:
      00392E 75 82 00         [24]  742 	mov	dpl, #0x00
      003931 22               [24]  743 	ret
      003932                        744 00102$:
                                    745 ;	keyboards/ajazz/ak820/ak820_flash.c:60: ak820_flash_diagnostic[0] = 1;
      003932 90 04 64         [24]  746 	mov	dptr,#_ak820_flash_diagnostic
      003935 74 01            [12]  747 	mov	a,#0x01
      003937 F0               [24]  748 	movx	@dptr,a
                                    749 ;	keyboards/ajazz/ak820/ak820_flash.c:61: ak820_flash_diagnostic[1] = operation ? operation : 0x9A;
      003938 90 04 EE         [24]  750 	mov	dptr,#_flash_operation_PARM_3
      00393B E0               [24]  751 	movx	a,@dptr
      00393C FF               [12]  752 	mov	r7,a
      00393D 60 04            [24]  753 	jz	00109$
      00393F 8F 06            [24]  754 	mov	ar6,r7
      003941 80 02            [24]  755 	sjmp	00110$
      003943                        756 00109$:
      003943 7E 9A            [12]  757 	mov	r6,#0x9a
      003945                        758 00110$:
      003945 90 04 65         [24]  759 	mov	dptr,#(_ak820_flash_diagnostic + 0x0001)
      003948 EE               [12]  760 	mov	a,r6
      003949 F0               [24]  761 	movx	@dptr,a
                                    762 ;	keyboards/ajazz/ak820/ak820_flash.c:62: ak820_flash_diagnostic[4] = (uint8_t)address;
      00394A 90 04 EF         [24]  763 	mov	dptr,#_flash_operation_address_10000_21
      00394D E0               [24]  764 	movx	a,@dptr
      00394E FD               [12]  765 	mov	r5,a
      00394F A3               [24]  766 	inc	dptr
      003950 E0               [24]  767 	movx	a,@dptr
      003951 FE               [12]  768 	mov	r6,a
      003952 8D 04            [24]  769 	mov	ar4,r5
      003954 90 04 68         [24]  770 	mov	dptr,#(_ak820_flash_diagnostic + 0x0004)
      003957 EC               [12]  771 	mov	a,r4
      003958 F0               [24]  772 	movx	@dptr,a
                                    773 ;	keyboards/ajazz/ak820/ak820_flash.c:63: ak820_flash_diagnostic[5] = (uint8_t)(address >> 8);
      003959 8E 05            [24]  774 	mov	ar5,r6
      00395B 90 04 69         [24]  775 	mov	dptr,#(_ak820_flash_diagnostic + 0x0005)
      00395E ED               [12]  776 	mov	a,r5
      00395F F0               [24]  777 	movx	@dptr,a
                                    778 ;	keyboards/ajazz/ak820/ak820_flash.c:64: previous_ie = IE;
      003960 90 04 F1         [24]  779 	mov	dptr,#_flash_operation_previous_ie_10000_22
      003963 E5 A8            [12]  780 	mov	a,_IE
      003965 F0               [24]  781 	movx	@dptr,a
                                    782 ;	keyboards/ajazz/ak820/ak820_flash.c:65: EA = 0;
                                    783 ;	assignBit
      003966 C2 AF            [12]  784 	clr	_EA
                                    785 ;	keyboards/ajazz/ak820/ak820_flash.c:66: SAFE_MOD = 0x55;
      003968 75 A1 55         [24]  786 	mov	_SAFE_MOD,#0x55
                                    787 ;	keyboards/ajazz/ak820/ak820_flash.c:67: SAFE_MOD = 0xAA;
      00396B 75 A1 AA         [24]  788 	mov	_SAFE_MOD,#0xaa
                                    789 ;	keyboards/ajazz/ak820/ak820_flash.c:68: GLOBAL_CFG |= 0x08;  // CODE_WE
      00396E 43 B1 08         [24]  790 	orl	_GLOBAL_CFG,#0x08
                                    791 ;	keyboards/ajazz/ak820/ak820_flash.c:69: ROM_ADDR_L = (uint8_t)address;
      003971 8C 84            [24]  792 	mov	_ROM_ADDR_L,r4
                                    793 ;	keyboards/ajazz/ak820/ak820_flash.c:70: ROM_ADDR_H = (uint8_t)(address >> 8);
      003973 8D 85            [24]  794 	mov	_ROM_ADDR_H,r5
                                    795 ;	keyboards/ajazz/ak820/ak820_flash.c:73: ROM_BUF_MOD = operation ? 0x80 : AK820_FLASH_PAGE - 1;
      003975 EF               [12]  796 	mov	a,r7
      003976 60 04            [24]  797 	jz	00111$
      003978 7E 80            [12]  798 	mov	r6,#0x80
      00397A 80 02            [24]  799 	sjmp	00112$
      00397C                        800 00111$:
      00397C 7E 3F            [12]  801 	mov	r6,#0x3f
      00397E                        802 00112$:
      00397E 8E 8F            [24]  803 	mov	_ROM_DATA_HH,r6
                                    804 ;	keyboards/ajazz/ak820/ak820_flash.c:74: ROM_DAT_BUF = value;
      003980 90 04 ED         [24]  805 	mov	dptr,#_flash_operation_PARM_2
      003983 E0               [24]  806 	movx	a,@dptr
      003984 F5 8E            [12]  807 	mov	_ROM_DATA_HL,a
                                    808 ;	keyboards/ajazz/ak820/ak820_flash.c:75: if (operation) {
      003986 EF               [12]  809 	mov	a,r7
      003987 60 13            [24]  810 	jz	00105$
                                    811 ;	keyboards/ajazz/ak820/ak820_flash.c:76: uint16_t states = erase_page();
      003989 12 38 D8         [24]  812 	lcall	_erase_page
      00398C AE 82            [24]  813 	mov	r6, dpl
      00398E AF 83            [24]  814 	mov	r7, dph
                                    815 ;	keyboards/ajazz/ak820/ak820_flash.c:77: before = (uint8_t)(states >> 8);
      003990 90 04 F2         [24]  816 	mov	dptr,#_flash_operation_before_10000_22
      003993 EF               [12]  817 	mov	a,r7
      003994 F0               [24]  818 	movx	@dptr,a
                                    819 ;	keyboards/ajazz/ak820/ak820_flash.c:78: status = (uint8_t)states;
      003995 90 04 F3         [24]  820 	mov	dptr,#_flash_operation_status_10000_22
      003998 EE               [12]  821 	mov	a,r6
      003999 F0               [24]  822 	movx	@dptr,a
      00399A 80 1D            [24]  823 	sjmp	00106$
      00399C                        824 00105$:
                                    825 ;	keyboards/ajazz/ak820/ak820_flash.c:80: uint16_t states = program_block(block_data);
      00399C 90 04 E9         [24]  826 	mov	dptr,#_block_data
      00399F E0               [24]  827 	movx	a,@dptr
      0039A0 FE               [12]  828 	mov	r6,a
      0039A1 A3               [24]  829 	inc	dptr
      0039A2 E0               [24]  830 	movx	a,@dptr
      0039A3 FF               [12]  831 	mov	r7,a
      0039A4 8E 82            [24]  832 	mov	dpl, r6
      0039A6 8F 83            [24]  833 	mov	dph, r7
      0039A8 12 38 C6         [24]  834 	lcall	_program_block
      0039AB AE 82            [24]  835 	mov	r6, dpl
      0039AD AF 83            [24]  836 	mov	r7, dph
                                    837 ;	keyboards/ajazz/ak820/ak820_flash.c:81: before = (uint8_t)(states >> 8);
      0039AF 90 04 F2         [24]  838 	mov	dptr,#_flash_operation_before_10000_22
      0039B2 EF               [12]  839 	mov	a,r7
      0039B3 F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_flash.c:82: status = (uint8_t)states;
      0039B4 90 04 F3         [24]  842 	mov	dptr,#_flash_operation_status_10000_22
      0039B7 EE               [12]  843 	mov	a,r6
      0039B8 F0               [24]  844 	movx	@dptr,a
      0039B9                        845 00106$:
                                    846 ;	keyboards/ajazz/ak820/ak820_flash.c:84: ak820_flash_diagnostic[2] = before;
      0039B9 90 04 F2         [24]  847 	mov	dptr,#_flash_operation_before_10000_22
      0039BC E0               [24]  848 	movx	a,@dptr
      0039BD FF               [12]  849 	mov	r7,a
      0039BE 90 04 66         [24]  850 	mov	dptr,#(_ak820_flash_diagnostic + 0x0002)
      0039C1 F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_flash.c:85: ak820_flash_diagnostic[3] = status;
      0039C2 90 04 F3         [24]  853 	mov	dptr,#_flash_operation_status_10000_22
      0039C5 E0               [24]  854 	movx	a,@dptr
      0039C6 FE               [12]  855 	mov	r6,a
      0039C7 90 04 67         [24]  856 	mov	dptr,#(_ak820_flash_diagnostic + 0x0003)
      0039CA F0               [24]  857 	movx	@dptr,a
                                    858 ;	keyboards/ajazz/ak820/ak820_flash.c:86: SAFE_MOD = 0x55;
      0039CB 75 A1 55         [24]  859 	mov	_SAFE_MOD,#0x55
                                    860 ;	keyboards/ajazz/ak820/ak820_flash.c:87: SAFE_MOD = 0xAA;
      0039CE 75 A1 AA         [24]  861 	mov	_SAFE_MOD,#0xaa
                                    862 ;	keyboards/ajazz/ak820/ak820_flash.c:88: GLOBAL_CFG &= (uint8_t)~0x08;
      0039D1 53 B1 F7         [24]  863 	anl	_GLOBAL_CFG,#0xf7
                                    864 ;	keyboards/ajazz/ak820/ak820_flash.c:89: SAFE_MOD = 0;
      0039D4 75 A1 00         [24]  865 	mov	_SAFE_MOD,#0x00
                                    866 ;	keyboards/ajazz/ak820/ak820_flash.c:90: IE = previous_ie;
      0039D7 90 04 F1         [24]  867 	mov	dptr,#_flash_operation_previous_ie_10000_22
      0039DA E0               [24]  868 	movx	a,@dptr
      0039DB F5 A8            [12]  869 	mov	_IE,a
                                    870 ;	keyboards/ajazz/ak820/ak820_flash.c:91: return (before & 0x40) && !(status & 0x02);
      0039DD EF               [12]  871 	mov	a,r7
      0039DE 23               [12]  872 	rl	a
      0039DF 23               [12]  873 	rl	a
      0039E0 54 01            [12]  874 	anl	a,#0x01
      0039E2 60 06            [24]  875 	jz	00113$
      0039E4 EE               [12]  876 	mov	a,r6
      0039E5 03               [12]  877 	rr	a
      0039E6 54 01            [12]  878 	anl	a,#0x01
      0039E8 60 04            [24]  879 	jz	00114$
      0039EA                        880 00113$:
                                    881 ;	assignBit
      0039EA C2 04            [12]  882 	clr	_flash_operation_sloc0_1_0
      0039EC 80 02            [24]  883 	sjmp	00115$
      0039EE                        884 00114$:
                                    885 ;	assignBit
      0039EE D2 04            [12]  886 	setb	_flash_operation_sloc0_1_0
      0039F0                        887 00115$:
      0039F0 A2 04            [12]  888 	mov	c,_flash_operation_sloc0_1_0
      0039F2 E4               [12]  889 	clr	a
      0039F3 33               [12]  890 	rlc	a
      0039F4 F5 82            [12]  891 	mov	dpl, a
                                    892 ;	keyboards/ajazz/ak820/ak820_flash.c:92: }
      0039F6 22               [24]  893 	ret
                                    894 ;------------------------------------------------------------
                                    895 ;Allocation info for local variables in function 'ak820_flash_erase'
                                    896 ;------------------------------------------------------------
                                    897 ;address       Allocated with name '_ak820_flash_erase_address_10000_27'
                                    898 ;i             Allocated with name '_ak820_flash_erase_i_10000_28'
                                    899 ;------------------------------------------------------------
                                    900 ;	keyboards/ajazz/ak820/ak820_flash.c:94: bool ak820_flash_erase(uint16_t address) {
                                    901 ;	-----------------------------------------
                                    902 ;	 function ak820_flash_erase
                                    903 ;	-----------------------------------------
      0039F7                        904 _ak820_flash_erase:
      0039F7 AF 83            [24]  905 	mov	r7,dph
      0039F9 E5 82            [12]  906 	mov	a,dpl
      0039FB 90 04 F4         [24]  907 	mov	dptr,#_ak820_flash_erase_address_10000_27
      0039FE F0               [24]  908 	movx	@dptr,a
      0039FF EF               [12]  909 	mov	a,r7
      003A00 A3               [24]  910 	inc	dptr
      003A01 F0               [24]  911 	movx	@dptr,a
                                    912 ;	keyboards/ajazz/ak820/ak820_flash.c:96: if (address & (AK820_FLASH_PAGE - 1)) return false;
      003A02 90 04 F4         [24]  913 	mov	dptr,#_ak820_flash_erase_address_10000_27
      003A05 E0               [24]  914 	movx	a,@dptr
      003A06 FE               [12]  915 	mov	r6,a
      003A07 A3               [24]  916 	inc	dptr
      003A08 E0               [24]  917 	movx	a,@dptr
      003A09 FF               [12]  918 	mov	r7,a
      003A0A EE               [12]  919 	mov	a,r6
      003A0B 54 3F            [12]  920 	anl	a,#0x3f
      003A0D 60 04            [24]  921 	jz	00102$
      003A0F 75 82 00         [24]  922 	mov	dpl, #0x00
      003A12 22               [24]  923 	ret
      003A13                        924 00102$:
                                    925 ;	keyboards/ajazz/ak820/ak820_flash.c:97: if (!flash_operation(address, 0, 0xA6)) return false;
      003A13 90 04 ED         [24]  926 	mov	dptr,#_flash_operation_PARM_2
      003A16 E4               [12]  927 	clr	a
      003A17 F0               [24]  928 	movx	@dptr,a
      003A18 90 04 EE         [24]  929 	mov	dptr,#_flash_operation_PARM_3
      003A1B 74 A6            [12]  930 	mov	a,#0xa6
      003A1D F0               [24]  931 	movx	@dptr,a
      003A1E 8E 82            [24]  932 	mov	dpl, r6
      003A20 8F 83            [24]  933 	mov	dph, r7
      003A22 12 39 0E         [24]  934 	lcall	_flash_operation
      003A25 E5 82            [12]  935 	mov	a, dpl
      003A27 70 03            [24]  936 	jnz	00120$
      003A29 F5 82            [12]  937 	mov	dpl,a
                                    938 ;	keyboards/ajazz/ak820/ak820_flash.c:100: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003A2B 22               [24]  939 	ret
      003A2C                        940 00120$:
      003A2C 7F 00            [12]  941 	mov	r7,#0x00
      003A2E                        942 00108$:
                                    943 ;	keyboards/ajazz/ak820/ak820_flash.c:101: if (ak820_flash_read(address + i) != 0) return false;
      003A2E 8F 05            [24]  944 	mov	ar5,r7
      003A30 7E 00            [12]  945 	mov	r6,#0x00
      003A32 90 04 F4         [24]  946 	mov	dptr,#_ak820_flash_erase_address_10000_27
      003A35 E0               [24]  947 	movx	a,@dptr
      003A36 FB               [12]  948 	mov	r3,a
      003A37 A3               [24]  949 	inc	dptr
      003A38 E0               [24]  950 	movx	a,@dptr
      003A39 FC               [12]  951 	mov	r4,a
      003A3A ED               [12]  952 	mov	a,r5
      003A3B 2B               [12]  953 	add	a, r3
      003A3C FB               [12]  954 	mov	r3,a
      003A3D EE               [12]  955 	mov	a,r6
      003A3E 3C               [12]  956 	addc	a, r4
      003A3F FC               [12]  957 	mov	r4,a
      003A40 8B 82            [24]  958 	mov	dpl, r3
      003A42 8C 83            [24]  959 	mov	dph, r4
      003A44 12 38 EA         [24]  960 	lcall	_ak820_flash_read
      003A47 E5 82            [12]  961 	mov	a, dpl
      003A49 60 04            [24]  962 	jz	00109$
      003A4B 75 82 00         [24]  963 	mov	dpl, #0x00
      003A4E 22               [24]  964 	ret
      003A4F                        965 00109$:
                                    966 ;	keyboards/ajazz/ak820/ak820_flash.c:100: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003A4F 0F               [12]  967 	inc	r7
      003A50 BF 40 DB         [24]  968 	cjne	r7,#0x40,00108$
                                    969 ;	keyboards/ajazz/ak820/ak820_flash.c:103: return true;
      003A53 75 82 01         [24]  970 	mov	dpl, #0x01
                                    971 ;	keyboards/ajazz/ak820/ak820_flash.c:104: }
      003A56 22               [24]  972 	ret
                                    973 ;------------------------------------------------------------
                                    974 ;Allocation info for local variables in function 'ak820_flash_program'
                                    975 ;------------------------------------------------------------
                                    976 ;sloc0         Allocated with name '_ak820_flash_program_sloc0_1_0'
                                    977 ;value         Allocated with name '_ak820_flash_program_PARM_2'
                                    978 ;address       Allocated with name '_ak820_flash_program_address_10000_34'
                                    979 ;i             Allocated with name '_ak820_flash_program_i_10000_35'
                                    980 ;offset        Allocated with name '_ak820_flash_program_offset_10000_35'
                                    981 ;page          Allocated with name '_ak820_flash_program_page_10000_35'
                                    982 ;------------------------------------------------------------
                                    983 ;	keyboards/ajazz/ak820/ak820_flash.c:106: bool ak820_flash_program(uint16_t address, uint8_t value) {
                                    984 ;	-----------------------------------------
                                    985 ;	 function ak820_flash_program
                                    986 ;	-----------------------------------------
      003A57                        987 _ak820_flash_program:
      003A57 AF 83            [24]  988 	mov	r7,dph
      003A59 E5 82            [12]  989 	mov	a,dpl
      003A5B 90 04 F7         [24]  990 	mov	dptr,#_ak820_flash_program_address_10000_34
      003A5E F0               [24]  991 	movx	@dptr,a
      003A5F EF               [12]  992 	mov	a,r7
      003A60 A3               [24]  993 	inc	dptr
      003A61 F0               [24]  994 	movx	@dptr,a
                                    995 ;	keyboards/ajazz/ak820/ak820_flash.c:110: if (address < AK820_NVM_BASE || address >= AK820_NVM_WRITE_END) return false;
      003A62 90 04 F7         [24]  996 	mov	dptr,#_ak820_flash_program_address_10000_34
      003A65 E0               [24]  997 	movx	a,@dptr
      003A66 FE               [12]  998 	mov	r6,a
      003A67 A3               [24]  999 	inc	dptr
      003A68 E0               [24] 1000 	movx	a,@dptr
      003A69 FF               [12] 1001 	mov	r7,a
      003A6A 8E 04            [24] 1002 	mov	ar4,r6
      003A6C 8F 05            [24] 1003 	mov	ar5,r7
      003A6E 74 39            [12] 1004 	mov	a,#0x100 - 0xc7
      003A70 2D               [12] 1005 	add	a,r5
      003A71 50 09            [24] 1006 	jnc	00101$
      003A73 C3               [12] 1007 	clr	c
      003A74 EC               [12] 1008 	mov	a,r4
      003A75 94 80            [12] 1009 	subb	a,#0x80
      003A77 ED               [12] 1010 	mov	a,r5
      003A78 94 EF            [12] 1011 	subb	a,#0xef
      003A7A 40 04            [24] 1012 	jc	00102$
      003A7C                       1013 00101$:
      003A7C 75 82 00         [24] 1014 	mov	dpl, #0x00
      003A7F 22               [24] 1015 	ret
      003A80                       1016 00102$:
                                   1017 ;	keyboards/ajazz/ak820/ak820_flash.c:111: offset = address & (AK820_FLASH_PAGE - 1);
      003A80 74 3F            [12] 1018 	mov	a,#0x3f
      003A82 5E               [12] 1019 	anl	a,r6
      003A83 FF               [12] 1020 	mov	r7,a
                                   1021 ;	keyboards/ajazz/ak820/ak820_flash.c:112: page = address & ~(AK820_FLASH_PAGE - 1);
      003A84 53 04 C0         [24] 1022 	anl	ar4,#0xc0
                                   1023 ;	keyboards/ajazz/ak820/ak820_flash.c:113: block_data = (uint8_t __xdata *)(((uint16_t)block_storage + AK820_FLASH_PAGE - 1) & ~(AK820_FLASH_PAGE - 1));
      003A87 7B 6A            [12] 1024 	mov	r3,#_block_storage
      003A89 7E 04            [12] 1025 	mov	r6,#(_block_storage >> 8)
      003A8B 74 3F            [12] 1026 	mov	a,#0x3f
      003A8D 2B               [12] 1027 	add	a, r3
      003A8E FB               [12] 1028 	mov	r3,a
      003A8F E4               [12] 1029 	clr	a
      003A90 3E               [12] 1030 	addc	a, r6
      003A91 FE               [12] 1031 	mov	r6,a
      003A92 53 03 C0         [24] 1032 	anl	ar3,#0xc0
      003A95 90 04 E9         [24] 1033 	mov	dptr,#_block_data
      003A98 EB               [12] 1034 	mov	a,r3
      003A99 F0               [24] 1035 	movx	@dptr,a
      003A9A EE               [12] 1036 	mov	a,r6
      003A9B A3               [24] 1037 	inc	dptr
      003A9C F0               [24] 1038 	movx	@dptr,a
                                   1039 ;	keyboards/ajazz/ak820/ak820_flash.c:119: for (i = 0; i != AK820_FLASH_PAGE; ++i) block_data[i] = ak820_flash_read(page + i);
      003A9D 7E 00            [12] 1040 	mov	r6,#0x00
      003A9F                       1041 00105$:
      003A9F C0 07            [24] 1042 	push	ar7
      003AA1 90 04 E9         [24] 1043 	mov	dptr,#_block_data
      003AA4 E0               [24] 1044 	movx	a,@dptr
      003AA5 FA               [12] 1045 	mov	r2,a
      003AA6 A3               [24] 1046 	inc	dptr
      003AA7 E0               [24] 1047 	movx	a,@dptr
      003AA8 FB               [12] 1048 	mov	r3,a
      003AA9 EE               [12] 1049 	mov	a,r6
      003AAA 2A               [12] 1050 	add	a, r2
      003AAB FA               [12] 1051 	mov	r2,a
      003AAC E4               [12] 1052 	clr	a
      003AAD 3B               [12] 1053 	addc	a, r3
      003AAE FB               [12] 1054 	mov	r3,a
      003AAF 8E 08            [24] 1055 	mov	_ak820_flash_program_sloc0_1_0,r6
      003AB1 75 09 00         [24] 1056 	mov	(_ak820_flash_program_sloc0_1_0 + 1),#0x00
      003AB4 8C 01            [24] 1057 	mov	ar1,r4
      003AB6 8D 07            [24] 1058 	mov	ar7,r5
      003AB8 E5 08            [12] 1059 	mov	a,_ak820_flash_program_sloc0_1_0
      003ABA 29               [12] 1060 	add	a, r1
      003ABB F9               [12] 1061 	mov	r1,a
      003ABC E5 09            [12] 1062 	mov	a,(_ak820_flash_program_sloc0_1_0 + 1)
      003ABE 3F               [12] 1063 	addc	a, r7
      003ABF FF               [12] 1064 	mov	r7,a
      003AC0 89 82            [24] 1065 	mov	dpl, r1
      003AC2 8F 83            [24] 1066 	mov	dph, r7
      003AC4 12 38 EA         [24] 1067 	lcall	_ak820_flash_read
      003AC7 AF 82            [24] 1068 	mov	r7, dpl
      003AC9 8A 82            [24] 1069 	mov	dpl,r2
      003ACB 8B 83            [24] 1070 	mov	dph,r3
      003ACD EF               [12] 1071 	mov	a,r7
      003ACE F0               [24] 1072 	movx	@dptr,a
      003ACF 0E               [12] 1073 	inc	r6
      003AD0 BE 40 02         [24] 1074 	cjne	r6,#0x40,00133$
      003AD3 80 04            [24] 1075 	sjmp	00134$
      003AD5                       1076 00133$:
      003AD5 D0 07            [24] 1077 	pop	ar7
      003AD7 80 C6            [24] 1078 	sjmp	00105$
      003AD9                       1079 00134$:
      003AD9 D0 07            [24] 1080 	pop	ar7
                                   1081 ;	keyboards/ajazz/ak820/ak820_flash.c:120: block_data[offset] |= value;
      003ADB 90 04 E9         [24] 1082 	mov	dptr,#_block_data
      003ADE E0               [24] 1083 	movx	a,@dptr
      003ADF FB               [12] 1084 	mov	r3,a
      003AE0 A3               [24] 1085 	inc	dptr
      003AE1 E0               [24] 1086 	movx	a,@dptr
      003AE2 FE               [12] 1087 	mov	r6,a
      003AE3 EF               [12] 1088 	mov	a,r7
      003AE4 2B               [12] 1089 	add	a, r3
      003AE5 FF               [12] 1090 	mov	r7,a
      003AE6 E4               [12] 1091 	clr	a
      003AE7 3E               [12] 1092 	addc	a, r6
      003AE8 FA               [12] 1093 	mov	r2,a
      003AE9 8F 82            [24] 1094 	mov	dpl,r7
      003AEB 8A 83            [24] 1095 	mov	dph,r2
      003AED E0               [24] 1096 	movx	a,@dptr
      003AEE FE               [12] 1097 	mov	r6,a
      003AEF 90 04 F6         [24] 1098 	mov	dptr,#_ak820_flash_program_PARM_2
      003AF2 E0               [24] 1099 	movx	a,@dptr
      003AF3 42 06            [12] 1100 	orl	ar6,a
      003AF5 8F 82            [24] 1101 	mov	dpl,r7
      003AF7 8A 83            [24] 1102 	mov	dph,r2
      003AF9 EE               [12] 1103 	mov	a,r6
      003AFA F0               [24] 1104 	movx	@dptr,a
                                   1105 ;	keyboards/ajazz/ak820/ak820_flash.c:121: return flash_operation(page, 0, 0);
      003AFB 90 04 ED         [24] 1106 	mov	dptr,#_flash_operation_PARM_2
      003AFE E4               [12] 1107 	clr	a
      003AFF F0               [24] 1108 	movx	@dptr,a
      003B00 90 04 EE         [24] 1109 	mov	dptr,#_flash_operation_PARM_3
      003B03 F0               [24] 1110 	movx	@dptr,a
      003B04 8C 82            [24] 1111 	mov	dpl, r4
      003B06 8D 83            [24] 1112 	mov	dph, r5
                                   1113 ;	keyboards/ajazz/ak820/ak820_flash.c:122: }
      003B08 02 39 0E         [24] 1114 	ljmp	_flash_operation
                                   1115 ;------------------------------------------------------------
                                   1116 ;Allocation info for local variables in function 'ak820_flash_program_page'
                                   1117 ;------------------------------------------------------------
                                   1118 ;data          Allocated with name '_ak820_flash_program_page_PARM_2'
                                   1119 ;address       Allocated with name '_ak820_flash_program_page_address_10000_38'
                                   1120 ;i             Allocated with name '_ak820_flash_program_page_i_10000_39'
                                   1121 ;------------------------------------------------------------
                                   1122 ;	keyboards/ajazz/ak820/ak820_flash.c:124: bool ak820_flash_program_page(uint16_t address, const uint8_t __xdata *data) {
                                   1123 ;	-----------------------------------------
                                   1124 ;	 function ak820_flash_program_page
                                   1125 ;	-----------------------------------------
      003B0B                       1126 _ak820_flash_program_page:
      003B0B AF 83            [24] 1127 	mov	r7,dph
      003B0D E5 82            [12] 1128 	mov	a,dpl
      003B0F 90 04 FB         [24] 1129 	mov	dptr,#_ak820_flash_program_page_address_10000_38
      003B12 F0               [24] 1130 	movx	@dptr,a
      003B13 EF               [12] 1131 	mov	a,r7
      003B14 A3               [24] 1132 	inc	dptr
      003B15 F0               [24] 1133 	movx	@dptr,a
                                   1134 ;	keyboards/ajazz/ak820/ak820_flash.c:126: if (address & (AK820_FLASH_PAGE - 1)) return false;
      003B16 90 04 FB         [24] 1135 	mov	dptr,#_ak820_flash_program_page_address_10000_38
      003B19 E0               [24] 1136 	movx	a,@dptr
      003B1A FE               [12] 1137 	mov	r6,a
      003B1B A3               [24] 1138 	inc	dptr
      003B1C E0               [24] 1139 	movx	a,@dptr
      003B1D EE               [12] 1140 	mov	a,r6
      003B1E 54 3F            [12] 1141 	anl	a,#0x3f
      003B20 60 04            [24] 1142 	jz	00102$
      003B22 75 82 00         [24] 1143 	mov	dpl, #0x00
      003B25 22               [24] 1144 	ret
      003B26                       1145 00102$:
                                   1146 ;	keyboards/ajazz/ak820/ak820_flash.c:127: block_data = (uint8_t __xdata *)(((uint16_t)block_storage + AK820_FLASH_PAGE - 1) & ~(AK820_FLASH_PAGE - 1));
      003B26 7E 6A            [12] 1147 	mov	r6,#_block_storage
      003B28 7F 04            [12] 1148 	mov	r7,#(_block_storage >> 8)
      003B2A 74 3F            [12] 1149 	mov	a,#0x3f
      003B2C 2E               [12] 1150 	add	a, r6
      003B2D FE               [12] 1151 	mov	r6,a
      003B2E E4               [12] 1152 	clr	a
      003B2F 3F               [12] 1153 	addc	a, r7
      003B30 FF               [12] 1154 	mov	r7,a
      003B31 53 06 C0         [24] 1155 	anl	ar6,#0xc0
      003B34 90 04 E9         [24] 1156 	mov	dptr,#_block_data
      003B37 EE               [12] 1157 	mov	a,r6
      003B38 F0               [24] 1158 	movx	@dptr,a
      003B39 EF               [12] 1159 	mov	a,r7
      003B3A A3               [24] 1160 	inc	dptr
      003B3B F0               [24] 1161 	movx	@dptr,a
                                   1162 ;	keyboards/ajazz/ak820/ak820_flash.c:128: for (i = 0; i != AK820_FLASH_PAGE; ++i) block_data[i] = data[i];
      003B3C 90 04 F9         [24] 1163 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003B3F E0               [24] 1164 	movx	a,@dptr
      003B40 FE               [12] 1165 	mov	r6,a
      003B41 A3               [24] 1166 	inc	dptr
      003B42 E0               [24] 1167 	movx	a,@dptr
      003B43 FF               [12] 1168 	mov	r7,a
      003B44 7D 00            [12] 1169 	mov	r5,#0x00
      003B46                       1170 00104$:
      003B46 90 04 E9         [24] 1171 	mov	dptr,#_block_data
      003B49 E0               [24] 1172 	movx	a,@dptr
      003B4A FB               [12] 1173 	mov	r3,a
      003B4B A3               [24] 1174 	inc	dptr
      003B4C E0               [24] 1175 	movx	a,@dptr
      003B4D FC               [12] 1176 	mov	r4,a
      003B4E ED               [12] 1177 	mov	a,r5
      003B4F 2B               [12] 1178 	add	a, r3
      003B50 FB               [12] 1179 	mov	r3,a
      003B51 E4               [12] 1180 	clr	a
      003B52 3C               [12] 1181 	addc	a, r4
      003B53 FC               [12] 1182 	mov	r4,a
      003B54 ED               [12] 1183 	mov	a,r5
      003B55 2E               [12] 1184 	add	a, r6
      003B56 F5 82            [12] 1185 	mov	dpl,a
      003B58 E4               [12] 1186 	clr	a
      003B59 3F               [12] 1187 	addc	a, r7
      003B5A F5 83            [12] 1188 	mov	dph,a
      003B5C E0               [24] 1189 	movx	a,@dptr
      003B5D 8B 82            [24] 1190 	mov	dpl,r3
      003B5F 8C 83            [24] 1191 	mov	dph,r4
      003B61 F0               [24] 1192 	movx	@dptr,a
      003B62 0D               [12] 1193 	inc	r5
      003B63 BD 40 E0         [24] 1194 	cjne	r5,#0x40,00104$
                                   1195 ;	keyboards/ajazz/ak820/ak820_flash.c:129: return flash_operation(address, 0, 0);
      003B66 90 04 FB         [24] 1196 	mov	dptr,#_ak820_flash_program_page_address_10000_38
      003B69 E0               [24] 1197 	movx	a,@dptr
      003B6A FE               [12] 1198 	mov	r6,a
      003B6B A3               [24] 1199 	inc	dptr
      003B6C E0               [24] 1200 	movx	a,@dptr
      003B6D FF               [12] 1201 	mov	r7,a
      003B6E 90 04 ED         [24] 1202 	mov	dptr,#_flash_operation_PARM_2
      003B71 E4               [12] 1203 	clr	a
      003B72 F0               [24] 1204 	movx	@dptr,a
      003B73 90 04 EE         [24] 1205 	mov	dptr,#_flash_operation_PARM_3
      003B76 F0               [24] 1206 	movx	@dptr,a
      003B77 8E 82            [24] 1207 	mov	dpl, r6
      003B79 8F 83            [24] 1208 	mov	dph, r7
                                   1209 ;	keyboards/ajazz/ak820/ak820_flash.c:130: }
      003B7B 02 39 0E         [24] 1210 	ljmp	_flash_operation
                                   1211 	.area CSEG    (CODE)
                                   1212 	.area CONST   (CODE)
                                   1213 	.area XINIT   (CODE)
                                   1214 	.area CABS    (ABS,CODE)
