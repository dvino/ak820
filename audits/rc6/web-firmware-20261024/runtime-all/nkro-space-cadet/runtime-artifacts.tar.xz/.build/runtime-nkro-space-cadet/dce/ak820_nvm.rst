                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_nvm
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _eeprom_driver_erase
                                     12 	.globl _eeprom_read_byte
                                     13 	.globl _eeprom_driver_init
                                     14 	.globl _ak820_macro_init
                                     15 	.globl _ak820_flash_program_page
                                     16 	.globl _ak820_flash_program
                                     17 	.globl _ak820_flash_erase
                                     18 	.globl _ak820_flash_read
                                     19 	.globl _ak820_eeprom_update_block_xdata_PARM_3
                                     20 	.globl _ak820_eeprom_update_block_xdata_PARM_2
                                     21 	.globl _ak820_eeprom_write_block_xdata_PARM_3
                                     22 	.globl _ak820_eeprom_write_block_xdata_PARM_2
                                     23 	.globl _ak820_eeprom_read_block_xdata_PARM_3
                                     24 	.globl _ak820_eeprom_read_block_xdata_PARM_2
                                     25 	.globl _ak820_nvm_diagnostic
                                     26 	.globl _ak820_nvm_ok
                                     27 	.globl _ak820_nvm_schema_fault
                                     28 	.globl _ak820_nvm_flush
                                     29 	.globl _ak820_nvm_begin
                                     30 	.globl _ak820_nvm_end
                                     31 	.globl _ak820_eeprom_read_block_xdata
                                     32 	.globl _ak820_eeprom_write_block_xdata
                                     33 	.globl _ak820_eeprom_update_block_xdata
                                     34 ;--------------------------------------------------------
                                     35 ; special function registers
                                     36 ;--------------------------------------------------------
                                     37 	.area RSEG    (ABS,DATA)
      000000                         38 	.org 0x0000
                                     39 ;--------------------------------------------------------
                                     40 ; special function bits
                                     41 ;--------------------------------------------------------
                                     42 	.area RSEG    (ABS,DATA)
      000000                         43 	.org 0x0000
                                     44 ;--------------------------------------------------------
                                     45 ; overlayable register banks
                                     46 ;--------------------------------------------------------
                                     47 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         48 	.ds 8
                                     49 ;--------------------------------------------------------
                                     50 ; overlayable bit register bank
                                     51 ;--------------------------------------------------------
                                     52 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         53 bits:
      000026                         54 	.ds 1
                           008000    55 	b0 = bits[0]
                           008100    56 	b1 = bits[1]
                           008200    57 	b2 = bits[2]
                           008300    58 	b3 = bits[3]
                           008400    59 	b4 = bits[4]
                           008500    60 	b5 = bits[5]
                           008600    61 	b6 = bits[6]
                           008700    62 	b7 = bits[7]
                                     63 ;--------------------------------------------------------
                                     64 ; internal ram data
                                     65 ;--------------------------------------------------------
                                     66 	.area DSEG    (DATA)
      00000C                         67 _ak820_eeprom_write_block_xdata_sloc0_1_0:
      00000C                         68 	.ds 2
      00000E                         69 _ak820_eeprom_update_block_xdata_sloc0_1_0:
      00000E                         70 	.ds 2
      000010                         71 _ak820_eeprom_update_block_xdata_sloc1_1_0:
      000010                         72 	.ds 2
      000012                         73 _ak820_eeprom_update_block_xdata_sloc2_1_0:
      000012                         74 	.ds 3
                                     75 ;--------------------------------------------------------
                                     76 ; overlayable items in internal ram
                                     77 ;--------------------------------------------------------
                                     78 ;--------------------------------------------------------
                                     79 ; indirectly addressable internal ram data
                                     80 ;--------------------------------------------------------
                                     81 	.area ISEG    (DATA)
                                     82 ;--------------------------------------------------------
                                     83 ; absolute internal ram data
                                     84 ;--------------------------------------------------------
                                     85 	.area IABS    (ABS,DATA)
                                     86 	.area IABS    (ABS,DATA)
                                     87 ;--------------------------------------------------------
                                     88 ; bit data
                                     89 ;--------------------------------------------------------
                                     90 	.area BSEG    (BIT)
      000009                         91 _page_valid:
      000009                         92 	.ds 1
      00000A                         93 _page_dirty:
      00000A                         94 	.ds 1
      00000B                         95 _storage_failed:
      00000B                         96 	.ds 1
      00000C                         97 _ak820_nvm_ok_sloc0_1_0:
      00000C                         98 	.ds 1
      00000D                         99 _load_page_sloc0_1_0:
      00000D                        100 	.ds 1
                                    101 ;--------------------------------------------------------
                                    102 ; paged external ram data
                                    103 ;--------------------------------------------------------
                                    104 	.area PSEG    (PAG,XDATA)
                                    105 ;--------------------------------------------------------
                                    106 ; uninitialized external ram data
                                    107 ;--------------------------------------------------------
                                    108 	.area XSEG    (XDATA)
      00051D                        109 _page_data:
      00051D                        110 	.ds 64
      00055D                        111 _cached_page:
      00055D                        112 	.ds 1
      00055E                        113 _batch_depth:
      00055E                        114 	.ds 1
      00055F                        115 _first_failure_stage:
      00055F                        116 	.ds 1
      000560                        117 _nvm_fail_stage_10000_20:
      000560                        118 	.ds 1
      000561                        119 _ak820_nvm_diagnostic_out_10000_23:
      000561                        120 	.ds 2
      000563                        121 _crc_byte_PARM_2:
      000563                        122 	.ds 1
      000564                        123 _crc_byte_crc_10000_25:
      000564                        124 	.ds 2
      000566                        125 _page_crc_crc_10000_30:
      000566                        126 	.ds 2
      000568                        127 _write_page_address_10000_32:
      000568                        128 	.ds 2
      00056A                        129 _journal_header_valid_header_10000_39:
      00056A                        130 	.ds 2
      00056C                        131 _recover_journal_header_10000_46:
      00056C                        132 	.ds 9
      000575                        133 _ak820_nvm_flush_header_10000_62:
      000575                        134 	.ds 9
      00057E                        135 _ak820_nvm_flush_stage_10000_62:
      00057E                        136 	.ds 1
      00057F                        137 _load_page_page_10000_87:
      00057F                        138 	.ds 1
      000580                        139 _read_offset_offset_10000_93:
      000580                        140 	.ds 2
      000582                        141 _eeprom_read_byte_addr_10000_97:
      000582                        142 	.ds 3
      000585                        143 _ak820_eeprom_read_block_xdata_PARM_2:
      000585                        144 	.ds 3
      000588                        145 _ak820_eeprom_read_block_xdata_PARM_3:
      000588                        146 	.ds 2
      00058A                        147 _ak820_eeprom_read_block_xdata_buf_10000_113:
      00058A                        148 	.ds 2
      00058C                        149 _ak820_eeprom_read_block_xdata_out_10000_114:
      00058C                        150 	.ds 2
      00058E                        151 _ak820_eeprom_write_block_xdata_PARM_2:
      00058E                        152 	.ds 3
      000591                        153 _ak820_eeprom_write_block_xdata_PARM_3:
      000591                        154 	.ds 2
      000593                        155 _ak820_eeprom_write_block_xdata_buf_10000_118:
      000593                        156 	.ds 2
      000595                        157 _ak820_eeprom_update_block_xdata_PARM_2:
      000595                        158 	.ds 3
      000598                        159 _ak820_eeprom_update_block_xdata_PARM_3:
      000598                        160 	.ds 2
      00059A                        161 _ak820_eeprom_update_block_xdata_buf_10000_127:
      00059A                        162 	.ds 2
                                    163 ;--------------------------------------------------------
                                    164 ; absolute external ram data
                                    165 ;--------------------------------------------------------
                                    166 	.area XABS    (ABS,XDATA)
                                    167 ;--------------------------------------------------------
                                    168 ; initialized external ram data
                                    169 ;--------------------------------------------------------
                                    170 	.area XISEG   (XDATA)
                                    171 	.area HOME    (CODE)
                                    172 	.area GSINIT0 (CODE)
                                    173 	.area GSINIT1 (CODE)
                                    174 	.area GSINIT2 (CODE)
                                    175 	.area GSINIT3 (CODE)
                                    176 	.area GSINIT4 (CODE)
                                    177 	.area GSINIT5 (CODE)
                                    178 	.area GSINIT  (CODE)
                                    179 	.area GSFINAL (CODE)
                                    180 	.area CSEG    (CODE)
                                    181 ;--------------------------------------------------------
                                    182 ; global & static initialisations
                                    183 ;--------------------------------------------------------
                                    184 	.area HOME    (CODE)
                                    185 	.area GSINIT  (CODE)
                                    186 	.area GSFINAL (CODE)
                                    187 	.area GSINIT  (CODE)
                                    188 ;--------------------------------------------------------
                                    189 ; Home
                                    190 ;--------------------------------------------------------
                                    191 	.area HOME    (CODE)
                                    192 	.area HOME    (CODE)
                                    193 ;--------------------------------------------------------
                                    194 ; code
                                    195 ;--------------------------------------------------------
                                    196 	.area CSEG    (CODE)
                                    197 ;------------------------------------------------------------
                                    198 ;Allocation info for local variables in function 'nvm_fail'
                                    199 ;------------------------------------------------------------
                                    200 ;stage         Allocated with name '_nvm_fail_stage_10000_20'
                                    201 ;------------------------------------------------------------
                                    202 ;	keyboards/ajazz/ak820/ak820_nvm.c:31: static void nvm_fail(uint8_t stage) {
                                    203 ;	-----------------------------------------
                                    204 ;	 function nvm_fail
                                    205 ;	-----------------------------------------
      003B7E                        206 _nvm_fail:
                           000007   207 	ar7 = 0x07
                           000006   208 	ar6 = 0x06
                           000005   209 	ar5 = 0x05
                           000004   210 	ar4 = 0x04
                           000003   211 	ar3 = 0x03
                           000002   212 	ar2 = 0x02
                           000001   213 	ar1 = 0x01
                           000000   214 	ar0 = 0x00
      003B7E E5 82            [12]  215 	mov	a,dpl
      003B80 90 05 60         [24]  216 	mov	dptr,#_nvm_fail_stage_10000_20
      003B83 F0               [24]  217 	movx	@dptr,a
                                    218 ;	keyboards/ajazz/ak820/ak820_nvm.c:32: if (!storage_failed) first_failure_stage = stage;
      003B84 20 0B 08         [24]  219 	jb	_storage_failed,00102$
      003B87 90 05 60         [24]  220 	mov	dptr,#_nvm_fail_stage_10000_20
      003B8A E0               [24]  221 	movx	a,@dptr
      003B8B 90 05 5F         [24]  222 	mov	dptr,#_first_failure_stage
      003B8E F0               [24]  223 	movx	@dptr,a
      003B8F                        224 00102$:
                                    225 ;	keyboards/ajazz/ak820/ak820_nvm.c:33: storage_failed = true;
                                    226 ;	assignBit
      003B8F D2 0B            [12]  227 	setb	_storage_failed
                                    228 ;	keyboards/ajazz/ak820/ak820_nvm.c:34: }
      003B91 22               [24]  229 	ret
                                    230 ;------------------------------------------------------------
                                    231 ;Allocation info for local variables in function 'ak820_nvm_diagnostic'
                                    232 ;------------------------------------------------------------
                                    233 ;out           Allocated with name '_ak820_nvm_diagnostic_out_10000_23'
                                    234 ;------------------------------------------------------------
                                    235 ;	keyboards/ajazz/ak820/ak820_nvm.c:36: void ak820_nvm_diagnostic(uint8_t AK820_XDATA *out) {
                                    236 ;	-----------------------------------------
                                    237 ;	 function ak820_nvm_diagnostic
                                    238 ;	-----------------------------------------
      003B92                        239 _ak820_nvm_diagnostic:
      003B92 12 38 7D         [24]  240 	lcall	_ak820_outline_0103
      003B95 90 05 61         [24]  241 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B98 12 38 82         [24]  242 	lcall	_ak820_outline_0104
                                    243 ;	keyboards/ajazz/ak820/ak820_nvm.c:37: out[0] = storage_failed;
      003B9B 90 05 61         [24]  244 	mov	dptr,#_ak820_nvm_diagnostic_out_10000_23
      003B9E 12 38 42         [24]  245 	lcall	_ak820_outline_0051
      003BA1 A2 0B            [12]  246 	mov	c,_storage_failed
      003BA3 E4               [12]  247 	clr	a
      003BA4 33               [12]  248 	rlc	a
      003BA5 12 38 87         [24]  249 	lcall	_ak820_outline_0112
      003BA8 12 43 32         [24]  250 	lcall	_ak820_outline_0070
                                    251 ;	keyboards/ajazz/ak820/ak820_nvm.c:38: out[1] = page_valid;
      003BAB A3               [24]  252 	inc	dptr
      003BAC A2 09            [12]  253 	mov	c,_page_valid
      003BAE E4               [12]  254 	clr	a
      003BAF 33               [12]  255 	rlc	a
      003BB0 12 43 06         [24]  256 	lcall	_ak820_outline_0030
                                    257 ;	keyboards/ajazz/ak820/ak820_nvm.c:39: out[2] = page_dirty;
      003BB3 A2 0A            [12]  258 	mov	c,_page_dirty
      003BB5 E4               [12]  259 	clr	a
      003BB6 33               [12]  260 	rlc	a
      003BB7 F0               [24]  261 	movx	@dptr,a
                                    262 ;	keyboards/ajazz/ak820/ak820_nvm.c:40: out[3] = batch_depth;
      003BB8 74 03            [12]  263 	mov	a,#0x03
      003BBA 12 43 71         [24]  264 	lcall	_ak820_outline_0154
      003BBD 90 05 5E         [24]  265 	mov	dptr,#_batch_depth
      003BC0 E0               [24]  266 	movx	a,@dptr
      003BC1 12 43 50         [24]  267 	lcall	_ak820_outline_0115
                                    268 ;	keyboards/ajazz/ak820/ak820_nvm.c:41: out[4] = (uint8_t)cached_page;
      003BC4 74 04            [12]  269 	mov	a,#0x04
      003BC6 12 43 71         [24]  270 	lcall	_ak820_outline_0154
      003BC9 90 05 5D         [24]  271 	mov	dptr,#_cached_page
      003BCC E0               [24]  272 	movx	a,@dptr
      003BCD 12 43 50         [24]  273 	lcall	_ak820_outline_0115
                                    274 ;	keyboards/ajazz/ak820/ak820_nvm.c:42: out[5] = (uint8_t)(cached_page >> 8);
      003BD0 12 42 FC         [24]  275 	lcall	_ak820_outline_0011
      003BD3 E4               [12]  276 	clr	a
      003BD4 F0               [24]  277 	movx	@dptr,a
                                    278 ;	keyboards/ajazz/ak820/ak820_nvm.c:43: out[6] = first_failure_stage;
      003BD5 74 06            [12]  279 	mov	a,#0x06
      003BD7 12 43 5B         [24]  280 	lcall	_ak820_outline_0131
      003BDA 90 05 5F         [24]  281 	mov	dptr,#_first_failure_stage
      003BDD E0               [24]  282 	movx	a,@dptr
      003BDE 12 38 87         [24]  283 	lcall	_ak820_outline_0112
      003BE1 F0               [24]  284 	movx	@dptr,a
                                    285 ;	keyboards/ajazz/ak820/ak820_nvm.c:44: }
      003BE2 22               [24]  286 	ret
                                    287 ;------------------------------------------------------------
                                    288 ;Allocation info for local variables in function 'crc_byte'
                                    289 ;------------------------------------------------------------
                                    290 ;value         Allocated with name '_crc_byte_PARM_2'
                                    291 ;crc           Allocated with name '_crc_byte_crc_10000_25'
                                    292 ;bit           Allocated with name '_crc_byte_bit_10000_26'
                                    293 ;------------------------------------------------------------
                                    294 ;	keyboards/ajazz/ak820/ak820_nvm.c:46: static uint16_t crc_byte(uint16_t crc, uint8_t value) {
                                    295 ;	-----------------------------------------
                                    296 ;	 function crc_byte
                                    297 ;	-----------------------------------------
      003BE3                        298 _crc_byte:
      003BE3 12 38 7D         [24]  299 	lcall	_ak820_outline_0103
      003BE6 90 05 64         [24]  300 	mov	dptr,#_crc_byte_crc_10000_25
      003BE9 12 38 82         [24]  301 	lcall	_ak820_outline_0104
                                    302 ;	keyboards/ajazz/ak820/ak820_nvm.c:48: crc ^= (uint16_t)value << 8;
      003BEC 90 05 63         [24]  303 	mov	dptr,#_crc_byte_PARM_2
      003BEF E0               [24]  304 	movx	a,@dptr
      003BF0 FF               [12]  305 	mov	r7,a
      003BF1 7E 00            [12]  306 	mov	r6,#0x00
      003BF3 90 05 64         [24]  307 	mov	dptr,#_crc_byte_crc_10000_25
      003BF6 E0               [24]  308 	movx	a,@dptr
      003BF7 6E               [12]  309 	xrl	a,r6
      003BF8 F0               [24]  310 	movx	@dptr,a
      003BF9 A3               [24]  311 	inc	dptr
      003BFA E0               [24]  312 	movx	a,@dptr
      003BFB 6F               [12]  313 	xrl	a,r7
      003BFC F0               [24]  314 	movx	@dptr,a
                                    315 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003BFD 7F 00            [12]  316 	mov	r7,#0x00
      003BFF                        317 00102$:
                                    318 ;	keyboards/ajazz/ak820/ak820_nvm.c:50: crc = (crc & 0x8000u) ? (uint16_t)((crc << 1) ^ 0x1021u) : (uint16_t)(crc << 1);
      003BFF 90 05 64         [24]  319 	mov	dptr,#_crc_byte_crc_10000_25
      003C02 12 38 71         [24]  320 	lcall	_ak820_outline_0092
      003C05 30 E7 0E         [24]  321 	jnb	acc.7,00106$
      003C08 ED               [12]  322 	mov	a,r5
      003C09 2D               [12]  323 	add	a,r5
      003C0A FB               [12]  324 	mov	r3,a
      003C0B EE               [12]  325 	mov	a,r6
      003C0C 33               [12]  326 	rlc	a
      003C0D FC               [12]  327 	mov	r4,a
      003C0E 63 03 21         [24]  328 	xrl	ar3,#0x21
      003C11 63 04 10         [24]  329 	xrl	ar4,#0x10
      003C14 80 06            [24]  330 	sjmp	00107$
      003C16                        331 00106$:
      003C16 ED               [12]  332 	mov	a,r5
      003C17 2D               [12]  333 	add	a,r5
      003C18 FB               [12]  334 	mov	r3,a
      003C19 EE               [12]  335 	mov	a,r6
      003C1A 33               [12]  336 	rlc	a
      003C1B FC               [12]  337 	mov	r4,a
      003C1C                        338 00107$:
      003C1C 90 05 64         [24]  339 	mov	dptr,#_crc_byte_crc_10000_25
      003C1F 12 38 65         [24]  340 	lcall	_ak820_outline_0081
                                    341 ;	keyboards/ajazz/ak820/ak820_nvm.c:49: for (bit = 0; bit != 8; ++bit) {
      003C22 0F               [12]  342 	inc	r7
      003C23 BF 08 D9         [24]  343 	cjne	r7,#0x08,00102$
                                    344 ;	keyboards/ajazz/ak820/ak820_nvm.c:52: return crc;
      003C26 12 33 FC         [24]  345 	lcall	_ak820_outline_0118
                                    346 ;	keyboards/ajazz/ak820/ak820_nvm.c:53: }
      003C29 22               [24]  347 	ret
                                    348 ;------------------------------------------------------------
                                    349 ;Allocation info for local variables in function 'page_crc'
                                    350 ;------------------------------------------------------------
                                    351 ;crc           Allocated with name '_page_crc_crc_10000_30'
                                    352 ;i             Allocated with name '_page_crc_i_10000_30'
                                    353 ;------------------------------------------------------------
                                    354 ;	keyboards/ajazz/ak820/ak820_nvm.c:55: static uint16_t page_crc(void) {
                                    355 ;	-----------------------------------------
                                    356 ;	 function page_crc
                                    357 ;	-----------------------------------------
      003C2A                        358 _page_crc:
                                    359 ;	keyboards/ajazz/ak820/ak820_nvm.c:56: uint16_t crc = 0xFFFFu;
      003C2A 90 05 66         [24]  360 	mov	dptr,#_page_crc_crc_10000_30
      003C2D 74 FF            [12]  361 	mov	a,#0xff
      003C2F F0               [24]  362 	movx	@dptr,a
      003C30 A3               [24]  363 	inc	dptr
      003C31 F0               [24]  364 	movx	@dptr,a
                                    365 ;	keyboards/ajazz/ak820/ak820_nvm.c:58: for (i = 0; i != AK820_FLASH_PAGE; ++i) crc = crc_byte(crc, page_data[i]);
      003C32 7F 00            [12]  366 	mov	r7,#0x00
      003C34                        367 00102$:
      003C34 90 05 66         [24]  368 	mov	dptr,#_page_crc_crc_10000_30
      003C37 12 38 71         [24]  369 	lcall	_ak820_outline_0092
      003C3A 12 43 44         [24]  370 	lcall	_ak820_outline_0101
      003C3D 90 05 63         [24]  371 	mov	dptr,#_crc_byte_PARM_2
      003C40 F0               [24]  372 	movx	@dptr,a
      003C41 12 38 9C         [24]  373 	lcall	_ak820_outline_0128
      003C44 C0 07            [24]  374 	push	ar7
      003C46 12 3B E3         [24]  375 	lcall	_crc_byte
      003C49 AD 82            [24]  376 	mov	r5, dpl
      003C4B AE 83            [24]  377 	mov	r6, dph
      003C4D D0 07            [24]  378 	pop	ar7
      003C4F 90 05 66         [24]  379 	mov	dptr,#_page_crc_crc_10000_30
      003C52 12 43 77         [24]  380 	lcall	_ak820_outline_0155
      003C55 0F               [12]  381 	inc	r7
      003C56 BF 40 DB         [24]  382 	cjne	r7,#0x40,00102$
                                    383 ;	keyboards/ajazz/ak820/ak820_nvm.c:59: return crc;
      003C59 12 38 9C         [24]  384 	lcall	_ak820_outline_0128
                                    385 ;	keyboards/ajazz/ak820/ak820_nvm.c:60: }
      003C5C 22               [24]  386 	ret
                                    387 ;------------------------------------------------------------
                                    388 ;Allocation info for local variables in function 'write_page'
                                    389 ;------------------------------------------------------------
                                    390 ;address       Allocated with name '_write_page_address_10000_32'
                                    391 ;i             Allocated with name '_write_page_i_10000_33'
                                    392 ;------------------------------------------------------------
                                    393 ;	keyboards/ajazz/ak820/ak820_nvm.c:62: static bool write_page(uint16_t address) {
                                    394 ;	-----------------------------------------
                                    395 ;	 function write_page
                                    396 ;	-----------------------------------------
      003C5D                        397 _write_page:
      003C5D 12 38 7D         [24]  398 	lcall	_ak820_outline_0103
      003C60 90 05 68         [24]  399 	mov	dptr,#_write_page_address_10000_32
      003C63 12 38 82         [24]  400 	lcall	_ak820_outline_0104
                                    401 ;	keyboards/ajazz/ak820/ak820_nvm.c:64: if (!ak820_flash_erase(address)) return false;
      003C66 90 05 68         [24]  402 	mov	dptr,#_write_page_address_10000_32
      003C69 12 37 F5         [24]  403 	lcall	_ak820_outline_0005
      003C6C C0 07            [24]  404 	push	ar7
      003C6E C0 06            [24]  405 	push	ar6
      003C70 12 39 F7         [24]  406 	lcall	_ak820_flash_erase
      003C73 E5 82            [12]  407 	mov	a, dpl
      003C75 D0 06            [24]  408 	pop	ar6
      003C77 D0 07            [24]  409 	pop	ar7
      003C79 70 03            [24]  410 	jnz	00102$
      003C7B F5 82            [12]  411 	mov	dpl,a
      003C7D 22               [24]  412 	ret
      003C7E                        413 00102$:
                                    414 ;	keyboards/ajazz/ak820/ak820_nvm.c:65: if (!ak820_flash_program_page(address, page_data)) return false;
      003C7E 90 04 F9         [24]  415 	mov	dptr,#_ak820_flash_program_page_PARM_2
      003C81 74 1D            [12]  416 	mov	a,#_page_data
      003C83 F0               [24]  417 	movx	@dptr,a
      003C84 74 05            [12]  418 	mov	a,#(_page_data >> 8)
      003C86 A3               [24]  419 	inc	dptr
      003C87 12 43 32         [24]  420 	lcall	_ak820_outline_0070
      003C8A 12 3B 0B         [24]  421 	lcall	_ak820_flash_program_page
      003C8D E5 82            [12]  422 	mov	a, dpl
      003C8F 70 03            [24]  423 	jnz	00120$
      003C91 F5 82            [12]  424 	mov	dpl,a
                                    425 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003C93 22               [24]  426 	ret
      003C94                        427 00120$:
      003C94 7F 00            [12]  428 	mov	r7,#0x00
      003C96                        429 00108$:
                                    430 ;	keyboards/ajazz/ak820/ak820_nvm.c:67: if (ak820_flash_read(address + i) != page_data[i]) return false;
      003C96 8F 05            [24]  431 	mov	ar5,r7
      003C98 7E 00            [12]  432 	mov	r6,#0x00
      003C9A 90 05 68         [24]  433 	mov	dptr,#_write_page_address_10000_32
      003C9D 12 38 8C         [24]  434 	lcall	_ak820_outline_0117
      003CA0 ED               [12]  435 	mov	a,r5
      003CA1 2B               [12]  436 	add	a, r3
      003CA2 FB               [12]  437 	mov	r3,a
      003CA3 EE               [12]  438 	mov	a,r6
      003CA4 3C               [12]  439 	addc	a, r4
      003CA5 FC               [12]  440 	mov	r4,a
      003CA6 12 33 FC         [24]  441 	lcall	_ak820_outline_0118
      003CA9 12 38 EA         [24]  442 	lcall	_ak820_flash_read
      003CAC AE 82            [24]  443 	mov	r6, dpl
      003CAE 12 43 44         [24]  444 	lcall	_ak820_outline_0101
      003CB1 FD               [12]  445 	mov	r5,a
      003CB2 EE               [12]  446 	mov	a,r6
      003CB3 B5 05 02         [24]  447 	cjne	a,ar5,00149$
      003CB6 80 04            [24]  448 	sjmp	00109$
      003CB8                        449 00149$:
      003CB8 75 82 00         [24]  450 	mov	dpl, #0x00
      003CBB 22               [24]  451 	ret
      003CBC                        452 00109$:
                                    453 ;	keyboards/ajazz/ak820/ak820_nvm.c:66: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003CBC 0F               [12]  454 	inc	r7
      003CBD BF 40 D6         [24]  455 	cjne	r7,#0x40,00108$
                                    456 ;	keyboards/ajazz/ak820/ak820_nvm.c:69: return true;
      003CC0 75 82 01         [24]  457 	mov	dpl, #0x01
                                    458 ;	keyboards/ajazz/ak820/ak820_nvm.c:70: }
      003CC3 22               [24]  459 	ret
                                    460 ;------------------------------------------------------------
                                    461 ;Allocation info for local variables in function 'journal_header_valid'
                                    462 ;------------------------------------------------------------
                                    463 ;header        Allocated with name '_journal_header_valid_header_10000_39'
                                    464 ;i             Allocated with name '_journal_header_valid_i_10000_40'
                                    465 ;------------------------------------------------------------
                                    466 ;	keyboards/ajazz/ak820/ak820_nvm.c:72: static bool journal_header_valid(uint8_t AK820_XDATA *header) {
                                    467 ;	-----------------------------------------
                                    468 ;	 function journal_header_valid
                                    469 ;	-----------------------------------------
      003CC4                        470 _journal_header_valid:
      003CC4 12 38 7D         [24]  471 	lcall	_ak820_outline_0103
      003CC7 90 05 6A         [24]  472 	mov	dptr,#_journal_header_valid_header_10000_39
      003CCA 12 38 82         [24]  473 	lcall	_ak820_outline_0104
                                    474 ;	keyboards/ajazz/ak820/ak820_nvm.c:74: if (header[0] != 0xA5u) return false;
      003CCD 90 05 6A         [24]  475 	mov	dptr,#_journal_header_valid_header_10000_39
      003CD0 12 37 F5         [24]  476 	lcall	_ak820_outline_0005
      003CD3 E0               [24]  477 	movx	a,@dptr
      003CD4 FD               [12]  478 	mov	r5,a
      003CD5 BD A5 02         [24]  479 	cjne	r5,#0xa5,00138$
      003CD8 80 04            [24]  480 	sjmp	00116$
      003CDA                        481 00138$:
      003CDA 75 82 00         [24]  482 	mov	dpl, #0x00
                                    483 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003CDD 22               [24]  484 	ret
      003CDE                        485 00116$:
      003CDE 7D 01            [12]  486 	mov	r5,#0x01
      003CE0                        487 00106$:
                                    488 ;	keyboards/ajazz/ak820/ak820_nvm.c:76: if ((uint8_t)(header[i] ^ header[i + 4]) != 0xFFu) return false;
      003CE0 ED               [12]  489 	mov	a,r5
      003CE1 12 38 32         [24]  490 	lcall	_ak820_outline_0020
      003CE4 E0               [24]  491 	movx	a,@dptr
      003CE5 FC               [12]  492 	mov	r4,a
      003CE6 8D 02            [24]  493 	mov	ar2,r5
      003CE8 7B 00            [12]  494 	mov	r3,#0x00
      003CEA 74 04            [12]  495 	mov	a,#0x04
      003CEC 2A               [12]  496 	add	a, r2
      003CED FA               [12]  497 	mov	r2,a
      003CEE E4               [12]  498 	clr	a
      003CEF 3B               [12]  499 	addc	a, r3
      003CF0 FB               [12]  500 	mov	r3,a
      003CF1 EA               [12]  501 	mov	a,r2
      003CF2 2E               [12]  502 	add	a, r6
      003CF3 F5 82            [12]  503 	mov	dpl,a
      003CF5 EB               [12]  504 	mov	a,r3
      003CF6 3F               [12]  505 	addc	a, r7
      003CF7 F5 83            [12]  506 	mov	dph,a
      003CF9 E0               [24]  507 	movx	a,@dptr
      003CFA 62 04            [12]  508 	xrl	ar4,a
      003CFC BC FF 02         [24]  509 	cjne	r4,#0xff,00139$
      003CFF 80 04            [24]  510 	sjmp	00107$
      003D01                        511 00139$:
      003D01 75 82 00         [24]  512 	mov	dpl, #0x00
      003D04 22               [24]  513 	ret
      003D05                        514 00107$:
                                    515 ;	keyboards/ajazz/ak820/ak820_nvm.c:75: for (i = 1; i != 5; ++i) {
      003D05 0D               [12]  516 	inc	r5
      003D06 BD 05 D7         [24]  517 	cjne	r5,#0x05,00106$
                                    518 ;	keyboards/ajazz/ak820/ak820_nvm.c:78: return true;
      003D09 75 82 01         [24]  519 	mov	dpl, #0x01
                                    520 ;	keyboards/ajazz/ak820/ak820_nvm.c:79: }
      003D0C 22               [24]  521 	ret
                                    522 ;------------------------------------------------------------
                                    523 ;Allocation info for local variables in function 'recover_journal'
                                    524 ;------------------------------------------------------------
                                    525 ;header        Allocated with name '_recover_journal_header_10000_46'
                                    526 ;i             Allocated with name '_recover_journal_i_10000_46'
                                    527 ;page          Allocated with name '_recover_journal_page_10000_46'
                                    528 ;crc           Allocated with name '_recover_journal_crc_10000_46'
                                    529 ;------------------------------------------------------------
                                    530 ;	keyboards/ajazz/ak820/ak820_nvm.c:81: static void recover_journal(void) {
                                    531 ;	-----------------------------------------
                                    532 ;	 function recover_journal
                                    533 ;	-----------------------------------------
      003D0D                        534 _recover_journal:
                                    535 ;	keyboards/ajazz/ak820/ak820_nvm.c:85: for (i = 0; i != sizeof(header); ++i) header[i] = ak820_flash_read(AK820_JOURNAL_HEADER + i);
      003D0D 7F 00            [12]  536 	mov	r7,#0x00
      003D0F                        537 00115$:
      003D0F EF               [12]  538 	mov	a,r7
      003D10 24 6C            [12]  539 	add	a, #_recover_journal_header_10000_46
      003D12 FD               [12]  540 	mov	r5,a
      003D13 E4               [12]  541 	clr	a
      003D14 34 05            [12]  542 	addc	a, #(_recover_journal_header_10000_46 >> 8)
      003D16 FE               [12]  543 	mov	r6,a
      003D17 8F 04            [24]  544 	mov	ar4,r7
      003D19 7B 00            [12]  545 	mov	r3,#0x00
      003D1B 74 40            [12]  546 	mov	a,#0x40
      003D1D 2C               [12]  547 	add	a, r4
      003D1E FC               [12]  548 	mov	r4,a
      003D1F 74 EF            [12]  549 	mov	a,#0xef
      003D21 3B               [12]  550 	addc	a, r3
      003D22 FB               [12]  551 	mov	r3,a
      003D23 12 43 82         [24]  552 	lcall	_ak820_outline_0177
      003D26 12 38 EA         [24]  553 	lcall	_ak820_flash_read
      003D29 AC 82            [24]  554 	mov	r4, dpl
      003D2B 12 38 9C         [24]  555 	lcall	_ak820_outline_0128
      003D2E EC               [12]  556 	mov	a,r4
      003D2F F0               [24]  557 	movx	@dptr,a
      003D30 0F               [12]  558 	inc	r7
      003D31 BF 09 DB         [24]  559 	cjne	r7,#0x09,00115$
                                    560 ;	keyboards/ajazz/ak820/ak820_nvm.c:88: if (!journal_header_valid(header)) return;
      003D34 90 05 6C         [24]  561 	mov	dptr,#_recover_journal_header_10000_46
      003D37 12 3C C4         [24]  562 	lcall	_journal_header_valid
      003D3A E5 82            [12]  563 	mov	a, dpl
      003D3C 70 01            [24]  564 	jnz	00103$
      003D3E 22               [24]  565 	ret
      003D3F                        566 00103$:
                                    567 ;	keyboards/ajazz/ak820/ak820_nvm.c:89: page = (uint16_t)header[1] | ((uint16_t)header[2] << 8);
      003D3F 90 05 6D         [24]  568 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0001)
      003D42 E0               [24]  569 	movx	a,@dptr
      003D43 FF               [12]  570 	mov	r7,a
      003D44 7E 00            [12]  571 	mov	r6,#0x00
      003D46 90 05 6E         [24]  572 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0002)
      003D49 E0               [24]  573 	movx	a,@dptr
      003D4A FC               [12]  574 	mov	r4,a
      003D4B E4               [12]  575 	clr	a
      003D4C 42 07            [12]  576 	orl	ar7,a
      003D4E EC               [12]  577 	mov	a,r4
      003D4F 42 06            [12]  578 	orl	ar6,a
                                    579 ;	keyboards/ajazz/ak820/ak820_nvm.c:90: crc = (uint16_t)header[3] | ((uint16_t)header[4] << 8);
      003D51 90 05 6F         [24]  580 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0003)
      003D54 E0               [24]  581 	movx	a,@dptr
      003D55 FD               [12]  582 	mov	r5,a
      003D56 7C 00            [12]  583 	mov	r4,#0x00
      003D58 90 05 70         [24]  584 	mov	dptr,#(_recover_journal_header_10000_46 + 0x0004)
      003D5B E0               [24]  585 	movx	a,@dptr
      003D5C FA               [12]  586 	mov	r2,a
      003D5D E4               [12]  587 	clr	a
      003D5E 12 43 61         [24]  588 	lcall	_ak820_outline_0136
                                    589 ;	keyboards/ajazz/ak820/ak820_nvm.c:91: if (page >= AK820_NVM_SIZE / AK820_FLASH_PAGE) {
      003D61 C3               [12]  590 	clr	c
      003D62 EF               [12]  591 	mov	a,r7
      003D63 94 A0            [12]  592 	subb	a,#0xa0
      003D65 EE               [12]  593 	mov	a,r6
      003D66 94 00            [12]  594 	subb	a,#0x00
      003D68 40 06            [24]  595 	jc	00134$
                                    596 ;	keyboards/ajazz/ak820/ak820_nvm.c:92: nvm_fail(AK820_NVM_FAULT_RECOVERY_PAGE);
      003D6A 75 82 01         [24]  597 	mov	dpl, #0x01
                                    598 ;	keyboards/ajazz/ak820/ak820_nvm.c:93: return;
      003D6D 02 3B 7E         [24]  599 	ljmp	_nvm_fail
                                    600 ;	keyboards/ajazz/ak820/ak820_nvm.c:95: for (i = 0; i != AK820_FLASH_PAGE; ++i) page_data[i] = ak820_flash_read(AK820_JOURNAL_DATA + i);
      003D70                        601 00134$:
      003D70 7B 00            [12]  602 	mov	r3,#0x00
      003D72                        603 00117$:
      003D72 C0 05            [24]  604 	push	ar5
      003D74 C0 04            [24]  605 	push	ar4
      003D76 EB               [12]  606 	mov	a,r3
      003D77 24 1D            [12]  607 	add	a, #_page_data
      003D79 F9               [12]  608 	mov	r1,a
      003D7A E4               [12]  609 	clr	a
      003D7B 34 05            [12]  610 	addc	a, #(_page_data >> 8)
      003D7D FA               [12]  611 	mov	r2,a
      003D7E 8B 00            [24]  612 	mov	ar0,r3
      003D80 7D 00            [12]  613 	mov	r5,#0x00
      003D82 74 EF            [12]  614 	mov	a,#0xef
      003D84 2D               [12]  615 	add	a, r5
      003D85 FD               [12]  616 	mov	r5,a
      003D86 88 82            [24]  617 	mov	dpl, r0
      003D88 8D 83            [24]  618 	mov	dph, r5
      003D8A 12 38 EA         [24]  619 	lcall	_ak820_flash_read
      003D8D AD 82            [24]  620 	mov	r5, dpl
      003D8F 12 43 7D         [24]  621 	lcall	_ak820_outline_0176
      003D92 ED               [12]  622 	mov	a,r5
      003D93 F0               [24]  623 	movx	@dptr,a
      003D94 0B               [12]  624 	inc	r3
      003D95 BB 40 02         [24]  625 	cjne	r3,#0x40,00190$
      003D98 80 06            [24]  626 	sjmp	00191$
      003D9A                        627 00190$:
      003D9A D0 04            [24]  628 	pop	ar4
      003D9C D0 05            [24]  629 	pop	ar5
      003D9E 80 D2            [24]  630 	sjmp	00117$
      003DA0                        631 00191$:
      003DA0 D0 04            [24]  632 	pop	ar4
      003DA2 D0 05            [24]  633 	pop	ar5
                                    634 ;	keyboards/ajazz/ak820/ak820_nvm.c:96: if (page_crc() != crc) nvm_fail(AK820_NVM_FAULT_RECOVERY_CRC);
      003DA4 C0 07            [24]  635 	push	ar7
      003DA6 C0 06            [24]  636 	push	ar6
      003DA8 C0 05            [24]  637 	push	ar5
      003DAA C0 04            [24]  638 	push	ar4
      003DAC 12 3C 2A         [24]  639 	lcall	_page_crc
      003DAF AA 82            [24]  640 	mov	r2, dpl
      003DB1 AB 83            [24]  641 	mov	r3, dph
      003DB3 D0 04            [24]  642 	pop	ar4
      003DB5 D0 05            [24]  643 	pop	ar5
      003DB7 D0 06            [24]  644 	pop	ar6
      003DB9 D0 07            [24]  645 	pop	ar7
      003DBB EA               [12]  646 	mov	a,r2
      003DBC B5 05 06         [24]  647 	cjne	a,ar5,00192$
      003DBF EB               [12]  648 	mov	a,r3
      003DC0 B5 04 02         [24]  649 	cjne	a,ar4,00192$
      003DC3 80 06            [24]  650 	sjmp	00113$
      003DC5                        651 00192$:
      003DC5 75 82 02         [24]  652 	mov	dpl, #0x02
      003DC8 02 3B 7E         [24]  653 	ljmp	_nvm_fail
      003DCB                        654 00113$:
                                    655 ;	keyboards/ajazz/ak820/ak820_nvm.c:97: else if (!write_page(AK820_NVM_BASE + page * AK820_FLASH_PAGE)) nvm_fail(AK820_NVM_FAULT_RECOVERY_WRITE);
      003DCB EE               [12]  656 	mov	a,r6
      003DCC 54 03            [12]  657 	anl	a,#0x03
      003DCE A2 E0            [12]  658 	mov	c,acc.0
      003DD0 CF               [12]  659 	xch	a,r7
      003DD1 13               [12]  660 	rrc	a
      003DD2 CF               [12]  661 	xch	a,r7
      003DD3 13               [12]  662 	rrc	a
      003DD4 A2 E0            [12]  663 	mov	c,acc.0
      003DD6 CF               [12]  664 	xch	a,r7
      003DD7 13               [12]  665 	rrc	a
      003DD8 CF               [12]  666 	xch	a,r7
      003DD9 13               [12]  667 	rrc	a
      003DDA CF               [12]  668 	xch	a,r7
      003DDB 24 C7            [12]  669 	add	a,#0xc7
      003DDD FE               [12]  670 	mov	r6,a
      003DDE 12 43 6C         [24]  671 	lcall	_ak820_outline_0151
      003DE1 12 3C 5D         [24]  672 	lcall	_write_page
      003DE4 E5 82            [12]  673 	mov	a, dpl
      003DE6 70 06            [24]  674 	jnz	00110$
      003DE8 75 82 03         [24]  675 	mov	dpl, #0x03
      003DEB 02 3B 7E         [24]  676 	ljmp	_nvm_fail
      003DEE                        677 00110$:
                                    678 ;	keyboards/ajazz/ak820/ak820_nvm.c:98: else if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) nvm_fail(AK820_NVM_FAULT_RECOVERY_CLEANUP);
      003DEE 90 EF 40         [24]  679 	mov	dptr,#0xef40
      003DF1 12 39 F7         [24]  680 	lcall	_ak820_flash_erase
      003DF4 E5 82            [12]  681 	mov	a, dpl
      003DF6 70 06            [24]  682 	jnz	00119$
      003DF8 75 82 04         [24]  683 	mov	dpl, #0x04
                                    684 ;	keyboards/ajazz/ak820/ak820_nvm.c:99: }
      003DFB 02 3B 7E         [24]  685 	ljmp	_nvm_fail
      003DFE                        686 00119$:
      003DFE 22               [24]  687 	ret
                                    688 ;------------------------------------------------------------
                                    689 ;Allocation info for local variables in function 'eeprom_driver_init'
                                    690 ;------------------------------------------------------------
                                    691 ;	keyboards/ajazz/ak820/ak820_nvm.c:101: void eeprom_driver_init(void) {
                                    692 ;	-----------------------------------------
                                    693 ;	 function eeprom_driver_init
                                    694 ;	-----------------------------------------
      003DFF                        695 _eeprom_driver_init:
                                    696 ;	keyboards/ajazz/ak820/ak820_nvm.c:102: storage_failed = false;
                                    697 ;	assignBit
      003DFF C2 0B            [12]  698 	clr	_storage_failed
                                    699 ;	keyboards/ajazz/ak820/ak820_nvm.c:103: first_failure_stage = AK820_NVM_FAULT_NONE;
      003E01 90 05 5F         [24]  700 	mov	dptr,#_first_failure_stage
      003E04 E4               [12]  701 	clr	a
      003E05 F0               [24]  702 	movx	@dptr,a
                                    703 ;	keyboards/ajazz/ak820/ak820_nvm.c:104: page_valid = page_dirty = false;
                                    704 ;	assignBit
      003E06 C2 0A            [12]  705 	clr	_page_dirty
                                    706 ;	assignBit
      003E08 C2 09            [12]  707 	clr	_page_valid
                                    708 ;	keyboards/ajazz/ak820/ak820_nvm.c:105: batch_depth = 0;
      003E0A 90 05 5E         [24]  709 	mov	dptr,#_batch_depth
      003E0D E4               [12]  710 	clr	a
      003E0E F0               [24]  711 	movx	@dptr,a
                                    712 ;	keyboards/ajazz/ak820/ak820_nvm.c:106: recover_journal();
      003E0F 12 3D 0D         [24]  713 	lcall	_recover_journal
                                    714 ;	keyboards/ajazz/ak820/ak820_nvm.c:108: ak820_macro_init();
                                    715 ;	keyboards/ajazz/ak820/ak820_nvm.c:110: }
      003E12 02 2A B7         [24]  716 	ljmp	_ak820_macro_init
                                    717 ;------------------------------------------------------------
                                    718 ;Allocation info for local variables in function 'ak820_nvm_ok'
                                    719 ;------------------------------------------------------------
                                    720 ;	keyboards/ajazz/ak820/ak820_nvm.c:112: bool ak820_nvm_ok(void) { return !storage_failed; }
                                    721 ;	-----------------------------------------
                                    722 ;	 function ak820_nvm_ok
                                    723 ;	-----------------------------------------
      003E15                        724 _ak820_nvm_ok:
      003E15 A2 0B            [12]  725 	mov	c,_storage_failed
      003E17 B3               [12]  726 	cpl	c
      003E18 92 0C            [24]  727 	mov  _ak820_nvm_ok_sloc0_1_0,c
      003E1A 12 38 B1         [24]  728 	lcall	_ak820_outline_0150
      003E1D 22               [24]  729 	ret
                                    730 ;------------------------------------------------------------
                                    731 ;Allocation info for local variables in function 'ak820_nvm_schema_fault'
                                    732 ;------------------------------------------------------------
                                    733 ;	keyboards/ajazz/ak820/ak820_nvm.c:114: void ak820_nvm_schema_fault(void) { nvm_fail(AK820_NVM_FAULT_SCHEMA); }
                                    734 ;	-----------------------------------------
                                    735 ;	 function ak820_nvm_schema_fault
                                    736 ;	-----------------------------------------
      003E1E                        737 _ak820_nvm_schema_fault:
      003E1E 75 82 10         [24]  738 	mov	dpl, #0x10
      003E21 02 3B 7E         [24]  739 	ljmp	_nvm_fail
                                    740 ;------------------------------------------------------------
                                    741 ;Allocation info for local variables in function 'ak820_nvm_flush'
                                    742 ;------------------------------------------------------------
                                    743 ;header        Allocated with name '_ak820_nvm_flush_header_10000_62'
                                    744 ;crc           Allocated with name '_ak820_nvm_flush_crc_10000_62'
                                    745 ;i             Allocated with name '_ak820_nvm_flush_i_10000_62'
                                    746 ;stage         Allocated with name '_ak820_nvm_flush_stage_10000_62'
                                    747 ;------------------------------------------------------------
                                    748 ;	keyboards/ajazz/ak820/ak820_nvm.c:116: void ak820_nvm_flush(void) {
                                    749 ;	-----------------------------------------
                                    750 ;	 function ak820_nvm_flush
                                    751 ;	-----------------------------------------
      003E24                        752 _ak820_nvm_flush:
                                    753 ;	keyboards/ajazz/ak820/ak820_nvm.c:121: if (!page_dirty || storage_failed) return;
      003E24 30 0A 03         [24]  754 	jnb	_page_dirty,00101$
      003E27 30 0B 01         [24]  755 	jnb	_storage_failed,00102$
      003E2A                        756 00101$:
      003E2A 22               [24]  757 	ret
      003E2B                        758 00102$:
                                    759 ;	keyboards/ajazz/ak820/ak820_nvm.c:122: crc = page_crc();
      003E2B 12 3C 2A         [24]  760 	lcall	_page_crc
      003E2E 12 43 56         [24]  761 	lcall	_ak820_outline_0129
                                    762 ;	keyboards/ajazz/ak820/ak820_nvm.c:123: header[0] = 0xA5u;
      003E31 90 05 75         [24]  763 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003E34 74 A5            [12]  764 	mov	a,#0xa5
      003E36 F0               [24]  765 	movx	@dptr,a
                                    766 ;	keyboards/ajazz/ak820/ak820_nvm.c:124: header[1] = (uint8_t)cached_page;
      003E37 90 05 5D         [24]  767 	mov	dptr,#_cached_page
      003E3A E0               [24]  768 	movx	a,@dptr
      003E3B 90 05 76         [24]  769 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0001)
      003E3E F0               [24]  770 	movx	@dptr,a
                                    771 ;	keyboards/ajazz/ak820/ak820_nvm.c:125: header[2] = (uint8_t)(cached_page >> 8);
      003E3F 90 05 77         [24]  772 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0002)
      003E42 E4               [12]  773 	clr	a
      003E43 F0               [24]  774 	movx	@dptr,a
                                    775 ;	keyboards/ajazz/ak820/ak820_nvm.c:126: header[3] = (uint8_t)crc;
      003E44 8E 05            [24]  776 	mov	ar5,r6
      003E46 90 05 78         [24]  777 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0003)
      003E49 ED               [12]  778 	mov	a,r5
      003E4A F0               [24]  779 	movx	@dptr,a
                                    780 ;	keyboards/ajazz/ak820/ak820_nvm.c:127: header[4] = (uint8_t)(crc >> 8);
      003E4B 8F 06            [24]  781 	mov	ar6,r7
      003E4D 90 05 79         [24]  782 	mov	dptr,#(_ak820_nvm_flush_header_10000_62 + 0x0004)
      003E50 EE               [12]  783 	mov	a,r6
      003E51 F0               [24]  784 	movx	@dptr,a
                                    785 ;	keyboards/ajazz/ak820/ak820_nvm.c:128: for (i = 1; i != 5; ++i) header[i + 4] = (uint8_t)~header[i];
      003E52 7F 01            [12]  786 	mov	r7,#0x01
      003E54                        787 00128$:
      003E54 8F 06            [24]  788 	mov	ar6,r7
      003E56 EE               [12]  789 	mov	a,r6
      003E57 24 04            [12]  790 	add	a,#0x04
      003E59 FE               [12]  791 	mov	r6,a
      003E5A 33               [12]  792 	rlc	a
      003E5B 95 E0            [12]  793 	subb	a,acc
      003E5D FD               [12]  794 	mov	r5,a
      003E5E EE               [12]  795 	mov	a,r6
      003E5F 24 75            [12]  796 	add	a, #_ak820_nvm_flush_header_10000_62
      003E61 FE               [12]  797 	mov	r6,a
      003E62 ED               [12]  798 	mov	a,r5
      003E63 34 05            [12]  799 	addc	a, #(_ak820_nvm_flush_header_10000_62 >> 8)
      003E65 FD               [12]  800 	mov	r5,a
      003E66 12 43 15         [24]  801 	lcall	_ak820_outline_0042
      003E69 FC               [12]  802 	mov	r4,a
      003E6A 63 04 FF         [24]  803 	xrl	ar4,#0xff
      003E6D 8E 82            [24]  804 	mov	dpl,r6
      003E6F 8D 83            [24]  805 	mov	dph,r5
      003E71 EC               [12]  806 	mov	a,r4
      003E72 F0               [24]  807 	movx	@dptr,a
      003E73 0F               [12]  808 	inc	r7
      003E74 BF 05 DD         [24]  809 	cjne	r7,#0x05,00128$
                                    810 ;	keyboards/ajazz/ak820/ak820_nvm.c:131: stage = AK820_NVM_FAULT_HEADER_ERASE;
      003E77 90 05 7E         [24]  811 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E7A 74 05            [12]  812 	mov	a,#0x05
      003E7C F0               [24]  813 	movx	@dptr,a
                                    814 ;	keyboards/ajazz/ak820/ak820_nvm.c:132: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003E7D 90 EF 40         [24]  815 	mov	dptr,#0xef40
      003E80 12 39 F7         [24]  816 	lcall	_ak820_flash_erase
      003E83 E5 82            [12]  817 	mov	a, dpl
      003E85 70 03            [24]  818 	jnz	00269$
      003E87 02 3F 6E         [24]  819 	ljmp	00127$
      003E8A                        820 00269$:
                                    821 ;	keyboards/ajazz/ak820/ak820_nvm.c:133: stage = AK820_NVM_FAULT_HEADER_ZERO;
      003E8A 90 05 7E         [24]  822 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003E8D 74 06            [12]  823 	mov	a,#0x06
      003E8F F0               [24]  824 	movx	@dptr,a
                                    825 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E90 7F 00            [12]  826 	mov	r7,#0x00
      003E92                        827 00130$:
                                    828 ;	keyboards/ajazz/ak820/ak820_nvm.c:135: if (ak820_flash_read(AK820_JOURNAL_HEADER + i)) goto failed;
      003E92 12 43 21         [24]  829 	lcall	_ak820_outline_0052
      003E95 12 38 EA         [24]  830 	lcall	_ak820_flash_read
      003E98 E5 82            [12]  831 	mov	a, dpl
      003E9A 60 03            [24]  832 	jz	00270$
      003E9C 02 3F 6E         [24]  833 	ljmp	00127$
      003E9F                        834 00270$:
                                    835 ;	keyboards/ajazz/ak820/ak820_nvm.c:134: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003E9F 0F               [12]  836 	inc	r7
      003EA0 BF 40 EF         [24]  837 	cjne	r7,#0x40,00130$
                                    838 ;	keyboards/ajazz/ak820/ak820_nvm.c:137: stage = AK820_NVM_FAULT_JOURNAL_WRITE;
      003EA3 90 05 7E         [24]  839 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EA6 74 07            [12]  840 	mov	a,#0x07
      003EA8 F0               [24]  841 	movx	@dptr,a
                                    842 ;	keyboards/ajazz/ak820/ak820_nvm.c:138: if (!write_page(AK820_JOURNAL_DATA)) goto failed;
      003EA9 90 EF 00         [24]  843 	mov	dptr,#0xef00
      003EAC 12 3C 5D         [24]  844 	lcall	_write_page
      003EAF E5 82            [12]  845 	mov	a, dpl
      003EB1 70 03            [24]  846 	jnz	00273$
      003EB3 02 3F 6E         [24]  847 	ljmp	00127$
      003EB6                        848 00273$:
                                    849 ;	keyboards/ajazz/ak820/ak820_nvm.c:139: stage = AK820_NVM_FAULT_METADATA_PROGRAM;
      003EB6 90 05 7E         [24]  850 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EB9 74 08            [12]  851 	mov	a,#0x08
      003EBB F0               [24]  852 	movx	@dptr,a
                                    853 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EBC 7F 01            [12]  854 	mov	r7,#0x01
      003EBE                        855 00132$:
                                    856 ;	keyboards/ajazz/ak820/ak820_nvm.c:141: if (header[i] && !ak820_flash_program(AK820_JOURNAL_HEADER + i, header[i])) goto failed;
      003EBE 12 43 15         [24]  857 	lcall	_ak820_outline_0042
      003EC1 FE               [12]  858 	mov	r6,a
      003EC2 60 23            [24]  859 	jz	00133$
      003EC4 8F 05            [24]  860 	mov	ar5,r7
      003EC6 7C 00            [12]  861 	mov	r4,#0x00
      003EC8 74 40            [12]  862 	mov	a,#0x40
      003ECA 2D               [12]  863 	add	a, r5
      003ECB FD               [12]  864 	mov	r5,a
      003ECC 74 EF            [12]  865 	mov	a,#0xef
      003ECE 3C               [12]  866 	addc	a, r4
      003ECF FC               [12]  867 	mov	r4,a
      003ED0 90 04 F6         [24]  868 	mov	dptr,#_ak820_flash_program_PARM_2
      003ED3 EE               [12]  869 	mov	a,r6
      003ED4 F0               [24]  870 	movx	@dptr,a
      003ED5 8D 82            [24]  871 	mov	dpl, r5
      003ED7 8C 83            [24]  872 	mov	dph, r4
      003ED9 C0 07            [24]  873 	push	ar7
      003EDB 12 3A 57         [24]  874 	lcall	_ak820_flash_program
      003EDE E5 82            [12]  875 	mov	a, dpl
      003EE0 D0 07            [24]  876 	pop	ar7
      003EE2 70 03            [24]  877 	jnz	00275$
      003EE4 02 3F 6E         [24]  878 	ljmp	00127$
      003EE7                        879 00275$:
      003EE7                        880 00133$:
                                    881 ;	keyboards/ajazz/ak820/ak820_nvm.c:140: for (i = 1; i != sizeof(header); ++i) {
      003EE7 0F               [12]  882 	inc	r7
      003EE8 BF 09 D3         [24]  883 	cjne	r7,#0x09,00132$
                                    884 ;	keyboards/ajazz/ak820/ak820_nvm.c:143: stage = AK820_NVM_FAULT_METADATA_READBACK;
      003EEB 90 05 7E         [24]  885 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003EEE 74 09            [12]  886 	mov	a,#0x09
      003EF0 F0               [24]  887 	movx	@dptr,a
                                    888 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003EF1 7F 01            [12]  889 	mov	r7,#0x01
      003EF3                        890 00134$:
                                    891 ;	keyboards/ajazz/ak820/ak820_nvm.c:145: if (ak820_flash_read(AK820_JOURNAL_HEADER + i) != header[i]) goto failed;
      003EF3 12 43 21         [24]  892 	lcall	_ak820_outline_0052
      003EF6 12 38 EA         [24]  893 	lcall	_ak820_flash_read
      003EF9 AE 82            [24]  894 	mov	r6, dpl
      003EFB 12 43 15         [24]  895 	lcall	_ak820_outline_0042
      003EFE FD               [12]  896 	mov	r5,a
      003EFF EE               [12]  897 	mov	a,r6
      003F00 B5 05 6B         [24]  898 	cjne	a,ar5,00127$
                                    899 ;	keyboards/ajazz/ak820/ak820_nvm.c:144: for (i = 1; i != sizeof(header); ++i) {
      003F03 0F               [12]  900 	inc	r7
      003F04 BF 09 EC         [24]  901 	cjne	r7,#0x09,00134$
                                    902 ;	keyboards/ajazz/ak820/ak820_nvm.c:148: stage = AK820_NVM_FAULT_COMMIT_PROGRAM;
      003F07 90 05 7E         [24]  903 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F0A 74 0A            [12]  904 	mov	a,#0x0a
      003F0C F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_nvm.c:149: if (!ak820_flash_program(AK820_JOURNAL_HEADER, header[0])) goto failed;
      003F0D 90 05 75         [24]  907 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F10 E0               [24]  908 	movx	a,@dptr
      003F11 90 04 F6         [24]  909 	mov	dptr,#_ak820_flash_program_PARM_2
      003F14 F0               [24]  910 	movx	@dptr,a
      003F15 90 EF 40         [24]  911 	mov	dptr,#0xef40
      003F18 12 3A 57         [24]  912 	lcall	_ak820_flash_program
      003F1B E5 82            [12]  913 	mov	a, dpl
      003F1D 60 4F            [24]  914 	jz	00127$
                                    915 ;	keyboards/ajazz/ak820/ak820_nvm.c:150: stage = AK820_NVM_FAULT_COMMIT_READBACK;
      003F1F 90 05 7E         [24]  916 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F22 74 0B            [12]  917 	mov	a,#0x0b
      003F24 F0               [24]  918 	movx	@dptr,a
                                    919 ;	keyboards/ajazz/ak820/ak820_nvm.c:151: if (ak820_flash_read(AK820_JOURNAL_HEADER) != header[0]) goto failed;
      003F25 90 EF 40         [24]  920 	mov	dptr,#0xef40
      003F28 12 38 EA         [24]  921 	lcall	_ak820_flash_read
      003F2B AF 82            [24]  922 	mov	r7, dpl
      003F2D 90 05 75         [24]  923 	mov	dptr,#_ak820_nvm_flush_header_10000_62
      003F30 E0               [24]  924 	movx	a,@dptr
      003F31 FE               [12]  925 	mov	r6,a
      003F32 EF               [12]  926 	mov	a,r7
      003F33 B5 06 38         [24]  927 	cjne	a,ar6,00127$
                                    928 ;	keyboards/ajazz/ak820/ak820_nvm.c:152: stage = AK820_NVM_FAULT_TARGET_WRITE;
      003F36 90 05 7E         [24]  929 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F39 74 0C            [12]  930 	mov	a,#0x0c
      003F3B F0               [24]  931 	movx	@dptr,a
                                    932 ;	keyboards/ajazz/ak820/ak820_nvm.c:153: if (!write_page(AK820_NVM_BASE + cached_page * AK820_FLASH_PAGE)) goto failed;
      003F3C 90 05 5D         [24]  933 	mov	dptr,#_cached_page
      003F3F E0               [24]  934 	movx	a,@dptr
      003F40 FE               [12]  935 	mov	r6,a
      003F41 E4               [12]  936 	clr	a
      003F42 C3               [12]  937 	clr	c
      003F43 CE               [12]  938 	xch	a,r6
      003F44 13               [12]  939 	rrc	a
      003F45 CE               [12]  940 	xch	a,r6
      003F46 13               [12]  941 	rrc	a
      003F47 A2 E0            [12]  942 	mov	c,acc.0
      003F49 CE               [12]  943 	xch	a,r6
      003F4A 13               [12]  944 	rrc	a
      003F4B CE               [12]  945 	xch	a,r6
      003F4C 13               [12]  946 	rrc	a
      003F4D CE               [12]  947 	xch	a,r6
      003F4E 24 C7            [12]  948 	add	a,#0xc7
      003F50 FF               [12]  949 	mov	r7,a
      003F51 12 38 87         [24]  950 	lcall	_ak820_outline_0112
      003F54 12 3C 5D         [24]  951 	lcall	_write_page
      003F57 E5 82            [12]  952 	mov	a, dpl
      003F59 60 13            [24]  953 	jz	00127$
                                    954 ;	keyboards/ajazz/ak820/ak820_nvm.c:154: stage = AK820_NVM_FAULT_CLEANUP;
      003F5B 90 05 7E         [24]  955 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F5E 74 0D            [12]  956 	mov	a,#0x0d
      003F60 F0               [24]  957 	movx	@dptr,a
                                    958 ;	keyboards/ajazz/ak820/ak820_nvm.c:155: if (!ak820_flash_erase(AK820_JOURNAL_HEADER)) goto failed;
      003F61 90 EF 40         [24]  959 	mov	dptr,#0xef40
      003F64 12 39 F7         [24]  960 	lcall	_ak820_flash_erase
      003F67 E5 82            [12]  961 	mov	a, dpl
      003F69 60 03            [24]  962 	jz	00127$
                                    963 ;	keyboards/ajazz/ak820/ak820_nvm.c:156: page_dirty = false;
                                    964 ;	assignBit
      003F6B C2 0A            [12]  965 	clr	_page_dirty
                                    966 ;	keyboards/ajazz/ak820/ak820_nvm.c:157: return;
                                    967 ;	keyboards/ajazz/ak820/ak820_nvm.c:158: failed:
      003F6D 22               [24]  968 	ret
      003F6E                        969 00127$:
                                    970 ;	keyboards/ajazz/ak820/ak820_nvm.c:159: nvm_fail(stage);
      003F6E 90 05 7E         [24]  971 	mov	dptr,#_ak820_nvm_flush_stage_10000_62
      003F71 E0               [24]  972 	movx	a,@dptr
      003F72 F5 82            [12]  973 	mov	dpl,a
                                    974 ;	keyboards/ajazz/ak820/ak820_nvm.c:160: }
      003F74 02 3B 7E         [24]  975 	ljmp	_nvm_fail
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'ak820_nvm_begin'
                                    978 ;------------------------------------------------------------
                                    979 ;	keyboards/ajazz/ak820/ak820_nvm.c:162: void ak820_nvm_begin(void) {
                                    980 ;	-----------------------------------------
                                    981 ;	 function ak820_nvm_begin
                                    982 ;	-----------------------------------------
      003F77                        983 _ak820_nvm_begin:
                                    984 ;	keyboards/ajazz/ak820/ak820_nvm.c:163: if (batch_depth == 255u) nvm_fail(AK820_NVM_FAULT_BATCH_OVERFLOW);
      003F77 90 05 5E         [24]  985 	mov	dptr,#_batch_depth
      003F7A E0               [24]  986 	movx	a,@dptr
      003F7B FF               [12]  987 	mov	r7,a
      003F7C BF FF 06         [24]  988 	cjne	r7,#0xff,00102$
      003F7F 75 82 0F         [24]  989 	mov	dpl, #0x0f
      003F82 02 3B 7E         [24]  990 	ljmp	_nvm_fail
      003F85                        991 00102$:
                                    992 ;	keyboards/ajazz/ak820/ak820_nvm.c:164: else ++batch_depth;
      003F85 90 05 5E         [24]  993 	mov	dptr,#_batch_depth
      003F88 EF               [12]  994 	mov	a,r7
      003F89 04               [12]  995 	inc	a
      003F8A F0               [24]  996 	movx	@dptr,a
                                    997 ;	keyboards/ajazz/ak820/ak820_nvm.c:165: }
      003F8B 22               [24]  998 	ret
                                    999 ;------------------------------------------------------------
                                   1000 ;Allocation info for local variables in function 'ak820_nvm_end'
                                   1001 ;------------------------------------------------------------
                                   1002 ;	keyboards/ajazz/ak820/ak820_nvm.c:167: void ak820_nvm_end(void) {
                                   1003 ;	-----------------------------------------
                                   1004 ;	 function ak820_nvm_end
                                   1005 ;	-----------------------------------------
      003F8C                       1006 _ak820_nvm_end:
                                   1007 ;	keyboards/ajazz/ak820/ak820_nvm.c:168: if (batch_depth) --batch_depth;
      003F8C 90 05 5E         [24] 1008 	mov	dptr,#_batch_depth
      003F8F E0               [24] 1009 	movx	a,@dptr
      003F90 FF               [12] 1010 	mov	r7,a
      003F91 E0               [24] 1011 	movx	a,@dptr
      003F92 60 06            [24] 1012 	jz	00102$
      003F94 EF               [12] 1013 	mov	a,r7
      003F95 14               [12] 1014 	dec	a
      003F96 90 05 5E         [24] 1015 	mov	dptr,#_batch_depth
      003F99 F0               [24] 1016 	movx	@dptr,a
      003F9A                       1017 00102$:
                                   1018 ;	keyboards/ajazz/ak820/ak820_nvm.c:169: if (!batch_depth) ak820_nvm_flush();
      003F9A 90 05 5E         [24] 1019 	mov	dptr,#_batch_depth
      003F9D E0               [24] 1020 	movx	a,@dptr
      003F9E 70 03            [24] 1021 	jnz	00105$
                                   1022 ;	keyboards/ajazz/ak820/ak820_nvm.c:170: }
      003FA0 02 3E 24         [24] 1023 	ljmp	_ak820_nvm_flush
      003FA3                       1024 00105$:
      003FA3 22               [24] 1025 	ret
                                   1026 ;------------------------------------------------------------
                                   1027 ;Allocation info for local variables in function 'load_page'
                                   1028 ;------------------------------------------------------------
                                   1029 ;page          Allocated with name '_load_page_page_10000_87'
                                   1030 ;i             Allocated with name '_load_page_i_10000_88'
                                   1031 ;------------------------------------------------------------
                                   1032 ;	keyboards/ajazz/ak820/ak820_nvm.c:172: static bool load_page(uint8_t page) {
                                   1033 ;	-----------------------------------------
                                   1034 ;	 function load_page
                                   1035 ;	-----------------------------------------
      003FA4                       1036 _load_page:
      003FA4 E5 82            [12] 1037 	mov	a,dpl
      003FA6 90 05 7F         [24] 1038 	mov	dptr,#_load_page_page_10000_87
      003FA9 F0               [24] 1039 	movx	@dptr,a
                                   1040 ;	keyboards/ajazz/ak820/ak820_nvm.c:174: if (page_valid && cached_page == page) return !storage_failed;
      003FAA 30 09 17         [24] 1041 	jnb	_page_valid,00102$
      003FAD 90 05 5D         [24] 1042 	mov	dptr,#_cached_page
      003FB0 E0               [24] 1043 	movx	a,@dptr
      003FB1 FF               [12] 1044 	mov	r7,a
      003FB2 90 05 7F         [24] 1045 	mov	dptr,#_load_page_page_10000_87
      003FB5 E0               [24] 1046 	movx	a,@dptr
      003FB6 FE               [12] 1047 	mov	r6,a
      003FB7 EF               [12] 1048 	mov	a,r7
      003FB8 B5 06 09         [24] 1049 	cjne	a,ar6,00102$
      003FBB A2 0B            [12] 1050 	mov	c,_storage_failed
      003FBD B3               [12] 1051 	cpl	c
      003FBE 92 0D            [24] 1052 	mov  _load_page_sloc0_1_0,c
      003FC0 12 38 B1         [24] 1053 	lcall	_ak820_outline_0150
      003FC3 22               [24] 1054 	ret
      003FC4                       1055 00102$:
                                   1056 ;	keyboards/ajazz/ak820/ak820_nvm.c:175: ak820_nvm_flush();
      003FC4 12 3E 24         [24] 1057 	lcall	_ak820_nvm_flush
                                   1058 ;	keyboards/ajazz/ak820/ak820_nvm.c:176: if (storage_failed) return false;
      003FC7 30 0B 04         [24] 1059 	jnb	_storage_failed,00119$
      003FCA 75 82 00         [24] 1060 	mov	dpl, #0x00
                                   1061 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      003FCD 22               [24] 1062 	ret
      003FCE                       1063 00119$:
      003FCE 7F 00            [12] 1064 	mov	r7,#0x00
      003FD0                       1065 00107$:
                                   1066 ;	keyboards/ajazz/ak820/ak820_nvm.c:178: page_data[i] = ak820_flash_read(AK820_NVM_BASE + page * AK820_FLASH_PAGE + i);
      003FD0 EF               [12] 1067 	mov	a,r7
      003FD1 24 1D            [12] 1068 	add	a, #_page_data
      003FD3 FD               [12] 1069 	mov	r5,a
      003FD4 E4               [12] 1070 	clr	a
      003FD5 34 05            [12] 1071 	addc	a, #(_page_data >> 8)
      003FD7 FE               [12] 1072 	mov	r6,a
      003FD8 90 05 7F         [24] 1073 	mov	dptr,#_load_page_page_10000_87
      003FDB E0               [24] 1074 	movx	a,@dptr
      003FDC FC               [12] 1075 	mov	r4,a
      003FDD FA               [12] 1076 	mov	r2,a
      003FDE E4               [12] 1077 	clr	a
      003FDF C3               [12] 1078 	clr	c
      003FE0 CA               [12] 1079 	xch	a,r2
      003FE1 13               [12] 1080 	rrc	a
      003FE2 CA               [12] 1081 	xch	a,r2
      003FE3 13               [12] 1082 	rrc	a
      003FE4 A2 E0            [12] 1083 	mov	c,acc.0
      003FE6 CA               [12] 1084 	xch	a,r2
      003FE7 13               [12] 1085 	rrc	a
      003FE8 CA               [12] 1086 	xch	a,r2
      003FE9 13               [12] 1087 	rrc	a
      003FEA CA               [12] 1088 	xch	a,r2
      003FEB 24 C7            [12] 1089 	add	a,#0xc7
      003FED FB               [12] 1090 	mov	r3,a
      003FEE 8F 01            [24] 1091 	mov	ar1,r7
      003FF0 89 00            [24] 1092 	mov	ar0,r1
      003FF2 79 00            [12] 1093 	mov	r1,#0x00
      003FF4 E8               [12] 1094 	mov	a,r0
      003FF5 2A               [12] 1095 	add	a, r2
      003FF6 FA               [12] 1096 	mov	r2,a
      003FF7 E9               [12] 1097 	mov	a,r1
      003FF8 3B               [12] 1098 	addc	a, r3
      003FF9 FB               [12] 1099 	mov	r3,a
      003FFA 12 38 A7         [24] 1100 	lcall	_ak820_outline_0137
      003FFD 12 38 EA         [24] 1101 	lcall	_ak820_flash_read
      004000 AB 82            [24] 1102 	mov	r3, dpl
      004002 12 38 9C         [24] 1103 	lcall	_ak820_outline_0128
      004005 EB               [12] 1104 	mov	a,r3
      004006 F0               [24] 1105 	movx	@dptr,a
                                   1106 ;	keyboards/ajazz/ak820/ak820_nvm.c:177: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      004007 0F               [12] 1107 	inc	r7
      004008 BF 40 C5         [24] 1108 	cjne	r7,#0x40,00107$
                                   1109 ;	keyboards/ajazz/ak820/ak820_nvm.c:180: cached_page = page;
      00400B 90 05 5D         [24] 1110 	mov	dptr,#_cached_page
      00400E EC               [12] 1111 	mov	a,r4
      00400F F0               [24] 1112 	movx	@dptr,a
                                   1113 ;	keyboards/ajazz/ak820/ak820_nvm.c:181: page_valid = true;
                                   1114 ;	assignBit
      004010 D2 09            [12] 1115 	setb	_page_valid
                                   1116 ;	keyboards/ajazz/ak820/ak820_nvm.c:182: return true;
      004012 75 82 01         [24] 1117 	mov	dpl, #0x01
                                   1118 ;	keyboards/ajazz/ak820/ak820_nvm.c:183: }
      004015 22               [24] 1119 	ret
                                   1120 ;------------------------------------------------------------
                                   1121 ;Allocation info for local variables in function 'read_offset'
                                   1122 ;------------------------------------------------------------
                                   1123 ;offset        Allocated with name '_read_offset_offset_10000_93'
                                   1124 ;------------------------------------------------------------
                                   1125 ;	keyboards/ajazz/ak820/ak820_nvm.c:185: static uint8_t read_offset(uint16_t offset) {
                                   1126 ;	-----------------------------------------
                                   1127 ;	 function read_offset
                                   1128 ;	-----------------------------------------
      004016                       1129 _read_offset:
      004016 12 38 7D         [24] 1130 	lcall	_ak820_outline_0103
      004019 90 05 80         [24] 1131 	mov	dptr,#_read_offset_offset_10000_93
      00401C 12 38 82         [24] 1132 	lcall	_ak820_outline_0104
                                   1133 ;	keyboards/ajazz/ak820/ak820_nvm.c:186: if (offset >= AK820_NVM_SIZE) return 0;
      00401F 90 05 80         [24] 1134 	mov	dptr,#_read_offset_offset_10000_93
      004022 12 38 42         [24] 1135 	lcall	_ak820_outline_0051
      004025 C3               [12] 1136 	clr	c
      004026 94 28            [12] 1137 	subb	a,#0x28
      004028 40 04            [24] 1138 	jc	00102$
      00402A 75 82 00         [24] 1139 	mov	dpl, #0x00
      00402D 22               [24] 1140 	ret
      00402E                       1141 00102$:
                                   1142 ;	keyboards/ajazz/ak820/ak820_nvm.c:187: if (page_valid && (offset / AK820_FLASH_PAGE) == cached_page)
      00402E 30 09 34         [24] 1143 	jnb	_page_valid,00104$
      004031 8E 04            [24] 1144 	mov	ar4,r6
      004033 EF               [12] 1145 	mov	a,r7
      004034 A2 E7            [12] 1146 	mov	c,acc.7
      004036 CC               [12] 1147 	xch	a,r4
      004037 33               [12] 1148 	rlc	a
      004038 CC               [12] 1149 	xch	a,r4
      004039 33               [12] 1150 	rlc	a
      00403A A2 E7            [12] 1151 	mov	c,acc.7
      00403C CC               [12] 1152 	xch	a,r4
      00403D 33               [12] 1153 	rlc	a
      00403E CC               [12] 1154 	xch	a,r4
      00403F 33               [12] 1155 	rlc	a
      004040 CC               [12] 1156 	xch	a,r4
      004041 54 03            [12] 1157 	anl	a,#0x03
      004043 FD               [12] 1158 	mov	r5,a
      004044 90 05 5D         [24] 1159 	mov	dptr,#_cached_page
      004047 E0               [24] 1160 	movx	a,@dptr
      004048 FA               [12] 1161 	mov	r2,a
      004049 7B 00            [12] 1162 	mov	r3,#0x00
      00404B EC               [12] 1163 	mov	a,r4
      00404C B5 02 16         [24] 1164 	cjne	a,ar2,00104$
      00404F ED               [12] 1165 	mov	a,r5
      004050 B5 03 12         [24] 1166 	cjne	a,ar3,00104$
                                   1167 ;	keyboards/ajazz/ak820/ak820_nvm.c:188: return page_data[offset % AK820_FLASH_PAGE];
      004053 74 3F            [12] 1168 	mov	a,#0x3f
      004055 5E               [12] 1169 	anl	a,r6
      004056 7D 00            [12] 1170 	mov	r5,#0x00
      004058 24 1D            [12] 1171 	add	a, #_page_data
      00405A F5 82            [12] 1172 	mov	dpl,a
      00405C ED               [12] 1173 	mov	a,r5
      00405D 34 05            [12] 1174 	addc	a, #(_page_data >> 8)
      00405F F5 83            [12] 1175 	mov	dph,a
      004061 E0               [24] 1176 	movx	a,@dptr
      004062 F5 82            [12] 1177 	mov	dpl,a
      004064 22               [24] 1178 	ret
      004065                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_nvm.c:189: return ak820_flash_read(AK820_NVM_BASE + offset);
      004065 74 C7            [12] 1181 	mov	a,#0xc7
      004067 2F               [12] 1182 	add	a, r7
      004068 FF               [12] 1183 	mov	r7,a
      004069 12 38 87         [24] 1184 	lcall	_ak820_outline_0112
                                   1185 ;	keyboards/ajazz/ak820/ak820_nvm.c:190: }
      00406C 02 38 EA         [24] 1186 	ljmp	_ak820_flash_read
                                   1187 ;------------------------------------------------------------
                                   1188 ;Allocation info for local variables in function 'eeprom_read_byte'
                                   1189 ;------------------------------------------------------------
                                   1190 ;addr          Allocated with name '_eeprom_read_byte_addr_10000_97'
                                   1191 ;------------------------------------------------------------
                                   1192 ;	keyboards/ajazz/ak820/ak820_nvm.c:193: uint8_t eeprom_read_byte(const uint8_t *addr) {
                                   1193 ;	-----------------------------------------
                                   1194 ;	 function eeprom_read_byte
                                   1195 ;	-----------------------------------------
      00406F                       1196 _eeprom_read_byte:
      00406F C0 07            [24] 1197 	push	ar7
      004071 C0 06            [24] 1198 	push	ar6
      004073 12 43 0E         [24] 1199 	lcall	_ak820_outline_0036
      004076 90 05 82         [24] 1200 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      004079 12 38 2A         [24] 1201 	lcall	_ak820_outline_0016
                                   1202 ;	keyboards/ajazz/ak820/ak820_nvm.c:194: return read_offset((uint16_t)(uintptr_t)addr);
      00407C 90 05 82         [24] 1203 	mov	dptr,#_eeprom_read_byte_addr_10000_97
      00407F 12 37 F5         [24] 1204 	lcall	_ak820_outline_0005
      004082 C0 06            [24] 1205 	push	ar6
      004084 C0 05            [24] 1206 	push	ar5
      004086 C0 04            [24] 1207 	push	ar4
      004088 C0 03            [24] 1208 	push	ar3
      00408A C0 02            [24] 1209 	push	ar2
      00408C C0 01            [24] 1210 	push	ar1
      00408E C0 00            [24] 1211 	push	ar0
      004090 12 40 16         [24] 1212 	lcall	_read_offset
      004093 AF 82            [24] 1213 	mov	r7, dpl
      004095 D0 00            [24] 1214 	pop	ar0
      004097 D0 01            [24] 1215 	pop	ar1
      004099 D0 02            [24] 1216 	pop	ar2
      00409B D0 03            [24] 1217 	pop	ar3
      00409D D0 04            [24] 1218 	pop	ar4
      00409F D0 05            [24] 1219 	pop	ar5
      0040A1 D0 06            [24] 1220 	pop	ar6
      0040A3 8F 82            [24] 1221 	mov	dpl, r7
                                   1222 ;	keyboards/ajazz/ak820/ak820_nvm.c:195: }
      0040A5 D0 06            [24] 1223 	pop	ar6
      0040A7 D0 07            [24] 1224 	pop	ar7
      0040A9 22               [24] 1225 	ret
                                   1226 ;------------------------------------------------------------
                                   1227 ;Allocation info for local variables in function 'eeprom_read_block'
                                   1228 ;------------------------------------------------------------
                                   1229 ;addr          Allocated with name '_eeprom_read_block_PARM_2'
                                   1230 ;len           Allocated with name '_eeprom_read_block_PARM_3'
                                   1231 ;buf           Allocated with name '_eeprom_read_block_buf_10000_99'
                                   1232 ;offset        Allocated with name '_eeprom_read_block_offset_10000_100'
                                   1233 ;out           Allocated with name '_eeprom_read_block_out_10000_100'
                                   1234 ;------------------------------------------------------------
                                   1235 ;	keyboards/ajazz/ak820/ak820_nvm.c:199: void eeprom_read_block(void *buf, const void *addr, size_t len) {
                                   1236 ;	-----------------------------------------
                                   1237 ;	 function ak820_eeprom_read_block_xdata
                                   1238 ;	-----------------------------------------
      0040AA                       1239 _ak820_eeprom_read_block_xdata:
      0040AA 12 38 7D         [24] 1240 	lcall	_ak820_outline_0103
      0040AD 90 05 8A         [24] 1241 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040B0 12 38 82         [24] 1242 	lcall	_ak820_outline_0104
                                   1243 ;	keyboards/ajazz/ak820/ak820_nvm.c:230: uint16_t offset = (uint16_t)(uintptr_t)addr;
      0040B3 90 05 85         [24] 1244 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      0040B6 12 38 42         [24] 1245 	lcall	_ak820_outline_0051
                                   1246 ;	keyboards/ajazz/ak820/ak820_nvm.c:231: uint8_t AK820_XDATA *out = (uint8_t AK820_XDATA *)buf;
      0040B9 90 05 8A         [24] 1247 	mov	dptr,#_ak820_eeprom_read_block_xdata_buf_10000_113
      0040BC 12 38 59         [24] 1248 	lcall	_ak820_outline_0059
      0040BF 90 05 8C         [24] 1249 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040C2 12 38 5F         [24] 1250 	lcall	_ak820_outline_0071
                                   1251 ;	keyboards/ajazz/ak820/ak820_nvm.c:232: while (len--) {
      0040C5 90 05 88         [24] 1252 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0040C8 12 38 59         [24] 1253 	lcall	_ak820_outline_0059
      0040CB                       1254 00103$:
      0040CB 8C 02            [24] 1255 	mov	ar2,r4
      0040CD 8D 03            [24] 1256 	mov	ar3,r5
      0040CF 1C               [12] 1257 	dec	r4
      0040D0 BC FF 01         [24] 1258 	cjne	r4,#0xff,00130$
      0040D3 1D               [12] 1259 	dec	r5
      0040D4                       1260 00130$:
      0040D4 EA               [12] 1261 	mov	a,r2
      0040D5 4B               [12] 1262 	orl	a,r3
      0040D6 60 5D            [24] 1263 	jz	00106$
                                   1264 ;	keyboards/ajazz/ak820/ak820_nvm.c:233: if (offset >= AK820_NVM_SIZE) { *out++ = 0; continue; }
      0040D8 8E 02            [24] 1265 	mov	ar2,r6
      0040DA 8F 03            [24] 1266 	mov	ar3,r7
      0040DC 74 D8            [12] 1267 	mov	a,#0x100 - 0x28
      0040DE 2B               [12] 1268 	add	a,r3
      0040DF 50 17            [24] 1269 	jnc	00102$
      0040E1 90 05 8C         [24] 1270 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040E4 12 43 3E         [24] 1271 	lcall	_ak820_outline_0099
      0040E7 12 38 A7         [24] 1272 	lcall	_ak820_outline_0137
      0040EA E4               [12] 1273 	clr	a
      0040EB F0               [24] 1274 	movx	@dptr,a
      0040EC 90 05 8C         [24] 1275 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040EF 04               [12] 1276 	inc	a
      0040F0 2A               [12] 1277 	add	a, r2
      0040F1 F0               [24] 1278 	movx	@dptr,a
      0040F2 E4               [12] 1279 	clr	a
      0040F3 3B               [12] 1280 	addc	a, r3
      0040F4 A3               [24] 1281 	inc	dptr
      0040F5 F0               [24] 1282 	movx	@dptr,a
      0040F6 80 D3            [24] 1283 	sjmp	00103$
      0040F8                       1284 00102$:
                                   1285 ;	keyboards/ajazz/ak820/ak820_nvm.c:234: *out++ = read_offset(offset);
      0040F8 90 05 8C         [24] 1286 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      0040FB 12 43 3E         [24] 1287 	lcall	_ak820_outline_0099
      0040FE 12 38 87         [24] 1288 	lcall	_ak820_outline_0112
      004101 C0 07            [24] 1289 	push	ar7
      004103 C0 06            [24] 1290 	push	ar6
      004105 C0 05            [24] 1291 	push	ar5
      004107 C0 04            [24] 1292 	push	ar4
      004109 C0 03            [24] 1293 	push	ar3
      00410B C0 02            [24] 1294 	push	ar2
      00410D 12 40 16         [24] 1295 	lcall	_read_offset
      004110 A9 82            [24] 1296 	mov	r1, dpl
      004112 D0 02            [24] 1297 	pop	ar2
      004114 D0 03            [24] 1298 	pop	ar3
      004116 D0 04            [24] 1299 	pop	ar4
      004118 D0 05            [24] 1300 	pop	ar5
      00411A D0 06            [24] 1301 	pop	ar6
      00411C D0 07            [24] 1302 	pop	ar7
      00411E 12 38 A7         [24] 1303 	lcall	_ak820_outline_0137
      004121 E9               [12] 1304 	mov	a,r1
      004122 F0               [24] 1305 	movx	@dptr,a
      004123 90 05 8C         [24] 1306 	mov	dptr,#_ak820_eeprom_read_block_xdata_out_10000_114
      004126 74 01            [12] 1307 	mov	a,#0x01
      004128 2A               [12] 1308 	add	a, r2
      004129 F0               [24] 1309 	movx	@dptr,a
      00412A E4               [12] 1310 	clr	a
      00412B 3B               [12] 1311 	addc	a, r3
      00412C A3               [24] 1312 	inc	dptr
      00412D F0               [24] 1313 	movx	@dptr,a
                                   1314 ;	keyboards/ajazz/ak820/ak820_nvm.c:235: ++offset;
      00412E 0E               [12] 1315 	inc	r6
      00412F BE 00 99         [24] 1316 	cjne	r6,#0x00,00103$
      004132 0F               [12] 1317 	inc	r7
      004133 80 96            [24] 1318 	sjmp	00103$
      004135                       1319 00106$:
                                   1320 ;	keyboards/ajazz/ak820/ak820_nvm.c:237: }
      004135 22               [24] 1321 	ret
                                   1322 ;------------------------------------------------------------
                                   1323 ;Allocation info for local variables in function 'ak820_eeprom_write_block_xdata'
                                   1324 ;------------------------------------------------------------
                                   1325 ;sloc0         Allocated with name '_ak820_eeprom_write_block_xdata_sloc0_1_0'
                                   1326 ;addr          Allocated with name '_ak820_eeprom_write_block_xdata_PARM_2'
                                   1327 ;len           Allocated with name '_ak820_eeprom_write_block_xdata_PARM_3'
                                   1328 ;buf           Allocated with name '_ak820_eeprom_write_block_xdata_buf_10000_118'
                                   1329 ;offset        Allocated with name '_ak820_eeprom_write_block_xdata_offset_10000_119'
                                   1330 ;in            Allocated with name '_ak820_eeprom_write_block_xdata_in_10000_119'
                                   1331 ;value         Allocated with name '_ak820_eeprom_write_block_xdata_value_20000_122'
                                   1332 ;------------------------------------------------------------
                                   1333 ;	keyboards/ajazz/ak820/ak820_nvm.c:239: void ak820_eeprom_write_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1334 ;	-----------------------------------------
                                   1335 ;	 function ak820_eeprom_write_block_xdata
                                   1336 ;	-----------------------------------------
      004136                       1337 _ak820_eeprom_write_block_xdata:
      004136 12 38 7D         [24] 1338 	lcall	_ak820_outline_0103
      004139 90 05 93         [24] 1339 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      00413C 12 38 82         [24] 1340 	lcall	_ak820_outline_0104
                                   1341 ;	keyboards/ajazz/ak820/ak820_nvm.c:240: uint16_t offset = (uint16_t)(uintptr_t)addr;
      00413F 90 05 8E         [24] 1342 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004142 12 38 42         [24] 1343 	lcall	_ak820_outline_0051
                                   1344 ;	keyboards/ajazz/ak820/ak820_nvm.c:241: const uint8_t AK820_XDATA *in = (const uint8_t AK820_XDATA *)buf;
      004145 90 05 93         [24] 1345 	mov	dptr,#_ak820_eeprom_write_block_xdata_buf_10000_118
      004148 12 38 59         [24] 1346 	lcall	_ak820_outline_0059
                                   1347 ;	keyboards/ajazz/ak820/ak820_nvm.c:243: if (offset > AK820_NVM_SIZE || len > AK820_NVM_SIZE - offset) {
      00414B 8E 02            [24] 1348 	mov	ar2,r6
      00414D 8F 03            [24] 1349 	mov	ar3,r7
      00414F C3               [12] 1350 	clr	c
      004150 E4               [12] 1351 	clr	a
      004151 9A               [12] 1352 	subb	a,r2
      004152 74 28            [12] 1353 	mov	a,#0x28
      004154 9B               [12] 1354 	subb	a,r3
      004155 40 15            [24] 1355 	jc	00101$
                                   1356 ;	free result
      004157 E4               [12] 1357 	clr	a
      004158 C3               [12] 1358 	clr	c
      004159 9E               [12] 1359 	subb	a,r6
      00415A FA               [12] 1360 	mov	r2,a
      00415B 74 28            [12] 1361 	mov	a,#0x28
      00415D 9F               [12] 1362 	subb	a,r7
      00415E FB               [12] 1363 	mov	r3,a
      00415F 90 05 91         [24] 1364 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004162 12 38 77         [24] 1365 	lcall	_ak820_outline_0098
      004165 C3               [12] 1366 	clr	c
      004166 EA               [12] 1367 	mov	a,r2
      004167 98               [12] 1368 	subb	a,r0
      004168 EB               [12] 1369 	mov	a,r3
      004169 99               [12] 1370 	subb	a,r1
      00416A 50 06            [24] 1371 	jnc	00125$
                                   1372 ;	free result
      00416C                       1373 00101$:
                                   1374 ;	keyboards/ajazz/ak820/ak820_nvm.c:244: nvm_fail(AK820_NVM_FAULT_WRITE_RANGE);
      00416C 75 82 0E         [24] 1375 	mov	dpl, #0x0e
                                   1376 ;	keyboards/ajazz/ak820/ak820_nvm.c:245: return;
      00416F 02 3B 7E         [24] 1377 	ljmp	_nvm_fail
                                   1378 ;	keyboards/ajazz/ak820/ak820_nvm.c:247: while (len--) {
      004172                       1379 00125$:
      004172 90 05 91         [24] 1380 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      004175 12 43 3E         [24] 1381 	lcall	_ak820_outline_0099
      004178                       1382 00108$:
      004178 8A 00            [24] 1383 	mov	ar0,r2
      00417A 8B 01            [24] 1384 	mov	ar1,r3
      00417C 1A               [12] 1385 	dec	r2
      00417D BA FF 01         [24] 1386 	cjne	r2,#0xff,00159$
      004180 1B               [12] 1387 	dec	r3
      004181                       1388 00159$:
      004181 E8               [12] 1389 	mov	a,r0
      004182 49               [12] 1390 	orl	a,r1
      004183 70 03            [24] 1391 	jnz	00160$
      004185 02 42 0F         [24] 1392 	ljmp	00110$
      004188                       1393 00160$:
                                   1394 ;	keyboards/ajazz/ak820/ak820_nvm.c:248: uint8_t value = *in++;
      004188 C0 02            [24] 1395 	push	ar2
      00418A C0 03            [24] 1396 	push	ar3
      00418C 12 43 38         [24] 1397 	lcall	_ak820_outline_0090
      00418F F9               [12] 1398 	mov	r1,a
      004190 A3               [24] 1399 	inc	dptr
      004191 12 43 67         [24] 1400 	lcall	_ak820_outline_0143
                                   1401 ;	keyboards/ajazz/ak820/ak820_nvm.c:249: if (!load_page(offset / AK820_FLASH_PAGE)) return;
      004194 8E 0C            [24] 1402 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,r6
      004196 8F 0D            [24] 1403 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),r7
      004198 A8 0C            [24] 1404 	mov	r0,_ak820_eeprom_write_block_xdata_sloc0_1_0
      00419A E5 0D            [12] 1405 	mov	a,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      00419C A2 E7            [12] 1406 	mov	c,acc.7
      00419E C8               [12] 1407 	xch	a,r0
      00419F 33               [12] 1408 	rlc	a
      0041A0 C8               [12] 1409 	xch	a,r0
      0041A1 33               [12] 1410 	rlc	a
      0041A2 A2 E7            [12] 1411 	mov	c,acc.7
      0041A4 C8               [12] 1412 	xch	a,r0
      0041A5 33               [12] 1413 	rlc	a
      0041A6 C8               [12] 1414 	xch	a,r0
      0041A7 33               [12] 1415 	rlc	a
      0041A8 C8               [12] 1416 	xch	a,r0
      0041A9 54 03            [12] 1417 	anl	a,#0x03
      0041AB FB               [12] 1418 	mov	r3,a
      0041AC 88 82            [24] 1419 	mov	dpl, r0
      0041AE C0 07            [24] 1420 	push	ar7
      0041B0 C0 06            [24] 1421 	push	ar6
      0041B2 C0 05            [24] 1422 	push	ar5
      0041B4 C0 04            [24] 1423 	push	ar4
      0041B6 C0 03            [24] 1424 	push	ar3
      0041B8 C0 02            [24] 1425 	push	ar2
      0041BA C0 01            [24] 1426 	push	ar1
      0041BC 12 3F A4         [24] 1427 	lcall	_load_page
      0041BF E5 82            [12] 1428 	mov	a, dpl
      0041C1 D0 01            [24] 1429 	pop	ar1
      0041C3 D0 02            [24] 1430 	pop	ar2
      0041C5 D0 03            [24] 1431 	pop	ar3
      0041C7 D0 04            [24] 1432 	pop	ar4
      0041C9 D0 05            [24] 1433 	pop	ar5
      0041CB D0 06            [24] 1434 	pop	ar6
      0041CD D0 07            [24] 1435 	pop	ar7
      0041CF D0 03            [24] 1436 	pop	ar3
      0041D1 D0 02            [24] 1437 	pop	ar2
      0041D3 70 01            [24] 1438 	jnz	00105$
      0041D5 22               [24] 1439 	ret
      0041D6                       1440 00105$:
                                   1441 ;	keyboards/ajazz/ak820/ak820_nvm.c:250: if (page_data[offset % AK820_FLASH_PAGE] != value) {
      0041D6 C0 06            [24] 1442 	push	ar6
      0041D8 C0 07            [24] 1443 	push	ar7
      0041DA 74 3F            [12] 1444 	mov	a,#0x3f
      0041DC 55 0C            [12] 1445 	anl	a,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041DE 7F 00            [12] 1446 	mov	r7,#0x00
      0041E0 24 1D            [12] 1447 	add	a, #_page_data
      0041E2 F5 0C            [12] 1448 	mov	_ak820_eeprom_write_block_xdata_sloc0_1_0,a
      0041E4 EF               [12] 1449 	mov	a,r7
      0041E5 34 05            [12] 1450 	addc	a, #(_page_data >> 8)
      0041E7 F5 0D            [12] 1451 	mov	(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1),a
      0041E9 85 0C 82         [24] 1452 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      0041EC 85 0D 83         [24] 1453 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      0041EF E0               [24] 1454 	movx	a,@dptr
      0041F0 B5 01 06         [24] 1455 	cjne	a,ar1,00162$
      0041F3 D0 07            [24] 1456 	pop	ar7
      0041F5 D0 06            [24] 1457 	pop	ar6
      0041F7 80 0E            [24] 1458 	sjmp	00107$
      0041F9                       1459 00162$:
      0041F9 D0 07            [24] 1460 	pop	ar7
      0041FB D0 06            [24] 1461 	pop	ar6
                                   1462 ;	keyboards/ajazz/ak820/ak820_nvm.c:251: page_data[offset % AK820_FLASH_PAGE] = value;
      0041FD 85 0C 82         [24] 1463 	mov	dpl,_ak820_eeprom_write_block_xdata_sloc0_1_0
      004200 85 0D 83         [24] 1464 	mov	dph,(_ak820_eeprom_write_block_xdata_sloc0_1_0 + 1)
      004203 E9               [12] 1465 	mov	a,r1
      004204 F0               [24] 1466 	movx	@dptr,a
                                   1467 ;	keyboards/ajazz/ak820/ak820_nvm.c:252: page_dirty = true;
                                   1468 ;	assignBit
      004205 D2 0A            [12] 1469 	setb	_page_dirty
      004207                       1470 00107$:
                                   1471 ;	keyboards/ajazz/ak820/ak820_nvm.c:254: ++offset;
      004207 0E               [12] 1472 	inc	r6
      004208 BE 00 01         [24] 1473 	cjne	r6,#0x00,00163$
      00420B 0F               [12] 1474 	inc	r7
      00420C                       1475 00163$:
      00420C 02 41 78         [24] 1476 	ljmp	00108$
      00420F                       1477 00110$:
                                   1478 ;	keyboards/ajazz/ak820/ak820_nvm.c:256: if (!batch_depth) ak820_nvm_flush();
      00420F 90 05 5E         [24] 1479 	mov	dptr,#_batch_depth
      004212 E0               [24] 1480 	movx	a,@dptr
      004213 70 03            [24] 1481 	jnz	00113$
                                   1482 ;	keyboards/ajazz/ak820/ak820_nvm.c:257: }
      004215 02 3E 24         [24] 1483 	ljmp	_ak820_nvm_flush
      004218                       1484 00113$:
      004218 22               [24] 1485 	ret
                                   1486 ;------------------------------------------------------------
                                   1487 ;Allocation info for local variables in function 'ak820_eeprom_update_block_xdata'
                                   1488 ;------------------------------------------------------------
                                   1489 ;sloc0         Allocated with name '_ak820_eeprom_update_block_xdata_sloc0_1_0'
                                   1490 ;sloc1         Allocated with name '_ak820_eeprom_update_block_xdata_sloc1_1_0'
                                   1491 ;sloc2         Allocated with name '_ak820_eeprom_update_block_xdata_sloc2_1_0'
                                   1492 ;addr          Allocated with name '_ak820_eeprom_update_block_xdata_PARM_2'
                                   1493 ;len           Allocated with name '_ak820_eeprom_update_block_xdata_PARM_3'
                                   1494 ;buf           Allocated with name '_ak820_eeprom_update_block_xdata_buf_10000_127'
                                   1495 ;source        Allocated with name '_ak820_eeprom_update_block_xdata_source_10000_128'
                                   1496 ;offset        Allocated with name '_ak820_eeprom_update_block_xdata_offset_10000_128'
                                   1497 ;i             Allocated with name '_ak820_eeprom_update_block_xdata_i_10000_128'
                                   1498 ;------------------------------------------------------------
                                   1499 ;	keyboards/ajazz/ak820/ak820_nvm.c:259: void ak820_eeprom_update_block_xdata(const void AK820_XDATA *buf, void *addr, size_t len) {
                                   1500 ;	-----------------------------------------
                                   1501 ;	 function ak820_eeprom_update_block_xdata
                                   1502 ;	-----------------------------------------
      004219                       1503 _ak820_eeprom_update_block_xdata:
      004219 12 38 7D         [24] 1504 	lcall	_ak820_outline_0103
      00421C 90 05 9A         [24] 1505 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00421F 12 38 82         [24] 1506 	lcall	_ak820_outline_0104
                                   1507 ;	keyboards/ajazz/ak820/ak820_nvm.c:260: const uint8_t AK820_XDATA *source = (const uint8_t AK820_XDATA *)buf;
      004222 90 05 9A         [24] 1508 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      004225 12 38 42         [24] 1509 	lcall	_ak820_outline_0051
                                   1510 ;	keyboards/ajazz/ak820/ak820_nvm.c:261: uint16_t offset = (uint16_t)(uintptr_t)addr;
      004228 90 05 95         [24] 1511 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_2
      00422B E0               [24] 1512 	movx	a,@dptr
      00422C F5 12            [12] 1513 	mov	_ak820_eeprom_update_block_xdata_sloc2_1_0,a
      00422E A3               [24] 1514 	inc	dptr
      00422F E0               [24] 1515 	movx	a,@dptr
      004230 F5 13            [12] 1516 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1),a
      004232 A3               [24] 1517 	inc	dptr
      004233 E0               [24] 1518 	movx	a,@dptr
      004234 F5 14            [12] 1519 	mov	(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2),a
      004236 A9 12            [24] 1520 	mov	r1,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004238 AA 13            [24] 1521 	mov	r2,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
                                   1522 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      00423A E4               [12] 1523 	clr	a
      00423B F5 0E            [12] 1524 	mov	_ak820_eeprom_update_block_xdata_sloc0_1_0,a
      00423D F5 0F            [12] 1525 	mov	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1),a
      00423F                       1526 00105$:
      00423F 90 05 98         [24] 1527 	mov	dptr,#_ak820_eeprom_update_block_xdata_PARM_3
      004242 E0               [24] 1528 	movx	a,@dptr
      004243 F5 10            [12] 1529 	mov	_ak820_eeprom_update_block_xdata_sloc1_1_0,a
      004245 A3               [24] 1530 	inc	dptr
      004246 E0               [24] 1531 	movx	a,@dptr
      004247 F5 11            [12] 1532 	mov	(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1),a
      004249 C3               [12] 1533 	clr	c
      00424A E5 0E            [12] 1534 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00424C 95 10            [12] 1535 	subb	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      00424E E5 0F            [12] 1536 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004250 95 11            [12] 1537 	subb	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      004252 50 68            [24] 1538 	jnc	00107$
                                   1539 ;	keyboards/ajazz/ak820/ak820_nvm.c:264: if (read_offset(offset + i) != source[i]) {
      004254 89 00            [24] 1540 	mov	ar0,r1
      004256 8A 05            [24] 1541 	mov	ar5,r2
      004258 E5 0E            [12] 1542 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00425A 28               [12] 1543 	add	a, r0
      00425B F8               [12] 1544 	mov	r0,a
      00425C E5 0F            [12] 1545 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      00425E 3D               [12] 1546 	addc	a, r5
      00425F FD               [12] 1547 	mov	r5,a
      004260 88 82            [24] 1548 	mov	dpl, r0
      004262 8D 83            [24] 1549 	mov	dph, r5
      004264 C0 07            [24] 1550 	push	ar7
      004266 C0 06            [24] 1551 	push	ar6
      004268 C0 02            [24] 1552 	push	ar2
      00426A C0 01            [24] 1553 	push	ar1
      00426C 12 40 16         [24] 1554 	lcall	_read_offset
      00426F AD 82            [24] 1555 	mov	r5, dpl
      004271 D0 01            [24] 1556 	pop	ar1
      004273 D0 02            [24] 1557 	pop	ar2
      004275 D0 06            [24] 1558 	pop	ar6
      004277 D0 07            [24] 1559 	pop	ar7
      004279 E5 0E            [12] 1560 	mov	a,_ak820_eeprom_update_block_xdata_sloc0_1_0
      00427B 2E               [12] 1561 	add	a, r6
      00427C F5 82            [12] 1562 	mov	dpl,a
      00427E E5 0F            [12] 1563 	mov	a,(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      004280 3F               [12] 1564 	addc	a, r7
      004281 F5 83            [12] 1565 	mov	dph,a
      004283 E0               [24] 1566 	movx	a,@dptr
      004284 FC               [12] 1567 	mov	r4,a
      004285 ED               [12] 1568 	mov	a,r5
      004286 B5 04 02         [24] 1569 	cjne	a,ar4,00131$
      004289 80 27            [24] 1570 	sjmp	00106$
      00428B                       1571 00131$:
                                   1572 ;	keyboards/ajazz/ak820/ak820_nvm.c:265: ak820_eeprom_write_block_xdata(buf, addr, len);
      00428B 90 05 9A         [24] 1573 	mov	dptr,#_ak820_eeprom_update_block_xdata_buf_10000_127
      00428E E0               [24] 1574 	movx	a,@dptr
      00428F F8               [12] 1575 	mov	r0,a
      004290 A3               [24] 1576 	inc	dptr
      004291 E0               [24] 1577 	movx	a,@dptr
      004292 FD               [12] 1578 	mov	r5,a
      004293 90 05 8E         [24] 1579 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      004296 E5 12            [12] 1580 	mov	a,_ak820_eeprom_update_block_xdata_sloc2_1_0
      004298 F0               [24] 1581 	movx	@dptr,a
      004299 E5 13            [12] 1582 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 1)
      00429B A3               [24] 1583 	inc	dptr
      00429C F0               [24] 1584 	movx	@dptr,a
      00429D E5 14            [12] 1585 	mov	a,(_ak820_eeprom_update_block_xdata_sloc2_1_0 + 2)
      00429F A3               [24] 1586 	inc	dptr
      0042A0 F0               [24] 1587 	movx	@dptr,a
      0042A1 90 05 91         [24] 1588 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      0042A4 E5 10            [12] 1589 	mov	a,_ak820_eeprom_update_block_xdata_sloc1_1_0
      0042A6 F0               [24] 1590 	movx	@dptr,a
      0042A7 E5 11            [12] 1591 	mov	a,(_ak820_eeprom_update_block_xdata_sloc1_1_0 + 1)
      0042A9 A3               [24] 1592 	inc	dptr
      0042AA F0               [24] 1593 	movx	@dptr,a
      0042AB 88 82            [24] 1594 	mov	dpl, r0
      0042AD 8D 83            [24] 1595 	mov	dph, r5
                                   1596 ;	keyboards/ajazz/ak820/ak820_nvm.c:266: return;
      0042AF 02 41 36         [24] 1597 	ljmp	_ak820_eeprom_write_block_xdata
      0042B2                       1598 00106$:
                                   1599 ;	keyboards/ajazz/ak820/ak820_nvm.c:263: for (i = 0; i < len; ++i) {
      0042B2 05 0E            [12] 1600 	inc	_ak820_eeprom_update_block_xdata_sloc0_1_0
      0042B4 E4               [12] 1601 	clr	a
      0042B5 B5 0E 87         [24] 1602 	cjne	a,_ak820_eeprom_update_block_xdata_sloc0_1_0,00105$
      0042B8 05 0F            [12] 1603 	inc	(_ak820_eeprom_update_block_xdata_sloc0_1_0 + 1)
      0042BA 80 83            [24] 1604 	sjmp	00105$
      0042BC                       1605 00107$:
                                   1606 ;	keyboards/ajazz/ak820/ak820_nvm.c:269: }
      0042BC 22               [24] 1607 	ret
                                   1608 ;------------------------------------------------------------
                                   1609 ;Allocation info for local variables in function 'eeprom_driver_erase'
                                   1610 ;------------------------------------------------------------
                                   1611 ;page          Allocated with name '_eeprom_driver_erase_page_10000_134'
                                   1612 ;i             Allocated with name '_eeprom_driver_erase_i_10000_134'
                                   1613 ;------------------------------------------------------------
                                   1614 ;	keyboards/ajazz/ak820/ak820_nvm.c:271: void eeprom_driver_erase(void) {
                                   1615 ;	-----------------------------------------
                                   1616 ;	 function eeprom_driver_erase
                                   1617 ;	-----------------------------------------
      0042BD                       1618 _eeprom_driver_erase:
                                   1619 ;	keyboards/ajazz/ak820/ak820_nvm.c:274: ak820_nvm_flush();
      0042BD 12 3E 24         [24] 1620 	lcall	_ak820_nvm_flush
                                   1621 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042C0 7F 00            [12] 1622 	mov	r7,#0x00
      0042C2                       1623 00111$:
      0042C2 BF A0 01         [24] 1624 	cjne	r7,#0xa0,00165$
      0042C5 22               [24] 1625 	ret
      0042C6                       1626 00165$:
      0042C6 20 0B 32         [24] 1627 	jb	_storage_failed,00113$
                                   1628 ;	keyboards/ajazz/ak820/ak820_nvm.c:276: if (!load_page(page)) return;
      0042C9 8F 82            [24] 1629 	mov	dpl, r7
      0042CB C0 07            [24] 1630 	push	ar7
      0042CD 12 3F A4         [24] 1631 	lcall	_load_page
      0042D0 E5 82            [12] 1632 	mov	a, dpl
      0042D2 D0 07            [24] 1633 	pop	ar7
      0042D4 70 01            [24] 1634 	jnz	00126$
                                   1635 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042D6 22               [24] 1636 	ret
      0042D7                       1637 00126$:
      0042D7 7E 00            [12] 1638 	mov	r6,#0x00
      0042D9                       1639 00107$:
                                   1640 ;	keyboards/ajazz/ak820/ak820_nvm.c:278: if (page_data[i]) { page_data[i] = 0; page_dirty = true; }
      0042D9 EE               [12] 1641 	mov	a,r6
      0042DA 24 1D            [12] 1642 	add	a, #_page_data
      0042DC FC               [12] 1643 	mov	r4,a
      0042DD E4               [12] 1644 	clr	a
      0042DE 34 05            [12] 1645 	addc	a, #(_page_data >> 8)
      0042E0 FD               [12] 1646 	mov	r5,a
      0042E1 12 43 38         [24] 1647 	lcall	_ak820_outline_0090
      0042E4 60 07            [24] 1648 	jz	00108$
      0042E6 12 38 92         [24] 1649 	lcall	_ak820_outline_0119
      0042E9 E4               [12] 1650 	clr	a
      0042EA F0               [24] 1651 	movx	@dptr,a
                                   1652 ;	assignBit
      0042EB D2 0A            [12] 1653 	setb	_page_dirty
      0042ED                       1654 00108$:
                                   1655 ;	keyboards/ajazz/ak820/ak820_nvm.c:277: for (i = 0; i != AK820_FLASH_PAGE; ++i) {
      0042ED 0E               [12] 1656 	inc	r6
      0042EE BE 40 E8         [24] 1657 	cjne	r6,#0x40,00107$
                                   1658 ;	keyboards/ajazz/ak820/ak820_nvm.c:280: ak820_nvm_flush();
      0042F1 C0 07            [24] 1659 	push	ar7
      0042F3 12 3E 24         [24] 1660 	lcall	_ak820_nvm_flush
      0042F6 D0 07            [24] 1661 	pop	ar7
                                   1662 ;	keyboards/ajazz/ak820/ak820_nvm.c:275: for (page = 0; page != AK820_NVM_SIZE / AK820_FLASH_PAGE && !storage_failed; ++page) {
      0042F8 0F               [12] 1663 	inc	r7
      0042F9 80 C7            [24] 1664 	sjmp	00111$
      0042FB                       1665 00113$:
                                   1666 ;	keyboards/ajazz/ak820/ak820_nvm.c:282: }
      0042FB 22               [24] 1667 	ret
                                   1668 	.area CSEG    (CODE)
                                   1669 	.area CONST   (CODE)
                                   1670 	.area XINIT   (CODE)
                                   1671 	.area CABS    (ABS,CODE)
                                   1672 
                                   1673 ; Experimental exact instruction outlining.
                                   1674 	.globl _ak820_outline_0005
                                   1675 	.globl _ak820_outline_0011
                                   1676 	.globl _ak820_outline_0016
                                   1677 	.globl _ak820_outline_0020
                                   1678 	.globl _ak820_outline_0030
                                   1679 	.globl _ak820_outline_0036
                                   1680 	.globl _ak820_outline_0042
                                   1681 	.globl _ak820_outline_0051
                                   1682 	.globl _ak820_outline_0052
                                   1683 	.globl _ak820_outline_0059
                                   1684 	.globl _ak820_outline_0070
                                   1685 	.globl _ak820_outline_0071
                                   1686 	.globl _ak820_outline_0081
                                   1687 	.globl _ak820_outline_0090
                                   1688 	.globl _ak820_outline_0092
                                   1689 	.globl _ak820_outline_0098
                                   1690 	.globl _ak820_outline_0099
                                   1691 	.globl _ak820_outline_0101
                                   1692 	.globl _ak820_outline_0103
                                   1693 	.globl _ak820_outline_0104
                                   1694 	.globl _ak820_outline_0112
                                   1695 	.globl _ak820_outline_0115
                                   1696 	.globl _ak820_outline_0117
                                   1697 	.globl _ak820_outline_0118
                                   1698 	.globl _ak820_outline_0119
                                   1699 	.globl _ak820_outline_0128
                                   1700 	.globl _ak820_outline_0129
                                   1701 	.globl _ak820_outline_0131
                                   1702 	.globl _ak820_outline_0136
                                   1703 	.globl _ak820_outline_0137
                                   1704 	.globl _ak820_outline_0143
                                   1705 	.globl _ak820_outline_0150
                                   1706 	.globl _ak820_outline_0151
                                   1707 	.globl _ak820_outline_0154
                                   1708 	.globl _ak820_outline_0155
                                   1709 	.globl _ak820_outline_0176
                                   1710 	.globl _ak820_outline_0177
                                   1711 
                                   1712 	.area CSEG (CODE)
                                   1713 ; function ak820_outline_0011
      0042FC                       1714 _ak820_outline_0011:
      0042FC 8E 82            [24] 1715 	mov	dpl,r6
      0042FE 8F 83            [24] 1716 	mov	dph,r7
      004300 A3               [24] 1717 	inc	dptr
      004301 A3               [24] 1718 	inc	dptr
      004302 A3               [24] 1719 	inc	dptr
      004303 A3               [24] 1720 	inc	dptr
      004304 A3               [24] 1721 	inc	dptr
      004305 22               [24] 1722 	ret
                                   1723 
                                   1724 	.area CSEG (CODE)
                                   1725 ; function ak820_outline_0030
      004306                       1726 _ak820_outline_0030:
      004306 F0               [24] 1727 	movx	@dptr,a
      004307 8E 82            [24] 1728 	mov	dpl,r6
      004309 8F 83            [24] 1729 	mov	dph,r7
      00430B A3               [24] 1730 	inc	dptr
      00430C A3               [24] 1731 	inc	dptr
      00430D 22               [24] 1732 	ret
                                   1733 
                                   1734 	.area CSEG (CODE)
                                   1735 ; function ak820_outline_0036
      00430E                       1736 _ak820_outline_0036:
      00430E AF F0            [24] 1737 	mov	r7,b
      004310 AE 83            [24] 1738 	mov	r6,dph
      004312 E5 82            [12] 1739 	mov	a,dpl
      004314 22               [24] 1740 	ret
                                   1741 
                                   1742 	.area CSEG (CODE)
                                   1743 ; function ak820_outline_0042
      004315                       1744 _ak820_outline_0042:
      004315 EF               [12] 1745 	mov	a,r7
      004316 24 75            [12] 1746 	add	a,#_ak820_nvm_flush_header_10000_62
      004318 F5 82            [12] 1747 	mov	dpl,a
      00431A E4               [12] 1748 	clr	a
      00431B 34 05            [12] 1749 	addc	a,#(_ak820_nvm_flush_header_10000_62>>8)
      00431D F5 83            [12] 1750 	mov	dph,a
      00431F E0               [24] 1751 	movx	a,@dptr
      004320 22               [24] 1752 	ret
                                   1753 
                                   1754 	.area CSEG (CODE)
                                   1755 ; function ak820_outline_0052
      004321                       1756 _ak820_outline_0052:
      004321 8F 06            [24] 1757 	mov	ar6,r7
      004323 7D 00            [12] 1758 	mov	r5,#0x00
      004325 74 40            [12] 1759 	mov	a,#0x40
      004327 2E               [12] 1760 	add	a,r6
      004328 FE               [12] 1761 	mov	r6,a
      004329 74 EF            [12] 1762 	mov	a,#0xef
      00432B 3D               [12] 1763 	addc	a,r5
      00432C FD               [12] 1764 	mov	r5,a
      00432D 8E 82            [24] 1765 	mov	dpl,r6
      00432F 8D 83            [24] 1766 	mov	dph,r5
      004331 22               [24] 1767 	ret
                                   1768 
                                   1769 	.area CSEG (CODE)
                                   1770 ; function ak820_outline_0070
      004332                       1771 _ak820_outline_0070:
      004332 F0               [24] 1772 	movx	@dptr,a
      004333 8E 82            [24] 1773 	mov	dpl,r6
      004335 8F 83            [24] 1774 	mov	dph,r7
      004337 22               [24] 1775 	ret
                                   1776 
                                   1777 	.area CSEG (CODE)
                                   1778 ; function ak820_outline_0090
      004338                       1779 _ak820_outline_0090:
      004338 8C 82            [24] 1780 	mov	dpl,r4
      00433A 8D 83            [24] 1781 	mov	dph,r5
      00433C E0               [24] 1782 	movx	a,@dptr
      00433D 22               [24] 1783 	ret
                                   1784 
                                   1785 	.area CSEG (CODE)
                                   1786 ; function ak820_outline_0099
      00433E                       1787 _ak820_outline_0099:
      00433E E0               [24] 1788 	movx	a,@dptr
      00433F FA               [12] 1789 	mov	r2,a
      004340 A3               [24] 1790 	inc	dptr
      004341 E0               [24] 1791 	movx	a,@dptr
      004342 FB               [12] 1792 	mov	r3,a
      004343 22               [24] 1793 	ret
                                   1794 
                                   1795 	.area CSEG (CODE)
                                   1796 ; function ak820_outline_0101
      004344                       1797 _ak820_outline_0101:
      004344 EF               [12] 1798 	mov	a,r7
      004345 24 1D            [12] 1799 	add	a,#_page_data
      004347 F5 82            [12] 1800 	mov	dpl,a
      004349 E4               [12] 1801 	clr	a
      00434A 34 05            [12] 1802 	addc	a,#(_page_data>>8)
      00434C F5 83            [12] 1803 	mov	dph,a
      00434E E0               [24] 1804 	movx	a,@dptr
      00434F 22               [24] 1805 	ret
                                   1806 
                                   1807 	.area CSEG (CODE)
                                   1808 ; function ak820_outline_0115
      004350                       1809 _ak820_outline_0115:
      004350 8C 82            [24] 1810 	mov	dpl,r4
      004352 8D 83            [24] 1811 	mov	dph,r5
      004354 F0               [24] 1812 	movx	@dptr,a
      004355 22               [24] 1813 	ret
                                   1814 
                                   1815 	.area CSEG (CODE)
                                   1816 ; function ak820_outline_0129
      004356                       1817 _ak820_outline_0129:
      004356 AE 82            [24] 1818 	mov	r6,dpl
      004358 AF 83            [24] 1819 	mov	r7,dph
      00435A 22               [24] 1820 	ret
                                   1821 
                                   1822 	.area CSEG (CODE)
                                   1823 ; function ak820_outline_0131
      00435B                       1824 _ak820_outline_0131:
      00435B 2E               [12] 1825 	add	a,r6
      00435C FE               [12] 1826 	mov	r6,a
      00435D E4               [12] 1827 	clr	a
      00435E 3F               [12] 1828 	addc	a,r7
      00435F FF               [12] 1829 	mov	r7,a
      004360 22               [24] 1830 	ret
                                   1831 
                                   1832 	.area CSEG (CODE)
                                   1833 ; function ak820_outline_0136
      004361                       1834 _ak820_outline_0136:
      004361 42 05            [12] 1835 	orl	ar5,a
      004363 EA               [12] 1836 	mov	a,r2
      004364 42 04            [12] 1837 	orl	ar4,a
      004366 22               [24] 1838 	ret
                                   1839 
                                   1840 	.area CSEG (CODE)
                                   1841 ; function ak820_outline_0143
      004367                       1842 _ak820_outline_0143:
      004367 AC 82            [24] 1843 	mov	r4,dpl
      004369 AD 83            [24] 1844 	mov	r5,dph
      00436B 22               [24] 1845 	ret
                                   1846 
                                   1847 	.area CSEG (CODE)
                                   1848 ; function ak820_outline_0151
      00436C                       1849 _ak820_outline_0151:
      00436C 8F 82            [24] 1850 	mov	dpl,r7
      00436E 8E 83            [24] 1851 	mov	dph,r6
      004370 22               [24] 1852 	ret
                                   1853 
                                   1854 	.area CSEG (CODE)
                                   1855 ; function ak820_outline_0154
      004371                       1856 _ak820_outline_0154:
      004371 2E               [12] 1857 	add	a,r6
      004372 FC               [12] 1858 	mov	r4,a
      004373 E4               [12] 1859 	clr	a
      004374 3F               [12] 1860 	addc	a,r7
      004375 FD               [12] 1861 	mov	r5,a
      004376 22               [24] 1862 	ret
                                   1863 
                                   1864 	.area CSEG (CODE)
                                   1865 ; function ak820_outline_0155
      004377                       1866 _ak820_outline_0155:
      004377 ED               [12] 1867 	mov	a,r5
      004378 F0               [24] 1868 	movx	@dptr,a
      004379 EE               [12] 1869 	mov	a,r6
      00437A A3               [24] 1870 	inc	dptr
      00437B F0               [24] 1871 	movx	@dptr,a
      00437C 22               [24] 1872 	ret
                                   1873 
                                   1874 	.area CSEG (CODE)
                                   1875 ; function ak820_outline_0176
      00437D                       1876 _ak820_outline_0176:
      00437D 89 82            [24] 1877 	mov	dpl,r1
      00437F 8A 83            [24] 1878 	mov	dph,r2
      004381 22               [24] 1879 	ret
                                   1880 
                                   1881 	.area CSEG (CODE)
                                   1882 ; function ak820_outline_0177
      004382                       1883 _ak820_outline_0177:
      004382 8C 82            [24] 1884 	mov	dpl,r4
      004384 8B 83            [24] 1885 	mov	dph,r3
      004386 22               [24] 1886 	ret
