                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module eeprom_driver
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_eeprom_write_block_xdata
                                     12 	.globl _ak820_eeprom_read_block_xdata
                                     13 	.globl _eeprom_read_byte
                                     14 	.globl _eeprom_update_dword_PARM_2
                                     15 	.globl _eeprom_update_word_PARM_2
                                     16 	.globl _eeprom_update_byte_PARM_2
                                     17 	.globl _eeprom_write_dword_PARM_2
                                     18 	.globl _eeprom_write_word_PARM_2
                                     19 	.globl _eeprom_write_byte_PARM_2
                                     20 	.globl _eeprom_read_word
                                     21 	.globl _eeprom_read_dword
                                     22 	.globl _eeprom_write_byte
                                     23 	.globl _eeprom_write_word
                                     24 	.globl _eeprom_write_dword
                                     25 	.globl _eeprom_update_byte
                                     26 	.globl _eeprom_update_word
                                     27 	.globl _eeprom_update_dword
                                     28 ;--------------------------------------------------------
                                     29 ; special function registers
                                     30 ;--------------------------------------------------------
                                     31 	.area RSEG    (ABS,DATA)
      000000                         32 	.org 0x0000
                                     33 ;--------------------------------------------------------
                                     34 ; special function bits
                                     35 ;--------------------------------------------------------
                                     36 	.area RSEG    (ABS,DATA)
      000000                         37 	.org 0x0000
                                     38 ;--------------------------------------------------------
                                     39 ; overlayable register banks
                                     40 ;--------------------------------------------------------
                                     41 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                         42 	.ds 8
                                     43 ;--------------------------------------------------------
                                     44 ; overlayable bit register bank
                                     45 ;--------------------------------------------------------
                                     46 	.area BIT_BANK	(REL,OVR,DATA)
      000026                         47 bits:
      000026                         48 	.ds 1
                           008000    49 	b0 = bits[0]
                           008100    50 	b1 = bits[1]
                           008200    51 	b2 = bits[2]
                           008300    52 	b3 = bits[3]
                           008400    53 	b4 = bits[4]
                           008500    54 	b5 = bits[5]
                           008600    55 	b6 = bits[6]
                           008700    56 	b7 = bits[7]
                                     57 ;--------------------------------------------------------
                                     58 ; internal ram data
                                     59 ;--------------------------------------------------------
                                     60 	.area DSEG    (DATA)
                                     61 ;--------------------------------------------------------
                                     62 ; overlayable items in internal ram
                                     63 ;--------------------------------------------------------
                                     64 ;--------------------------------------------------------
                                     65 ; indirectly addressable internal ram data
                                     66 ;--------------------------------------------------------
                                     67 	.area ISEG    (DATA)
                                     68 ;--------------------------------------------------------
                                     69 ; absolute internal ram data
                                     70 ;--------------------------------------------------------
                                     71 	.area IABS    (ABS,DATA)
                                     72 	.area IABS    (ABS,DATA)
                                     73 ;--------------------------------------------------------
                                     74 ; bit data
                                     75 ;--------------------------------------------------------
                                     76 	.area BSEG    (BIT)
                                     77 ;--------------------------------------------------------
                                     78 ; paged external ram data
                                     79 ;--------------------------------------------------------
                                     80 	.area PSEG    (PAG,XDATA)
                                     81 ;--------------------------------------------------------
                                     82 ; uninitialized external ram data
                                     83 ;--------------------------------------------------------
                                     84 	.area XSEG    (XDATA)
      00068F                         85 _eeprom_read_word_addr_10000_91:
      00068F                         86 	.ds 3
      000692                         87 _eeprom_read_word_ret_10000_92:
      000692                         88 	.ds 2
      000694                         89 _eeprom_read_dword_addr_10000_93:
      000694                         90 	.ds 3
      000697                         91 _eeprom_read_dword_ret_10000_94:
      000697                         92 	.ds 4
      00069B                         93 _eeprom_write_byte_PARM_2:
      00069B                         94 	.ds 1
      00069C                         95 _eeprom_write_byte_addr_10000_95:
      00069C                         96 	.ds 3
      00069F                         97 _eeprom_write_word_PARM_2:
      00069F                         98 	.ds 2
      0006A1                         99 _eeprom_write_word_addr_10000_97:
      0006A1                        100 	.ds 3
      0006A4                        101 _eeprom_write_dword_PARM_2:
      0006A4                        102 	.ds 4
      0006A8                        103 _eeprom_write_dword_addr_10000_99:
      0006A8                        104 	.ds 3
      0006AB                        105 _eeprom_update_byte_PARM_2:
      0006AB                        106 	.ds 1
      0006AC                        107 _eeprom_update_byte_addr_10000_107:
      0006AC                        108 	.ds 3
      0006AF                        109 _eeprom_update_word_PARM_2:
      0006AF                        110 	.ds 2
      0006B1                        111 _eeprom_update_word_addr_10000_111:
      0006B1                        112 	.ds 3
      0006B4                        113 _eeprom_update_dword_PARM_2:
      0006B4                        114 	.ds 4
      0006B8                        115 _eeprom_update_dword_addr_10000_115:
      0006B8                        116 	.ds 3
                                    117 ;--------------------------------------------------------
                                    118 ; absolute external ram data
                                    119 ;--------------------------------------------------------
                                    120 	.area XABS    (ABS,XDATA)
                                    121 ;--------------------------------------------------------
                                    122 ; initialized external ram data
                                    123 ;--------------------------------------------------------
                                    124 	.area XISEG   (XDATA)
                                    125 	.area HOME    (CODE)
                                    126 	.area GSINIT0 (CODE)
                                    127 	.area GSINIT1 (CODE)
                                    128 	.area GSINIT2 (CODE)
                                    129 	.area GSINIT3 (CODE)
                                    130 	.area GSINIT4 (CODE)
                                    131 	.area GSINIT5 (CODE)
                                    132 	.area GSINIT  (CODE)
                                    133 	.area GSFINAL (CODE)
                                    134 	.area CSEG    (CODE)
                                    135 ;--------------------------------------------------------
                                    136 ; global & static initialisations
                                    137 ;--------------------------------------------------------
                                    138 	.area HOME    (CODE)
                                    139 	.area GSINIT  (CODE)
                                    140 	.area GSFINAL (CODE)
                                    141 	.area GSINIT  (CODE)
                                    142 ;--------------------------------------------------------
                                    143 ; Home
                                    144 ;--------------------------------------------------------
                                    145 	.area HOME    (CODE)
                                    146 	.area HOME    (CODE)
                                    147 ;--------------------------------------------------------
                                    148 ; code
                                    149 ;--------------------------------------------------------
                                    150 	.area CSEG    (CODE)
                                    151 ;------------------------------------------------------------
                                    152 ;Allocation info for local variables in function 'eeprom_read_word'
                                    153 ;------------------------------------------------------------
                                    154 ;addr          Allocated with name '_eeprom_read_word_addr_10000_91'
                                    155 ;ret           Allocated with name '_eeprom_read_word_ret_10000_92'
                                    156 ;------------------------------------------------------------
                                    157 ;	drivers/eeprom/eeprom_driver.c:44: uint16_t eeprom_read_word(const uint16_t *addr) {
                                    158 ;	-----------------------------------------
                                    159 ;	 function eeprom_read_word
                                    160 ;	-----------------------------------------
      004F7C                        161 _eeprom_read_word:
                           000007   162 	ar7 = 0x07
                           000006   163 	ar6 = 0x06
                           000005   164 	ar5 = 0x05
                           000004   165 	ar4 = 0x04
                           000003   166 	ar3 = 0x03
                           000002   167 	ar2 = 0x02
                           000001   168 	ar1 = 0x01
                           000000   169 	ar0 = 0x00
      004F7C 12 45 5E         [24]  170 	lcall	_ak820_outline_0037
      004F7F 90 06 8F         [24]  171 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004F82 12 3A 74         [24]  172 	lcall	_ak820_outline_0017
                                    173 ;	drivers/eeprom/eeprom_driver.c:45: uint16_t ret = 0;
      004F85 90 06 92         [24]  174 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004F88 12 51 87         [24]  175 	lcall	_ak820_outline_0182
                                    176 ;	drivers/eeprom/eeprom_driver.c:46: EEPROM_LOCAL_READ(&ret, addr, 2);
      004F8B 90 06 8F         [24]  177 	mov	dptr,#_eeprom_read_word_addr_10000_91
      004F8E 12 51 34         [24]  178 	lcall	_ak820_outline_0012
      004F91 90 05 95         [24]  179 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004F94 ED               [12]  180 	mov	a,r5
      004F95 12 3A 74         [24]  181 	lcall	_ak820_outline_0017
      004F98 90 05 98         [24]  182 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004F9B 12 51 79         [24]  183 	lcall	_ak820_outline_0110
      004F9E 90 06 92         [24]  184 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004FA1 12 42 FA         [24]  185 	lcall	_ak820_eeprom_read_block_xdata
                                    186 ;	drivers/eeprom/eeprom_driver.c:47: return ret;
      004FA4 90 06 92         [24]  187 	mov	dptr,#_eeprom_read_word_ret_10000_92
      004FA7 12 51 70         [24]  188 	lcall	_ak820_outline_0092
                                    189 ;	drivers/eeprom/eeprom_driver.c:48: }
      004FAA 22               [24]  190 	ret
                                    191 ;------------------------------------------------------------
                                    192 ;Allocation info for local variables in function 'eeprom_read_dword'
                                    193 ;------------------------------------------------------------
                                    194 ;addr          Allocated with name '_eeprom_read_dword_addr_10000_93'
                                    195 ;ret           Allocated with name '_eeprom_read_dword_ret_10000_94'
                                    196 ;------------------------------------------------------------
                                    197 ;	drivers/eeprom/eeprom_driver.c:50: uint32_t eeprom_read_dword(const uint32_t *addr) {
                                    198 ;	-----------------------------------------
                                    199 ;	 function eeprom_read_dword
                                    200 ;	-----------------------------------------
      004FAB                        201 _eeprom_read_dword:
      004FAB 12 45 5E         [24]  202 	lcall	_ak820_outline_0037
      004FAE 90 06 94         [24]  203 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004FB1 12 3A 74         [24]  204 	lcall	_ak820_outline_0017
                                    205 ;	drivers/eeprom/eeprom_driver.c:51: uint32_t ret = 0;
      004FB4 90 06 97         [24]  206 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004FB7 12 51 45         [24]  207 	lcall	_ak820_outline_0050
                                    208 ;	drivers/eeprom/eeprom_driver.c:52: EEPROM_LOCAL_READ(&ret, addr, 4);
      004FBA 90 06 94         [24]  209 	mov	dptr,#_eeprom_read_dword_addr_10000_93
      004FBD 12 51 34         [24]  210 	lcall	_ak820_outline_0012
      004FC0 90 05 95         [24]  211 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      004FC3 ED               [12]  212 	mov	a,r5
      004FC4 12 3A 74         [24]  213 	lcall	_ak820_outline_0017
      004FC7 90 05 98         [24]  214 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      004FCA 74 04            [12]  215 	mov	a,#0x04
      004FCC 12 3A E7         [24]  216 	lcall	_ak820_outline_0134
      004FCF 90 06 97         [24]  217 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004FD2 12 42 FA         [24]  218 	lcall	_ak820_eeprom_read_block_xdata
                                    219 ;	drivers/eeprom/eeprom_driver.c:53: return ret;
      004FD5 90 06 97         [24]  220 	mov	dptr,#_eeprom_read_dword_ret_10000_94
      004FD8 12 51 4E         [24]  221 	lcall	_ak820_outline_0054
                                    222 ;	drivers/eeprom/eeprom_driver.c:54: }
      004FDB 22               [24]  223 	ret
                                    224 ;------------------------------------------------------------
                                    225 ;Allocation info for local variables in function 'eeprom_write_byte'
                                    226 ;------------------------------------------------------------
                                    227 ;value         Allocated with name '_eeprom_write_byte_PARM_2'
                                    228 ;addr          Allocated with name '_eeprom_write_byte_addr_10000_95'
                                    229 ;------------------------------------------------------------
                                    230 ;	drivers/eeprom/eeprom_driver.c:56: void eeprom_write_byte(uint8_t *addr, uint8_t value) {
                                    231 ;	-----------------------------------------
                                    232 ;	 function eeprom_write_byte
                                    233 ;	-----------------------------------------
      004FDC                        234 _eeprom_write_byte:
      004FDC 12 45 5E         [24]  235 	lcall	_ak820_outline_0037
      004FDF 90 06 9C         [24]  236 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004FE2 12 3A 74         [24]  237 	lcall	_ak820_outline_0017
                                    238 ;	drivers/eeprom/eeprom_driver.c:57: EEPROM_LOCAL_WRITE(&value, addr, 1);
      004FE5 90 06 9C         [24]  239 	mov	dptr,#_eeprom_write_byte_addr_10000_95
      004FE8 12 51 1D         [24]  240 	lcall	_ak820_outline_0004
      004FEB 74 01            [12]  241 	mov	a,#0x01
      004FED 12 3A E7         [24]  242 	lcall	_ak820_outline_0134
      004FF0 90 06 9B         [24]  243 	mov	dptr,#_eeprom_write_byte_PARM_2
                                    244 ;	drivers/eeprom/eeprom_driver.c:58: }
      004FF3 02 43 86         [24]  245 	ljmp	_ak820_eeprom_write_block_xdata
                                    246 ;------------------------------------------------------------
                                    247 ;Allocation info for local variables in function 'eeprom_write_word'
                                    248 ;------------------------------------------------------------
                                    249 ;value         Allocated with name '_eeprom_write_word_PARM_2'
                                    250 ;addr          Allocated with name '_eeprom_write_word_addr_10000_97'
                                    251 ;------------------------------------------------------------
                                    252 ;	drivers/eeprom/eeprom_driver.c:60: void eeprom_write_word(uint16_t *addr, uint16_t value) {
                                    253 ;	-----------------------------------------
                                    254 ;	 function eeprom_write_word
                                    255 ;	-----------------------------------------
      004FF6                        256 _eeprom_write_word:
      004FF6 12 45 5E         [24]  257 	lcall	_ak820_outline_0037
      004FF9 90 06 A1         [24]  258 	mov	dptr,#_eeprom_write_word_addr_10000_97
      004FFC 12 3A 74         [24]  259 	lcall	_ak820_outline_0017
                                    260 ;	drivers/eeprom/eeprom_driver.c:61: EEPROM_LOCAL_WRITE(&value, addr, 2);
      004FFF 90 06 A1         [24]  261 	mov	dptr,#_eeprom_write_word_addr_10000_97
      005002 12 51 1D         [24]  262 	lcall	_ak820_outline_0004
      005005 12 51 79         [24]  263 	lcall	_ak820_outline_0110
      005008 90 06 9F         [24]  264 	mov	dptr,#_eeprom_write_word_PARM_2
                                    265 ;	drivers/eeprom/eeprom_driver.c:62: }
      00500B 02 43 86         [24]  266 	ljmp	_ak820_eeprom_write_block_xdata
                                    267 ;------------------------------------------------------------
                                    268 ;Allocation info for local variables in function 'eeprom_write_dword'
                                    269 ;------------------------------------------------------------
                                    270 ;value         Allocated with name '_eeprom_write_dword_PARM_2'
                                    271 ;addr          Allocated with name '_eeprom_write_dword_addr_10000_99'
                                    272 ;------------------------------------------------------------
                                    273 ;	drivers/eeprom/eeprom_driver.c:64: void eeprom_write_dword(uint32_t *addr, uint32_t value) {
                                    274 ;	-----------------------------------------
                                    275 ;	 function eeprom_write_dword
                                    276 ;	-----------------------------------------
      00500E                        277 _eeprom_write_dword:
      00500E 12 45 5E         [24]  278 	lcall	_ak820_outline_0037
      005011 90 06 A8         [24]  279 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      005014 12 3A 74         [24]  280 	lcall	_ak820_outline_0017
                                    281 ;	drivers/eeprom/eeprom_driver.c:65: EEPROM_LOCAL_WRITE(&value, addr, 4);
      005017 90 06 A8         [24]  282 	mov	dptr,#_eeprom_write_dword_addr_10000_99
      00501A 12 51 1D         [24]  283 	lcall	_ak820_outline_0004
      00501D 74 04            [12]  284 	mov	a,#0x04
      00501F 12 3A E7         [24]  285 	lcall	_ak820_outline_0134
      005022 90 06 A4         [24]  286 	mov	dptr,#_eeprom_write_dword_PARM_2
                                    287 ;	drivers/eeprom/eeprom_driver.c:66: }
      005025 02 43 86         [24]  288 	ljmp	_ak820_eeprom_write_block_xdata
                                    289 ;------------------------------------------------------------
                                    290 ;Allocation info for local variables in function 'eeprom_update_block'
                                    291 ;------------------------------------------------------------
                                    292 ;sloc0         Allocated with name '_eeprom_update_block_sloc0_1_0'
                                    293 ;sloc1         Allocated with name '_eeprom_update_block_sloc1_1_0'
                                    294 ;sloc2         Allocated with name '_eeprom_update_block_sloc2_1_0'
                                    295 ;sloc3         Allocated with name '_eeprom_update_block_sloc3_1_0'
                                    296 ;addr          Allocated with name '_eeprom_update_block_PARM_2'
                                    297 ;len           Allocated with name '_eeprom_update_block_PARM_3'
                                    298 ;buf           Allocated with name '_eeprom_update_block_buf_10000_101'
                                    299 ;source        Allocated with name '_eeprom_update_block_source_10000_102'
                                    300 ;target        Allocated with name '_eeprom_update_block_target_10000_102'
                                    301 ;i             Allocated with name '_eeprom_update_block_i_10000_102'
                                    302 ;------------------------------------------------------------
                                    303 ;	drivers/eeprom/eeprom_driver.c:68: void eeprom_update_block(const void *buf, void *addr, size_t len) {
                                    304 ;	-----------------------------------------
                                    305 ;	 function eeprom_update_byte
                                    306 ;	-----------------------------------------
      005028                        307 _eeprom_update_byte:
      005028 C0 07            [24]  308 	push	ar7
      00502A C0 06            [24]  309 	push	ar6
      00502C C0 05            [24]  310 	push	ar5
      00502E C0 04            [24]  311 	push	ar4
      005030 12 45 5E         [24]  312 	lcall	_ak820_outline_0037
      005033 90 06 AC         [24]  313 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005036 12 3A 74         [24]  314 	lcall	_ak820_outline_0017
                                    315 ;	drivers/eeprom/eeprom_driver.c:83: uint8_t orig = eeprom_read_byte(addr);
      005039 90 06 AC         [24]  316 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      00503C 12 51 0E         [24]  317 	lcall	_ak820_outline_0001
      00503F 12 42 BF         [24]  318 	lcall	_eeprom_read_byte
      005042 AF 82            [24]  319 	mov	r7, dpl
                                    320 ;	drivers/eeprom/eeprom_driver.c:84: if (orig != value) {
      005044 90 06 AB         [24]  321 	mov	dptr,#_eeprom_update_byte_PARM_2
      005047 E0               [24]  322 	movx	a,@dptr
      005048 FE               [12]  323 	mov	r6,a
      005049 EF               [12]  324 	mov	a,r7
      00504A B5 06 02         [24]  325 	cjne	a,ar6,00112$
      00504D 80 35            [24]  326 	sjmp	00103$
      00504F                        327 00112$:
                                    328 ;	drivers/eeprom/eeprom_driver.c:85: eeprom_write_byte(addr, value);
      00504F 90 06 AC         [24]  329 	mov	dptr,#_eeprom_update_byte_addr_10000_107
      005052 12 3A A3         [24]  330 	lcall	_ak820_outline_0059
      005055 A3               [24]  331 	inc	dptr
      005056 E0               [24]  332 	movx	a,@dptr
      005057 FF               [12]  333 	mov	r7,a
      005058 90 06 9B         [24]  334 	mov	dptr,#_eeprom_write_byte_PARM_2
      00505B EE               [12]  335 	mov	a,r6
      00505C 12 3A C1         [24]  336 	lcall	_ak820_outline_0101
      00505F 8F F0            [24]  337 	mov	b, r7
      005061 C0 07            [24]  338 	push	ar7
      005063 C0 06            [24]  339 	push	ar6
      005065 C0 05            [24]  340 	push	ar5
      005067 C0 04            [24]  341 	push	ar4
      005069 C0 03            [24]  342 	push	ar3
      00506B C0 02            [24]  343 	push	ar2
      00506D C0 01            [24]  344 	push	ar1
      00506F C0 00            [24]  345 	push	ar0
      005071 12 4F DC         [24]  346 	lcall	_eeprom_write_byte
      005074 D0 00            [24]  347 	pop	ar0
      005076 D0 01            [24]  348 	pop	ar1
      005078 D0 02            [24]  349 	pop	ar2
      00507A D0 03            [24]  350 	pop	ar3
      00507C D0 04            [24]  351 	pop	ar4
      00507E D0 05            [24]  352 	pop	ar5
      005080 D0 06            [24]  353 	pop	ar6
      005082 D0 07            [24]  354 	pop	ar7
      005084                        355 00103$:
                                    356 ;	drivers/eeprom/eeprom_driver.c:87: }
      005084 D0 04            [24]  357 	pop	ar4
      005086 D0 05            [24]  358 	pop	ar5
      005088 D0 06            [24]  359 	pop	ar6
      00508A D0 07            [24]  360 	pop	ar7
      00508C 22               [24]  361 	ret
                                    362 ;------------------------------------------------------------
                                    363 ;Allocation info for local variables in function 'eeprom_update_word'
                                    364 ;------------------------------------------------------------
                                    365 ;value         Allocated with name '_eeprom_update_word_PARM_2'
                                    366 ;addr          Allocated with name '_eeprom_update_word_addr_10000_111'
                                    367 ;orig          Allocated with name '_eeprom_update_word_orig_10000_112'
                                    368 ;------------------------------------------------------------
                                    369 ;	drivers/eeprom/eeprom_driver.c:89: void eeprom_update_word(uint16_t *addr, uint16_t value) {
                                    370 ;	-----------------------------------------
                                    371 ;	 function eeprom_update_word
                                    372 ;	-----------------------------------------
      00508D                        373 _eeprom_update_word:
      00508D 12 45 5E         [24]  374 	lcall	_ak820_outline_0037
      005090 90 06 B1         [24]  375 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005093 12 3A 74         [24]  376 	lcall	_ak820_outline_0017
                                    377 ;	drivers/eeprom/eeprom_driver.c:90: uint16_t orig = eeprom_read_word(addr);
      005096 90 06 B1         [24]  378 	mov	dptr,#_eeprom_update_word_addr_10000_111
      005099 12 51 0E         [24]  379 	lcall	_ak820_outline_0001
      00509C 12 4F 7C         [24]  380 	lcall	_eeprom_read_word
      00509F 12 45 A7         [24]  381 	lcall	_ak820_outline_0133
                                    382 ;	drivers/eeprom/eeprom_driver.c:91: if (orig != value) {
      0050A2 90 06 AF         [24]  383 	mov	dptr,#_eeprom_update_word_PARM_2
      0050A5 12 3A A3         [24]  384 	lcall	_ak820_outline_0059
      0050A8 EE               [12]  385 	mov	a,r6
      0050A9 B5 04 05         [24]  386 	cjne	a,ar4,00112$
      0050AC EF               [12]  387 	mov	a,r7
      0050AD B5 05 01         [24]  388 	cjne	a,ar5,00112$
      0050B0 22               [24]  389 	ret
      0050B1                        390 00112$:
                                    391 ;	drivers/eeprom/eeprom_driver.c:92: eeprom_write_word(addr, value);
      0050B1 90 06 B1         [24]  392 	mov	dptr,#_eeprom_update_word_addr_10000_111
      0050B4 E0               [24]  393 	movx	a,@dptr
      0050B5 FB               [12]  394 	mov	r3,a
      0050B6 A3               [24]  395 	inc	dptr
      0050B7 12 3A 8C         [24]  396 	lcall	_ak820_outline_0051
      0050BA 90 06 9F         [24]  397 	mov	dptr,#_eeprom_write_word_PARM_2
      0050BD 12 3A A9         [24]  398 	lcall	_ak820_outline_0072
      0050C0 8B 82            [24]  399 	mov	dpl, r3
      0050C2 8E 83            [24]  400 	mov	dph, r6
      0050C4 8F F0            [24]  401 	mov	b, r7
                                    402 ;	drivers/eeprom/eeprom_driver.c:94: }
      0050C6 02 4F F6         [24]  403 	ljmp	_eeprom_write_word
                                    404 ;------------------------------------------------------------
                                    405 ;Allocation info for local variables in function 'eeprom_update_dword'
                                    406 ;------------------------------------------------------------
                                    407 ;value         Allocated with name '_eeprom_update_dword_PARM_2'
                                    408 ;addr          Allocated with name '_eeprom_update_dword_addr_10000_115'
                                    409 ;orig          Allocated with name '_eeprom_update_dword_orig_10000_116'
                                    410 ;------------------------------------------------------------
                                    411 ;	drivers/eeprom/eeprom_driver.c:96: void eeprom_update_dword(uint32_t *addr, uint32_t value) {
                                    412 ;	-----------------------------------------
                                    413 ;	 function eeprom_update_dword
                                    414 ;	-----------------------------------------
      0050C9                        415 _eeprom_update_dword:
      0050C9 12 45 5E         [24]  416 	lcall	_ak820_outline_0037
      0050CC 90 06 B8         [24]  417 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0050CF 12 3A 74         [24]  418 	lcall	_ak820_outline_0017
                                    419 ;	drivers/eeprom/eeprom_driver.c:97: uint32_t orig = eeprom_read_dword(addr);
      0050D2 90 06 B8         [24]  420 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0050D5 12 51 0E         [24]  421 	lcall	_ak820_outline_0001
      0050D8 12 4F AB         [24]  422 	lcall	_eeprom_read_dword
      0050DB 12 51 5F         [24]  423 	lcall	_ak820_outline_0056
                                    424 ;	drivers/eeprom/eeprom_driver.c:98: if (orig != value) {
      0050DE 90 06 B4         [24]  425 	mov	dptr,#_eeprom_update_dword_PARM_2
      0050E1 E0               [24]  426 	movx	a,@dptr
      0050E2 F8               [12]  427 	mov	r0,a
      0050E3 A3               [24]  428 	inc	dptr
      0050E4 12 51 67         [24]  429 	lcall	_ak820_outline_0091
      0050E7 EC               [12]  430 	mov	a,r4
      0050E8 B5 00 0D         [24]  431 	cjne	a,ar0,00112$
      0050EB ED               [12]  432 	mov	a,r5
      0050EC B5 01 09         [24]  433 	cjne	a,ar1,00112$
      0050EF EE               [12]  434 	mov	a,r6
      0050F0 B5 02 05         [24]  435 	cjne	a,ar2,00112$
      0050F3 EF               [12]  436 	mov	a,r7
      0050F4 B5 03 01         [24]  437 	cjne	a,ar3,00112$
      0050F7 22               [24]  438 	ret
      0050F8                        439 00112$:
                                    440 ;	drivers/eeprom/eeprom_driver.c:99: eeprom_write_dword(addr, value);
      0050F8 90 06 B8         [24]  441 	mov	dptr,#_eeprom_update_dword_addr_10000_115
      0050FB 12 51 34         [24]  442 	lcall	_ak820_outline_0012
      0050FE 90 06 A4         [24]  443 	mov	dptr,#_eeprom_write_dword_PARM_2
      005101 E8               [12]  444 	mov	a,r0
      005102 F0               [24]  445 	movx	@dptr,a
      005103 E9               [12]  446 	mov	a,r1
      005104 A3               [24]  447 	inc	dptr
      005105 12 51 80         [24]  448 	lcall	_ak820_outline_0155
      005108 12 51 3D         [24]  449 	lcall	_ak820_outline_0034
                                    450 ;	drivers/eeprom/eeprom_driver.c:101: }
      00510B 02 50 0E         [24]  451 	ljmp	_eeprom_write_dword
                                    452 	.area CSEG    (CODE)
                                    453 	.area CONST   (CODE)
                                    454 	.area XINIT   (CODE)
                                    455 	.area CABS    (ABS,CODE)
                                    456 
                                    457 ; Experimental exact instruction outlining.
                                    458 	.globl _ak820_outline_0001
                                    459 	.globl _ak820_outline_0004
                                    460 	.globl _ak820_outline_0012
                                    461 	.globl _ak820_outline_0017
                                    462 	.globl _ak820_outline_0034
                                    463 	.globl _ak820_outline_0037
                                    464 	.globl _ak820_outline_0050
                                    465 	.globl _ak820_outline_0051
                                    466 	.globl _ak820_outline_0054
                                    467 	.globl _ak820_outline_0056
                                    468 	.globl _ak820_outline_0059
                                    469 	.globl _ak820_outline_0072
                                    470 	.globl _ak820_outline_0091
                                    471 	.globl _ak820_outline_0092
                                    472 	.globl _ak820_outline_0101
                                    473 	.globl _ak820_outline_0110
                                    474 	.globl _ak820_outline_0133
                                    475 	.globl _ak820_outline_0134
                                    476 	.globl _ak820_outline_0155
                                    477 	.globl _ak820_outline_0182
                                    478 
                                    479 	.area CSEG (CODE)
                                    480 ; function ak820_outline_0001
      00510E                        481 _ak820_outline_0001:
      00510E E0               [24]  482 	movx	a,@dptr
      00510F FD               [12]  483 	mov	r5,a
      005110 A3               [24]  484 	inc	dptr
      005111 E0               [24]  485 	movx	a,@dptr
      005112 FE               [12]  486 	mov	r6,a
      005113 A3               [24]  487 	inc	dptr
      005114 E0               [24]  488 	movx	a,@dptr
      005115 FF               [12]  489 	mov	r7,a
      005116 8D 82            [24]  490 	mov	dpl,r5
      005118 8E 83            [24]  491 	mov	dph,r6
      00511A 8F F0            [24]  492 	mov	b,r7
      00511C 22               [24]  493 	ret
                                    494 
                                    495 	.area CSEG (CODE)
                                    496 ; function ak820_outline_0004
      00511D                        497 _ak820_outline_0004:
      00511D E0               [24]  498 	movx	a,@dptr
      00511E FD               [12]  499 	mov	r5,a
      00511F A3               [24]  500 	inc	dptr
      005120 E0               [24]  501 	movx	a,@dptr
      005121 FE               [12]  502 	mov	r6,a
      005122 A3               [24]  503 	inc	dptr
      005123 E0               [24]  504 	movx	a,@dptr
      005124 FF               [12]  505 	mov	r7,a
      005125 90 05 9E         [24]  506 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      005128 ED               [12]  507 	mov	a,r5
      005129 F0               [24]  508 	movx	@dptr,a
      00512A EE               [12]  509 	mov	a,r6
      00512B A3               [24]  510 	inc	dptr
      00512C F0               [24]  511 	movx	@dptr,a
      00512D EF               [12]  512 	mov	a,r7
      00512E A3               [24]  513 	inc	dptr
      00512F F0               [24]  514 	movx	@dptr,a
      005130 90 05 A1         [24]  515 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      005133 22               [24]  516 	ret
                                    517 
                                    518 	.area CSEG (CODE)
                                    519 ; function ak820_outline_0012
      005134                        520 _ak820_outline_0012:
      005134 E0               [24]  521 	movx	a,@dptr
      005135 FD               [12]  522 	mov	r5,a
      005136 A3               [24]  523 	inc	dptr
      005137 E0               [24]  524 	movx	a,@dptr
      005138 FE               [12]  525 	mov	r6,a
      005139 A3               [24]  526 	inc	dptr
      00513A E0               [24]  527 	movx	a,@dptr
      00513B FF               [12]  528 	mov	r7,a
      00513C 22               [24]  529 	ret
                                    530 
                                    531 	.area CSEG (CODE)
                                    532 ; function ak820_outline_0034
      00513D                        533 _ak820_outline_0034:
      00513D F0               [24]  534 	movx	@dptr,a
      00513E 8D 82            [24]  535 	mov	dpl,r5
      005140 8E 83            [24]  536 	mov	dph,r6
      005142 8F F0            [24]  537 	mov	b,r7
      005144 22               [24]  538 	ret
                                    539 
                                    540 	.area CSEG (CODE)
                                    541 ; function ak820_outline_0050
      005145                        542 _ak820_outline_0050:
      005145 E4               [12]  543 	clr	a
      005146 F0               [24]  544 	movx	@dptr,a
      005147 A3               [24]  545 	inc	dptr
      005148 F0               [24]  546 	movx	@dptr,a
      005149 A3               [24]  547 	inc	dptr
      00514A F0               [24]  548 	movx	@dptr,a
      00514B A3               [24]  549 	inc	dptr
      00514C F0               [24]  550 	movx	@dptr,a
      00514D 22               [24]  551 	ret
                                    552 
                                    553 	.area CSEG (CODE)
                                    554 ; function ak820_outline_0054
      00514E                        555 _ak820_outline_0054:
      00514E E0               [24]  556 	movx	a,@dptr
      00514F FC               [12]  557 	mov	r4,a
      005150 A3               [24]  558 	inc	dptr
      005151 E0               [24]  559 	movx	a,@dptr
      005152 FD               [12]  560 	mov	r5,a
      005153 A3               [24]  561 	inc	dptr
      005154 E0               [24]  562 	movx	a,@dptr
      005155 FE               [12]  563 	mov	r6,a
      005156 A3               [24]  564 	inc	dptr
      005157 E0               [24]  565 	movx	a,@dptr
      005158 8C 82            [24]  566 	mov	dpl,r4
      00515A 8D 83            [24]  567 	mov	dph,r5
      00515C 8E F0            [24]  568 	mov	b,r6
      00515E 22               [24]  569 	ret
                                    570 
                                    571 	.area CSEG (CODE)
                                    572 ; function ak820_outline_0056
      00515F                        573 _ak820_outline_0056:
      00515F AC 82            [24]  574 	mov	r4,dpl
      005161 AD 83            [24]  575 	mov	r5,dph
      005163 AE F0            [24]  576 	mov	r6,b
      005165 FF               [12]  577 	mov	r7,a
      005166 22               [24]  578 	ret
                                    579 
                                    580 	.area CSEG (CODE)
                                    581 ; function ak820_outline_0091
      005167                        582 _ak820_outline_0091:
      005167 E0               [24]  583 	movx	a,@dptr
      005168 F9               [12]  584 	mov	r1,a
      005169 A3               [24]  585 	inc	dptr
      00516A E0               [24]  586 	movx	a,@dptr
      00516B FA               [12]  587 	mov	r2,a
      00516C A3               [24]  588 	inc	dptr
      00516D E0               [24]  589 	movx	a,@dptr
      00516E FB               [12]  590 	mov	r3,a
      00516F 22               [24]  591 	ret
                                    592 
                                    593 	.area CSEG (CODE)
                                    594 ; function ak820_outline_0092
      005170                        595 _ak820_outline_0092:
      005170 E0               [24]  596 	movx	a,@dptr
      005171 FE               [12]  597 	mov	r6,a
      005172 A3               [24]  598 	inc	dptr
      005173 E0               [24]  599 	movx	a,@dptr
      005174 8E 82            [24]  600 	mov	dpl,r6
      005176 F5 83            [12]  601 	mov	dph,a
      005178 22               [24]  602 	ret
                                    603 
                                    604 	.area CSEG (CODE)
                                    605 ; function ak820_outline_0110
      005179                        606 _ak820_outline_0110:
      005179 74 02            [12]  607 	mov	a,#0x02
      00517B F0               [24]  608 	movx	@dptr,a
      00517C E4               [12]  609 	clr	a
      00517D A3               [24]  610 	inc	dptr
      00517E F0               [24]  611 	movx	@dptr,a
      00517F 22               [24]  612 	ret
                                    613 
                                    614 	.area CSEG (CODE)
                                    615 ; function ak820_outline_0155
      005180                        616 _ak820_outline_0155:
      005180 F0               [24]  617 	movx	@dptr,a
      005181 EA               [12]  618 	mov	a,r2
      005182 A3               [24]  619 	inc	dptr
      005183 F0               [24]  620 	movx	@dptr,a
      005184 EB               [12]  621 	mov	a,r3
      005185 A3               [24]  622 	inc	dptr
      005186 22               [24]  623 	ret
                                    624 
                                    625 	.area CSEG (CODE)
                                    626 ; function ak820_outline_0182
      005187                        627 _ak820_outline_0182:
      005187 E4               [12]  628 	clr	a
      005188 F0               [24]  629 	movx	@dptr,a
      005189 A3               [24]  630 	inc	dptr
      00518A F0               [24]  631 	movx	@dptr,a
      00518B 22               [24]  632 	ret
