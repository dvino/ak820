                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module action
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _ak820_combo_cancel
                                     12 	.globl _ak820_combo_tick
                                     13 	.globl _ak820_autoshift_cancel
                                     14 	.globl _ak820_autoshift_process
                                     15 	.globl _ak820_autoshift_before
                                     16 	.globl _ak820_oneshot_cancel
                                     17 	.globl _ak820_oneshot_post
                                     18 	.globl _ak820_oneshot_process
                                     19 	.globl _ak820_tapping_source
                                     20 	.globl _ak820_tapping_cancel
                                     21 	.globl _ak820_tapping_process
                                     22 	.globl _ak820_tapping_before
                                     23 	.globl _pre_process_record_quantum
                                     24 	.globl _get_record_keycode
                                     25 	.globl _repeat_key_cancel
                                     26 	.globl _clear_owned_usages
                                     27 	.globl _owned_usage_key
                                     28 	.globl _clear_owned_keys
                                     29 	.globl _del_owned_key
                                     30 	.globl _add_owned_key
                                     31 	.globl _clear_owned_mods
                                     32 	.globl _del_owned_weak_mods
                                     33 	.globl _add_owned_weak_mods
                                     34 	.globl _del_owned_mods
                                     35 	.globl _add_owned_mods
                                     36 	.globl _clear_weak_mods
                                     37 	.globl _clear_mods
                                     38 	.globl _send_keyboard_report
                                     39 	.globl _layer_hold_clear
                                     40 	.globl _layer_hold_off
                                     41 	.globl _layer_hold_on
                                     42 	.globl _ak820_resolve_key
                                     43 	.globl _layer_xor
                                     44 	.globl _layer_and
                                     45 	.globl _layer_or
                                     46 	.globl _layer_off
                                     47 	.globl _layer_on
                                     48 	.globl _layer_move
                                     49 	.globl _layer_clear
                                     50 	.globl _layer_state_set
                                     51 	.globl _default_layer_xor
                                     52 	.globl _default_layer_and
                                     53 	.globl _default_layer_or
                                     54 	.globl _default_layer_set
                                     55 	.globl _post_process_record_quantum
                                     56 	.globl _process_record_quantum
                                     57 	.globl _action_for_keycode
                                     58 	.globl _mDelaymS
                                     59 	.globl _host_consumer_send
                                     60 	.globl _host_system_send
                                     61 	.globl _host_keyboard_leds
                                     62 	.globl _led_set
                                     63 	.globl _clear_keys_from_report
                                     64 	.globl ___memcpy
                                     65 	.globl _ADC_START
                                     66 	.globl _S0_R_FIFO
                                     67 	.globl _S0_T_FIFO
                                     68 	.globl _S0_FREE
                                     69 	.globl _S0_IF_BYTE
                                     70 	.globl _S0_IF_FIRST
                                     71 	.globl _S0_IF_OV
                                     72 	.globl _S0_FST_ACT
                                     73 	.globl _CP_RL2
                                     74 	.globl _C_T2
                                     75 	.globl _TR2
                                     76 	.globl _EXEN2
                                     77 	.globl _TCLK
                                     78 	.globl _RCLK
                                     79 	.globl _EXF2
                                     80 	.globl _CAP1F
                                     81 	.globl _TF2
                                     82 	.globl _RI
                                     83 	.globl _TI
                                     84 	.globl _RB8
                                     85 	.globl _TB8
                                     86 	.globl _REN
                                     87 	.globl _SM2
                                     88 	.globl _SM1
                                     89 	.globl _SM0
                                     90 	.globl _IT0
                                     91 	.globl _IE0
                                     92 	.globl _IT1
                                     93 	.globl _IE1
                                     94 	.globl _TR0
                                     95 	.globl _TF0
                                     96 	.globl _TR1
                                     97 	.globl _TF1
                                     98 	.globl _P4_0
                                     99 	.globl _P4_1
                                    100 	.globl _P4_2
                                    101 	.globl _P4_3
                                    102 	.globl _P4_4
                                    103 	.globl _P4_5
                                    104 	.globl _P4_6
                                    105 	.globl _RXD
                                    106 	.globl _TXD
                                    107 	.globl _INT0
                                    108 	.globl _INT1
                                    109 	.globl _T0
                                    110 	.globl _T1
                                    111 	.globl _MOSI1
                                    112 	.globl _MISO1
                                    113 	.globl _SCK1
                                    114 	.globl _P3_0
                                    115 	.globl _P3_1
                                    116 	.globl _P3_2
                                    117 	.globl _P3_3
                                    118 	.globl _P3_4
                                    119 	.globl _P3_5
                                    120 	.globl _P3_6
                                    121 	.globl _P3_7
                                    122 	.globl _CAP1_
                                    123 	.globl _T2_
                                    124 	.globl _CAP2_
                                    125 	.globl _T2EX_
                                    126 	.globl _RXD1
                                    127 	.globl _TXD1
                                    128 	.globl _P2_0
                                    129 	.globl _P2_1
                                    130 	.globl _P2_2
                                    131 	.globl _P2_3
                                    132 	.globl _P2_4
                                    133 	.globl _P2_5
                                    134 	.globl _P2_6
                                    135 	.globl _P2_7
                                    136 	.globl _AIN0
                                    137 	.globl _AIN1
                                    138 	.globl _AIN2
                                    139 	.globl _AIN3
                                    140 	.globl _AIN4
                                    141 	.globl _AIN5
                                    142 	.globl _AIN6
                                    143 	.globl _AIN7
                                    144 	.globl _CAP1
                                    145 	.globl _T2
                                    146 	.globl _CAP2
                                    147 	.globl _T2EX
                                    148 	.globl _INT0_
                                    149 	.globl _SCS
                                    150 	.globl _MOSI
                                    151 	.globl _MISO
                                    152 	.globl _SCK
                                    153 	.globl _RXD1_
                                    154 	.globl _TXD1_
                                    155 	.globl _P1_0
                                    156 	.globl _P1_1
                                    157 	.globl _P1_2
                                    158 	.globl _P1_3
                                    159 	.globl _P1_4
                                    160 	.globl _P1_5
                                    161 	.globl _P1_6
                                    162 	.globl _P1_7
                                    163 	.globl _AIN8
                                    164 	.globl _AIN9
                                    165 	.globl _AIN10
                                    166 	.globl _AIN11
                                    167 	.globl _AIN12
                                    168 	.globl _AIN13
                                    169 	.globl _RXD_
                                    170 	.globl _TXD_
                                    171 	.globl _SCL0
                                    172 	.globl _SDA0
                                    173 	.globl _P0_0
                                    174 	.globl _P0_1
                                    175 	.globl _P0_2
                                    176 	.globl _P0_3
                                    177 	.globl _P0_4
                                    178 	.globl _P0_5
                                    179 	.globl _P0_6
                                    180 	.globl _P0_7
                                    181 	.globl _IE_SPI0
                                    182 	.globl _IE_USB
                                    183 	.globl _IE_ADC
                                    184 	.globl _IE_UART1
                                    185 	.globl _IE_PWM_I2C
                                    186 	.globl _IE_GPIO
                                    187 	.globl _IE_WDOG
                                    188 	.globl _PX0
                                    189 	.globl _PT0
                                    190 	.globl _PX1
                                    191 	.globl _PT1
                                    192 	.globl _PS
                                    193 	.globl _PT2
                                    194 	.globl _PL_FLAG
                                    195 	.globl _PH_FLAG
                                    196 	.globl _EX0
                                    197 	.globl _ET0
                                    198 	.globl _EX1
                                    199 	.globl _ET1
                                    200 	.globl _ES
                                    201 	.globl _ET2
                                    202 	.globl _E_DIS
                                    203 	.globl _EA
                                    204 	.globl _P
                                    205 	.globl _F1
                                    206 	.globl _OV
                                    207 	.globl _RS0
                                    208 	.globl _RS1
                                    209 	.globl _F0
                                    210 	.globl _AC
                                    211 	.globl _CY
                                    212 	.globl _I2CS_INT_ST
                                    213 	.globl _I2CX_INT
                                    214 	.globl _LED_STATUS
                                    215 	.globl _LED_DMA_H
                                    216 	.globl _LED_DMA_L
                                    217 	.globl _LED_DMA
                                    218 	.globl _LED_PWM_OE
                                    219 	.globl _LED_COMMON
                                    220 	.globl _ADC_CHAN
                                    221 	.globl _ADC_DAT_H
                                    222 	.globl _ADC_DAT_L
                                    223 	.globl _ADC_DAT
                                    224 	.globl _ADC_CTRL
                                    225 	.globl _SPI1_CK_SE
                                    226 	.globl _SPI1_CTRL
                                    227 	.globl _SPI1_DATA
                                    228 	.globl _SPI1_STAT
                                    229 	.globl _SIF1
                                    230 	.globl _SBAUD1
                                    231 	.globl _SBUF1
                                    232 	.globl _SCON1
                                    233 	.globl _SPI0_SETUP
                                    234 	.globl _SPI0_CK_SE
                                    235 	.globl _SPI0_CTRL
                                    236 	.globl _SPI0_DATA
                                    237 	.globl _SPI0_STAT
                                    238 	.globl _T2CAP1H
                                    239 	.globl _T2CAP1L
                                    240 	.globl _T2CAP1
                                    241 	.globl _TH2
                                    242 	.globl _TL2
                                    243 	.globl _T2COUNT
                                    244 	.globl _RCAP2H
                                    245 	.globl _RCAP2L
                                    246 	.globl _RCAP2
                                    247 	.globl _T2MOD
                                    248 	.globl _T2CON
                                    249 	.globl _SBUF
                                    250 	.globl _SCON
                                    251 	.globl _TH1
                                    252 	.globl _TH0
                                    253 	.globl _TL1
                                    254 	.globl _TL0
                                    255 	.globl _TMOD
                                    256 	.globl _TCON
                                    257 	.globl _XBUS_AUX
                                    258 	.globl _P7
                                    259 	.globl _P6_DIR
                                    260 	.globl _P6_OUT_PU
                                    261 	.globl _P6_IN
                                    262 	.globl _P5_DIR
                                    263 	.globl _P5_OUT_PU
                                    264 	.globl _P5_IN
                                    265 	.globl _P4_LED_KEY
                                    266 	.globl _P4_DIR_PU
                                    267 	.globl _P4_MOD_OC
                                    268 	.globl _P4
                                    269 	.globl _P3_DIR_PU
                                    270 	.globl _P3_MOD_OC
                                    271 	.globl _P3
                                    272 	.globl _P2_DIR_PU
                                    273 	.globl _P2_MOD_OC
                                    274 	.globl _P2
                                    275 	.globl _P1_DIR_PU
                                    276 	.globl _P1_MOD_OC
                                    277 	.globl _P1
                                    278 	.globl _P0_DIR_PU
                                    279 	.globl _P0_MOD_OC
                                    280 	.globl _P0
                                    281 	.globl _ROM_CTRL
                                    282 	.globl _ROM_DATA_HH
                                    283 	.globl _ROM_DATA_HL
                                    284 	.globl _ROM_DATA_HI
                                    285 	.globl _ROM_ADDR_H
                                    286 	.globl _ROM_ADDR_L
                                    287 	.globl _ROM_ADDR
                                    288 	.globl _GPIO_IE
                                    289 	.globl _IP_EX
                                    290 	.globl _IE_EX
                                    291 	.globl _IP
                                    292 	.globl _IE
                                    293 	.globl _WDOG_COUNT
                                    294 	.globl _RESET_KEEP
                                    295 	.globl _WAKE_CTRL
                                    296 	.globl _CLOCK_CFG
                                    297 	.globl _POWER_CFG
                                    298 	.globl _PCON
                                    299 	.globl _GLOBAL_CFG
                                    300 	.globl _SAFE_MOD
                                    301 	.globl _DPH
                                    302 	.globl _DPL
                                    303 	.globl _SP
                                    304 	.globl _A_INV
                                    305 	.globl _B
                                    306 	.globl _ACC
                                    307 	.globl _PSW
                                    308 	.globl _disable_action_cache
                                    309 	.globl _tap_code_delay_PARM_2
                                    310 	.globl _process_action_PARM_2
                                    311 	.globl _action_exec_PARM_1
                                    312 	.globl _tp_buttons
                                    313 	.globl _action_exec
                                    314 	.globl _ak820_action_exec
                                    315 	.globl _process_record
                                    316 	.globl _process_record_handler
                                    317 	.globl _process_action
                                    318 	.globl _register_code
                                    319 	.globl _unregister_code
                                    320 	.globl _tap_code_delay
                                    321 	.globl _tap_code
                                    322 	.globl _register_mods
                                    323 	.globl _unregister_mods
                                    324 	.globl _register_weak_mods
                                    325 	.globl _unregister_weak_mods
                                    326 	.globl _clear_keyboard
                                    327 	.globl _clear_keyboard_but_mods
                                    328 	.globl _clear_keyboard_but_mods_and_keys
                                    329 ;--------------------------------------------------------
                                    330 ; special function registers
                                    331 ;--------------------------------------------------------
                                    332 	.area RSEG    (ABS,DATA)
      000000                        333 	.org 0x0000
                           0000D0   334 _PSW	=	0x00d0
                           0000E0   335 _ACC	=	0x00e0
                           0000F0   336 _B	=	0x00f0
                           0000FD   337 _A_INV	=	0x00fd
                           000081   338 _SP	=	0x0081
                           000082   339 _DPL	=	0x0082
                           000083   340 _DPH	=	0x0083
                           0000A1   341 _SAFE_MOD	=	0x00a1
                           0000B1   342 _GLOBAL_CFG	=	0x00b1
                           000087   343 _PCON	=	0x0087
                           0000BA   344 _POWER_CFG	=	0x00ba
                           0000B9   345 _CLOCK_CFG	=	0x00b9
                           0000A9   346 _WAKE_CTRL	=	0x00a9
                           0000FE   347 _RESET_KEEP	=	0x00fe
                           0000FF   348 _WDOG_COUNT	=	0x00ff
                           0000A8   349 _IE	=	0x00a8
                           0000B8   350 _IP	=	0x00b8
                           0000E8   351 _IE_EX	=	0x00e8
                           0000E9   352 _IP_EX	=	0x00e9
                           0000B2   353 _GPIO_IE	=	0x00b2
                           008584   354 _ROM_ADDR	=	0x8584
                           000084   355 _ROM_ADDR_L	=	0x0084
                           000085   356 _ROM_ADDR_H	=	0x0085
                           008F8E   357 _ROM_DATA_HI	=	0x8f8e
                           00008E   358 _ROM_DATA_HL	=	0x008e
                           00008F   359 _ROM_DATA_HH	=	0x008f
                           000086   360 _ROM_CTRL	=	0x0086
                           000080   361 _P0	=	0x0080
                           0000C4   362 _P0_MOD_OC	=	0x00c4
                           0000C5   363 _P0_DIR_PU	=	0x00c5
                           000090   364 _P1	=	0x0090
                           000092   365 _P1_MOD_OC	=	0x0092
                           000093   366 _P1_DIR_PU	=	0x0093
                           0000A0   367 _P2	=	0x00a0
                           000094   368 _P2_MOD_OC	=	0x0094
                           000095   369 _P2_DIR_PU	=	0x0095
                           0000B0   370 _P3	=	0x00b0
                           000096   371 _P3_MOD_OC	=	0x0096
                           000097   372 _P3_DIR_PU	=	0x0097
                           0000C0   373 _P4	=	0x00c0
                           0000C2   374 _P4_MOD_OC	=	0x00c2
                           0000C3   375 _P4_DIR_PU	=	0x00c3
                           0000C1   376 _P4_LED_KEY	=	0x00c1
                           0000AA   377 _P5_IN	=	0x00aa
                           0000AB   378 _P5_OUT_PU	=	0x00ab
                           0000AC   379 _P5_DIR	=	0x00ac
                           0000AD   380 _P6_IN	=	0x00ad
                           0000AE   381 _P6_OUT_PU	=	0x00ae
                           0000AF   382 _P6_DIR	=	0x00af
                           0000F1   383 _P7	=	0x00f1
                           0000A2   384 _XBUS_AUX	=	0x00a2
                           000088   385 _TCON	=	0x0088
                           000089   386 _TMOD	=	0x0089
                           00008A   387 _TL0	=	0x008a
                           00008B   388 _TL1	=	0x008b
                           00008C   389 _TH0	=	0x008c
                           00008D   390 _TH1	=	0x008d
                           000098   391 _SCON	=	0x0098
                           000099   392 _SBUF	=	0x0099
                           0000C8   393 _T2CON	=	0x00c8
                           0000C9   394 _T2MOD	=	0x00c9
                           00CBCA   395 _RCAP2	=	0xcbca
                           0000CA   396 _RCAP2L	=	0x00ca
                           0000CB   397 _RCAP2H	=	0x00cb
                           00CDCC   398 _T2COUNT	=	0xcdcc
                           0000CC   399 _TL2	=	0x00cc
                           0000CD   400 _TH2	=	0x00cd
                           00CFCE   401 _T2CAP1	=	0xcfce
                           0000CE   402 _T2CAP1L	=	0x00ce
                           0000CF   403 _T2CAP1H	=	0x00cf
                           0000F8   404 _SPI0_STAT	=	0x00f8
                           0000F9   405 _SPI0_DATA	=	0x00f9
                           0000FA   406 _SPI0_CTRL	=	0x00fa
                           0000FB   407 _SPI0_CK_SE	=	0x00fb
                           0000FC   408 _SPI0_SETUP	=	0x00fc
                           0000BC   409 _SCON1	=	0x00bc
                           0000BD   410 _SBUF1	=	0x00bd
                           0000BE   411 _SBAUD1	=	0x00be
                           0000BF   412 _SIF1	=	0x00bf
                           0000B4   413 _SPI1_STAT	=	0x00b4
                           0000B5   414 _SPI1_DATA	=	0x00b5
                           0000B6   415 _SPI1_CTRL	=	0x00b6
                           0000B7   416 _SPI1_CK_SE	=	0x00b7
                           0000F3   417 _ADC_CTRL	=	0x00f3
                           00F5F4   418 _ADC_DAT	=	0xf5f4
                           0000F4   419 _ADC_DAT_L	=	0x00f4
                           0000F5   420 _ADC_DAT_H	=	0x00f5
                           0000F6   421 _ADC_CHAN	=	0x00f6
                           0000A6   422 _LED_COMMON	=	0x00a6
                           0000A7   423 _LED_PWM_OE	=	0x00a7
                           00C7C6   424 _LED_DMA	=	0xc7c6
                           0000C6   425 _LED_DMA_L	=	0x00c6
                           0000C7   426 _LED_DMA_H	=	0x00c7
                           0000F7   427 _LED_STATUS	=	0x00f7
                           0000B3   428 _I2CX_INT	=	0x00b3
                           0000BB   429 _I2CS_INT_ST	=	0x00bb
                                    430 ;--------------------------------------------------------
                                    431 ; special function bits
                                    432 ;--------------------------------------------------------
                                    433 	.area RSEG    (ABS,DATA)
      000000                        434 	.org 0x0000
                           0000D7   435 _CY	=	0x00d7
                           0000D6   436 _AC	=	0x00d6
                           0000D5   437 _F0	=	0x00d5
                           0000D4   438 _RS1	=	0x00d4
                           0000D3   439 _RS0	=	0x00d3
                           0000D2   440 _OV	=	0x00d2
                           0000D1   441 _F1	=	0x00d1
                           0000D0   442 _P	=	0x00d0
                           0000AF   443 _EA	=	0x00af
                           0000AE   444 _E_DIS	=	0x00ae
                           0000AD   445 _ET2	=	0x00ad
                           0000AC   446 _ES	=	0x00ac
                           0000AB   447 _ET1	=	0x00ab
                           0000AA   448 _EX1	=	0x00aa
                           0000A9   449 _ET0	=	0x00a9
                           0000A8   450 _EX0	=	0x00a8
                           0000BF   451 _PH_FLAG	=	0x00bf
                           0000BE   452 _PL_FLAG	=	0x00be
                           0000BD   453 _PT2	=	0x00bd
                           0000BC   454 _PS	=	0x00bc
                           0000BB   455 _PT1	=	0x00bb
                           0000BA   456 _PX1	=	0x00ba
                           0000B9   457 _PT0	=	0x00b9
                           0000B8   458 _PX0	=	0x00b8
                           0000EF   459 _IE_WDOG	=	0x00ef
                           0000EE   460 _IE_GPIO	=	0x00ee
                           0000ED   461 _IE_PWM_I2C	=	0x00ed
                           0000EC   462 _IE_UART1	=	0x00ec
                           0000EB   463 _IE_ADC	=	0x00eb
                           0000E9   464 _IE_USB	=	0x00e9
                           0000E8   465 _IE_SPI0	=	0x00e8
                           000087   466 _P0_7	=	0x0087
                           000086   467 _P0_6	=	0x0086
                           000085   468 _P0_5	=	0x0085
                           000084   469 _P0_4	=	0x0084
                           000083   470 _P0_3	=	0x0083
                           000082   471 _P0_2	=	0x0082
                           000081   472 _P0_1	=	0x0081
                           000080   473 _P0_0	=	0x0080
                           000081   474 _SDA0	=	0x0081
                           000080   475 _SCL0	=	0x0080
                           000083   476 _TXD_	=	0x0083
                           000082   477 _RXD_	=	0x0082
                           000085   478 _AIN13	=	0x0085
                           000084   479 _AIN12	=	0x0084
                           000083   480 _AIN11	=	0x0083
                           000082   481 _AIN10	=	0x0082
                           000081   482 _AIN9	=	0x0081
                           000080   483 _AIN8	=	0x0080
                           000097   484 _P1_7	=	0x0097
                           000096   485 _P1_6	=	0x0096
                           000095   486 _P1_5	=	0x0095
                           000094   487 _P1_4	=	0x0094
                           000093   488 _P1_3	=	0x0093
                           000092   489 _P1_2	=	0x0092
                           000091   490 _P1_1	=	0x0091
                           000090   491 _P1_0	=	0x0090
                           000097   492 _TXD1_	=	0x0097
                           000096   493 _RXD1_	=	0x0096
                           000097   494 _SCK	=	0x0097
                           000096   495 _MISO	=	0x0096
                           000095   496 _MOSI	=	0x0095
                           000094   497 _SCS	=	0x0094
                           000092   498 _INT0_	=	0x0092
                           000091   499 _T2EX	=	0x0091
                           000091   500 _CAP2	=	0x0091
                           000090   501 _T2	=	0x0090
                           000090   502 _CAP1	=	0x0090
                           000097   503 _AIN7	=	0x0097
                           000096   504 _AIN6	=	0x0096
                           000095   505 _AIN5	=	0x0095
                           000094   506 _AIN4	=	0x0094
                           000093   507 _AIN3	=	0x0093
                           000092   508 _AIN2	=	0x0092
                           000091   509 _AIN1	=	0x0091
                           000090   510 _AIN0	=	0x0090
                           0000A7   511 _P2_7	=	0x00a7
                           0000A6   512 _P2_6	=	0x00a6
                           0000A5   513 _P2_5	=	0x00a5
                           0000A4   514 _P2_4	=	0x00a4
                           0000A3   515 _P2_3	=	0x00a3
                           0000A2   516 _P2_2	=	0x00a2
                           0000A1   517 _P2_1	=	0x00a1
                           0000A0   518 _P2_0	=	0x00a0
                           0000A7   519 _TXD1	=	0x00a7
                           0000A6   520 _RXD1	=	0x00a6
                           0000A5   521 _T2EX_	=	0x00a5
                           0000A5   522 _CAP2_	=	0x00a5
                           0000A4   523 _T2_	=	0x00a4
                           0000A4   524 _CAP1_	=	0x00a4
                           0000B7   525 _P3_7	=	0x00b7
                           0000B6   526 _P3_6	=	0x00b6
                           0000B5   527 _P3_5	=	0x00b5
                           0000B4   528 _P3_4	=	0x00b4
                           0000B3   529 _P3_3	=	0x00b3
                           0000B2   530 _P3_2	=	0x00b2
                           0000B1   531 _P3_1	=	0x00b1
                           0000B0   532 _P3_0	=	0x00b0
                           0000B7   533 _SCK1	=	0x00b7
                           0000B6   534 _MISO1	=	0x00b6
                           0000B5   535 _MOSI1	=	0x00b5
                           0000B5   536 _T1	=	0x00b5
                           0000B4   537 _T0	=	0x00b4
                           0000B3   538 _INT1	=	0x00b3
                           0000B2   539 _INT0	=	0x00b2
                           0000B1   540 _TXD	=	0x00b1
                           0000B0   541 _RXD	=	0x00b0
                           0000C6   542 _P4_6	=	0x00c6
                           0000C5   543 _P4_5	=	0x00c5
                           0000C4   544 _P4_4	=	0x00c4
                           0000C3   545 _P4_3	=	0x00c3
                           0000C2   546 _P4_2	=	0x00c2
                           0000C1   547 _P4_1	=	0x00c1
                           0000C0   548 _P4_0	=	0x00c0
                           00008F   549 _TF1	=	0x008f
                           00008E   550 _TR1	=	0x008e
                           00008D   551 _TF0	=	0x008d
                           00008C   552 _TR0	=	0x008c
                           00008B   553 _IE1	=	0x008b
                           00008A   554 _IT1	=	0x008a
                           000089   555 _IE0	=	0x0089
                           000088   556 _IT0	=	0x0088
                           00009F   557 _SM0	=	0x009f
                           00009E   558 _SM1	=	0x009e
                           00009D   559 _SM2	=	0x009d
                           00009C   560 _REN	=	0x009c
                           00009B   561 _TB8	=	0x009b
                           00009A   562 _RB8	=	0x009a
                           000099   563 _TI	=	0x0099
                           000098   564 _RI	=	0x0098
                           0000CF   565 _TF2	=	0x00cf
                           0000CF   566 _CAP1F	=	0x00cf
                           0000CE   567 _EXF2	=	0x00ce
                           0000CD   568 _RCLK	=	0x00cd
                           0000CC   569 _TCLK	=	0x00cc
                           0000CB   570 _EXEN2	=	0x00cb
                           0000CA   571 _TR2	=	0x00ca
                           0000C9   572 _C_T2	=	0x00c9
                           0000C8   573 _CP_RL2	=	0x00c8
                           0000FF   574 _S0_FST_ACT	=	0x00ff
                           0000FE   575 _S0_IF_OV	=	0x00fe
                           0000FD   576 _S0_IF_FIRST	=	0x00fd
                           0000FC   577 _S0_IF_BYTE	=	0x00fc
                           0000FB   578 _S0_FREE	=	0x00fb
                           0000FA   579 _S0_T_FIFO	=	0x00fa
                           0000F8   580 _S0_R_FIFO	=	0x00f8
                           0000F7   581 _ADC_START	=	0x00f7
                                    582 ;--------------------------------------------------------
                                    583 ; overlayable register banks
                                    584 ;--------------------------------------------------------
                                    585 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        586 	.ds 8
                                    587 ;--------------------------------------------------------
                                    588 ; internal ram data
                                    589 ;--------------------------------------------------------
                                    590 	.area DSEG    (DATA)
      000027                        591 _process_action_sloc0_1_0:
      000027                        592 	.ds 1
                                    593 ;--------------------------------------------------------
                                    594 ; overlayable items in internal ram
                                    595 ;--------------------------------------------------------
                                    596 ;--------------------------------------------------------
                                    597 ; indirectly addressable internal ram data
                                    598 ;--------------------------------------------------------
                                    599 	.area ISEG    (DATA)
                                    600 ;--------------------------------------------------------
                                    601 ; absolute internal ram data
                                    602 ;--------------------------------------------------------
                                    603 	.area IABS    (ABS,DATA)
                                    604 	.area IABS    (ABS,DATA)
                                    605 ;--------------------------------------------------------
                                    606 ; bit data
                                    607 ;--------------------------------------------------------
                                    608 	.area BSEG    (BIT)
      000020                        609 _process_action_sloc1_1_0:
      000020                        610 	.ds 1
                                    611 ;--------------------------------------------------------
                                    612 ; paged external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area PSEG    (PAG,XDATA)
                                    615 ;--------------------------------------------------------
                                    616 ; uninitialized external ram data
                                    617 ;--------------------------------------------------------
                                    618 	.area XSEG    (XDATA)
      00081E                        619 _tp_buttons::
      00081E                        620 	.ds 2
      000820                        621 _action_exec_PARM_1:
      000820                        622 	.ds 6
      000826                        623 _action_exec_record_10001_628:
      000826                        624 	.ds 9
      00082F                        625 _ak820_action_exec_event_10000_633:
      00082F                        626 	.ds 2
      000831                        627 _ak820_action_exec_snapshot_10000_634:
      000831                        628 	.ds 6
      000837                        629 _process_record_record_10000_637:
      000837                        630 	.ds 3
      00083A                        631 _process_record_handler_record_argument_10000_645:
      00083A                        632 	.ds 3
      00083D                        633 _process_record_handler_action_10000_646:
      00083D                        634 	.ds 2
      00083F                        635 _process_action_PARM_2:
      00083F                        636 	.ds 2
      000841                        637 _process_action_record_argument_10000_657:
      000841                        638 	.ds 3
      000844                        639 _process_action_on_40000_680:
      000844                        640 	.ds 1
      000845                        641 _register_code_code_10000_714:
      000845                        642 	.ds 1
      000846                        643 _unregister_code_code_10000_728:
      000846                        644 	.ds 1
      000847                        645 _tap_code_delay_PARM_2:
      000847                        646 	.ds 2
      000849                        647 _tap_code_delay_code_10000_741:
      000849                        648 	.ds 1
      00084A                        649 _tap_code_code_10000_748:
      00084A                        650 	.ds 1
      00084B                        651 _register_mods_mods_10000_750:
      00084B                        652 	.ds 1
      00084C                        653 _unregister_mods_mods_10000_754:
      00084C                        654 	.ds 1
      00084D                        655 _register_weak_mods_mods_10000_758:
      00084D                        656 	.ds 1
      00084E                        657 _unregister_weak_mods_mods_10000_762:
      00084E                        658 	.ds 1
                                    659 ;--------------------------------------------------------
                                    660 ; absolute external ram data
                                    661 ;--------------------------------------------------------
                                    662 	.area XABS    (ABS,XDATA)
                                    663 ;--------------------------------------------------------
                                    664 ; initialized external ram data
                                    665 ;--------------------------------------------------------
                                    666 	.area XISEG   (XDATA)
      000DCE                        667 _disable_action_cache::
      000DCE                        668 	.ds 1
                                    669 	.area HOME    (CODE)
                                    670 	.area GSINIT0 (CODE)
                                    671 	.area GSINIT1 (CODE)
                                    672 	.area GSINIT2 (CODE)
                                    673 	.area GSINIT3 (CODE)
                                    674 	.area GSINIT4 (CODE)
                                    675 	.area GSINIT5 (CODE)
                                    676 	.area GSINIT  (CODE)
                                    677 	.area GSFINAL (CODE)
                                    678 	.area CSEG    (CODE)
                                    679 ;--------------------------------------------------------
                                    680 ; global & static initialisations
                                    681 ;--------------------------------------------------------
                                    682 	.area HOME    (CODE)
                                    683 	.area GSINIT  (CODE)
                                    684 	.area GSFINAL (CODE)
                                    685 	.area GSINIT  (CODE)
                                    686 ;--------------------------------------------------------
                                    687 ; Home
                                    688 ;--------------------------------------------------------
                                    689 	.area HOME    (CODE)
                                    690 	.area HOME    (CODE)
                                    691 ;--------------------------------------------------------
                                    692 ; code
                                    693 ;--------------------------------------------------------
                                    694 	.area CSEG    (CODE)
                                    695 ;------------------------------------------------------------
                                    696 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    697 ;------------------------------------------------------------
                                    698 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_40'
                                    699 ;------------------------------------------------------------
                                    700 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    701 ;	-----------------------------------------
                           000007   702 	ar7 = 0x07
                           000006   703 	ar6 = 0x06
                           000005   704 	ar5 = 0x05
                           000004   705 	ar4 = 0x04
                           000003   706 	ar3 = 0x03
                           000002   707 	ar2 = 0x02
                           000001   708 	ar1 = 0x01
                           000000   709 	ar0 = 0x00
                                    710 ;	 function action_exec
                                    711 ;	-----------------------------------------
      007241                        712 _action_exec:
                                    713 ;	quantum/action.c:95: ak820_combo_tick(event.time);
      007241 90 08 22         [24]  714 	mov	dptr,#(_action_exec_PARM_1 + 0x0002)
      007244 12 3A 3F         [24]  715 	lcall	_ak820_outline_0005
      007247 12 38 4F         [24]  716 	lcall	_ak820_combo_tick
                                    717 ;	quantum/action.c:98: if (!ak820_tapping_before(&event)) return;
      00724A 90 08 20         [24]  718 	mov	dptr,#_action_exec_PARM_1
      00724D 12 46 9E         [24]  719 	lcall	_ak820_tapping_before
      007250 E5 82            [12]  720 	mov	a, dpl
      007252 70 01            [24]  721 	jnz	00102$
      007254 22               [24]  722 	ret
      007255                        723 00102$:
                                    724 ;	quantum/action.c:100: if (!ak820_autoshift_before(&event)) return;
      007255 90 08 20         [24]  725 	mov	dptr,#_action_exec_PARM_1
      007258 12 31 2D         [24]  726 	lcall	_ak820_autoshift_before
      00725B E5 82            [12]  727 	mov	a, dpl
      00725D 70 01            [24]  728 	jnz	00104$
      00725F 22               [24]  729 	ret
      007260                        730 00104$:
                                    731 ;	quantum/action.c:116: if (event.pressed) {
      007260 90 08 25         [24]  732 	mov	dptr,#(_action_exec_PARM_1 + 0x0005)
      007263 E0               [24]  733 	movx	a,@dptr
      007264 60 03            [24]  734 	jz	00106$
                                    735 ;	quantum/action.c:118: clear_weak_mods();
      007266 12 82 B6         [24]  736 	lcall	_clear_weak_mods
      007269                        737 00106$:
                                    738 ;	quantum/action.c:130: record.event = event;
      007269 90 0D AD         [24]  739 	mov	dptr,#___memcpy_PARM_2
      00726C 74 20            [12]  740 	mov	a,#_action_exec_PARM_1
      00726E F0               [24]  741 	movx	@dptr,a
      00726F 74 08            [12]  742 	mov	a,#(_action_exec_PARM_1 >> 8)
      007271 12 3A BB         [24]  743 	lcall	_ak820_outline_0093
      007274 12 79 2A         [24]  744 	lcall	_ak820_outline_0070
      007277 90 08 26         [24]  745 	mov	dptr,#_action_exec_record_10001_628
      00727A F5 F0            [12]  746 	mov	b,a
      00727C 12 B9 EF         [24]  747 	lcall	___memcpy
                                    748 ;	quantum/action.c:132: record.tap.count = 0;
      00727F 90 08 2C         [24]  749 	mov	dptr,#(_action_exec_record_10001_628 + 0x0006)
      007282 E0               [24]  750 	movx	a,@dptr
      007283 54 0F            [12]  751 	anl	a,#0x0f
      007285 F0               [24]  752 	movx	@dptr,a
                                    753 ;	quantum/action.c:137: record.keycode = 0;
      007286 90 08 2D         [24]  754 	mov	dptr,#(_action_exec_record_10001_628 + 0x0007)
      007289 12 51 87         [24]  755 	lcall	_ak820_outline_0182
                                    756 ;	quantum/action.c:168: if (IS_NOEVENT(record.event) || pre_process_record_quantum(&record)) {
      00728C 90 08 2A         [24]  757 	mov	dptr,#(_action_exec_record_10001_628 + 0x0004)
      00728F E0               [24]  758 	movx	a,@dptr
      007290 60 0D            [24]  759 	jz	00111$
      007292 90 08 26         [24]  760 	mov	dptr,#_action_exec_record_10001_628
      007295 75 F0 00         [24]  761 	mov	b, #0x00
      007298 12 A0 97         [24]  762 	lcall	_pre_process_record_quantum
      00729B E5 82            [12]  763 	mov	a, dpl
      00729D 60 1F            [24]  764 	jz	00114$
      00729F                        765 00111$:
                                    766 ;	quantum/action.c:170: if (!ak820_tapping_process(&record)) return;
      00729F 90 08 26         [24]  767 	mov	dptr,#_action_exec_record_10001_628
      0072A2 12 47 85         [24]  768 	lcall	_ak820_tapping_process
      0072A5 E5 82            [12]  769 	mov	a, dpl
      0072A7 70 01            [24]  770 	jnz	00108$
      0072A9 22               [24]  771 	ret
      0072AA                        772 00108$:
                                    773 ;	quantum/action.c:172: if (!ak820_autoshift_process(&record)) return;
      0072AA 90 08 26         [24]  774 	mov	dptr,#_action_exec_record_10001_628
      0072AD 12 32 35         [24]  775 	lcall	_ak820_autoshift_process
      0072B0 E5 82            [12]  776 	mov	a, dpl
      0072B2 70 01            [24]  777 	jnz	00110$
      0072B4 22               [24]  778 	ret
      0072B5                        779 00110$:
                                    780 ;	quantum/action.c:175: process_record(&record);
      0072B5 90 08 26         [24]  781 	mov	dptr,#_action_exec_record_10001_628
      0072B8 75 F0 00         [24]  782 	mov	b, #0x00
                                    783 ;	quantum/action.c:190: }
      0072BB 02 72 FB         [24]  784 	ljmp	_process_record
      0072BE                        785 00114$:
      0072BE 22               [24]  786 	ret
                                    787 ;------------------------------------------------------------
                                    788 ;Allocation info for local variables in function 'ak820_action_exec'
                                    789 ;------------------------------------------------------------
                                    790 ;event         Allocated with name '_ak820_action_exec_event_10000_633'
                                    791 ;snapshot      Allocated with name '_ak820_action_exec_snapshot_10000_634'
                                    792 ;------------------------------------------------------------
                                    793 ;	quantum/action.c:193: void ak820_action_exec(const keyevent_t __xdata *event) {
                                    794 ;	-----------------------------------------
                                    795 ;	 function ak820_action_exec
                                    796 ;	-----------------------------------------
      0072BF                        797 _ak820_action_exec:
      0072BF 12 3A CD         [24]  798 	lcall	_ak820_outline_0107
      0072C2 90 08 2F         [24]  799 	mov	dptr,#_ak820_action_exec_event_10000_633
      0072C5 12 3A D2         [24]  800 	lcall	_ak820_outline_0108
                                    801 ;	quantum/action.c:196: keyevent_t snapshot = *event;
      0072C8 90 08 2F         [24]  802 	mov	dptr,#_ak820_action_exec_event_10000_633
      0072CB 12 3A AF         [24]  803 	lcall	_ak820_outline_0079
      0072CE 7F 00            [12]  804 	mov	r7,#0x00
      0072D0 90 0D AD         [24]  805 	mov	dptr,#___memcpy_PARM_2
      0072D3 ED               [12]  806 	mov	a,r5
      0072D4 12 3A 74         [24]  807 	lcall	_ak820_outline_0017
      0072D7 12 79 2A         [24]  808 	lcall	_ak820_outline_0070
      0072DA 90 08 31         [24]  809 	mov	dptr,#_ak820_action_exec_snapshot_10000_634
      0072DD F5 F0            [12]  810 	mov	b,a
      0072DF 12 B9 EF         [24]  811 	lcall	___memcpy
                                    812 ;	quantum/action.c:197: action_exec(snapshot);
      0072E2 90 0D AD         [24]  813 	mov	dptr,#___memcpy_PARM_2
      0072E5 74 31            [12]  814 	mov	a,#_ak820_action_exec_snapshot_10000_634
      0072E7 F0               [24]  815 	movx	@dptr,a
      0072E8 74 08            [12]  816 	mov	a,#(_ak820_action_exec_snapshot_10000_634 >> 8)
      0072EA 12 3A BB         [24]  817 	lcall	_ak820_outline_0093
      0072ED 12 79 2A         [24]  818 	lcall	_ak820_outline_0070
      0072F0 90 08 20         [24]  819 	mov	dptr,#_action_exec_PARM_1
      0072F3 F5 F0            [12]  820 	mov	b,a
      0072F5 12 B9 EF         [24]  821 	lcall	___memcpy
                                    822 ;	quantum/action.c:198: }
      0072F8 02 72 41         [24]  823 	ljmp	_action_exec
                                    824 ;------------------------------------------------------------
                                    825 ;Allocation info for local variables in function 'process_record_nocache'
                                    826 ;------------------------------------------------------------
                                    827 ;record        Allocated with name '_process_record_nocache_record_10000_635'
                                    828 ;------------------------------------------------------------
                                    829 ;	quantum/action.c:283: void process_record_nocache(keyrecord_t *record) {
                                    830 ;	-----------------------------------------
                                    831 ;	 function process_record
                                    832 ;	-----------------------------------------
      0072FB                        833 _process_record:
      0072FB 12 45 5E         [24]  834 	lcall	_ak820_outline_0037
      0072FE 90 08 37         [24]  835 	mov	dptr,#_process_record_record_10000_637
      007301 12 3A 74         [24]  836 	lcall	_ak820_outline_0017
                                    837 ;	quantum/action.c:337: if (IS_NOEVENT(record->event)) {
      007304 90 08 37         [24]  838 	mov	dptr,#_process_record_record_10000_637
      007307 12 51 34         [24]  839 	lcall	_ak820_outline_0012
      00730A 74 04            [12]  840 	mov	a,#0x04
      00730C 12 78 FD         [24]  841 	lcall	_ak820_outline_0014
      00730F 12 BA C8         [24]  842 	lcall	__gptrget
      007312 70 01            [24]  843 	jnz	00102$
                                    844 ;	quantum/action.c:338: return;
      007314 22               [24]  845 	ret
      007315                        846 00102$:
                                    847 ;	quantum/action.c:346: uint8_t oneshot_source = ak820_tapping_source(record->event.key);
      007315 8D 02            [24]  848 	mov	ar2,r5
      007317 8E 03            [24]  849 	mov	ar3,r6
      007319 8F 04            [24]  850 	mov	ar4,r7
      00731B 90 0D AD         [24]  851 	mov	dptr,#___memcpy_PARM_2
      00731E EA               [12]  852 	mov	a,r2
      00731F 12 79 71         [24]  853 	lcall	_ak820_outline_0187
      007322 EC               [12]  854 	mov	a,r4
      007323 A3               [24]  855 	inc	dptr
      007324 F0               [24]  856 	movx	@dptr,a
      007325 90 0D B0         [24]  857 	mov	dptr,#___memcpy_PARM_3
      007328 12 51 79         [24]  858 	lcall	_ak820_outline_0110
      00732B 90 06 34         [24]  859 	mov	dptr,#_ak820_tapping_source_PARM_1
      00732E F5 F0            [12]  860 	mov	b,a
      007330 C0 07            [24]  861 	push	ar7
      007332 C0 06            [24]  862 	push	ar6
      007334 C0 05            [24]  863 	push	ar5
      007336 12 B9 EF         [24]  864 	lcall	___memcpy
      007339 12 45 D8         [24]  865 	lcall	_ak820_tapping_source
      00733C AC 82            [24]  866 	mov	r4, dpl
      00733E D0 05            [24]  867 	pop	ar5
      007340 D0 06            [24]  868 	pop	ar6
      007342 D0 07            [24]  869 	pop	ar7
                                    870 ;	quantum/action.c:347: bool oneshot_pressed = record->event.pressed;
      007344 74 05            [12]  871 	mov	a,#0x05
      007346 12 78 EF         [24]  872 	lcall	_ak820_outline_0013
      007349 12 BA C8         [24]  873 	lcall	__gptrget
      00734C FB               [12]  874 	mov	r3,a
                                    875 ;	quantum/action.c:348: record->keycode = get_record_keycode(record, true);
      00734D 12 79 56         [24]  876 	lcall	_ak820_outline_0146
      007350 90 0C 04         [24]  877 	mov	dptr,#_get_record_keycode_PARM_2
      007353 74 01            [12]  878 	mov	a,#0x01
      007355 12 51 3D         [24]  879 	lcall	_ak820_outline_0034
      007358 C0 04            [24]  880 	push	ar4
      00735A C0 03            [24]  881 	push	ar3
      00735C C0 02            [24]  882 	push	ar2
      00735E C0 01            [24]  883 	push	ar1
      007360 C0 00            [24]  884 	push	ar0
      007362 12 A0 59         [24]  885 	lcall	_get_record_keycode
      007365 12 45 A7         [24]  886 	lcall	_ak820_outline_0133
      007368 D0 00            [24]  887 	pop	ar0
      00736A D0 01            [24]  888 	pop	ar1
      00736C D0 02            [24]  889 	pop	ar2
      00736E D0 03            [24]  890 	pop	ar3
      007370 D0 04            [24]  891 	pop	ar4
      007372 12 4A FD         [24]  892 	lcall	_ak820_outline_0112
      007375 EE               [12]  893 	mov	a,r6
      007376 12 BA 8D         [24]  894 	lcall	__gptrput
      007379 A3               [24]  895 	inc	dptr
      00737A EF               [12]  896 	mov	a,r7
      00737B 12 BA 8D         [24]  897 	lcall	__gptrput
                                    898 ;	quantum/action.c:349: if (!ak820_oneshot_process(record->keycode, oneshot_source, oneshot_pressed)) return;
      00737E 90 08 37         [24]  899 	mov	dptr,#_process_record_record_10000_637
      007381 12 51 34         [24]  900 	lcall	_ak820_outline_0012
      007384 12 79 56         [24]  901 	lcall	_ak820_outline_0146
      007387 12 4A FD         [24]  902 	lcall	_ak820_outline_0112
      00738A 12 BA C8         [24]  903 	lcall	__gptrget
      00738D F8               [12]  904 	mov	r0,a
      00738E A3               [24]  905 	inc	dptr
      00738F 12 BA C8         [24]  906 	lcall	__gptrget
      007392 F9               [12]  907 	mov	r1,a
      007393 90 06 44         [24]  908 	mov	dptr,#_ak820_oneshot_process_PARM_2
      007396 EC               [12]  909 	mov	a,r4
      007397 F0               [24]  910 	movx	@dptr,a
      007398 90 06 45         [24]  911 	mov	dptr,#_ak820_oneshot_process_PARM_3
      00739B EB               [12]  912 	mov	a,r3
      00739C F0               [24]  913 	movx	@dptr,a
      00739D 12 3B 01         [24]  914 	lcall	_ak820_outline_0157
      0073A0 C0 07            [24]  915 	push	ar7
      0073A2 C0 06            [24]  916 	push	ar6
      0073A4 C0 05            [24]  917 	push	ar5
      0073A6 C0 04            [24]  918 	push	ar4
      0073A8 C0 03            [24]  919 	push	ar3
      0073AA 12 49 37         [24]  920 	lcall	_ak820_oneshot_process
      0073AD E5 82            [12]  921 	mov	a, dpl
      0073AF D0 03            [24]  922 	pop	ar3
      0073B1 D0 04            [24]  923 	pop	ar4
      0073B3 D0 05            [24]  924 	pop	ar5
      0073B5 D0 06            [24]  925 	pop	ar6
      0073B7 D0 07            [24]  926 	pop	ar7
      0073B9 70 01            [24]  927 	jnz	00104$
      0073BB 22               [24]  928 	ret
      0073BC                        929 00104$:
                                    930 ;	quantum/action.c:351: if (!process_record_quantum(record)) {
      0073BC 12 6F A4         [24]  931 	lcall	_ak820_outline_0057
      0073BF C0 04            [24]  932 	push	ar4
      0073C1 C0 03            [24]  933 	push	ar3
      0073C3 12 A1 23         [24]  934 	lcall	_process_record_quantum
      0073C6 E5 82            [12]  935 	mov	a, dpl
      0073C8 D0 03            [24]  936 	pop	ar3
      0073CA D0 04            [24]  937 	pop	ar4
      0073CC 70 0A            [24]  938 	jnz	00106$
                                    939 ;	quantum/action.c:353: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0073CE 90 05 AC         [24]  940 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0073D1 EB               [12]  941 	mov	a,r3
      0073D2 F0               [24]  942 	movx	@dptr,a
      0073D3 8C 82            [24]  943 	mov	dpl, r4
                                    944 ;	quantum/action.c:360: return;
      0073D5 02 2E BB         [24]  945 	ljmp	_ak820_oneshot_post
      0073D8                        946 00106$:
                                    947 ;	quantum/action.c:366: process_record_handler(record);
      0073D8 90 08 37         [24]  948 	mov	dptr,#_process_record_record_10000_637
      0073DB 12 51 0E         [24]  949 	lcall	_ak820_outline_0001
      0073DE C0 04            [24]  950 	push	ar4
      0073E0 C0 03            [24]  951 	push	ar3
      0073E2 12 73 FC         [24]  952 	lcall	_process_record_handler
                                    953 ;	quantum/action.c:370: post_process_record_quantum(record);
      0073E5 90 08 37         [24]  954 	mov	dptr,#_process_record_record_10000_637
      0073E8 12 51 0E         [24]  955 	lcall	_ak820_outline_0001
      0073EB 12 A0 F8         [24]  956 	lcall	_post_process_record_quantum
      0073EE D0 03            [24]  957 	pop	ar3
      0073F0 D0 04            [24]  958 	pop	ar4
                                    959 ;	quantum/action.c:372: ak820_oneshot_post(oneshot_source, oneshot_pressed);
      0073F2 90 05 AC         [24]  960 	mov	dptr,#_ak820_oneshot_post_PARM_2
      0073F5 EB               [12]  961 	mov	a,r3
      0073F6 F0               [24]  962 	movx	@dptr,a
      0073F7 8C 82            [24]  963 	mov	dpl, r4
                                    964 ;	quantum/action.c:374: }
      0073F9 02 2E BB         [24]  965 	ljmp	_ak820_oneshot_post
                                    966 ;------------------------------------------------------------
                                    967 ;Allocation info for local variables in function 'process_record_handler'
                                    968 ;------------------------------------------------------------
                                    969 ;record_argument Allocated with name '_process_record_handler_record_argument_10000_645'
                                    970 ;record        Allocated with name '_process_record_handler_record_10000_646'
                                    971 ;action        Allocated with name '_process_record_handler_action_10000_646'
                                    972 ;------------------------------------------------------------
                                    973 ;	quantum/action.c:376: void process_record_handler(keyrecord_t *record_argument) {
                                    974 ;	-----------------------------------------
                                    975 ;	 function process_record_handler
                                    976 ;	-----------------------------------------
      0073FC                        977 _process_record_handler:
      0073FC 12 45 5E         [24]  978 	lcall	_ak820_outline_0037
      0073FF 90 08 3A         [24]  979 	mov	dptr,#_process_record_handler_record_argument_10000_645
      007402 12 3A 74         [24]  980 	lcall	_ak820_outline_0017
                                    981 ;	quantum/action.c:380: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007405 90 08 3A         [24]  982 	mov	dptr,#_process_record_handler_record_argument_10000_645
      007408 12 3A 49         [24]  983 	lcall	_ak820_outline_0007
                                    984 ;	quantum/action.c:387: if (record->keycode) {
      00740B 4C               [12]  985 	orl	a,r4
      00740C 60 19            [24]  986 	jz	00102$
                                    987 ;	quantum/action.c:388: action.code = action_for_keycode(record->keycode);
      00740E 12 3A E2         [24]  988 	lcall	_ak820_outline_0124
      007411 C0 07            [24]  989 	push	ar7
      007413 C0 06            [24]  990 	push	ar6
      007415 12 96 95         [24]  991 	lcall	_action_for_keycode
      007418 12 45 B8         [24]  992 	lcall	_ak820_outline_0149
      00741B D0 06            [24]  993 	pop	ar6
      00741D D0 07            [24]  994 	pop	ar7
      00741F 90 08 3D         [24]  995 	mov	dptr,#_process_record_handler_action_10000_646
      007422 12 3A A9         [24]  996 	lcall	_ak820_outline_0072
      007425 80 2B            [24]  997 	sjmp	00104$
      007427                        998 00102$:
                                    999 ;	quantum/action.c:391: action.code = action_for_keycode(ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed));
      007427 12 79 0B         [24] 1000 	lcall	_ak820_outline_0021
      00742A 7A 00            [12] 1001 	mov	r2,#0x00
      00742C 12 45 B2         [24] 1002 	lcall	_ak820_outline_0142
      00742F 12 45 4C         [24] 1003 	lcall	_ak820_outline_0011
      007432 E0               [24] 1004 	movx	a,@dptr
      007433 90 09 79         [24] 1005 	mov	dptr,#_ak820_resolve_key_PARM_2
      007436 F0               [24] 1006 	movx	@dptr,a
      007437 8D 82            [24] 1007 	mov	dpl, r5
      007439 8C 83            [24] 1008 	mov	dph, r4
      00743B C0 07            [24] 1009 	push	ar7
      00743D C0 06            [24] 1010 	push	ar6
      00743F 12 7C B2         [24] 1011 	lcall	_ak820_resolve_key
      007442 12 96 95         [24] 1012 	lcall	_action_for_keycode
      007445 12 45 B8         [24] 1013 	lcall	_ak820_outline_0149
      007448 D0 06            [24] 1014 	pop	ar6
      00744A D0 07            [24] 1015 	pop	ar7
      00744C 90 08 3D         [24] 1016 	mov	dptr,#_process_record_handler_action_10000_646
      00744F 12 3A A9         [24] 1017 	lcall	_ak820_outline_0072
                                   1018 ;	quantum/action.c:400: ac_dprintf("ACTION: ");
      007452                       1019 00104$:
                                   1020 ;	quantum/action.c:411: process_action(record, action);
      007452 7D 00            [12] 1021 	mov	r5,#0x00
      007454 90 0D AD         [24] 1022 	mov	dptr,#___memcpy_PARM_2
      007457 74 3D            [12] 1023 	mov	a,#_process_record_handler_action_10000_646
      007459 F0               [24] 1024 	movx	@dptr,a
      00745A 74 08            [12] 1025 	mov	a,#(_process_record_handler_action_10000_646 >> 8)
      00745C 12 3A BB         [24] 1026 	lcall	_ak820_outline_0093
      00745F 90 0D B0         [24] 1027 	mov	dptr,#___memcpy_PARM_3
      007462 12 51 79         [24] 1028 	lcall	_ak820_outline_0110
      007465 90 08 3F         [24] 1029 	mov	dptr,#_process_action_PARM_2
      007468 F5 F0            [12] 1030 	mov	b,a
      00746A C0 07            [24] 1031 	push	ar7
      00746C C0 06            [24] 1032 	push	ar6
      00746E C0 05            [24] 1033 	push	ar5
      007470 12 B9 EF         [24] 1034 	lcall	___memcpy
      007473 D0 05            [24] 1035 	pop	ar5
      007475 D0 06            [24] 1036 	pop	ar6
      007477 D0 07            [24] 1037 	pop	ar7
      007479 12 71 B9         [24] 1038 	lcall	_ak820_outline_0064
                                   1039 ;	quantum/action.c:412: }
      00747C 02 74 7F         [24] 1040 	ljmp	_process_action
                                   1041 ;------------------------------------------------------------
                                   1042 ;Allocation info for local variables in function 'register_mouse'
                                   1043 ;------------------------------------------------------------
                                   1044 ;pressed       Allocated with name '_register_mouse_PARM_2'
                                   1045 ;mouse_keycode Allocated with name '_register_mouse_mouse_keycode_10000_654'
                                   1046 ;------------------------------------------------------------
                                   1047 ;	quantum/action.c:424: void register_mouse(uint8_t mouse_keycode, bool pressed) {
                                   1048 ;	-----------------------------------------
                                   1049 ;	 function process_action
                                   1050 ;	-----------------------------------------
      00747F                       1051 _process_action:
      00747F 12 45 5E         [24] 1052 	lcall	_ak820_outline_0037
      007482 90 08 41         [24] 1053 	mov	dptr,#_process_action_record_argument_10000_657
      007485 12 3A 74         [24] 1054 	lcall	_ak820_outline_0017
                                   1055 ;	quantum/action.c:477: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      007488 90 08 41         [24] 1056 	mov	dptr,#_process_action_record_argument_10000_657
      00748B 12 3A 3F         [24] 1057 	lcall	_ak820_outline_0005
                                   1058 ;	quantum/action.c:483: pressed = record->event.pressed;
      00748E A3               [24] 1059 	inc	dptr
      00748F A3               [24] 1060 	inc	dptr
      007490 A3               [24] 1061 	inc	dptr
      007491 A3               [24] 1062 	inc	dptr
      007492 A3               [24] 1063 	inc	dptr
      007493 E0               [24] 1064 	movx	a,@dptr
      007494 F5 27            [12] 1065 	mov	_process_action_sloc0_1_0,a
                                   1066 ;	quantum/action.c:507: switch (action.kind.id) {
      007496 90 08 40         [24] 1067 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007499 E0               [24] 1068 	movx	a,@dptr
      00749A C4               [12] 1069 	swap	a
      00749B 54 0F            [12] 1070 	anl	a,#0x0f
      00749D FD               [12] 1071 	mov  r5,a
      00749E 24 F4            [12] 1072 	add	a,#0xff - 0x0b
      0074A0 50 03            [24] 1073 	jnc	00434$
      0074A2 02 77 20         [24] 1074 	ljmp	00181$
      0074A5                       1075 00434$:
                                   1076 ;	free result
      0074A5 ED               [12] 1077 	mov	a,r5
      0074A6 24 0A            [12] 1078 	add	a,#(00435$-3-.)
      0074A8 83               [24] 1079 	movc	a,@a+pc
      0074A9 F5 82            [12] 1080 	mov	dpl,a
      0074AB ED               [12] 1081 	mov	a,r5
      0074AC 24 10            [12] 1082 	add	a,#(00436$-3-.)
      0074AE 83               [24] 1083 	movc	a,@a+pc
      0074AF F5 83            [12] 1084 	mov	dph,a
      0074B1 E4               [12] 1085 	clr	a
      0074B2 73               [24] 1086 	jmp	@a+dptr
      0074B3                       1087 00435$:
      0074B3 CB                    1088 	.db	00102$
      0074B4 CB                    1089 	.db	00102$
      0074B5 20                    1090 	.db	00181$
      0074B6 20                    1091 	.db	00181$
      0074B7 55                    1092 	.db	00123$
      0074B8 20                    1093 	.db	00181$
      0074B9 20                    1094 	.db	00181$
      0074BA 20                    1095 	.db	00181$
      0074BB B5                    1096 	.db	00131$
      0074BC 87                    1097 	.db	00147$
      0074BD AD                    1098 	.db	00152$
      0074BE AD                    1099 	.db	00152$
      0074BF                       1100 00436$:
      0074BF 74                    1101 	.db	00102$>>8
      0074C0 74                    1102 	.db	00102$>>8
      0074C1 77                    1103 	.db	00181$>>8
      0074C2 77                    1104 	.db	00181$>>8
      0074C3 75                    1105 	.db	00123$>>8
      0074C4 77                    1106 	.db	00181$>>8
      0074C5 77                    1107 	.db	00181$>>8
      0074C6 77                    1108 	.db	00181$>>8
      0074C7 75                    1109 	.db	00131$>>8
      0074C8 76                    1110 	.db	00147$>>8
      0074C9 76                    1111 	.db	00152$>>8
      0074CA 76                    1112 	.db	00152$>>8
                                   1113 ;	quantum/action.c:510: case ACT_RMODS: {
      0074CB                       1114 00102$:
                                   1115 ;	quantum/action.c:511: mods = (action.kind.id == ACT_LMODS) ? action.key.mods : action.key.mods << 4;
      0074CB 90 08 40         [24] 1116 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0074CE E0               [24] 1117 	movx	a,@dptr
      0074CF 54 F0            [12] 1118 	anl	a,#0xf0
      0074D1 70 06            [24] 1119 	jnz	00194$
      0074D3 12 79 44         [24] 1120 	lcall	_ak820_outline_0113
      0074D6 FD               [12] 1121 	mov	r5,a
      0074D7 80 07            [24] 1122 	sjmp	00195$
      0074D9                       1123 00194$:
      0074D9 12 79 44         [24] 1124 	lcall	_ak820_outline_0113
      0074DC C4               [12] 1125 	swap	a
      0074DD 54 F0            [12] 1126 	anl	a,#0xf0
      0074DF FD               [12] 1127 	mov	r5,a
      0074E0                       1128 00195$:
                                   1129 ;	quantum/action.c:513: if (pressed) {
      0074E0 E5 27            [12] 1130 	mov	a,_process_action_sloc0_1_0
      0074E2 60 35            [24] 1131 	jz	00119$
                                   1132 ;	quantum/action.c:514: if (mods) {
      0074E4 ED               [12] 1133 	mov	a,r5
      0074E5 60 29            [24] 1134 	jz	00110$
                                   1135 ;	quantum/action.c:515: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      0074E7 12 79 60         [24] 1136 	lcall	_ak820_outline_0159
      0074EA FC               [12] 1137 	mov	r4,a
      0074EB BC E0 00         [24] 1138 	cjne	r4,#0xe0,00440$
      0074EE                       1139 00440$:
      0074EE 40 07            [24] 1140 	jc	00108$
      0074F0 12 79 60         [24] 1141 	lcall	_ak820_outline_0159
      0074F3 24 18            [12] 1142 	add	a,#0xff - 0xe7
      0074F5 50 0A            [24] 1143 	jnc	00104$
                                   1144 ;	free result
      0074F7                       1145 00108$:
      0074F7 7B 3F            [12] 1146 	mov	r3,#_process_action_PARM_2
      0074F9 7C 08            [12] 1147 	mov	r4,#(_process_action_PARM_2 >> 8)
      0074FB 12 36 47         [24] 1148 	lcall	_ak820_outline_0123
      0074FE E0               [24] 1149 	movx	a,@dptr
      0074FF 70 07            [24] 1150 	jnz	00105$
      007501                       1151 00104$:
                                   1152 ;	quantum/action.c:519: add_owned_mods(mods);
      007501 8D 82            [24] 1153 	mov	dpl, r5
      007503 12 7E CC         [24] 1154 	lcall	_add_owned_mods
      007506 80 05            [24] 1155 	sjmp	00106$
      007508                       1156 00105$:
                                   1157 ;	quantum/action.c:521: add_owned_weak_mods(mods);
      007508 8D 82            [24] 1158 	mov	dpl, r5
      00750A 12 7E EB         [24] 1159 	lcall	_add_owned_weak_mods
      00750D                       1160 00106$:
                                   1161 ;	quantum/action.c:523: send_keyboard_report();
      00750D 12 82 06         [24] 1162 	lcall	_send_keyboard_report
      007510                       1163 00110$:
                                   1164 ;	quantum/action.c:525: register_code(action.key.code);
      007510 12 79 34         [24] 1165 	lcall	_ak820_outline_0078
      007513 12 77 37         [24] 1166 	lcall	_register_code
      007516 02 77 20         [24] 1167 	ljmp	00181$
      007519                       1168 00119$:
                                   1169 ;	quantum/action.c:527: unregister_code(action.key.code);
      007519 12 79 34         [24] 1170 	lcall	_ak820_outline_0078
      00751C C0 05            [24] 1171 	push	ar5
      00751E 12 77 A4         [24] 1172 	lcall	_unregister_code
      007521 D0 05            [24] 1173 	pop	ar5
                                   1174 ;	quantum/action.c:528: if (mods) {
      007523 ED               [12] 1175 	mov	a,r5
      007524 70 03            [24] 1176 	jnz	00444$
      007526 02 77 20         [24] 1177 	ljmp	00181$
      007529                       1178 00444$:
                                   1179 ;	quantum/action.c:529: if (IS_MODIFIER_KEYCODE(action.key.code) || action.key.code == KC_NO) {
      007529 12 79 60         [24] 1180 	lcall	_ak820_outline_0159
      00752C FC               [12] 1181 	mov	r4,a
      00752D BC E0 00         [24] 1182 	cjne	r4,#0xe0,00445$
      007530                       1183 00445$:
      007530 40 07            [24] 1184 	jc	00115$
      007532 12 79 60         [24] 1185 	lcall	_ak820_outline_0159
      007535 24 18            [12] 1186 	add	a,#0xff - 0xe7
      007537 50 0A            [24] 1187 	jnc	00111$
                                   1188 ;	free result
      007539                       1189 00115$:
      007539 7B 3F            [12] 1190 	mov	r3,#_process_action_PARM_2
      00753B 7C 08            [12] 1191 	mov	r4,#(_process_action_PARM_2 >> 8)
      00753D 12 36 47         [24] 1192 	lcall	_ak820_outline_0123
      007540 E0               [24] 1193 	movx	a,@dptr
      007541 70 07            [24] 1194 	jnz	00112$
      007543                       1195 00111$:
                                   1196 ;	quantum/action.c:530: del_owned_mods(mods);
      007543 8D 82            [24] 1197 	mov	dpl, r5
      007545 12 7E DC         [24] 1198 	lcall	_del_owned_mods
      007548 80 05            [24] 1199 	sjmp	00113$
      00754A                       1200 00112$:
                                   1201 ;	quantum/action.c:532: del_owned_weak_mods(mods);
      00754A 8D 82            [24] 1202 	mov	dpl, r5
      00754C 12 7E FB         [24] 1203 	lcall	_del_owned_weak_mods
      00754F                       1204 00113$:
                                   1205 ;	quantum/action.c:534: send_keyboard_report();
      00754F 12 82 06         [24] 1206 	lcall	_send_keyboard_report
                                   1207 ;	quantum/action.c:537: } break;
      007552 02 77 20         [24] 1208 	ljmp	00181$
                                   1209 ;	quantum/action.c:614: case ACT_USAGE:
      007555                       1210 00123$:
                                   1211 ;	quantum/action.c:620: if (record->keycode >= KC_SYSTEM_POWER && record->keycode <= KC_LAUNCHPAD) {
      007555 74 07            [12] 1212 	mov	a,#0x07
      007557 12 3A 7C         [24] 1213 	lcall	_ak820_outline_0022
      00755A 12 4A 71         [24] 1214 	lcall	_ak820_outline_0008
      00755D C3               [12] 1215 	clr	c
      00755E EC               [12] 1216 	mov	a,r4
      00755F 94 A5            [12] 1217 	subb	a,#0xa5
      007561 ED               [12] 1218 	mov	a,r5
      007562 94 00            [12] 1219 	subb	a,#0x00
      007564 40 15            [24] 1220 	jc	00125$
      007566 74 C2            [12] 1221 	mov	a,#0xc2
      007568 9C               [12] 1222 	subb	a,r4
      007569 E4               [12] 1223 	clr	a
      00756A 9D               [12] 1224 	subb	a,r5
      00756B 40 0E            [24] 1225 	jc	00125$
                                   1226 ;	free result
                                   1227 ;	quantum/action.c:621: owned_usage_key((uint8_t)record->keycode, pressed);
      00756D 90 0A A0         [24] 1228 	mov	dptr,#_owned_usage_key_PARM_2
      007570 E5 27            [12] 1229 	mov	a,_process_action_sloc0_1_0
      007572 F0               [24] 1230 	movx	@dptr,a
      007573 8E 82            [24] 1231 	mov	dpl, r6
      007575 12 80 B1         [24] 1232 	lcall	_owned_usage_key
                                   1233 ;	quantum/action.c:622: break;
      007578 02 77 20         [24] 1234 	ljmp	00181$
      00757B                       1235 00125$:
                                   1236 ;	quantum/action.c:625: switch (action.usage.page) {
      00757B 12 79 3B         [24] 1237 	lcall	_ak820_outline_0089
      00757E FF               [12] 1238 	mov	r7,a
      00757F 60 08            [24] 1239 	jz	00127$
      007581 BF 01 02         [24] 1240 	cjne	r7,#0x01,00452$
      007584 80 19            [24] 1241 	sjmp	00128$
      007586                       1242 00452$:
      007586 02 77 20         [24] 1243 	ljmp	00181$
                                   1244 ;	quantum/action.c:626: case PAGE_SYSTEM:
      007589                       1245 00127$:
                                   1246 ;	quantum/action.c:627: host_system_send(pressed ? action.usage.code : 0);
      007589 E5 27            [12] 1247 	mov	a,_process_action_sloc0_1_0
      00758B 60 05            [24] 1248 	jz	00196$
      00758D 12 79 4B         [24] 1249 	lcall	_ak820_outline_0130
      007590 80 04            [24] 1250 	sjmp	00197$
      007592                       1251 00196$:
      007592 7E 00            [12] 1252 	mov	r6,#0x00
      007594 7F 00            [12] 1253 	mov	r7,#0x00
      007596                       1254 00197$:
      007596 12 3A D7         [24] 1255 	lcall	_ak820_outline_0118
      007599 12 6F 2E         [24] 1256 	lcall	_host_system_send
                                   1257 ;	quantum/action.c:628: break;
      00759C 02 77 20         [24] 1258 	ljmp	00181$
                                   1259 ;	quantum/action.c:629: case PAGE_CONSUMER:
      00759F                       1260 00128$:
                                   1261 ;	quantum/action.c:630: host_consumer_send(pressed ? action.usage.code : 0);
      00759F E5 27            [12] 1262 	mov	a,_process_action_sloc0_1_0
      0075A1 60 05            [24] 1263 	jz	00198$
      0075A3 12 79 4B         [24] 1264 	lcall	_ak820_outline_0130
      0075A6 80 04            [24] 1265 	sjmp	00199$
      0075A8                       1266 00198$:
      0075A8 7E 00            [12] 1267 	mov	r6,#0x00
      0075AA 7F 00            [12] 1268 	mov	r7,#0x00
      0075AC                       1269 00199$:
      0075AC 12 3A D7         [24] 1270 	lcall	_ak820_outline_0118
      0075AF 12 6F 5E         [24] 1271 	lcall	_host_consumer_send
                                   1272 ;	quantum/action.c:633: break;
      0075B2 02 77 20         [24] 1273 	ljmp	00181$
                                   1274 ;	quantum/action.c:640: case ACT_LAYER: {
      0075B5                       1275 00131$:
                                   1276 ;	quantum/action.c:641: uint8_t on = action.layer_bitop.on;
      0075B5 90 08 40         [24] 1277 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      0075B8 E0               [24] 1278 	movx	a,@dptr
      0075B9 54 03            [12] 1279 	anl	a,#0x03
      0075BB 90 08 44         [24] 1280 	mov	dptr,#_process_action_on_40000_680
      0075BE F0               [24] 1281 	movx	@dptr,a
                                   1282 ;	quantum/action.c:644: if (on ? (pressed ? (on & ON_PRESS) : (on & ON_RELEASE)) : !pressed) {
      0075BF E0               [24] 1283 	movx	a,@dptr
      0075C0 FF               [12] 1284 	mov	r7,a
      0075C1 60 11            [24] 1285 	jz	00200$
      0075C3 E5 27            [12] 1286 	mov	a,_process_action_sloc0_1_0
      0075C5 60 07            [24] 1287 	jz	00202$
      0075C7 8F 06            [24] 1288 	mov	ar6,r7
      0075C9 53 06 01         [24] 1289 	anl	ar6,#0x01
      0075CC 80 10            [24] 1290 	sjmp	00201$
      0075CE                       1291 00202$:
      0075CE 74 02            [12] 1292 	mov	a,#0x02
      0075D0 5F               [12] 1293 	anl	a,r7
      0075D1 FE               [12] 1294 	mov	r6,a
      0075D2 80 0A            [24] 1295 	sjmp	00201$
      0075D4                       1296 00200$:
      0075D4 E5 27            [12] 1297 	mov	a,_process_action_sloc0_1_0
      0075D6 B4 01 00         [24] 1298 	cjne	a,#0x01,00457$
      0075D9                       1299 00457$:
      0075D9 92 20            [24] 1300 	mov  _process_action_sloc1_1_0,c
      0075DB E4               [12] 1301 	clr	a
      0075DC 33               [12] 1302 	rlc	a
      0075DD FE               [12] 1303 	mov	r6,a
      0075DE                       1304 00201$:
      0075DE EE               [12] 1305 	mov	a,r6
      0075DF 70 03            [24] 1306 	jnz	00458$
      0075E1 02 77 20         [24] 1307 	ljmp	00181$
      0075E4                       1308 00458$:
                                   1309 ;	quantum/action.c:645: uint8_t shift = action.layer_bitop.part * 4;
      0075E4 12 79 60         [24] 1310 	lcall	_ak820_outline_0159
      0075E7 C4               [12] 1311 	swap	a
      0075E8 03               [12] 1312 	rr	a
      0075E9 54 07            [12] 1313 	anl	a,#0x07
      0075EB 25 E0            [12] 1314 	add	a,acc
      0075ED 25 E0            [12] 1315 	add	a,acc
      0075EF FF               [12] 1316 	mov	r7,a
                                   1317 ;	quantum/action.c:646: layer_state_t bits = ((layer_state_t)action.layer_bitop.bits) << shift;
      0075F0 12 79 60         [24] 1318 	lcall	_ak820_outline_0159
      0075F3 54 0F            [12] 1319 	anl	a,#0x0f
      0075F5 FE               [12] 1320 	mov	r6,a
      0075F6 8F F0            [24] 1321 	mov	b,r7
      0075F8 05 F0            [12] 1322 	inc	b
      0075FA EE               [12] 1323 	mov	a,r6
      0075FB 80 02            [24] 1324 	sjmp	00460$
      0075FD                       1325 00459$:
      0075FD 25 E0            [12] 1326 	add	a,acc
      0075FF                       1327 00460$:
      0075FF D5 F0 FB         [24] 1328 	djnz	b,00459$
      007602 FE               [12] 1329 	mov	r6,a
                                   1330 ;	quantum/action.c:647: layer_state_t mask = action.layer_bitop.xbit ? ~(((layer_state_t)0xf) << shift) : 0;
      007603 12 79 60         [24] 1331 	lcall	_ak820_outline_0159
      007606 30 E4 11         [24] 1332 	jnb	acc.4,00204$
      007609 8F F0            [24] 1333 	mov	b,r7
      00760B 05 F0            [12] 1334 	inc	b
      00760D 74 0F            [12] 1335 	mov	a,#0x0f
      00760F 80 02            [24] 1336 	sjmp	00463$
      007611                       1337 00462$:
      007611 25 E0            [12] 1338 	add	a,acc
      007613                       1339 00463$:
      007613 D5 F0 FB         [24] 1340 	djnz	b,00462$
      007616 F4               [12] 1341 	cpl	a
      007617 FF               [12] 1342 	mov	r7,a
      007618 80 02            [24] 1343 	sjmp	00205$
      00761A                       1344 00204$:
      00761A 7F 00            [12] 1345 	mov	r7,#0x00
      00761C                       1346 00205$:
                                   1347 ;	quantum/action.c:648: bits |= mask;
      00761C EE               [12] 1348 	mov	a,r6
      00761D 42 07            [12] 1349 	orl	ar7,a
                                   1350 ;	quantum/action.c:649: if (!on) {
      00761F 90 08 44         [24] 1351 	mov	dptr,#_process_action_on_40000_680
      007622 E0               [24] 1352 	movx	a,@dptr
      007623 70 31            [24] 1353 	jnz	00143$
                                   1354 ;	quantum/action.c:650: switch (action.layer_bitop.op) {
      007625 12 79 3B         [24] 1355 	lcall	_ak820_outline_0089
      007628 FE               [12] 1356 	mov	r6,a
      007629 2E               [12] 1357 	add	a,r6
                                   1358 ;	quantum/action.c:651: case OP_BIT_AND: default_layer_and(bits); break;
      00762A 90 76 2E         [24] 1359 	mov	dptr,#00465$
      00762D 73               [24] 1360 	jmp	@a+dptr
      00762E                       1361 00465$:
      00762E 80 06            [24] 1362 	sjmp	00132$
      007630 80 0C            [24] 1363 	sjmp	00133$
      007632 80 12            [24] 1364 	sjmp	00134$
      007634 80 18            [24] 1365 	sjmp	00135$
      007636                       1366 00132$:
      007636 8F 82            [24] 1367 	mov	dpl, r7
      007638 12 79 C0         [24] 1368 	lcall	_default_layer_and
      00763B 02 77 20         [24] 1369 	ljmp	00181$
                                   1370 ;	quantum/action.c:652: case OP_BIT_OR: default_layer_or(bits); break;
      00763E                       1371 00133$:
      00763E 8F 82            [24] 1372 	mov	dpl, r7
      007640 12 79 AF         [24] 1373 	lcall	_default_layer_or
      007643 02 77 20         [24] 1374 	ljmp	00181$
                                   1375 ;	quantum/action.c:653: case OP_BIT_XOR: default_layer_xor(bits); break;
      007646                       1376 00134$:
      007646 8F 82            [24] 1377 	mov	dpl, r7
      007648 12 79 D6         [24] 1378 	lcall	_default_layer_xor
      00764B 02 77 20         [24] 1379 	ljmp	00181$
                                   1380 ;	quantum/action.c:654: case OP_BIT_SET: default_layer_set(bits); break;
      00764E                       1381 00135$:
      00764E 8F 82            [24] 1382 	mov	dpl, r7
      007650 12 79 A4         [24] 1383 	lcall	_default_layer_set
                                   1384 ;	quantum/action.c:655: }
      007653 02 77 20         [24] 1385 	ljmp	00181$
      007656                       1386 00143$:
                                   1387 ;	quantum/action.c:657: switch (action.layer_bitop.op) {
      007656 12 79 3B         [24] 1388 	lcall	_ak820_outline_0089
      007659 FE               [12] 1389 	mov	r6,a
      00765A 2E               [12] 1390 	add	a,r6
                                   1391 ;	quantum/action.c:658: case OP_BIT_AND: layer_and(bits); break;
      00765B 90 76 5F         [24] 1392 	mov	dptr,#00466$
      00765E 73               [24] 1393 	jmp	@a+dptr
      00765F                       1394 00466$:
      00765F 80 06            [24] 1395 	sjmp	00137$
      007661 80 0C            [24] 1396 	sjmp	00138$
      007663 80 12            [24] 1397 	sjmp	00139$
      007665 80 18            [24] 1398 	sjmp	00140$
      007667                       1399 00137$:
      007667 8F 82            [24] 1400 	mov	dpl, r7
      007669 12 7B 5A         [24] 1401 	lcall	_layer_and
      00766C 02 77 20         [24] 1402 	ljmp	00181$
                                   1403 ;	quantum/action.c:659: case OP_BIT_OR: layer_or(bits); break;
      00766F                       1404 00138$:
      00766F 8F 82            [24] 1405 	mov	dpl, r7
      007671 12 7B 49         [24] 1406 	lcall	_layer_or
      007674 02 77 20         [24] 1407 	ljmp	00181$
                                   1408 ;	quantum/action.c:660: case OP_BIT_XOR: layer_xor(bits); break;
      007677                       1409 00139$:
      007677 8F 82            [24] 1410 	mov	dpl, r7
      007679 12 7B 70         [24] 1411 	lcall	_layer_xor
      00767C 02 77 20         [24] 1412 	ljmp	00181$
                                   1413 ;	quantum/action.c:661: case OP_BIT_SET: layer_state_set(bits); break;
      00767F                       1414 00140$:
      00767F 8F 82            [24] 1415 	mov	dpl, r7
      007681 12 7A E6         [24] 1416 	lcall	_layer_state_set
                                   1417 ;	quantum/action.c:665: break;
      007684 02 77 20         [24] 1418 	ljmp	00181$
                                   1419 ;	quantum/action.c:667: case ACT_LAYER_MODS:
      007687                       1420 00147$:
                                   1421 ;	quantum/action.c:668: if (pressed) {
      007687 E5 27            [12] 1422 	mov	a,_process_action_sloc0_1_0
      007689 60 11            [24] 1423 	jz	00149$
                                   1424 ;	quantum/action.c:669: layer_hold_on(action.layer_mods.layer);
      00768B 12 79 44         [24] 1425 	lcall	_ak820_outline_0113
      00768E F5 82            [12] 1426 	mov	dpl,a
      007690 12 7A 46         [24] 1427 	lcall	_layer_hold_on
                                   1428 ;	quantum/action.c:670: register_mods(action.layer_mods.mods);
      007693 12 79 34         [24] 1429 	lcall	_ak820_outline_0078
      007696 12 78 5A         [24] 1430 	lcall	_register_mods
      007699 02 77 20         [24] 1431 	ljmp	00181$
      00769C                       1432 00149$:
                                   1433 ;	quantum/action.c:672: unregister_mods(action.layer_mods.mods);
      00769C 12 79 34         [24] 1434 	lcall	_ak820_outline_0078
      00769F 12 78 6E         [24] 1435 	lcall	_unregister_mods
                                   1436 ;	quantum/action.c:673: layer_hold_off(action.layer_mods.layer);
      0076A2 12 79 44         [24] 1437 	lcall	_ak820_outline_0113
      0076A5 F5 82            [12] 1438 	mov	dpl,a
      0076A7 12 7A 7E         [24] 1439 	lcall	_layer_hold_off
                                   1440 ;	quantum/action.c:675: break;
      0076AA 02 77 20         [24] 1441 	ljmp	00181$
                                   1442 ;	quantum/action.c:677: case ACT_LAYER_TAP_EXT:
      0076AD                       1443 00152$:
                                   1444 ;	quantum/action.c:678: switch (action.layer_tap.code) {
      0076AD 12 79 60         [24] 1445 	lcall	_ak820_outline_0159
      0076B0 FF               [12] 1446 	mov	r7,a
      0076B1 BF F1 02         [24] 1447 	cjne	r7,#0xf1,00468$
      0076B4 80 0A            [24] 1448 	sjmp	00154$
      0076B6                       1449 00468$:
      0076B6 BF F2 02         [24] 1450 	cjne	r7,#0xf2,00469$
      0076B9 80 19            [24] 1451 	sjmp	00155$
      0076BB                       1452 00469$:
                                   1453 ;	quantum/action.c:694: momentary_layer_action:
      0076BB BF F3 3B         [24] 1454 	cjne	r7,#0xf3,00160$
      0076BE 80 28            [24] 1455 	sjmp	00156$
      0076C0                       1456 00154$:
                                   1457 ;	quantum/action.c:695: pressed ? layer_hold_on(action.layer_tap.val) : layer_hold_off(action.layer_tap.val);
      0076C0 E5 27            [12] 1458 	mov	a,_process_action_sloc0_1_0
      0076C2 60 08            [24] 1459 	jz	00206$
      0076C4 12 79 1A         [24] 1460 	lcall	_ak820_outline_0042
      0076C7 12 7A 46         [24] 1461 	lcall	_layer_hold_on
      0076CA 80 54            [24] 1462 	sjmp	00181$
      0076CC                       1463 00206$:
      0076CC 12 79 1A         [24] 1464 	lcall	_ak820_outline_0042
      0076CF 12 7A 7E         [24] 1465 	lcall	_layer_hold_off
                                   1466 ;	quantum/action.c:696: break;
                                   1467 ;	quantum/action.c:697: case OP_OFF_ON:
      0076D2 80 4C            [24] 1468 	sjmp	00181$
      0076D4                       1469 00155$:
                                   1470 ;	quantum/action.c:698: pressed ? layer_off(action.layer_tap.val) : layer_on(action.layer_tap.val);
      0076D4 E5 27            [12] 1471 	mov	a,_process_action_sloc0_1_0
      0076D6 60 08            [24] 1472 	jz	00208$
      0076D8 12 79 1A         [24] 1473 	lcall	_ak820_outline_0042
      0076DB 12 7B 2B         [24] 1474 	lcall	_layer_off
      0076DE 80 40            [24] 1475 	sjmp	00181$
      0076E0                       1476 00208$:
      0076E0 12 79 1A         [24] 1477 	lcall	_ak820_outline_0042
      0076E3 12 7B 10         [24] 1478 	lcall	_layer_on
                                   1479 ;	quantum/action.c:699: break;
                                   1480 ;	quantum/action.c:700: case OP_SET_CLEAR:
      0076E6 80 38            [24] 1481 	sjmp	00181$
      0076E8                       1482 00156$:
                                   1483 ;	quantum/action.c:701: pressed ? layer_move(action.layer_tap.val) : layer_clear();
      0076E8 E5 27            [12] 1484 	mov	a,_process_action_sloc0_1_0
      0076EA 60 08            [24] 1485 	jz	00210$
      0076EC 12 79 1A         [24] 1486 	lcall	_ak820_outline_0042
      0076EF 12 7A FA         [24] 1487 	lcall	_layer_move
      0076F2 80 2C            [24] 1488 	sjmp	00181$
      0076F4                       1489 00210$:
      0076F4 12 7A F4         [24] 1490 	lcall	_layer_clear
                                   1491 ;	quantum/action.c:702: break;
                                   1492 ;	quantum/action.c:748: default:
      0076F7 80 27            [24] 1493 	sjmp	00181$
      0076F9                       1494 00160$:
                                   1495 ;	quantum/action.c:755: if (pressed) {
      0076F9 E5 27            [12] 1496 	mov	a,_process_action_sloc0_1_0
      0076FB 60 08            [24] 1497 	jz	00163$
                                   1498 ;	quantum/action.c:757: register_code(action.layer_tap.code);
      0076FD 12 79 34         [24] 1499 	lcall	_ak820_outline_0078
      007700 12 77 37         [24] 1500 	lcall	_register_code
                                   1501 ;	quantum/action.c:759: ac_dprintf("KEYMAP_TAP_KEY: Tap: unregister_code\n");
      007703 80 1B            [24] 1502 	sjmp	00181$
      007705                       1503 00163$:
                                   1504 ;	quantum/action.c:760: if (action.layer_tap.code == KC_CAPS) {
      007705 12 79 60         [24] 1505 	lcall	_ak820_outline_0159
      007708 FF               [12] 1506 	mov	r7,a
      007709 BF 39 0E         [24] 1507 	cjne	r7,#0x39,00175$
                                   1508 ;	quantum/action.c:761: wait_ms(TAP_HOLD_CAPS_DELAY);
      00770C 7F 50            [12] 1509 	mov	r7,#0x50
      00770E                       1510 00187$:
      00770E EF               [12] 1511 	mov	a,r7
      00770F 60 09            [24] 1512 	jz	00175$
      007711 90 00 01         [24] 1513 	mov	dptr,#0x0001
      007714 12 5B 08         [24] 1514 	lcall	_mDelaymS
      007717 1F               [12] 1515 	dec	r7
                                   1516 ;	quantum/action.c:763: wait_ms(TAP_CODE_DELAY);
      007718 80 F4            [24] 1517 	sjmp	00187$
      00771A                       1518 00175$:
                                   1519 ;	quantum/action.c:765: unregister_code(action.layer_tap.code);
      00771A 12 79 34         [24] 1520 	lcall	_ak820_outline_0078
      00771D 12 77 A4         [24] 1521 	lcall	_unregister_code
                                   1522 ;	quantum/action.c:848: }
      007720                       1523 00181$:
                                   1524 ;	quantum/action.c:869: switch (action.kind.id) {
      007720 90 08 40         [24] 1525 	mov	dptr,#(_process_action_PARM_2 + 0x0001)
      007723 E0               [24] 1526 	movx	a,@dptr
      007724 C4               [12] 1527 	swap	a
      007725 54 0F            [12] 1528 	anl	a,#0x0f
      007727 FF               [12] 1529 	mov	r7,a
      007728 BF 08 02         [24] 1530 	cjne	r7,#0x08,00478$
      00772B 80 03            [24] 1531 	sjmp	00183$
      00772D                       1532 00478$:
      00772D BF 09 06         [24] 1533 	cjne	r7,#0x09,00192$
                                   1534 ;	quantum/action.c:871: case ACT_LAYER_MODS:
      007730                       1535 00183$:
                                   1536 ;	quantum/action.c:876: led_set(host_keyboard_leds());
      007730 12 6E 93         [24] 1537 	lcall	_host_keyboard_leds
                                   1538 ;	quantum/action.c:880: }
                                   1539 ;	quantum/action.c:933: }
      007733 02 99 4A         [24] 1540 	ljmp	_led_set
      007736                       1541 00192$:
      007736 22               [24] 1542 	ret
                                   1543 ;------------------------------------------------------------
                                   1544 ;Allocation info for local variables in function 'register_code'
                                   1545 ;------------------------------------------------------------
                                   1546 ;code          Allocated with name '_register_code_code_10000_714'
                                   1547 ;------------------------------------------------------------
                                   1548 ;	quantum/action.c:939: __attribute__((weak)) void register_code(uint8_t code) {
                                   1549 ;	-----------------------------------------
                                   1550 ;	 function register_code
                                   1551 ;	-----------------------------------------
      007737                       1552 _register_code:
      007737 E5 82            [12] 1553 	mov	a,dpl
      007739 90 08 45         [24] 1554 	mov	dptr,#_register_code_code_10000_714
      00773C F0               [24] 1555 	movx	@dptr,a
                                   1556 ;	quantum/action.c:940: if (code == KC_NO) {
      00773D E0               [24] 1557 	movx	a,@dptr
      00773E FF               [12] 1558 	mov	r7,a
      00773F 70 01            [24] 1559 	jnz	00123$
                                   1560 ;	quantum/action.c:941: return;
      007741 22               [24] 1561 	ret
      007742                       1562 00123$:
                                   1563 ;	quantum/action.c:976: } else if (IS_BASIC_KEYCODE(code)) {
      007742 BF 04 00         [24] 1564 	cjne	r7,#0x04,00186$
      007745                       1565 00186$:
      007745 40 12            [24] 1566 	jc	00119$
      007747 EF               [12] 1567 	mov	a,r7
      007748 24 5B            [12] 1568 	add	a,#0xff - 0xa4
      00774A 40 0D            [24] 1569 	jc	00119$
                                   1570 ;	free result
                                   1571 ;	quantum/action.c:981: if (!add_owned_key(code)) return;
      00774C 8F 82            [24] 1572 	mov	dpl, r7
      00774E 12 7F 70         [24] 1573 	lcall	_add_owned_key
      007751 E5 82            [12] 1574 	mov	a, dpl
      007753 70 01            [24] 1575 	jnz	00104$
      007755 22               [24] 1576 	ret
      007756                       1577 00104$:
                                   1578 ;	quantum/action.c:995: send_keyboard_report();
      007756 02 82 06         [24] 1579 	ljmp	_send_keyboard_report
      007759                       1580 00119$:
                                   1581 ;	quantum/action.c:996: } else if (IS_MODIFIER_KEYCODE(code)) {
      007759 12 79 65         [24] 1582 	lcall	_ak820_outline_0167
      00775C BF E0 00         [24] 1583 	cjne	r7,#0xe0,00190$
      00775F                       1584 00190$:
      00775F 40 1A            [24] 1585 	jc	00115$
      007761 EF               [12] 1586 	mov	a,r7
      007762 24 18            [12] 1587 	add	a,#0xff - 0xe7
      007764 40 15            [24] 1588 	jc	00115$
                                   1589 ;	free result
                                   1590 ;	quantum/action.c:997: add_owned_mods(MOD_BIT(code));
      007766 74 07            [12] 1591 	mov	a,#0x07
      007768 5F               [12] 1592 	anl	a,r7
      007769 12 79 23         [24] 1593 	lcall	_ak820_outline_0061
      00776C 80 02            [24] 1594 	sjmp	00194$
      00776E                       1595 00193$:
      00776E 25 E0            [12] 1596 	add	a,acc
      007770                       1597 00194$:
      007770 D5 F0 FB         [24] 1598 	djnz	b,00193$
      007773 F5 82            [12] 1599 	mov	dpl,a
      007775 12 7E CC         [24] 1600 	lcall	_add_owned_mods
                                   1601 ;	quantum/action.c:998: send_keyboard_report();
      007778 02 82 06         [24] 1602 	ljmp	_send_keyboard_report
      00777B                       1603 00115$:
                                   1604 ;	quantum/action.c:1001: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      00777B 12 79 65         [24] 1605 	lcall	_ak820_outline_0167
      00777E BF A5 00         [24] 1606 	cjne	r7,#0xa5,00195$
      007781                       1607 00195$:
      007781 40 05            [24] 1608 	jc	00113$
      007783 EF               [12] 1609 	mov	a,r7
      007784 24 58            [12] 1610 	add	a,#0xff - 0xa7
      007786 50 0D            [24] 1611 	jnc	00108$
                                   1612 ;	free result
      007788                       1613 00113$:
      007788 12 79 65         [24] 1614 	lcall	_ak820_outline_0167
      00778B BF A8 00         [24] 1615 	cjne	r7,#0xa8,00198$
      00778E                       1616 00198$:
      00778E 40 13            [24] 1617 	jc	00125$
      007790 EF               [12] 1618 	mov	a,r7
      007791 24 3D            [12] 1619 	add	a,#0xff - 0xc2
      007793 40 0E            [24] 1620 	jc	00125$
                                   1621 ;	free result
      007795                       1622 00108$:
                                   1623 ;	quantum/action.c:1003: owned_usage_key(code, true);
      007795 12 79 65         [24] 1624 	lcall	_ak820_outline_0167
      007798 90 0A A0         [24] 1625 	mov	dptr,#_owned_usage_key_PARM_2
      00779B 74 01            [12] 1626 	mov	a,#0x01
      00779D F0               [24] 1627 	movx	@dptr,a
      00779E 8F 82            [24] 1628 	mov	dpl, r7
                                   1629 ;	quantum/action.c:1011: register_mouse(code, true);
                                   1630 ;	quantum/action.c:1013: }
      0077A0 02 80 B1         [24] 1631 	ljmp	_owned_usage_key
      0077A3                       1632 00125$:
      0077A3 22               [24] 1633 	ret
                                   1634 ;------------------------------------------------------------
                                   1635 ;Allocation info for local variables in function 'unregister_code'
                                   1636 ;------------------------------------------------------------
                                   1637 ;code          Allocated with name '_unregister_code_code_10000_728'
                                   1638 ;------------------------------------------------------------
                                   1639 ;	quantum/action.c:1019: __attribute__((weak)) void unregister_code(uint8_t code) {
                                   1640 ;	-----------------------------------------
                                   1641 ;	 function unregister_code
                                   1642 ;	-----------------------------------------
      0077A4                       1643 _unregister_code:
      0077A4 E5 82            [12] 1644 	mov	a,dpl
      0077A6 90 08 46         [24] 1645 	mov	dptr,#_unregister_code_code_10000_728
      0077A9 F0               [24] 1646 	movx	@dptr,a
                                   1647 ;	quantum/action.c:1020: if (code == KC_NO) {
      0077AA E0               [24] 1648 	movx	a,@dptr
      0077AB FF               [12] 1649 	mov	r7,a
      0077AC 70 01            [24] 1650 	jnz	00121$
                                   1651 ;	quantum/action.c:1021: return;
      0077AE 22               [24] 1652 	ret
      0077AF                       1653 00121$:
                                   1654 ;	quantum/action.c:1053: } else if (IS_BASIC_KEYCODE(code)) {
      0077AF BF 04 00         [24] 1655 	cjne	r7,#0x04,00184$
      0077B2                       1656 00184$:
      0077B2 40 12            [24] 1657 	jc	00117$
      0077B4 EF               [12] 1658 	mov	a,r7
      0077B5 24 5B            [12] 1659 	add	a,#0xff - 0xa4
      0077B7 40 0D            [24] 1660 	jc	00117$
                                   1661 ;	free result
                                   1662 ;	quantum/action.c:1055: if (!del_owned_key(code)) return;
      0077B9 8F 82            [24] 1663 	mov	dpl, r7
      0077BB 12 7F EA         [24] 1664 	lcall	_del_owned_key
      0077BE E5 82            [12] 1665 	mov	a, dpl
      0077C0 70 01            [24] 1666 	jnz	00102$
      0077C2 22               [24] 1667 	ret
      0077C3                       1668 00102$:
                                   1669 ;	quantum/action.c:1062: send_keyboard_report();
      0077C3 02 82 06         [24] 1670 	ljmp	_send_keyboard_report
      0077C6                       1671 00117$:
                                   1672 ;	quantum/action.c:1063: } else if (IS_MODIFIER_KEYCODE(code)) {
      0077C6 12 79 6B         [24] 1673 	lcall	_ak820_outline_0168
      0077C9 BF E0 00         [24] 1674 	cjne	r7,#0xe0,00188$
      0077CC                       1675 00188$:
      0077CC 40 1A            [24] 1676 	jc	00113$
      0077CE EF               [12] 1677 	mov	a,r7
      0077CF 24 18            [12] 1678 	add	a,#0xff - 0xe7
      0077D1 40 15            [24] 1679 	jc	00113$
                                   1680 ;	free result
                                   1681 ;	quantum/action.c:1064: del_owned_mods(MOD_BIT(code));
      0077D3 74 07            [12] 1682 	mov	a,#0x07
      0077D5 5F               [12] 1683 	anl	a,r7
      0077D6 12 79 23         [24] 1684 	lcall	_ak820_outline_0061
      0077D9 80 02            [24] 1685 	sjmp	00192$
      0077DB                       1686 00191$:
      0077DB 25 E0            [12] 1687 	add	a,acc
      0077DD                       1688 00192$:
      0077DD D5 F0 FB         [24] 1689 	djnz	b,00191$
      0077E0 F5 82            [12] 1690 	mov	dpl,a
      0077E2 12 7E DC         [24] 1691 	lcall	_del_owned_mods
                                   1692 ;	quantum/action.c:1065: send_keyboard_report();
      0077E5 02 82 06         [24] 1693 	ljmp	_send_keyboard_report
      0077E8                       1694 00113$:
                                   1695 ;	quantum/action.c:1068: } else if (IS_SYSTEM_KEYCODE(code) || IS_CONSUMER_KEYCODE(code)) {
      0077E8 12 79 6B         [24] 1696 	lcall	_ak820_outline_0168
      0077EB BF A5 00         [24] 1697 	cjne	r7,#0xa5,00193$
      0077EE                       1698 00193$:
      0077EE 40 05            [24] 1699 	jc	00111$
      0077F0 EF               [12] 1700 	mov	a,r7
      0077F1 24 58            [12] 1701 	add	a,#0xff - 0xa7
      0077F3 50 0D            [24] 1702 	jnc	00106$
                                   1703 ;	free result
      0077F5                       1704 00111$:
      0077F5 12 79 6B         [24] 1705 	lcall	_ak820_outline_0168
      0077F8 BF A8 00         [24] 1706 	cjne	r7,#0xa8,00196$
      0077FB                       1707 00196$:
      0077FB 40 12            [24] 1708 	jc	00123$
      0077FD EF               [12] 1709 	mov	a,r7
      0077FE 24 3D            [12] 1710 	add	a,#0xff - 0xc2
      007800 40 0D            [24] 1711 	jc	00123$
                                   1712 ;	free result
      007802                       1713 00106$:
                                   1714 ;	quantum/action.c:1070: owned_usage_key(code, false);
      007802 12 79 6B         [24] 1715 	lcall	_ak820_outline_0168
      007805 90 0A A0         [24] 1716 	mov	dptr,#_owned_usage_key_PARM_2
      007808 E4               [12] 1717 	clr	a
      007809 F0               [24] 1718 	movx	@dptr,a
      00780A 8F 82            [24] 1719 	mov	dpl, r7
                                   1720 ;	quantum/action.c:1078: register_mouse(code, false);
                                   1721 ;	quantum/action.c:1080: }
      00780C 02 80 B1         [24] 1722 	ljmp	_owned_usage_key
      00780F                       1723 00123$:
      00780F 22               [24] 1724 	ret
                                   1725 ;------------------------------------------------------------
                                   1726 ;Allocation info for local variables in function 'tap_code_delay'
                                   1727 ;------------------------------------------------------------
                                   1728 ;delay         Allocated with name '_tap_code_delay_PARM_2'
                                   1729 ;code          Allocated with name '_tap_code_delay_code_10000_741'
                                   1730 ;i             Allocated with name '_tap_code_delay_i_20000_743'
                                   1731 ;i             Allocated with name '_tap_code_delay_i_50000_746'
                                   1732 ;------------------------------------------------------------
                                   1733 ;	quantum/action.c:1087: __attribute__((weak)) void tap_code_delay(uint8_t code, uint16_t delay) {
                                   1734 ;	-----------------------------------------
                                   1735 ;	 function tap_code_delay
                                   1736 ;	-----------------------------------------
      007810                       1737 _tap_code_delay:
      007810 E5 82            [12] 1738 	mov	a,dpl
      007812 90 08 49         [24] 1739 	mov	dptr,#_tap_code_delay_code_10000_741
      007815 F0               [24] 1740 	movx	@dptr,a
                                   1741 ;	quantum/action.c:1088: register_code(code);
      007816 E0               [24] 1742 	movx	a,@dptr
      007817 FF               [12] 1743 	mov	r7,a
      007818 F5 82            [12] 1744 	mov	dpl,a
      00781A C0 07            [24] 1745 	push	ar7
      00781C 12 77 37         [24] 1746 	lcall	_register_code
      00781F D0 07            [24] 1747 	pop	ar7
                                   1748 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007821 90 08 47         [24] 1749 	mov	dptr,#_tap_code_delay_PARM_2
      007824 12 3A AF         [24] 1750 	lcall	_ak820_outline_0079
      007827                       1751 00110$:
      007827 ED               [12] 1752 	mov	a,r5
      007828 4E               [12] 1753 	orl	a,r6
      007829 60 0D            [24] 1754 	jz	00105$
                                   1755 ;	quantum/action.c:1090: wait_ms(1);
      00782B 90 00 01         [24] 1756 	mov	dptr,#0x0001
      00782E 12 5B 08         [24] 1757 	lcall	_mDelaymS
                                   1758 ;	quantum/action.c:1089: for (uint16_t i = delay; i > 0; i--) {
      007831 1D               [12] 1759 	dec	r5
      007832 BD FF 01         [24] 1760 	cjne	r5,#0xff,00141$
      007835 1E               [12] 1761 	dec	r6
      007836                       1762 00141$:
      007836 80 EF            [24] 1763 	sjmp	00110$
      007838                       1764 00105$:
                                   1765 ;	quantum/action.c:1092: unregister_code(code);
      007838 8F 82            [24] 1766 	mov	dpl, r7
                                   1767 ;	quantum/action.c:1093: }
      00783A 02 77 A4         [24] 1768 	ljmp	_unregister_code
                                   1769 ;------------------------------------------------------------
                                   1770 ;Allocation info for local variables in function 'tap_code'
                                   1771 ;------------------------------------------------------------
                                   1772 ;code          Allocated with name '_tap_code_code_10000_748'
                                   1773 ;------------------------------------------------------------
                                   1774 ;	quantum/action.c:1099: __attribute__((weak)) void tap_code(uint8_t code) {
                                   1775 ;	-----------------------------------------
                                   1776 ;	 function tap_code
                                   1777 ;	-----------------------------------------
      00783D                       1778 _tap_code:
      00783D E5 82            [12] 1779 	mov	a,dpl
      00783F 90 08 4A         [24] 1780 	mov	dptr,#_tap_code_code_10000_748
      007842 F0               [24] 1781 	movx	@dptr,a
                                   1782 ;	quantum/action.c:1100: tap_code_delay(code, code == KC_CAPS ? QS_tap_hold_caps_delay : QS_tap_code_delay);
      007843 E0               [24] 1783 	movx	a,@dptr
      007844 FF               [12] 1784 	mov	r7,a
      007845 BF 39 04         [24] 1785 	cjne	r7,#0x39,00103$
      007848 7E 50            [12] 1786 	mov	r6,#0x50
      00784A 80 02            [24] 1787 	sjmp	00104$
      00784C                       1788 00103$:
      00784C 7E 00            [12] 1789 	mov	r6,#0x00
      00784E                       1790 00104$:
      00784E 90 08 47         [24] 1791 	mov	dptr,#_tap_code_delay_PARM_2
      007851 EE               [12] 1792 	mov	a,r6
      007852 12 3A E7         [24] 1793 	lcall	_ak820_outline_0134
      007855 8F 82            [24] 1794 	mov	dpl, r7
                                   1795 ;	quantum/action.c:1101: }
      007857 02 78 10         [24] 1796 	ljmp	_tap_code_delay
                                   1797 ;------------------------------------------------------------
                                   1798 ;Allocation info for local variables in function 'register_mods'
                                   1799 ;------------------------------------------------------------
                                   1800 ;mods          Allocated with name '_register_mods_mods_10000_750'
                                   1801 ;------------------------------------------------------------
                                   1802 ;	quantum/action.c:1107: __attribute__((weak)) void register_mods(uint8_t mods) {
                                   1803 ;	-----------------------------------------
                                   1804 ;	 function register_mods
                                   1805 ;	-----------------------------------------
      00785A                       1806 _register_mods:
      00785A E5 82            [12] 1807 	mov	a,dpl
      00785C 90 08 4B         [24] 1808 	mov	dptr,#_register_mods_mods_10000_750
      00785F F0               [24] 1809 	movx	@dptr,a
                                   1810 ;	quantum/action.c:1108: if (mods) {
      007860 E0               [24] 1811 	movx	a,@dptr
      007861 FF               [12] 1812 	mov	r7,a
      007862 E0               [24] 1813 	movx	a,@dptr
      007863 60 08            [24] 1814 	jz	00103$
                                   1815 ;	quantum/action.c:1109: add_owned_mods(mods);
      007865 8F 82            [24] 1816 	mov	dpl, r7
      007867 12 7E CC         [24] 1817 	lcall	_add_owned_mods
                                   1818 ;	quantum/action.c:1110: send_keyboard_report();
                                   1819 ;	quantum/action.c:1112: }
      00786A 02 82 06         [24] 1820 	ljmp	_send_keyboard_report
      00786D                       1821 00103$:
      00786D 22               [24] 1822 	ret
                                   1823 ;------------------------------------------------------------
                                   1824 ;Allocation info for local variables in function 'unregister_mods'
                                   1825 ;------------------------------------------------------------
                                   1826 ;mods          Allocated with name '_unregister_mods_mods_10000_754'
                                   1827 ;------------------------------------------------------------
                                   1828 ;	quantum/action.c:1118: __attribute__((weak)) void unregister_mods(uint8_t mods) {
                                   1829 ;	-----------------------------------------
                                   1830 ;	 function unregister_mods
                                   1831 ;	-----------------------------------------
      00786E                       1832 _unregister_mods:
      00786E E5 82            [12] 1833 	mov	a,dpl
      007870 90 08 4C         [24] 1834 	mov	dptr,#_unregister_mods_mods_10000_754
      007873 F0               [24] 1835 	movx	@dptr,a
                                   1836 ;	quantum/action.c:1119: if (mods) {
      007874 E0               [24] 1837 	movx	a,@dptr
      007875 FF               [12] 1838 	mov	r7,a
      007876 E0               [24] 1839 	movx	a,@dptr
      007877 60 08            [24] 1840 	jz	00103$
                                   1841 ;	quantum/action.c:1120: del_owned_mods(mods);
      007879 8F 82            [24] 1842 	mov	dpl, r7
      00787B 12 7E DC         [24] 1843 	lcall	_del_owned_mods
                                   1844 ;	quantum/action.c:1121: send_keyboard_report();
                                   1845 ;	quantum/action.c:1123: }
      00787E 02 82 06         [24] 1846 	ljmp	_send_keyboard_report
      007881                       1847 00103$:
      007881 22               [24] 1848 	ret
                                   1849 ;------------------------------------------------------------
                                   1850 ;Allocation info for local variables in function 'register_weak_mods'
                                   1851 ;------------------------------------------------------------
                                   1852 ;mods          Allocated with name '_register_weak_mods_mods_10000_758'
                                   1853 ;------------------------------------------------------------
                                   1854 ;	quantum/action.c:1129: __attribute__((weak)) void register_weak_mods(uint8_t mods) {
                                   1855 ;	-----------------------------------------
                                   1856 ;	 function register_weak_mods
                                   1857 ;	-----------------------------------------
      007882                       1858 _register_weak_mods:
      007882 E5 82            [12] 1859 	mov	a,dpl
      007884 90 08 4D         [24] 1860 	mov	dptr,#_register_weak_mods_mods_10000_758
      007887 F0               [24] 1861 	movx	@dptr,a
                                   1862 ;	quantum/action.c:1130: if (mods) {
      007888 E0               [24] 1863 	movx	a,@dptr
      007889 FF               [12] 1864 	mov	r7,a
      00788A E0               [24] 1865 	movx	a,@dptr
      00788B 60 08            [24] 1866 	jz	00103$
                                   1867 ;	quantum/action.c:1131: add_owned_weak_mods(mods);
      00788D 8F 82            [24] 1868 	mov	dpl, r7
      00788F 12 7E EB         [24] 1869 	lcall	_add_owned_weak_mods
                                   1870 ;	quantum/action.c:1132: send_keyboard_report();
                                   1871 ;	quantum/action.c:1134: }
      007892 02 82 06         [24] 1872 	ljmp	_send_keyboard_report
      007895                       1873 00103$:
      007895 22               [24] 1874 	ret
                                   1875 ;------------------------------------------------------------
                                   1876 ;Allocation info for local variables in function 'unregister_weak_mods'
                                   1877 ;------------------------------------------------------------
                                   1878 ;mods          Allocated with name '_unregister_weak_mods_mods_10000_762'
                                   1879 ;------------------------------------------------------------
                                   1880 ;	quantum/action.c:1140: __attribute__((weak)) void unregister_weak_mods(uint8_t mods) {
                                   1881 ;	-----------------------------------------
                                   1882 ;	 function unregister_weak_mods
                                   1883 ;	-----------------------------------------
      007896                       1884 _unregister_weak_mods:
      007896 E5 82            [12] 1885 	mov	a,dpl
      007898 90 08 4E         [24] 1886 	mov	dptr,#_unregister_weak_mods_mods_10000_762
      00789B F0               [24] 1887 	movx	@dptr,a
                                   1888 ;	quantum/action.c:1141: if (mods) {
      00789C E0               [24] 1889 	movx	a,@dptr
      00789D FF               [12] 1890 	mov	r7,a
      00789E E0               [24] 1891 	movx	a,@dptr
      00789F 60 08            [24] 1892 	jz	00103$
                                   1893 ;	quantum/action.c:1142: del_owned_weak_mods(mods);
      0078A1 8F 82            [24] 1894 	mov	dpl, r7
      0078A3 12 7E FB         [24] 1895 	lcall	_del_owned_weak_mods
                                   1896 ;	quantum/action.c:1143: send_keyboard_report();
                                   1897 ;	quantum/action.c:1145: }
      0078A6 02 82 06         [24] 1898 	ljmp	_send_keyboard_report
      0078A9                       1899 00103$:
      0078A9 22               [24] 1900 	ret
                                   1901 ;------------------------------------------------------------
                                   1902 ;Allocation info for local variables in function 'clear_keyboard'
                                   1903 ;------------------------------------------------------------
                                   1904 ;	quantum/action.c:1151: void clear_keyboard(void) {
                                   1905 ;	-----------------------------------------
                                   1906 ;	 function clear_keyboard
                                   1907 ;	-----------------------------------------
      0078AA                       1908 _clear_keyboard:
                                   1909 ;	quantum/action.c:1152: clear_mods();
      0078AA 12 82 81         [24] 1910 	lcall	_clear_mods
                                   1911 ;	quantum/action.c:1153: clear_keyboard_but_mods();
                                   1912 ;	quantum/action.c:1154: }
      0078AD 02 78 B0         [24] 1913 	ljmp	_clear_keyboard_but_mods
                                   1914 ;------------------------------------------------------------
                                   1915 ;Allocation info for local variables in function 'clear_keyboard_but_mods'
                                   1916 ;------------------------------------------------------------
                                   1917 ;	quantum/action.c:1160: void clear_keyboard_but_mods(void) {
                                   1918 ;	-----------------------------------------
                                   1919 ;	 function clear_keyboard_but_mods
                                   1920 ;	-----------------------------------------
      0078B0                       1921 _clear_keyboard_but_mods:
                                   1922 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0078B0 90 0D D3         [24] 1923 	mov	dptr,#_actual_keyboard_report
      0078B3 12 71 5A         [24] 1924 	lcall	_clear_keys_from_report
                                   1925 ;	quantum/action.c:1162: clear_keyboard_but_mods_and_keys();
                                   1926 ;	quantum/action.c:1163: }
      0078B6 02 78 B9         [24] 1927 	ljmp	_clear_keyboard_but_mods_and_keys
                                   1928 ;------------------------------------------------------------
                                   1929 ;Allocation info for local variables in function 'clear_keyboard_but_mods_and_keys'
                                   1930 ;------------------------------------------------------------
                                   1931 ;	quantum/action.c:1169: void clear_keyboard_but_mods_and_keys(void) {
                                   1932 ;	-----------------------------------------
                                   1933 ;	 function clear_keyboard_but_mods_and_keys
                                   1934 ;	-----------------------------------------
      0078B9                       1935 _clear_keyboard_but_mods_and_keys:
                                   1936 ;	quantum/action.c:1171: ak820_tapping_cancel();
      0078B9 12 49 16         [24] 1937 	lcall	_ak820_tapping_cancel
                                   1938 ;	quantum/action.c:1179: ak820_autoshift_cancel();
      0078BC 12 33 4A         [24] 1939 	lcall	_ak820_autoshift_cancel
                                   1940 ;	quantum/action.c:1182: ak820_oneshot_cancel();
      0078BF 12 2E F0         [24] 1941 	lcall	_ak820_oneshot_cancel
                                   1942 ;	quantum/action.c:1185: ak820_combo_cancel();
      0078C2 12 37 BB         [24] 1943 	lcall	_ak820_combo_cancel
                                   1944 ;	quantum/action.c:1188: repeat_key_cancel();
      0078C5 12 A3 40         [24] 1945 	lcall	_repeat_key_cancel
                                   1946 ;	quantum/action.c:1190: clear_owned_mods();
      0078C8 12 7F 0B         [24] 1947 	lcall	_clear_owned_mods
                                   1948 ;	quantum/action.c:1191: clear_owned_keys();
      0078CB 12 7F 43         [24] 1949 	lcall	_clear_owned_keys
                                   1950 ;	quantum/action.c:1192: clear_owned_usages();
      0078CE 12 80 79         [24] 1951 	lcall	_clear_owned_usages
                                   1952 ;	quantum/action.c:1193: layer_hold_clear();
      0078D1 12 7A B7         [24] 1953 	lcall	_layer_hold_clear
                                   1954 ;	quantum/action.c:1195: clear_macro_tri_layer();
      0078D4 12 9D FF         [24] 1955 	lcall	_clear_macro_tri_layer
                                   1956 ;	quantum/action_util.h:50: clear_keys_from_report(keyboard_report);
      0078D7 90 0D D3         [24] 1957 	mov	dptr,#_actual_keyboard_report
      0078DA 12 71 5A         [24] 1958 	lcall	_clear_keys_from_report
                                   1959 ;	quantum/action.c:1200: host_system_send(0);
      0078DD 90 00 00         [24] 1960 	mov	dptr,#0x0000
      0078E0 12 6F 2E         [24] 1961 	lcall	_host_system_send
                                   1962 ;	quantum/action.c:1201: host_consumer_send(0);
      0078E3 90 00 00         [24] 1963 	mov	dptr,#0x0000
      0078E6 12 6F 5E         [24] 1964 	lcall	_host_consumer_send
                                   1965 ;	quantum/action.c:1203: clear_weak_mods();
      0078E9 12 82 B6         [24] 1966 	lcall	_clear_weak_mods
                                   1967 ;	quantum/action.c:1204: send_keyboard_report();
                                   1968 ;	quantum/action.c:1212: }
      0078EC 02 82 06         [24] 1969 	ljmp	_send_keyboard_report
                                   1970 ;------------------------------------------------------------
                                   1971 ;Allocation info for local variables in function 'is_tap_record'
                                   1972 ;------------------------------------------------------------
                                   1973 ;record        Allocated with name '_is_tap_record_record_10000_778'
                                   1974 ;action        Allocated with name '_is_tap_record_action_10001_782'
                                   1975 ;------------------------------------------------------------
                                   1976 ;	quantum/action.c:1218: bool is_tap_record(keyrecord_t *record) {
                                   1977 ;	-----------------------------------------
                                   1978 	.area CSEG    (CODE)
                                   1979 	.area CONST   (CODE)
                                   1980 	.area XINIT   (CODE)
      00C2C0                       1981 __xinit__disable_action_cache:
      00C2C0 00                    1982 	.db #0x00	;  0
                                   1983 	.area CABS    (ABS,CODE)
                                   1984 
                                   1985 ; Experimental exact instruction outlining.
                                   1986 	.globl _ak820_outline_0001
                                   1987 	.globl _ak820_outline_0005
                                   1988 	.globl _ak820_outline_0007
                                   1989 	.globl _ak820_outline_0008
                                   1990 	.globl _ak820_outline_0011
                                   1991 	.globl _ak820_outline_0012
                                   1992 	.globl _ak820_outline_0013
                                   1993 	.globl _ak820_outline_0014
                                   1994 	.globl _ak820_outline_0017
                                   1995 	.globl _ak820_outline_0021
                                   1996 	.globl _ak820_outline_0022
                                   1997 	.globl _ak820_outline_0034
                                   1998 	.globl _ak820_outline_0037
                                   1999 	.globl _ak820_outline_0042
                                   2000 	.globl _ak820_outline_0057
                                   2001 	.globl _ak820_outline_0061
                                   2002 	.globl _ak820_outline_0064
                                   2003 	.globl _ak820_outline_0070
                                   2004 	.globl _ak820_outline_0072
                                   2005 	.globl _ak820_outline_0078
                                   2006 	.globl _ak820_outline_0079
                                   2007 	.globl _ak820_outline_0089
                                   2008 	.globl _ak820_outline_0093
                                   2009 	.globl _ak820_outline_0107
                                   2010 	.globl _ak820_outline_0108
                                   2011 	.globl _ak820_outline_0110
                                   2012 	.globl _ak820_outline_0112
                                   2013 	.globl _ak820_outline_0113
                                   2014 	.globl _ak820_outline_0118
                                   2015 	.globl _ak820_outline_0123
                                   2016 	.globl _ak820_outline_0124
                                   2017 	.globl _ak820_outline_0130
                                   2018 	.globl _ak820_outline_0133
                                   2019 	.globl _ak820_outline_0134
                                   2020 	.globl _ak820_outline_0142
                                   2021 	.globl _ak820_outline_0146
                                   2022 	.globl _ak820_outline_0149
                                   2023 	.globl _ak820_outline_0157
                                   2024 	.globl _ak820_outline_0159
                                   2025 	.globl _ak820_outline_0167
                                   2026 	.globl _ak820_outline_0168
                                   2027 	.globl _ak820_outline_0182
                                   2028 	.globl _ak820_outline_0187
                                   2029 
                                   2030 	.area CSEG (CODE)
                                   2031 ; function ak820_outline_0013
      0078EF                       2032 _ak820_outline_0013:
      0078EF 2D               [12] 2033 	add	a,r5
      0078F0 F9               [12] 2034 	mov	r1,a
      0078F1 E4               [12] 2035 	clr	a
      0078F2 3E               [12] 2036 	addc	a,r6
      0078F3 FA               [12] 2037 	mov	r2,a
      0078F4 8F 03            [24] 2038 	mov	ar3,r7
      0078F6 89 82            [24] 2039 	mov	dpl,r1
      0078F8 8A 83            [24] 2040 	mov	dph,r2
      0078FA 8B F0            [24] 2041 	mov	b,r3
      0078FC 22               [24] 2042 	ret
                                   2043 
                                   2044 	.area CSEG (CODE)
                                   2045 ; function ak820_outline_0014
      0078FD                       2046 _ak820_outline_0014:
      0078FD 2D               [12] 2047 	add	a,r5
      0078FE FA               [12] 2048 	mov	r2,a
      0078FF E4               [12] 2049 	clr	a
      007900 3E               [12] 2050 	addc	a,r6
      007901 FB               [12] 2051 	mov	r3,a
      007902 8F 04            [24] 2052 	mov	ar4,r7
      007904 8A 82            [24] 2053 	mov	dpl,r2
      007906 8B 83            [24] 2054 	mov	dph,r3
      007908 8C F0            [24] 2055 	mov	b,r4
      00790A 22               [24] 2056 	ret
                                   2057 
                                   2058 	.area CSEG (CODE)
                                   2059 ; function ak820_outline_0021
      00790B                       2060 _ak820_outline_0021:
      00790B 8E 82            [24] 2061 	mov	dpl,r6
      00790D 8F 83            [24] 2062 	mov	dph,r7
      00790F A3               [24] 2063 	inc	dptr
      007910 E0               [24] 2064 	movx	a,@dptr
      007911 FC               [12] 2065 	mov	r4,a
      007912 7D 00            [12] 2066 	mov	r5,#0x00
      007914 8E 82            [24] 2067 	mov	dpl,r6
      007916 8F 83            [24] 2068 	mov	dph,r7
      007918 E0               [24] 2069 	movx	a,@dptr
      007919 22               [24] 2070 	ret
                                   2071 
                                   2072 	.area CSEG (CODE)
                                   2073 ; function ak820_outline_0042
      00791A                       2074 _ak820_outline_0042:
      00791A 90 08 40         [24] 2075 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00791D E0               [24] 2076 	movx	a,@dptr
      00791E 54 1F            [12] 2077 	anl	a,#0x1f
      007920 F5 82            [12] 2078 	mov	dpl,a
      007922 22               [24] 2079 	ret
                                   2080 
                                   2081 	.area CSEG (CODE)
                                   2082 ; function ak820_outline_0061
      007923                       2083 _ak820_outline_0061:
      007923 F5 F0            [12] 2084 	mov	b,a
      007925 05 F0            [12] 2085 	inc	b
      007927 74 01            [12] 2086 	mov	a,#0x01
      007929 22               [24] 2087 	ret
                                   2088 
                                   2089 	.area CSEG (CODE)
                                   2090 ; function ak820_outline_0070
      00792A                       2091 _ak820_outline_0070:
      00792A 90 0D B0         [24] 2092 	mov	dptr,#___memcpy_PARM_3
      00792D 74 06            [12] 2093 	mov	a,#0x06
      00792F F0               [24] 2094 	movx	@dptr,a
      007930 E4               [12] 2095 	clr	a
      007931 A3               [24] 2096 	inc	dptr
      007932 F0               [24] 2097 	movx	@dptr,a
      007933 22               [24] 2098 	ret
                                   2099 
                                   2100 	.area CSEG (CODE)
                                   2101 ; function ak820_outline_0078
      007934                       2102 _ak820_outline_0078:
      007934 90 08 3F         [24] 2103 	mov	dptr,#_process_action_PARM_2
      007937 E0               [24] 2104 	movx	a,@dptr
      007938 F5 82            [12] 2105 	mov	dpl,a
      00793A 22               [24] 2106 	ret
                                   2107 
                                   2108 	.area CSEG (CODE)
                                   2109 ; function ak820_outline_0089
      00793B                       2110 _ak820_outline_0089:
      00793B 90 08 40         [24] 2111 	mov	dptr,#(_process_action_PARM_2+0x0001)
      00793E E0               [24] 2112 	movx	a,@dptr
      00793F 03               [12] 2113 	rr	a
      007940 03               [12] 2114 	rr	a
      007941 54 03            [12] 2115 	anl	a,#0x03
      007943 22               [24] 2116 	ret
                                   2117 
                                   2118 	.area CSEG (CODE)
                                   2119 ; function ak820_outline_0113
      007944                       2120 _ak820_outline_0113:
      007944 90 08 40         [24] 2121 	mov	dptr,#(_process_action_PARM_2+0x0001)
      007947 E0               [24] 2122 	movx	a,@dptr
      007948 54 0F            [12] 2123 	anl	a,#0x0f
      00794A 22               [24] 2124 	ret
                                   2125 
                                   2126 	.area CSEG (CODE)
                                   2127 ; function ak820_outline_0130
      00794B                       2128 _ak820_outline_0130:
      00794B 90 08 3F         [24] 2129 	mov	dptr,#_process_action_PARM_2
      00794E E0               [24] 2130 	movx	a,@dptr
      00794F FE               [12] 2131 	mov	r6,a
      007950 A3               [24] 2132 	inc	dptr
      007951 E0               [24] 2133 	movx	a,@dptr
      007952 54 03            [12] 2134 	anl	a,#0x03
      007954 FF               [12] 2135 	mov	r7,a
      007955 22               [24] 2136 	ret
                                   2137 
                                   2138 	.area CSEG (CODE)
                                   2139 ; function ak820_outline_0146
      007956                       2140 _ak820_outline_0146:
      007956 74 07            [12] 2141 	mov	a,#0x07
      007958 2D               [12] 2142 	add	a,r5
      007959 F8               [12] 2143 	mov	r0,a
      00795A E4               [12] 2144 	clr	a
      00795B 3E               [12] 2145 	addc	a,r6
      00795C F9               [12] 2146 	mov	r1,a
      00795D 8F 02            [24] 2147 	mov	ar2,r7
      00795F 22               [24] 2148 	ret
                                   2149 
                                   2150 	.area CSEG (CODE)
                                   2151 ; function ak820_outline_0159
      007960                       2152 _ak820_outline_0159:
      007960 90 08 3F         [24] 2153 	mov	dptr,#_process_action_PARM_2
      007963 E0               [24] 2154 	movx	a,@dptr
      007964 22               [24] 2155 	ret
                                   2156 
                                   2157 	.area CSEG (CODE)
                                   2158 ; function ak820_outline_0167
      007965                       2159 _ak820_outline_0167:
      007965 90 08 45         [24] 2160 	mov	dptr,#_register_code_code_10000_714
      007968 E0               [24] 2161 	movx	a,@dptr
      007969 FF               [12] 2162 	mov	r7,a
      00796A 22               [24] 2163 	ret
                                   2164 
                                   2165 	.area CSEG (CODE)
                                   2166 ; function ak820_outline_0168
      00796B                       2167 _ak820_outline_0168:
      00796B 90 08 46         [24] 2168 	mov	dptr,#_unregister_code_code_10000_728
      00796E E0               [24] 2169 	movx	a,@dptr
      00796F FF               [12] 2170 	mov	r7,a
      007970 22               [24] 2171 	ret
                                   2172 
                                   2173 	.area CSEG (CODE)
                                   2174 ; function ak820_outline_0187
      007971                       2175 _ak820_outline_0187:
      007971 F0               [24] 2176 	movx	@dptr,a
      007972 EB               [12] 2177 	mov	a,r3
      007973 A3               [24] 2178 	inc	dptr
      007974 F0               [24] 2179 	movx	@dptr,a
      007975 22               [24] 2180 	ret
