                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module dynamic_keymap
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _dynamic_keymap_encoder_to_eeprom_address
                                     12 	.globl _ak820_combo_valid
                                     13 	.globl _ak820_eeprom_write_block_xdata
                                     14 	.globl _ak820_eeprom_read_block_xdata
                                     15 	.globl _ak820_nvm_flush
                                     16 	.globl _ak820_nvm_ok
                                     17 	.globl _ak820_macro_reset
                                     18 	.globl _ak820_macro_write
                                     19 	.globl _ak820_macro_length
                                     20 	.globl _ak820_macro_ready
                                     21 	.globl _send_char
                                     22 	.globl _keycode_at_encodermap_location_raw
                                     23 	.globl _keycode_at_keymap_location_raw
                                     24 	.globl _vial_keycode_tap
                                     25 	.globl _vial_keycode_up
                                     26 	.globl _vial_keycode_down
                                     27 	.globl _clear_keyboard
                                     28 	.globl _tap_code
                                     29 	.globl _unregister_code
                                     30 	.globl _register_code
                                     31 	.globl _mDelaymS
                                     32 	.globl ___memcpy
                                     33 	.globl _memset
                                     34 	.globl _eeprom_update_byte
                                     35 	.globl _eeprom_read_byte
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _dynamic_keymap_macro_set_buffer_PARM_3
                                    280 	.globl _dynamic_keymap_macro_set_buffer_PARM_2
                                    281 	.globl _dynamic_keymap_macro_get_buffer_PARM_3
                                    282 	.globl _dynamic_keymap_macro_get_buffer_PARM_2
                                    283 	.globl _keycode_at_encodermap_location_PARM_3
                                    284 	.globl _keycode_at_encodermap_location_PARM_2
                                    285 	.globl _keycode_at_keymap_location_PARM_3
                                    286 	.globl _keycode_at_keymap_location_PARM_2
                                    287 	.globl _dynamic_keymap_set_buffer_PARM_3
                                    288 	.globl _dynamic_keymap_set_buffer_PARM_2
                                    289 	.globl _dynamic_keymap_get_buffer_PARM_3
                                    290 	.globl _dynamic_keymap_get_buffer_PARM_2
                                    291 	.globl _dynamic_keymap_set_combo_PARM_2
                                    292 	.globl _dynamic_keymap_get_combo_PARM_2
                                    293 	.globl _dynamic_keymap_set_encoder_PARM_4
                                    294 	.globl _dynamic_keymap_set_encoder_PARM_3
                                    295 	.globl _dynamic_keymap_set_encoder_PARM_2
                                    296 	.globl _dynamic_keymap_get_encoder_PARM_3
                                    297 	.globl _dynamic_keymap_get_encoder_PARM_2
                                    298 	.globl _dynamic_keymap_encoder_to_eeprom_address_PARM_2
                                    299 	.globl _dynamic_keymap_set_keycode_PARM_4
                                    300 	.globl _dynamic_keymap_set_keycode_PARM_3
                                    301 	.globl _dynamic_keymap_set_keycode_PARM_2
                                    302 	.globl _dynamic_keymap_get_keycode_PARM_3
                                    303 	.globl _dynamic_keymap_get_keycode_PARM_2
                                    304 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_3
                                    305 	.globl _dynamic_keymap_key_to_eeprom_address_PARM_2
                                    306 	.globl _dynamic_keymap_get_layer_count
                                    307 	.globl _dynamic_keymap_key_to_eeprom_address
                                    308 	.globl _dynamic_keymap_get_keycode
                                    309 	.globl _dynamic_keymap_set_keycode
                                    310 	.globl _dynamic_keymap_get_encoder
                                    311 	.globl _dynamic_keymap_set_encoder
                                    312 	.globl _dynamic_keymap_get_combo
                                    313 	.globl _dynamic_keymap_set_combo
                                    314 	.globl _dynamic_keymap_reset
                                    315 	.globl _dynamic_keymap_get_buffer
                                    316 	.globl _dynamic_keymap_set_buffer
                                    317 	.globl _keycode_at_keymap_location
                                    318 	.globl _keycode_at_encodermap_location
                                    319 	.globl _dynamic_keymap_macro_get_count
                                    320 	.globl _dynamic_keymap_macro_get_buffer_size
                                    321 	.globl _dynamic_keymap_macro_get_buffer
                                    322 	.globl _dynamic_keymap_macro_set_buffer
                                    323 	.globl _dynamic_keymap_macro_reset
                                    324 	.globl _dynamic_keymap_macro_send
                                    325 ;--------------------------------------------------------
                                    326 ; special function registers
                                    327 ;--------------------------------------------------------
                                    328 	.area RSEG    (ABS,DATA)
      000000                        329 	.org 0x0000
                           0000D0   330 _PSW	=	0x00d0
                           0000E0   331 _ACC	=	0x00e0
                           0000F0   332 _B	=	0x00f0
                           0000FD   333 _A_INV	=	0x00fd
                           000081   334 _SP	=	0x0081
                           000082   335 _DPL	=	0x0082
                           000083   336 _DPH	=	0x0083
                           0000A1   337 _SAFE_MOD	=	0x00a1
                           0000B1   338 _GLOBAL_CFG	=	0x00b1
                           000087   339 _PCON	=	0x0087
                           0000BA   340 _POWER_CFG	=	0x00ba
                           0000B9   341 _CLOCK_CFG	=	0x00b9
                           0000A9   342 _WAKE_CTRL	=	0x00a9
                           0000FE   343 _RESET_KEEP	=	0x00fe
                           0000FF   344 _WDOG_COUNT	=	0x00ff
                           0000A8   345 _IE	=	0x00a8
                           0000B8   346 _IP	=	0x00b8
                           0000E8   347 _IE_EX	=	0x00e8
                           0000E9   348 _IP_EX	=	0x00e9
                           0000B2   349 _GPIO_IE	=	0x00b2
                           008584   350 _ROM_ADDR	=	0x8584
                           000084   351 _ROM_ADDR_L	=	0x0084
                           000085   352 _ROM_ADDR_H	=	0x0085
                           008F8E   353 _ROM_DATA_HI	=	0x8f8e
                           00008E   354 _ROM_DATA_HL	=	0x008e
                           00008F   355 _ROM_DATA_HH	=	0x008f
                           000086   356 _ROM_CTRL	=	0x0086
                           000080   357 _P0	=	0x0080
                           0000C4   358 _P0_MOD_OC	=	0x00c4
                           0000C5   359 _P0_DIR_PU	=	0x00c5
                           000090   360 _P1	=	0x0090
                           000092   361 _P1_MOD_OC	=	0x0092
                           000093   362 _P1_DIR_PU	=	0x0093
                           0000A0   363 _P2	=	0x00a0
                           000094   364 _P2_MOD_OC	=	0x0094
                           000095   365 _P2_DIR_PU	=	0x0095
                           0000B0   366 _P3	=	0x00b0
                           000096   367 _P3_MOD_OC	=	0x0096
                           000097   368 _P3_DIR_PU	=	0x0097
                           0000C0   369 _P4	=	0x00c0
                           0000C2   370 _P4_MOD_OC	=	0x00c2
                           0000C3   371 _P4_DIR_PU	=	0x00c3
                           0000C1   372 _P4_LED_KEY	=	0x00c1
                           0000AA   373 _P5_IN	=	0x00aa
                           0000AB   374 _P5_OUT_PU	=	0x00ab
                           0000AC   375 _P5_DIR	=	0x00ac
                           0000AD   376 _P6_IN	=	0x00ad
                           0000AE   377 _P6_OUT_PU	=	0x00ae
                           0000AF   378 _P6_DIR	=	0x00af
                           0000F1   379 _P7	=	0x00f1
                           0000A2   380 _XBUS_AUX	=	0x00a2
                           000088   381 _TCON	=	0x0088
                           000089   382 _TMOD	=	0x0089
                           00008A   383 _TL0	=	0x008a
                           00008B   384 _TL1	=	0x008b
                           00008C   385 _TH0	=	0x008c
                           00008D   386 _TH1	=	0x008d
                           000098   387 _SCON	=	0x0098
                           000099   388 _SBUF	=	0x0099
                           0000C8   389 _T2CON	=	0x00c8
                           0000C9   390 _T2MOD	=	0x00c9
                           00CBCA   391 _RCAP2	=	0xcbca
                           0000CA   392 _RCAP2L	=	0x00ca
                           0000CB   393 _RCAP2H	=	0x00cb
                           00CDCC   394 _T2COUNT	=	0xcdcc
                           0000CC   395 _TL2	=	0x00cc
                           0000CD   396 _TH2	=	0x00cd
                           00CFCE   397 _T2CAP1	=	0xcfce
                           0000CE   398 _T2CAP1L	=	0x00ce
                           0000CF   399 _T2CAP1H	=	0x00cf
                           0000F8   400 _SPI0_STAT	=	0x00f8
                           0000F9   401 _SPI0_DATA	=	0x00f9
                           0000FA   402 _SPI0_CTRL	=	0x00fa
                           0000FB   403 _SPI0_CK_SE	=	0x00fb
                           0000FC   404 _SPI0_SETUP	=	0x00fc
                           0000BC   405 _SCON1	=	0x00bc
                           0000BD   406 _SBUF1	=	0x00bd
                           0000BE   407 _SBAUD1	=	0x00be
                           0000BF   408 _SIF1	=	0x00bf
                           0000B4   409 _SPI1_STAT	=	0x00b4
                           0000B5   410 _SPI1_DATA	=	0x00b5
                           0000B6   411 _SPI1_CTRL	=	0x00b6
                           0000B7   412 _SPI1_CK_SE	=	0x00b7
                           0000F3   413 _ADC_CTRL	=	0x00f3
                           00F5F4   414 _ADC_DAT	=	0xf5f4
                           0000F4   415 _ADC_DAT_L	=	0x00f4
                           0000F5   416 _ADC_DAT_H	=	0x00f5
                           0000F6   417 _ADC_CHAN	=	0x00f6
                           0000A6   418 _LED_COMMON	=	0x00a6
                           0000A7   419 _LED_PWM_OE	=	0x00a7
                           00C7C6   420 _LED_DMA	=	0xc7c6
                           0000C6   421 _LED_DMA_L	=	0x00c6
                           0000C7   422 _LED_DMA_H	=	0x00c7
                           0000F7   423 _LED_STATUS	=	0x00f7
                           0000B3   424 _I2CX_INT	=	0x00b3
                           0000BB   425 _I2CS_INT_ST	=	0x00bb
                                    426 ;--------------------------------------------------------
                                    427 ; special function bits
                                    428 ;--------------------------------------------------------
                                    429 	.area RSEG    (ABS,DATA)
      000000                        430 	.org 0x0000
                           0000D7   431 _CY	=	0x00d7
                           0000D6   432 _AC	=	0x00d6
                           0000D5   433 _F0	=	0x00d5
                           0000D4   434 _RS1	=	0x00d4
                           0000D3   435 _RS0	=	0x00d3
                           0000D2   436 _OV	=	0x00d2
                           0000D1   437 _F1	=	0x00d1
                           0000D0   438 _P	=	0x00d0
                           0000AF   439 _EA	=	0x00af
                           0000AE   440 _E_DIS	=	0x00ae
                           0000AD   441 _ET2	=	0x00ad
                           0000AC   442 _ES	=	0x00ac
                           0000AB   443 _ET1	=	0x00ab
                           0000AA   444 _EX1	=	0x00aa
                           0000A9   445 _ET0	=	0x00a9
                           0000A8   446 _EX0	=	0x00a8
                           0000BF   447 _PH_FLAG	=	0x00bf
                           0000BE   448 _PL_FLAG	=	0x00be
                           0000BD   449 _PT2	=	0x00bd
                           0000BC   450 _PS	=	0x00bc
                           0000BB   451 _PT1	=	0x00bb
                           0000BA   452 _PX1	=	0x00ba
                           0000B9   453 _PT0	=	0x00b9
                           0000B8   454 _PX0	=	0x00b8
                           0000EF   455 _IE_WDOG	=	0x00ef
                           0000EE   456 _IE_GPIO	=	0x00ee
                           0000ED   457 _IE_PWM_I2C	=	0x00ed
                           0000EC   458 _IE_UART1	=	0x00ec
                           0000EB   459 _IE_ADC	=	0x00eb
                           0000E9   460 _IE_USB	=	0x00e9
                           0000E8   461 _IE_SPI0	=	0x00e8
                           000087   462 _P0_7	=	0x0087
                           000086   463 _P0_6	=	0x0086
                           000085   464 _P0_5	=	0x0085
                           000084   465 _P0_4	=	0x0084
                           000083   466 _P0_3	=	0x0083
                           000082   467 _P0_2	=	0x0082
                           000081   468 _P0_1	=	0x0081
                           000080   469 _P0_0	=	0x0080
                           000081   470 _SDA0	=	0x0081
                           000080   471 _SCL0	=	0x0080
                           000083   472 _TXD_	=	0x0083
                           000082   473 _RXD_	=	0x0082
                           000085   474 _AIN13	=	0x0085
                           000084   475 _AIN12	=	0x0084
                           000083   476 _AIN11	=	0x0083
                           000082   477 _AIN10	=	0x0082
                           000081   478 _AIN9	=	0x0081
                           000080   479 _AIN8	=	0x0080
                           000097   480 _P1_7	=	0x0097
                           000096   481 _P1_6	=	0x0096
                           000095   482 _P1_5	=	0x0095
                           000094   483 _P1_4	=	0x0094
                           000093   484 _P1_3	=	0x0093
                           000092   485 _P1_2	=	0x0092
                           000091   486 _P1_1	=	0x0091
                           000090   487 _P1_0	=	0x0090
                           000097   488 _TXD1_	=	0x0097
                           000096   489 _RXD1_	=	0x0096
                           000097   490 _SCK	=	0x0097
                           000096   491 _MISO	=	0x0096
                           000095   492 _MOSI	=	0x0095
                           000094   493 _SCS	=	0x0094
                           000092   494 _INT0_	=	0x0092
                           000091   495 _T2EX	=	0x0091
                           000091   496 _CAP2	=	0x0091
                           000090   497 _T2	=	0x0090
                           000090   498 _CAP1	=	0x0090
                           000097   499 _AIN7	=	0x0097
                           000096   500 _AIN6	=	0x0096
                           000095   501 _AIN5	=	0x0095
                           000094   502 _AIN4	=	0x0094
                           000093   503 _AIN3	=	0x0093
                           000092   504 _AIN2	=	0x0092
                           000091   505 _AIN1	=	0x0091
                           000090   506 _AIN0	=	0x0090
                           0000A7   507 _P2_7	=	0x00a7
                           0000A6   508 _P2_6	=	0x00a6
                           0000A5   509 _P2_5	=	0x00a5
                           0000A4   510 _P2_4	=	0x00a4
                           0000A3   511 _P2_3	=	0x00a3
                           0000A2   512 _P2_2	=	0x00a2
                           0000A1   513 _P2_1	=	0x00a1
                           0000A0   514 _P2_0	=	0x00a0
                           0000A7   515 _TXD1	=	0x00a7
                           0000A6   516 _RXD1	=	0x00a6
                           0000A5   517 _T2EX_	=	0x00a5
                           0000A5   518 _CAP2_	=	0x00a5
                           0000A4   519 _T2_	=	0x00a4
                           0000A4   520 _CAP1_	=	0x00a4
                           0000B7   521 _P3_7	=	0x00b7
                           0000B6   522 _P3_6	=	0x00b6
                           0000B5   523 _P3_5	=	0x00b5
                           0000B4   524 _P3_4	=	0x00b4
                           0000B3   525 _P3_3	=	0x00b3
                           0000B2   526 _P3_2	=	0x00b2
                           0000B1   527 _P3_1	=	0x00b1
                           0000B0   528 _P3_0	=	0x00b0
                           0000B7   529 _SCK1	=	0x00b7
                           0000B6   530 _MISO1	=	0x00b6
                           0000B5   531 _MOSI1	=	0x00b5
                           0000B5   532 _T1	=	0x00b5
                           0000B4   533 _T0	=	0x00b4
                           0000B3   534 _INT1	=	0x00b3
                           0000B2   535 _INT0	=	0x00b2
                           0000B1   536 _TXD	=	0x00b1
                           0000B0   537 _RXD	=	0x00b0
                           0000C6   538 _P4_6	=	0x00c6
                           0000C5   539 _P4_5	=	0x00c5
                           0000C4   540 _P4_4	=	0x00c4
                           0000C3   541 _P4_3	=	0x00c3
                           0000C2   542 _P4_2	=	0x00c2
                           0000C1   543 _P4_1	=	0x00c1
                           0000C0   544 _P4_0	=	0x00c0
                           00008F   545 _TF1	=	0x008f
                           00008E   546 _TR1	=	0x008e
                           00008D   547 _TF0	=	0x008d
                           00008C   548 _TR0	=	0x008c
                           00008B   549 _IE1	=	0x008b
                           00008A   550 _IT1	=	0x008a
                           000089   551 _IE0	=	0x0089
                           000088   552 _IT0	=	0x0088
                           00009F   553 _SM0	=	0x009f
                           00009E   554 _SM1	=	0x009e
                           00009D   555 _SM2	=	0x009d
                           00009C   556 _REN	=	0x009c
                           00009B   557 _TB8	=	0x009b
                           00009A   558 _RB8	=	0x009a
                           000099   559 _TI	=	0x0099
                           000098   560 _RI	=	0x0098
                           0000CF   561 _TF2	=	0x00cf
                           0000CF   562 _CAP1F	=	0x00cf
                           0000CE   563 _EXF2	=	0x00ce
                           0000CD   564 _RCLK	=	0x00cd
                           0000CC   565 _TCLK	=	0x00cc
                           0000CB   566 _EXEN2	=	0x00cb
                           0000CA   567 _TR2	=	0x00ca
                           0000C9   568 _C_T2	=	0x00c9
                           0000C8   569 _CP_RL2	=	0x00c8
                           0000FF   570 _S0_FST_ACT	=	0x00ff
                           0000FE   571 _S0_IF_OV	=	0x00fe
                           0000FD   572 _S0_IF_FIRST	=	0x00fd
                           0000FC   573 _S0_IF_BYTE	=	0x00fc
                           0000FB   574 _S0_FREE	=	0x00fb
                           0000FA   575 _S0_T_FIFO	=	0x00fa
                           0000F8   576 _S0_R_FIFO	=	0x00f8
                           0000F7   577 _ADC_START	=	0x00f7
                                    578 ;--------------------------------------------------------
                                    579 ; overlayable register banks
                                    580 ;--------------------------------------------------------
                                    581 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        582 	.ds 8
                                    583 ;--------------------------------------------------------
                                    584 ; internal ram data
                                    585 ;--------------------------------------------------------
                                    586 	.area DSEG    (DATA)
      000029                        587 _dynamic_keymap_set_encoder_sloc0_1_0:
      000029                        588 	.ds 2
      00002B                        589 _dynamic_keymap_get_combo_sloc0_1_0:
      00002B                        590 	.ds 1
      00002C                        591 _ak820_dynamic_read_buffer_sloc0_1_0:
      00002C                        592 	.ds 1
      00002D                        593 _dynamic_keymap_set_buffer_sloc0_1_0:
      00002D                        594 	.ds 2
      00002F                        595 _dynamic_keymap_set_buffer_sloc1_1_0:
      00002F                        596 	.ds 2
      000031                        597 _dynamic_keymap_set_buffer_sloc2_1_0:
      000031                        598 	.ds 1
      000032                        599 _dynamic_keymap_macro_get_buffer_sloc0_1_0:
      000032                        600 	.ds 2
                                    601 ;--------------------------------------------------------
                                    602 ; overlayable items in internal ram
                                    603 ;--------------------------------------------------------
                                    604 ;--------------------------------------------------------
                                    605 ; indirectly addressable internal ram data
                                    606 ;--------------------------------------------------------
                                    607 	.area ISEG    (DATA)
                                    608 ;--------------------------------------------------------
                                    609 ; absolute internal ram data
                                    610 ;--------------------------------------------------------
                                    611 	.area IABS    (ABS,DATA)
                                    612 	.area IABS    (ABS,DATA)
                                    613 ;--------------------------------------------------------
                                    614 ; bit data
                                    615 ;--------------------------------------------------------
                                    616 	.area BSEG    (BIT)
      000025                        617 _dynamic_keymap_macro_send_sloc0_1_0:
      000025                        618 	.ds 1
                                    619 ;--------------------------------------------------------
                                    620 ; paged external ram data
                                    621 ;--------------------------------------------------------
                                    622 	.area PSEG    (PAG,XDATA)
                                    623 ;--------------------------------------------------------
                                    624 ; uninitialized external ram data
                                    625 ;--------------------------------------------------------
                                    626 	.area XSEG    (XDATA)
      000AE5                        627 _dynamic_keymap_key_to_eeprom_address_PARM_2:
      000AE5                        628 	.ds 1
      000AE6                        629 _dynamic_keymap_key_to_eeprom_address_PARM_3:
      000AE6                        630 	.ds 1
      000AE7                        631 _dynamic_keymap_key_to_eeprom_address_layer_10000_364:
      000AE7                        632 	.ds 1
      000AE8                        633 _dynamic_keymap_get_keycode_PARM_2:
      000AE8                        634 	.ds 1
      000AE9                        635 _dynamic_keymap_get_keycode_PARM_3:
      000AE9                        636 	.ds 1
      000AEA                        637 _dynamic_keymap_get_keycode_layer_10000_366:
      000AEA                        638 	.ds 1
      000AEB                        639 _dynamic_keymap_set_keycode_PARM_2:
      000AEB                        640 	.ds 1
      000AEC                        641 _dynamic_keymap_set_keycode_PARM_3:
      000AEC                        642 	.ds 1
      000AED                        643 _dynamic_keymap_set_keycode_PARM_4:
      000AED                        644 	.ds 2
      000AEF                        645 _dynamic_keymap_set_keycode_layer_10000_370:
      000AEF                        646 	.ds 1
      000AF0                        647 _dynamic_keymap_encoder_to_eeprom_address_PARM_2:
      000AF0                        648 	.ds 1
      000AF1                        649 _dynamic_keymap_encoder_to_eeprom_address_layer_10000_374:
      000AF1                        650 	.ds 1
      000AF2                        651 _dynamic_keymap_get_encoder_PARM_2:
      000AF2                        652 	.ds 1
      000AF3                        653 _dynamic_keymap_get_encoder_PARM_3:
      000AF3                        654 	.ds 1
      000AF4                        655 _dynamic_keymap_get_encoder_layer_10000_376:
      000AF4                        656 	.ds 1
      000AF5                        657 _dynamic_keymap_set_encoder_PARM_2:
      000AF5                        658 	.ds 1
      000AF6                        659 _dynamic_keymap_set_encoder_PARM_3:
      000AF6                        660 	.ds 1
      000AF7                        661 _dynamic_keymap_set_encoder_PARM_4:
      000AF7                        662 	.ds 2
      000AF9                        663 _dynamic_keymap_set_encoder_layer_10000_380:
      000AF9                        664 	.ds 1
      000AFA                        665 _dynamic_keymap_get_combo_PARM_2:
      000AFA                        666 	.ds 3
      000AFD                        667 _dynamic_keymap_get_combo_index_10000_384:
      000AFD                        668 	.ds 1
      000AFE                        669 _dynamic_keymap_set_combo_PARM_2:
      000AFE                        670 	.ds 3
      000B01                        671 _dynamic_keymap_set_combo_index_10000_390:
      000B01                        672 	.ds 1
      000B02                        673 _dynamic_keymap_set_combo_stored_10002_395:
      000B02                        674 	.ds 10
      000B0C                        675 _dynamic_keymap_reset_vial_unlocked_prev_10000_398:
      000B0C                        676 	.ds 1
      000B0D                        677 _dynamic_keymap_reset_combo_10001_407:
      000B0D                        678 	.ds 10
      000B17                        679 _ak820_dynamic_read_buffer_PARM_2:
      000B17                        680 	.ds 2
      000B19                        681 _ak820_dynamic_read_buffer_PARM_3:
      000B19                        682 	.ds 2
      000B1B                        683 _ak820_dynamic_read_buffer_PARM_4:
      000B1B                        684 	.ds 2
      000B1D                        685 _ak820_dynamic_read_buffer_PARM_5:
      000B1D                        686 	.ds 3
      000B20                        687 _ak820_dynamic_read_buffer_base_10000_409:
      000B20                        688 	.ds 2
      000B22                        689 _ak820_dynamic_read_buffer_available_10000_410:
      000B22                        690 	.ds 1
      000B23                        691 _dynamic_keymap_get_buffer_PARM_2:
      000B23                        692 	.ds 2
      000B25                        693 _dynamic_keymap_get_buffer_PARM_3:
      000B25                        694 	.ds 3
      000B28                        695 _dynamic_keymap_get_buffer_offset_10000_416:
      000B28                        696 	.ds 2
      000B2A                        697 _dynamic_keymap_set_buffer_PARM_2:
      000B2A                        698 	.ds 2
      000B2C                        699 _dynamic_keymap_set_buffer_PARM_3:
      000B2C                        700 	.ds 3
      000B2F                        701 _dynamic_keymap_set_buffer_offset_10000_418:
      000B2F                        702 	.ds 2
      000B31                        703 _dynamic_keymap_set_buffer_chk_offset_30001_425:
      000B31                        704 	.ds 1
      000B32                        705 _dynamic_keymap_set_buffer_chk_sz_30001_425:
      000B32                        706 	.ds 1
      000B33                        707 _dynamic_keymap_set_buffer_i_40001_432:
      000B33                        708 	.ds 1
      000B34                        709 _keycode_at_keymap_location_PARM_2:
      000B34                        710 	.ds 1
      000B35                        711 _keycode_at_keymap_location_PARM_3:
      000B35                        712 	.ds 1
      000B36                        713 _keycode_at_keymap_location_layer_num_10000_436:
      000B36                        714 	.ds 1
      000B37                        715 _keycode_at_encodermap_location_PARM_2:
      000B37                        716 	.ds 1
      000B38                        717 _keycode_at_encodermap_location_PARM_3:
      000B38                        718 	.ds 1
      000B39                        719 _keycode_at_encodermap_location_layer_num_10000_440:
      000B39                        720 	.ds 1
      000B3A                        721 _dynamic_keymap_macro_get_buffer_PARM_2:
      000B3A                        722 	.ds 2
      000B3C                        723 _dynamic_keymap_macro_get_buffer_PARM_3:
      000B3C                        724 	.ds 3
      000B3F                        725 _dynamic_keymap_macro_get_buffer_offset_10000_448:
      000B3F                        726 	.ds 2
      000B41                        727 _dynamic_keymap_macro_set_buffer_PARM_2:
      000B41                        728 	.ds 2
      000B43                        729 _dynamic_keymap_macro_set_buffer_PARM_3:
      000B43                        730 	.ds 3
      000B46                        731 _dynamic_keymap_macro_set_buffer_offset_10000_450:
      000B46                        732 	.ds 2
      000B48                        733 _decode_keycode_kc_10000_454:
      000B48                        734 	.ds 2
      000B4A                        735 _dynamic_keymap_macro_send_id_10000_457:
      000B4A                        736 	.ds 1
      000B4B                        737 _dynamic_keymap_macro_send_sending_10000_458:
      000B4B                        738 	.ds 1
      000B4C                        739 _dynamic_keymap_macro_send_p_10001_463:
      000B4C                        740 	.ds 2
      000B4E                        741 _dynamic_keymap_macro_send_data_10003_470:
      000B4E                        742 	.ds 4
                                    743 ;--------------------------------------------------------
                                    744 ; absolute external ram data
                                    745 ;--------------------------------------------------------
                                    746 	.area XABS    (ABS,XDATA)
                                    747 ;--------------------------------------------------------
                                    748 ; initialized external ram data
                                    749 ;--------------------------------------------------------
                                    750 	.area XISEG   (XDATA)
                                    751 	.area HOME    (CODE)
                                    752 	.area GSINIT0 (CODE)
                                    753 	.area GSINIT1 (CODE)
                                    754 	.area GSINIT2 (CODE)
                                    755 	.area GSINIT3 (CODE)
                                    756 	.area GSINIT4 (CODE)
                                    757 	.area GSINIT5 (CODE)
                                    758 	.area GSINIT  (CODE)
                                    759 	.area GSFINAL (CODE)
                                    760 	.area CSEG    (CODE)
                                    761 ;--------------------------------------------------------
                                    762 ; global & static initialisations
                                    763 ;--------------------------------------------------------
                                    764 	.area HOME    (CODE)
                                    765 	.area GSINIT  (CODE)
                                    766 	.area GSFINAL (CODE)
                                    767 	.area GSINIT  (CODE)
                                    768 ;--------------------------------------------------------
                                    769 ; Home
                                    770 ;--------------------------------------------------------
                                    771 	.area HOME    (CODE)
                                    772 	.area HOME    (CODE)
                                    773 ;--------------------------------------------------------
                                    774 ; code
                                    775 ;--------------------------------------------------------
                                    776 	.area CSEG    (CODE)
                                    777 ;------------------------------------------------------------
                                    778 ;Allocation info for local variables in function 'KEYCODE2SYSTEM'
                                    779 ;------------------------------------------------------------
                                    780 ;key           Allocated with name '_KEYCODE2SYSTEM_key_10000_230'
                                    781 ;------------------------------------------------------------
                                    782 ;	tmk_core/protocol/report.h:262: static inline uint16_t KEYCODE2SYSTEM(uint8_t key) {
                                    783 ;	-----------------------------------------
                           000007   784 	ar7 = 0x07
                           000006   785 	ar6 = 0x06
                           000005   786 	ar5 = 0x05
                           000004   787 	ar4 = 0x04
                           000003   788 	ar3 = 0x03
                           000002   789 	ar2 = 0x02
                           000001   790 	ar1 = 0x01
                           000000   791 	ar0 = 0x00
                                    792 ;	 function dynamic_keymap_get_layer_count
                                    793 ;	-----------------------------------------
      0085AC                        794 _dynamic_keymap_get_layer_count:
                                    795 ;	quantum/dynamic_keymap.c:178: return DYNAMIC_KEYMAP_LAYER_COUNT;
      0085AC 75 82 06         [24]  796 	mov	dpl, #0x06
                                    797 ;	quantum/dynamic_keymap.c:179: }
      0085AF 22               [24]  798 	ret
                                    799 ;------------------------------------------------------------
                                    800 ;Allocation info for local variables in function 'dynamic_keymap_key_to_eeprom_address'
                                    801 ;------------------------------------------------------------
                                    802 ;row           Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_2'
                                    803 ;column        Allocated with name '_dynamic_keymap_key_to_eeprom_address_PARM_3'
                                    804 ;layer         Allocated with name '_dynamic_keymap_key_to_eeprom_address_layer_10000_364'
                                    805 ;------------------------------------------------------------
                                    806 ;	quantum/dynamic_keymap.c:181: void *dynamic_keymap_key_to_eeprom_address(uint8_t layer, uint8_t row, uint8_t column) {
                                    807 ;	-----------------------------------------
                                    808 ;	 function dynamic_keymap_key_to_eeprom_address
                                    809 ;	-----------------------------------------
      0085B0                        810 _dynamic_keymap_key_to_eeprom_address:
      0085B0 E5 82            [12]  811 	mov	a,dpl
      0085B2 90 0A E7         [24]  812 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_layer_10000_364
      0085B5 F0               [24]  813 	movx	@dptr,a
                                    814 ;	quantum/dynamic_keymap.c:183: return ((uint8_t *)DYNAMIC_KEYMAP_EEPROM_ADDR) + (layer * MATRIX_ROWS * MATRIX_COLS * 2) + (row * MATRIX_COLS * 2) + (column * 2);
      0085B6 E0               [24]  815 	movx	a,@dptr
      0085B7 FF               [12]  816 	mov	r7,a
      0085B8 7E 00            [12]  817 	mov	r6,#0x00
      0085BA 74 40            [12]  818 	mov	a,#0x40
      0085BC 12 45 AC         [24]  819 	lcall	_ak820_outline_0137
      0085BF 7D 00            [12]  820 	mov	r5,#0x00
      0085C1 90 0A E5         [24]  821 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      0085C4 E0               [24]  822 	movx	a,@dptr
      0085C5 75 F0 10         [24]  823 	mov	b,#0x10
      0085C8 A4               [48]  824 	mul	ab
      0085C9 2E               [12]  825 	add	a, r6
      0085CA FE               [12]  826 	mov	r6,a
      0085CB EF               [12]  827 	mov	a,r7
      0085CC 35 F0            [12]  828 	addc	a, b
      0085CE FF               [12]  829 	mov	r7,a
      0085CF 90 0A E6         [24]  830 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      0085D2 E0               [24]  831 	movx	a,@dptr
      0085D3 7C 00            [12]  832 	mov	r4,#0x00
      0085D5 25 E0            [12]  833 	add	a,acc
      0085D7 FB               [12]  834 	mov	r3,a
      0085D8 EC               [12]  835 	mov	a,r4
      0085D9 33               [12]  836 	rlc	a
      0085DA FC               [12]  837 	mov	r4,a
      0085DB EB               [12]  838 	mov	a,r3
      0085DC 2E               [12]  839 	add	a, r6
      0085DD FE               [12]  840 	mov	r6,a
      0085DE EC               [12]  841 	mov	a,r4
      0085DF 3F               [12]  842 	addc	a, r7
      0085E0 FF               [12]  843 	mov	r7,a
      0085E1 12 71 B9         [24]  844 	lcall	_ak820_outline_0064
                                    845 ;	quantum/dynamic_keymap.c:184: }
      0085E4 22               [24]  846 	ret
                                    847 ;------------------------------------------------------------
                                    848 ;Allocation info for local variables in function 'dynamic_keymap_get_keycode'
                                    849 ;------------------------------------------------------------
                                    850 ;row           Allocated with name '_dynamic_keymap_get_keycode_PARM_2'
                                    851 ;column        Allocated with name '_dynamic_keymap_get_keycode_PARM_3'
                                    852 ;layer         Allocated with name '_dynamic_keymap_get_keycode_layer_10000_366'
                                    853 ;address       Allocated with name '_dynamic_keymap_get_keycode_address_10001_369'
                                    854 ;keycode       Allocated with name '_dynamic_keymap_get_keycode_keycode_10001_369'
                                    855 ;------------------------------------------------------------
                                    856 ;	quantum/dynamic_keymap.c:186: uint16_t dynamic_keymap_get_keycode(uint8_t layer, uint8_t row, uint8_t column) {
                                    857 ;	-----------------------------------------
                                    858 ;	 function dynamic_keymap_get_keycode
                                    859 ;	-----------------------------------------
      0085E5                        860 _dynamic_keymap_get_keycode:
      0085E5 E5 82            [12]  861 	mov	a,dpl
      0085E7 90 0A EA         [24]  862 	mov	dptr,#_dynamic_keymap_get_keycode_layer_10000_366
      0085EA F0               [24]  863 	movx	@dptr,a
                                    864 ;	quantum/dynamic_keymap.c:187: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return KC_NO;
      0085EB E0               [24]  865 	movx	a,@dptr
      0085EC FF               [12]  866 	mov	r7,a
      0085ED BF 06 00         [24]  867 	cjne	r7,#0x06,00121$
      0085F0                        868 00121$:
      0085F0 50 14            [24]  869 	jnc	00101$
      0085F2 90 0A E8         [24]  870 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      0085F5 E0               [24]  871 	movx	a,@dptr
      0085F6 FE               [12]  872 	mov	r6,a
      0085F7 BE 10 00         [24]  873 	cjne	r6,#0x10,00123$
      0085FA                        874 00123$:
      0085FA 50 0A            [24]  875 	jnc	00101$
      0085FC 90 0A E9         [24]  876 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      0085FF E0               [24]  877 	movx	a,@dptr
      008600 FD               [12]  878 	mov	r5,a
      008601 BD 08 00         [24]  879 	cjne	r5,#0x08,00125$
      008604                        880 00125$:
      008604 40 04            [24]  881 	jc	00102$
      008606                        882 00101$:
      008606 90 00 00         [24]  883 	mov	dptr,#0x0000
      008609 22               [24]  884 	ret
      00860A                        885 00102$:
                                    886 ;	quantum/dynamic_keymap.c:188: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      00860A 12 90 40         [24]  887 	lcall	_ak820_outline_0099
      00860D 12 85 B0         [24]  888 	lcall	_dynamic_keymap_key_to_eeprom_address
                                    889 ;	quantum/dynamic_keymap.c:190: uint16_t keycode = eeprom_read_byte(address) << 8;
      008610 12 90 54         [24]  890 	lcall	_ak820_outline_0116
      008613 12 42 BF         [24]  891 	lcall	_eeprom_read_byte
      008616 AB 82            [24]  892 	mov	r3,dpl
      008618 7C 00            [12]  893 	mov	r4,#0x00
                                    894 ;	quantum/dynamic_keymap.c:191: keycode |= eeprom_read_byte(address + 1);
      00861A 0D               [12]  895 	inc	r5
      00861B BD 00 01         [24]  896 	cjne	r5,#0x00,00127$
      00861E 0E               [12]  897 	inc	r6
      00861F                        898 00127$:
      00861F 12 6F A4         [24]  899 	lcall	_ak820_outline_0057
      008622 12 42 BF         [24]  900 	lcall	_eeprom_read_byte
      008625 AF 82            [24]  901 	mov	r7, dpl
      008627 7E 00            [12]  902 	mov	r6,#0x00
      008629 EF               [12]  903 	mov	a,r7
      00862A 42 04            [12]  904 	orl	ar4,a
      00862C EE               [12]  905 	mov	a,r6
      00862D 42 03            [12]  906 	orl	ar3,a
                                    907 ;	quantum/dynamic_keymap.c:192: return keycode;
      00862F 12 45 D3         [24]  908 	lcall	_ak820_outline_0184
                                    909 ;	quantum/dynamic_keymap.c:193: }
      008632 22               [24]  910 	ret
                                    911 ;------------------------------------------------------------
                                    912 ;Allocation info for local variables in function 'dynamic_keymap_set_keycode'
                                    913 ;------------------------------------------------------------
                                    914 ;row           Allocated with name '_dynamic_keymap_set_keycode_PARM_2'
                                    915 ;column        Allocated with name '_dynamic_keymap_set_keycode_PARM_3'
                                    916 ;keycode       Allocated with name '_dynamic_keymap_set_keycode_PARM_4'
                                    917 ;layer         Allocated with name '_dynamic_keymap_set_keycode_layer_10000_370'
                                    918 ;address       Allocated with name '_dynamic_keymap_set_keycode_address_10001_373'
                                    919 ;------------------------------------------------------------
                                    920 ;	quantum/dynamic_keymap.c:195: void dynamic_keymap_set_keycode(uint8_t layer, uint8_t row, uint8_t column, uint16_t keycode) {
                                    921 ;	-----------------------------------------
                                    922 ;	 function dynamic_keymap_set_keycode
                                    923 ;	-----------------------------------------
      008633                        924 _dynamic_keymap_set_keycode:
      008633 E5 82            [12]  925 	mov	a,dpl
      008635 90 0A EF         [24]  926 	mov	dptr,#_dynamic_keymap_set_keycode_layer_10000_370
      008638 F0               [24]  927 	movx	@dptr,a
                                    928 ;	quantum/dynamic_keymap.c:196: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || row >= MATRIX_ROWS || column >= MATRIX_COLS) return;
      008639 E0               [24]  929 	movx	a,@dptr
      00863A FF               [12]  930 	mov	r7,a
      00863B BF 06 00         [24]  931 	cjne	r7,#0x06,00121$
      00863E                        932 00121$:
      00863E 50 14            [24]  933 	jnc	00101$
      008640 90 0A EB         [24]  934 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008643 E0               [24]  935 	movx	a,@dptr
      008644 FE               [12]  936 	mov	r6,a
      008645 BE 10 00         [24]  937 	cjne	r6,#0x10,00123$
      008648                        938 00123$:
      008648 50 0A            [24]  939 	jnc	00101$
      00864A 90 0A EC         [24]  940 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      00864D E0               [24]  941 	movx	a,@dptr
      00864E FD               [12]  942 	mov	r5,a
      00864F BD 08 00         [24]  943 	cjne	r5,#0x08,00125$
      008652                        944 00125$:
      008652 40 01            [24]  945 	jc	00102$
      008654                        946 00101$:
      008654 22               [24]  947 	ret
      008655                        948 00102$:
                                    949 ;	quantum/dynamic_keymap.c:197: uint8_t *address = dynamic_keymap_key_to_eeprom_address(layer, row, column);
      008655 12 90 40         [24]  950 	lcall	_ak820_outline_0099
      008658 12 85 B0         [24]  951 	lcall	_dynamic_keymap_key_to_eeprom_address
      00865B 12 90 54         [24]  952 	lcall	_ak820_outline_0116
                                    953 ;	quantum/dynamic_keymap.c:199: eeprom_update_byte(address, (uint8_t)(keycode >> 8));
      00865E 90 0A ED         [24]  954 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      008661 E0               [24]  955 	movx	a,@dptr
      008662 FB               [12]  956 	mov	r3,a
      008663 A3               [24]  957 	inc	dptr
      008664 E0               [24]  958 	movx	a,@dptr
      008665 90 06 AB         [24]  959 	mov	dptr,#_eeprom_update_byte_PARM_2
      008668 12 51 3D         [24]  960 	lcall	_ak820_outline_0034
      00866B 12 50 28         [24]  961 	lcall	_eeprom_update_byte
                                    962 ;	quantum/dynamic_keymap.c:200: eeprom_update_byte(address + 1, (uint8_t)(keycode & 0xFF));
      00866E 0D               [12]  963 	inc	r5
      00866F BD 00 01         [24]  964 	cjne	r5,#0x00,00127$
      008672 0E               [12]  965 	inc	r6
      008673                        966 00127$:
      008673 90 06 AB         [24]  967 	mov	dptr,#_eeprom_update_byte_PARM_2
      008676 EB               [12]  968 	mov	a,r3
      008677 12 51 3D         [24]  969 	lcall	_ak820_outline_0034
                                    970 ;	quantum/dynamic_keymap.c:201: }
      00867A 02 50 28         [24]  971 	ljmp	_eeprom_update_byte
                                    972 ;------------------------------------------------------------
                                    973 ;Allocation info for local variables in function 'dynamic_keymap_encoder_to_eeprom_address'
                                    974 ;------------------------------------------------------------
                                    975 ;encoder_id    Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_PARM_2'
                                    976 ;layer         Allocated with name '_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374'
                                    977 ;------------------------------------------------------------
                                    978 ;	quantum/dynamic_keymap.c:204: void *dynamic_keymap_encoder_to_eeprom_address(uint8_t layer, uint8_t encoder_id) {
                                    979 ;	-----------------------------------------
                                    980 ;	 function dynamic_keymap_encoder_to_eeprom_address
                                    981 ;	-----------------------------------------
      00867D                        982 _dynamic_keymap_encoder_to_eeprom_address:
      00867D E5 82            [12]  983 	mov	a,dpl
      00867F 90 0A F1         [24]  984 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_layer_10000_374
      008682 F0               [24]  985 	movx	@dptr,a
                                    986 ;	quantum/dynamic_keymap.c:205: return ((uint8_t *)DYNAMIC_KEYMAP_ENCODER_EEPROM_ADDR) + (layer * NUM_ENCODERS * 2 * 2) + (encoder_id * 2 * 2);
      008683 E0               [24]  987 	movx	a,@dptr
      008684 75 F0 04         [24]  988 	mov	b,#0x04
      008687 A4               [48]  989 	mul	ab
      008688 24 40            [12]  990 	add	a, #0x40
      00868A FD               [12]  991 	mov	r5,a
      00868B 74 06            [12]  992 	mov	a,#0x06
      00868D 35 F0            [12]  993 	addc	a, b
      00868F FE               [12]  994 	mov	r6,a
      008690 7F 00            [12]  995 	mov	r7,#0x00
      008692 90 0A F0         [24]  996 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008695 E0               [24]  997 	movx	a,@dptr
      008696 75 F0 04         [24]  998 	mov	b,#0x04
      008699 A4               [48]  999 	mul	ab
      00869A 2D               [12] 1000 	add	a, r5
      00869B FD               [12] 1001 	mov	r5,a
      00869C EE               [12] 1002 	mov	a,r6
      00869D 35 F0            [12] 1003 	addc	a, b
      00869F FE               [12] 1004 	mov	r6,a
      0086A0 12 6F A4         [24] 1005 	lcall	_ak820_outline_0057
                                   1006 ;	quantum/dynamic_keymap.c:206: }
      0086A3 22               [24] 1007 	ret
                                   1008 ;------------------------------------------------------------
                                   1009 ;Allocation info for local variables in function 'dynamic_keymap_get_encoder'
                                   1010 ;------------------------------------------------------------
                                   1011 ;encoder_id    Allocated with name '_dynamic_keymap_get_encoder_PARM_2'
                                   1012 ;clockwise     Allocated with name '_dynamic_keymap_get_encoder_PARM_3'
                                   1013 ;layer         Allocated with name '_dynamic_keymap_get_encoder_layer_10000_376'
                                   1014 ;address       Allocated with name '_dynamic_keymap_get_encoder_address_10001_379'
                                   1015 ;keycode       Allocated with name '_dynamic_keymap_get_encoder_keycode_10001_379'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/dynamic_keymap.c:208: uint16_t dynamic_keymap_get_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function dynamic_keymap_get_encoder
                                   1020 ;	-----------------------------------------
      0086A4                       1021 _dynamic_keymap_get_encoder:
      0086A4 E5 82            [12] 1022 	mov	a,dpl
      0086A6 90 0A F4         [24] 1023 	mov	dptr,#_dynamic_keymap_get_encoder_layer_10000_376
      0086A9 F0               [24] 1024 	movx	@dptr,a
                                   1025 ;	quantum/dynamic_keymap.c:209: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return KC_NO;
      0086AA E0               [24] 1026 	movx	a,@dptr
      0086AB FF               [12] 1027 	mov	r7,a
      0086AC BF 06 00         [24] 1028 	cjne	r7,#0x06,00131$
      0086AF                       1029 00131$:
      0086AF 50 0A            [24] 1030 	jnc	00101$
      0086B1 90 0A F2         [24] 1031 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      0086B4 E0               [24] 1032 	movx	a,@dptr
      0086B5 FE               [12] 1033 	mov	r6,a
      0086B6 BE 01 00         [24] 1034 	cjne	r6,#0x01,00133$
      0086B9                       1035 00133$:
      0086B9 40 04            [24] 1036 	jc	00102$
      0086BB                       1037 00101$:
      0086BB 90 00 00         [24] 1038 	mov	dptr,#0x0000
      0086BE 22               [24] 1039 	ret
      0086BF                       1040 00102$:
                                   1041 ;	quantum/dynamic_keymap.c:210: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      0086BF 90 0A F0         [24] 1042 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      0086C2 E4               [12] 1043 	clr	a
      0086C3 F0               [24] 1044 	movx	@dptr,a
      0086C4 8F 82            [24] 1045 	mov	dpl, r7
      0086C6 12 86 7D         [24] 1046 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      0086C9 12 90 54         [24] 1047 	lcall	_ak820_outline_0116
                                   1048 ;	quantum/dynamic_keymap.c:212: uint16_t keycode = ((uint16_t)eeprom_read_byte(address + (clockwise ? 0 : 2))) << 8;
      0086CC 90 0A F3         [24] 1049 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      0086CF E0               [24] 1050 	movx	a,@dptr
      0086D0 FC               [12] 1051 	mov	r4,a
      0086D1 E0               [24] 1052 	movx	a,@dptr
      0086D2 60 04            [24] 1053 	jz	00106$
      0086D4 7B 00            [12] 1054 	mov	r3,#0x00
      0086D6 80 02            [24] 1055 	sjmp	00107$
      0086D8                       1056 00106$:
      0086D8 7B 02            [12] 1057 	mov	r3,#0x02
      0086DA                       1058 00107$:
      0086DA EB               [12] 1059 	mov	a,r3
      0086DB 12 78 EF         [24] 1060 	lcall	_ak820_outline_0013
      0086DE 12 42 BF         [24] 1061 	lcall	_eeprom_read_byte
      0086E1 AA 82            [24] 1062 	mov	r2,dpl
      0086E3 7B 00            [12] 1063 	mov	r3,#0x00
                                   1064 ;	quantum/dynamic_keymap.c:213: keycode |= eeprom_read_byte(address + (clockwise ? 0 : 2) + 1);
      0086E5 EC               [12] 1065 	mov	a,r4
      0086E6 60 04            [24] 1066 	jz	00108$
      0086E8 7C 00            [12] 1067 	mov	r4,#0x00
      0086EA 80 02            [24] 1068 	sjmp	00109$
      0086EC                       1069 00108$:
      0086EC 7C 02            [12] 1070 	mov	r4,#0x02
      0086EE                       1071 00109$:
      0086EE EC               [12] 1072 	mov	a,r4
      0086EF 12 3B 06         [24] 1073 	lcall	_ak820_outline_0160
      0086F2 0D               [12] 1074 	inc	r5
      0086F3 BD 00 01         [24] 1075 	cjne	r5,#0x00,00137$
      0086F6 0E               [12] 1076 	inc	r6
      0086F7                       1077 00137$:
      0086F7 12 6F A4         [24] 1078 	lcall	_ak820_outline_0057
      0086FA 12 42 BF         [24] 1079 	lcall	_eeprom_read_byte
      0086FD AF 82            [24] 1080 	mov	r7, dpl
      0086FF 7E 00            [12] 1081 	mov	r6,#0x00
      008701 EF               [12] 1082 	mov	a,r7
      008702 42 03            [12] 1083 	orl	ar3,a
      008704 EE               [12] 1084 	mov	a,r6
      008705 42 02            [12] 1085 	orl	ar2,a
                                   1086 ;	quantum/dynamic_keymap.c:214: return keycode;
      008707 8B 82            [24] 1087 	mov	dpl, r3
      008709 8A 83            [24] 1088 	mov	dph, r2
                                   1089 ;	quantum/dynamic_keymap.c:215: }
      00870B 22               [24] 1090 	ret
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'dynamic_keymap_set_encoder'
                                   1093 ;------------------------------------------------------------
                                   1094 ;sloc0         Allocated with name '_dynamic_keymap_set_encoder_sloc0_1_0'
                                   1095 ;encoder_id    Allocated with name '_dynamic_keymap_set_encoder_PARM_2'
                                   1096 ;clockwise     Allocated with name '_dynamic_keymap_set_encoder_PARM_3'
                                   1097 ;keycode       Allocated with name '_dynamic_keymap_set_encoder_PARM_4'
                                   1098 ;layer         Allocated with name '_dynamic_keymap_set_encoder_layer_10000_380'
                                   1099 ;address       Allocated with name '_dynamic_keymap_set_encoder_address_10001_383'
                                   1100 ;------------------------------------------------------------
                                   1101 ;	quantum/dynamic_keymap.c:217: void dynamic_keymap_set_encoder(uint8_t layer, uint8_t encoder_id, bool clockwise, uint16_t keycode) {
                                   1102 ;	-----------------------------------------
                                   1103 ;	 function dynamic_keymap_set_encoder
                                   1104 ;	-----------------------------------------
      00870C                       1105 _dynamic_keymap_set_encoder:
      00870C E5 82            [12] 1106 	mov	a,dpl
      00870E 90 0A F9         [24] 1107 	mov	dptr,#_dynamic_keymap_set_encoder_layer_10000_380
      008711 F0               [24] 1108 	movx	@dptr,a
                                   1109 ;	quantum/dynamic_keymap.c:218: if (layer >= DYNAMIC_KEYMAP_LAYER_COUNT || encoder_id >= NUM_ENCODERS) return;
      008712 E0               [24] 1110 	movx	a,@dptr
      008713 FF               [12] 1111 	mov	r7,a
      008714 BF 06 00         [24] 1112 	cjne	r7,#0x06,00131$
      008717                       1113 00131$:
      008717 50 0A            [24] 1114 	jnc	00101$
      008719 90 0A F5         [24] 1115 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00871C E0               [24] 1116 	movx	a,@dptr
      00871D FE               [12] 1117 	mov	r6,a
      00871E BE 01 00         [24] 1118 	cjne	r6,#0x01,00133$
      008721                       1119 00133$:
      008721 40 01            [24] 1120 	jc	00102$
      008723                       1121 00101$:
      008723 22               [24] 1122 	ret
      008724                       1123 00102$:
                                   1124 ;	quantum/dynamic_keymap.c:219: uint8_t *address = dynamic_keymap_encoder_to_eeprom_address(layer, encoder_id);
      008724 90 0A F0         [24] 1125 	mov	dptr,#_dynamic_keymap_encoder_to_eeprom_address_PARM_2
      008727 E4               [12] 1126 	clr	a
      008728 F0               [24] 1127 	movx	@dptr,a
      008729 8F 82            [24] 1128 	mov	dpl, r7
      00872B 12 86 7D         [24] 1129 	lcall	_dynamic_keymap_encoder_to_eeprom_address
      00872E 12 90 54         [24] 1130 	lcall	_ak820_outline_0116
                                   1131 ;	quantum/dynamic_keymap.c:221: eeprom_update_byte(address + (clockwise ? 0 : 2), (uint8_t)(keycode >> 8));
      008731 90 0A F6         [24] 1132 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      008734 E0               [24] 1133 	movx	a,@dptr
      008735 FC               [12] 1134 	mov	r4,a
      008736 E0               [24] 1135 	movx	a,@dptr
      008737 60 04            [24] 1136 	jz	00106$
      008739 7B 00            [12] 1137 	mov	r3,#0x00
      00873B 80 02            [24] 1138 	sjmp	00107$
      00873D                       1139 00106$:
      00873D 7B 02            [12] 1140 	mov	r3,#0x02
      00873F                       1141 00107$:
      00873F EB               [12] 1142 	mov	a,r3
      008740 12 90 66         [24] 1143 	lcall	_ak820_outline_0136
      008743 8F 03            [24] 1144 	mov	ar3,r7
      008745 90 0A F7         [24] 1145 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008748 E0               [24] 1146 	movx	a,@dptr
      008749 F5 29            [12] 1147 	mov	_dynamic_keymap_set_encoder_sloc0_1_0,a
      00874B A3               [24] 1148 	inc	dptr
      00874C E0               [24] 1149 	movx	a,@dptr
      00874D F5 2A            [12] 1150 	mov	(_dynamic_keymap_set_encoder_sloc0_1_0 + 1),a
      00874F 90 06 AB         [24] 1151 	mov	dptr,#_eeprom_update_byte_PARM_2
      008752 F0               [24] 1152 	movx	@dptr,a
      008753 12 45 CE         [24] 1153 	lcall	_ak820_outline_0183
      008756 8B F0            [24] 1154 	mov	b, r3
      008758 12 50 28         [24] 1155 	lcall	_eeprom_update_byte
                                   1156 ;	quantum/dynamic_keymap.c:222: eeprom_update_byte(address + (clockwise ? 0 : 2) + 1, (uint8_t)(keycode & 0xFF));
      00875B EC               [12] 1157 	mov	a,r4
      00875C 60 04            [24] 1158 	jz	00108$
      00875E 7C 00            [12] 1159 	mov	r4,#0x00
      008760 80 02            [24] 1160 	sjmp	00109$
      008762                       1161 00108$:
      008762 7C 02            [12] 1162 	mov	r4,#0x02
      008764                       1163 00109$:
      008764 EC               [12] 1164 	mov	a,r4
      008765 12 3B 06         [24] 1165 	lcall	_ak820_outline_0160
      008768 0D               [12] 1166 	inc	r5
      008769 BD 00 01         [24] 1167 	cjne	r5,#0x00,00137$
      00876C 0E               [12] 1168 	inc	r6
      00876D                       1169 00137$:
      00876D 90 06 AB         [24] 1170 	mov	dptr,#_eeprom_update_byte_PARM_2
      008770 E5 29            [12] 1171 	mov	a,_dynamic_keymap_set_encoder_sloc0_1_0
      008772 12 51 3D         [24] 1172 	lcall	_ak820_outline_0034
                                   1173 ;	quantum/dynamic_keymap.c:223: }
      008775 02 50 28         [24] 1174 	ljmp	_eeprom_update_byte
                                   1175 ;------------------------------------------------------------
                                   1176 ;Allocation info for local variables in function 'dynamic_keymap_get_combo'
                                   1177 ;------------------------------------------------------------
                                   1178 ;sloc0         Allocated with name '_dynamic_keymap_get_combo_sloc0_1_0'
                                   1179 ;buffer        Allocated with name '_dynamic_keymap_get_combo_PARM_2'
                                   1180 ;index         Allocated with name '_dynamic_keymap_get_combo_index_10000_384'
                                   1181 ;entry         Allocated with name '_dynamic_keymap_get_combo_entry_10000_385'
                                   1182 ;address       Allocated with name '_dynamic_keymap_get_combo_address_10001_387'
                                   1183 ;marked        Allocated with name '_dynamic_keymap_get_combo_marked_10002_388'
                                   1184 ;------------------------------------------------------------
                                   1185 ;	quantum/dynamic_keymap.c:267: int dynamic_keymap_get_combo(uint8_t index, vial_combo_entry_t *buffer) {
                                   1186 ;	-----------------------------------------
                                   1187 ;	 function dynamic_keymap_get_combo
                                   1188 ;	-----------------------------------------
      008778                       1189 _dynamic_keymap_get_combo:
      008778 E5 82            [12] 1190 	mov	a,dpl
      00877A 90 0A FD         [24] 1191 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      00877D F0               [24] 1192 	movx	@dptr,a
                                   1193 ;	quantum/dynamic_keymap.c:270: vial_combo_entry_t AK820_STATE_MEM *entry = (vial_combo_entry_t AK820_STATE_MEM *)buffer;
      00877E 90 0A FA         [24] 1194 	mov	dptr,#_dynamic_keymap_get_combo_PARM_2
      008781 12 3A 8C         [24] 1195 	lcall	_ak820_outline_0051
                                   1196 ;	quantum/dynamic_keymap.c:274: if (index >= VIAL_COMBO_ENTRIES)
      008784 90 0A FD         [24] 1197 	mov	dptr,#_dynamic_keymap_get_combo_index_10000_384
      008787 E0               [24] 1198 	movx	a,@dptr
      008788 FD               [12] 1199 	mov	r5,a
      008789 BD 08 00         [24] 1200 	cjne	r5,#0x08,00132$
      00878C                       1201 00132$:
      00878C 40 04            [24] 1202 	jc	00102$
                                   1203 ;	quantum/dynamic_keymap.c:275: return -1;
      00878E 90 FF FF         [24] 1204 	mov	dptr,#0xffff
      008791 22               [24] 1205 	ret
      008792                       1206 00102$:
                                   1207 ;	quantum/dynamic_keymap.c:277: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      008792 12 90 2C         [24] 1208 	lcall	_ak820_outline_0081
                                   1209 ;	quantum/dynamic_keymap.c:279: ak820_eeprom_read_block_xdata(entry, address, sizeof(vial_combo_entry_t));
      008795 8E 02            [24] 1210 	mov	ar2,r6
      008797 8F 03            [24] 1211 	mov	ar3,r7
      008799 90 05 95         [24] 1212 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      00879C 12 3A A9         [24] 1213 	lcall	_ak820_outline_0072
      00879F E4               [12] 1214 	clr	a
      0087A0 A3               [24] 1215 	inc	dptr
      0087A1 F0               [24] 1216 	movx	@dptr,a
      0087A2 90 05 98         [24] 1217 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      0087A5 12 90 4D         [24] 1218 	lcall	_ak820_outline_0111
      0087A8 12 3A F7         [24] 1219 	lcall	_ak820_outline_0143
      0087AB C0 07            [24] 1220 	push	ar7
      0087AD C0 06            [24] 1221 	push	ar6
      0087AF 12 42 FA         [24] 1222 	lcall	_ak820_eeprom_read_block_xdata
      0087B2 D0 06            [24] 1223 	pop	ar6
      0087B4 D0 07            [24] 1224 	pop	ar7
                                   1225 ;	quantum/dynamic_keymap.c:284: bool marked = entry->input[2] == AK820_COMBO_MARKER && entry->input[3] == AK820_COMBO_VERSION;
      0087B6 74 04            [12] 1226 	mov	a,#0x04
      0087B8 12 4A BB         [24] 1227 	lcall	_ak820_outline_0033
      0087BB FA               [12] 1228 	mov	r2,a
      0087BC A3               [24] 1229 	inc	dptr
      0087BD E0               [24] 1230 	movx	a,@dptr
      0087BE FB               [12] 1231 	mov	r3,a
      0087BF BA 20 13         [24] 1232 	cjne	r2,#0x20,00108$
      0087C2 BB 08 10         [24] 1233 	cjne	r3,#0x08,00108$
      0087C5 74 06            [12] 1234 	mov	a,#0x06
      0087C7 12 3A 7C         [24] 1235 	lcall	_ak820_outline_0022
      0087CA 12 45 95         [24] 1236 	lcall	_ak820_outline_0103
      0087CD BA 01 05         [24] 1237 	cjne	r2,#0x01,00136$
      0087D0 BB 00 02         [24] 1238 	cjne	r3,#0x00,00136$
      0087D3 80 05            [24] 1239 	sjmp	00109$
      0087D5                       1240 00136$:
      0087D5                       1241 00108$:
      0087D5 75 2B 00         [24] 1242 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x00
      0087D8 80 03            [24] 1243 	sjmp	00110$
      0087DA                       1244 00109$:
      0087DA 75 2B 01         [24] 1245 	mov	_dynamic_keymap_get_combo_sloc0_1_0,#0x01
      0087DD                       1246 00110$:
                                   1247 ;	quantum/dynamic_keymap.c:285: entry->input[2] = entry->input[3] = 0;
      0087DD 74 06            [12] 1248 	mov	a,#0x06
      0087DF 12 3A 7C         [24] 1249 	lcall	_ak820_outline_0022
      0087E2 E4               [12] 1250 	clr	a
      0087E3 F0               [24] 1251 	movx	@dptr,a
      0087E4 A3               [24] 1252 	inc	dptr
      0087E5 12 3A C1         [24] 1253 	lcall	_ak820_outline_0101
      0087E8 F0               [24] 1254 	movx	@dptr,a
      0087E9 A3               [24] 1255 	inc	dptr
      0087EA F0               [24] 1256 	movx	@dptr,a
                                   1257 ;	quantum/dynamic_keymap.c:286: if (!marked || !ak820_combo_valid(entry)) memset(entry, 0, sizeof(*entry));
      0087EB E5 2B            [12] 1258 	mov	a,_dynamic_keymap_get_combo_sloc0_1_0
      0087ED 60 12            [24] 1259 	jz	00103$
      0087EF 12 3A D7         [24] 1260 	lcall	_ak820_outline_0118
      0087F2 C0 07            [24] 1261 	push	ar7
      0087F4 C0 06            [24] 1262 	push	ar6
      0087F6 12 37 1C         [24] 1263 	lcall	_ak820_combo_valid
      0087F9 E5 82            [12] 1264 	mov	a, dpl
      0087FB D0 06            [24] 1265 	pop	ar6
      0087FD D0 07            [24] 1266 	pop	ar7
      0087FF 70 13            [24] 1267 	jnz	00104$
      008801                       1268 00103$:
      008801 7D 00            [12] 1269 	mov	r5,#0x00
      008803 90 0D B5         [24] 1270 	mov	dptr,#_memset_PARM_2
      008806 E4               [12] 1271 	clr	a
      008807 F0               [24] 1272 	movx	@dptr,a
      008808 90 0D B6         [24] 1273 	mov	dptr,#_memset_PARM_3
      00880B 12 90 4D         [24] 1274 	lcall	_ak820_outline_0111
      00880E 12 71 B9         [24] 1275 	lcall	_ak820_outline_0064
      008811 12 BA 65         [24] 1276 	lcall	_memset
      008814                       1277 00104$:
                                   1278 ;	quantum/dynamic_keymap.c:289: return 0;
      008814 90 00 00         [24] 1279 	mov	dptr,#0x0000
                                   1280 ;	quantum/dynamic_keymap.c:290: }
      008817 22               [24] 1281 	ret
                                   1282 ;------------------------------------------------------------
                                   1283 ;Allocation info for local variables in function 'dynamic_keymap_set_combo'
                                   1284 ;------------------------------------------------------------
                                   1285 ;buffer        Allocated with name '_dynamic_keymap_set_combo_PARM_2'
                                   1286 ;index         Allocated with name '_dynamic_keymap_set_combo_index_10000_390'
                                   1287 ;entry         Allocated with name '_dynamic_keymap_set_combo_entry_10000_391'
                                   1288 ;address       Allocated with name '_dynamic_keymap_set_combo_address_10001_394'
                                   1289 ;stored        Allocated with name '_dynamic_keymap_set_combo_stored_10002_395'
                                   1290 ;------------------------------------------------------------
                                   1291 ;	quantum/dynamic_keymap.c:292: int dynamic_keymap_set_combo(uint8_t index, const vial_combo_entry_t *buffer) {
                                   1292 ;	-----------------------------------------
                                   1293 ;	 function dynamic_keymap_set_combo
                                   1294 ;	-----------------------------------------
      008818                       1295 _dynamic_keymap_set_combo:
      008818 E5 82            [12] 1296 	mov	a,dpl
      00881A 90 0B 01         [24] 1297 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      00881D F0               [24] 1298 	movx	@dptr,a
                                   1299 ;	quantum/dynamic_keymap.c:294: const vial_combo_entry_t AK820_STATE_MEM *entry = (const vial_combo_entry_t AK820_STATE_MEM *)buffer;
      00881E 90 0A FE         [24] 1300 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      008821 12 3A 3F         [24] 1301 	lcall	_ak820_outline_0005
                                   1302 ;	quantum/dynamic_keymap.c:299: if (!ak820_combo_valid(entry) || !ak820_nvm_ok()) return -1;
      008824 C0 07            [24] 1303 	push	ar7
      008826 C0 06            [24] 1304 	push	ar6
      008828 12 37 1C         [24] 1305 	lcall	_ak820_combo_valid
      00882B E5 82            [12] 1306 	mov	a, dpl
      00882D D0 06            [24] 1307 	pop	ar6
      00882F D0 07            [24] 1308 	pop	ar7
      008831 60 07            [24] 1309 	jz	00101$
      008833 12 40 65         [24] 1310 	lcall	_ak820_nvm_ok
      008836 E5 82            [12] 1311 	mov	a, dpl
      008838 70 04            [24] 1312 	jnz	00102$
      00883A                       1313 00101$:
      00883A 90 FF FF         [24] 1314 	mov	dptr,#0xffff
      00883D 22               [24] 1315 	ret
      00883E                       1316 00102$:
                                   1317 ;	quantum/dynamic_keymap.c:301: if (index >= VIAL_COMBO_ENTRIES)
      00883E 90 0B 01         [24] 1318 	mov	dptr,#_dynamic_keymap_set_combo_index_10000_390
      008841 E0               [24] 1319 	movx	a,@dptr
      008842 FD               [12] 1320 	mov	r5,a
      008843 BD 08 00         [24] 1321 	cjne	r5,#0x08,00133$
      008846                       1322 00133$:
      008846 40 04            [24] 1323 	jc	00105$
                                   1324 ;	quantum/dynamic_keymap.c:302: return -1;
      008848 90 FF FF         [24] 1325 	mov	dptr,#0xffff
      00884B 22               [24] 1326 	ret
      00884C                       1327 00105$:
                                   1328 ;	quantum/dynamic_keymap.c:304: uint8_t *address = (uint8_t *)(VIAL_COMBO_EEPROM_ADDR + index * sizeof(vial_combo_entry_t));
      00884C 12 90 2C         [24] 1329 	lcall	_ak820_outline_0081
                                   1330 ;	quantum/dynamic_keymap.c:306: clear_keyboard();
      00884F C0 07            [24] 1331 	push	ar7
      008851 C0 06            [24] 1332 	push	ar6
      008853 C0 05            [24] 1333 	push	ar5
      008855 C0 04            [24] 1334 	push	ar4
      008857 12 78 AA         [24] 1335 	lcall	_clear_keyboard
      00885A D0 04            [24] 1336 	pop	ar4
      00885C D0 05            [24] 1337 	pop	ar5
      00885E D0 06            [24] 1338 	pop	ar6
      008860 D0 07            [24] 1339 	pop	ar7
                                   1340 ;	quantum/dynamic_keymap.c:307: vial_combo_entry_t stored = *entry;
      008862 90 0D AD         [24] 1341 	mov	dptr,#___memcpy_PARM_2
      008865 12 4A CE         [24] 1342 	lcall	_ak820_outline_0058
      008868 E4               [12] 1343 	clr	a
      008869 A3               [24] 1344 	inc	dptr
      00886A F0               [24] 1345 	movx	@dptr,a
      00886B 90 0D B0         [24] 1346 	mov	dptr,#___memcpy_PARM_3
      00886E 12 90 4D         [24] 1347 	lcall	_ak820_outline_0111
      008871 90 0B 02         [24] 1348 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      008874 F5 F0            [12] 1349 	mov	b,a
      008876 C0 05            [24] 1350 	push	ar5
      008878 C0 04            [24] 1351 	push	ar4
      00887A 12 B9 EF         [24] 1352 	lcall	___memcpy
      00887D D0 04            [24] 1353 	pop	ar4
      00887F D0 05            [24] 1354 	pop	ar5
                                   1355 ;	quantum/dynamic_keymap.c:308: stored.input[2] = AK820_COMBO_MARKER;
      008881 90 0B 06         [24] 1356 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0004)
      008884 74 20            [12] 1357 	mov	a,#0x20
      008886 F0               [24] 1358 	movx	@dptr,a
      008887 74 08            [12] 1359 	mov	a,#0x08
      008889 A3               [24] 1360 	inc	dptr
      00888A F0               [24] 1361 	movx	@dptr,a
                                   1362 ;	quantum/dynamic_keymap.c:309: stored.input[3] = AK820_COMBO_VERSION;
      00888B 90 0B 08         [24] 1363 	mov	dptr,#(_dynamic_keymap_set_combo_stored_10002_395 + 0x0006)
      00888E 74 01            [12] 1364 	mov	a,#0x01
      008890 12 3A E7         [24] 1365 	lcall	_ak820_outline_0134
                                   1366 ;	quantum/dynamic_keymap.c:310: ak820_eeprom_write_block_xdata(&stored, address, sizeof(stored));
      008893 90 05 9E         [24] 1367 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008896 12 3A A9         [24] 1368 	lcall	_ak820_outline_0072
      008899 E4               [12] 1369 	clr	a
      00889A A3               [24] 1370 	inc	dptr
      00889B F0               [24] 1371 	movx	@dptr,a
      00889C 90 05 A1         [24] 1372 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      00889F 12 90 4D         [24] 1373 	lcall	_ak820_outline_0111
      0088A2 90 0B 02         [24] 1374 	mov	dptr,#_dynamic_keymap_set_combo_stored_10002_395
      0088A5 12 43 86         [24] 1375 	lcall	_ak820_eeprom_write_block_xdata
                                   1376 ;	quantum/dynamic_keymap.c:315: ak820_nvm_flush();
      0088A8 12 40 74         [24] 1377 	lcall	_ak820_nvm_flush
                                   1378 ;	quantum/dynamic_keymap.c:316: if (!ak820_nvm_ok()) return -1;
      0088AB 12 40 65         [24] 1379 	lcall	_ak820_nvm_ok
      0088AE E5 82            [12] 1380 	mov	a, dpl
      0088B0 70 04            [24] 1381 	jnz	00107$
      0088B2 90 FF FF         [24] 1382 	mov	dptr,#0xffff
      0088B5 22               [24] 1383 	ret
      0088B6                       1384 00107$:
                                   1385 ;	quantum/dynamic_keymap.c:320: return 0;
      0088B6 90 00 00         [24] 1386 	mov	dptr,#0x0000
                                   1387 ;	quantum/dynamic_keymap.c:321: }
      0088B9 22               [24] 1388 	ret
                                   1389 ;------------------------------------------------------------
                                   1390 ;Allocation info for local variables in function 'dynamic_keymap_reset'
                                   1391 ;------------------------------------------------------------
                                   1392 ;vial_unlocked_prev Allocated with name '_dynamic_keymap_reset_vial_unlocked_prev_10000_398'
                                   1393 ;layer         Allocated with name '_dynamic_keymap_reset_layer_20000_399'
                                   1394 ;row           Allocated with name '_dynamic_keymap_reset_row_40000_401'
                                   1395 ;column        Allocated with name '_dynamic_keymap_reset_column_60000_403'
                                   1396 ;encoder       Allocated with name '_dynamic_keymap_reset_encoder_40000_405'
                                   1397 ;combo         Allocated with name '_dynamic_keymap_reset_combo_10001_407'
                                   1398 ;i             Allocated with name '_dynamic_keymap_reset_i_20001_408'
                                   1399 ;------------------------------------------------------------
                                   1400 ;	quantum/dynamic_keymap.c:346: void dynamic_keymap_reset(void) {
                                   1401 ;	-----------------------------------------
                                   1402 ;	 function dynamic_keymap_reset
                                   1403 ;	-----------------------------------------
      0088BA                       1404 _dynamic_keymap_reset:
                                   1405 ;	quantum/dynamic_keymap.c:357: bool vial_unlocked_prev = vial_unlocked;
      0088BA 90 0E 2E         [24] 1406 	mov	dptr,#_vial_unlocked
      0088BD E0               [24] 1407 	movx	a,@dptr
      0088BE 90 0B 0C         [24] 1408 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      0088C1 F0               [24] 1409 	movx	@dptr,a
                                   1410 ;	quantum/dynamic_keymap.c:358: vial_unlocked = 1;
      0088C2 90 0E 2E         [24] 1411 	mov	dptr,#_vial_unlocked
      0088C5 74 01            [12] 1412 	mov	a,#0x01
      0088C7 F0               [24] 1413 	movx	@dptr,a
                                   1414 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      0088C8 7F 00            [12] 1415 	mov	r7,#0x00
      0088CA                       1416 00116$:
      0088CA BF 06 00         [24] 1417 	cjne	r7,#0x06,00198$
      0088CD                       1418 00198$:
      0088CD 40 03            [24] 1419 	jc	00199$
      0088CF 02 89 7D         [24] 1420 	ljmp	00104$
      0088D2                       1421 00199$:
                                   1422 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      0088D2 7E 00            [12] 1423 	mov	r6,#0x00
      0088D4                       1424 00110$:
      0088D4 BE 10 00         [24] 1425 	cjne	r6,#0x10,00200$
      0088D7                       1426 00200$:
      0088D7 50 4D            [24] 1427 	jnc	00102$
                                   1428 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      0088D9 7D 00            [12] 1429 	mov	r5,#0x00
      0088DB                       1430 00107$:
      0088DB BD 08 00         [24] 1431 	cjne	r5,#0x08,00202$
      0088DE                       1432 00202$:
      0088DE 50 43            [24] 1433 	jnc	00111$
                                   1434 ;	quantum/dynamic_keymap.c:365: dynamic_keymap_set_keycode(layer, row, column, keycode_at_keymap_location_raw(layer, row, column));
      0088E0 90 0B A8         [24] 1435 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_2
      0088E3 EE               [12] 1436 	mov	a,r6
      0088E4 F0               [24] 1437 	movx	@dptr,a
      0088E5 90 0B A9         [24] 1438 	mov	dptr,#_keycode_at_keymap_location_raw_PARM_3
      0088E8 ED               [12] 1439 	mov	a,r5
      0088E9 F0               [24] 1440 	movx	@dptr,a
      0088EA 8F 82            [24] 1441 	mov	dpl, r7
      0088EC C0 07            [24] 1442 	push	ar7
      0088EE C0 06            [24] 1443 	push	ar6
      0088F0 C0 05            [24] 1444 	push	ar5
      0088F2 12 98 78         [24] 1445 	lcall	_keycode_at_keymap_location_raw
      0088F5 AB 82            [24] 1446 	mov	r3, dpl
      0088F7 AC 83            [24] 1447 	mov	r4, dph
      0088F9 D0 05            [24] 1448 	pop	ar5
      0088FB D0 06            [24] 1449 	pop	ar6
      0088FD D0 07            [24] 1450 	pop	ar7
      0088FF 90 0A EB         [24] 1451 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_2
      008902 EE               [12] 1452 	mov	a,r6
      008903 F0               [24] 1453 	movx	@dptr,a
      008904 90 0A EC         [24] 1454 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_3
      008907 ED               [12] 1455 	mov	a,r5
      008908 F0               [24] 1456 	movx	@dptr,a
      008909 90 0A ED         [24] 1457 	mov	dptr,#_dynamic_keymap_set_keycode_PARM_4
      00890C 12 3A B5         [24] 1458 	lcall	_ak820_outline_0085
      00890F 8F 82            [24] 1459 	mov	dpl, r7
      008911 C0 07            [24] 1460 	push	ar7
      008913 C0 06            [24] 1461 	push	ar6
      008915 C0 05            [24] 1462 	push	ar5
      008917 12 86 33         [24] 1463 	lcall	_dynamic_keymap_set_keycode
      00891A D0 05            [24] 1464 	pop	ar5
      00891C D0 06            [24] 1465 	pop	ar6
      00891E D0 07            [24] 1466 	pop	ar7
                                   1467 ;	quantum/dynamic_keymap.c:364: for (reset_index_t column = 0; column < MATRIX_COLS; column++) {
      008920 0D               [12] 1468 	inc	r5
      008921 80 B8            [24] 1469 	sjmp	00107$
      008923                       1470 00111$:
                                   1471 ;	quantum/dynamic_keymap.c:363: for (reset_index_t row = 0; row < MATRIX_ROWS; row++) {
      008923 0E               [12] 1472 	inc	r6
      008924 80 AE            [24] 1473 	sjmp	00110$
      008926                       1474 00102$:
                                   1475 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008926 7E 00            [12] 1476 	mov	r6,#0x00
      008928                       1477 00113$:
      008928 BE 01 00         [24] 1478 	cjne	r6,#0x01,00204$
      00892B                       1479 00204$:
      00892B 50 4C            [24] 1480 	jnc	00117$
                                   1481 ;	quantum/dynamic_keymap.c:370: dynamic_keymap_set_encoder(layer, encoder, true, keycode_at_encodermap_location_raw(layer, encoder, true));
      00892D 12 90 82         [24] 1482 	lcall	_ak820_outline_0178
      008930 04               [12] 1483 	inc	a
      008931 F0               [24] 1484 	movx	@dptr,a
      008932 8F 82            [24] 1485 	mov	dpl, r7
      008934 C0 07            [24] 1486 	push	ar7
      008936 12 98 BD         [24] 1487 	lcall	_keycode_at_encodermap_location_raw
      008939 12 45 B8         [24] 1488 	lcall	_ak820_outline_0149
      00893C D0 07            [24] 1489 	pop	ar7
      00893E 12 90 79         [24] 1490 	lcall	_ak820_outline_0177
      008941 04               [12] 1491 	inc	a
      008942 F0               [24] 1492 	movx	@dptr,a
      008943 90 0A F7         [24] 1493 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008946 12 3A A9         [24] 1494 	lcall	_ak820_outline_0072
      008949 8F 82            [24] 1495 	mov	dpl, r7
      00894B C0 07            [24] 1496 	push	ar7
      00894D 12 87 0C         [24] 1497 	lcall	_dynamic_keymap_set_encoder
      008950 D0 07            [24] 1498 	pop	ar7
                                   1499 ;	quantum/dynamic_keymap.c:371: dynamic_keymap_set_encoder(layer, encoder, false, keycode_at_encodermap_location_raw(layer, encoder, false));
      008952 12 90 82         [24] 1500 	lcall	_ak820_outline_0178
      008955 F0               [24] 1501 	movx	@dptr,a
      008956 8F 82            [24] 1502 	mov	dpl, r7
      008958 C0 07            [24] 1503 	push	ar7
      00895A 12 98 BD         [24] 1504 	lcall	_keycode_at_encodermap_location_raw
      00895D 12 45 B8         [24] 1505 	lcall	_ak820_outline_0149
      008960 D0 07            [24] 1506 	pop	ar7
      008962 12 90 79         [24] 1507 	lcall	_ak820_outline_0177
      008965 F0               [24] 1508 	movx	@dptr,a
      008966 90 0A F7         [24] 1509 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_4
      008969 12 3A A9         [24] 1510 	lcall	_ak820_outline_0072
      00896C 8F 82            [24] 1511 	mov	dpl, r7
      00896E C0 07            [24] 1512 	push	ar7
      008970 12 87 0C         [24] 1513 	lcall	_dynamic_keymap_set_encoder
      008973 D0 07            [24] 1514 	pop	ar7
                                   1515 ;	quantum/dynamic_keymap.c:369: for (reset_index_t encoder = 0; encoder < NUM_ENCODERS; encoder++) {
      008975 7E 01            [12] 1516 	mov	r6,#0x01
      008977 80 AF            [24] 1517 	sjmp	00113$
      008979                       1518 00117$:
                                   1519 ;	quantum/dynamic_keymap.c:362: for (reset_index_t layer = 0; layer < DYNAMIC_KEYMAP_LAYER_COUNT; layer++) {
      008979 0F               [12] 1520 	inc	r7
      00897A 02 88 CA         [24] 1521 	ljmp	00116$
      00897D                       1522 00104$:
                                   1523 ;	quantum/dynamic_keymap.c:388: vial_combo_entry_t combo = { { 0 }, 0 };
      00897D 90 0B 0D         [24] 1524 	mov	dptr,#_dynamic_keymap_reset_combo_10001_407
      008980 12 51 87         [24] 1525 	lcall	_ak820_outline_0182
      008983 90 0B 0F         [24] 1526 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0002)
      008986 F0               [24] 1527 	movx	@dptr,a
      008987 A3               [24] 1528 	inc	dptr
      008988 F0               [24] 1529 	movx	@dptr,a
      008989 90 0B 11         [24] 1530 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0004)
      00898C F0               [24] 1531 	movx	@dptr,a
      00898D A3               [24] 1532 	inc	dptr
      00898E F0               [24] 1533 	movx	@dptr,a
      00898F 90 0B 13         [24] 1534 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0006)
      008992 F0               [24] 1535 	movx	@dptr,a
      008993 A3               [24] 1536 	inc	dptr
      008994 F0               [24] 1537 	movx	@dptr,a
      008995 90 0B 15         [24] 1538 	mov	dptr,#(_dynamic_keymap_reset_combo_10001_407 + 0x0008)
      008998 F0               [24] 1539 	movx	@dptr,a
      008999 A3               [24] 1540 	inc	dptr
      00899A F0               [24] 1541 	movx	@dptr,a
                                   1542 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      00899B FF               [12] 1543 	mov	r7,a
      00899C                       1544 00119$:
      00899C BF 08 00         [24] 1545 	cjne	r7,#0x08,00206$
      00899F                       1546 00206$:
      00899F 50 19            [24] 1547 	jnc	00105$
                                   1548 ;	quantum/dynamic_keymap.c:390: dynamic_keymap_set_combo(i, &combo);
      0089A1 8F 06            [24] 1549 	mov	ar6,r7
      0089A3 90 0A FE         [24] 1550 	mov	dptr,#_dynamic_keymap_set_combo_PARM_2
      0089A6 74 0D            [12] 1551 	mov	a,#_dynamic_keymap_reset_combo_10001_407
      0089A8 F0               [24] 1552 	movx	@dptr,a
      0089A9 74 0B            [12] 1553 	mov	a,#(_dynamic_keymap_reset_combo_10001_407 >> 8)
      0089AB 12 3A BB         [24] 1554 	lcall	_ak820_outline_0093
      0089AE 8E 82            [24] 1555 	mov	dpl, r6
      0089B0 C0 07            [24] 1556 	push	ar7
      0089B2 12 88 18         [24] 1557 	lcall	_dynamic_keymap_set_combo
      0089B5 D0 07            [24] 1558 	pop	ar7
                                   1559 ;	quantum/dynamic_keymap.c:389: for (size_t i = 0; i < VIAL_COMBO_ENTRIES; ++i)
      0089B7 0F               [12] 1560 	inc	r7
      0089B8 80 E2            [24] 1561 	sjmp	00119$
      0089BA                       1562 00105$:
                                   1563 ;	quantum/dynamic_keymap.c:403: vial_unlocked = vial_unlocked_prev;
      0089BA 90 0B 0C         [24] 1564 	mov	dptr,#_dynamic_keymap_reset_vial_unlocked_prev_10000_398
      0089BD E0               [24] 1565 	movx	a,@dptr
      0089BE 90 0E 2E         [24] 1566 	mov	dptr,#_vial_unlocked
      0089C1 F0               [24] 1567 	movx	@dptr,a
                                   1568 ;	quantum/dynamic_keymap.c:405: }
      0089C2 22               [24] 1569 	ret
                                   1570 ;------------------------------------------------------------
                                   1571 ;Allocation info for local variables in function 'ak820_dynamic_read_buffer'
                                   1572 ;------------------------------------------------------------
                                   1573 ;sloc0         Allocated with name '_ak820_dynamic_read_buffer_sloc0_1_0'
                                   1574 ;limit         Allocated with name '_ak820_dynamic_read_buffer_PARM_2'
                                   1575 ;offset        Allocated with name '_ak820_dynamic_read_buffer_PARM_3'
                                   1576 ;size          Allocated with name '_ak820_dynamic_read_buffer_PARM_4'
                                   1577 ;data          Allocated with name '_ak820_dynamic_read_buffer_PARM_5'
                                   1578 ;base          Allocated with name '_ak820_dynamic_read_buffer_base_10000_409'
                                   1579 ;target        Allocated with name '_ak820_dynamic_read_buffer_target_10000_410'
                                   1580 ;available     Allocated with name '_ak820_dynamic_read_buffer_available_10000_410'
                                   1581 ;remaining     Allocated with name '_ak820_dynamic_read_buffer_remaining_30000_413'
                                   1582 ;i             Allocated with name '_ak820_dynamic_read_buffer_i_20000_415'
                                   1583 ;------------------------------------------------------------
                                   1584 ;	quantum/dynamic_keymap.c:410: static void ak820_dynamic_read_buffer(uint16_t base, uint16_t limit, uint16_t offset, uint16_t size, uint8_t *data) {
                                   1585 ;	-----------------------------------------
                                   1586 ;	 function ak820_dynamic_read_buffer
                                   1587 ;	-----------------------------------------
      0089C3                       1588 _ak820_dynamic_read_buffer:
      0089C3 12 3A CD         [24] 1589 	lcall	_ak820_outline_0107
      0089C6 90 0B 20         [24] 1590 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      0089C9 12 3A D2         [24] 1591 	lcall	_ak820_outline_0108
                                   1592 ;	quantum/dynamic_keymap.c:411: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      0089CC 90 0B 1D         [24] 1593 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      0089CF 12 3A 8C         [24] 1594 	lcall	_ak820_outline_0051
                                   1595 ;	quantum/dynamic_keymap.c:412: uint8_t available = 0;
      0089D2 90 0B 22         [24] 1596 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      0089D5 E4               [12] 1597 	clr	a
      0089D6 F0               [24] 1598 	movx	@dptr,a
                                   1599 ;	quantum/dynamic_keymap.c:413: if (size > 28) return;
      0089D7 90 0B 1B         [24] 1600 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      0089DA 12 3A A3         [24] 1601 	lcall	_ak820_outline_0059
      0089DD 8C 02            [24] 1602 	mov	ar2,r4
      0089DF 8D 03            [24] 1603 	mov	ar3,r5
      0089E1 C3               [12] 1604 	clr	c
      0089E2 74 1C            [12] 1605 	mov	a,#0x1c
      0089E4 9A               [12] 1606 	subb	a,r2
      0089E5 E4               [12] 1607 	clr	a
      0089E6 9B               [12] 1608 	subb	a,r3
      0089E7 50 01            [24] 1609 	jnc	00102$
                                   1610 ;	free result
      0089E9 22               [24] 1611 	ret
      0089EA                       1612 00102$:
                                   1613 ;	quantum/dynamic_keymap.c:414: if (offset < limit) {
      0089EA 90 0B 19         [24] 1614 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      0089ED 12 45 95         [24] 1615 	lcall	_ak820_outline_0103
      0089F0 90 0B 17         [24] 1616 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      0089F3 12 3A C7         [24] 1617 	lcall	_ak820_outline_0102
      0089F6 C3               [12] 1618 	clr	c
      0089F7 EA               [12] 1619 	mov	a,r2
      0089F8 98               [12] 1620 	subb	a,r0
      0089F9 EB               [12] 1621 	mov	a,r3
      0089FA 99               [12] 1622 	subb	a,r1
      0089FB 50 17            [24] 1623 	jnc	00104$
                                   1624 ;	quantum/dynamic_keymap.c:415: uint16_t remaining = limit - offset;
      0089FD E8               [12] 1625 	mov	a,r0
      0089FE C3               [12] 1626 	clr	c
      0089FF 9A               [12] 1627 	subb	a,r2
      008A00 F8               [12] 1628 	mov	r0,a
      008A01 E9               [12] 1629 	mov	a,r1
      008A02 9B               [12] 1630 	subb	a,r3
      008A03 F9               [12] 1631 	mov	r1,a
                                   1632 ;	quantum/dynamic_keymap.c:416: available = remaining < size ? remaining : size;
      008A04 C3               [12] 1633 	clr	c
      008A05 E8               [12] 1634 	mov	a,r0
      008A06 9C               [12] 1635 	subb	a,r4
      008A07 E9               [12] 1636 	mov	a,r1
      008A08 9D               [12] 1637 	subb	a,r5
      008A09 40 04            [24] 1638 	jc	00114$
      008A0B 8C 00            [24] 1639 	mov	ar0,r4
      008A0D 8D 01            [24] 1640 	mov	ar1,r5
      008A0F                       1641 00114$:
      008A0F 90 0B 22         [24] 1642 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008A12 E8               [12] 1643 	mov	a,r0
      008A13 F0               [24] 1644 	movx	@dptr,a
      008A14                       1645 00104$:
                                   1646 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008A14 90 0B 22         [24] 1647 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008A17 E0               [24] 1648 	movx	a,@dptr
      008A18 F5 2C            [12] 1649 	mov	_ak820_dynamic_read_buffer_sloc0_1_0,a
      008A1A E0               [24] 1650 	movx	a,@dptr
      008A1B 60 42            [24] 1651 	jz	00106$
      008A1D C0 04            [24] 1652 	push	ar4
      008A1F C0 05            [24] 1653 	push	ar5
      008A21 8E 00            [24] 1654 	mov	ar0,r6
      008A23 8F 05            [24] 1655 	mov	ar5,r7
      008A25 90 0B 20         [24] 1656 	mov	dptr,#_ak820_dynamic_read_buffer_base_10000_409
      008A28 E0               [24] 1657 	movx	a,@dptr
      008A29 F9               [12] 1658 	mov	r1,a
      008A2A A3               [24] 1659 	inc	dptr
      008A2B E0               [24] 1660 	movx	a,@dptr
      008A2C FC               [12] 1661 	mov	r4,a
      008A2D EA               [12] 1662 	mov	a,r2
      008A2E 29               [12] 1663 	add	a, r1
      008A2F FA               [12] 1664 	mov	r2,a
      008A30 EB               [12] 1665 	mov	a,r3
      008A31 3C               [12] 1666 	addc	a, r4
      008A32 FB               [12] 1667 	mov	r3,a
      008A33 90 05 95         [24] 1668 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_2
      008A36 EA               [12] 1669 	mov	a,r2
      008A37 F0               [24] 1670 	movx	@dptr,a
      008A38 EB               [12] 1671 	mov	a,r3
      008A39 12 3A BB         [24] 1672 	lcall	_ak820_outline_0093
      008A3C 90 05 98         [24] 1673 	mov	dptr,#_ak820_eeprom_read_block_xdata_PARM_3
      008A3F E5 2C            [12] 1674 	mov	a,_ak820_dynamic_read_buffer_sloc0_1_0
      008A41 12 3A E7         [24] 1675 	lcall	_ak820_outline_0134
      008A44 88 82            [24] 1676 	mov	dpl, r0
      008A46 8D 83            [24] 1677 	mov	dph, r5
      008A48 C0 07            [24] 1678 	push	ar7
      008A4A C0 06            [24] 1679 	push	ar6
      008A4C C0 05            [24] 1680 	push	ar5
      008A4E C0 04            [24] 1681 	push	ar4
      008A50 12 42 FA         [24] 1682 	lcall	_ak820_eeprom_read_block_xdata
      008A53 D0 04            [24] 1683 	pop	ar4
      008A55 D0 05            [24] 1684 	pop	ar5
      008A57 D0 06            [24] 1685 	pop	ar6
      008A59 D0 07            [24] 1686 	pop	ar7
                                   1687 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008A5B D0 05            [24] 1688 	pop	ar5
      008A5D D0 04            [24] 1689 	pop	ar4
                                   1690 ;	quantum/dynamic_keymap.c:418: if (available) ak820_eeprom_read_block_xdata(target, (const void *)(uintptr_t)(base + offset), available);
      008A5F                       1691 00106$:
                                   1692 ;	quantum/dynamic_keymap.c:419: for (uint8_t i = available; i < size; ++i) target[i] = 0;
      008A5F 90 0B 22         [24] 1693 	mov	dptr,#_ak820_dynamic_read_buffer_available_10000_410
      008A62 E0               [24] 1694 	movx	a,@dptr
      008A63 FB               [12] 1695 	mov	r3,a
      008A64                       1696 00109$:
      008A64 8B 01            [24] 1697 	mov	ar1,r3
      008A66 7A 00            [12] 1698 	mov	r2,#0x00
      008A68 C3               [12] 1699 	clr	c
      008A69 E9               [12] 1700 	mov	a,r1
      008A6A 9C               [12] 1701 	subb	a,r4
      008A6B EA               [12] 1702 	mov	a,r2
      008A6C 9D               [12] 1703 	subb	a,r5
      008A6D 50 09            [24] 1704 	jnc	00111$
      008A6F EB               [12] 1705 	mov	a,r3
      008A70 12 3A 7C         [24] 1706 	lcall	_ak820_outline_0022
      008A73 E4               [12] 1707 	clr	a
      008A74 F0               [24] 1708 	movx	@dptr,a
      008A75 0B               [12] 1709 	inc	r3
      008A76 80 EC            [24] 1710 	sjmp	00109$
      008A78                       1711 00111$:
                                   1712 ;	quantum/dynamic_keymap.c:420: }
      008A78 22               [24] 1713 	ret
                                   1714 ;------------------------------------------------------------
                                   1715 ;Allocation info for local variables in function 'dynamic_keymap_get_buffer'
                                   1716 ;------------------------------------------------------------
                                   1717 ;size          Allocated with name '_dynamic_keymap_get_buffer_PARM_2'
                                   1718 ;data          Allocated with name '_dynamic_keymap_get_buffer_PARM_3'
                                   1719 ;offset        Allocated with name '_dynamic_keymap_get_buffer_offset_10000_416'
                                   1720 ;------------------------------------------------------------
                                   1721 ;	quantum/dynamic_keymap.c:423: void dynamic_keymap_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1722 ;	-----------------------------------------
                                   1723 ;	 function dynamic_keymap_get_buffer
                                   1724 ;	-----------------------------------------
      008A79                       1725 _dynamic_keymap_get_buffer:
      008A79 12 3A CD         [24] 1726 	lcall	_ak820_outline_0107
      008A7C 90 0B 28         [24] 1727 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008A7F 12 3A D2         [24] 1728 	lcall	_ak820_outline_0108
                                   1729 ;	quantum/dynamic_keymap.c:426: DYNAMIC_KEYMAP_LAYER_COUNT * MATRIX_ROWS * MATRIX_COLS * 2, offset, size, data);
      008A82 90 0B 28         [24] 1730 	mov	dptr,#_dynamic_keymap_get_buffer_offset_10000_416
      008A85 12 3A 8C         [24] 1731 	lcall	_ak820_outline_0051
      008A88 90 0B 23         [24] 1732 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_2
      008A8B 12 3A A3         [24] 1733 	lcall	_ak820_outline_0059
      008A8E 90 0B 25         [24] 1734 	mov	dptr,#_dynamic_keymap_get_buffer_PARM_3
      008A91 12 51 67         [24] 1735 	lcall	_ak820_outline_0091
      008A94 90 0B 17         [24] 1736 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008A97 E4               [12] 1737 	clr	a
      008A98 F0               [24] 1738 	movx	@dptr,a
      008A99 74 06            [12] 1739 	mov	a,#0x06
      008A9B A3               [24] 1740 	inc	dptr
      008A9C F0               [24] 1741 	movx	@dptr,a
      008A9D 90 0B 19         [24] 1742 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008AA0 12 4A CE         [24] 1743 	lcall	_ak820_outline_0058
      008AA3 90 0B 1B         [24] 1744 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008AA6 12 3A A9         [24] 1745 	lcall	_ak820_outline_0072
      008AA9 90 0B 1D         [24] 1746 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008AAC E9               [12] 1747 	mov	a,r1
      008AAD 12 51 80         [24] 1748 	lcall	_ak820_outline_0155
      008AB0 F0               [24] 1749 	movx	@dptr,a
      008AB1 90 00 40         [24] 1750 	mov	dptr,#0x0040
                                   1751 ;	quantum/dynamic_keymap.c:448: }
      008AB4 02 89 C3         [24] 1752 	ljmp	_ak820_dynamic_read_buffer
                                   1753 ;------------------------------------------------------------
                                   1754 ;Allocation info for local variables in function 'dynamic_keymap_set_buffer'
                                   1755 ;------------------------------------------------------------
                                   1756 ;sloc0         Allocated with name '_dynamic_keymap_set_buffer_sloc0_1_0'
                                   1757 ;sloc1         Allocated with name '_dynamic_keymap_set_buffer_sloc1_1_0'
                                   1758 ;sloc2         Allocated with name '_dynamic_keymap_set_buffer_sloc2_1_0'
                                   1759 ;size          Allocated with name '_dynamic_keymap_set_buffer_PARM_2'
                                   1760 ;data          Allocated with name '_dynamic_keymap_set_buffer_PARM_3'
                                   1761 ;offset        Allocated with name '_dynamic_keymap_set_buffer_offset_10000_418'
                                   1762 ;dynamic_keymap_eeprom_size Allocated with name '_dynamic_keymap_set_buffer_dynamic_keymap_eeprom_size_10000_419'
                                   1763 ;target        Allocated with name '_dynamic_keymap_set_buffer_target_10000_419'
                                   1764 ;buffer        Allocated with name '_dynamic_keymap_set_buffer_buffer_10000_419'
                                   1765 ;count         Allocated with name '_dynamic_keymap_set_buffer_count_10001_422'
                                   1766 ;chk_offset    Allocated with name '_dynamic_keymap_set_buffer_chk_offset_30001_425'
                                   1767 ;chk_sz        Allocated with name '_dynamic_keymap_set_buffer_chk_sz_30001_425'
                                   1768 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_427'
                                   1769 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_430'
                                   1770 ;i             Allocated with name '_dynamic_keymap_set_buffer_i_40001_432'
                                   1771 ;kc            Allocated with name '_dynamic_keymap_set_buffer_kc_50001_433'
                                   1772 ;------------------------------------------------------------
                                   1773 ;	quantum/dynamic_keymap.c:450: void dynamic_keymap_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   1774 ;	-----------------------------------------
                                   1775 ;	 function dynamic_keymap_set_buffer
                                   1776 ;	-----------------------------------------
      008AB7                       1777 _dynamic_keymap_set_buffer:
      008AB7 12 3A CD         [24] 1778 	lcall	_ak820_outline_0107
      008ABA 90 0B 2F         [24] 1779 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008ABD 12 3A D2         [24] 1780 	lcall	_ak820_outline_0108
                                   1781 ;	quantum/dynamic_keymap.c:452: uint8_t DYNAMIC_BUFFER_MEM *target = (uint8_t DYNAMIC_BUFFER_MEM *)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset);
      008AC0 90 0B 2F         [24] 1782 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008AC3 12 4A 71         [24] 1783 	lcall	_ak820_outline_0008
      008AC6 74 40            [12] 1784 	mov	a,#0x40
      008AC8 2C               [12] 1785 	add	a, r4
      008AC9 FA               [12] 1786 	mov	r2,a
      008ACA E4               [12] 1787 	clr	a
      008ACB 3D               [12] 1788 	addc	a, r5
      008ACC FB               [12] 1789 	mov	r3,a
                                   1790 ;	quantum/dynamic_keymap.c:453: uint8_t DYNAMIC_BUFFER_MEM *buffer = (uint8_t DYNAMIC_BUFFER_MEM *)data;
      008ACD 90 0B 2C         [24] 1791 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_3
      008AD0 12 3A C7         [24] 1792 	lcall	_ak820_outline_0102
                                   1793 ;	quantum/dynamic_keymap.c:457: if (!size) return;
      008AD3 90 0B 2A         [24] 1794 	mov	dptr,#_dynamic_keymap_set_buffer_PARM_2
      008AD6 E0               [24] 1795 	movx	a,@dptr
      008AD7 F5 2D            [12] 1796 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,a
      008AD9 A3               [24] 1797 	inc	dptr
      008ADA E0               [24] 1798 	movx	a,@dptr
      008ADB F5 2E            [12] 1799 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),a
      008ADD E5 2D            [12] 1800 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008ADF 45 2E            [12] 1801 	orl	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008AE1 70 01            [24] 1802 	jnz	00102$
      008AE3 22               [24] 1803 	ret
      008AE4                       1804 00102$:
                                   1805 ;	quantum/dynamic_keymap.c:459: if (size > 28) return;
      008AE4 85 2D 2F         [24] 1806 	mov	_dynamic_keymap_set_buffer_sloc1_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
      008AE7 85 2E 30         [24] 1807 	mov	(_dynamic_keymap_set_buffer_sloc1_1_0 + 1),(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008AEA C3               [12] 1808 	clr	c
      008AEB 74 1C            [12] 1809 	mov	a,#0x1c
      008AED 95 2F            [12] 1810 	subb	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008AEF E4               [12] 1811 	clr	a
      008AF0 95 30            [12] 1812 	subb	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008AF2 50 01            [24] 1813 	jnc	00104$
                                   1814 ;	free result
      008AF4 22               [24] 1815 	ret
      008AF5                       1816 00104$:
                                   1817 ;	quantum/dynamic_keymap.c:461: dynamic_buffer_size_t count = size;
      008AF5 85 2D 31         [24] 1818 	mov	_dynamic_keymap_set_buffer_sloc2_1_0,_dynamic_keymap_set_buffer_sloc0_1_0
                                   1819 ;	quantum/dynamic_keymap.c:465: if (offset >= dynamic_keymap_eeprom_size || dynamic_keymap_eeprom_size - offset < size)
      008AF8 74 FA            [12] 1820 	mov	a,#0x100 - 0x06
      008AFA 2F               [12] 1821 	add	a,r7
      008AFB 40 11            [24] 1822 	jc	00105$
      008AFD E4               [12] 1823 	clr	a
      008AFE C3               [12] 1824 	clr	c
      008AFF 9E               [12] 1825 	subb	a,r6
      008B00 FE               [12] 1826 	mov	r6,a
      008B01 74 06            [12] 1827 	mov	a,#0x06
      008B03 9F               [12] 1828 	subb	a,r7
      008B04 FF               [12] 1829 	mov	r7,a
      008B05 C3               [12] 1830 	clr	c
      008B06 EE               [12] 1831 	mov	a,r6
      008B07 95 2D            [12] 1832 	subb	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008B09 EF               [12] 1833 	mov	a,r7
      008B0A 95 2E            [12] 1834 	subb	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B0C 50 01            [24] 1835 	jnc	00106$
      008B0E                       1836 00105$:
                                   1837 ;	quantum/dynamic_keymap.c:466: return;
      008B0E 22               [24] 1838 	ret
      008B0F                       1839 00106$:
                                   1840 ;	quantum/dynamic_keymap.c:470: if (!vial_unlocked) {
      008B0F 90 0E 2E         [24] 1841 	mov	dptr,#_vial_unlocked
      008B12 E0               [24] 1842 	movx	a,@dptr
      008B13 60 03            [24] 1843 	jz	00207$
      008B15 02 8C 22         [24] 1844 	ljmp	00120$
      008B18                       1845 00207$:
                                   1846 ;	quantum/dynamic_keymap.c:472: dynamic_buffer_size_t chk_offset = 0;
      008B18 90 0B 31         [24] 1847 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008B1B E4               [12] 1848 	clr	a
      008B1C F0               [24] 1849 	movx	@dptr,a
                                   1850 ;	quantum/dynamic_keymap.c:473: dynamic_buffer_size_t chk_sz = count;
      008B1D 90 0B 32         [24] 1851 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008B20 E5 31            [12] 1852 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008B22 F0               [24] 1853 	movx	@dptr,a
                                   1854 ;	quantum/dynamic_keymap.c:476: if (offset % 2 != 0) {
      008B23 EC               [12] 1855 	mov	a,r4
      008B24 30 E0 31         [24] 1856 	jnb	acc.0,00111$
                                   1857 ;	quantum/dynamic_keymap.c:477: uint16_t kc = (eeprom_read_byte(target - 1) << 8) | buffer[0];
      008B27 EA               [12] 1858 	mov	a,r2
      008B28 24 FF            [12] 1859 	add	a,#0xff
      008B2A FE               [12] 1860 	mov	r6,a
      008B2B EB               [12] 1861 	mov	a,r3
      008B2C 34 FF            [12] 1862 	addc	a,#0xff
      008B2E FF               [12] 1863 	mov	r7,a
      008B2F 7D 00            [12] 1864 	mov	r5,#0x00
      008B31 12 71 B9         [24] 1865 	lcall	_ak820_outline_0064
      008B34 12 42 BF         [24] 1866 	lcall	_eeprom_read_byte
      008B37 AE 82            [24] 1867 	mov	r6,dpl
      008B39 7F 00            [12] 1868 	mov	r7,#0x00
      008B3B 12 3B 01         [24] 1869 	lcall	_ak820_outline_0157
      008B3E E0               [24] 1870 	movx	a,@dptr
      008B3F 7C 00            [12] 1871 	mov	r4,#0x00
      008B41 42 07            [12] 1872 	orl	ar7,a
      008B43 EC               [12] 1873 	mov	a,r4
      008B44 42 06            [12] 1874 	orl	ar6,a
                                   1875 ;	quantum/dynamic_keymap.c:478: if (kc == QK_BOOT)
      008B46 BF 00 09         [24] 1876 	cjne	r7,#0x00,00109$
      008B49 BE 7C 06         [24] 1877 	cjne	r6,#0x7c,00109$
                                   1878 ;	quantum/dynamic_keymap.c:479: buffer[0] = 0xFF;
      008B4C 12 3B 01         [24] 1879 	lcall	_ak820_outline_0157
      008B4F 74 FF            [12] 1880 	mov	a,#0xff
      008B51 F0               [24] 1881 	movx	@dptr,a
      008B52                       1882 00109$:
                                   1883 ;	quantum/dynamic_keymap.c:482: chk_offset += 1;
      008B52 90 0B 31         [24] 1884 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008B55 74 01            [12] 1885 	mov	a,#0x01
      008B57 F0               [24] 1886 	movx	@dptr,a
      008B58                       1887 00111$:
                                   1888 ;	quantum/dynamic_keymap.c:486: if ((offset + size) % 2 != 0) {
      008B58 90 0B 2F         [24] 1889 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008B5B 12 3A 8C         [24] 1890 	lcall	_ak820_outline_0051
      008B5E E5 2D            [12] 1891 	mov	a,_dynamic_keymap_set_buffer_sloc0_1_0
      008B60 2E               [12] 1892 	add	a, r6
      008B61 FE               [12] 1893 	mov	r6,a
      008B62 E5 2E            [12] 1894 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008B64 3F               [12] 1895 	addc	a, r7
      008B65 EE               [12] 1896 	mov	a,r6
      008B66 30 E0 5A         [24] 1897 	jnb	acc.0,00115$
                                   1898 ;	quantum/dynamic_keymap.c:487: uint16_t kc = (buffer[count - 1] << 8) | eeprom_read_byte(target + count);
      008B69 AE 31            [24] 1899 	mov	r6,_dynamic_keymap_set_buffer_sloc2_1_0
      008B6B 7F 00            [12] 1900 	mov	r7,#0x00
      008B6D EE               [12] 1901 	mov	a,r6
      008B6E 24 FF            [12] 1902 	add	a,#0xff
      008B70 FC               [12] 1903 	mov	r4,a
      008B71 EF               [12] 1904 	mov	a,r7
      008B72 34 FF            [12] 1905 	addc	a,#0xff
      008B74 FD               [12] 1906 	mov	r5,a
      008B75 EC               [12] 1907 	mov	a,r4
      008B76 28               [12] 1908 	add	a, r0
      008B77 F5 82            [12] 1909 	mov	dpl,a
      008B79 ED               [12] 1910 	mov	a,r5
      008B7A 39               [12] 1911 	addc	a, r1
      008B7B F5 83            [12] 1912 	mov	dph,a
      008B7D E0               [24] 1913 	movx	a,@dptr
      008B7E FC               [12] 1914 	mov	r4,a
      008B7F 7D 00            [12] 1915 	mov	r5,#0x00
      008B81 E5 31            [12] 1916 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008B83 2A               [12] 1917 	add	a, r2
      008B84 FA               [12] 1918 	mov	r2,a
      008B85 E4               [12] 1919 	clr	a
      008B86 3B               [12] 1920 	addc	a, r3
      008B87 FB               [12] 1921 	mov	r3,a
      008B88 C0 00            [24] 1922 	push	ar0
      008B8A C0 01            [24] 1923 	push	ar1
      008B8C 8B 01            [24] 1924 	mov	ar1,r3
      008B8E 7B 00            [12] 1925 	mov	r3,#0x00
      008B90 8A 82            [24] 1926 	mov	dpl, r2
      008B92 89 83            [24] 1927 	mov	dph, r1
      008B94 8B F0            [24] 1928 	mov	b, r3
      008B96 12 42 BF         [24] 1929 	lcall	_eeprom_read_byte
      008B99 AB 82            [24] 1930 	mov	r3, dpl
      008B9B 7A 00            [12] 1931 	mov	r2,#0x00
      008B9D EB               [12] 1932 	mov	a,r3
      008B9E 12 45 B2         [24] 1933 	lcall	_ak820_outline_0142
                                   1934 ;	quantum/dynamic_keymap.c:488: if (kc == QK_BOOT)
      008BA1 BD 00 05         [24] 1935 	cjne	r5,#0x00,00212$
      008BA4 BC 7C 02         [24] 1936 	cjne	r4,#0x7c,00212$
      008BA7 80 06            [24] 1937 	sjmp	00213$
      008BA9                       1938 00212$:
      008BA9 D0 01            [24] 1939 	pop	ar1
      008BAB D0 00            [24] 1940 	pop	ar0
      008BAD 80 0D            [24] 1941 	sjmp	00113$
      008BAF                       1942 00213$:
      008BAF D0 01            [24] 1943 	pop	ar1
      008BB1 D0 00            [24] 1944 	pop	ar0
                                   1945 ;	quantum/dynamic_keymap.c:489: buffer[count - 1] = 0xFF;
      008BB3 1E               [12] 1946 	dec	r6
      008BB4 BE FF 01         [24] 1947 	cjne	r6,#0xff,00214$
      008BB7 1F               [12] 1948 	dec	r7
      008BB8                       1949 00214$:
      008BB8 EE               [12] 1950 	mov	a,r6
      008BB9 12 90 5B         [24] 1951 	lcall	_ak820_outline_0128
      008BBC                       1952 00113$:
                                   1953 ;	quantum/dynamic_keymap.c:492: chk_sz -= 1;
      008BBC E5 31            [12] 1954 	mov	a,_dynamic_keymap_set_buffer_sloc2_1_0
      008BBE 14               [12] 1955 	dec	a
      008BBF 90 0B 32         [24] 1956 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008BC2 F0               [24] 1957 	movx	@dptr,a
      008BC3                       1958 00115$:
                                   1959 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008BC3 90 0B 31         [24] 1960 	mov	dptr,#_dynamic_keymap_set_buffer_chk_offset_30001_425
      008BC6 E0               [24] 1961 	movx	a,@dptr
      008BC7 90 0B 33         [24] 1962 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008BCA F0               [24] 1963 	movx	@dptr,a
      008BCB                       1964 00122$:
      008BCB 90 0B 33         [24] 1965 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008BCE E0               [24] 1966 	movx	a,@dptr
      008BCF FF               [12] 1967 	mov	r7,a
      008BD0 90 0B 32         [24] 1968 	mov	dptr,#_dynamic_keymap_set_buffer_chk_sz_30001_425
      008BD3 E0               [24] 1969 	movx	a,@dptr
      008BD4 FE               [12] 1970 	mov	r6,a
      008BD5 C3               [12] 1971 	clr	c
      008BD6 EF               [12] 1972 	mov	a,r7
      008BD7 9E               [12] 1973 	subb	a,r6
      008BD8 50 48            [24] 1974 	jnc	00120$
                                   1975 ;	quantum/dynamic_keymap.c:497: uint16_t kc = (buffer[i] << 8) | buffer[i + 1];
      008BDA EF               [12] 1976 	mov	a,r7
      008BDB 28               [12] 1977 	add	a, r0
      008BDC FD               [12] 1978 	mov	r5,a
      008BDD E4               [12] 1979 	clr	a
      008BDE 39               [12] 1980 	addc	a, r1
      008BDF FE               [12] 1981 	mov	r6,a
      008BE0 12 4A DB         [24] 1982 	lcall	_ak820_outline_0077
      008BE3 7B 00            [12] 1983 	mov	r3,#0x00
      008BE5 8C 2E            [24] 1984 	mov	(_dynamic_keymap_set_buffer_sloc0_1_0 + 1),r4
      008BE7 8B 2D            [24] 1985 	mov	_dynamic_keymap_set_buffer_sloc0_1_0,r3
      008BE9 8F 02            [24] 1986 	mov	ar2,r7
      008BEB 7F 00            [12] 1987 	mov	r7,#0x00
      008BED 74 01            [12] 1988 	mov	a,#0x01
      008BEF 2A               [12] 1989 	add	a, r2
      008BF0 FB               [12] 1990 	mov	r3,a
      008BF1 E4               [12] 1991 	clr	a
      008BF2 3F               [12] 1992 	addc	a, r7
      008BF3 FC               [12] 1993 	mov	r4,a
      008BF4 EB               [12] 1994 	mov	a,r3
      008BF5 28               [12] 1995 	add	a, r0
      008BF6 F5 82            [12] 1996 	mov	dpl,a
      008BF8 EC               [12] 1997 	mov	a,r4
      008BF9 39               [12] 1998 	addc	a, r1
      008BFA F5 83            [12] 1999 	mov	dph,a
      008BFC E0               [24] 2000 	movx	a,@dptr
      008BFD FC               [12] 2001 	mov	r4,a
      008BFE 7B 00            [12] 2002 	mov	r3,#0x00
      008C00 E5 2E            [12] 2003 	mov	a,(_dynamic_keymap_set_buffer_sloc0_1_0 + 1)
      008C02 42 03            [12] 2004 	orl	ar3,a
                                   2005 ;	quantum/dynamic_keymap.c:498: if (kc == QK_BOOT) {
      008C04 BC 00 12         [24] 2006 	cjne	r4,#0x00,00123$
      008C07 BB 7C 0F         [24] 2007 	cjne	r3,#0x7c,00123$
                                   2008 ;	quantum/dynamic_keymap.c:499: buffer[i] = 0xFF;
      008C0A 12 3A EC         [24] 2009 	lcall	_ak820_outline_0135
      008C0D 74 FF            [12] 2010 	mov	a,#0xff
      008C0F F0               [24] 2011 	movx	@dptr,a
                                   2012 ;	quantum/dynamic_keymap.c:500: buffer[i + 1] = 0xFF;
      008C10 0A               [12] 2013 	inc	r2
      008C11 BA 00 01         [24] 2014 	cjne	r2,#0x00,00218$
      008C14 0F               [12] 2015 	inc	r7
      008C15                       2016 00218$:
      008C15 EA               [12] 2017 	mov	a,r2
      008C16 12 90 5B         [24] 2018 	lcall	_ak820_outline_0128
      008C19                       2019 00123$:
                                   2020 ;	quantum/dynamic_keymap.c:496: for (dynamic_buffer_size_t i = chk_offset; i < chk_sz; i += 2) {
      008C19 90 0B 33         [24] 2021 	mov	dptr,#_dynamic_keymap_set_buffer_i_40001_432
      008C1C E0               [24] 2022 	movx	a,@dptr
      008C1D 24 02            [12] 2023 	add	a,#0x02
      008C1F F0               [24] 2024 	movx	@dptr,a
      008C20 80 A9            [24] 2025 	sjmp	00122$
      008C22                       2026 00120$:
                                   2027 ;	quantum/dynamic_keymap.c:511: ak820_eeprom_write_block_xdata(buffer, (void *)(uintptr_t)(DYNAMIC_KEYMAP_EEPROM_ADDR + offset), size);
      008C22 90 0B 2F         [24] 2028 	mov	dptr,#_dynamic_keymap_set_buffer_offset_10000_418
      008C25 12 3A 8C         [24] 2029 	lcall	_ak820_outline_0051
      008C28 74 40            [12] 2030 	mov	a,#0x40
      008C2A 12 45 AC         [24] 2031 	lcall	_ak820_outline_0137
      008C2D 90 05 9E         [24] 2032 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_2
      008C30 12 4A CE         [24] 2033 	lcall	_ak820_outline_0058
      008C33 E4               [12] 2034 	clr	a
      008C34 A3               [24] 2035 	inc	dptr
      008C35 F0               [24] 2036 	movx	@dptr,a
      008C36 90 05 A1         [24] 2037 	mov	dptr,#_ak820_eeprom_write_block_xdata_PARM_3
      008C39 E5 2F            [12] 2038 	mov	a,_dynamic_keymap_set_buffer_sloc1_1_0
      008C3B F0               [24] 2039 	movx	@dptr,a
      008C3C E5 30            [12] 2040 	mov	a,(_dynamic_keymap_set_buffer_sloc1_1_0 + 1)
      008C3E A3               [24] 2041 	inc	dptr
      008C3F F0               [24] 2042 	movx	@dptr,a
      008C40 12 3B 01         [24] 2043 	lcall	_ak820_outline_0157
                                   2044 ;	quantum/dynamic_keymap.c:521: }
      008C43 02 43 86         [24] 2045 	ljmp	_ak820_eeprom_write_block_xdata
                                   2046 ;------------------------------------------------------------
                                   2047 ;Allocation info for local variables in function 'keycode_at_keymap_location'
                                   2048 ;------------------------------------------------------------
                                   2049 ;row           Allocated with name '_keycode_at_keymap_location_PARM_2'
                                   2050 ;column        Allocated with name '_keycode_at_keymap_location_PARM_3'
                                   2051 ;layer_num     Allocated with name '_keycode_at_keymap_location_layer_num_10000_436'
                                   2052 ;------------------------------------------------------------
                                   2053 ;	quantum/dynamic_keymap.c:523: uint16_t keycode_at_keymap_location(uint8_t layer_num, uint8_t row, uint8_t column) {
                                   2054 ;	-----------------------------------------
                                   2055 ;	 function keycode_at_keymap_location
                                   2056 ;	-----------------------------------------
      008C46                       2057 _keycode_at_keymap_location:
      008C46 E5 82            [12] 2058 	mov	a,dpl
      008C48 90 0B 36         [24] 2059 	mov	dptr,#_keycode_at_keymap_location_layer_num_10000_436
      008C4B F0               [24] 2060 	movx	@dptr,a
                                   2061 ;	quantum/dynamic_keymap.c:524: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && row < MATRIX_ROWS && column < MATRIX_COLS) {
      008C4C E0               [24] 2062 	movx	a,@dptr
      008C4D FF               [12] 2063 	mov	r7,a
      008C4E BF 06 00         [24] 2064 	cjne	r7,#0x06,00128$
      008C51                       2065 00128$:
      008C51 50 23            [24] 2066 	jnc	00102$
      008C53 90 0B 34         [24] 2067 	mov	dptr,#_keycode_at_keymap_location_PARM_2
      008C56 E0               [24] 2068 	movx	a,@dptr
      008C57 FE               [12] 2069 	mov	r6,a
      008C58 BE 10 00         [24] 2070 	cjne	r6,#0x10,00130$
      008C5B                       2071 00130$:
      008C5B 50 19            [24] 2072 	jnc	00102$
      008C5D 90 0B 35         [24] 2073 	mov	dptr,#_keycode_at_keymap_location_PARM_3
      008C60 E0               [24] 2074 	movx	a,@dptr
      008C61 FD               [12] 2075 	mov	r5,a
      008C62 BD 08 00         [24] 2076 	cjne	r5,#0x08,00132$
      008C65                       2077 00132$:
      008C65 50 0F            [24] 2078 	jnc	00102$
                                   2079 ;	quantum/dynamic_keymap.c:525: return dynamic_keymap_get_keycode(layer_num, row, column);
      008C67 90 0A E8         [24] 2080 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_2
      008C6A EE               [12] 2081 	mov	a,r6
      008C6B F0               [24] 2082 	movx	@dptr,a
      008C6C 90 0A E9         [24] 2083 	mov	dptr,#_dynamic_keymap_get_keycode_PARM_3
      008C6F ED               [12] 2084 	mov	a,r5
      008C70 F0               [24] 2085 	movx	@dptr,a
      008C71 8F 82            [24] 2086 	mov	dpl, r7
      008C73 02 85 E5         [24] 2087 	ljmp	_dynamic_keymap_get_keycode
      008C76                       2088 00102$:
                                   2089 ;	quantum/dynamic_keymap.c:527: return KC_NO;
      008C76 90 00 00         [24] 2090 	mov	dptr,#0x0000
                                   2091 ;	quantum/dynamic_keymap.c:528: }
      008C79 22               [24] 2092 	ret
                                   2093 ;------------------------------------------------------------
                                   2094 ;Allocation info for local variables in function 'keycode_at_encodermap_location'
                                   2095 ;------------------------------------------------------------
                                   2096 ;encoder_idx   Allocated with name '_keycode_at_encodermap_location_PARM_2'
                                   2097 ;clockwise     Allocated with name '_keycode_at_encodermap_location_PARM_3'
                                   2098 ;layer_num     Allocated with name '_keycode_at_encodermap_location_layer_num_10000_440'
                                   2099 ;------------------------------------------------------------
                                   2100 ;	quantum/dynamic_keymap.c:531: uint16_t keycode_at_encodermap_location(uint8_t layer_num, uint8_t encoder_idx, bool clockwise) {
                                   2101 ;	-----------------------------------------
                                   2102 ;	 function keycode_at_encodermap_location
                                   2103 ;	-----------------------------------------
      008C7A                       2104 _keycode_at_encodermap_location:
      008C7A E5 82            [12] 2105 	mov	a,dpl
      008C7C 90 0B 39         [24] 2106 	mov	dptr,#_keycode_at_encodermap_location_layer_num_10000_440
      008C7F F0               [24] 2107 	movx	@dptr,a
                                   2108 ;	quantum/dynamic_keymap.c:532: if (layer_num < DYNAMIC_KEYMAP_LAYER_COUNT && encoder_idx < NUM_ENCODERS) {
      008C80 E0               [24] 2109 	movx	a,@dptr
      008C81 FF               [12] 2110 	mov	r7,a
      008C82 BF 06 00         [24] 2111 	cjne	r7,#0x06,00120$
      008C85                       2112 00120$:
      008C85 50 1E            [24] 2113 	jnc	00102$
      008C87 90 0B 37         [24] 2114 	mov	dptr,#_keycode_at_encodermap_location_PARM_2
      008C8A E0               [24] 2115 	movx	a,@dptr
      008C8B FE               [12] 2116 	mov	r6,a
      008C8C BE 01 00         [24] 2117 	cjne	r6,#0x01,00122$
      008C8F                       2118 00122$:
      008C8F 50 14            [24] 2119 	jnc	00102$
                                   2120 ;	quantum/dynamic_keymap.c:533: return dynamic_keymap_get_encoder(layer_num, encoder_idx, clockwise);
      008C91 90 0B 38         [24] 2121 	mov	dptr,#_keycode_at_encodermap_location_PARM_3
      008C94 E0               [24] 2122 	movx	a,@dptr
      008C95 FE               [12] 2123 	mov	r6,a
      008C96 90 0A F2         [24] 2124 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_2
      008C99 E4               [12] 2125 	clr	a
      008C9A F0               [24] 2126 	movx	@dptr,a
      008C9B 90 0A F3         [24] 2127 	mov	dptr,#_dynamic_keymap_get_encoder_PARM_3
      008C9E EE               [12] 2128 	mov	a,r6
      008C9F F0               [24] 2129 	movx	@dptr,a
      008CA0 8F 82            [24] 2130 	mov	dpl, r7
      008CA2 02 86 A4         [24] 2131 	ljmp	_dynamic_keymap_get_encoder
      008CA5                       2132 00102$:
                                   2133 ;	quantum/dynamic_keymap.c:535: return KC_NO;
      008CA5 90 00 00         [24] 2134 	mov	dptr,#0x0000
                                   2135 ;	quantum/dynamic_keymap.c:536: }
      008CA8 22               [24] 2136 	ret
                                   2137 ;------------------------------------------------------------
                                   2138 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_count'
                                   2139 ;------------------------------------------------------------
                                   2140 ;	quantum/dynamic_keymap.c:539: uint8_t dynamic_keymap_macro_get_count(void) {
                                   2141 ;	-----------------------------------------
                                   2142 ;	 function dynamic_keymap_macro_get_count
                                   2143 ;	-----------------------------------------
      008CA9                       2144 _dynamic_keymap_macro_get_count:
                                   2145 ;	quantum/dynamic_keymap.c:540: return DYNAMIC_KEYMAP_MACRO_COUNT;
      008CA9 75 82 10         [24] 2146 	mov	dpl, #0x10
                                   2147 ;	quantum/dynamic_keymap.c:541: }
      008CAC 22               [24] 2148 	ret
                                   2149 ;------------------------------------------------------------
                                   2150 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer_size'
                                   2151 ;------------------------------------------------------------
                                   2152 ;	quantum/dynamic_keymap.c:543: uint16_t dynamic_keymap_macro_get_buffer_size(void) {
                                   2153 ;	-----------------------------------------
                                   2154 ;	 function dynamic_keymap_macro_get_buffer_size
                                   2155 ;	-----------------------------------------
      008CAD                       2156 _dynamic_keymap_macro_get_buffer_size:
                                   2157 ;	quantum/dynamic_keymap.c:544: return DYNAMIC_KEYMAP_MACRO_EEPROM_SIZE;
      008CAD 90 20 00         [24] 2158 	mov	dptr,#0x2000
                                   2159 ;	quantum/dynamic_keymap.c:545: }
      008CB0 22               [24] 2160 	ret
                                   2161 ;------------------------------------------------------------
                                   2162 ;Allocation info for local variables in function 'dynamic_keymap_macro_get_buffer'
                                   2163 ;------------------------------------------------------------
                                   2164 ;sloc0         Allocated with name '_dynamic_keymap_macro_get_buffer_sloc0_1_0'
                                   2165 ;size          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_2'
                                   2166 ;data          Allocated with name '_dynamic_keymap_macro_get_buffer_PARM_3'
                                   2167 ;offset        Allocated with name '_dynamic_keymap_macro_get_buffer_offset_10000_448'
                                   2168 ;------------------------------------------------------------
                                   2169 ;	quantum/dynamic_keymap.c:547: void dynamic_keymap_macro_get_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2170 ;	-----------------------------------------
                                   2171 ;	 function dynamic_keymap_macro_get_buffer
                                   2172 ;	-----------------------------------------
      008CB1                       2173 _dynamic_keymap_macro_get_buffer:
      008CB1 12 3A CD         [24] 2174 	lcall	_ak820_outline_0107
      008CB4 90 0B 3F         [24] 2175 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008CB7 12 3A D2         [24] 2176 	lcall	_ak820_outline_0108
                                   2177 ;	quantum/dynamic_keymap.c:550: ak820_macro_length(), offset, size, data);
      008CBA 12 2B 2B         [24] 2178 	lcall	_ak820_macro_length
      008CBD 12 45 A7         [24] 2179 	lcall	_ak820_outline_0133
      008CC0 90 0B 3F         [24] 2180 	mov	dptr,#_dynamic_keymap_macro_get_buffer_offset_10000_448
      008CC3 12 3A A3         [24] 2181 	lcall	_ak820_outline_0059
      008CC6 90 0B 3A         [24] 2182 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_2
      008CC9 E0               [24] 2183 	movx	a,@dptr
      008CCA F5 32            [12] 2184 	mov	_dynamic_keymap_macro_get_buffer_sloc0_1_0,a
      008CCC A3               [24] 2185 	inc	dptr
      008CCD E0               [24] 2186 	movx	a,@dptr
      008CCE F5 33            [12] 2187 	mov	(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1),a
      008CD0 90 0B 3C         [24] 2188 	mov	dptr,#_dynamic_keymap_macro_get_buffer_PARM_3
      008CD3 12 3A C7         [24] 2189 	lcall	_ak820_outline_0102
      008CD6 A3               [24] 2190 	inc	dptr
      008CD7 E0               [24] 2191 	movx	a,@dptr
      008CD8 FB               [12] 2192 	mov	r3,a
      008CD9 90 0B 17         [24] 2193 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_2
      008CDC 12 4A CE         [24] 2194 	lcall	_ak820_outline_0058
      008CDF 90 0B 19         [24] 2195 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_3
      008CE2 12 3A A9         [24] 2196 	lcall	_ak820_outline_0072
      008CE5 90 0B 1B         [24] 2197 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_4
      008CE8 E5 32            [12] 2198 	mov	a,_dynamic_keymap_macro_get_buffer_sloc0_1_0
      008CEA F0               [24] 2199 	movx	@dptr,a
      008CEB E5 33            [12] 2200 	mov	a,(_dynamic_keymap_macro_get_buffer_sloc0_1_0 + 1)
      008CED A3               [24] 2201 	inc	dptr
      008CEE F0               [24] 2202 	movx	@dptr,a
      008CEF 90 0B 1D         [24] 2203 	mov	dptr,#_ak820_dynamic_read_buffer_PARM_5
      008CF2 E8               [12] 2204 	mov	a,r0
      008CF3 F0               [24] 2205 	movx	@dptr,a
      008CF4 E9               [12] 2206 	mov	a,r1
      008CF5 A3               [24] 2207 	inc	dptr
      008CF6 12 79 71         [24] 2208 	lcall	_ak820_outline_0187
      008CF9 90 08 00         [24] 2209 	mov	dptr,#0x0800
                                   2210 ;	quantum/dynamic_keymap.c:572: }
      008CFC 02 89 C3         [24] 2211 	ljmp	_ak820_dynamic_read_buffer
                                   2212 ;------------------------------------------------------------
                                   2213 ;Allocation info for local variables in function 'dynamic_keymap_macro_set_buffer'
                                   2214 ;------------------------------------------------------------
                                   2215 ;size          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_2'
                                   2216 ;data          Allocated with name '_dynamic_keymap_macro_set_buffer_PARM_3'
                                   2217 ;offset        Allocated with name '_dynamic_keymap_macro_set_buffer_offset_10000_450'
                                   2218 ;------------------------------------------------------------
                                   2219 ;	quantum/dynamic_keymap.c:575: bool dynamic_keymap_macro_set_buffer(uint16_t offset, uint16_t size, uint8_t *data) {
                                   2220 ;	-----------------------------------------
                                   2221 ;	 function dynamic_keymap_macro_set_buffer
                                   2222 ;	-----------------------------------------
      008CFF                       2223 _dynamic_keymap_macro_set_buffer:
      008CFF 12 3A CD         [24] 2224 	lcall	_ak820_outline_0107
      008D02 90 0B 46         [24] 2225 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008D05 12 3A D2         [24] 2226 	lcall	_ak820_outline_0108
                                   2227 ;	quantum/dynamic_keymap.c:576: return ak820_macro_write(offset, size, data);
      008D08 90 0B 46         [24] 2228 	mov	dptr,#_dynamic_keymap_macro_set_buffer_offset_10000_450
      008D0B 12 3A 8C         [24] 2229 	lcall	_ak820_outline_0051
      008D0E 90 0B 41         [24] 2230 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_2
      008D11 12 3A A3         [24] 2231 	lcall	_ak820_outline_0059
      008D14 90 0B 43         [24] 2232 	mov	dptr,#_dynamic_keymap_macro_set_buffer_PARM_3
      008D17 12 51 67         [24] 2233 	lcall	_ak820_outline_0091
      008D1A 90 05 24         [24] 2234 	mov	dptr,#_ak820_macro_write_PARM_2
      008D1D 12 3A A9         [24] 2235 	lcall	_ak820_outline_0072
      008D20 90 05 26         [24] 2236 	mov	dptr,#_ak820_macro_write_PARM_3
      008D23 E9               [12] 2237 	mov	a,r1
      008D24 12 51 80         [24] 2238 	lcall	_ak820_outline_0155
      008D27 12 45 89         [24] 2239 	lcall	_ak820_outline_0071
                                   2240 ;	quantum/dynamic_keymap.c:577: }
      008D2A 02 2B 45         [24] 2241 	ljmp	_ak820_macro_write
                                   2242 ;------------------------------------------------------------
                                   2243 ;Allocation info for local variables in function 'dynamic_keymap_macro_reset'
                                   2244 ;------------------------------------------------------------
                                   2245 ;	quantum/dynamic_keymap.c:592: void dynamic_keymap_macro_reset(void) {
                                   2246 ;	-----------------------------------------
                                   2247 ;	 function dynamic_keymap_macro_reset
                                   2248 ;	-----------------------------------------
      008D2D                       2249 _dynamic_keymap_macro_reset:
                                   2250 ;	quantum/dynamic_keymap.c:594: ak820_macro_reset();
                                   2251 ;	quantum/dynamic_keymap.c:603: }
      008D2D 02 2E 64         [24] 2252 	ljmp	_ak820_macro_reset
                                   2253 ;------------------------------------------------------------
                                   2254 ;Allocation info for local variables in function 'decode_keycode'
                                   2255 ;------------------------------------------------------------
                                   2256 ;kc            Allocated with name '_decode_keycode_kc_10000_454'
                                   2257 ;------------------------------------------------------------
                                   2258 ;	quantum/dynamic_keymap.c:605: static uint16_t decode_keycode(uint16_t kc) {
                                   2259 ;	-----------------------------------------
                                   2260 ;	 function decode_keycode
                                   2261 ;	-----------------------------------------
      008D30                       2262 _decode_keycode:
      008D30 12 3A CD         [24] 2263 	lcall	_ak820_outline_0107
      008D33 90 0B 48         [24] 2264 	mov	dptr,#_decode_keycode_kc_10000_454
      008D36 12 3A D2         [24] 2265 	lcall	_ak820_outline_0108
                                   2266 ;	quantum/dynamic_keymap.c:607: if (kc > 0xFF00)
      008D39 90 0B 48         [24] 2267 	mov	dptr,#_decode_keycode_kc_10000_454
      008D3C 12 4A 71         [24] 2268 	lcall	_ak820_outline_0008
      008D3F C3               [12] 2269 	clr	c
      008D40 E4               [12] 2270 	clr	a
      008D41 9C               [12] 2271 	subb	a,r4
      008D42 74 FF            [12] 2272 	mov	a,#0xff
      008D44 9D               [12] 2273 	subb	a,r5
      008D45 50 08            [24] 2274 	jnc	00102$
                                   2275 ;	free result
                                   2276 ;	quantum/dynamic_keymap.c:608: return (kc & 0xFF) << 8;
      008D47 8C 05            [24] 2277 	mov	ar5,r4
      008D49 7C 00            [12] 2278 	mov	r4,#0x00
      008D4B 12 3A E2         [24] 2279 	lcall	_ak820_outline_0124
      008D4E 22               [24] 2280 	ret
      008D4F                       2281 00102$:
                                   2282 ;	quantum/dynamic_keymap.c:609: return kc;
      008D4F 12 3A D7         [24] 2283 	lcall	_ak820_outline_0118
                                   2284 ;	quantum/dynamic_keymap.c:610: }
      008D52 22               [24] 2285 	ret
                                   2286 ;------------------------------------------------------------
                                   2287 ;Allocation info for local variables in function 'dynamic_keymap_macro_send'
                                   2288 ;------------------------------------------------------------
                                   2289 ;id            Allocated with name '_dynamic_keymap_macro_send_id_10000_457'
                                   2290 ;sending       Allocated with name '_dynamic_keymap_macro_send_sending_10000_458'
                                   2291 ;p             Allocated with name '_dynamic_keymap_macro_send_p_10001_463'
                                   2292 ;end           Allocated with name '_dynamic_keymap_macro_send_end_10002_464'
                                   2293 ;data          Allocated with name '_dynamic_keymap_macro_send_data_10003_470'
                                   2294 ;kc            Allocated with name '_dynamic_keymap_macro_send_kc_110003_488'
                                   2295 ;d0            Allocated with name '_dynamic_keymap_macro_send_d0_80003_492'
                                   2296 ;d1            Allocated with name '_dynamic_keymap_macro_send_d1_80003_492'
                                   2297 ;ms            Allocated with name '_dynamic_keymap_macro_send_ms_80004_494'
                                   2298 ;i             Allocated with name '_dynamic_keymap_macro_send_i_100004_496'
                                   2299 ;delay         Allocated with name '_dynamic_keymap_macro_send_delay_50003_500'
                                   2300 ;i             Allocated with name '_dynamic_keymap_macro_send_i_70003_502'
                                   2301 ;------------------------------------------------------------
                                   2302 ;	quantum/dynamic_keymap.c:612: void dynamic_keymap_macro_send(uint8_t id) {
                                   2303 ;	-----------------------------------------
                                   2304 ;	 function dynamic_keymap_macro_send
                                   2305 ;	-----------------------------------------
      008D53                       2306 _dynamic_keymap_macro_send:
      008D53 E5 82            [12] 2307 	mov	a,dpl
      008D55 90 0B 4A         [24] 2308 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008D58 F0               [24] 2309 	movx	@dptr,a
                                   2310 ;	quantum/dynamic_keymap.c:617: if (sending) return;
      008D59 90 0B 4B         [24] 2311 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008D5C E0               [24] 2312 	movx	a,@dptr
      008D5D 60 01            [24] 2313 	jz	00102$
      008D5F 22               [24] 2314 	ret
      008D60                       2315 00102$:
                                   2316 ;	quantum/dynamic_keymap.c:619: if (id >= DYNAMIC_KEYMAP_MACRO_COUNT) {
      008D60 90 0B 4A         [24] 2317 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008D63 E0               [24] 2318 	movx	a,@dptr
      008D64 FF               [12] 2319 	mov	r7,a
      008D65 BF 10 00         [24] 2320 	cjne	r7,#0x10,00422$
      008D68                       2321 00422$:
      008D68 40 01            [24] 2322 	jc	00104$
                                   2323 ;	quantum/dynamic_keymap.c:620: return;
      008D6A 22               [24] 2324 	ret
      008D6B                       2325 00104$:
                                   2326 ;	quantum/dynamic_keymap.c:626: if (!ak820_macro_ready()) return;
      008D6B C0 07            [24] 2327 	push	ar7
      008D6D 12 2A F2         [24] 2328 	lcall	_ak820_macro_ready
      008D70 E5 82            [12] 2329 	mov	a, dpl
      008D72 D0 07            [24] 2330 	pop	ar7
      008D74 70 01            [24] 2331 	jnz	00106$
      008D76 22               [24] 2332 	ret
      008D77                       2333 00106$:
                                   2334 ;	quantum/dynamic_keymap.c:643: p = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR;
      008D77 90 0B 4C         [24] 2335 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008D7A E4               [12] 2336 	clr	a
      008D7B F0               [24] 2337 	movx	@dptr,a
      008D7C 74 08            [12] 2338 	mov	a,#0x08
      008D7E A3               [24] 2339 	inc	dptr
      008D7F F0               [24] 2340 	movx	@dptr,a
                                   2341 ;	quantum/dynamic_keymap.c:644: uint16_t end = DYNAMIC_KEYMAP_MACRO_EEPROM_ADDR + ak820_macro_length();
      008D80 C0 07            [24] 2342 	push	ar7
      008D82 12 2B 2B         [24] 2343 	lcall	_ak820_macro_length
      008D85 AD 82            [24] 2344 	mov	r5, dpl
      008D87 AE 83            [24] 2345 	mov	r6, dph
      008D89 D0 07            [24] 2346 	pop	ar7
      008D8B 74 08            [12] 2347 	mov	a,#0x08
      008D8D 2E               [12] 2348 	add	a, r6
      008D8E FE               [12] 2349 	mov	r6,a
                                   2350 ;	quantum/dynamic_keymap.c:649: while (id > 0) {
      008D8F 7B 00            [12] 2351 	mov	r3,#0x00
      008D91 7C 08            [12] 2352 	mov	r4,#0x08
      008D93                       2353 00111$:
      008D93 EF               [12] 2354 	mov	a,r7
      008D94 60 31            [24] 2355 	jz	00113$
                                   2356 ;	quantum/dynamic_keymap.c:653: if (p == end) {
      008D96 EB               [12] 2357 	mov	a,r3
      008D97 B5 05 05         [24] 2358 	cjne	a,ar5,00108$
      008D9A EC               [12] 2359 	mov	a,r4
      008D9B B5 06 01         [24] 2360 	cjne	a,ar6,00108$
                                   2361 ;	quantum/dynamic_keymap.c:654: return;
      008D9E 22               [24] 2362 	ret
      008D9F                       2363 00108$:
                                   2364 ;	quantum/dynamic_keymap.c:656: if (eeprom_read_byte((const uint8_t *)(uintptr_t)p) == 0) {
      008D9F 8B 01            [24] 2365 	mov	ar1,r3
      008DA1 8C 02            [24] 2366 	mov	ar2,r4
      008DA3 8A 00            [24] 2367 	mov	ar0,r2
      008DA5 7A 00            [12] 2368 	mov	r2,#0x00
      008DA7 89 82            [24] 2369 	mov	dpl, r1
      008DA9 88 83            [24] 2370 	mov	dph, r0
      008DAB 8A F0            [24] 2371 	mov	b, r2
      008DAD 12 42 BF         [24] 2372 	lcall	_eeprom_read_byte
      008DB0 E5 82            [12] 2373 	mov	a, dpl
      008DB2 70 06            [24] 2374 	jnz	00110$
                                   2375 ;	quantum/dynamic_keymap.c:657: --id;
      008DB4 1F               [12] 2376 	dec	r7
      008DB5 90 0B 4A         [24] 2377 	mov	dptr,#_dynamic_keymap_macro_send_id_10000_457
      008DB8 EF               [12] 2378 	mov	a,r7
      008DB9 F0               [24] 2379 	movx	@dptr,a
      008DBA                       2380 00110$:
                                   2381 ;	quantum/dynamic_keymap.c:659: ++p;
      008DBA 0B               [12] 2382 	inc	r3
      008DBB BB 00 01         [24] 2383 	cjne	r3,#0x00,00429$
      008DBE 0C               [12] 2384 	inc	r4
      008DBF                       2385 00429$:
      008DBF 90 0B 4C         [24] 2386 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008DC2 12 3A B5         [24] 2387 	lcall	_ak820_outline_0085
      008DC5 80 CC            [24] 2388 	sjmp	00111$
      008DC7                       2389 00113$:
                                   2390 ;	quantum/dynamic_keymap.c:665: sending = true;
      008DC7 90 0B 4B         [24] 2391 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      008DCA 74 01            [12] 2392 	mov	a,#0x01
      008DCC F0               [24] 2393 	movx	@dptr,a
                                   2394 ;	quantum/dynamic_keymap.c:667: ak820_macro_cancelled = ak820_macro_primitive = false;
      008DCD 12 90 73         [24] 2395 	lcall	_ak820_outline_0165
      008DD0 90 09 94         [24] 2396 	mov	dptr,#_ak820_macro_cancelled
      008DD3 F0               [24] 2397 	movx	@dptr,a
                                   2398 ;	quantum/dynamic_keymap.c:672: char data[4] = {0, 0, 0, 0};
      008DD4 90 0B 4E         [24] 2399 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008DD7 F0               [24] 2400 	movx	@dptr,a
      008DD8 90 0B 4F         [24] 2401 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008DDB F0               [24] 2402 	movx	@dptr,a
      008DDC 90 0B 50         [24] 2403 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008DDF F0               [24] 2404 	movx	@dptr,a
      008DE0 90 0B 51         [24] 2405 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008DE3 F0               [24] 2406 	movx	@dptr,a
                                   2407 ;	quantum/dynamic_keymap.c:675: while (p < end
      008DE4                       2408 00167$:
                                   2409 ;	quantum/dynamic_keymap.c:677: && !ak820_macro_cancelled
      008DE4 90 0B 4C         [24] 2410 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008DE7 E0               [24] 2411 	movx	a,@dptr
      008DE8 FC               [12] 2412 	mov	r4,a
      008DE9 A3               [24] 2413 	inc	dptr
      008DEA E0               [24] 2414 	movx	a,@dptr
      008DEB FF               [12] 2415 	mov	r7,a
      008DEC C3               [12] 2416 	clr	c
      008DED EC               [12] 2417 	mov	a,r4
      008DEE 9D               [12] 2418 	subb	a,r5
      008DEF EF               [12] 2419 	mov	a,r7
      008DF0 9E               [12] 2420 	subb	a,r6
      008DF1 40 03            [24] 2421 	jc	00430$
      008DF3 02 90 08         [24] 2422 	ljmp	00169$
      008DF6                       2423 00430$:
      008DF6 90 09 94         [24] 2424 	mov	dptr,#_ak820_macro_cancelled
      008DF9 E0               [24] 2425 	movx	a,@dptr
      008DFA 60 03            [24] 2426 	jz	00431$
      008DFC 02 90 08         [24] 2427 	ljmp	00169$
      008DFF                       2428 00431$:
                                   2429 ;	quantum/dynamic_keymap.c:680: data[0] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008DFF 8C 02            [24] 2430 	mov	ar2,r4
      008E01 8F 03            [24] 2431 	mov	ar3,r7
      008E03 90 0B 4C         [24] 2432 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008E06 74 01            [12] 2433 	mov	a,#0x01
      008E08 2C               [12] 2434 	add	a, r4
      008E09 F0               [24] 2435 	movx	@dptr,a
      008E0A E4               [12] 2436 	clr	a
      008E0B 3F               [12] 2437 	addc	a, r7
      008E0C A3               [24] 2438 	inc	dptr
      008E0D F0               [24] 2439 	movx	@dptr,a
      008E0E 7F 00            [12] 2440 	mov	r7,#0x00
      008E10 12 3A F7         [24] 2441 	lcall	_ak820_outline_0143
      008E13 8F F0            [24] 2442 	mov	b, r7
      008E15 12 42 BF         [24] 2443 	lcall	_eeprom_read_byte
      008E18 AF 82            [24] 2444 	mov	r7, dpl
      008E1A 90 0B 4E         [24] 2445 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008E1D EF               [12] 2446 	mov	a,r7
      008E1E F0               [24] 2447 	movx	@dptr,a
                                   2448 ;	quantum/dynamic_keymap.c:681: data[1] = 0;
      008E1F 90 0B 4F         [24] 2449 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008E22 E4               [12] 2450 	clr	a
      008E23 F0               [24] 2451 	movx	@dptr,a
                                   2452 ;	quantum/dynamic_keymap.c:683: if (data[0] == 0) {
      008E24 90 0B 4E         [24] 2453 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008E27 E0               [24] 2454 	movx	a,@dptr
      008E28 70 03            [24] 2455 	jnz	00432$
      008E2A 02 90 08         [24] 2456 	ljmp	00169$
      008E2D                       2457 00432$:
                                   2458 ;	quantum/dynamic_keymap.c:686: if (data[0] == SS_QMK_PREFIX) {
      008E2D 90 0B 4E         [24] 2459 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008E30 E0               [24] 2460 	movx	a,@dptr
      008E31 FF               [12] 2461 	mov	r7,a
      008E32 BF 01 02         [24] 2462 	cjne	r7,#0x01,00433$
      008E35 80 03            [24] 2463 	sjmp	00434$
      008E37                       2464 00433$:
      008E37 02 8F EA         [24] 2465 	ljmp	00164$
      008E3A                       2466 00434$:
                                   2467 ;	quantum/dynamic_keymap.c:689: data[1] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E3A 12 90 10         [24] 2468 	lcall	_ak820_outline_0000
      008E3D 12 42 BF         [24] 2469 	lcall	_eeprom_read_byte
      008E40 AF 82            [24] 2470 	mov	r7, dpl
      008E42 90 0B 4F         [24] 2471 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008E45 EF               [12] 2472 	mov	a,r7
      008E46 F0               [24] 2473 	movx	@dptr,a
                                   2474 ;	quantum/dynamic_keymap.c:690: if (data[1] == 0)
      008E47 EF               [12] 2475 	mov	a,r7
      008E48 70 03            [24] 2476 	jnz	00435$
      008E4A 02 90 08         [24] 2477 	ljmp	00169$
      008E4D                       2478 00435$:
                                   2479 ;	quantum/dynamic_keymap.c:692: if (data[1] == SS_TAP_CODE || data[1] == SS_DOWN_CODE || data[1] == SS_UP_CODE) {
      008E4D 12 90 3A         [24] 2480 	lcall	_ak820_outline_0094
      008E50 BF 01 02         [24] 2481 	cjne	r7,#0x01,00436$
      008E53 80 13            [24] 2482 	sjmp	00151$
      008E55                       2483 00436$:
      008E55 12 90 3A         [24] 2484 	lcall	_ak820_outline_0094
      008E58 BF 02 02         [24] 2485 	cjne	r7,#0x02,00437$
      008E5B 80 0B            [24] 2486 	sjmp	00151$
      008E5D                       2487 00437$:
      008E5D 12 90 3A         [24] 2488 	lcall	_ak820_outline_0094
      008E60 BF 03 02         [24] 2489 	cjne	r7,#0x03,00438$
      008E63 80 03            [24] 2490 	sjmp	00439$
      008E65                       2491 00438$:
      008E65 02 8E C9         [24] 2492 	ljmp	00152$
      008E68                       2493 00439$:
      008E68                       2494 00151$:
                                   2495 ;	quantum/dynamic_keymap.c:694: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008E68 12 90 10         [24] 2496 	lcall	_ak820_outline_0000
      008E6B 12 42 BF         [24] 2497 	lcall	_eeprom_read_byte
      008E6E 12 90 8B         [24] 2498 	lcall	_ak820_outline_0181
                                   2499 ;	quantum/dynamic_keymap.c:698: if (data[2] != 0) {
      008E71 70 03            [24] 2500 	jnz	00440$
      008E73 02 8D E4         [24] 2501 	ljmp	00167$
      008E76                       2502 00440$:
                                   2503 ;	quantum/dynamic_keymap.c:700: ak820_macro_primitive = data[1] != SS_TAP_CODE;
      008E76 12 90 3A         [24] 2504 	lcall	_ak820_outline_0094
      008E79 BF 01 03         [24] 2505 	cjne	r7,#0x01,00441$
      008E7C D3               [12] 2506 	setb	c
      008E7D 80 01            [24] 2507 	sjmp	00442$
      008E7F                       2508 00441$:
      008E7F C3               [12] 2509 	clr	c
      008E80                       2510 00442$:
      008E80 92 25            [24] 2511 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008E82 90 09 93         [24] 2512 	mov	dptr,#_ak820_macro_primitive
      008E85 B3               [12] 2513 	cpl	c
      008E86 E4               [12] 2514 	clr	a
      008E87 33               [12] 2515 	rlc	a
      008E88 F0               [24] 2516 	movx	@dptr,a
                                   2517 ;	quantum/dynamic_keymap.c:702: if (data[1] == SS_TAP_CODE) tap_code((uint8_t)data[2]);
      008E89 12 90 3A         [24] 2518 	lcall	_ak820_outline_0094
      008E8C BF 01 10         [24] 2519 	cjne	r7,#0x01,00122$
      008E8F 12 90 6C         [24] 2520 	lcall	_ak820_outline_0151
      008E92 C0 06            [24] 2521 	push	ar6
      008E94 C0 05            [24] 2522 	push	ar5
      008E96 12 78 3D         [24] 2523 	lcall	_tap_code
      008E99 D0 05            [24] 2524 	pop	ar5
      008E9B D0 06            [24] 2525 	pop	ar6
      008E9D 80 24            [24] 2526 	sjmp	00123$
      008E9F                       2527 00122$:
                                   2528 ;	quantum/dynamic_keymap.c:703: else if (data[1] == SS_DOWN_CODE) register_code((uint8_t)data[2]);
      008E9F 12 90 3A         [24] 2529 	lcall	_ak820_outline_0094
      008EA2 BF 02 10         [24] 2530 	cjne	r7,#0x02,00119$
      008EA5 12 90 6C         [24] 2531 	lcall	_ak820_outline_0151
      008EA8 C0 06            [24] 2532 	push	ar6
      008EAA C0 05            [24] 2533 	push	ar5
      008EAC 12 77 37         [24] 2534 	lcall	_register_code
      008EAF D0 05            [24] 2535 	pop	ar5
      008EB1 D0 06            [24] 2536 	pop	ar6
      008EB3 80 0E            [24] 2537 	sjmp	00123$
      008EB5                       2538 00119$:
                                   2539 ;	quantum/dynamic_keymap.c:704: else unregister_code((uint8_t)data[2]);
      008EB5 12 90 6C         [24] 2540 	lcall	_ak820_outline_0151
      008EB8 C0 06            [24] 2541 	push	ar6
      008EBA C0 05            [24] 2542 	push	ar5
      008EBC 12 77 A4         [24] 2543 	lcall	_unregister_code
      008EBF D0 05            [24] 2544 	pop	ar5
      008EC1 D0 06            [24] 2545 	pop	ar6
      008EC3                       2546 00123$:
                                   2547 ;	quantum/dynamic_keymap.c:706: ak820_macro_primitive = false;
      008EC3 12 90 73         [24] 2548 	lcall	_ak820_outline_0165
      008EC6 02 8D E4         [24] 2549 	ljmp	00167$
      008EC9                       2550 00152$:
                                   2551 ;	quantum/dynamic_keymap.c:714: } else if (data[1] == VIAL_MACRO_EXT_TAP || data[1] == VIAL_MACRO_EXT_DOWN || data[1] == VIAL_MACRO_EXT_UP) {
      008EC9 12 90 3A         [24] 2552 	lcall	_ak820_outline_0094
      008ECC BF 05 02         [24] 2553 	cjne	r7,#0x05,00447$
      008ECF 80 13            [24] 2554 	sjmp	00146$
      008ED1                       2555 00447$:
      008ED1 12 90 3A         [24] 2556 	lcall	_ak820_outline_0094
      008ED4 BF 06 02         [24] 2557 	cjne	r7,#0x06,00448$
      008ED7 80 0B            [24] 2558 	sjmp	00146$
      008ED9                       2559 00448$:
      008ED9 12 90 3A         [24] 2560 	lcall	_ak820_outline_0094
      008EDC BF 07 02         [24] 2561 	cjne	r7,#0x07,00449$
      008EDF 80 03            [24] 2562 	sjmp	00450$
      008EE1                       2563 00449$:
      008EE1 02 8F 8A         [24] 2564 	ljmp	00147$
      008EE4                       2565 00450$:
      008EE4                       2566 00146$:
                                   2567 ;	quantum/dynamic_keymap.c:715: data[2] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008EE4 12 90 10         [24] 2568 	lcall	_ak820_outline_0000
      008EE7 12 42 BF         [24] 2569 	lcall	_eeprom_read_byte
      008EEA 12 90 8B         [24] 2570 	lcall	_ak820_outline_0181
                                   2571 ;	quantum/dynamic_keymap.c:716: if (data[2] != 0) {
      008EED 70 03            [24] 2572 	jnz	00451$
      008EEF 02 8D E4         [24] 2573 	ljmp	00167$
      008EF2                       2574 00451$:
                                   2575 ;	quantum/dynamic_keymap.c:717: data[3] = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008EF2 12 90 10         [24] 2576 	lcall	_ak820_outline_0000
      008EF5 12 42 BF         [24] 2577 	lcall	_eeprom_read_byte
      008EF8 AF 82            [24] 2578 	mov	r7, dpl
      008EFA 90 0B 51         [24] 2579 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008EFD EF               [12] 2580 	mov	a,r7
      008EFE F0               [24] 2581 	movx	@dptr,a
                                   2582 ;	quantum/dynamic_keymap.c:718: if (data[3] != 0) {
      008EFF EF               [12] 2583 	mov	a,r7
      008F00 70 03            [24] 2584 	jnz	00452$
      008F02 02 8D E4         [24] 2585 	ljmp	00167$
      008F05                       2586 00452$:
                                   2587 ;	quantum/dynamic_keymap.c:721: kc = (uint8_t)data[2] | ((uint16_t)(uint8_t)data[3] << 8);
      008F05 90 0B 50         [24] 2588 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0002)
      008F08 E0               [24] 2589 	movx	a,@dptr
      008F09 FF               [12] 2590 	mov	r7,a
      008F0A 90 0B 51         [24] 2591 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0003)
      008F0D E0               [24] 2592 	movx	a,@dptr
      008F0E FB               [12] 2593 	mov	r3,a
      008F0F E4               [12] 2594 	clr	a
      008F10 FC               [12] 2595 	mov	r4,a
      008F11 FA               [12] 2596 	mov	r2,a
      008F12 EF               [12] 2597 	mov	a,r7
      008F13 42 04            [12] 2598 	orl	ar4,a
      008F15 EA               [12] 2599 	mov	a,r2
      008F16 42 03            [12] 2600 	orl	ar3,a
                                   2601 ;	quantum/dynamic_keymap.c:725: kc = decode_keycode(kc);
      008F18 12 45 D3         [24] 2602 	lcall	_ak820_outline_0184
      008F1B C0 06            [24] 2603 	push	ar6
      008F1D C0 05            [24] 2604 	push	ar5
      008F1F 12 8D 30         [24] 2605 	lcall	_decode_keycode
      008F22 AC 82            [24] 2606 	mov	r4, dpl
      008F24 AF 83            [24] 2607 	mov	r7, dph
      008F26 D0 05            [24] 2608 	pop	ar5
      008F28 D0 06            [24] 2609 	pop	ar6
                                   2610 ;	quantum/dynamic_keymap.c:727: ak820_macro_primitive = data[1] != VIAL_MACRO_EXT_TAP;
      008F2A 90 0B 4F         [24] 2611 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008F2D E0               [24] 2612 	movx	a,@dptr
      008F2E FB               [12] 2613 	mov	r3,a
      008F2F BB 05 03         [24] 2614 	cjne	r3,#0x05,00453$
      008F32 D3               [12] 2615 	setb	c
      008F33 80 01            [24] 2616 	sjmp	00454$
      008F35                       2617 00453$:
      008F35 C3               [12] 2618 	clr	c
      008F36                       2619 00454$:
      008F36 92 25            [24] 2620 	mov	_dynamic_keymap_macro_send_sloc0_1_0,c
      008F38 90 09 93         [24] 2621 	mov	dptr,#_ak820_macro_primitive
      008F3B B3               [12] 2622 	cpl	c
      008F3C E4               [12] 2623 	clr	a
      008F3D 33               [12] 2624 	rlc	a
      008F3E F0               [24] 2625 	movx	@dptr,a
                                   2626 ;	quantum/dynamic_keymap.c:729: switch (data[1]) {
      008F3F 90 0B 4F         [24] 2627 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470 + 0x0001)
      008F42 E0               [24] 2628 	movx	a,@dptr
      008F43 FB               [12] 2629 	mov	r3,a
      008F44 BB 05 02         [24] 2630 	cjne	r3,#0x05,00455$
      008F47 80 0A            [24] 2631 	sjmp	00126$
      008F49                       2632 00455$:
      008F49 BB 06 02         [24] 2633 	cjne	r3,#0x06,00456$
      008F4C 80 16            [24] 2634 	sjmp	00127$
      008F4E                       2635 00456$:
                                   2636 ;	quantum/dynamic_keymap.c:730: case VIAL_MACRO_EXT_TAP:
      008F4E BB 07 33         [24] 2637 	cjne	r3,#0x07,00129$
      008F51 80 22            [24] 2638 	sjmp	00128$
      008F53                       2639 00126$:
                                   2640 ;	quantum/dynamic_keymap.c:731: vial_keycode_tap(kc);
      008F53 8C 82            [24] 2641 	mov	dpl, r4
      008F55 8F 83            [24] 2642 	mov	dph, r7
      008F57 C0 06            [24] 2643 	push	ar6
      008F59 C0 05            [24] 2644 	push	ar5
      008F5B 12 B3 E8         [24] 2645 	lcall	_vial_keycode_tap
      008F5E D0 05            [24] 2646 	pop	ar5
      008F60 D0 06            [24] 2647 	pop	ar6
                                   2648 ;	quantum/dynamic_keymap.c:732: break;
                                   2649 ;	quantum/dynamic_keymap.c:733: case VIAL_MACRO_EXT_DOWN:
      008F62 80 20            [24] 2650 	sjmp	00129$
      008F64                       2651 00127$:
                                   2652 ;	quantum/dynamic_keymap.c:734: vial_keycode_down(kc);
      008F64 8C 82            [24] 2653 	mov	dpl, r4
      008F66 8F 83            [24] 2654 	mov	dph, r7
      008F68 C0 06            [24] 2655 	push	ar6
      008F6A C0 05            [24] 2656 	push	ar5
      008F6C 12 B3 1D         [24] 2657 	lcall	_vial_keycode_down
      008F6F D0 05            [24] 2658 	pop	ar5
      008F71 D0 06            [24] 2659 	pop	ar6
                                   2660 ;	quantum/dynamic_keymap.c:735: break;
                                   2661 ;	quantum/dynamic_keymap.c:736: case VIAL_MACRO_EXT_UP:
      008F73 80 0F            [24] 2662 	sjmp	00129$
      008F75                       2663 00128$:
                                   2664 ;	quantum/dynamic_keymap.c:737: vial_keycode_up(kc);
      008F75 8C 82            [24] 2665 	mov	dpl, r4
      008F77 8F 83            [24] 2666 	mov	dph, r7
      008F79 C0 06            [24] 2667 	push	ar6
      008F7B C0 05            [24] 2668 	push	ar5
      008F7D 12 B3 83         [24] 2669 	lcall	_vial_keycode_up
      008F80 D0 05            [24] 2670 	pop	ar5
      008F82 D0 06            [24] 2671 	pop	ar6
                                   2672 ;	quantum/dynamic_keymap.c:739: }
      008F84                       2673 00129$:
                                   2674 ;	quantum/dynamic_keymap.c:741: ak820_macro_primitive = false;
      008F84 12 90 73         [24] 2675 	lcall	_ak820_outline_0165
      008F87 02 8D E4         [24] 2676 	ljmp	00167$
      008F8A                       2677 00147$:
                                   2678 ;	quantum/dynamic_keymap.c:745: } else if (data[1] == SS_DELAY_CODE) {
      008F8A 12 90 3A         [24] 2679 	lcall	_ak820_outline_0094
      008F8D BF 04 02         [24] 2680 	cjne	r7,#0x04,00458$
      008F90 80 03            [24] 2681 	sjmp	00459$
      008F92                       2682 00458$:
      008F92 02 8D E4         [24] 2683 	ljmp	00167$
      008F95                       2684 00459$:
                                   2685 ;	quantum/dynamic_keymap.c:747: uint8_t d0 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F95 12 90 10         [24] 2686 	lcall	_ak820_outline_0000
      008F98 12 42 BF         [24] 2687 	lcall	_eeprom_read_byte
      008F9B AF 82            [24] 2688 	mov	r7, dpl
                                   2689 ;	quantum/dynamic_keymap.c:748: uint8_t d1 = eeprom_read_byte((const uint8_t *)(uintptr_t)p++);
      008F9D 90 0B 4C         [24] 2690 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008FA0 12 3A DC         [24] 2691 	lcall	_ak820_outline_0122
      008FA3 90 0B 4C         [24] 2692 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      008FA6 74 01            [12] 2693 	mov	a,#0x01
      008FA8 2B               [12] 2694 	add	a, r3
      008FA9 F0               [24] 2695 	movx	@dptr,a
      008FAA E4               [12] 2696 	clr	a
      008FAB 3C               [12] 2697 	addc	a, r4
      008FAC A3               [24] 2698 	inc	dptr
      008FAD F0               [24] 2699 	movx	@dptr,a
      008FAE 7A 00            [12] 2700 	mov	r2,#0x00
      008FB0 12 36 47         [24] 2701 	lcall	_ak820_outline_0123
      008FB3 8A F0            [24] 2702 	mov	b, r2
      008FB5 12 42 BF         [24] 2703 	lcall	_eeprom_read_byte
      008FB8 AC 82            [24] 2704 	mov	r4, dpl
                                   2705 ;	quantum/dynamic_keymap.c:749: if (d0 == 0 || d1 == 0)
      008FBA EF               [12] 2706 	mov	a,r7
      008FBB 60 4B            [24] 2707 	jz	00169$
      008FBD EC               [12] 2708 	mov	a,r4
      008FBE 60 48            [24] 2709 	jz	00169$
                                   2710 ;	quantum/dynamic_keymap.c:752: uint16_t ms = (uint16_t)(d0 - 1) + (uint16_t)(d1 - 1) * 255u;
      008FC0 1F               [12] 2711 	dec	r7
      008FC1 1C               [12] 2712 	dec	r4
      008FC2 EC               [12] 2713 	mov	a,r4
      008FC3 75 F0 FF         [24] 2714 	mov	b,#0xff
      008FC6 A4               [48] 2715 	mul	ab
      008FC7 FC               [12] 2716 	mov	r4,a
      008FC8 AB F0            [24] 2717 	mov	r3,b
      008FCA 7A 00            [12] 2718 	mov	r2,#0x00
      008FCC EC               [12] 2719 	mov	a,r4
      008FCD 2F               [12] 2720 	add	a, r7
      008FCE FC               [12] 2721 	mov	r4,a
      008FCF EB               [12] 2722 	mov	a,r3
      008FD0 3A               [12] 2723 	addc	a, r2
      008FD1 FB               [12] 2724 	mov	r3,a
                                   2725 ;	quantum/dynamic_keymap.c:753: while (ms--) wait_ms(1);
      008FD2                       2726 00141$:
      008FD2 8C 02            [24] 2727 	mov	ar2,r4
      008FD4 8B 07            [24] 2728 	mov	ar7,r3
      008FD6 1C               [12] 2729 	dec	r4
      008FD7 BC FF 01         [24] 2730 	cjne	r4,#0xff,00462$
      008FDA 1B               [12] 2731 	dec	r3
      008FDB                       2732 00462$:
      008FDB EA               [12] 2733 	mov	a,r2
      008FDC 4F               [12] 2734 	orl	a,r7
      008FDD 70 03            [24] 2735 	jnz	00463$
      008FDF 02 8D E4         [24] 2736 	ljmp	00167$
      008FE2                       2737 00463$:
      008FE2 90 00 01         [24] 2738 	mov	dptr,#0x0001
      008FE5 12 5B 08         [24] 2739 	lcall	_mDelaymS
      008FE8 80 E8            [24] 2740 	sjmp	00141$
      008FEA                       2741 00164$:
                                   2742 ;	quantum/dynamic_keymap.c:759: if ((uint8_t)data[0] >= 128) break;
      008FEA 90 0B 4E         [24] 2743 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008FED E0               [24] 2744 	movx	a,@dptr
      008FEE FF               [12] 2745 	mov	r7,a
      008FEF BF 80 00         [24] 2746 	cjne	r7,#0x80,00464$
      008FF2                       2747 00464$:
      008FF2 50 14            [24] 2748 	jnc	00169$
                                   2749 ;	quantum/dynamic_keymap.c:763: send_char(data[0]);
      008FF4 90 0B 4E         [24] 2750 	mov	dptr,#_dynamic_keymap_macro_send_data_10003_470
      008FF7 E0               [24] 2751 	movx	a,@dptr
      008FF8 F5 82            [12] 2752 	mov	dpl,a
      008FFA C0 06            [24] 2753 	push	ar6
      008FFC C0 05            [24] 2754 	push	ar5
      008FFE 12 A6 8F         [24] 2755 	lcall	_send_char
      009001 D0 05            [24] 2756 	pop	ar5
      009003 D0 06            [24] 2757 	pop	ar6
                                   2758 ;	quantum/dynamic_keymap.c:764: for (uint8_t delay = DYNAMIC_KEYMAP_MACRO_DELAY; delay; --delay) wait_ms(1);
      009005 02 8D E4         [24] 2759 	ljmp	00167$
      009008                       2760 00169$:
                                   2761 ;	quantum/dynamic_keymap.c:772: ak820_macro_primitive = false;
      009008 12 90 73         [24] 2762 	lcall	_ak820_outline_0165
                                   2763 ;	quantum/dynamic_keymap.c:774: sending = false;
      00900B 90 0B 4B         [24] 2764 	mov	dptr,#_dynamic_keymap_macro_send_sending_10000_458
      00900E F0               [24] 2765 	movx	@dptr,a
                                   2766 ;	quantum/dynamic_keymap.c:776: }
      00900F 22               [24] 2767 	ret
                                   2768 	.area CSEG    (CODE)
                                   2769 	.area CONST   (CODE)
                                   2770 	.area XINIT   (CODE)
                                   2771 	.area CABS    (ABS,CODE)
                                   2772 
                                   2773 ; Experimental exact instruction outlining.
                                   2774 	.globl _ak820_outline_0000
                                   2775 	.globl _ak820_outline_0005
                                   2776 	.globl _ak820_outline_0008
                                   2777 	.globl _ak820_outline_0013
                                   2778 	.globl _ak820_outline_0022
                                   2779 	.globl _ak820_outline_0033
                                   2780 	.globl _ak820_outline_0034
                                   2781 	.globl _ak820_outline_0051
                                   2782 	.globl _ak820_outline_0057
                                   2783 	.globl _ak820_outline_0058
                                   2784 	.globl _ak820_outline_0059
                                   2785 	.globl _ak820_outline_0064
                                   2786 	.globl _ak820_outline_0071
                                   2787 	.globl _ak820_outline_0072
                                   2788 	.globl _ak820_outline_0077
                                   2789 	.globl _ak820_outline_0081
                                   2790 	.globl _ak820_outline_0085
                                   2791 	.globl _ak820_outline_0091
                                   2792 	.globl _ak820_outline_0093
                                   2793 	.globl _ak820_outline_0094
                                   2794 	.globl _ak820_outline_0099
                                   2795 	.globl _ak820_outline_0101
                                   2796 	.globl _ak820_outline_0102
                                   2797 	.globl _ak820_outline_0103
                                   2798 	.globl _ak820_outline_0107
                                   2799 	.globl _ak820_outline_0108
                                   2800 	.globl _ak820_outline_0111
                                   2801 	.globl _ak820_outline_0116
                                   2802 	.globl _ak820_outline_0118
                                   2803 	.globl _ak820_outline_0122
                                   2804 	.globl _ak820_outline_0123
                                   2805 	.globl _ak820_outline_0124
                                   2806 	.globl _ak820_outline_0128
                                   2807 	.globl _ak820_outline_0133
                                   2808 	.globl _ak820_outline_0134
                                   2809 	.globl _ak820_outline_0135
                                   2810 	.globl _ak820_outline_0136
                                   2811 	.globl _ak820_outline_0137
                                   2812 	.globl _ak820_outline_0142
                                   2813 	.globl _ak820_outline_0143
                                   2814 	.globl _ak820_outline_0149
                                   2815 	.globl _ak820_outline_0151
                                   2816 	.globl _ak820_outline_0155
                                   2817 	.globl _ak820_outline_0157
                                   2818 	.globl _ak820_outline_0160
                                   2819 	.globl _ak820_outline_0165
                                   2820 	.globl _ak820_outline_0177
                                   2821 	.globl _ak820_outline_0178
                                   2822 	.globl _ak820_outline_0181
                                   2823 	.globl _ak820_outline_0182
                                   2824 	.globl _ak820_outline_0183
                                   2825 	.globl _ak820_outline_0184
                                   2826 	.globl _ak820_outline_0187
                                   2827 
                                   2828 	.area CSEG (CODE)
                                   2829 ; function ak820_outline_0000
      009010                       2830 _ak820_outline_0000:
      009010 90 0B 4C         [24] 2831 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      009013 E0               [24] 2832 	movx	a,@dptr
      009014 FC               [12] 2833 	mov	r4,a
      009015 A3               [24] 2834 	inc	dptr
      009016 E0               [24] 2835 	movx	a,@dptr
      009017 FF               [12] 2836 	mov	r7,a
      009018 90 0B 4C         [24] 2837 	mov	dptr,#_dynamic_keymap_macro_send_p_10001_463
      00901B 74 01            [12] 2838 	mov	a,#0x01
      00901D 2C               [12] 2839 	add	a,r4
      00901E F0               [24] 2840 	movx	@dptr,a
      00901F E4               [12] 2841 	clr	a
      009020 3F               [12] 2842 	addc	a,r7
      009021 A3               [24] 2843 	inc	dptr
      009022 F0               [24] 2844 	movx	@dptr,a
      009023 7B 00            [12] 2845 	mov	r3,#0x00
      009025 8C 82            [24] 2846 	mov	dpl,r4
      009027 8F 83            [24] 2847 	mov	dph,r7
      009029 8B F0            [24] 2848 	mov	b,r3
      00902B 22               [24] 2849 	ret
                                   2850 
                                   2851 	.area CSEG (CODE)
                                   2852 ; function ak820_outline_0081
      00902C                       2853 _ak820_outline_0081:
      00902C ED               [12] 2854 	mov	a,r5
      00902D 75 F0 0A         [24] 2855 	mov	b,#0x0a
      009030 A4               [48] 2856 	mul	ab
      009031 24 58            [12] 2857 	add	a,#0x58
      009033 FC               [12] 2858 	mov	r4,a
      009034 74 06            [12] 2859 	mov	a,#0x06
      009036 35 F0            [12] 2860 	addc	a,b
      009038 FD               [12] 2861 	mov	r5,a
      009039 22               [24] 2862 	ret
                                   2863 
                                   2864 	.area CSEG (CODE)
                                   2865 ; function ak820_outline_0094
      00903A                       2866 _ak820_outline_0094:
      00903A 90 0B 4F         [24] 2867 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0001)
      00903D E0               [24] 2868 	movx	a,@dptr
      00903E FF               [12] 2869 	mov	r7,a
      00903F 22               [24] 2870 	ret
                                   2871 
                                   2872 	.area CSEG (CODE)
                                   2873 ; function ak820_outline_0099
      009040                       2874 _ak820_outline_0099:
      009040 90 0A E5         [24] 2875 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_2
      009043 EE               [12] 2876 	mov	a,r6
      009044 F0               [24] 2877 	movx	@dptr,a
      009045 90 0A E6         [24] 2878 	mov	dptr,#_dynamic_keymap_key_to_eeprom_address_PARM_3
      009048 ED               [12] 2879 	mov	a,r5
      009049 F0               [24] 2880 	movx	@dptr,a
      00904A 8F 82            [24] 2881 	mov	dpl,r7
      00904C 22               [24] 2882 	ret
                                   2883 
                                   2884 	.area CSEG (CODE)
                                   2885 ; function ak820_outline_0111
      00904D                       2886 _ak820_outline_0111:
      00904D 74 0A            [12] 2887 	mov	a,#0x0a
      00904F F0               [24] 2888 	movx	@dptr,a
      009050 E4               [12] 2889 	clr	a
      009051 A3               [24] 2890 	inc	dptr
      009052 F0               [24] 2891 	movx	@dptr,a
      009053 22               [24] 2892 	ret
                                   2893 
                                   2894 	.area CSEG (CODE)
                                   2895 ; function ak820_outline_0116
      009054                       2896 _ak820_outline_0116:
      009054 AD 82            [24] 2897 	mov	r5,dpl
      009056 AE 83            [24] 2898 	mov	r6,dph
      009058 AF F0            [24] 2899 	mov	r7,b
      00905A 22               [24] 2900 	ret
                                   2901 
                                   2902 	.area CSEG (CODE)
                                   2903 ; function ak820_outline_0128
      00905B                       2904 _ak820_outline_0128:
      00905B 28               [12] 2905 	add	a,r0
      00905C F5 82            [12] 2906 	mov	dpl,a
      00905E EF               [12] 2907 	mov	a,r7
      00905F 39               [12] 2908 	addc	a,r1
      009060 F5 83            [12] 2909 	mov	dph,a
      009062 74 FF            [12] 2910 	mov	a,#0xff
      009064 F0               [24] 2911 	movx	@dptr,a
      009065 22               [24] 2912 	ret
                                   2913 
                                   2914 	.area CSEG (CODE)
                                   2915 ; function ak820_outline_0136
      009066                       2916 _ak820_outline_0136:
      009066 2D               [12] 2917 	add	a,r5
      009067 F9               [12] 2918 	mov	r1,a
      009068 E4               [12] 2919 	clr	a
      009069 3E               [12] 2920 	addc	a,r6
      00906A FA               [12] 2921 	mov	r2,a
      00906B 22               [24] 2922 	ret
                                   2923 
                                   2924 	.area CSEG (CODE)
                                   2925 ; function ak820_outline_0151
      00906C                       2926 _ak820_outline_0151:
      00906C 90 0B 50         [24] 2927 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      00906F E0               [24] 2928 	movx	a,@dptr
      009070 F5 82            [12] 2929 	mov	dpl,a
      009072 22               [24] 2930 	ret
                                   2931 
                                   2932 	.area CSEG (CODE)
                                   2933 ; function ak820_outline_0165
      009073                       2934 _ak820_outline_0165:
      009073 90 09 93         [24] 2935 	mov	dptr,#_ak820_macro_primitive
      009076 E4               [12] 2936 	clr	a
      009077 F0               [24] 2937 	movx	@dptr,a
      009078 22               [24] 2938 	ret
                                   2939 
                                   2940 	.area CSEG (CODE)
                                   2941 ; function ak820_outline_0177
      009079                       2942 _ak820_outline_0177:
      009079 90 0A F5         [24] 2943 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_2
      00907C E4               [12] 2944 	clr	a
      00907D F0               [24] 2945 	movx	@dptr,a
      00907E 90 0A F6         [24] 2946 	mov	dptr,#_dynamic_keymap_set_encoder_PARM_3
      009081 22               [24] 2947 	ret
                                   2948 
                                   2949 	.area CSEG (CODE)
                                   2950 ; function ak820_outline_0178
      009082                       2951 _ak820_outline_0178:
      009082 90 0B AB         [24] 2952 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_2
      009085 E4               [12] 2953 	clr	a
      009086 F0               [24] 2954 	movx	@dptr,a
      009087 90 0B AC         [24] 2955 	mov	dptr,#_keycode_at_encodermap_location_raw_PARM_3
      00908A 22               [24] 2956 	ret
                                   2957 
                                   2958 	.area CSEG (CODE)
                                   2959 ; function ak820_outline_0181
      00908B                       2960 _ak820_outline_0181:
      00908B AF 82            [24] 2961 	mov	r7,dpl
      00908D 90 0B 50         [24] 2962 	mov	dptr,#(_dynamic_keymap_macro_send_data_10003_470+0x0002)
      009090 EF               [12] 2963 	mov	a,r7
      009091 F0               [24] 2964 	movx	@dptr,a
      009092 EF               [12] 2965 	mov	a,r7
      009093 22               [24] 2966 	ret
