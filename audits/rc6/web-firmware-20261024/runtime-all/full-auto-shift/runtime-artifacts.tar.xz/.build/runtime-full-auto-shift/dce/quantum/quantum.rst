                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module quantum
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _shutdown_quantum
                                     12 	.globl _extract_mod_bits
                                     13 	.globl _process_tri_layer
                                     14 	.globl _process_rgb
                                     15 	.globl _process_grave_esc
                                     16 	.globl _ak820_combo_process
                                     17 	.globl _process_repeat_key
                                     18 	.globl _process_last_key
                                     19 	.globl _process_caps_word
                                     20 	.globl _process_record_via
                                     21 	.globl _mcu_reset
                                     22 	.globl _bootloader_jump
                                     23 	.globl _ak820_resolve_key
                                     24 	.globl _default_layer_set
                                     25 	.globl _clear_keyboard
                                     26 	.globl _unregister_weak_mods
                                     27 	.globl _register_weak_mods
                                     28 	.globl _unregister_mods
                                     29 	.globl _register_mods
                                     30 	.globl _unregister_code
                                     31 	.globl _register_code
                                     32 	.globl _eeconfig_disable
                                     33 	.globl _rgb_matrix_set_suspend_state
                                     34 	.globl _rgb_matrix_task
                                     35 	.globl _mDelaymS
                                     36 	.globl _ADC_START
                                     37 	.globl _S0_R_FIFO
                                     38 	.globl _S0_T_FIFO
                                     39 	.globl _S0_FREE
                                     40 	.globl _S0_IF_BYTE
                                     41 	.globl _S0_IF_FIRST
                                     42 	.globl _S0_IF_OV
                                     43 	.globl _S0_FST_ACT
                                     44 	.globl _CP_RL2
                                     45 	.globl _C_T2
                                     46 	.globl _TR2
                                     47 	.globl _EXEN2
                                     48 	.globl _TCLK
                                     49 	.globl _RCLK
                                     50 	.globl _EXF2
                                     51 	.globl _CAP1F
                                     52 	.globl _TF2
                                     53 	.globl _RI
                                     54 	.globl _TI
                                     55 	.globl _RB8
                                     56 	.globl _TB8
                                     57 	.globl _REN
                                     58 	.globl _SM2
                                     59 	.globl _SM1
                                     60 	.globl _SM0
                                     61 	.globl _IT0
                                     62 	.globl _IE0
                                     63 	.globl _IT1
                                     64 	.globl _IE1
                                     65 	.globl _TR0
                                     66 	.globl _TF0
                                     67 	.globl _TR1
                                     68 	.globl _TF1
                                     69 	.globl _P4_0
                                     70 	.globl _P4_1
                                     71 	.globl _P4_2
                                     72 	.globl _P4_3
                                     73 	.globl _P4_4
                                     74 	.globl _P4_5
                                     75 	.globl _P4_6
                                     76 	.globl _RXD
                                     77 	.globl _TXD
                                     78 	.globl _INT0
                                     79 	.globl _INT1
                                     80 	.globl _T0
                                     81 	.globl _T1
                                     82 	.globl _MOSI1
                                     83 	.globl _MISO1
                                     84 	.globl _SCK1
                                     85 	.globl _P3_0
                                     86 	.globl _P3_1
                                     87 	.globl _P3_2
                                     88 	.globl _P3_3
                                     89 	.globl _P3_4
                                     90 	.globl _P3_5
                                     91 	.globl _P3_6
                                     92 	.globl _P3_7
                                     93 	.globl _CAP1_
                                     94 	.globl _T2_
                                     95 	.globl _CAP2_
                                     96 	.globl _T2EX_
                                     97 	.globl _RXD1
                                     98 	.globl _TXD1
                                     99 	.globl _P2_0
                                    100 	.globl _P2_1
                                    101 	.globl _P2_2
                                    102 	.globl _P2_3
                                    103 	.globl _P2_4
                                    104 	.globl _P2_5
                                    105 	.globl _P2_6
                                    106 	.globl _P2_7
                                    107 	.globl _AIN0
                                    108 	.globl _AIN1
                                    109 	.globl _AIN2
                                    110 	.globl _AIN3
                                    111 	.globl _AIN4
                                    112 	.globl _AIN5
                                    113 	.globl _AIN6
                                    114 	.globl _AIN7
                                    115 	.globl _CAP1
                                    116 	.globl _T2
                                    117 	.globl _CAP2
                                    118 	.globl _T2EX
                                    119 	.globl _INT0_
                                    120 	.globl _SCS
                                    121 	.globl _MOSI
                                    122 	.globl _MISO
                                    123 	.globl _SCK
                                    124 	.globl _RXD1_
                                    125 	.globl _TXD1_
                                    126 	.globl _P1_0
                                    127 	.globl _P1_1
                                    128 	.globl _P1_2
                                    129 	.globl _P1_3
                                    130 	.globl _P1_4
                                    131 	.globl _P1_5
                                    132 	.globl _P1_6
                                    133 	.globl _P1_7
                                    134 	.globl _AIN8
                                    135 	.globl _AIN9
                                    136 	.globl _AIN10
                                    137 	.globl _AIN11
                                    138 	.globl _AIN12
                                    139 	.globl _AIN13
                                    140 	.globl _RXD_
                                    141 	.globl _TXD_
                                    142 	.globl _SCL0
                                    143 	.globl _SDA0
                                    144 	.globl _P0_0
                                    145 	.globl _P0_1
                                    146 	.globl _P0_2
                                    147 	.globl _P0_3
                                    148 	.globl _P0_4
                                    149 	.globl _P0_5
                                    150 	.globl _P0_6
                                    151 	.globl _P0_7
                                    152 	.globl _IE_SPI0
                                    153 	.globl _IE_USB
                                    154 	.globl _IE_ADC
                                    155 	.globl _IE_UART1
                                    156 	.globl _IE_PWM_I2C
                                    157 	.globl _IE_GPIO
                                    158 	.globl _IE_WDOG
                                    159 	.globl _PX0
                                    160 	.globl _PT0
                                    161 	.globl _PX1
                                    162 	.globl _PT1
                                    163 	.globl _PS
                                    164 	.globl _PT2
                                    165 	.globl _PL_FLAG
                                    166 	.globl _PH_FLAG
                                    167 	.globl _EX0
                                    168 	.globl _ET0
                                    169 	.globl _EX1
                                    170 	.globl _ET1
                                    171 	.globl _ES
                                    172 	.globl _ET2
                                    173 	.globl _E_DIS
                                    174 	.globl _EA
                                    175 	.globl _P
                                    176 	.globl _F1
                                    177 	.globl _OV
                                    178 	.globl _RS0
                                    179 	.globl _RS1
                                    180 	.globl _F0
                                    181 	.globl _AC
                                    182 	.globl _CY
                                    183 	.globl _I2CS_INT_ST
                                    184 	.globl _I2CX_INT
                                    185 	.globl _LED_STATUS
                                    186 	.globl _LED_DMA_H
                                    187 	.globl _LED_DMA_L
                                    188 	.globl _LED_DMA
                                    189 	.globl _LED_PWM_OE
                                    190 	.globl _LED_COMMON
                                    191 	.globl _ADC_CHAN
                                    192 	.globl _ADC_DAT_H
                                    193 	.globl _ADC_DAT_L
                                    194 	.globl _ADC_DAT
                                    195 	.globl _ADC_CTRL
                                    196 	.globl _SPI1_CK_SE
                                    197 	.globl _SPI1_CTRL
                                    198 	.globl _SPI1_DATA
                                    199 	.globl _SPI1_STAT
                                    200 	.globl _SIF1
                                    201 	.globl _SBAUD1
                                    202 	.globl _SBUF1
                                    203 	.globl _SCON1
                                    204 	.globl _SPI0_SETUP
                                    205 	.globl _SPI0_CK_SE
                                    206 	.globl _SPI0_CTRL
                                    207 	.globl _SPI0_DATA
                                    208 	.globl _SPI0_STAT
                                    209 	.globl _T2CAP1H
                                    210 	.globl _T2CAP1L
                                    211 	.globl _T2CAP1
                                    212 	.globl _TH2
                                    213 	.globl _TL2
                                    214 	.globl _T2COUNT
                                    215 	.globl _RCAP2H
                                    216 	.globl _RCAP2L
                                    217 	.globl _RCAP2
                                    218 	.globl _T2MOD
                                    219 	.globl _T2CON
                                    220 	.globl _SBUF
                                    221 	.globl _SCON
                                    222 	.globl _TH1
                                    223 	.globl _TH0
                                    224 	.globl _TL1
                                    225 	.globl _TL0
                                    226 	.globl _TMOD
                                    227 	.globl _TCON
                                    228 	.globl _XBUS_AUX
                                    229 	.globl _P7
                                    230 	.globl _P6_DIR
                                    231 	.globl _P6_OUT_PU
                                    232 	.globl _P6_IN
                                    233 	.globl _P5_DIR
                                    234 	.globl _P5_OUT_PU
                                    235 	.globl _P5_IN
                                    236 	.globl _P4_LED_KEY
                                    237 	.globl _P4_DIR_PU
                                    238 	.globl _P4_MOD_OC
                                    239 	.globl _P4
                                    240 	.globl _P3_DIR_PU
                                    241 	.globl _P3_MOD_OC
                                    242 	.globl _P3
                                    243 	.globl _P2_DIR_PU
                                    244 	.globl _P2_MOD_OC
                                    245 	.globl _P2
                                    246 	.globl _P1_DIR_PU
                                    247 	.globl _P1_MOD_OC
                                    248 	.globl _P1
                                    249 	.globl _P0_DIR_PU
                                    250 	.globl _P0_MOD_OC
                                    251 	.globl _P0
                                    252 	.globl _ROM_CTRL
                                    253 	.globl _ROM_DATA_HH
                                    254 	.globl _ROM_DATA_HL
                                    255 	.globl _ROM_DATA_HI
                                    256 	.globl _ROM_ADDR_H
                                    257 	.globl _ROM_ADDR_L
                                    258 	.globl _ROM_ADDR
                                    259 	.globl _GPIO_IE
                                    260 	.globl _IP_EX
                                    261 	.globl _IE_EX
                                    262 	.globl _IP
                                    263 	.globl _IE
                                    264 	.globl _WDOG_COUNT
                                    265 	.globl _RESET_KEEP
                                    266 	.globl _WAKE_CTRL
                                    267 	.globl _CLOCK_CFG
                                    268 	.globl _POWER_CFG
                                    269 	.globl _PCON
                                    270 	.globl _GLOBAL_CFG
                                    271 	.globl _SAFE_MOD
                                    272 	.globl _DPH
                                    273 	.globl _DPL
                                    274 	.globl _SP
                                    275 	.globl _A_INV
                                    276 	.globl _B
                                    277 	.globl _ACC
                                    278 	.globl _PSW
                                    279 	.globl _process_record_quantum_helper_PARM_2
                                    280 	.globl _get_record_keycode_PARM_2
                                    281 	.globl _post_process_record_user_PARM_2
                                    282 	.globl _post_process_record_kb_PARM_2
                                    283 	.globl _process_record_user_PARM_2
                                    284 	.globl _process_record_kb_PARM_2
                                    285 	.globl _pre_process_record_user_PARM_2
                                    286 	.globl _pre_process_record_kb_PARM_2
                                    287 	.globl _register_code16
                                    288 	.globl _unregister_code16
                                    289 	.globl _pre_process_record_kb
                                    290 	.globl _pre_process_record_user
                                    291 	.globl _process_action_kb
                                    292 	.globl _process_record_kb
                                    293 	.globl _process_record_user
                                    294 	.globl _post_process_record_kb
                                    295 	.globl _post_process_record_user
                                    296 	.globl _reset_keyboard
                                    297 	.globl _soft_reset_keyboard
                                    298 	.globl _get_record_keycode
                                    299 	.globl _pre_process_record_quantum
                                    300 	.globl _post_process_record_quantum
                                    301 	.globl _process_record_quantum
                                    302 	.globl _process_record_quantum_helper
                                    303 	.globl _shutdown_user
                                    304 ;--------------------------------------------------------
                                    305 ; special function registers
                                    306 ;--------------------------------------------------------
                                    307 	.area RSEG    (ABS,DATA)
      000000                        308 	.org 0x0000
                           0000D0   309 _PSW	=	0x00d0
                           0000E0   310 _ACC	=	0x00e0
                           0000F0   311 _B	=	0x00f0
                           0000FD   312 _A_INV	=	0x00fd
                           000081   313 _SP	=	0x0081
                           000082   314 _DPL	=	0x0082
                           000083   315 _DPH	=	0x0083
                           0000A1   316 _SAFE_MOD	=	0x00a1
                           0000B1   317 _GLOBAL_CFG	=	0x00b1
                           000087   318 _PCON	=	0x0087
                           0000BA   319 _POWER_CFG	=	0x00ba
                           0000B9   320 _CLOCK_CFG	=	0x00b9
                           0000A9   321 _WAKE_CTRL	=	0x00a9
                           0000FE   322 _RESET_KEEP	=	0x00fe
                           0000FF   323 _WDOG_COUNT	=	0x00ff
                           0000A8   324 _IE	=	0x00a8
                           0000B8   325 _IP	=	0x00b8
                           0000E8   326 _IE_EX	=	0x00e8
                           0000E9   327 _IP_EX	=	0x00e9
                           0000B2   328 _GPIO_IE	=	0x00b2
                           008584   329 _ROM_ADDR	=	0x8584
                           000084   330 _ROM_ADDR_L	=	0x0084
                           000085   331 _ROM_ADDR_H	=	0x0085
                           008F8E   332 _ROM_DATA_HI	=	0x8f8e
                           00008E   333 _ROM_DATA_HL	=	0x008e
                           00008F   334 _ROM_DATA_HH	=	0x008f
                           000086   335 _ROM_CTRL	=	0x0086
                           000080   336 _P0	=	0x0080
                           0000C4   337 _P0_MOD_OC	=	0x00c4
                           0000C5   338 _P0_DIR_PU	=	0x00c5
                           000090   339 _P1	=	0x0090
                           000092   340 _P1_MOD_OC	=	0x0092
                           000093   341 _P1_DIR_PU	=	0x0093
                           0000A0   342 _P2	=	0x00a0
                           000094   343 _P2_MOD_OC	=	0x0094
                           000095   344 _P2_DIR_PU	=	0x0095
                           0000B0   345 _P3	=	0x00b0
                           000096   346 _P3_MOD_OC	=	0x0096
                           000097   347 _P3_DIR_PU	=	0x0097
                           0000C0   348 _P4	=	0x00c0
                           0000C2   349 _P4_MOD_OC	=	0x00c2
                           0000C3   350 _P4_DIR_PU	=	0x00c3
                           0000C1   351 _P4_LED_KEY	=	0x00c1
                           0000AA   352 _P5_IN	=	0x00aa
                           0000AB   353 _P5_OUT_PU	=	0x00ab
                           0000AC   354 _P5_DIR	=	0x00ac
                           0000AD   355 _P6_IN	=	0x00ad
                           0000AE   356 _P6_OUT_PU	=	0x00ae
                           0000AF   357 _P6_DIR	=	0x00af
                           0000F1   358 _P7	=	0x00f1
                           0000A2   359 _XBUS_AUX	=	0x00a2
                           000088   360 _TCON	=	0x0088
                           000089   361 _TMOD	=	0x0089
                           00008A   362 _TL0	=	0x008a
                           00008B   363 _TL1	=	0x008b
                           00008C   364 _TH0	=	0x008c
                           00008D   365 _TH1	=	0x008d
                           000098   366 _SCON	=	0x0098
                           000099   367 _SBUF	=	0x0099
                           0000C8   368 _T2CON	=	0x00c8
                           0000C9   369 _T2MOD	=	0x00c9
                           00CBCA   370 _RCAP2	=	0xcbca
                           0000CA   371 _RCAP2L	=	0x00ca
                           0000CB   372 _RCAP2H	=	0x00cb
                           00CDCC   373 _T2COUNT	=	0xcdcc
                           0000CC   374 _TL2	=	0x00cc
                           0000CD   375 _TH2	=	0x00cd
                           00CFCE   376 _T2CAP1	=	0xcfce
                           0000CE   377 _T2CAP1L	=	0x00ce
                           0000CF   378 _T2CAP1H	=	0x00cf
                           0000F8   379 _SPI0_STAT	=	0x00f8
                           0000F9   380 _SPI0_DATA	=	0x00f9
                           0000FA   381 _SPI0_CTRL	=	0x00fa
                           0000FB   382 _SPI0_CK_SE	=	0x00fb
                           0000FC   383 _SPI0_SETUP	=	0x00fc
                           0000BC   384 _SCON1	=	0x00bc
                           0000BD   385 _SBUF1	=	0x00bd
                           0000BE   386 _SBAUD1	=	0x00be
                           0000BF   387 _SIF1	=	0x00bf
                           0000B4   388 _SPI1_STAT	=	0x00b4
                           0000B5   389 _SPI1_DATA	=	0x00b5
                           0000B6   390 _SPI1_CTRL	=	0x00b6
                           0000B7   391 _SPI1_CK_SE	=	0x00b7
                           0000F3   392 _ADC_CTRL	=	0x00f3
                           00F5F4   393 _ADC_DAT	=	0xf5f4
                           0000F4   394 _ADC_DAT_L	=	0x00f4
                           0000F5   395 _ADC_DAT_H	=	0x00f5
                           0000F6   396 _ADC_CHAN	=	0x00f6
                           0000A6   397 _LED_COMMON	=	0x00a6
                           0000A7   398 _LED_PWM_OE	=	0x00a7
                           00C7C6   399 _LED_DMA	=	0xc7c6
                           0000C6   400 _LED_DMA_L	=	0x00c6
                           0000C7   401 _LED_DMA_H	=	0x00c7
                           0000F7   402 _LED_STATUS	=	0x00f7
                           0000B3   403 _I2CX_INT	=	0x00b3
                           0000BB   404 _I2CS_INT_ST	=	0x00bb
                                    405 ;--------------------------------------------------------
                                    406 ; special function bits
                                    407 ;--------------------------------------------------------
                                    408 	.area RSEG    (ABS,DATA)
      000000                        409 	.org 0x0000
                           0000D7   410 _CY	=	0x00d7
                           0000D6   411 _AC	=	0x00d6
                           0000D5   412 _F0	=	0x00d5
                           0000D4   413 _RS1	=	0x00d4
                           0000D3   414 _RS0	=	0x00d3
                           0000D2   415 _OV	=	0x00d2
                           0000D1   416 _F1	=	0x00d1
                           0000D0   417 _P	=	0x00d0
                           0000AF   418 _EA	=	0x00af
                           0000AE   419 _E_DIS	=	0x00ae
                           0000AD   420 _ET2	=	0x00ad
                           0000AC   421 _ES	=	0x00ac
                           0000AB   422 _ET1	=	0x00ab
                           0000AA   423 _EX1	=	0x00aa
                           0000A9   424 _ET0	=	0x00a9
                           0000A8   425 _EX0	=	0x00a8
                           0000BF   426 _PH_FLAG	=	0x00bf
                           0000BE   427 _PL_FLAG	=	0x00be
                           0000BD   428 _PT2	=	0x00bd
                           0000BC   429 _PS	=	0x00bc
                           0000BB   430 _PT1	=	0x00bb
                           0000BA   431 _PX1	=	0x00ba
                           0000B9   432 _PT0	=	0x00b9
                           0000B8   433 _PX0	=	0x00b8
                           0000EF   434 _IE_WDOG	=	0x00ef
                           0000EE   435 _IE_GPIO	=	0x00ee
                           0000ED   436 _IE_PWM_I2C	=	0x00ed
                           0000EC   437 _IE_UART1	=	0x00ec
                           0000EB   438 _IE_ADC	=	0x00eb
                           0000E9   439 _IE_USB	=	0x00e9
                           0000E8   440 _IE_SPI0	=	0x00e8
                           000087   441 _P0_7	=	0x0087
                           000086   442 _P0_6	=	0x0086
                           000085   443 _P0_5	=	0x0085
                           000084   444 _P0_4	=	0x0084
                           000083   445 _P0_3	=	0x0083
                           000082   446 _P0_2	=	0x0082
                           000081   447 _P0_1	=	0x0081
                           000080   448 _P0_0	=	0x0080
                           000081   449 _SDA0	=	0x0081
                           000080   450 _SCL0	=	0x0080
                           000083   451 _TXD_	=	0x0083
                           000082   452 _RXD_	=	0x0082
                           000085   453 _AIN13	=	0x0085
                           000084   454 _AIN12	=	0x0084
                           000083   455 _AIN11	=	0x0083
                           000082   456 _AIN10	=	0x0082
                           000081   457 _AIN9	=	0x0081
                           000080   458 _AIN8	=	0x0080
                           000097   459 _P1_7	=	0x0097
                           000096   460 _P1_6	=	0x0096
                           000095   461 _P1_5	=	0x0095
                           000094   462 _P1_4	=	0x0094
                           000093   463 _P1_3	=	0x0093
                           000092   464 _P1_2	=	0x0092
                           000091   465 _P1_1	=	0x0091
                           000090   466 _P1_0	=	0x0090
                           000097   467 _TXD1_	=	0x0097
                           000096   468 _RXD1_	=	0x0096
                           000097   469 _SCK	=	0x0097
                           000096   470 _MISO	=	0x0096
                           000095   471 _MOSI	=	0x0095
                           000094   472 _SCS	=	0x0094
                           000092   473 _INT0_	=	0x0092
                           000091   474 _T2EX	=	0x0091
                           000091   475 _CAP2	=	0x0091
                           000090   476 _T2	=	0x0090
                           000090   477 _CAP1	=	0x0090
                           000097   478 _AIN7	=	0x0097
                           000096   479 _AIN6	=	0x0096
                           000095   480 _AIN5	=	0x0095
                           000094   481 _AIN4	=	0x0094
                           000093   482 _AIN3	=	0x0093
                           000092   483 _AIN2	=	0x0092
                           000091   484 _AIN1	=	0x0091
                           000090   485 _AIN0	=	0x0090
                           0000A7   486 _P2_7	=	0x00a7
                           0000A6   487 _P2_6	=	0x00a6
                           0000A5   488 _P2_5	=	0x00a5
                           0000A4   489 _P2_4	=	0x00a4
                           0000A3   490 _P2_3	=	0x00a3
                           0000A2   491 _P2_2	=	0x00a2
                           0000A1   492 _P2_1	=	0x00a1
                           0000A0   493 _P2_0	=	0x00a0
                           0000A7   494 _TXD1	=	0x00a7
                           0000A6   495 _RXD1	=	0x00a6
                           0000A5   496 _T2EX_	=	0x00a5
                           0000A5   497 _CAP2_	=	0x00a5
                           0000A4   498 _T2_	=	0x00a4
                           0000A4   499 _CAP1_	=	0x00a4
                           0000B7   500 _P3_7	=	0x00b7
                           0000B6   501 _P3_6	=	0x00b6
                           0000B5   502 _P3_5	=	0x00b5
                           0000B4   503 _P3_4	=	0x00b4
                           0000B3   504 _P3_3	=	0x00b3
                           0000B2   505 _P3_2	=	0x00b2
                           0000B1   506 _P3_1	=	0x00b1
                           0000B0   507 _P3_0	=	0x00b0
                           0000B7   508 _SCK1	=	0x00b7
                           0000B6   509 _MISO1	=	0x00b6
                           0000B5   510 _MOSI1	=	0x00b5
                           0000B5   511 _T1	=	0x00b5
                           0000B4   512 _T0	=	0x00b4
                           0000B3   513 _INT1	=	0x00b3
                           0000B2   514 _INT0	=	0x00b2
                           0000B1   515 _TXD	=	0x00b1
                           0000B0   516 _RXD	=	0x00b0
                           0000C6   517 _P4_6	=	0x00c6
                           0000C5   518 _P4_5	=	0x00c5
                           0000C4   519 _P4_4	=	0x00c4
                           0000C3   520 _P4_3	=	0x00c3
                           0000C2   521 _P4_2	=	0x00c2
                           0000C1   522 _P4_1	=	0x00c1
                           0000C0   523 _P4_0	=	0x00c0
                           00008F   524 _TF1	=	0x008f
                           00008E   525 _TR1	=	0x008e
                           00008D   526 _TF0	=	0x008d
                           00008C   527 _TR0	=	0x008c
                           00008B   528 _IE1	=	0x008b
                           00008A   529 _IT1	=	0x008a
                           000089   530 _IE0	=	0x0089
                           000088   531 _IT0	=	0x0088
                           00009F   532 _SM0	=	0x009f
                           00009E   533 _SM1	=	0x009e
                           00009D   534 _SM2	=	0x009d
                           00009C   535 _REN	=	0x009c
                           00009B   536 _TB8	=	0x009b
                           00009A   537 _RB8	=	0x009a
                           000099   538 _TI	=	0x0099
                           000098   539 _RI	=	0x0098
                           0000CF   540 _TF2	=	0x00cf
                           0000CF   541 _CAP1F	=	0x00cf
                           0000CE   542 _EXF2	=	0x00ce
                           0000CD   543 _RCLK	=	0x00cd
                           0000CC   544 _TCLK	=	0x00cc
                           0000CB   545 _EXEN2	=	0x00cb
                           0000CA   546 _TR2	=	0x00ca
                           0000C9   547 _C_T2	=	0x00c9
                           0000C8   548 _CP_RL2	=	0x00c8
                           0000FF   549 _S0_FST_ACT	=	0x00ff
                           0000FE   550 _S0_IF_OV	=	0x00fe
                           0000FD   551 _S0_IF_FIRST	=	0x00fd
                           0000FC   552 _S0_IF_BYTE	=	0x00fc
                           0000FB   553 _S0_FREE	=	0x00fb
                           0000FA   554 _S0_T_FIFO	=	0x00fa
                           0000F8   555 _S0_R_FIFO	=	0x00f8
                           0000F7   556 _ADC_START	=	0x00f7
                                    557 ;--------------------------------------------------------
                                    558 ; overlayable register banks
                                    559 ;--------------------------------------------------------
                                    560 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        561 	.ds 8
                                    562 ;--------------------------------------------------------
                                    563 ; internal ram data
                                    564 ;--------------------------------------------------------
                                    565 	.area DSEG    (DATA)
                                    566 ;--------------------------------------------------------
                                    567 ; overlayable items in internal ram
                                    568 ;--------------------------------------------------------
                                    569 ;--------------------------------------------------------
                                    570 ; indirectly addressable internal ram data
                                    571 ;--------------------------------------------------------
                                    572 	.area ISEG    (DATA)
                                    573 ;--------------------------------------------------------
                                    574 ; absolute internal ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area IABS    (ABS,DATA)
                                    577 	.area IABS    (ABS,DATA)
                                    578 ;--------------------------------------------------------
                                    579 ; bit data
                                    580 ;--------------------------------------------------------
                                    581 	.area BSEG    (BIT)
      000026                        582 _get_record_keycode_sloc0_1_0:
      000026                        583 	.ds 1
      000027                        584 _pre_process_record_quantum_sloc0_1_0:
      000027                        585 	.ds 1
      000028                        586 _process_ak820_nkro_sloc0_1_0:
      000028                        587 	.ds 1
                                    588 ;--------------------------------------------------------
                                    589 ; paged external ram data
                                    590 ;--------------------------------------------------------
                                    591 	.area PSEG    (PAG,XDATA)
                                    592 ;--------------------------------------------------------
                                    593 ; uninitialized external ram data
                                    594 ;--------------------------------------------------------
                                    595 	.area XSEG    (XDATA)
      000BE6                        596 _extract_mod_bits_code_10000_599:
      000BE6                        597 	.ds 2
      000BE8                        598 _register_code16_code_10000_605:
      000BE8                        599 	.ds 2
      000BEA                        600 _unregister_code16_code_10000_610:
      000BEA                        601 	.ds 2
      000BEC                        602 _pre_process_record_kb_PARM_2:
      000BEC                        603 	.ds 3
      000BEF                        604 _pre_process_record_kb_keycode_10000_624:
      000BEF                        605 	.ds 2
      000BF1                        606 _pre_process_record_user_PARM_2:
      000BF1                        607 	.ds 3
      000BF4                        608 _process_record_kb_PARM_2:
      000BF4                        609 	.ds 3
      000BF7                        610 _process_record_kb_keycode_10000_630:
      000BF7                        611 	.ds 2
      000BF9                        612 _process_record_user_PARM_2:
      000BF9                        613 	.ds 3
      000BFC                        614 _post_process_record_kb_PARM_2:
      000BFC                        615 	.ds 3
      000BFF                        616 _post_process_record_kb_keycode_10000_634:
      000BFF                        617 	.ds 2
      000C01                        618 _post_process_record_user_PARM_2:
      000C01                        619 	.ds 3
      000C04                        620 _get_record_keycode_PARM_2:
      000C04                        621 	.ds 1
      000C05                        622 _get_record_keycode_record_argument_10000_648:
      000C05                        623 	.ds 3
      000C08                        624 _pre_process_record_quantum_record_argument_10000_654:
      000C08                        625 	.ds 3
      000C0B                        626 _post_process_record_quantum_record_10000_656:
      000C0B                        627 	.ds 3
      000C0E                        628 _process_record_quantum_record_10000_658:
      000C0E                        629 	.ds 3
      000C11                        630 _process_ak820_nkro_PARM_2:
      000C11                        631 	.ds 3
      000C14                        632 _process_ak820_nkro_keycode_10000_660:
      000C14                        633 	.ds 2
      000C16                        634 _process_record_quantum_helper_PARM_2:
      000C16                        635 	.ds 3
      000C19                        636 _process_record_quantum_helper_keycode_10000_665:
      000C19                        637 	.ds 2
      000C1B                        638 _get_u8_str_last_num_10000_691:
      000C1B                        639 	.ds 1
      000C1C                        640 _get_u16_str_last_num_10000_695:
      000C1C                        641 	.ds 2
                                    642 ;--------------------------------------------------------
                                    643 ; absolute external ram data
                                    644 ;--------------------------------------------------------
                                    645 	.area XABS    (ABS,XDATA)
                                    646 ;--------------------------------------------------------
                                    647 ; initialized external ram data
                                    648 ;--------------------------------------------------------
                                    649 	.area XISEG   (XDATA)
                                    650 	.area HOME    (CODE)
                                    651 	.area GSINIT0 (CODE)
                                    652 	.area GSINIT1 (CODE)
                                    653 	.area GSINIT2 (CODE)
                                    654 	.area GSINIT3 (CODE)
                                    655 	.area GSINIT4 (CODE)
                                    656 	.area GSINIT5 (CODE)
                                    657 	.area GSINIT  (CODE)
                                    658 	.area GSFINAL (CODE)
                                    659 	.area CSEG    (CODE)
                                    660 ;--------------------------------------------------------
                                    661 ; global & static initialisations
                                    662 ;--------------------------------------------------------
                                    663 	.area HOME    (CODE)
                                    664 	.area GSINIT  (CODE)
                                    665 	.area GSFINAL (CODE)
                                    666 	.area GSINIT  (CODE)
                                    667 ;------------------------------------------------------------
                                    668 ;Allocation info for local variables in function 'get_u8_str'
                                    669 ;------------------------------------------------------------
                                    670 ;curr_pad      Allocated with name '_get_u8_str_PARM_2'
                                    671 ;curr_num      Allocated with name '_get_u8_str_curr_num_10000_690'
                                    672 ;buf           Allocated with name '_get_u8_str_buf_10000_691'
                                    673 ;last_num      Allocated with name '_get_u8_str_last_num_10000_691'
                                    674 ;last_pad      Allocated with name '_get_u8_str_last_pad_10000_691'
                                    675 ;------------------------------------------------------------
                                    676 ;	quantum/quantum.c:750: static uint8_t last_num = 0xFF;
      0030F3 90 0C 1B         [24]  677 	mov	dptr,#_get_u8_str_last_num_10000_691
      0030F6 74 FF            [12]  678 	mov	a,#0xff
      0030F8 F0               [24]  679 	movx	@dptr,a
                                    680 ;------------------------------------------------------------
                                    681 ;Allocation info for local variables in function 'get_u16_str'
                                    682 ;------------------------------------------------------------
                                    683 ;curr_pad      Allocated with name '_get_u16_str_PARM_2'
                                    684 ;curr_num      Allocated with name '_get_u16_str_curr_num_10000_694'
                                    685 ;buf           Allocated with name '_get_u16_str_buf_10000_695'
                                    686 ;last_num      Allocated with name '_get_u16_str_last_num_10000_695'
                                    687 ;last_pad      Allocated with name '_get_u16_str_last_pad_10000_695'
                                    688 ;------------------------------------------------------------
                                    689 ;	quantum/quantum.c:770: static uint16_t last_num = 0xFF;
      0030F9 90 0C 1C         [24]  690 	mov	dptr,#_get_u16_str_last_num_10000_695
      0030FC 74 FF            [12]  691 	mov	a,#0xff
      0030FE F0               [24]  692 	movx	@dptr,a
      0030FF E4               [12]  693 	clr	a
      003100 A3               [24]  694 	inc	dptr
      003101 F0               [24]  695 	movx	@dptr,a
                                    696 ;--------------------------------------------------------
                                    697 ; Home
                                    698 ;--------------------------------------------------------
                                    699 	.area HOME    (CODE)
                                    700 	.area HOME    (CODE)
                                    701 ;--------------------------------------------------------
                                    702 ; code
                                    703 ;--------------------------------------------------------
                                    704 	.area CSEG    (CODE)
                                    705 ;------------------------------------------------------------
                                    706 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    707 ;------------------------------------------------------------
                                    708 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_193'
                                    709 ;------------------------------------------------------------
                                    710 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    711 ;	-----------------------------------------
                           000007   712 	ar7 = 0x07
                           000006   713 	ar6 = 0x06
                           000005   714 	ar5 = 0x05
                           000004   715 	ar4 = 0x04
                           000003   716 	ar3 = 0x03
                           000002   717 	ar2 = 0x02
                           000001   718 	ar1 = 0x01
                           000000   719 	ar0 = 0x00
                                    720 ;	 function extract_mod_bits
                                    721 ;	-----------------------------------------
      009F18                        722 _extract_mod_bits:
      009F18 12 3A CD         [24]  723 	lcall	_ak820_outline_0107
      009F1B 90 0B E6         [24]  724 	mov	dptr,#_extract_mod_bits_code_10000_599
      009F1E 12 3A D2         [24]  725 	lcall	_ak820_outline_0108
                                    726 ;	quantum/quantum.c:107: uint8_t mods = (uint8_t)(code >> 8);
      009F21 90 0B E6         [24]  727 	mov	dptr,#_extract_mod_bits_code_10000_599
      009F24 E0               [24]  728 	movx	a,@dptr
      009F25 A3               [24]  729 	inc	dptr
      009F26 E0               [24]  730 	movx	a,@dptr
                                    731 ;	quantum/quantum.c:108: if (!mods || mods > (QK_MODS_MAX >> 8)) return 0;
      009F27 FF               [12]  732 	mov	r7,a
      009F28 60 05            [24]  733 	jz	00101$
      009F2A EF               [12]  734 	mov	a,r7
      009F2B 24 E0            [12]  735 	add	a,#0xff - 0x1f
      009F2D 50 04            [24]  736 	jnc	00102$
                                    737 ;	free result
      009F2F                        738 00101$:
      009F2F 75 82 00         [24]  739 	mov	dpl, #0x00
      009F32 22               [24]  740 	ret
      009F33                        741 00102$:
                                    742 ;	quantum/quantum.c:109: return (mods & 0x10) ? (uint8_t)(mods << 4) : mods;
      009F33 EF               [12]  743 	mov	a,r7
      009F34 30 E4 07         [24]  744 	jnb	acc.4,00106$
      009F37 EF               [12]  745 	mov	a,r7
      009F38 C4               [12]  746 	swap	a
      009F39 54 F0            [12]  747 	anl	a,#0xf0
      009F3B FE               [12]  748 	mov	r6,a
      009F3C 80 02            [24]  749 	sjmp	00107$
      009F3E                        750 00106$:
      009F3E 8F 06            [24]  751 	mov	ar6,r7
      009F40                        752 00107$:
      009F40 8E 82            [24]  753 	mov	dpl, r6
                                    754 ;	quantum/quantum.c:137: }
      009F42 22               [24]  755 	ret
                                    756 ;------------------------------------------------------------
                                    757 ;Allocation info for local variables in function 'do_code16'
                                    758 ;------------------------------------------------------------
                                    759 ;f             Allocated with name '_do_code16_PARM_2'
                                    760 ;code          Allocated with name '_do_code16_code_10000_602'
                                    761 ;------------------------------------------------------------
                                    762 ;	quantum/quantum.c:139: void do_code16(uint16_t code, void (*f)(uint8_t)) {
                                    763 ;	-----------------------------------------
                                    764 ;	 function register_code16
                                    765 ;	-----------------------------------------
      009F43                        766 _register_code16:
      009F43 12 3A CD         [24]  767 	lcall	_ak820_outline_0107
      009F46 90 0B E8         [24]  768 	mov	dptr,#_register_code16_code_10000_605
      009F49 12 3A D2         [24]  769 	lcall	_ak820_outline_0108
                                    770 ;	quantum/quantum.c:145: uint8_t mods = extract_mod_bits(code);
      009F4C 90 0B E8         [24]  771 	mov	dptr,#_register_code16_code_10000_605
      009F4F 12 3A 3F         [24]  772 	lcall	_ak820_outline_0005
      009F52 C0 07            [24]  773 	push	ar7
      009F54 C0 06            [24]  774 	push	ar6
      009F56 12 9F 18         [24]  775 	lcall	_extract_mod_bits
      009F59 AD 82            [24]  776 	mov	r5, dpl
      009F5B D0 06            [24]  777 	pop	ar6
      009F5D D0 07            [24]  778 	pop	ar7
                                    779 ;	quantum/quantum.c:146: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009F5F 12 9D 51         [24]  780 	lcall	_ak820_outline_0119
      009F62 40 07            [24]  781 	jc	00105$
      009F64 74 E7            [12]  782 	mov	a,#0xe7
      009F66 9E               [12]  783 	subb	a,r6
      009F67 E4               [12]  784 	clr	a
      009F68 9F               [12]  785 	subb	a,r7
      009F69 50 08            [24]  786 	jnc	00101$
                                    787 ;	free result
      009F6B                        788 00105$:
      009F6B 90 0B E8         [24]  789 	mov	dptr,#_register_code16_code_10000_605
      009F6E 12 6F 9C         [24]  790 	lcall	_ak820_outline_0040
      009F71 70 07            [24]  791 	jnz	00102$
      009F73                        792 00101$:
                                    793 ;	quantum/quantum.c:147: register_mods(mods);
      009F73 8D 82            [24]  794 	mov	dpl, r5
      009F75 12 78 5A         [24]  795 	lcall	_register_mods
      009F78 80 05            [24]  796 	sjmp	00103$
      009F7A                        797 00102$:
                                    798 ;	quantum/quantum.c:149: register_weak_mods(mods);
      009F7A 8D 82            [24]  799 	mov	dpl, r5
      009F7C 12 78 82         [24]  800 	lcall	_register_weak_mods
      009F7F                        801 00103$:
                                    802 ;	quantum/quantum.c:151: register_code(code);
      009F7F 90 0B E8         [24]  803 	mov	dptr,#_register_code16_code_10000_605
      009F82 E0               [24]  804 	movx	a,@dptr
      009F83 F5 82            [12]  805 	mov	dpl,a
                                    806 ;	quantum/quantum.c:161: }
      009F85 02 77 37         [24]  807 	ljmp	_register_code
                                    808 ;------------------------------------------------------------
                                    809 ;Allocation info for local variables in function 'unregister_code16'
                                    810 ;------------------------------------------------------------
                                    811 ;code          Allocated with name '_unregister_code16_code_10000_610'
                                    812 ;mods          Allocated with name '_unregister_code16_mods_10000_611'
                                    813 ;------------------------------------------------------------
                                    814 ;	quantum/quantum.c:163: __attribute__((weak)) void unregister_code16(uint16_t code) {
                                    815 ;	-----------------------------------------
                                    816 ;	 function unregister_code16
                                    817 ;	-----------------------------------------
      009F88                        818 _unregister_code16:
      009F88 12 3A CD         [24]  819 	lcall	_ak820_outline_0107
      009F8B 90 0B EA         [24]  820 	mov	dptr,#_unregister_code16_code_10000_610
      009F8E 12 3A D2         [24]  821 	lcall	_ak820_outline_0108
                                    822 ;	quantum/quantum.c:165: uint8_t mods = extract_mod_bits(code);
      009F91 90 0B EA         [24]  823 	mov	dptr,#_unregister_code16_code_10000_610
      009F94 12 3A 3F         [24]  824 	lcall	_ak820_outline_0005
      009F97 C0 07            [24]  825 	push	ar7
      009F99 C0 06            [24]  826 	push	ar6
      009F9B 12 9F 18         [24]  827 	lcall	_extract_mod_bits
      009F9E AD 82            [24]  828 	mov	r5, dpl
      009FA0 D0 06            [24]  829 	pop	ar6
                                    830 ;	quantum/quantum.c:166: unregister_code(code);
      009FA2 8E 04            [24]  831 	mov	ar4,r6
      009FA4 8C 82            [24]  832 	mov	dpl, r4
      009FA6 C0 06            [24]  833 	push	ar6
      009FA8 C0 05            [24]  834 	push	ar5
      009FAA 12 77 A4         [24]  835 	lcall	_unregister_code
      009FAD D0 05            [24]  836 	pop	ar5
      009FAF D0 06            [24]  837 	pop	ar6
      009FB1 D0 07            [24]  838 	pop	ar7
                                    839 ;	quantum/quantum.c:167: if (IS_MODIFIER_KEYCODE(code) || code == KC_NO) {
      009FB3 12 9D 51         [24]  840 	lcall	_ak820_outline_0119
      009FB6 40 07            [24]  841 	jc	00105$
      009FB8 74 E7            [12]  842 	mov	a,#0xe7
      009FBA 9E               [12]  843 	subb	a,r6
      009FBB E4               [12]  844 	clr	a
      009FBC 9F               [12]  845 	subb	a,r7
      009FBD 50 08            [24]  846 	jnc	00101$
                                    847 ;	free result
      009FBF                        848 00105$:
      009FBF 90 0B EA         [24]  849 	mov	dptr,#_unregister_code16_code_10000_610
      009FC2 12 6F 9C         [24]  850 	lcall	_ak820_outline_0040
      009FC5 70 05            [24]  851 	jnz	00102$
      009FC7                        852 00101$:
                                    853 ;	quantum/quantum.c:168: unregister_mods(mods);
      009FC7 8D 82            [24]  854 	mov	dpl, r5
      009FC9 02 78 6E         [24]  855 	ljmp	_unregister_mods
      009FCC                        856 00102$:
                                    857 ;	quantum/quantum.c:170: unregister_weak_mods(mods);
      009FCC 8D 82            [24]  858 	mov	dpl, r5
                                    859 ;	quantum/quantum.c:181: }
      009FCE 02 78 96         [24]  860 	ljmp	_unregister_weak_mods
                                    861 ;------------------------------------------------------------
                                    862 ;Allocation info for local variables in function 'tap_code16_delay'
                                    863 ;------------------------------------------------------------
                                    864 ;delay         Allocated with name '_tap_code16_delay_PARM_2'
                                    865 ;code          Allocated with name '_tap_code16_delay_code_10000_615'
                                    866 ;i             Allocated with name '_tap_code16_delay_i_20000_617'
                                    867 ;i             Allocated with name '_tap_code16_delay_i_50000_620'
                                    868 ;------------------------------------------------------------
                                    869 ;	quantum/quantum.c:188: __attribute__((weak)) void tap_code16_delay(uint16_t code, uint16_t delay) {
                                    870 ;	-----------------------------------------
                                    871 ;	 function pre_process_record_kb
                                    872 ;	-----------------------------------------
      009FD1                        873 _pre_process_record_kb:
      009FD1 12 3A CD         [24]  874 	lcall	_ak820_outline_0107
      009FD4 90 0B EF         [24]  875 	mov	dptr,#_pre_process_record_kb_keycode_10000_624
      009FD7 12 3A D2         [24]  876 	lcall	_ak820_outline_0108
                                    877 ;	quantum/quantum.c:205: return pre_process_record_user(keycode, record);
      009FDA 90 0B EF         [24]  878 	mov	dptr,#_pre_process_record_kb_keycode_10000_624
      009FDD 12 3A 8C         [24]  879 	lcall	_ak820_outline_0051
      009FE0 90 0B EC         [24]  880 	mov	dptr,#_pre_process_record_kb_PARM_2
      009FE3 12 9D 48         [24]  881 	lcall	_ak820_outline_0026
      009FE6 90 0B F1         [24]  882 	mov	dptr,#_pre_process_record_user_PARM_2
      009FE9 12 A3 33         [24]  883 	lcall	_ak820_outline_0010
                                    884 ;	quantum/quantum.c:206: }
      009FEC 02 9F EF         [24]  885 	ljmp	_pre_process_record_user
                                    886 ;------------------------------------------------------------
                                    887 ;Allocation info for local variables in function 'pre_process_record_user'
                                    888 ;------------------------------------------------------------
                                    889 ;record        Allocated with name '_pre_process_record_user_PARM_2'
                                    890 ;keycode       Allocated with name '_pre_process_record_user_keycode_10000_626'
                                    891 ;------------------------------------------------------------
                                    892 ;	quantum/quantum.c:208: __attribute__((weak)) bool pre_process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    893 ;	-----------------------------------------
                                    894 ;	 function pre_process_record_user
                                    895 ;	-----------------------------------------
      009FEF                        896 _pre_process_record_user:
                                    897 ;	quantum/quantum.c:209: return true;
      009FEF 75 82 01         [24]  898 	mov	dpl, #0x01
                                    899 ;	quantum/quantum.c:210: }
      009FF2 22               [24]  900 	ret
                                    901 ;------------------------------------------------------------
                                    902 ;Allocation info for local variables in function 'process_action_kb'
                                    903 ;------------------------------------------------------------
                                    904 ;record        Allocated with name '_process_action_kb_record_10000_628'
                                    905 ;------------------------------------------------------------
                                    906 ;	quantum/quantum.c:212: __attribute__((weak)) bool process_action_kb(keyrecord_t *record) {
                                    907 ;	-----------------------------------------
                                    908 ;	 function process_action_kb
                                    909 ;	-----------------------------------------
      009FF3                        910 _process_action_kb:
                                    911 ;	quantum/quantum.c:213: return true;
      009FF3 75 82 01         [24]  912 	mov	dpl, #0x01
                                    913 ;	quantum/quantum.c:214: }
      009FF6 22               [24]  914 	ret
                                    915 ;------------------------------------------------------------
                                    916 ;Allocation info for local variables in function 'process_record_kb'
                                    917 ;------------------------------------------------------------
                                    918 ;record        Allocated with name '_process_record_kb_PARM_2'
                                    919 ;keycode       Allocated with name '_process_record_kb_keycode_10000_630'
                                    920 ;------------------------------------------------------------
                                    921 ;	quantum/quantum.c:216: __attribute__((weak)) bool process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    922 ;	-----------------------------------------
                                    923 ;	 function process_record_kb
                                    924 ;	-----------------------------------------
      009FF7                        925 _process_record_kb:
      009FF7 12 3A CD         [24]  926 	lcall	_ak820_outline_0107
      009FFA 90 0B F7         [24]  927 	mov	dptr,#_process_record_kb_keycode_10000_630
      009FFD 12 3A D2         [24]  928 	lcall	_ak820_outline_0108
                                    929 ;	quantum/quantum.c:217: return process_record_user(keycode, record);
      00A000 90 0B F7         [24]  930 	mov	dptr,#_process_record_kb_keycode_10000_630
      00A003 12 3A 8C         [24]  931 	lcall	_ak820_outline_0051
      00A006 90 0B F4         [24]  932 	mov	dptr,#_process_record_kb_PARM_2
      00A009 12 9D 48         [24]  933 	lcall	_ak820_outline_0026
      00A00C 90 0B F9         [24]  934 	mov	dptr,#_process_record_user_PARM_2
      00A00F 12 A3 33         [24]  935 	lcall	_ak820_outline_0010
                                    936 ;	quantum/quantum.c:218: }
      00A012 02 A0 15         [24]  937 	ljmp	_process_record_user
                                    938 ;------------------------------------------------------------
                                    939 ;Allocation info for local variables in function 'process_record_user'
                                    940 ;------------------------------------------------------------
                                    941 ;record        Allocated with name '_process_record_user_PARM_2'
                                    942 ;keycode       Allocated with name '_process_record_user_keycode_10000_632'
                                    943 ;------------------------------------------------------------
                                    944 ;	quantum/quantum.c:220: __attribute__((weak)) bool process_record_user(uint16_t keycode, keyrecord_t *record) {
                                    945 ;	-----------------------------------------
                                    946 ;	 function process_record_user
                                    947 ;	-----------------------------------------
      00A015                        948 _process_record_user:
                                    949 ;	quantum/quantum.c:221: return true;
      00A015 75 82 01         [24]  950 	mov	dpl, #0x01
                                    951 ;	quantum/quantum.c:222: }
      00A018 22               [24]  952 	ret
                                    953 ;------------------------------------------------------------
                                    954 ;Allocation info for local variables in function 'post_process_record_kb'
                                    955 ;------------------------------------------------------------
                                    956 ;record        Allocated with name '_post_process_record_kb_PARM_2'
                                    957 ;keycode       Allocated with name '_post_process_record_kb_keycode_10000_634'
                                    958 ;------------------------------------------------------------
                                    959 ;	quantum/quantum.c:224: __attribute__((weak)) void post_process_record_kb(uint16_t keycode, keyrecord_t *record) {
                                    960 ;	-----------------------------------------
                                    961 ;	 function post_process_record_kb
                                    962 ;	-----------------------------------------
      00A019                        963 _post_process_record_kb:
      00A019 12 3A CD         [24]  964 	lcall	_ak820_outline_0107
      00A01C 90 0B FF         [24]  965 	mov	dptr,#_post_process_record_kb_keycode_10000_634
      00A01F 12 3A D2         [24]  966 	lcall	_ak820_outline_0108
                                    967 ;	quantum/quantum.c:225: post_process_record_user(keycode, record);
      00A022 90 0B FF         [24]  968 	mov	dptr,#_post_process_record_kb_keycode_10000_634
      00A025 12 3A 8C         [24]  969 	lcall	_ak820_outline_0051
      00A028 90 0B FC         [24]  970 	mov	dptr,#_post_process_record_kb_PARM_2
      00A02B 12 9D 48         [24]  971 	lcall	_ak820_outline_0026
      00A02E 90 0C 01         [24]  972 	mov	dptr,#_post_process_record_user_PARM_2
      00A031 12 A3 33         [24]  973 	lcall	_ak820_outline_0010
                                    974 ;	quantum/quantum.c:226: }
      00A034 02 A0 37         [24]  975 	ljmp	_post_process_record_user
                                    976 ;------------------------------------------------------------
                                    977 ;Allocation info for local variables in function 'post_process_record_user'
                                    978 ;------------------------------------------------------------
                                    979 ;record        Allocated with name '_post_process_record_user_PARM_2'
                                    980 ;keycode       Allocated with name '_post_process_record_user_keycode_10000_636'
                                    981 ;------------------------------------------------------------
                                    982 ;	quantum/quantum.c:228: __attribute__((weak)) void post_process_record_user(uint16_t keycode, keyrecord_t *record) {}
                                    983 ;	-----------------------------------------
                                    984 ;	 function post_process_record_user
                                    985 ;	-----------------------------------------
      00A037                        986 _post_process_record_user:
      00A037 22               [24]  987 	ret
                                    988 ;------------------------------------------------------------
                                    989 ;Allocation info for local variables in function 'shutdown_quantum'
                                    990 ;------------------------------------------------------------
                                    991 ;i             Allocated with name '_shutdown_quantum_i_30000_642'
                                    992 ;------------------------------------------------------------
                                    993 ;	quantum/quantum.c:230: void shutdown_quantum(void) {
                                    994 ;	-----------------------------------------
                                    995 ;	 function shutdown_quantum
                                    996 ;	-----------------------------------------
      00A038                        997 _shutdown_quantum:
                                    998 ;	quantum/quantum.c:231: clear_keyboard();
      00A038 12 78 AA         [24]  999 	lcall	_clear_keyboard
                                   1000 ;	quantum/quantum.c:246: shutdown_user();
      00A03B 12 A3 25         [24] 1001 	lcall	_shutdown_user
                                   1002 ;	quantum/quantum.c:247: wait_ms(250);
      00A03E 7F FA            [12] 1003 	mov	r7,#0xfa
      00A040                       1004 00106$:
      00A040 EF               [12] 1005 	mov	a,r7
      00A041 60 09            [24] 1006 	jz	00108$
      00A043 90 00 01         [24] 1007 	mov	dptr,#0x0001
      00A046 12 5B 08         [24] 1008 	lcall	_mDelaymS
      00A049 1F               [12] 1009 	dec	r7
      00A04A 80 F4            [24] 1010 	sjmp	00106$
      00A04C                       1011 00108$:
                                   1012 ;	quantum/quantum.c:252: }
      00A04C 22               [24] 1013 	ret
                                   1014 ;------------------------------------------------------------
                                   1015 ;Allocation info for local variables in function 'reset_keyboard'
                                   1016 ;------------------------------------------------------------
                                   1017 ;	quantum/quantum.c:254: void reset_keyboard(void) {
                                   1018 ;	-----------------------------------------
                                   1019 ;	 function reset_keyboard
                                   1020 ;	-----------------------------------------
      00A04D                       1021 _reset_keyboard:
                                   1022 ;	quantum/quantum.c:255: shutdown_quantum();
      00A04D 12 A0 38         [24] 1023 	lcall	_shutdown_quantum
                                   1024 ;	quantum/quantum.c:256: bootloader_jump();
                                   1025 ;	quantum/quantum.c:257: }
      00A050 02 36 59         [24] 1026 	ljmp	_bootloader_jump
                                   1027 ;------------------------------------------------------------
                                   1028 ;Allocation info for local variables in function 'soft_reset_keyboard'
                                   1029 ;------------------------------------------------------------
                                   1030 ;	quantum/quantum.c:259: void soft_reset_keyboard(void) {
                                   1031 ;	-----------------------------------------
                                   1032 ;	 function soft_reset_keyboard
                                   1033 ;	-----------------------------------------
      00A053                       1034 _soft_reset_keyboard:
                                   1035 ;	quantum/quantum.c:260: shutdown_quantum();
      00A053 12 A0 38         [24] 1036 	lcall	_shutdown_quantum
                                   1037 ;	quantum/quantum.c:261: mcu_reset();
                                   1038 ;	quantum/quantum.c:262: }
      00A056 02 36 4C         [24] 1039 	ljmp	_mcu_reset
                                   1040 ;------------------------------------------------------------
                                   1041 ;Allocation info for local variables in function 'get_record_keycode'
                                   1042 ;------------------------------------------------------------
                                   1043 ;update_layer_cache Allocated with name '_get_record_keycode_PARM_2'
                                   1044 ;record_argument Allocated with name '_get_record_keycode_record_argument_10000_648'
                                   1045 ;record        Allocated with name '_get_record_keycode_record_10000_649'
                                   1046 ;------------------------------------------------------------
                                   1047 ;	quantum/quantum.c:265: uint16_t get_record_keycode(keyrecord_t *record_argument, bool update_layer_cache) {
                                   1048 ;	-----------------------------------------
                                   1049 ;	 function get_record_keycode
                                   1050 ;	-----------------------------------------
      00A059                       1051 _get_record_keycode:
      00A059 12 45 5E         [24] 1052 	lcall	_ak820_outline_0037
      00A05C 90 0C 05         [24] 1053 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      00A05F 12 3A 74         [24] 1054 	lcall	_ak820_outline_0017
                                   1055 ;	quantum/quantum.c:267: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A062 90 0C 05         [24] 1056 	mov	dptr,#_get_record_keycode_record_argument_10000_648
      00A065 12 3A 49         [24] 1057 	lcall	_ak820_outline_0007
                                   1058 ;	quantum/quantum.c:272: if (record->keycode) {
      00A068 4C               [12] 1059 	orl	a,r4
      00A069 60 04            [24] 1060 	jz	00102$
                                   1061 ;	quantum/quantum.c:273: return record->keycode;
      00A06B 12 3A E2         [24] 1062 	lcall	_ak820_outline_0124
      00A06E 22               [24] 1063 	ret
      00A06F                       1064 00102$:
                                   1065 ;	quantum/quantum.c:277: return ak820_resolve_key(AK820_KEYPOS_VALUE(record->event.key), record->event.pressed && update_layer_cache);
      00A06F 12 79 0B         [24] 1066 	lcall	_ak820_outline_0021
      00A072 7A 00            [12] 1067 	mov	r2,#0x00
      00A074 12 45 B2         [24] 1068 	lcall	_ak820_outline_0142
      00A077 12 3A 5D         [24] 1069 	lcall	_ak820_outline_0009
      00A07A 60 06            [24] 1070 	jz	00105$
      00A07C 90 0C 04         [24] 1071 	mov	dptr,#_get_record_keycode_PARM_2
      00A07F E0               [24] 1072 	movx	a,@dptr
      00A080 70 04            [24] 1073 	jnz	00106$
      00A082                       1074 00105$:
                                   1075 ;	assignBit
      00A082 C2 26            [12] 1076 	clr	_get_record_keycode_sloc0_1_0
      00A084 80 02            [24] 1077 	sjmp	00107$
      00A086                       1078 00106$:
                                   1079 ;	assignBit
      00A086 D2 26            [12] 1080 	setb	_get_record_keycode_sloc0_1_0
      00A088                       1081 00107$:
      00A088 90 09 79         [24] 1082 	mov	dptr,#_ak820_resolve_key_PARM_2
      00A08B A2 26            [12] 1083 	mov	c,_get_record_keycode_sloc0_1_0
      00A08D E4               [12] 1084 	clr	a
      00A08E 33               [12] 1085 	rlc	a
      00A08F F0               [24] 1086 	movx	@dptr,a
      00A090 8D 82            [24] 1087 	mov	dpl, r5
      00A092 8C 83            [24] 1088 	mov	dph, r4
                                   1089 ;	quantum/quantum.c:281: }
      00A094 02 7C B2         [24] 1090 	ljmp	_ak820_resolve_key
                                   1091 ;------------------------------------------------------------
                                   1092 ;Allocation info for local variables in function 'get_event_keycode'
                                   1093 ;------------------------------------------------------------
                                   1094 ;event         Allocated with name '_get_event_keycode_PARM_1'
                                   1095 ;update_layer_cache Allocated with name '_get_event_keycode_update_layer_cache_10000_652'
                                   1096 ;------------------------------------------------------------
                                   1097 ;	quantum/quantum.c:289: uint16_t get_event_keycode(keyevent_t event, bool update_layer_cache) {
                                   1098 ;	-----------------------------------------
                                   1099 ;	 function pre_process_record_quantum
                                   1100 ;	-----------------------------------------
      00A097                       1101 _pre_process_record_quantum:
      00A097 12 45 5E         [24] 1102 	lcall	_ak820_outline_0037
      00A09A 90 0C 08         [24] 1103 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      00A09D 12 3A 74         [24] 1104 	lcall	_ak820_outline_0017
                                   1105 ;	quantum/quantum.c:322: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A0A0 90 0C 08         [24] 1106 	mov	dptr,#_pre_process_record_quantum_record_argument_10000_654
      00A0A3 12 3A 8C         [24] 1107 	lcall	_ak820_outline_0051
                                   1108 ;	quantum/quantum.c:326: uint16_t keycode = get_record_keycode(record, true);
      00A0A6 8E 03            [24] 1109 	mov	ar3,r6
      00A0A8 8F 04            [24] 1110 	mov	ar4,r7
      00A0AA 7D 00            [12] 1111 	mov	r5,#0x00
      00A0AC 90 0C 04         [24] 1112 	mov	dptr,#_get_record_keycode_PARM_2
      00A0AF 74 01            [12] 1113 	mov	a,#0x01
      00A0B1 F0               [24] 1114 	movx	@dptr,a
      00A0B2 12 36 47         [24] 1115 	lcall	_ak820_outline_0123
      00A0B5 8D F0            [24] 1116 	mov	b, r5
      00A0B7 C0 07            [24] 1117 	push	ar7
      00A0B9 C0 06            [24] 1118 	push	ar6
      00A0BB 12 A0 59         [24] 1119 	lcall	_get_record_keycode
      00A0BE 12 45 B8         [24] 1120 	lcall	_ak820_outline_0149
      00A0C1 D0 06            [24] 1121 	pop	ar6
      00A0C3 D0 07            [24] 1122 	pop	ar7
                                   1123 ;	quantum/quantum.c:328: record->keycode = keycode;
      00A0C5 74 07            [12] 1124 	mov	a,#0x07
      00A0C7 12 3A 7C         [24] 1125 	lcall	_ak820_outline_0022
      00A0CA 12 3A A9         [24] 1126 	lcall	_ak820_outline_0072
                                   1127 ;	quantum/quantum.c:338: return pre_process_record_kb(keycode, record) &&
      00A0CD 90 0B EC         [24] 1128 	mov	dptr,#_pre_process_record_kb_PARM_2
      00A0D0 12 A3 26         [24] 1129 	lcall	_ak820_outline_0002
      00A0D3 C0 07            [24] 1130 	push	ar7
      00A0D5 C0 06            [24] 1131 	push	ar6
      00A0D7 12 9F D1         [24] 1132 	lcall	_pre_process_record_kb
      00A0DA E5 82            [12] 1133 	mov	a, dpl
      00A0DC D0 06            [24] 1134 	pop	ar6
      00A0DE D0 07            [24] 1135 	pop	ar7
      00A0E0 60 0A            [24] 1136 	jz	00103$
                                   1137 ;	quantum/quantum.c:341: ak820_combo_process((keyrecord_t AK820_STATE_MEM *)record) &&
      00A0E2 12 3A D7         [24] 1138 	lcall	_ak820_outline_0118
      00A0E5 12 38 86         [24] 1139 	lcall	_ak820_combo_process
      00A0E8 E5 82            [12] 1140 	mov	a, dpl
      00A0EA 70 04            [24] 1141 	jnz	00104$
                                   1142 ;	quantum/quantum.c:346: true;
      00A0EC                       1143 00103$:
                                   1144 ;	assignBit
      00A0EC C2 27            [12] 1145 	clr	_pre_process_record_quantum_sloc0_1_0
      00A0EE 80 02            [24] 1146 	sjmp	00105$
      00A0F0                       1147 00104$:
                                   1148 ;	assignBit
      00A0F0 D2 27            [12] 1149 	setb	_pre_process_record_quantum_sloc0_1_0
      00A0F2                       1150 00105$:
      00A0F2 A2 27            [12] 1151 	mov	c,_pre_process_record_quantum_sloc0_1_0
      00A0F4 12 3A FC         [24] 1152 	lcall	_ak820_outline_0156
                                   1153 ;	quantum/quantum.c:347: }
      00A0F7 22               [24] 1154 	ret
                                   1155 ;------------------------------------------------------------
                                   1156 ;Allocation info for local variables in function 'post_process_record_quantum'
                                   1157 ;------------------------------------------------------------
                                   1158 ;record        Allocated with name '_post_process_record_quantum_record_10000_656'
                                   1159 ;keycode       Allocated with name '_post_process_record_quantum_keycode_10000_657'
                                   1160 ;------------------------------------------------------------
                                   1161 ;	quantum/quantum.c:350: void post_process_record_quantum(keyrecord_t *record) {
                                   1162 ;	-----------------------------------------
                                   1163 ;	 function post_process_record_quantum
                                   1164 ;	-----------------------------------------
      00A0F8                       1165 _post_process_record_quantum:
      00A0F8 12 45 5E         [24] 1166 	lcall	_ak820_outline_0037
      00A0FB 90 0C 0B         [24] 1167 	mov	dptr,#_post_process_record_quantum_record_10000_656
      00A0FE 12 3A 74         [24] 1168 	lcall	_ak820_outline_0017
                                   1169 ;	quantum/quantum.c:351: uint16_t keycode = get_record_keycode(record, false);
      00A101 90 0C 0B         [24] 1170 	mov	dptr,#_post_process_record_quantum_record_10000_656
      00A104 12 51 34         [24] 1171 	lcall	_ak820_outline_0012
      00A107 90 0C 04         [24] 1172 	mov	dptr,#_get_record_keycode_PARM_2
      00A10A E4               [12] 1173 	clr	a
      00A10B 12 51 3D         [24] 1174 	lcall	_ak820_outline_0034
      00A10E 12 A0 59         [24] 1175 	lcall	_get_record_keycode
      00A111 12 45 A7         [24] 1176 	lcall	_ak820_outline_0133
                                   1177 ;	quantum/quantum.c:352: post_process_record_kb(keycode, record);
      00A114 90 0C 0B         [24] 1178 	mov	dptr,#_post_process_record_quantum_record_10000_656
      00A117 12 9D 48         [24] 1179 	lcall	_ak820_outline_0026
      00A11A 90 0B FC         [24] 1180 	mov	dptr,#_post_process_record_kb_PARM_2
      00A11D 12 A3 33         [24] 1181 	lcall	_ak820_outline_0010
                                   1182 ;	quantum/quantum.c:353: }
      00A120 02 A0 19         [24] 1183 	ljmp	_post_process_record_kb
                                   1184 ;------------------------------------------------------------
                                   1185 ;Allocation info for local variables in function 'process_record_quantum'
                                   1186 ;------------------------------------------------------------
                                   1187 ;record        Allocated with name '_process_record_quantum_record_10000_658'
                                   1188 ;keycode       Allocated with name '_process_record_quantum_keycode_10000_659'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	quantum/quantum.c:355: bool process_record_quantum(keyrecord_t *record) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function process_record_quantum
                                   1193 ;	-----------------------------------------
      00A123                       1194 _process_record_quantum:
      00A123 12 45 5E         [24] 1195 	lcall	_ak820_outline_0037
      00A126 90 0C 0E         [24] 1196 	mov	dptr,#_process_record_quantum_record_10000_658
      00A129 12 3A 74         [24] 1197 	lcall	_ak820_outline_0017
                                   1198 ;	quantum/quantum.c:357: uint16_t keycode = get_record_keycode(record, false);
      00A12C 90 0C 0E         [24] 1199 	mov	dptr,#_process_record_quantum_record_10000_658
      00A12F 12 51 34         [24] 1200 	lcall	_ak820_outline_0012
      00A132 90 0C 04         [24] 1201 	mov	dptr,#_get_record_keycode_PARM_2
      00A135 E4               [12] 1202 	clr	a
      00A136 12 51 3D         [24] 1203 	lcall	_ak820_outline_0034
      00A139 12 A0 59         [24] 1204 	lcall	_get_record_keycode
      00A13C 12 45 A7         [24] 1205 	lcall	_ak820_outline_0133
                                   1206 ;	quantum/quantum.c:361: return process_record_quantum_helper(keycode, record);
      00A13F 90 0C 0E         [24] 1207 	mov	dptr,#_process_record_quantum_record_10000_658
      00A142 12 9D 48         [24] 1208 	lcall	_ak820_outline_0026
      00A145 90 0C 16         [24] 1209 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A148 12 A3 33         [24] 1210 	lcall	_ak820_outline_0010
                                   1211 ;	quantum/quantum.c:362: }
      00A14B 02 A1 B9         [24] 1212 	ljmp	_process_record_quantum_helper
                                   1213 ;------------------------------------------------------------
                                   1214 ;Allocation info for local variables in function 'process_ak820_nkro'
                                   1215 ;------------------------------------------------------------
                                   1216 ;record_argument Allocated with name '_process_ak820_nkro_PARM_2'
                                   1217 ;keycode       Allocated with name '_process_ak820_nkro_keycode_10000_660'
                                   1218 ;record        Allocated with name '_process_ak820_nkro_record_10000_661'
                                   1219 ;------------------------------------------------------------
                                   1220 ;	quantum/quantum.c:369: static bool process_ak820_nkro(uint16_t keycode, keyrecord_t *record_argument) {
                                   1221 ;	-----------------------------------------
                                   1222 ;	 function process_ak820_nkro
                                   1223 ;	-----------------------------------------
      00A14E                       1224 _process_ak820_nkro:
      00A14E 12 3A CD         [24] 1225 	lcall	_ak820_outline_0107
      00A151 90 0C 14         [24] 1226 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      00A154 12 3A D2         [24] 1227 	lcall	_ak820_outline_0108
                                   1228 ;	quantum/quantum.c:371: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A157 90 0C 11         [24] 1229 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A15A 12 3A 8C         [24] 1230 	lcall	_ak820_outline_0051
                                   1231 ;	quantum/quantum.c:375: if (keycode < QK_MAGIC_NKRO_ON || keycode > QK_MAGIC_TOGGLE_NKRO) return true;
      00A15D 90 0C 14         [24] 1232 	mov	dptr,#_process_ak820_nkro_keycode_10000_660
      00A160 12 3A A3         [24] 1233 	lcall	_ak820_outline_0059
      00A163 C3               [12] 1234 	clr	c
      00A164 EC               [12] 1235 	mov	a,r4
      00A165 94 11            [12] 1236 	subb	a,#0x11
      00A167 ED               [12] 1237 	mov	a,r5
      00A168 94 70            [12] 1238 	subb	a,#0x70
      00A16A 40 08            [24] 1239 	jc	00101$
      00A16C 74 13            [12] 1240 	mov	a,#0x13
      00A16E 9C               [12] 1241 	subb	a,r4
      00A16F 74 70            [12] 1242 	mov	a,#0x70
      00A171 9D               [12] 1243 	subb	a,r5
      00A172 50 04            [24] 1244 	jnc	00102$
                                   1245 ;	free result
      00A174                       1246 00101$:
      00A174 75 82 01         [24] 1247 	mov	dpl, #0x01
      00A177 22               [24] 1248 	ret
      00A178                       1249 00102$:
                                   1250 ;	quantum/quantum.c:376: if (record->event.pressed) {
      00A178 12 3A 5D         [24] 1251 	lcall	_ak820_outline_0009
      00A17B 60 38            [24] 1252 	jz	00105$
                                   1253 ;	quantum/quantum.c:377: clear_keyboard();
      00A17D C0 05            [24] 1254 	push	ar5
      00A17F C0 04            [24] 1255 	push	ar4
      00A181 12 78 AA         [24] 1256 	lcall	_clear_keyboard
      00A184 D0 04            [24] 1257 	pop	ar4
      00A186 D0 05            [24] 1258 	pop	ar5
                                   1259 ;	quantum/quantum.c:378: keymap_config.nkro = keycode == QK_MAGIC_TOGGLE_NKRO ? !keymap_config.nkro : keycode == QK_MAGIC_NKRO_ON;
      00A188 BC 13 14         [24] 1260 	cjne	r4,#0x13,00108$
      00A18B BD 70 11         [24] 1261 	cjne	r5,#0x70,00108$
      00A18E 90 0A CB         [24] 1262 	mov	dptr,#_keymap_config
      00A191 E0               [24] 1263 	movx	a,@dptr
      00A192 23               [12] 1264 	rl	a
      00A193 54 01            [12] 1265 	anl	a,#0x01
      00A195 B4 01 00         [24] 1266 	cjne	a,#0x01,00136$
      00A198                       1267 00136$:
      00A198 92 28            [24] 1268 	mov  _process_ak820_nkro_sloc0_1_0,c
      00A19A E4               [12] 1269 	clr	a
      00A19B 33               [12] 1270 	rlc	a
      00A19C FF               [12] 1271 	mov	r7,a
      00A19D 80 09            [24] 1272 	sjmp	00109$
      00A19F                       1273 00108$:
      00A19F E4               [12] 1274 	clr	a
      00A1A0 BC 11 04         [24] 1275 	cjne	r4,#0x11,00137$
      00A1A3 BD 70 01         [24] 1276 	cjne	r5,#0x70,00137$
      00A1A6 04               [12] 1277 	inc	a
      00A1A7                       1278 00137$:
      00A1A7 FF               [12] 1279 	mov	r7,a
      00A1A8                       1280 00109$:
                                   1281 ;	assignBit
      00A1A8 EF               [12] 1282 	mov	a,r7
      00A1A9 24 FF            [12] 1283 	add	a,#0xff
      00A1AB E4               [12] 1284 	clr	a
      00A1AC 33               [12] 1285 	rlc	a
      00A1AD 90 0A CB         [24] 1286 	mov	dptr,#_keymap_config
      00A1B0 13               [12] 1287 	rrc	a
      00A1B1 E0               [24] 1288 	movx	a,@dptr
      00A1B2 92 E7            [24] 1289 	mov	acc.7,c
      00A1B4 F0               [24] 1290 	movx	@dptr,a
      00A1B5                       1291 00105$:
                                   1292 ;	quantum/quantum.c:380: return false;
      00A1B5 75 82 00         [24] 1293 	mov	dpl, #0x00
                                   1294 ;	quantum/quantum.c:381: }
      00A1B8 22               [24] 1295 	ret
                                   1296 ;------------------------------------------------------------
                                   1297 ;Allocation info for local variables in function 'process_record_quantum_helper'
                                   1298 ;------------------------------------------------------------
                                   1299 ;record_argument Allocated with name '_process_record_quantum_helper_PARM_2'
                                   1300 ;keycode       Allocated with name '_process_record_quantum_helper_keycode_10000_665'
                                   1301 ;record        Allocated with name '_process_record_quantum_helper_record_10000_666'
                                   1302 ;------------------------------------------------------------
                                   1303 ;	quantum/quantum.c:384: bool process_record_quantum_helper(uint16_t keycode, keyrecord_t *record_argument) {
                                   1304 ;	-----------------------------------------
                                   1305 ;	 function process_record_quantum_helper
                                   1306 ;	-----------------------------------------
      00A1B9                       1307 _process_record_quantum_helper:
      00A1B9 12 3A CD         [24] 1308 	lcall	_ak820_outline_0107
      00A1BC 90 0C 19         [24] 1309 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      00A1BF 12 3A D2         [24] 1310 	lcall	_ak820_outline_0108
                                   1311 ;	quantum/quantum.c:386: keyrecord_t __xdata *record = (keyrecord_t __xdata *)record_argument;
      00A1C2 90 0C 16         [24] 1312 	mov	dptr,#_process_record_quantum_helper_PARM_2
      00A1C5 12 3A 8C         [24] 1313 	lcall	_ak820_outline_0051
                                   1314 ;	quantum/quantum.c:429: process_ak820_nkro(keycode, record) &&
      00A1C8 90 0C 19         [24] 1315 	mov	dptr,#_process_record_quantum_helper_keycode_10000_665
      00A1CB 12 3A A3         [24] 1316 	lcall	_ak820_outline_0059
      00A1CE 90 0C 11         [24] 1317 	mov	dptr,#_process_ak820_nkro_PARM_2
      00A1D1 12 A3 26         [24] 1318 	lcall	_ak820_outline_0002
      00A1D4 C0 07            [24] 1319 	push	ar7
      00A1D6 C0 06            [24] 1320 	push	ar6
      00A1D8 C0 05            [24] 1321 	push	ar5
      00A1DA C0 04            [24] 1322 	push	ar4
      00A1DC 12 A1 4E         [24] 1323 	lcall	_process_ak820_nkro
      00A1DF E5 82            [12] 1324 	mov	a, dpl
      00A1E1 D0 04            [24] 1325 	pop	ar4
      00A1E3 D0 05            [24] 1326 	pop	ar5
      00A1E5 D0 06            [24] 1327 	pop	ar6
      00A1E7 D0 07            [24] 1328 	pop	ar7
      00A1E9 70 03            [24] 1329 	jnz	00204$
      00A1EB 02 A2 E2         [24] 1330 	ljmp	00101$
      00A1EE                       1331 00204$:
                                   1332 ;	quantum/quantum.c:440: process_last_key(keycode, record) && process_repeat_key(keycode, record) &&
      00A1EE 90 0B CF         [24] 1333 	mov	dptr,#_process_last_key_PARM_2
      00A1F1 12 A3 26         [24] 1334 	lcall	_ak820_outline_0002
      00A1F4 C0 07            [24] 1335 	push	ar7
      00A1F6 C0 06            [24] 1336 	push	ar6
      00A1F8 C0 05            [24] 1337 	push	ar5
      00A1FA C0 04            [24] 1338 	push	ar4
      00A1FC 12 9C 81         [24] 1339 	lcall	_process_last_key
      00A1FF E5 82            [12] 1340 	mov	a, dpl
      00A201 D0 04            [24] 1341 	pop	ar4
      00A203 D0 05            [24] 1342 	pop	ar5
      00A205 D0 06            [24] 1343 	pop	ar6
      00A207 D0 07            [24] 1344 	pop	ar7
      00A209 70 03            [24] 1345 	jnz	00205$
      00A20B 02 A2 E2         [24] 1346 	ljmp	00101$
      00A20E                       1347 00205$:
      00A20E 90 0B D5         [24] 1348 	mov	dptr,#_process_repeat_key_PARM_2
      00A211 12 A3 26         [24] 1349 	lcall	_ak820_outline_0002
      00A214 C0 07            [24] 1350 	push	ar7
      00A216 C0 06            [24] 1351 	push	ar6
      00A218 C0 05            [24] 1352 	push	ar5
      00A21A C0 04            [24] 1353 	push	ar4
      00A21C 12 9C FF         [24] 1354 	lcall	_process_repeat_key
      00A21F E5 82            [12] 1355 	mov	a, dpl
      00A221 D0 04            [24] 1356 	pop	ar4
      00A223 D0 05            [24] 1357 	pop	ar5
      00A225 D0 06            [24] 1358 	pop	ar6
      00A227 D0 07            [24] 1359 	pop	ar7
      00A229 70 03            [24] 1360 	jnz	00206$
      00A22B 02 A2 E2         [24] 1361 	ljmp	00101$
      00A22E                       1362 00206$:
                                   1363 ;	quantum/quantum.c:449: process_record_via(keycode, record) &&
      00A22E 90 0C 56         [24] 1364 	mov	dptr,#_process_record_via_PARM_2
      00A231 12 A3 26         [24] 1365 	lcall	_ak820_outline_0002
      00A234 C0 07            [24] 1366 	push	ar7
      00A236 C0 06            [24] 1367 	push	ar6
      00A238 C0 05            [24] 1368 	push	ar5
      00A23A C0 04            [24] 1369 	push	ar4
      00A23C 12 A8 37         [24] 1370 	lcall	_process_record_via
      00A23F E5 82            [12] 1371 	mov	a, dpl
      00A241 D0 04            [24] 1372 	pop	ar4
      00A243 D0 05            [24] 1373 	pop	ar5
      00A245 D0 06            [24] 1374 	pop	ar6
      00A247 D0 07            [24] 1375 	pop	ar7
      00A249 70 03            [24] 1376 	jnz	00207$
      00A24B 02 A2 E2         [24] 1377 	ljmp	00101$
      00A24E                       1378 00207$:
                                   1379 ;	quantum/quantum.c:459: process_record_kb(keycode, record) &&
      00A24E 90 0B F4         [24] 1380 	mov	dptr,#_process_record_kb_PARM_2
      00A251 12 A3 26         [24] 1381 	lcall	_ak820_outline_0002
      00A254 C0 07            [24] 1382 	push	ar7
      00A256 C0 06            [24] 1383 	push	ar6
      00A258 C0 05            [24] 1384 	push	ar5
      00A25A C0 04            [24] 1385 	push	ar4
      00A25C 12 9F F7         [24] 1386 	lcall	_process_record_kb
      00A25F E5 82            [12] 1387 	mov	a, dpl
      00A261 D0 04            [24] 1388 	pop	ar4
      00A263 D0 05            [24] 1389 	pop	ar5
      00A265 D0 06            [24] 1390 	pop	ar6
      00A267 D0 07            [24] 1391 	pop	ar7
      00A269 70 03            [24] 1392 	jnz	00208$
      00A26B 02 A2 E2         [24] 1393 	ljmp	00101$
      00A26E                       1394 00208$:
                                   1395 ;	quantum/quantum.c:482: process_caps_word(keycode, record) &&
      00A26E 90 0B B7         [24] 1396 	mov	dptr,#_process_caps_word_PARM_2
      00A271 12 A3 26         [24] 1397 	lcall	_ak820_outline_0002
      00A274 C0 07            [24] 1398 	push	ar7
      00A276 C0 06            [24] 1399 	push	ar6
      00A278 C0 05            [24] 1400 	push	ar5
      00A27A C0 04            [24] 1401 	push	ar4
      00A27C 12 9A 09         [24] 1402 	lcall	_process_caps_word
      00A27F E5 82            [12] 1403 	mov	a, dpl
      00A281 D0 04            [24] 1404 	pop	ar4
      00A283 D0 05            [24] 1405 	pop	ar5
      00A285 D0 06            [24] 1406 	pop	ar6
      00A287 D0 07            [24] 1407 	pop	ar7
      00A289 60 57            [24] 1408 	jz	00101$
                                   1409 ;	quantum/quantum.c:509: process_grave_esc(keycode, record) &&
      00A28B 90 0B BC         [24] 1410 	mov	dptr,#_process_grave_esc_PARM_2
      00A28E 12 A3 26         [24] 1411 	lcall	_ak820_outline_0002
      00A291 C0 07            [24] 1412 	push	ar7
      00A293 C0 06            [24] 1413 	push	ar6
      00A295 C0 05            [24] 1414 	push	ar5
      00A297 C0 04            [24] 1415 	push	ar4
      00A299 12 9B 1C         [24] 1416 	lcall	_process_grave_esc
      00A29C E5 82            [12] 1417 	mov	a, dpl
      00A29E D0 04            [24] 1418 	pop	ar4
      00A2A0 D0 05            [24] 1419 	pop	ar5
      00A2A2 D0 06            [24] 1420 	pop	ar6
      00A2A4 D0 07            [24] 1421 	pop	ar7
      00A2A6 60 3A            [24] 1422 	jz	00101$
                                   1423 ;	quantum/quantum.c:512: process_rgb(keycode, record) &&
      00A2A8 90 0B DA         [24] 1424 	mov	dptr,#_process_rgb_PARM_2
      00A2AB 12 A3 26         [24] 1425 	lcall	_ak820_outline_0002
      00A2AE C0 07            [24] 1426 	push	ar7
      00A2B0 C0 06            [24] 1427 	push	ar6
      00A2B2 C0 05            [24] 1428 	push	ar5
      00A2B4 C0 04            [24] 1429 	push	ar4
      00A2B6 12 9D 59         [24] 1430 	lcall	_process_rgb
      00A2B9 E5 82            [12] 1431 	mov	a, dpl
      00A2BB D0 04            [24] 1432 	pop	ar4
      00A2BD D0 05            [24] 1433 	pop	ar5
      00A2BF D0 06            [24] 1434 	pop	ar6
      00A2C1 D0 07            [24] 1435 	pop	ar7
      00A2C3 60 1D            [24] 1436 	jz	00101$
                                   1437 ;	quantum/quantum.c:524: process_tri_layer(keycode, record) &&
      00A2C5 90 0B E0         [24] 1438 	mov	dptr,#_process_tri_layer_PARM_2
      00A2C8 12 A3 26         [24] 1439 	lcall	_ak820_outline_0002
      00A2CB C0 07            [24] 1440 	push	ar7
      00A2CD C0 06            [24] 1441 	push	ar6
      00A2CF C0 05            [24] 1442 	push	ar5
      00A2D1 C0 04            [24] 1443 	push	ar4
      00A2D3 12 9E 0A         [24] 1444 	lcall	_process_tri_layer
      00A2D6 E5 82            [12] 1445 	mov	a, dpl
      00A2D8 D0 04            [24] 1446 	pop	ar4
      00A2DA D0 05            [24] 1447 	pop	ar5
      00A2DC D0 06            [24] 1448 	pop	ar6
      00A2DE D0 07            [24] 1449 	pop	ar7
      00A2E0 70 04            [24] 1450 	jnz	00102$
                                   1451 ;	quantum/quantum.c:526: true)) {
      00A2E2                       1452 00101$:
                                   1453 ;	quantum/quantum.c:527: return false;
      00A2E2 75 82 00         [24] 1454 	mov	dpl, #0x00
      00A2E5 22               [24] 1455 	ret
      00A2E6                       1456 00102$:
                                   1457 ;	quantum/quantum.c:530: if (record->event.pressed) {
      00A2E6 74 05            [12] 1458 	mov	a,#0x05
      00A2E8 12 4A B0         [24] 1459 	lcall	_ak820_outline_0032
      00A2EB 60 30            [24] 1460 	jz	00117$
                                   1461 ;	quantum/quantum.c:531: switch (keycode) {
      00A2ED BC 00 05         [24] 1462 	cjne	r4,#0x00,00214$
      00A2F0 BD 7C 02         [24] 1463 	cjne	r5,#0x7c,00214$
      00A2F3 80 10            [24] 1464 	sjmp	00112$
      00A2F5                       1465 00214$:
      00A2F5 BC 01 05         [24] 1466 	cjne	r4,#0x01,00215$
      00A2F8 BD 7C 02         [24] 1467 	cjne	r5,#0x7c,00215$
      00A2FB 80 0F            [24] 1468 	sjmp	00113$
      00A2FD                       1469 00215$:
                                   1470 ;	quantum/quantum.c:533: case QK_BOOTLOADER:
      00A2FD BC 03 1D         [24] 1471 	cjne	r4,#0x03,00117$
      00A300 BD 7C 1A         [24] 1472 	cjne	r5,#0x7c,00117$
      00A303 80 0E            [24] 1473 	sjmp	00114$
      00A305                       1474 00112$:
                                   1475 ;	quantum/quantum.c:534: reset_keyboard();
      00A305 12 A0 4D         [24] 1476 	lcall	_reset_keyboard
                                   1477 ;	quantum/quantum.c:535: return false;
      00A308 75 82 00         [24] 1478 	mov	dpl, #0x00
                                   1479 ;	quantum/quantum.c:536: case QK_REBOOT:
      00A30B 22               [24] 1480 	ret
      00A30C                       1481 00113$:
                                   1482 ;	quantum/quantum.c:537: soft_reset_keyboard();
      00A30C 12 A0 53         [24] 1483 	lcall	_soft_reset_keyboard
                                   1484 ;	quantum/quantum.c:538: return false;
      00A30F 75 82 00         [24] 1485 	mov	dpl, #0x00
                                   1486 ;	quantum/quantum.c:550: case QK_CLEAR_EEPROM:
      00A312 22               [24] 1487 	ret
      00A313                       1488 00114$:
                                   1489 ;	quantum/quantum.c:557: eeconfig_disable();
      00A313 12 91 75         [24] 1490 	lcall	_eeconfig_disable
                                   1491 ;	quantum/quantum.c:558: soft_reset_keyboard();
      00A316 12 A0 53         [24] 1492 	lcall	_soft_reset_keyboard
                                   1493 ;	quantum/quantum.c:560: return false;
      00A319 75 82 00         [24] 1494 	mov	dpl, #0x00
                                   1495 ;	quantum/quantum.c:615: }
      00A31C 22               [24] 1496 	ret
      00A31D                       1497 00117$:
                                   1498 ;	quantum/quantum.c:618: return process_action_kb(record);
      00A31D 7D 00            [12] 1499 	mov	r5,#0x00
      00A31F 12 71 B9         [24] 1500 	lcall	_ak820_outline_0064
                                   1501 ;	quantum/quantum.c:619: }
      00A322 02 9F F3         [24] 1502 	ljmp	_process_action_kb
                                   1503 ;------------------------------------------------------------
                                   1504 ;Allocation info for local variables in function 'set_single_persistent_default_layer'
                                   1505 ;------------------------------------------------------------
                                   1506 ;default_layer Allocated with name '_set_single_persistent_default_layer_default_layer_10000_673'
                                   1507 ;------------------------------------------------------------
                                   1508 ;	quantum/quantum.c:621: void set_single_persistent_default_layer(uint8_t default_layer) {
                                   1509 ;	-----------------------------------------
                                   1510 ;	 function shutdown_user
                                   1511 ;	-----------------------------------------
      00A325                       1512 _shutdown_user:
      00A325 22               [24] 1513 	ret
                                   1514 ;------------------------------------------------------------
                                   1515 ;Allocation info for local variables in function 'suspend_power_down_quantum'
                                   1516 ;------------------------------------------------------------
                                   1517 ;	quantum/quantum.c:637: void suspend_power_down_quantum(void) {
                                   1518 ;	-----------------------------------------
                                   1519 	.area CSEG    (CODE)
                                   1520 	.area CONST   (CODE)
                                   1521 	.area XINIT   (CODE)
                                   1522 	.area CABS    (ABS,CODE)
                                   1523 
                                   1524 ; Experimental exact instruction outlining.
                                   1525 	.globl _ak820_outline_0002
                                   1526 	.globl _ak820_outline_0005
                                   1527 	.globl _ak820_outline_0007
                                   1528 	.globl _ak820_outline_0009
                                   1529 	.globl _ak820_outline_0010
                                   1530 	.globl _ak820_outline_0012
                                   1531 	.globl _ak820_outline_0017
                                   1532 	.globl _ak820_outline_0021
                                   1533 	.globl _ak820_outline_0022
                                   1534 	.globl _ak820_outline_0026
                                   1535 	.globl _ak820_outline_0032
                                   1536 	.globl _ak820_outline_0034
                                   1537 	.globl _ak820_outline_0037
                                   1538 	.globl _ak820_outline_0040
                                   1539 	.globl _ak820_outline_0051
                                   1540 	.globl _ak820_outline_0059
                                   1541 	.globl _ak820_outline_0064
                                   1542 	.globl _ak820_outline_0072
                                   1543 	.globl _ak820_outline_0107
                                   1544 	.globl _ak820_outline_0108
                                   1545 	.globl _ak820_outline_0118
                                   1546 	.globl _ak820_outline_0119
                                   1547 	.globl _ak820_outline_0123
                                   1548 	.globl _ak820_outline_0124
                                   1549 	.globl _ak820_outline_0133
                                   1550 	.globl _ak820_outline_0142
                                   1551 	.globl _ak820_outline_0149
                                   1552 	.globl _ak820_outline_0156
                                   1553 
                                   1554 	.area CSEG (CODE)
                                   1555 ; function ak820_outline_0002
      00A326                       1556 _ak820_outline_0002:
      00A326 EE               [12] 1557 	mov	a,r6
      00A327 F0               [24] 1558 	movx	@dptr,a
      00A328 EF               [12] 1559 	mov	a,r7
      00A329 A3               [24] 1560 	inc	dptr
      00A32A F0               [24] 1561 	movx	@dptr,a
      00A32B E4               [12] 1562 	clr	a
      00A32C A3               [24] 1563 	inc	dptr
      00A32D F0               [24] 1564 	movx	@dptr,a
      00A32E 8C 82            [24] 1565 	mov	dpl,r4
      00A330 8D 83            [24] 1566 	mov	dph,r5
      00A332 22               [24] 1567 	ret
                                   1568 
                                   1569 	.area CSEG (CODE)
                                   1570 ; function ak820_outline_0010
      00A333                       1571 _ak820_outline_0010:
      00A333 EB               [12] 1572 	mov	a,r3
      00A334 F0               [24] 1573 	movx	@dptr,a
      00A335 EC               [12] 1574 	mov	a,r4
      00A336 A3               [24] 1575 	inc	dptr
      00A337 F0               [24] 1576 	movx	@dptr,a
      00A338 ED               [12] 1577 	mov	a,r5
      00A339 A3               [24] 1578 	inc	dptr
      00A33A F0               [24] 1579 	movx	@dptr,a
      00A33B 8E 82            [24] 1580 	mov	dpl,r6
      00A33D 8F 83            [24] 1581 	mov	dph,r7
      00A33F 22               [24] 1582 	ret
