                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module keyboard
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _quantum_task
                                     12 	.globl _switch_events
                                     13 	.globl _quantum_init
                                     14 	.globl _should_process_keypress
                                     15 	.globl _last_encoder_activity_trigger
                                     16 	.globl _last_matrix_activity_trigger
                                     17 	.globl _caps_word_task
                                     18 	.globl _vial_unlock_task
                                     19 	.globl _vial_init
                                     20 	.globl _eeprom_driver_init
                                     21 	.globl _via_init
                                     22 	.globl _encoder_read
                                     23 	.globl _encoder_init
                                     24 	.globl _rgb_matrix_init
                                     25 	.globl _rgb_matrix_task
                                     26 	.globl _process_rgb_matrix
                                     27 	.globl _ak820_action_exec
                                     28 	.globl _print_set_sendchar
                                     29 	.globl _sendchar
                                     30 	.globl _led_task
                                     31 	.globl _led_init_ports
                                     32 	.globl _magic
                                     33 	.globl _matrix_print
                                     34 	.globl _matrix_get_row
                                     35 	.globl _matrix_scan
                                     36 	.globl _matrix_init
                                     37 	.globl _keyboard_post_init_user
                                     38 	.globl _timer_elapsed32
                                     39 	.globl _timer_read32
                                     40 	.globl _timer_read
                                     41 	.globl _timer_init
                                     42 	.globl _ADC_START
                                     43 	.globl _S0_R_FIFO
                                     44 	.globl _S0_T_FIFO
                                     45 	.globl _S0_FREE
                                     46 	.globl _S0_IF_BYTE
                                     47 	.globl _S0_IF_FIRST
                                     48 	.globl _S0_IF_OV
                                     49 	.globl _S0_FST_ACT
                                     50 	.globl _CP_RL2
                                     51 	.globl _C_T2
                                     52 	.globl _TR2
                                     53 	.globl _EXEN2
                                     54 	.globl _TCLK
                                     55 	.globl _RCLK
                                     56 	.globl _EXF2
                                     57 	.globl _CAP1F
                                     58 	.globl _TF2
                                     59 	.globl _RI
                                     60 	.globl _TI
                                     61 	.globl _RB8
                                     62 	.globl _TB8
                                     63 	.globl _REN
                                     64 	.globl _SM2
                                     65 	.globl _SM1
                                     66 	.globl _SM0
                                     67 	.globl _IT0
                                     68 	.globl _IE0
                                     69 	.globl _IT1
                                     70 	.globl _IE1
                                     71 	.globl _TR0
                                     72 	.globl _TF0
                                     73 	.globl _TR1
                                     74 	.globl _TF1
                                     75 	.globl _P4_0
                                     76 	.globl _P4_1
                                     77 	.globl _P4_2
                                     78 	.globl _P4_3
                                     79 	.globl _P4_4
                                     80 	.globl _P4_5
                                     81 	.globl _P4_6
                                     82 	.globl _RXD
                                     83 	.globl _TXD
                                     84 	.globl _INT0
                                     85 	.globl _INT1
                                     86 	.globl _T0
                                     87 	.globl _T1
                                     88 	.globl _MOSI1
                                     89 	.globl _MISO1
                                     90 	.globl _SCK1
                                     91 	.globl _P3_0
                                     92 	.globl _P3_1
                                     93 	.globl _P3_2
                                     94 	.globl _P3_3
                                     95 	.globl _P3_4
                                     96 	.globl _P3_5
                                     97 	.globl _P3_6
                                     98 	.globl _P3_7
                                     99 	.globl _CAP1_
                                    100 	.globl _T2_
                                    101 	.globl _CAP2_
                                    102 	.globl _T2EX_
                                    103 	.globl _RXD1
                                    104 	.globl _TXD1
                                    105 	.globl _P2_0
                                    106 	.globl _P2_1
                                    107 	.globl _P2_2
                                    108 	.globl _P2_3
                                    109 	.globl _P2_4
                                    110 	.globl _P2_5
                                    111 	.globl _P2_6
                                    112 	.globl _P2_7
                                    113 	.globl _AIN0
                                    114 	.globl _AIN1
                                    115 	.globl _AIN2
                                    116 	.globl _AIN3
                                    117 	.globl _AIN4
                                    118 	.globl _AIN5
                                    119 	.globl _AIN6
                                    120 	.globl _AIN7
                                    121 	.globl _CAP1
                                    122 	.globl _T2
                                    123 	.globl _CAP2
                                    124 	.globl _T2EX
                                    125 	.globl _INT0_
                                    126 	.globl _SCS
                                    127 	.globl _MOSI
                                    128 	.globl _MISO
                                    129 	.globl _SCK
                                    130 	.globl _RXD1_
                                    131 	.globl _TXD1_
                                    132 	.globl _P1_0
                                    133 	.globl _P1_1
                                    134 	.globl _P1_2
                                    135 	.globl _P1_3
                                    136 	.globl _P1_4
                                    137 	.globl _P1_5
                                    138 	.globl _P1_6
                                    139 	.globl _P1_7
                                    140 	.globl _AIN8
                                    141 	.globl _AIN9
                                    142 	.globl _AIN10
                                    143 	.globl _AIN11
                                    144 	.globl _AIN12
                                    145 	.globl _AIN13
                                    146 	.globl _RXD_
                                    147 	.globl _TXD_
                                    148 	.globl _SCL0
                                    149 	.globl _SDA0
                                    150 	.globl _P0_0
                                    151 	.globl _P0_1
                                    152 	.globl _P0_2
                                    153 	.globl _P0_3
                                    154 	.globl _P0_4
                                    155 	.globl _P0_5
                                    156 	.globl _P0_6
                                    157 	.globl _P0_7
                                    158 	.globl _IE_SPI0
                                    159 	.globl _IE_USB
                                    160 	.globl _IE_ADC
                                    161 	.globl _IE_UART1
                                    162 	.globl _IE_PWM_I2C
                                    163 	.globl _IE_GPIO
                                    164 	.globl _IE_WDOG
                                    165 	.globl _PX0
                                    166 	.globl _PT0
                                    167 	.globl _PX1
                                    168 	.globl _PT1
                                    169 	.globl _PS
                                    170 	.globl _PT2
                                    171 	.globl _PL_FLAG
                                    172 	.globl _PH_FLAG
                                    173 	.globl _EX0
                                    174 	.globl _ET0
                                    175 	.globl _EX1
                                    176 	.globl _ET1
                                    177 	.globl _ES
                                    178 	.globl _ET2
                                    179 	.globl _E_DIS
                                    180 	.globl _EA
                                    181 	.globl _P
                                    182 	.globl _F1
                                    183 	.globl _OV
                                    184 	.globl _RS0
                                    185 	.globl _RS1
                                    186 	.globl _F0
                                    187 	.globl _AC
                                    188 	.globl _CY
                                    189 	.globl _I2CS_INT_ST
                                    190 	.globl _I2CX_INT
                                    191 	.globl _LED_STATUS
                                    192 	.globl _LED_DMA_H
                                    193 	.globl _LED_DMA_L
                                    194 	.globl _LED_DMA
                                    195 	.globl _LED_PWM_OE
                                    196 	.globl _LED_COMMON
                                    197 	.globl _ADC_CHAN
                                    198 	.globl _ADC_DAT_H
                                    199 	.globl _ADC_DAT_L
                                    200 	.globl _ADC_DAT
                                    201 	.globl _ADC_CTRL
                                    202 	.globl _SPI1_CK_SE
                                    203 	.globl _SPI1_CTRL
                                    204 	.globl _SPI1_DATA
                                    205 	.globl _SPI1_STAT
                                    206 	.globl _SIF1
                                    207 	.globl _SBAUD1
                                    208 	.globl _SBUF1
                                    209 	.globl _SCON1
                                    210 	.globl _SPI0_SETUP
                                    211 	.globl _SPI0_CK_SE
                                    212 	.globl _SPI0_CTRL
                                    213 	.globl _SPI0_DATA
                                    214 	.globl _SPI0_STAT
                                    215 	.globl _T2CAP1H
                                    216 	.globl _T2CAP1L
                                    217 	.globl _T2CAP1
                                    218 	.globl _TH2
                                    219 	.globl _TL2
                                    220 	.globl _T2COUNT
                                    221 	.globl _RCAP2H
                                    222 	.globl _RCAP2L
                                    223 	.globl _RCAP2
                                    224 	.globl _T2MOD
                                    225 	.globl _T2CON
                                    226 	.globl _SBUF
                                    227 	.globl _SCON
                                    228 	.globl _TH1
                                    229 	.globl _TH0
                                    230 	.globl _TL1
                                    231 	.globl _TL0
                                    232 	.globl _TMOD
                                    233 	.globl _TCON
                                    234 	.globl _XBUS_AUX
                                    235 	.globl _P7
                                    236 	.globl _P6_DIR
                                    237 	.globl _P6_OUT_PU
                                    238 	.globl _P6_IN
                                    239 	.globl _P5_DIR
                                    240 	.globl _P5_OUT_PU
                                    241 	.globl _P5_IN
                                    242 	.globl _P4_LED_KEY
                                    243 	.globl _P4_DIR_PU
                                    244 	.globl _P4_MOD_OC
                                    245 	.globl _P4
                                    246 	.globl _P3_DIR_PU
                                    247 	.globl _P3_MOD_OC
                                    248 	.globl _P3
                                    249 	.globl _P2_DIR_PU
                                    250 	.globl _P2_MOD_OC
                                    251 	.globl _P2
                                    252 	.globl _P1_DIR_PU
                                    253 	.globl _P1_MOD_OC
                                    254 	.globl _P1
                                    255 	.globl _P0_DIR_PU
                                    256 	.globl _P0_MOD_OC
                                    257 	.globl _P0
                                    258 	.globl _ROM_CTRL
                                    259 	.globl _ROM_DATA_HH
                                    260 	.globl _ROM_DATA_HL
                                    261 	.globl _ROM_DATA_HI
                                    262 	.globl _ROM_ADDR_H
                                    263 	.globl _ROM_ADDR_L
                                    264 	.globl _ROM_ADDR
                                    265 	.globl _GPIO_IE
                                    266 	.globl _IP_EX
                                    267 	.globl _IE_EX
                                    268 	.globl _IP
                                    269 	.globl _IE
                                    270 	.globl _WDOG_COUNT
                                    271 	.globl _RESET_KEEP
                                    272 	.globl _WAKE_CTRL
                                    273 	.globl _CLOCK_CFG
                                    274 	.globl _POWER_CFG
                                    275 	.globl _PCON
                                    276 	.globl _GLOBAL_CFG
                                    277 	.globl _SAFE_MOD
                                    278 	.globl _DPH
                                    279 	.globl _DPL
                                    280 	.globl _SP
                                    281 	.globl _A_INV
                                    282 	.globl _B
                                    283 	.globl _ACC
                                    284 	.globl _PSW
                                    285 	.globl _switch_events_PARM_3
                                    286 	.globl _switch_events_PARM_2
                                    287 	.globl _keyboard_post_init_kb
                                    288 	.globl _matrix_can_read
                                    289 	.globl _keyboard_setup
                                    290 	.globl _is_keyboard_master
                                    291 	.globl _housekeeping_task
                                    292 	.globl _keyboard_init
                                    293 	.globl _keyboard_task
                                    294 ;--------------------------------------------------------
                                    295 ; special function registers
                                    296 ;--------------------------------------------------------
                                    297 	.area RSEG    (ABS,DATA)
      000000                        298 	.org 0x0000
                           0000D0   299 _PSW	=	0x00d0
                           0000E0   300 _ACC	=	0x00e0
                           0000F0   301 _B	=	0x00f0
                           0000FD   302 _A_INV	=	0x00fd
                           000081   303 _SP	=	0x0081
                           000082   304 _DPL	=	0x0082
                           000083   305 _DPH	=	0x0083
                           0000A1   306 _SAFE_MOD	=	0x00a1
                           0000B1   307 _GLOBAL_CFG	=	0x00b1
                           000087   308 _PCON	=	0x0087
                           0000BA   309 _POWER_CFG	=	0x00ba
                           0000B9   310 _CLOCK_CFG	=	0x00b9
                           0000A9   311 _WAKE_CTRL	=	0x00a9
                           0000FE   312 _RESET_KEEP	=	0x00fe
                           0000FF   313 _WDOG_COUNT	=	0x00ff
                           0000A8   314 _IE	=	0x00a8
                           0000B8   315 _IP	=	0x00b8
                           0000E8   316 _IE_EX	=	0x00e8
                           0000E9   317 _IP_EX	=	0x00e9
                           0000B2   318 _GPIO_IE	=	0x00b2
                           008584   319 _ROM_ADDR	=	0x8584
                           000084   320 _ROM_ADDR_L	=	0x0084
                           000085   321 _ROM_ADDR_H	=	0x0085
                           008F8E   322 _ROM_DATA_HI	=	0x8f8e
                           00008E   323 _ROM_DATA_HL	=	0x008e
                           00008F   324 _ROM_DATA_HH	=	0x008f
                           000086   325 _ROM_CTRL	=	0x0086
                           000080   326 _P0	=	0x0080
                           0000C4   327 _P0_MOD_OC	=	0x00c4
                           0000C5   328 _P0_DIR_PU	=	0x00c5
                           000090   329 _P1	=	0x0090
                           000092   330 _P1_MOD_OC	=	0x0092
                           000093   331 _P1_DIR_PU	=	0x0093
                           0000A0   332 _P2	=	0x00a0
                           000094   333 _P2_MOD_OC	=	0x0094
                           000095   334 _P2_DIR_PU	=	0x0095
                           0000B0   335 _P3	=	0x00b0
                           000096   336 _P3_MOD_OC	=	0x0096
                           000097   337 _P3_DIR_PU	=	0x0097
                           0000C0   338 _P4	=	0x00c0
                           0000C2   339 _P4_MOD_OC	=	0x00c2
                           0000C3   340 _P4_DIR_PU	=	0x00c3
                           0000C1   341 _P4_LED_KEY	=	0x00c1
                           0000AA   342 _P5_IN	=	0x00aa
                           0000AB   343 _P5_OUT_PU	=	0x00ab
                           0000AC   344 _P5_DIR	=	0x00ac
                           0000AD   345 _P6_IN	=	0x00ad
                           0000AE   346 _P6_OUT_PU	=	0x00ae
                           0000AF   347 _P6_DIR	=	0x00af
                           0000F1   348 _P7	=	0x00f1
                           0000A2   349 _XBUS_AUX	=	0x00a2
                           000088   350 _TCON	=	0x0088
                           000089   351 _TMOD	=	0x0089
                           00008A   352 _TL0	=	0x008a
                           00008B   353 _TL1	=	0x008b
                           00008C   354 _TH0	=	0x008c
                           00008D   355 _TH1	=	0x008d
                           000098   356 _SCON	=	0x0098
                           000099   357 _SBUF	=	0x0099
                           0000C8   358 _T2CON	=	0x00c8
                           0000C9   359 _T2MOD	=	0x00c9
                           00CBCA   360 _RCAP2	=	0xcbca
                           0000CA   361 _RCAP2L	=	0x00ca
                           0000CB   362 _RCAP2H	=	0x00cb
                           00CDCC   363 _T2COUNT	=	0xcdcc
                           0000CC   364 _TL2	=	0x00cc
                           0000CD   365 _TH2	=	0x00cd
                           00CFCE   366 _T2CAP1	=	0xcfce
                           0000CE   367 _T2CAP1L	=	0x00ce
                           0000CF   368 _T2CAP1H	=	0x00cf
                           0000F8   369 _SPI0_STAT	=	0x00f8
                           0000F9   370 _SPI0_DATA	=	0x00f9
                           0000FA   371 _SPI0_CTRL	=	0x00fa
                           0000FB   372 _SPI0_CK_SE	=	0x00fb
                           0000FC   373 _SPI0_SETUP	=	0x00fc
                           0000BC   374 _SCON1	=	0x00bc
                           0000BD   375 _SBUF1	=	0x00bd
                           0000BE   376 _SBAUD1	=	0x00be
                           0000BF   377 _SIF1	=	0x00bf
                           0000B4   378 _SPI1_STAT	=	0x00b4
                           0000B5   379 _SPI1_DATA	=	0x00b5
                           0000B6   380 _SPI1_CTRL	=	0x00b6
                           0000B7   381 _SPI1_CK_SE	=	0x00b7
                           0000F3   382 _ADC_CTRL	=	0x00f3
                           00F5F4   383 _ADC_DAT	=	0xf5f4
                           0000F4   384 _ADC_DAT_L	=	0x00f4
                           0000F5   385 _ADC_DAT_H	=	0x00f5
                           0000F6   386 _ADC_CHAN	=	0x00f6
                           0000A6   387 _LED_COMMON	=	0x00a6
                           0000A7   388 _LED_PWM_OE	=	0x00a7
                           00C7C6   389 _LED_DMA	=	0xc7c6
                           0000C6   390 _LED_DMA_L	=	0x00c6
                           0000C7   391 _LED_DMA_H	=	0x00c7
                           0000F7   392 _LED_STATUS	=	0x00f7
                           0000B3   393 _I2CX_INT	=	0x00b3
                           0000BB   394 _I2CS_INT_ST	=	0x00bb
                                    395 ;--------------------------------------------------------
                                    396 ; special function bits
                                    397 ;--------------------------------------------------------
                                    398 	.area RSEG    (ABS,DATA)
      000000                        399 	.org 0x0000
                           0000D7   400 _CY	=	0x00d7
                           0000D6   401 _AC	=	0x00d6
                           0000D5   402 _F0	=	0x00d5
                           0000D4   403 _RS1	=	0x00d4
                           0000D3   404 _RS0	=	0x00d3
                           0000D2   405 _OV	=	0x00d2
                           0000D1   406 _F1	=	0x00d1
                           0000D0   407 _P	=	0x00d0
                           0000AF   408 _EA	=	0x00af
                           0000AE   409 _E_DIS	=	0x00ae
                           0000AD   410 _ET2	=	0x00ad
                           0000AC   411 _ES	=	0x00ac
                           0000AB   412 _ET1	=	0x00ab
                           0000AA   413 _EX1	=	0x00aa
                           0000A9   414 _ET0	=	0x00a9
                           0000A8   415 _EX0	=	0x00a8
                           0000BF   416 _PH_FLAG	=	0x00bf
                           0000BE   417 _PL_FLAG	=	0x00be
                           0000BD   418 _PT2	=	0x00bd
                           0000BC   419 _PS	=	0x00bc
                           0000BB   420 _PT1	=	0x00bb
                           0000BA   421 _PX1	=	0x00ba
                           0000B9   422 _PT0	=	0x00b9
                           0000B8   423 _PX0	=	0x00b8
                           0000EF   424 _IE_WDOG	=	0x00ef
                           0000EE   425 _IE_GPIO	=	0x00ee
                           0000ED   426 _IE_PWM_I2C	=	0x00ed
                           0000EC   427 _IE_UART1	=	0x00ec
                           0000EB   428 _IE_ADC	=	0x00eb
                           0000E9   429 _IE_USB	=	0x00e9
                           0000E8   430 _IE_SPI0	=	0x00e8
                           000087   431 _P0_7	=	0x0087
                           000086   432 _P0_6	=	0x0086
                           000085   433 _P0_5	=	0x0085
                           000084   434 _P0_4	=	0x0084
                           000083   435 _P0_3	=	0x0083
                           000082   436 _P0_2	=	0x0082
                           000081   437 _P0_1	=	0x0081
                           000080   438 _P0_0	=	0x0080
                           000081   439 _SDA0	=	0x0081
                           000080   440 _SCL0	=	0x0080
                           000083   441 _TXD_	=	0x0083
                           000082   442 _RXD_	=	0x0082
                           000085   443 _AIN13	=	0x0085
                           000084   444 _AIN12	=	0x0084
                           000083   445 _AIN11	=	0x0083
                           000082   446 _AIN10	=	0x0082
                           000081   447 _AIN9	=	0x0081
                           000080   448 _AIN8	=	0x0080
                           000097   449 _P1_7	=	0x0097
                           000096   450 _P1_6	=	0x0096
                           000095   451 _P1_5	=	0x0095
                           000094   452 _P1_4	=	0x0094
                           000093   453 _P1_3	=	0x0093
                           000092   454 _P1_2	=	0x0092
                           000091   455 _P1_1	=	0x0091
                           000090   456 _P1_0	=	0x0090
                           000097   457 _TXD1_	=	0x0097
                           000096   458 _RXD1_	=	0x0096
                           000097   459 _SCK	=	0x0097
                           000096   460 _MISO	=	0x0096
                           000095   461 _MOSI	=	0x0095
                           000094   462 _SCS	=	0x0094
                           000092   463 _INT0_	=	0x0092
                           000091   464 _T2EX	=	0x0091
                           000091   465 _CAP2	=	0x0091
                           000090   466 _T2	=	0x0090
                           000090   467 _CAP1	=	0x0090
                           000097   468 _AIN7	=	0x0097
                           000096   469 _AIN6	=	0x0096
                           000095   470 _AIN5	=	0x0095
                           000094   471 _AIN4	=	0x0094
                           000093   472 _AIN3	=	0x0093
                           000092   473 _AIN2	=	0x0092
                           000091   474 _AIN1	=	0x0091
                           000090   475 _AIN0	=	0x0090
                           0000A7   476 _P2_7	=	0x00a7
                           0000A6   477 _P2_6	=	0x00a6
                           0000A5   478 _P2_5	=	0x00a5
                           0000A4   479 _P2_4	=	0x00a4
                           0000A3   480 _P2_3	=	0x00a3
                           0000A2   481 _P2_2	=	0x00a2
                           0000A1   482 _P2_1	=	0x00a1
                           0000A0   483 _P2_0	=	0x00a0
                           0000A7   484 _TXD1	=	0x00a7
                           0000A6   485 _RXD1	=	0x00a6
                           0000A5   486 _T2EX_	=	0x00a5
                           0000A5   487 _CAP2_	=	0x00a5
                           0000A4   488 _T2_	=	0x00a4
                           0000A4   489 _CAP1_	=	0x00a4
                           0000B7   490 _P3_7	=	0x00b7
                           0000B6   491 _P3_6	=	0x00b6
                           0000B5   492 _P3_5	=	0x00b5
                           0000B4   493 _P3_4	=	0x00b4
                           0000B3   494 _P3_3	=	0x00b3
                           0000B2   495 _P3_2	=	0x00b2
                           0000B1   496 _P3_1	=	0x00b1
                           0000B0   497 _P3_0	=	0x00b0
                           0000B7   498 _SCK1	=	0x00b7
                           0000B6   499 _MISO1	=	0x00b6
                           0000B5   500 _MOSI1	=	0x00b5
                           0000B5   501 _T1	=	0x00b5
                           0000B4   502 _T0	=	0x00b4
                           0000B3   503 _INT1	=	0x00b3
                           0000B2   504 _INT0	=	0x00b2
                           0000B1   505 _TXD	=	0x00b1
                           0000B0   506 _RXD	=	0x00b0
                           0000C6   507 _P4_6	=	0x00c6
                           0000C5   508 _P4_5	=	0x00c5
                           0000C4   509 _P4_4	=	0x00c4
                           0000C3   510 _P4_3	=	0x00c3
                           0000C2   511 _P4_2	=	0x00c2
                           0000C1   512 _P4_1	=	0x00c1
                           0000C0   513 _P4_0	=	0x00c0
                           00008F   514 _TF1	=	0x008f
                           00008E   515 _TR1	=	0x008e
                           00008D   516 _TF0	=	0x008d
                           00008C   517 _TR0	=	0x008c
                           00008B   518 _IE1	=	0x008b
                           00008A   519 _IT1	=	0x008a
                           000089   520 _IE0	=	0x0089
                           000088   521 _IT0	=	0x0088
                           00009F   522 _SM0	=	0x009f
                           00009E   523 _SM1	=	0x009e
                           00009D   524 _SM2	=	0x009d
                           00009C   525 _REN	=	0x009c
                           00009B   526 _TB8	=	0x009b
                           00009A   527 _RB8	=	0x009a
                           000099   528 _TI	=	0x0099
                           000098   529 _RI	=	0x0098
                           0000CF   530 _TF2	=	0x00cf
                           0000CF   531 _CAP1F	=	0x00cf
                           0000CE   532 _EXF2	=	0x00ce
                           0000CD   533 _RCLK	=	0x00cd
                           0000CC   534 _TCLK	=	0x00cc
                           0000CB   535 _EXEN2	=	0x00cb
                           0000CA   536 _TR2	=	0x00ca
                           0000C9   537 _C_T2	=	0x00c9
                           0000C8   538 _CP_RL2	=	0x00c8
                           0000FF   539 _S0_FST_ACT	=	0x00ff
                           0000FE   540 _S0_IF_OV	=	0x00fe
                           0000FD   541 _S0_IF_FIRST	=	0x00fd
                           0000FC   542 _S0_IF_BYTE	=	0x00fc
                           0000FB   543 _S0_FREE	=	0x00fb
                           0000FA   544 _S0_T_FIFO	=	0x00fa
                           0000F8   545 _S0_R_FIFO	=	0x00f8
                           0000F7   546 _ADC_START	=	0x00f7
                                    547 ;--------------------------------------------------------
                                    548 ; overlayable register banks
                                    549 ;--------------------------------------------------------
                                    550 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        551 	.ds 8
                                    552 ;--------------------------------------------------------
                                    553 ; internal ram data
                                    554 ;--------------------------------------------------------
                                    555 	.area DSEG    (DATA)
                                    556 ;--------------------------------------------------------
                                    557 ; overlayable items in internal ram
                                    558 ;--------------------------------------------------------
                                    559 	.area	OSEG    (OVR,DATA)
                                    560 ;--------------------------------------------------------
                                    561 ; indirectly addressable internal ram data
                                    562 ;--------------------------------------------------------
                                    563 	.area ISEG    (DATA)
                                    564 ;--------------------------------------------------------
                                    565 ; absolute internal ram data
                                    566 ;--------------------------------------------------------
                                    567 	.area IABS    (ABS,DATA)
                                    568 	.area IABS    (ABS,DATA)
                                    569 ;--------------------------------------------------------
                                    570 ; bit data
                                    571 ;--------------------------------------------------------
                                    572 	.area BSEG    (BIT)
                                    573 ;--------------------------------------------------------
                                    574 ; paged external ram data
                                    575 ;--------------------------------------------------------
                                    576 	.area PSEG    (PAG,XDATA)
                                    577 ;--------------------------------------------------------
                                    578 ; uninitialized external ram data
                                    579 ;--------------------------------------------------------
                                    580 	.area XSEG    (XDATA)
      000B70                        581 _switch_events_PARM_2:
      000B70                        582 	.ds 1
      000B71                        583 _switch_events_PARM_3:
      000B71                        584 	.ds 1
      000B72                        585 _switch_events_row_10000_492:
      000B72                        586 	.ds 1
      000B73                        587 _generate_tick_event_last_tick_10000_495:
      000B73                        588 	.ds 2
      000B75                        589 _matrix_task_last_tick_60000_524:
      000B75                        590 	.ds 2
      000B77                        591 _matrix_task_dummy_event_70000_525:
      000B77                        592 	.ds 6
      000B7D                        593 _matrix_task_matrix_previous_10001_502:
      000B7D                        594 	.ds 16
      000B8D                        595 _matrix_task_matrix_changed_10002_503:
      000B8D                        596 	.ds 1
      000B8E                        597 _matrix_task_last_tick_60002_528:
      000B8E                        598 	.ds 2
      000B90                        599 _matrix_task_dummy_event_70002_529:
      000B90                        600 	.ds 6
      000B96                        601 _matrix_task_row_changes_30003_512:
      000B96                        602 	.ds 1
      000B97                        603 _matrix_task_col_mask_30004_515:
      000B97                        604 	.ds 1
      000B98                        605 _matrix_task_dummy_event_90004_521:
      000B98                        606 	.ds 6
                                    607 ;--------------------------------------------------------
                                    608 ; absolute external ram data
                                    609 ;--------------------------------------------------------
                                    610 	.area XABS    (ABS,XDATA)
                                    611 ;--------------------------------------------------------
                                    612 ; initialized external ram data
                                    613 ;--------------------------------------------------------
                                    614 	.area XISEG   (XDATA)
      000E0C                        615 _last_input_modification_time:
      000E0C                        616 	.ds 4
      000E10                        617 _last_matrix_modification_time:
      000E10                        618 	.ds 4
      000E14                        619 _last_encoder_modification_time:
      000E14                        620 	.ds 4
      000E18                        621 _last_pointing_device_modification_time:
      000E18                        622 	.ds 4
                                    623 	.area HOME    (CODE)
                                    624 	.area GSINIT0 (CODE)
                                    625 	.area GSINIT1 (CODE)
                                    626 	.area GSINIT2 (CODE)
                                    627 	.area GSINIT3 (CODE)
                                    628 	.area GSINIT4 (CODE)
                                    629 	.area GSINIT5 (CODE)
                                    630 	.area GSINIT  (CODE)
                                    631 	.area GSFINAL (CODE)
                                    632 	.area CSEG    (CODE)
                                    633 ;--------------------------------------------------------
                                    634 ; global & static initialisations
                                    635 ;--------------------------------------------------------
                                    636 	.area HOME    (CODE)
                                    637 	.area GSINIT  (CODE)
                                    638 	.area GSFINAL (CODE)
                                    639 	.area GSINIT  (CODE)
                                    640 ;------------------------------------------------------------
                                    641 ;Allocation info for local variables in function 'generate_tick_event'
                                    642 ;------------------------------------------------------------
                                    643 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_495'
                                    644 ;now           Allocated with name '_generate_tick_event_now_10000_495'
                                    645 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_497'
                                    646 ;------------------------------------------------------------
                                    647 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      0030DA 90 0B 73         [24]  648 	mov	dptr,#_generate_tick_event_last_tick_10000_495
      0030DD E4               [12]  649 	clr	a
      0030DE F0               [24]  650 	movx	@dptr,a
      0030DF A3               [24]  651 	inc	dptr
      0030E0 F0               [24]  652 	movx	@dptr,a
                                    653 ;------------------------------------------------------------
                                    654 ;Allocation info for local variables in function 'matrix_task'
                                    655 ;------------------------------------------------------------
                                    656 ;last_tick     Allocated with name '_matrix_task_last_tick_60000_524'
                                    657 ;now           Allocated with name '_matrix_task_now_60000_524'
                                    658 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70000_525'
                                    659 ;matrix_previous Allocated with name '_matrix_task_matrix_previous_10001_502'
                                    660 ;matrix_changed Allocated with name '_matrix_task_matrix_changed_10002_503'
                                    661 ;row           Allocated with name '_matrix_task_row_20002_504'
                                    662 ;last_tick     Allocated with name '_matrix_task_last_tick_60002_528'
                                    663 ;now           Allocated with name '_matrix_task_now_60002_528'
                                    664 ;dummy_event   Allocated with name '_matrix_task_dummy_event_70002_529'
                                    665 ;process_keypress Allocated with name '_matrix_task_process_keypress_10003_510'
                                    666 ;row           Allocated with name '_matrix_task_row_20003_511'
                                    667 ;__400030089   Allocated with name '_matrix_task___400030089_40003_512'
                                    668 ;current_row   Allocated with name '_matrix_task_current_row_30003_512'
                                    669 ;row_changes   Allocated with name '_matrix_task_row_changes_30003_512'
                                    670 ;__500030090   Allocated with name '_matrix_task___500030090_50003_530'
                                    671 ;__500030091   Allocated with name '_matrix_task___500030091_50003_530'
                                    672 ;row           Allocated with name '_matrix_task_row_60003_531'
                                    673 ;rowdata       Allocated with name '_matrix_task_rowdata_60003_531'
                                    674 ;col_mask      Allocated with name '_matrix_task_col_mask_30004_515'
                                    675 ;col           Allocated with name '_matrix_task_col_40004_516'
                                    676 ;key_pressed   Allocated with name '_matrix_task_key_pressed_70004_519'
                                    677 ;dummy_event   Allocated with name '_matrix_task_dummy_event_90004_521'
                                    678 ;------------------------------------------------------------
                                    679 ;	quantum/keyboard.c:544: static uint16_t last_tick = 0;
      0030E1 90 0B 75         [24]  680 	mov	dptr,#_matrix_task_last_tick_60000_524
      0030E4 E4               [12]  681 	clr	a
      0030E5 F0               [24]  682 	movx	@dptr,a
      0030E6 A3               [24]  683 	inc	dptr
      0030E7 F0               [24]  684 	movx	@dptr,a
      0030E8 90 0B 8E         [24]  685 	mov	dptr,#_matrix_task_last_tick_60002_528
      0030EB F0               [24]  686 	movx	@dptr,a
      0030EC A3               [24]  687 	inc	dptr
      0030ED F0               [24]  688 	movx	@dptr,a
                                    689 ;--------------------------------------------------------
                                    690 ; Home
                                    691 ;--------------------------------------------------------
                                    692 	.area HOME    (CODE)
                                    693 	.area HOME    (CODE)
                                    694 ;--------------------------------------------------------
                                    695 ; code
                                    696 ;--------------------------------------------------------
                                    697 	.area CSEG    (CODE)
                                    698 ;------------------------------------------------------------
                                    699 ;Allocation info for local variables in function 'IS_KEYEVENT'
                                    700 ;------------------------------------------------------------
                                    701 ;event         Allocated with name '_IS_KEYEVENT_PARM_1'
                                    702 ;------------------------------------------------------------
                                    703 ;	quantum/keyboard.c:36: bool IS_KEYEVENT(const keyevent_t event) {
                                    704 ;	-----------------------------------------
                           000007   705 	ar7 = 0x07
                           000006   706 	ar6 = 0x06
                           000005   707 	ar5 = 0x05
                           000004   708 	ar4 = 0x04
                           000003   709 	ar3 = 0x03
                           000002   710 	ar2 = 0x02
                           000001   711 	ar1 = 0x01
                           000000   712 	ar0 = 0x00
                                    713 ;	 function last_matrix_activity_trigger
                                    714 ;	-----------------------------------------
      009449                        715 _last_matrix_activity_trigger:
                                    716 ;	quantum/keyboard.c:190: last_matrix_modification_time = last_input_modification_time = sync_timer_read32();
      009449 12 4B 50         [24]  717 	lcall	_timer_read32
      00944C 12 51 5F         [24]  718 	lcall	_ak820_outline_0056
      00944F 90 0E 0C         [24]  719 	mov	dptr,#_last_input_modification_time
      009452 12 92 0E         [24]  720 	lcall	_ak820_outline_0006
      009455 90 0E 10         [24]  721 	mov	dptr,#_last_matrix_modification_time
      009458 12 92 0E         [24]  722 	lcall	_ak820_outline_0006
                                    723 ;	quantum/keyboard.c:191: }
      00945B 22               [24]  724 	ret
                                    725 ;------------------------------------------------------------
                                    726 ;Allocation info for local variables in function 'last_encoder_activity_time'
                                    727 ;------------------------------------------------------------
                                    728 ;	quantum/keyboard.c:194: uint32_t        last_encoder_activity_time(void) {
                                    729 ;	-----------------------------------------
                                    730 ;	 function last_encoder_activity_trigger
                                    731 ;	-----------------------------------------
      00945C                        732 _last_encoder_activity_trigger:
                                    733 ;	quantum/keyboard.c:201: last_encoder_modification_time = last_input_modification_time = sync_timer_read32();
      00945C 12 4B 50         [24]  734 	lcall	_timer_read32
      00945F 12 51 5F         [24]  735 	lcall	_ak820_outline_0056
      009462 90 0E 0C         [24]  736 	mov	dptr,#_last_input_modification_time
      009465 12 92 0E         [24]  737 	lcall	_ak820_outline_0006
      009468 90 0E 14         [24]  738 	mov	dptr,#_last_encoder_modification_time
      00946B 12 92 0E         [24]  739 	lcall	_ak820_outline_0006
                                    740 ;	quantum/keyboard.c:202: }
      00946E 22               [24]  741 	ret
                                    742 ;------------------------------------------------------------
                                    743 ;Allocation info for local variables in function 'last_pointing_device_activity_time'
                                    744 ;------------------------------------------------------------
                                    745 ;	quantum/keyboard.c:205: uint32_t        last_pointing_device_activity_time(void) {
                                    746 ;	-----------------------------------------
                                    747 ;	 function keyboard_post_init_kb
                                    748 ;	-----------------------------------------
      00946F                        749 _keyboard_post_init_kb:
                                    750 ;	quantum/keyboard.c:345: keyboard_post_init_user();
                                    751 ;	quantum/keyboard.c:346: }
      00946F 02 98 77         [24]  752 	ljmp	_keyboard_post_init_user
                                    753 ;------------------------------------------------------------
                                    754 ;Allocation info for local variables in function 'matrix_can_read'
                                    755 ;------------------------------------------------------------
                                    756 ;	quantum/keyboard.c:352: __attribute__((weak)) bool matrix_can_read(void) {
                                    757 ;	-----------------------------------------
                                    758 ;	 function matrix_can_read
                                    759 ;	-----------------------------------------
      009472                        760 _matrix_can_read:
                                    761 ;	quantum/keyboard.c:353: return true;
      009472 75 82 01         [24]  762 	mov	dpl, #0x01
                                    763 ;	quantum/keyboard.c:354: }
      009475 22               [24]  764 	ret
                                    765 ;------------------------------------------------------------
                                    766 ;Allocation info for local variables in function 'keyboard_setup'
                                    767 ;------------------------------------------------------------
                                    768 ;	quantum/keyboard.c:360: void keyboard_setup(void) {
                                    769 ;	-----------------------------------------
                                    770 ;	 function keyboard_setup
                                    771 ;	-----------------------------------------
      009476                        772 _keyboard_setup:
                                    773 ;	quantum/keyboard.c:361: print_set_sendchar(sendchar);
      009476 90 99 DF         [24]  774 	mov	dptr,#_sendchar
      009479 12 99 B3         [24]  775 	lcall	_print_set_sendchar
                                    776 ;	quantum/keyboard.c:363: eeprom_driver_init();
      00947C 12 40 4F         [24]  777 	lcall	_eeprom_driver_init
                                    778 ;	quantum/keyboard.c:366: vial_init();
                                    779 ;	quantum/keyboard.c:372: keyboard_pre_init_kb();
                                    780 ;	quantum/keyboard.c:373: }
      00947F 02 AF 0B         [24]  781 	ljmp	_vial_init
                                    782 ;------------------------------------------------------------
                                    783 ;Allocation info for local variables in function 'is_keyboard_master'
                                    784 ;------------------------------------------------------------
                                    785 ;	quantum/keyboard.c:381: __attribute__((weak)) bool is_keyboard_master(void) {
                                    786 ;	-----------------------------------------
                                    787 ;	 function is_keyboard_master
                                    788 ;	-----------------------------------------
      009482                        789 _is_keyboard_master:
                                    790 ;	quantum/keyboard.c:382: return true;
      009482 75 82 01         [24]  791 	mov	dpl, #0x01
                                    792 ;	quantum/keyboard.c:383: }
      009485 22               [24]  793 	ret
                                    794 ;------------------------------------------------------------
                                    795 ;Allocation info for local variables in function 'is_keyboard_left'
                                    796 ;------------------------------------------------------------
                                    797 ;	quantum/keyboard.c:389: __attribute__((weak)) bool is_keyboard_left(void) {
                                    798 ;	-----------------------------------------
                                    799 ;	 function should_process_keypress
                                    800 ;	-----------------------------------------
      009486                        801 _should_process_keypress:
                                    802 ;	quantum/keyboard.c:401: return is_keyboard_master();
                                    803 ;	quantum/keyboard.c:402: }
      009486 02 94 82         [24]  804 	ljmp	_is_keyboard_master
                                    805 ;------------------------------------------------------------
                                    806 ;Allocation info for local variables in function 'housekeeping_task_kb'
                                    807 ;------------------------------------------------------------
                                    808 ;	quantum/keyboard.c:409: __attribute__((weak)) void housekeeping_task_kb(void) {}
                                    809 ;	-----------------------------------------
                                    810 ;	 function housekeeping_task
                                    811 ;	-----------------------------------------
      009489                        812 _housekeeping_task:
                                    813 ;	quantum/keyboard.c:424: housekeeping_task_user();
                                    814 ;	quantum/keyboard.c:425: }
      009489 22               [24]  815 	ret
                                    816 ;------------------------------------------------------------
                                    817 ;Allocation info for local variables in function 'quantum_init'
                                    818 ;------------------------------------------------------------
                                    819 ;	quantum/keyboard.c:431: void quantum_init(void) {
                                    820 ;	-----------------------------------------
                                    821 ;	 function quantum_init
                                    822 ;	-----------------------------------------
      00948A                        823 _quantum_init:
                                    824 ;	quantum/keyboard.c:432: magic();
      00948A 12 83 47         [24]  825 	lcall	_magic
                                    826 ;	quantum/keyboard.c:433: led_init_ports();
      00948D 12 99 49         [24]  827 	lcall	_led_init_ports
                                    828 ;	quantum/keyboard.c:444: rgb_matrix_init();
                                    829 ;	quantum/keyboard.c:452: }
      009490 02 53 06         [24]  830 	ljmp	_rgb_matrix_init
                                    831 ;------------------------------------------------------------
                                    832 ;Allocation info for local variables in function 'keyboard_init'
                                    833 ;------------------------------------------------------------
                                    834 ;	quantum/keyboard.c:458: void keyboard_init(void) {
                                    835 ;	-----------------------------------------
                                    836 ;	 function keyboard_init
                                    837 ;	-----------------------------------------
      009493                        838 _keyboard_init:
                                    839 ;	quantum/keyboard.c:459: timer_init();
      009493 12 4B 12         [24]  840 	lcall	_timer_init
                                    841 ;	quantum/keyboard.c:462: via_init();
      009496 12 A7 DB         [24]  842 	lcall	_via_init
                                    843 ;	quantum/keyboard.c:468: encoder_init();
      009499 12 92 51         [24]  844 	lcall	_encoder_init
                                    845 ;	quantum/keyboard.c:470: matrix_init();
      00949C 12 5C 14         [24]  846 	lcall	_matrix_init
                                    847 ;	quantum/keyboard.c:471: quantum_init();
      00949F 12 94 8A         [24]  848 	lcall	_quantum_init
                                    849 ;	quantum/keyboard.c:521: keyboard_post_init_kb(); /* Always keep this last */
                                    850 ;	quantum/keyboard.c:522: }
      0094A2 02 94 6F         [24]  851 	ljmp	_keyboard_post_init_kb
                                    852 ;------------------------------------------------------------
                                    853 ;Allocation info for local variables in function 'switch_events'
                                    854 ;------------------------------------------------------------
                                    855 ;col           Allocated with name '_switch_events_PARM_2'
                                    856 ;pressed       Allocated with name '_switch_events_PARM_3'
                                    857 ;row           Allocated with name '_switch_events_row_10000_492'
                                    858 ;------------------------------------------------------------
                                    859 ;	quantum/keyboard.c:529: void switch_events(uint8_t row, uint8_t col, bool pressed) {
                                    860 ;	-----------------------------------------
                                    861 ;	 function switch_events
                                    862 ;	-----------------------------------------
      0094A5                        863 _switch_events:
      0094A5 E5 82            [12]  864 	mov	a,dpl
      0094A7 90 0B 72         [24]  865 	mov	dptr,#_switch_events_row_10000_492
      0094AA F0               [24]  866 	movx	@dptr,a
                                    867 ;	quantum/keyboard.c:534: process_rgb_matrix(row, col, pressed);
      0094AB E0               [24]  868 	movx	a,@dptr
      0094AC FF               [12]  869 	mov	r7,a
      0094AD 90 0B 70         [24]  870 	mov	dptr,#_switch_events_PARM_2
      0094B0 E0               [24]  871 	movx	a,@dptr
      0094B1 FE               [12]  872 	mov	r6,a
      0094B2 90 0B 71         [24]  873 	mov	dptr,#_switch_events_PARM_3
      0094B5 E0               [24]  874 	movx	a,@dptr
      0094B6 FD               [12]  875 	mov	r5,a
      0094B7 90 07 3B         [24]  876 	mov	dptr,#_process_rgb_matrix_PARM_2
      0094BA EE               [12]  877 	mov	a,r6
      0094BB F0               [24]  878 	movx	@dptr,a
      0094BC 90 07 3C         [24]  879 	mov	dptr,#_process_rgb_matrix_PARM_3
      0094BF ED               [12]  880 	mov	a,r5
      0094C0 F0               [24]  881 	movx	@dptr,a
      0094C1 8F 82            [24]  882 	mov	dpl, r7
                                    883 ;	quantum/keyboard.c:536: }
      0094C3 02 56 91         [24]  884 	ljmp	_process_rgb_matrix
                                    885 ;------------------------------------------------------------
                                    886 ;Allocation info for local variables in function 'generate_tick_event'
                                    887 ;------------------------------------------------------------
                                    888 ;last_tick     Allocated with name '_generate_tick_event_last_tick_10000_495'
                                    889 ;now           Allocated with name '_generate_tick_event_now_10000_495'
                                    890 ;dummy_event   Allocated with name '_generate_tick_event_dummy_event_30000_497'
                                    891 ;------------------------------------------------------------
                                    892 ;	quantum/keyboard.c:542: static inline void generate_tick_event(void) {
                                    893 ;	-----------------------------------------
                                    894 ;	 function matrix_task
                                    895 ;	-----------------------------------------
      0094C6                        896 _matrix_task:
                                    897 ;	quantum/keyboard.c:562: if (!matrix_can_read()) {
      0094C6 12 94 72         [24]  898 	lcall	_matrix_can_read
      0094C9 E5 82            [12]  899 	mov	a, dpl
      0094CB 70 4B            [24]  900 	jnz	00102$
                                    901 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      0094CD 12 4B 81         [24]  902 	lcall	_timer_read
      0094D0 12 45 A7         [24]  903 	lcall	_ak820_outline_0133
                                    904 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      0094D3 90 0B 75         [24]  905 	mov	dptr,#_matrix_task_last_tick_60000_524
      0094D6 12 3A A3         [24]  906 	lcall	_ak820_outline_0059
      0094D9 EE               [12]  907 	mov	a,r6
      0094DA C3               [12]  908 	clr	c
      0094DB 9C               [12]  909 	subb	a,r4
      0094DC FC               [12]  910 	mov	r4,a
      0094DD EF               [12]  911 	mov	a,r7
      0094DE 9D               [12]  912 	subb	a,r5
      0094DF 4C               [12]  913 	orl	a,r4
      0094E0 60 32            [24]  914 	jz	00120$
                                    915 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      0094E2 90 0B 77         [24]  916 	mov	dptr,#_matrix_task_dummy_event_70000_525
      0094E5 E4               [12]  917 	clr	a
      0094E6 F0               [24]  918 	movx	@dptr,a
      0094E7 90 0B 78         [24]  919 	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0001)
      0094EA F0               [24]  920 	movx	@dptr,a
      0094EB 12 4B 81         [24]  921 	lcall	_timer_read
      0094EE 12 45 B8         [24]  922 	lcall	_ak820_outline_0149
      0094F1 90 0B 79         [24]  923 	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0002)
      0094F4 12 3A A9         [24]  924 	lcall	_ak820_outline_0072
      0094F7 90 0B 7B         [24]  925 	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0004)
      0094FA E4               [12]  926 	clr	a
      0094FB F0               [24]  927 	movx	@dptr,a
      0094FC 90 0B 7C         [24]  928 	mov	dptr,#(_matrix_task_dummy_event_70000_525 + 0x0005)
      0094FF F0               [24]  929 	movx	@dptr,a
                                    930 ;	quantum/keyboard.c:549: AK820_ACTION_EXEC(dummy_event);
      009500 90 0B 77         [24]  931 	mov	dptr,#_matrix_task_dummy_event_70000_525
      009503 C0 07            [24]  932 	push	ar7
      009505 C0 06            [24]  933 	push	ar6
      009507 12 72 BF         [24]  934 	lcall	_ak820_action_exec
      00950A D0 06            [24]  935 	pop	ar6
      00950C D0 07            [24]  936 	pop	ar7
                                    937 ;	quantum/keyboard.c:550: last_tick = now;
      00950E 90 0B 75         [24]  938 	mov	dptr,#_matrix_task_last_tick_60000_524
      009511 12 4A CE         [24]  939 	lcall	_ak820_outline_0058
                                    940 ;	quantum/keyboard.c:563: generate_tick_event();
      009514                        941 00120$:
                                    942 ;	quantum/keyboard.c:564: return false;
      009514 75 82 00         [24]  943 	mov	dpl, #0x00
      009517 22               [24]  944 	ret
      009518                        945 00102$:
                                    946 ;	quantum/keyboard.c:569: matrix_scan();
      009518 12 5C 3D         [24]  947 	lcall	_matrix_scan
                                    948 ;	quantum/keyboard.c:573: vial_unlock_task();
      00951B 12 AE 76         [24]  949 	lcall	_vial_unlock_task
                                    950 ;	quantum/keyboard.c:575: bool matrix_changed = false;
      00951E 90 0B 8D         [24]  951 	mov	dptr,#_matrix_task_matrix_changed_10002_503
      009521 E4               [12]  952 	clr	a
      009522 F0               [24]  953 	movx	@dptr,a
                                    954 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      009523 FF               [12]  955 	mov	r7,a
      009524                        956 00127$:
      009524 BF 10 00         [24]  957 	cjne	r7,#0x10,00247$
      009527                        958 00247$:
      009527 50 1F            [24]  959 	jnc	00103$
      009529 90 0B 8D         [24]  960 	mov	dptr,#_matrix_task_matrix_changed_10002_503
      00952C E0               [24]  961 	movx	a,@dptr
      00952D 70 19            [24]  962 	jnz	00103$
                                    963 ;	quantum/keyboard.c:577: matrix_changed |= matrix_previous[row] ^ matrix_get_row(row);
      00952F EF               [12]  964 	mov	a,r7
      009530 12 96 8B         [24]  965 	lcall	_ak820_outline_0066
      009533 E0               [24]  966 	movx	a,@dptr
      009534 FE               [12]  967 	mov	r6,a
      009535 8F 82            [24]  968 	mov	dpl, r7
      009537 12 5B C9         [24]  969 	lcall	_matrix_get_row
      00953A E5 82            [12]  970 	mov	a,dpl
      00953C 6E               [12]  971 	xrl	a,r6
                                    972 ;	assignBit
      00953D 90 0B 8D         [24]  973 	mov	dptr,#_matrix_task_matrix_changed_10002_503
      009540 24 FF            [12]  974 	add	a,#0xff
      009542 E4               [12]  975 	clr	a
      009543 33               [12]  976 	rlc	a
      009544 F0               [24]  977 	movx	@dptr,a
                                    978 ;	quantum/keyboard.c:576: for (uint8_t row = 0; row < MATRIX_ROWS && !matrix_changed; row++) {
      009545 0F               [12]  979 	inc	r7
      009546 80 DC            [24]  980 	sjmp	00127$
      009548                        981 00103$:
                                    982 ;	quantum/keyboard.c:583: if (!matrix_changed) {
      009548 90 0B 8D         [24]  983 	mov	dptr,#_matrix_task_matrix_changed_10002_503
      00954B E0               [24]  984 	movx	a,@dptr
      00954C 70 4B            [24]  985 	jnz	00105$
                                    986 ;	quantum/keyboard.c:545: const uint16_t  now       = timer_read();
      00954E 12 4B 81         [24]  987 	lcall	_timer_read
      009551 12 45 A7         [24]  988 	lcall	_ak820_outline_0133
                                    989 ;	quantum/keyboard.c:546: if (TIMER_DIFF_16(now, last_tick) != 0) {
      009554 90 0B 8E         [24]  990 	mov	dptr,#_matrix_task_last_tick_60002_528
      009557 12 3A A3         [24]  991 	lcall	_ak820_outline_0059
      00955A EE               [12]  992 	mov	a,r6
      00955B C3               [12]  993 	clr	c
      00955C 9C               [12]  994 	subb	a,r4
      00955D FC               [12]  995 	mov	r4,a
      00955E EF               [12]  996 	mov	a,r7
      00955F 9D               [12]  997 	subb	a,r5
      009560 4C               [12]  998 	orl	a,r4
      009561 60 32            [24]  999 	jz	00123$
                                   1000 ;	quantum/keyboard.c:548: MAKE_TICK_EVENT;
      009563 90 0B 90         [24] 1001 	mov	dptr,#_matrix_task_dummy_event_70002_529
      009566 E4               [12] 1002 	clr	a
      009567 F0               [24] 1003 	movx	@dptr,a
      009568 90 0B 91         [24] 1004 	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0001)
      00956B F0               [24] 1005 	movx	@dptr,a
      00956C 12 4B 81         [24] 1006 	lcall	_timer_read
      00956F 12 45 B8         [24] 1007 	lcall	_ak820_outline_0149
      009572 90 0B 92         [24] 1008 	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0002)
      009575 12 3A A9         [24] 1009 	lcall	_ak820_outline_0072
      009578 90 0B 94         [24] 1010 	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0004)
      00957B E4               [12] 1011 	clr	a
      00957C F0               [24] 1012 	movx	@dptr,a
      00957D 90 0B 95         [24] 1013 	mov	dptr,#(_matrix_task_dummy_event_70002_529 + 0x0005)
      009580 F0               [24] 1014 	movx	@dptr,a
                                   1015 ;	quantum/keyboard.c:549: AK820_ACTION_EXEC(dummy_event);
      009581 90 0B 90         [24] 1016 	mov	dptr,#_matrix_task_dummy_event_70002_529
      009584 C0 07            [24] 1017 	push	ar7
      009586 C0 06            [24] 1018 	push	ar6
      009588 12 72 BF         [24] 1019 	lcall	_ak820_action_exec
      00958B D0 06            [24] 1020 	pop	ar6
      00958D D0 07            [24] 1021 	pop	ar7
                                   1022 ;	quantum/keyboard.c:550: last_tick = now;
      00958F 90 0B 8E         [24] 1023 	mov	dptr,#_matrix_task_last_tick_60002_528
      009592 12 4A CE         [24] 1024 	lcall	_ak820_outline_0058
                                   1025 ;	quantum/keyboard.c:584: generate_tick_event();
      009595                       1026 00123$:
                                   1027 ;	quantum/keyboard.c:585: return matrix_changed;
      009595 75 82 00         [24] 1028 	mov	dpl, #0x00
      009598 22               [24] 1029 	ret
      009599                       1030 00105$:
                                   1031 ;	quantum/keyboard.c:588: if (debug_config.matrix) {
      009599 90 0E 20         [24] 1032 	mov	dptr,#_debug_config
      00959C E0               [24] 1033 	movx	a,@dptr
      00959D 30 E1 03         [24] 1034 	jnb	acc.1,00107$
                                   1035 ;	quantum/keyboard.c:589: matrix_print();
      0095A0 12 5C 69         [24] 1036 	lcall	_matrix_print
      0095A3                       1037 00107$:
                                   1038 ;	quantum/keyboard.c:592: const bool process_keypress = should_process_keypress();
      0095A3 12 94 86         [24] 1039 	lcall	_should_process_keypress
      0095A6 AF 82            [24] 1040 	mov	r7, dpl
                                   1041 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      0095A8 7E 00            [12] 1042 	mov	r6,#0x00
      0095AA                       1043 00133$:
      0095AA BE 10 00         [24] 1044 	cjne	r6,#0x10,00253$
      0095AD                       1045 00253$:
      0095AD 40 03            [24] 1046 	jc	00254$
      0095AF 02 96 67         [24] 1047 	ljmp	00117$
      0095B2                       1048 00254$:
                                   1049 ;	quantum/keyboard.c:595: const matrix_row_t current_row = matrix_get_row(row);
      0095B2 8E 82            [24] 1050 	mov	dpl, r6
      0095B4 12 5B C9         [24] 1051 	lcall	_matrix_get_row
      0095B7 AD 82            [24] 1052 	mov	r5, dpl
                                   1053 ;	quantum/keyboard.c:596: const matrix_row_t row_changes = current_row ^ matrix_previous[row];
      0095B9 EE               [12] 1054 	mov	a,r6
      0095BA 12 96 8B         [24] 1055 	lcall	_ak820_outline_0066
      0095BD E0               [24] 1056 	movx	a,@dptr
      0095BE FC               [12] 1057 	mov	r4,a
      0095BF ED               [12] 1058 	mov	a,r5
      0095C0 62 04            [12] 1059 	xrl	ar4,a
      0095C2 90 0B 96         [24] 1060 	mov	dptr,#_matrix_task_row_changes_30003_512
      0095C5 EC               [12] 1061 	mov	a,r4
      0095C6 F0               [24] 1062 	movx	@dptr,a
                                   1063 ;	quantum/keyboard.c:598: if (!row_changes || has_ghost_in_row(row, current_row)) {
      0095C7 EC               [12] 1064 	mov	a,r4
      0095C8 70 03            [24] 1065 	jnz	00255$
      0095CA 02 96 63         [24] 1066 	ljmp	00116$
      0095CD                       1067 00255$:
                                   1068 ;	quantum/keyboard.c:602: matrix_row_t col_mask = 1;
      0095CD 90 0B 97         [24] 1069 	mov	dptr,#_matrix_task_col_mask_30004_515
      0095D0 74 01            [12] 1070 	mov	a,#0x01
      0095D2 F0               [24] 1071 	movx	@dptr,a
                                   1072 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      0095D3 7C 00            [12] 1073 	mov	r4,#0x00
      0095D5                       1074 00130$:
      0095D5 BC 08 00         [24] 1075 	cjne	r4,#0x08,00256$
      0095D8                       1076 00256$:
      0095D8 40 03            [24] 1077 	jc	00257$
      0095DA 02 96 5D         [24] 1078 	ljmp	00115$
      0095DD                       1079 00257$:
                                   1080 ;	quantum/keyboard.c:604: if (row_changes & col_mask) {
      0095DD 90 0B 96         [24] 1081 	mov	dptr,#_matrix_task_row_changes_30003_512
      0095E0 E0               [24] 1082 	movx	a,@dptr
      0095E1 FB               [12] 1083 	mov	r3,a
      0095E2 90 0B 97         [24] 1084 	mov	dptr,#_matrix_task_col_mask_30004_515
      0095E5 E0               [24] 1085 	movx	a,@dptr
      0095E6 FA               [12] 1086 	mov	r2,a
      0095E7 5B               [12] 1087 	anl	a,r3
      0095E8 60 68            [24] 1088 	jz	00131$
                                   1089 ;	quantum/keyboard.c:605: const bool key_pressed = current_row & col_mask;
      0095EA ED               [12] 1090 	mov	a,r5
      0095EB 52 02            [12] 1091 	anl	ar2,a
                                   1092 ;	assignBit
      0095ED EA               [12] 1093 	mov	a,r2
      0095EE 24 FF            [12] 1094 	add	a,#0xff
      0095F0 E4               [12] 1095 	clr	a
      0095F1 33               [12] 1096 	rlc	a
      0095F2 FA               [12] 1097 	mov	r2,a
                                   1098 ;	quantum/keyboard.c:607: if (process_keypress) {
      0095F3 EF               [12] 1099 	mov	a,r7
      0095F4 60 3D            [24] 1100 	jz	00112$
                                   1101 ;	quantum/keyboard.c:609: MAKE_KEYEVENT(row, col, key_pressed);
      0095F6 90 0B 98         [24] 1102 	mov	dptr,#_matrix_task_dummy_event_90004_521
      0095F9 EC               [12] 1103 	mov	a,r4
      0095FA F0               [24] 1104 	movx	@dptr,a
      0095FB 90 0B 99         [24] 1105 	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0001)
      0095FE EE               [12] 1106 	mov	a,r6
      0095FF F0               [24] 1107 	movx	@dptr,a
      009600 12 4B 81         [24] 1108 	lcall	_timer_read
      009603 A9 82            [24] 1109 	mov	r1, dpl
      009605 AB 83            [24] 1110 	mov	r3, dph
      009607 90 0B 9A         [24] 1111 	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0002)
      00960A E9               [12] 1112 	mov	a,r1
      00960B 12 79 71         [24] 1113 	lcall	_ak820_outline_0187
      00960E 90 0B 9C         [24] 1114 	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0004)
      009611 74 01            [12] 1115 	mov	a,#0x01
      009613 F0               [24] 1116 	movx	@dptr,a
      009614 90 0B 9D         [24] 1117 	mov	dptr,#(_matrix_task_dummy_event_90004_521 + 0x0005)
      009617 EA               [12] 1118 	mov	a,r2
      009618 F0               [24] 1119 	movx	@dptr,a
                                   1120 ;	quantum/keyboard.c:610: AK820_ACTION_EXEC(dummy_event);
      009619 90 0B 98         [24] 1121 	mov	dptr,#_matrix_task_dummy_event_90004_521
      00961C C0 07            [24] 1122 	push	ar7
      00961E C0 06            [24] 1123 	push	ar6
      009620 C0 05            [24] 1124 	push	ar5
      009622 C0 04            [24] 1125 	push	ar4
      009624 C0 02            [24] 1126 	push	ar2
      009626 12 72 BF         [24] 1127 	lcall	_ak820_action_exec
      009629 D0 02            [24] 1128 	pop	ar2
      00962B D0 04            [24] 1129 	pop	ar4
      00962D D0 05            [24] 1130 	pop	ar5
      00962F D0 06            [24] 1131 	pop	ar6
      009631 D0 07            [24] 1132 	pop	ar7
      009633                       1133 00112$:
                                   1134 ;	quantum/keyboard.c:613: switch_events(row, col, key_pressed);
      009633 90 0B 70         [24] 1135 	mov	dptr,#_switch_events_PARM_2
      009636 EC               [12] 1136 	mov	a,r4
      009637 F0               [24] 1137 	movx	@dptr,a
      009638 90 0B 71         [24] 1138 	mov	dptr,#_switch_events_PARM_3
      00963B EA               [12] 1139 	mov	a,r2
      00963C F0               [24] 1140 	movx	@dptr,a
      00963D 8E 82            [24] 1141 	mov	dpl, r6
      00963F C0 07            [24] 1142 	push	ar7
      009641 C0 06            [24] 1143 	push	ar6
      009643 C0 05            [24] 1144 	push	ar5
      009645 C0 04            [24] 1145 	push	ar4
      009647 12 94 A5         [24] 1146 	lcall	_switch_events
      00964A D0 04            [24] 1147 	pop	ar4
      00964C D0 05            [24] 1148 	pop	ar5
      00964E D0 06            [24] 1149 	pop	ar6
      009650 D0 07            [24] 1150 	pop	ar7
      009652                       1151 00131$:
                                   1152 ;	quantum/keyboard.c:603: for (uint8_t col = 0; col < MATRIX_COLS; col++, col_mask <<= 1) {
      009652 0C               [12] 1153 	inc	r4
      009653 90 0B 97         [24] 1154 	mov	dptr,#_matrix_task_col_mask_30004_515
      009656 E0               [24] 1155 	movx	a,@dptr
      009657 25 E0            [12] 1156 	add	a,acc
      009659 F0               [24] 1157 	movx	@dptr,a
      00965A 02 95 D5         [24] 1158 	ljmp	00130$
      00965D                       1159 00115$:
                                   1160 ;	quantum/keyboard.c:617: matrix_previous[row] = current_row;
      00965D EE               [12] 1161 	mov	a,r6
      00965E 12 96 8B         [24] 1162 	lcall	_ak820_outline_0066
      009661 ED               [12] 1163 	mov	a,r5
      009662 F0               [24] 1164 	movx	@dptr,a
      009663                       1165 00116$:
                                   1166 ;	quantum/keyboard.c:594: for (uint8_t row = 0; row < MATRIX_ROWS; row++) {
      009663 0E               [12] 1167 	inc	r6
      009664 02 95 AA         [24] 1168 	ljmp	00133$
      009667                       1169 00117$:
                                   1170 ;	quantum/keyboard.c:620: return matrix_changed;
      009667 75 82 01         [24] 1171 	mov	dpl, #0x01
                                   1172 ;	quantum/keyboard.c:621: }
      00966A 22               [24] 1173 	ret
                                   1174 ;------------------------------------------------------------
                                   1175 ;Allocation info for local variables in function 'quantum_task'
                                   1176 ;------------------------------------------------------------
                                   1177 ;	quantum/keyboard.c:627: void quantum_task(void) {
                                   1178 ;	-----------------------------------------
                                   1179 ;	 function quantum_task
                                   1180 ;	-----------------------------------------
      00966B                       1181 _quantum_task:
                                   1182 ;	quantum/keyboard.c:694: caps_word_task();
                                   1183 ;	quantum/keyboard.c:700: }
      00966B 02 2E FF         [24] 1184 	ljmp	_caps_word_task
                                   1185 ;------------------------------------------------------------
                                   1186 ;Allocation info for local variables in function 'keyboard_task'
                                   1187 ;------------------------------------------------------------
                                   1188 ;activity_has_occurred Allocated with name '_keyboard_task_activity_has_occurred_10000_536'
                                   1189 ;------------------------------------------------------------
                                   1190 ;	quantum/keyboard.c:703: void keyboard_task(void) {
                                   1191 ;	-----------------------------------------
                                   1192 ;	 function keyboard_task
                                   1193 ;	-----------------------------------------
      00966E                       1194 _keyboard_task:
                                   1195 ;	quantum/keyboard.c:705: if (matrix_task()) {
      00966E 12 94 C6         [24] 1196 	lcall	_matrix_task
      009671 E5 82            [12] 1197 	mov	a, dpl
      009673 60 03            [24] 1198 	jz	00102$
                                   1199 ;	quantum/keyboard.c:706: last_matrix_activity_trigger();
      009675 12 94 49         [24] 1200 	lcall	_last_matrix_activity_trigger
                                   1201 ;	quantum/keyboard.c:707: activity_has_occurred = true;
      009678                       1202 00102$:
                                   1203 ;	quantum/keyboard.c:710: quantum_task();
      009678 12 96 6B         [24] 1204 	lcall	_quantum_task
                                   1205 ;	quantum/keyboard.c:724: rgb_matrix_task();
      00967B 12 54 2C         [24] 1206 	lcall	_rgb_matrix_task
                                   1207 ;	quantum/keyboard.c:734: if (encoder_read()) {
      00967E 12 93 AC         [24] 1208 	lcall	_encoder_read
      009681 E5 82            [12] 1209 	mov	a, dpl
      009683 60 03            [24] 1210 	jz	00104$
                                   1211 ;	quantum/keyboard.c:735: last_encoder_activity_trigger();
      009685 12 94 5C         [24] 1212 	lcall	_last_encoder_activity_trigger
                                   1213 ;	quantum/keyboard.c:736: activity_has_occurred = true;
      009688                       1214 00104$:
                                   1215 ;	quantum/keyboard.c:790: led_task();
                                   1216 ;	quantum/keyboard.c:791: }
      009688 02 99 6B         [24] 1217 	ljmp	_led_task
                                   1218 	.area CSEG    (CODE)
                                   1219 	.area CONST   (CODE)
                                   1220 	.area XINIT   (CODE)
      00C2FE                       1221 __xinit__last_input_modification_time:
      00C2FE 00 00 00 00           1222 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C302                       1223 __xinit__last_matrix_modification_time:
      00C302 00 00 00 00           1224 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C306                       1225 __xinit__last_encoder_modification_time:
      00C306 00 00 00 00           1226 	.byte #0x00, #0x00, #0x00, #0x00	; 0
      00C30A                       1227 __xinit__last_pointing_device_modification_time:
      00C30A 00 00 00 00           1228 	.byte #0x00, #0x00, #0x00, #0x00	; 0
                                   1229 	.area CABS    (ABS,CODE)
                                   1230 
                                   1231 ; Experimental exact instruction outlining.
                                   1232 	.globl _ak820_outline_0006
                                   1233 	.globl _ak820_outline_0056
                                   1234 	.globl _ak820_outline_0058
                                   1235 	.globl _ak820_outline_0059
                                   1236 	.globl _ak820_outline_0066
                                   1237 	.globl _ak820_outline_0072
                                   1238 	.globl _ak820_outline_0133
                                   1239 	.globl _ak820_outline_0149
                                   1240 	.globl _ak820_outline_0187
                                   1241 
                                   1242 	.area CSEG (CODE)
                                   1243 ; function ak820_outline_0066
      00968B                       1244 _ak820_outline_0066:
      00968B 24 7D            [12] 1245 	add	a,#_matrix_task_matrix_previous_10001_502
      00968D F5 82            [12] 1246 	mov	dpl,a
      00968F E4               [12] 1247 	clr	a
      009690 34 0B            [12] 1248 	addc	a,#(_matrix_task_matrix_previous_10001_502>>8)
      009692 F5 83            [12] 1249 	mov	dph,a
      009694 22               [24] 1250 	ret
