                                      1 ;--------------------------------------------------------
                                      2 ; File Created by SDCC : free open source ISO C Compiler
                                      3 ; Version 4.6.0 #16555 (Linux)
                                      4 ;--------------------------------------------------------
                                      5 	.module ak820_tap_dance
                                      6 	
                                      7 	.optsdcc -mmcs51 --model-large
                                      8 ;--------------------------------------------------------
                                      9 ; Public variables in this module
                                     10 ;--------------------------------------------------------
                                     11 	.globl _get_repeat_key_count
                                     12 	.globl _dynamic_keymap_get_tap_dance
                                     13 	.globl _process_record
                                     14 	.globl _ADC_START
                                     15 	.globl _S0_R_FIFO
                                     16 	.globl _S0_T_FIFO
                                     17 	.globl _S0_FREE
                                     18 	.globl _S0_IF_BYTE
                                     19 	.globl _S0_IF_FIRST
                                     20 	.globl _S0_IF_OV
                                     21 	.globl _S0_FST_ACT
                                     22 	.globl _CP_RL2
                                     23 	.globl _C_T2
                                     24 	.globl _TR2
                                     25 	.globl _EXEN2
                                     26 	.globl _TCLK
                                     27 	.globl _RCLK
                                     28 	.globl _EXF2
                                     29 	.globl _CAP1F
                                     30 	.globl _TF2
                                     31 	.globl _RI
                                     32 	.globl _TI
                                     33 	.globl _RB8
                                     34 	.globl _TB8
                                     35 	.globl _REN
                                     36 	.globl _SM2
                                     37 	.globl _SM1
                                     38 	.globl _SM0
                                     39 	.globl _IT0
                                     40 	.globl _IE0
                                     41 	.globl _IT1
                                     42 	.globl _IE1
                                     43 	.globl _TR0
                                     44 	.globl _TF0
                                     45 	.globl _TR1
                                     46 	.globl _TF1
                                     47 	.globl _P4_0
                                     48 	.globl _P4_1
                                     49 	.globl _P4_2
                                     50 	.globl _P4_3
                                     51 	.globl _P4_4
                                     52 	.globl _P4_5
                                     53 	.globl _P4_6
                                     54 	.globl _RXD
                                     55 	.globl _TXD
                                     56 	.globl _INT0
                                     57 	.globl _INT1
                                     58 	.globl _T0
                                     59 	.globl _T1
                                     60 	.globl _MOSI1
                                     61 	.globl _MISO1
                                     62 	.globl _SCK1
                                     63 	.globl _P3_0
                                     64 	.globl _P3_1
                                     65 	.globl _P3_2
                                     66 	.globl _P3_3
                                     67 	.globl _P3_4
                                     68 	.globl _P3_5
                                     69 	.globl _P3_6
                                     70 	.globl _P3_7
                                     71 	.globl _CAP1_
                                     72 	.globl _T2_
                                     73 	.globl _CAP2_
                                     74 	.globl _T2EX_
                                     75 	.globl _RXD1
                                     76 	.globl _TXD1
                                     77 	.globl _P2_0
                                     78 	.globl _P2_1
                                     79 	.globl _P2_2
                                     80 	.globl _P2_3
                                     81 	.globl _P2_4
                                     82 	.globl _P2_5
                                     83 	.globl _P2_6
                                     84 	.globl _P2_7
                                     85 	.globl _AIN0
                                     86 	.globl _AIN1
                                     87 	.globl _AIN2
                                     88 	.globl _AIN3
                                     89 	.globl _AIN4
                                     90 	.globl _AIN5
                                     91 	.globl _AIN6
                                     92 	.globl _AIN7
                                     93 	.globl _CAP1
                                     94 	.globl _T2
                                     95 	.globl _CAP2
                                     96 	.globl _T2EX
                                     97 	.globl _INT0_
                                     98 	.globl _SCS
                                     99 	.globl _MOSI
                                    100 	.globl _MISO
                                    101 	.globl _SCK
                                    102 	.globl _RXD1_
                                    103 	.globl _TXD1_
                                    104 	.globl _P1_0
                                    105 	.globl _P1_1
                                    106 	.globl _P1_2
                                    107 	.globl _P1_3
                                    108 	.globl _P1_4
                                    109 	.globl _P1_5
                                    110 	.globl _P1_6
                                    111 	.globl _P1_7
                                    112 	.globl _AIN8
                                    113 	.globl _AIN9
                                    114 	.globl _AIN10
                                    115 	.globl _AIN11
                                    116 	.globl _AIN12
                                    117 	.globl _AIN13
                                    118 	.globl _RXD_
                                    119 	.globl _TXD_
                                    120 	.globl _SCL0
                                    121 	.globl _SDA0
                                    122 	.globl _P0_0
                                    123 	.globl _P0_1
                                    124 	.globl _P0_2
                                    125 	.globl _P0_3
                                    126 	.globl _P0_4
                                    127 	.globl _P0_5
                                    128 	.globl _P0_6
                                    129 	.globl _P0_7
                                    130 	.globl _IE_SPI0
                                    131 	.globl _IE_USB
                                    132 	.globl _IE_ADC
                                    133 	.globl _IE_UART1
                                    134 	.globl _IE_PWM_I2C
                                    135 	.globl _IE_GPIO
                                    136 	.globl _IE_WDOG
                                    137 	.globl _PX0
                                    138 	.globl _PT0
                                    139 	.globl _PX1
                                    140 	.globl _PT1
                                    141 	.globl _PS
                                    142 	.globl _PT2
                                    143 	.globl _PL_FLAG
                                    144 	.globl _PH_FLAG
                                    145 	.globl _EX0
                                    146 	.globl _ET0
                                    147 	.globl _EX1
                                    148 	.globl _ET1
                                    149 	.globl _ES
                                    150 	.globl _ET2
                                    151 	.globl _E_DIS
                                    152 	.globl _EA
                                    153 	.globl _P
                                    154 	.globl _F1
                                    155 	.globl _OV
                                    156 	.globl _RS0
                                    157 	.globl _RS1
                                    158 	.globl _F0
                                    159 	.globl _AC
                                    160 	.globl _CY
                                    161 	.globl _I2CS_INT_ST
                                    162 	.globl _I2CX_INT
                                    163 	.globl _LED_STATUS
                                    164 	.globl _LED_DMA_H
                                    165 	.globl _LED_DMA_L
                                    166 	.globl _LED_DMA
                                    167 	.globl _LED_PWM_OE
                                    168 	.globl _LED_COMMON
                                    169 	.globl _ADC_CHAN
                                    170 	.globl _ADC_DAT_H
                                    171 	.globl _ADC_DAT_L
                                    172 	.globl _ADC_DAT
                                    173 	.globl _ADC_CTRL
                                    174 	.globl _SPI1_CK_SE
                                    175 	.globl _SPI1_CTRL
                                    176 	.globl _SPI1_DATA
                                    177 	.globl _SPI1_STAT
                                    178 	.globl _SIF1
                                    179 	.globl _SBAUD1
                                    180 	.globl _SBUF1
                                    181 	.globl _SCON1
                                    182 	.globl _SPI0_SETUP
                                    183 	.globl _SPI0_CK_SE
                                    184 	.globl _SPI0_CTRL
                                    185 	.globl _SPI0_DATA
                                    186 	.globl _SPI0_STAT
                                    187 	.globl _T2CAP1H
                                    188 	.globl _T2CAP1L
                                    189 	.globl _T2CAP1
                                    190 	.globl _TH2
                                    191 	.globl _TL2
                                    192 	.globl _T2COUNT
                                    193 	.globl _RCAP2H
                                    194 	.globl _RCAP2L
                                    195 	.globl _RCAP2
                                    196 	.globl _T2MOD
                                    197 	.globl _T2CON
                                    198 	.globl _SBUF
                                    199 	.globl _SCON
                                    200 	.globl _TH1
                                    201 	.globl _TH0
                                    202 	.globl _TL1
                                    203 	.globl _TL0
                                    204 	.globl _TMOD
                                    205 	.globl _TCON
                                    206 	.globl _XBUS_AUX
                                    207 	.globl _P7
                                    208 	.globl _P6_DIR
                                    209 	.globl _P6_OUT_PU
                                    210 	.globl _P6_IN
                                    211 	.globl _P5_DIR
                                    212 	.globl _P5_OUT_PU
                                    213 	.globl _P5_IN
                                    214 	.globl _P4_LED_KEY
                                    215 	.globl _P4_DIR_PU
                                    216 	.globl _P4_MOD_OC
                                    217 	.globl _P4
                                    218 	.globl _P3_DIR_PU
                                    219 	.globl _P3_MOD_OC
                                    220 	.globl _P3
                                    221 	.globl _P2_DIR_PU
                                    222 	.globl _P2_MOD_OC
                                    223 	.globl _P2
                                    224 	.globl _P1_DIR_PU
                                    225 	.globl _P1_MOD_OC
                                    226 	.globl _P1
                                    227 	.globl _P0_DIR_PU
                                    228 	.globl _P0_MOD_OC
                                    229 	.globl _P0
                                    230 	.globl _ROM_CTRL
                                    231 	.globl _ROM_DATA_HH
                                    232 	.globl _ROM_DATA_HL
                                    233 	.globl _ROM_DATA_HI
                                    234 	.globl _ROM_ADDR_H
                                    235 	.globl _ROM_ADDR_L
                                    236 	.globl _ROM_ADDR
                                    237 	.globl _GPIO_IE
                                    238 	.globl _IP_EX
                                    239 	.globl _IE_EX
                                    240 	.globl _IP
                                    241 	.globl _IE
                                    242 	.globl _WDOG_COUNT
                                    243 	.globl _RESET_KEEP
                                    244 	.globl _WAKE_CTRL
                                    245 	.globl _CLOCK_CFG
                                    246 	.globl _POWER_CFG
                                    247 	.globl _PCON
                                    248 	.globl _GLOBAL_CFG
                                    249 	.globl _SAFE_MOD
                                    250 	.globl _DPH
                                    251 	.globl _DPL
                                    252 	.globl _SP
                                    253 	.globl _A_INV
                                    254 	.globl _B
                                    255 	.globl _ACC
                                    256 	.globl _PSW
                                    257 	.globl _ak820_tap_dance_valid
                                    258 	.globl _ak820_tap_dance_task
                                    259 	.globl _ak820_tap_dance_before
                                    260 	.globl _ak820_tap_dance_process
                                    261 	.globl _ak820_tap_dance_cancel
                                    262 ;--------------------------------------------------------
                                    263 ; special function registers
                                    264 ;--------------------------------------------------------
                                    265 	.area RSEG    (ABS,DATA)
      000000                        266 	.org 0x0000
                           0000D0   267 _PSW	=	0x00d0
                           0000E0   268 _ACC	=	0x00e0
                           0000F0   269 _B	=	0x00f0
                           0000FD   270 _A_INV	=	0x00fd
                           000081   271 _SP	=	0x0081
                           000082   272 _DPL	=	0x0082
                           000083   273 _DPH	=	0x0083
                           0000A1   274 _SAFE_MOD	=	0x00a1
                           0000B1   275 _GLOBAL_CFG	=	0x00b1
                           000087   276 _PCON	=	0x0087
                           0000BA   277 _POWER_CFG	=	0x00ba
                           0000B9   278 _CLOCK_CFG	=	0x00b9
                           0000A9   279 _WAKE_CTRL	=	0x00a9
                           0000FE   280 _RESET_KEEP	=	0x00fe
                           0000FF   281 _WDOG_COUNT	=	0x00ff
                           0000A8   282 _IE	=	0x00a8
                           0000B8   283 _IP	=	0x00b8
                           0000E8   284 _IE_EX	=	0x00e8
                           0000E9   285 _IP_EX	=	0x00e9
                           0000B2   286 _GPIO_IE	=	0x00b2
                           008584   287 _ROM_ADDR	=	0x8584
                           000084   288 _ROM_ADDR_L	=	0x0084
                           000085   289 _ROM_ADDR_H	=	0x0085
                           008F8E   290 _ROM_DATA_HI	=	0x8f8e
                           00008E   291 _ROM_DATA_HL	=	0x008e
                           00008F   292 _ROM_DATA_HH	=	0x008f
                           000086   293 _ROM_CTRL	=	0x0086
                           000080   294 _P0	=	0x0080
                           0000C4   295 _P0_MOD_OC	=	0x00c4
                           0000C5   296 _P0_DIR_PU	=	0x00c5
                           000090   297 _P1	=	0x0090
                           000092   298 _P1_MOD_OC	=	0x0092
                           000093   299 _P1_DIR_PU	=	0x0093
                           0000A0   300 _P2	=	0x00a0
                           000094   301 _P2_MOD_OC	=	0x0094
                           000095   302 _P2_DIR_PU	=	0x0095
                           0000B0   303 _P3	=	0x00b0
                           000096   304 _P3_MOD_OC	=	0x0096
                           000097   305 _P3_DIR_PU	=	0x0097
                           0000C0   306 _P4	=	0x00c0
                           0000C2   307 _P4_MOD_OC	=	0x00c2
                           0000C3   308 _P4_DIR_PU	=	0x00c3
                           0000C1   309 _P4_LED_KEY	=	0x00c1
                           0000AA   310 _P5_IN	=	0x00aa
                           0000AB   311 _P5_OUT_PU	=	0x00ab
                           0000AC   312 _P5_DIR	=	0x00ac
                           0000AD   313 _P6_IN	=	0x00ad
                           0000AE   314 _P6_OUT_PU	=	0x00ae
                           0000AF   315 _P6_DIR	=	0x00af
                           0000F1   316 _P7	=	0x00f1
                           0000A2   317 _XBUS_AUX	=	0x00a2
                           000088   318 _TCON	=	0x0088
                           000089   319 _TMOD	=	0x0089
                           00008A   320 _TL0	=	0x008a
                           00008B   321 _TL1	=	0x008b
                           00008C   322 _TH0	=	0x008c
                           00008D   323 _TH1	=	0x008d
                           000098   324 _SCON	=	0x0098
                           000099   325 _SBUF	=	0x0099
                           0000C8   326 _T2CON	=	0x00c8
                           0000C9   327 _T2MOD	=	0x00c9
                           00CBCA   328 _RCAP2	=	0xcbca
                           0000CA   329 _RCAP2L	=	0x00ca
                           0000CB   330 _RCAP2H	=	0x00cb
                           00CDCC   331 _T2COUNT	=	0xcdcc
                           0000CC   332 _TL2	=	0x00cc
                           0000CD   333 _TH2	=	0x00cd
                           00CFCE   334 _T2CAP1	=	0xcfce
                           0000CE   335 _T2CAP1L	=	0x00ce
                           0000CF   336 _T2CAP1H	=	0x00cf
                           0000F8   337 _SPI0_STAT	=	0x00f8
                           0000F9   338 _SPI0_DATA	=	0x00f9
                           0000FA   339 _SPI0_CTRL	=	0x00fa
                           0000FB   340 _SPI0_CK_SE	=	0x00fb
                           0000FC   341 _SPI0_SETUP	=	0x00fc
                           0000BC   342 _SCON1	=	0x00bc
                           0000BD   343 _SBUF1	=	0x00bd
                           0000BE   344 _SBAUD1	=	0x00be
                           0000BF   345 _SIF1	=	0x00bf
                           0000B4   346 _SPI1_STAT	=	0x00b4
                           0000B5   347 _SPI1_DATA	=	0x00b5
                           0000B6   348 _SPI1_CTRL	=	0x00b6
                           0000B7   349 _SPI1_CK_SE	=	0x00b7
                           0000F3   350 _ADC_CTRL	=	0x00f3
                           00F5F4   351 _ADC_DAT	=	0xf5f4
                           0000F4   352 _ADC_DAT_L	=	0x00f4
                           0000F5   353 _ADC_DAT_H	=	0x00f5
                           0000F6   354 _ADC_CHAN	=	0x00f6
                           0000A6   355 _LED_COMMON	=	0x00a6
                           0000A7   356 _LED_PWM_OE	=	0x00a7
                           00C7C6   357 _LED_DMA	=	0xc7c6
                           0000C6   358 _LED_DMA_L	=	0x00c6
                           0000C7   359 _LED_DMA_H	=	0x00c7
                           0000F7   360 _LED_STATUS	=	0x00f7
                           0000B3   361 _I2CX_INT	=	0x00b3
                           0000BB   362 _I2CS_INT_ST	=	0x00bb
                                    363 ;--------------------------------------------------------
                                    364 ; special function bits
                                    365 ;--------------------------------------------------------
                                    366 	.area RSEG    (ABS,DATA)
      000000                        367 	.org 0x0000
                           0000D7   368 _CY	=	0x00d7
                           0000D6   369 _AC	=	0x00d6
                           0000D5   370 _F0	=	0x00d5
                           0000D4   371 _RS1	=	0x00d4
                           0000D3   372 _RS0	=	0x00d3
                           0000D2   373 _OV	=	0x00d2
                           0000D1   374 _F1	=	0x00d1
                           0000D0   375 _P	=	0x00d0
                           0000AF   376 _EA	=	0x00af
                           0000AE   377 _E_DIS	=	0x00ae
                           0000AD   378 _ET2	=	0x00ad
                           0000AC   379 _ES	=	0x00ac
                           0000AB   380 _ET1	=	0x00ab
                           0000AA   381 _EX1	=	0x00aa
                           0000A9   382 _ET0	=	0x00a9
                           0000A8   383 _EX0	=	0x00a8
                           0000BF   384 _PH_FLAG	=	0x00bf
                           0000BE   385 _PL_FLAG	=	0x00be
                           0000BD   386 _PT2	=	0x00bd
                           0000BC   387 _PS	=	0x00bc
                           0000BB   388 _PT1	=	0x00bb
                           0000BA   389 _PX1	=	0x00ba
                           0000B9   390 _PT0	=	0x00b9
                           0000B8   391 _PX0	=	0x00b8
                           0000EF   392 _IE_WDOG	=	0x00ef
                           0000EE   393 _IE_GPIO	=	0x00ee
                           0000ED   394 _IE_PWM_I2C	=	0x00ed
                           0000EC   395 _IE_UART1	=	0x00ec
                           0000EB   396 _IE_ADC	=	0x00eb
                           0000E9   397 _IE_USB	=	0x00e9
                           0000E8   398 _IE_SPI0	=	0x00e8
                           000087   399 _P0_7	=	0x0087
                           000086   400 _P0_6	=	0x0086
                           000085   401 _P0_5	=	0x0085
                           000084   402 _P0_4	=	0x0084
                           000083   403 _P0_3	=	0x0083
                           000082   404 _P0_2	=	0x0082
                           000081   405 _P0_1	=	0x0081
                           000080   406 _P0_0	=	0x0080
                           000081   407 _SDA0	=	0x0081
                           000080   408 _SCL0	=	0x0080
                           000083   409 _TXD_	=	0x0083
                           000082   410 _RXD_	=	0x0082
                           000085   411 _AIN13	=	0x0085
                           000084   412 _AIN12	=	0x0084
                           000083   413 _AIN11	=	0x0083
                           000082   414 _AIN10	=	0x0082
                           000081   415 _AIN9	=	0x0081
                           000080   416 _AIN8	=	0x0080
                           000097   417 _P1_7	=	0x0097
                           000096   418 _P1_6	=	0x0096
                           000095   419 _P1_5	=	0x0095
                           000094   420 _P1_4	=	0x0094
                           000093   421 _P1_3	=	0x0093
                           000092   422 _P1_2	=	0x0092
                           000091   423 _P1_1	=	0x0091
                           000090   424 _P1_0	=	0x0090
                           000097   425 _TXD1_	=	0x0097
                           000096   426 _RXD1_	=	0x0096
                           000097   427 _SCK	=	0x0097
                           000096   428 _MISO	=	0x0096
                           000095   429 _MOSI	=	0x0095
                           000094   430 _SCS	=	0x0094
                           000092   431 _INT0_	=	0x0092
                           000091   432 _T2EX	=	0x0091
                           000091   433 _CAP2	=	0x0091
                           000090   434 _T2	=	0x0090
                           000090   435 _CAP1	=	0x0090
                           000097   436 _AIN7	=	0x0097
                           000096   437 _AIN6	=	0x0096
                           000095   438 _AIN5	=	0x0095
                           000094   439 _AIN4	=	0x0094
                           000093   440 _AIN3	=	0x0093
                           000092   441 _AIN2	=	0x0092
                           000091   442 _AIN1	=	0x0091
                           000090   443 _AIN0	=	0x0090
                           0000A7   444 _P2_7	=	0x00a7
                           0000A6   445 _P2_6	=	0x00a6
                           0000A5   446 _P2_5	=	0x00a5
                           0000A4   447 _P2_4	=	0x00a4
                           0000A3   448 _P2_3	=	0x00a3
                           0000A2   449 _P2_2	=	0x00a2
                           0000A1   450 _P2_1	=	0x00a1
                           0000A0   451 _P2_0	=	0x00a0
                           0000A7   452 _TXD1	=	0x00a7
                           0000A6   453 _RXD1	=	0x00a6
                           0000A5   454 _T2EX_	=	0x00a5
                           0000A5   455 _CAP2_	=	0x00a5
                           0000A4   456 _T2_	=	0x00a4
                           0000A4   457 _CAP1_	=	0x00a4
                           0000B7   458 _P3_7	=	0x00b7
                           0000B6   459 _P3_6	=	0x00b6
                           0000B5   460 _P3_5	=	0x00b5
                           0000B4   461 _P3_4	=	0x00b4
                           0000B3   462 _P3_3	=	0x00b3
                           0000B2   463 _P3_2	=	0x00b2
                           0000B1   464 _P3_1	=	0x00b1
                           0000B0   465 _P3_0	=	0x00b0
                           0000B7   466 _SCK1	=	0x00b7
                           0000B6   467 _MISO1	=	0x00b6
                           0000B5   468 _MOSI1	=	0x00b5
                           0000B5   469 _T1	=	0x00b5
                           0000B4   470 _T0	=	0x00b4
                           0000B3   471 _INT1	=	0x00b3
                           0000B2   472 _INT0	=	0x00b2
                           0000B1   473 _TXD	=	0x00b1
                           0000B0   474 _RXD	=	0x00b0
                           0000C6   475 _P4_6	=	0x00c6
                           0000C5   476 _P4_5	=	0x00c5
                           0000C4   477 _P4_4	=	0x00c4
                           0000C3   478 _P4_3	=	0x00c3
                           0000C2   479 _P4_2	=	0x00c2
                           0000C1   480 _P4_1	=	0x00c1
                           0000C0   481 _P4_0	=	0x00c0
                           00008F   482 _TF1	=	0x008f
                           00008E   483 _TR1	=	0x008e
                           00008D   484 _TF0	=	0x008d
                           00008C   485 _TR0	=	0x008c
                           00008B   486 _IE1	=	0x008b
                           00008A   487 _IT1	=	0x008a
                           000089   488 _IE0	=	0x0089
                           000088   489 _IT0	=	0x0088
                           00009F   490 _SM0	=	0x009f
                           00009E   491 _SM1	=	0x009e
                           00009D   492 _SM2	=	0x009d
                           00009C   493 _REN	=	0x009c
                           00009B   494 _TB8	=	0x009b
                           00009A   495 _RB8	=	0x009a
                           000099   496 _TI	=	0x0099
                           000098   497 _RI	=	0x0098
                           0000CF   498 _TF2	=	0x00cf
                           0000CF   499 _CAP1F	=	0x00cf
                           0000CE   500 _EXF2	=	0x00ce
                           0000CD   501 _RCLK	=	0x00cd
                           0000CC   502 _TCLK	=	0x00cc
                           0000CB   503 _EXEN2	=	0x00cb
                           0000CA   504 _TR2	=	0x00ca
                           0000C9   505 _C_T2	=	0x00c9
                           0000C8   506 _CP_RL2	=	0x00c8
                           0000FF   507 _S0_FST_ACT	=	0x00ff
                           0000FE   508 _S0_IF_OV	=	0x00fe
                           0000FD   509 _S0_IF_FIRST	=	0x00fd
                           0000FC   510 _S0_IF_BYTE	=	0x00fc
                           0000FB   511 _S0_FREE	=	0x00fb
                           0000FA   512 _S0_T_FIFO	=	0x00fa
                           0000F8   513 _S0_R_FIFO	=	0x00f8
                           0000F7   514 _ADC_START	=	0x00f7
                                    515 ;--------------------------------------------------------
                                    516 ; overlayable register banks
                                    517 ;--------------------------------------------------------
                                    518 	.area REG_BANK_0	(REL,OVR,DATA)
      000000                        519 	.ds 8
                                    520 ;--------------------------------------------------------
                                    521 ; internal ram data
                                    522 ;--------------------------------------------------------
                                    523 	.area DSEG    (DATA)
                                    524 ;--------------------------------------------------------
                                    525 ; overlayable items in internal ram
                                    526 ;--------------------------------------------------------
                                    527 ;--------------------------------------------------------
                                    528 ; indirectly addressable internal ram data
                                    529 ;--------------------------------------------------------
                                    530 	.area ISEG    (DATA)
                                    531 ;--------------------------------------------------------
                                    532 ; absolute internal ram data
                                    533 ;--------------------------------------------------------
                                    534 	.area IABS    (ABS,DATA)
                                    535 	.area IABS    (ABS,DATA)
                                    536 ;--------------------------------------------------------
                                    537 ; bit data
                                    538 ;--------------------------------------------------------
                                    539 	.area BSEG    (BIT)
      00000F                        540 _td_finish_sloc0_1_0:
      00000F                        541 	.ds 1
      000010                        542 _ak820_tap_dance_before_sloc0_1_0:
      000010                        543 	.ds 1
      000011                        544 _ak820_tap_dance_process_sloc0_1_0:
      000011                        545 	.ds 1
                                    546 ;--------------------------------------------------------
                                    547 ; paged external ram data
                                    548 ;--------------------------------------------------------
                                    549 	.area PSEG    (PAG,XDATA)
                                    550 ;--------------------------------------------------------
                                    551 ; uninitialized external ram data
                                    552 ;--------------------------------------------------------
                                    553 	.area XSEG    (XDATA)
      0005FC                        554 _td_slots:
      0005FC                        555 	.ds 32
      00061C                        556 _td_wait:
      00061C                        557 	.ds 2
      00061E                        558 _td_work:
      00061E                        559 	.ds 2
      000620                        560 _td_entry:
      000620                        561 	.ds 10
      00062A                        562 _td_time:
      00062A                        563 	.ds 2
      00062C                        564 _td_map:
      00062C                        565 	.ds 64
      00066C                        566 _td_map_get_id_10000_596:
      00066C                        567 	.ds 1
      00066D                        568 _td_map_set_PARM_2:
      00066D                        569 	.ds 1
      00066E                        570 _td_map_set_id_10000_598:
      00066E                        571 	.ds 1
      00066F                        572 _td_record:
      00066F                        573 	.ds 9
      000678                        574 _td_step:
      000678                        575 	.ds 1
      000679                        576 _ak820_td_invoking:
      000679                        577 	.ds 1
      00067A                        578 _ak820_tap_dance_valid_entry_10000_601:
      00067A                        579 	.ds 2
      00067C                        580 _ak820_tap_dance_valid_basic_30000_605:
      00067C                        581 	.ds 1
      00067D                        582 _td_finish_interrupted_10000_610:
      00067D                        583 	.ds 1
      00067E                        584 _td_finish_choice_10000_611:
      00067E                        585 	.ds 1
      00067F                        586 _td_finish_state_10000_611:
      00067F                        587 	.ds 1
      000680                        588 _td_finish_extra_10000_611:
      000680                        589 	.ds 1
      000681                        590 _ak820_tap_dance_task_now_10000_628:
      000681                        591 	.ds 2
      000683                        592 _ak820_tap_dance_task_term_10000_629:
      000683                        593 	.ds 2
      000685                        594 _ak820_tap_dance_before_event_10000_632:
      000685                        595 	.ds 2
      000687                        596 _ak820_tap_dance_process_record_10000_648:
      000687                        597 	.ds 2
                                    598 ;--------------------------------------------------------
                                    599 ; absolute external ram data
                                    600 ;--------------------------------------------------------
                                    601 	.area XABS    (ABS,XDATA)
                                    602 ;--------------------------------------------------------
                                    603 ; initialized external ram data
                                    604 ;--------------------------------------------------------
                                    605 	.area XISEG   (XDATA)
                                    606 	.area HOME    (CODE)
                                    607 	.area GSINIT0 (CODE)
                                    608 	.area GSINIT1 (CODE)
                                    609 	.area GSINIT2 (CODE)
                                    610 	.area GSINIT3 (CODE)
                                    611 	.area GSINIT4 (CODE)
                                    612 	.area GSINIT5 (CODE)
                                    613 	.area GSINIT  (CODE)
                                    614 	.area GSFINAL (CODE)
                                    615 	.area CSEG    (CODE)
                                    616 ;--------------------------------------------------------
                                    617 ; global & static initialisations
                                    618 ;--------------------------------------------------------
                                    619 	.area HOME    (CODE)
                                    620 	.area GSINIT  (CODE)
                                    621 	.area GSFINAL (CODE)
                                    622 	.area GSINIT  (CODE)
                                    623 ;--------------------------------------------------------
                                    624 ; Home
                                    625 ;--------------------------------------------------------
                                    626 	.area HOME    (CODE)
                                    627 	.area HOME    (CODE)
                                    628 ;--------------------------------------------------------
                                    629 ; code
                                    630 ;--------------------------------------------------------
                                    631 	.area CSEG    (CODE)
                                    632 ;------------------------------------------------------------
                                    633 ;Allocation info for local variables in function 'rgb_matrix_check_finished_leds'
                                    634 ;------------------------------------------------------------
                                    635 ;led_idx       Allocated with name '_rgb_matrix_check_finished_leds_led_idx_10000_191'
                                    636 ;------------------------------------------------------------
                                    637 ;	quantum/rgb_matrix/rgb_matrix.h:260: static inline bool rgb_matrix_check_finished_leds(uint8_t led_idx) {
                                    638 ;	-----------------------------------------
                           000007   639 	ar7 = 0x07
                           000006   640 	ar6 = 0x06
                           000005   641 	ar5 = 0x05
                           000004   642 	ar4 = 0x04
                           000003   643 	ar3 = 0x03
                           000002   644 	ar2 = 0x02
                           000001   645 	ar1 = 0x01
                           000000   646 	ar0 = 0x00
                                    647 ;	 function td_map_get
                                    648 ;	-----------------------------------------
      004C0E                        649 _td_map_get:
      004C0E AF 82            [24]  650 	mov r7,dpl
      004C10 EF               [12]  651 	mov a,r7
      004C11 90 06 6C         [24]  652 	mov dptr,#(_td_map_get_id_10000_596+0x0000)
      004C14 C3               [12]  653 	clr	c
      004C15 13               [12]  654 	rrc	a
      004C16 24 2C            [12]  655 	add	a, #_td_map
      004C18 F5 82            [12]  656 	mov	dpl,a
      004C1A E4               [12]  657 	clr	a
      004C1B 34 06            [12]  658 	addc	a, #(_td_map >> 8)
      004C1D F5 83            [12]  659 	mov	dph,a
      004C1F E0               [24]  660 	movx	a,@dptr
      004C20 FE               [12]  661 	mov	r6,a
                                    662 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:23: return (id & 1) ? packed >> 4 : packed & 15;
      004C21 EF               [12]  663 	mov	a,r7
      004C22 30 E0 07         [24]  664 	jnb	acc.0,00103$
      004C25 EE               [12]  665 	mov	a,r6
      004C26 C4               [12]  666 	swap	a
      004C27 54 0F            [12]  667 	anl	a,#0x0f
      004C29 FF               [12]  668 	mov	r7,a
      004C2A 80 05            [24]  669 	sjmp	00104$
      004C2C                        670 00103$:
      004C2C 53 06 0F         [24]  671 	anl	ar6,#0x0f
      004C2F 8E 07            [24]  672 	mov	ar7,r6
      004C31                        673 00104$:
      004C31 8F 82            [24]  674 	mov	dpl, r7
                                    675 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:24: }
      004C33 22               [24]  676 	ret
                                    677 ;------------------------------------------------------------
                                    678 ;Allocation info for local variables in function 'td_map_set'
                                    679 ;------------------------------------------------------------
                                    680 ;value         Allocated with name '_td_map_set_PARM_2'
                                    681 ;id            Allocated with name '_td_map_set_id_10000_598'
                                    682 ;packed        Allocated with name '_td_map_set_packed_10000_599'
                                    683 ;------------------------------------------------------------
                                    684 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:25: static void td_map_set(uint8_t id, uint8_t value) {
                                    685 ;	-----------------------------------------
                                    686 ;	 function td_map_set
                                    687 ;	-----------------------------------------
      004C34                        688 _td_map_set:
      004C34 AF 82            [24]  689 	mov r7,dpl
      004C36 EF               [12]  690 	mov a,r7
      004C37 90 06 6E         [24]  691 	mov dptr,#(_td_map_set_id_10000_598+0x0000)
      004C3A C3               [12]  692 	clr	c
      004C3B 13               [12]  693 	rrc	a
      004C3C 24 2C            [12]  694 	add	a, #_td_map
      004C3E FD               [12]  695 	mov	r5,a
      004C3F E4               [12]  696 	clr	a
      004C40 34 06            [12]  697 	addc	a, #(_td_map >> 8)
      004C42 FE               [12]  698 	mov	r6,a
                                    699 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:27: if (id & 1) *packed = (*packed & 15) | ((value & 15) << 4);
      004C43 EF               [12]  700 	mov	a,r7
      004C44 30 E0 18         [24]  701 	jnb	acc.0,00102$
      004C47 12 51 E2         [24]  702 	lcall	_ak820_outline_0105
      004C4A FF               [12]  703 	mov	r7,a
      004C4B 53 07 0F         [24]  704 	anl	ar7,#0x0f
      004C4E 90 06 6D         [24]  705 	mov	dptr,#_td_map_set_PARM_2
      004C51 E0               [24]  706 	movx	a,@dptr
      004C52 54 0F            [12]  707 	anl	a,#0x0f
      004C54 C4               [12]  708 	swap	a
      004C55 54 F0            [12]  709 	anl	a,#0xf0
      004C57 42 07            [12]  710 	orl	ar7,a
      004C59 12 38 AA         [24]  711 	lcall	_ak820_outline_0138
      004C5C EF               [12]  712 	mov	a,r7
      004C5D F0               [24]  713 	movx	@dptr,a
      004C5E 22               [24]  714 	ret
      004C5F                        715 00102$:
                                    716 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:28: else *packed = (*packed & 240) | (value & 15);
      004C5F 12 51 E2         [24]  717 	lcall	_ak820_outline_0105
      004C62 FF               [12]  718 	mov	r7,a
      004C63 53 07 F0         [24]  719 	anl	ar7,#0xf0
      004C66 90 06 6D         [24]  720 	mov	dptr,#_td_map_set_PARM_2
      004C69 E0               [24]  721 	movx	a,@dptr
      004C6A 54 0F            [12]  722 	anl	a,#0x0f
      004C6C 42 07            [12]  723 	orl	ar7,a
      004C6E 12 38 AA         [24]  724 	lcall	_ak820_outline_0138
      004C71 EF               [12]  725 	mov	a,r7
      004C72 F0               [24]  726 	movx	@dptr,a
                                    727 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:29: }
      004C73 22               [24]  728 	ret
                                    729 ;------------------------------------------------------------
                                    730 ;Allocation info for local variables in function 'ak820_tap_dance_valid'
                                    731 ;------------------------------------------------------------
                                    732 ;entry         Allocated with name '_ak820_tap_dance_valid_entry_10000_601'
                                    733 ;bytes         Allocated with name '_ak820_tap_dance_valid_bytes_10000_602'
                                    734 ;i             Allocated with name '_ak820_tap_dance_valid_i_20000_604'
                                    735 ;basic         Allocated with name '_ak820_tap_dance_valid_basic_30000_605'
                                    736 ;mods          Allocated with name '_ak820_tap_dance_valid_mods_30000_605'
                                    737 ;------------------------------------------------------------
                                    738 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:34: bool ak820_tap_dance_valid(const vial_tap_dance_entry_t AK820_STATE_MEM *entry) {
                                    739 ;	-----------------------------------------
                                    740 ;	 function ak820_tap_dance_valid
                                    741 ;	-----------------------------------------
      004C74                        742 _ak820_tap_dance_valid:
      004C74 12 3B 8E         [24]  743 	lcall	_ak820_outline_0065
      004C77 90 06 7B         [24]  744 	mov dptr,#(_ak820_tap_dance_valid_entry_10000_601+0x0001)
                                    745 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:36: if (bytes[9] & 128) return false;
      004C7A 74 09            [12]  746 	mov	a,#0x09
      004C7C 12 37 FB         [24]  747 	lcall	_ak820_outline_0023
      004C7F E0               [24]  748 	movx	a,@dptr
      004C80 30 E7 04         [24]  749 	jnb	acc.7,00130$
                                    750 	.globl _ak820_tailshare_00012
                           000075   751 _ak820_tailshare_00012 = .
      004C83 75 82 00         [24]  752 	mov	dpl, #0x00
                                    753 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:37: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
      004C86 22               [24]  754 	ret
      004C87                        755 00130$:
      004C87 7D 00            [12]  756 	mov	r5,#0x00
      004C89                        757 00114$:
      004C89 BD 04 00         [24]  758 	cjne	r5,#0x04,00167$
      004C8C                        759 00167$:
      004C8C 50 35            [24]  760 	jnc	00112$
                                    761 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:38: uint8_t basic = bytes[0], mods = bytes[1];
      004C8E 12 38 4C         [24]  762 	lcall	_ak820_outline_0077
      004C91 FC               [12]  763 	mov	r4,a
      004C92 90 06 7C         [24]  764 	mov	dptr,#_ak820_tap_dance_valid_basic_30000_605
      004C95 F0               [24]  765 	movx	@dptr,a
      004C96 12 38 22         [24]  766 	lcall	_ak820_outline_0044
                                    767 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:39: if (!(basic | mods)) continue;
      004C99 FB               [12]  768 	mov	r3,a
      004C9A 4C               [12]  769 	orl	a,r4
      004C9B 60 20            [24]  770 	jz	00111$
                                    771 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:40: if (mods >= 32 || !((basic >= KC_A && basic <= KC_EXSEL) ||
      004C9D BB 20 00         [24]  772 	cjne	r3,#0x20,00170$
      004CA0                        773 00170$:
      004CA0 50 19            [24]  774 	jnc	00105$
      004CA2 BC 04 00         [24]  775 	cjne	r4,#0x04,00172$
      004CA5                        776 00172$:
      004CA5 40 05            [24]  777 	jc	00109$
      004CA7 EC               [12]  778 	mov	a,r4
      004CA8 24 5B            [12]  779 	add	a,#0xff - 0xa4
      004CAA 50 11            [24]  780 	jnc	00111$
                                    781 ;	free result
      004CAC                        782 00109$:
                                    783 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:41: (basic >= KC_LEFT_CTRL && basic <= KC_RIGHT_GUI))) return false;
      004CAC 90 06 7C         [24]  784 	mov	dptr,#_ak820_tap_dance_valid_basic_30000_605
      004CAF E0               [24]  785 	movx	a,@dptr
      004CB0 FC               [12]  786 	mov	r4,a
      004CB1 BC E0 00         [24]  787 	cjne	r4,#0xe0,00175$
      004CB4                        788 00175$:
      004CB4 40 05            [24]  789 	jc	00105$
      004CB6 EC               [12]  790 	mov	a,r4
      004CB7 24 18            [12]  791 	add	a,#0xff - 0xe7
      004CB9 50 02            [24]  792 	jnc	00111$
                                    793 ;	free result
      004CBB                        794 00105$:
      004CBB 81 83            [12]  795 	ajmp	_ak820_tailshare_00012
      004CBD                        796 00111$:
                                    797 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:37: for (uint8_t i = 0; i < 4; ++i, bytes += 2) {
      004CBD 0D               [12]  798 	inc	r5
      004CBE 12 51 D3         [24]  799 	lcall	_ak820_outline_0084
      004CC1 80 C6            [24]  800 	sjmp	00114$
      004CC3                        801 00112$:
                                    802 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:43: return true;
                                    803 	.globl _ak820_tailshare_00013
                           0000B5   804 _ak820_tailshare_00013 = .
      004CC3 75 82 01         [24]  805 	mov	dpl, #0x01
                                    806 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:44: }
      004CC6 22               [24]  807 	ret
                                    808 ;------------------------------------------------------------
                                    809 ;Allocation info for local variables in function 'td_prepare'
                                    810 ;------------------------------------------------------------
                                    811 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:47: static void td_prepare(void) {
                                    812 ;	-----------------------------------------
                                    813 ;	 function td_prepare
                                    814 ;	-----------------------------------------
      004CC7                        815 _td_prepare:
                                    816 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:48: td_record.event.key.row = td_work->source / MATRIX_COLS;
      004CC7 90 06 1E         [24]  817 	mov	dptr,#_td_work
      004CCA 12 37 D4         [24]  818 	lcall	_ak820_outline_0005
      004CCD A3               [24]  819 	inc	dptr
      004CCE A3               [24]  820 	inc	dptr
      004CCF E0               [24]  821 	movx	a,@dptr
      004CD0 75 F0 08         [24]  822 	mov	b,#0x08
      004CD3 84               [48]  823 	div	ab
      004CD4 90 06 70         [24]  824 	mov	dptr,#(_td_record + 0x0001)
      004CD7 F0               [24]  825 	movx	@dptr,a
                                    826 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:49: td_record.event.key.col = td_work->source % MATRIX_COLS;
      004CD8 90 06 1E         [24]  827 	mov	dptr,#_td_work
      004CDB 12 37 D4         [24]  828 	lcall	_ak820_outline_0005
      004CDE A3               [24]  829 	inc	dptr
      004CDF A3               [24]  830 	inc	dptr
      004CE0 E0               [24]  831 	movx	a,@dptr
      004CE1 FF               [12]  832 	mov	r7,a
      004CE2 53 07 07         [24]  833 	anl	ar7,#0x07
      004CE5 90 06 6F         [24]  834 	mov	dptr,#_td_record
      004CE8 EF               [12]  835 	mov	a,r7
      004CE9 F0               [24]  836 	movx	@dptr,a
                                    837 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:50: td_record.event.type = KEY_EVENT;
      004CEA 90 06 73         [24]  838 	mov	dptr,#(_td_record + 0x0004)
      004CED 74 01            [12]  839 	mov	a,#0x01
      004CEF F0               [24]  840 	movx	@dptr,a
                                    841 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:51: td_record.event.time = td_time;
      004CF0 90 06 2A         [24]  842 	mov	dptr,#_td_time
      004CF3 12 38 29         [24]  843 	lcall	_ak820_outline_0055
      004CF6 90 06 71         [24]  844 	mov	dptr,#(_td_record + 0x0002)
      004CF9 12 51 C7         [24]  845 	lcall	_ak820_outline_0064
                                    846 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:52: td_record.tap.count = 1;
      004CFC 90 06 75         [24]  847 	mov	dptr,#(_td_record + 0x0006)
      004CFF E0               [24]  848 	movx	a,@dptr
      004D00 54 0F            [12]  849 	anl	a,#0x0f
      004D02 44 10            [12]  850 	orl	a,#0x10
      004D04 F0               [24]  851 	movx	@dptr,a
                                    852 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:53: }
      004D05 22               [24]  853 	ret
                                    854 ;------------------------------------------------------------
                                    855 ;Allocation info for local variables in function 'td_finish'
                                    856 ;------------------------------------------------------------
                                    857 ;interrupted   Allocated with name '_td_finish_interrupted_10000_610'
                                    858 ;choice        Allocated with name '_td_finish_choice_10000_611'
                                    859 ;state         Allocated with name '_td_finish_state_10000_611'
                                    860 ;extra         Allocated with name '_td_finish_extra_10000_611'
                                    861 ;------------------------------------------------------------
                                    862 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:54: static void td_finish(bool interrupted) {
                                    863 ;	-----------------------------------------
                                    864 ;	 function td_finish
                                    865 ;	-----------------------------------------
      004D06                        866 _td_finish:
      004D06 E5 82            [12]  867 	mov	a,dpl
      004D08 90 06 7D         [24]  868 	mov	dptr,#_td_finish_interrupted_10000_610
      004D0B F0               [24]  869 	movx	@dptr,a
                                    870 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:55: uint8_t choice = 0, state;
      004D0C 90 06 7E         [24]  871 	mov	dptr,#_td_finish_choice_10000_611
      004D0F E4               [12]  872 	clr	a
      004D10 F0               [24]  873 	movx	@dptr,a
                                    874 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:56: bool extra = false;
      004D11 90 06 80         [24]  875 	mov	dptr,#_td_finish_extra_10000_611
      004D14 F0               [24]  876 	movx	@dptr,a
                                    877 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:57: if (ak820_td_invoking) return;
      004D15 90 06 79         [24]  878 	mov	dptr,#_ak820_td_invoking
      004D18 E0               [24]  879 	movx	a,@dptr
      004D19 60 01            [24]  880 	jz	00102$
      004D1B 22               [24]  881 	ret
      004D1C                        882 00102$:
                                    883 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:58: if (!td_wait) return;
      004D1C 90 06 1C         [24]  884 	mov	dptr,#_td_wait
      004D1F 12 38 29         [24]  885 	lcall	_ak820_outline_0055
      004D22 90 06 1C         [24]  886 	mov	dptr,#_td_wait
      004D25 12 51 BF         [24]  887 	lcall	_ak820_outline_0030
      004D28 70 01            [24]  888 	jnz	00104$
      004D2A 22               [24]  889 	ret
      004D2B                        890 00104$:
                                    891 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:59: ak820_td_invoking = true;
      004D2B 90 06 79         [24]  892 	mov	dptr,#_ak820_td_invoking
      004D2E 74 01            [12]  893 	mov	a,#0x01
      004D30 F0               [24]  894 	movx	@dptr,a
                                    895 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:60: td_work = td_wait;
      004D31 90 06 1E         [24]  896 	mov	dptr,#_td_work
      004D34 12 51 C7         [24]  897 	lcall	_ak820_outline_0064
                                    898 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:61: td_wait = 0;
      004D37 90 06 1C         [24]  899 	mov	dptr,#_td_wait
      004D3A 12 52 06         [24]  900 	lcall	_ak820_outline_0162
                                    901 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:62: state = td_work->state;
      004D3D 12 51 86         [24]  902 	lcall	_ak820_outline_0007
      004D40 FD               [12]  903 	mov	r5,a
      004D41 90 06 7F         [24]  904 	mov	dptr,#_td_finish_state_10000_611
      004D44 F0               [24]  905 	movx	@dptr,a
                                    906 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:63: td_work->state = state | TD_DONE;
      004D45 43 05 08         [24]  907 	orl	ar5,#0x08
      004D48 12 46 2F         [24]  908 	lcall	_ak820_outline_0127
      004D4B ED               [12]  909 	mov	a,r5
      004D4C F0               [24]  910 	movx	@dptr,a
                                    911 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:64: if ((state & 3) == 1) {
      004D4D 90 06 7F         [24]  912 	mov	dptr,#_td_finish_state_10000_611
      004D50 E0               [24]  913 	movx	a,@dptr
      004D51 FF               [12]  914 	mov	r7,a
      004D52 FE               [12]  915 	mov	r6,a
      004D53 53 06 03         [24]  916 	anl	ar6,#0x03
      004D56 BE 01 12         [24]  917 	cjne	r6,#0x01,00112$
                                    918 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:65: if ((state & TD_DOWN) && !interrupted) choice = 1;
      004D59 EF               [12]  919 	mov	a,r7
      004D5A 30 E2 2B         [24]  920 	jnb	acc.2,00113$
      004D5D 90 06 7D         [24]  921 	mov	dptr,#_td_finish_interrupted_10000_610
      004D60 E0               [24]  922 	movx	a,@dptr
      004D61 70 25            [24]  923 	jnz	00113$
      004D63 90 06 7E         [24]  924 	mov	dptr,#_td_finish_choice_10000_611
      004D66 74 01            [12]  925 	mov	a,#0x01
      004D68 F0               [24]  926 	movx	@dptr,a
      004D69 80 1D            [24]  927 	sjmp	00113$
      004D6B                        928 00112$:
                                    929 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:66: } else if (interrupted) extra = true;
      004D6B 90 06 7D         [24]  930 	mov	dptr,#_td_finish_interrupted_10000_610
      004D6E E0               [24]  931 	movx	a,@dptr
      004D6F 60 08            [24]  932 	jz	00109$
      004D71 90 06 80         [24]  933 	mov	dptr,#_td_finish_extra_10000_611
      004D74 74 01            [12]  934 	mov	a,#0x01
      004D76 F0               [24]  935 	movx	@dptr,a
      004D77 80 0F            [24]  936 	sjmp	00113$
      004D79                        937 00109$:
                                    938 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:67: else choice = (state & TD_DOWN) ? 3 : 2;
      004D79 EF               [12]  939 	mov	a,r7
      004D7A 30 E2 04         [24]  940 	jnb	acc.2,00136$
      004D7D 7F 03            [12]  941 	mov	r7,#0x03
      004D7F 80 02            [24]  942 	sjmp	00137$
      004D81                        943 00136$:
      004D81 7F 02            [12]  944 	mov	r7,#0x02
      004D83                        945 00137$:
      004D83 90 06 7E         [24]  946 	mov	dptr,#_td_finish_choice_10000_611
      004D86 EF               [12]  947 	mov	a,r7
      004D87 F0               [24]  948 	movx	@dptr,a
      004D88                        949 00113$:
                                    950 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:68: td_work->output = ((uint16_t AK820_STATE_MEM *)&td_entry)[choice];
      004D88 90 06 1E         [24]  951 	mov	dptr,#_td_work
      004D8B 12 38 29         [24]  952 	lcall	_ak820_outline_0055
      004D8E 90 06 7E         [24]  953 	mov	dptr,#_td_finish_choice_10000_611
      004D91 E0               [24]  954 	movx	a,@dptr
      004D92 FD               [12]  955 	mov	r5,a
      004D93 12 52 10         [24]  956 	lcall	_ak820_outline_0196
      004D96 24 20            [12]  957 	add	a, #_td_entry
      004D98 F5 82            [12]  958 	mov	dpl,a
      004D9A 74 06            [12]  959 	mov	a,#(_td_entry >> 8)
      004D9C 35 F0            [12]  960 	addc	a, b
      004D9E F5 83            [12]  961 	mov	dph,a
      004DA0 12 38 79         [24]  962 	lcall	_ak820_outline_0097
      004DA3 12 46 2F         [24]  963 	lcall	_ak820_outline_0127
      004DA6 12 38 85         [24]  964 	lcall	_ak820_outline_0101
                                    965 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:69: if (!td_work->output) {
      004DA9 90 06 1E         [24]  966 	mov	dptr,#_td_work
      004DAC 12 37 D4         [24]  967 	lcall	_ak820_outline_0005
      004DAF E0               [24]  968 	movx	a,@dptr
      004DB0 FB               [12]  969 	mov	r3,a
      004DB1 A3               [24]  970 	inc	dptr
      004DB2 E0               [24]  971 	movx	a,@dptr
      004DB3 4B               [12]  972 	orl	a,r3
      004DB4 70 28            [24]  973 	jnz	00117$
                                    974 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:70: if (choice >= 2) extra = true;
      004DB6 BD 02 00         [24]  975 	cjne	r5,#0x02,00286$
      004DB9                        976 00286$:
      004DB9 40 06            [24]  977 	jc	00115$
      004DBB 90 06 80         [24]  978 	mov	dptr,#_td_finish_extra_10000_611
      004DBE 74 01            [12]  979 	mov	a,#0x01
      004DC0 F0               [24]  980 	movx	@dptr,a
      004DC1                        981 00115$:
                                    982 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:71: td_work->output = choice == 3 && td_entry.on_hold ? td_entry.on_hold : td_entry.on_tap;
      004DC1 90 06 7E         [24]  983 	mov	dptr,#_td_finish_choice_10000_611
      004DC4 E0               [24]  984 	movx	a,@dptr
      004DC5 FD               [12]  985 	mov	r5,a
      004DC6 BD 03 09         [24]  986 	cjne	r5,#0x03,00138$
      004DC9 90 06 22         [24]  987 	mov	dptr,#(_td_entry + 0x0002)
      004DCC 12 38 40         [24]  988 	lcall	_ak820_outline_0063
      004DCF 4C               [12]  989 	orl	a,r4
      004DD0 70 06            [24]  990 	jnz	00139$
      004DD2                        991 00138$:
      004DD2 90 06 20         [24]  992 	mov	dptr,#_td_entry
      004DD5 12 38 40         [24]  993 	lcall	_ak820_outline_0063
      004DD8                        994 00139$:
      004DD8 12 46 2F         [24]  995 	lcall	_ak820_outline_0127
      004DDB 12 38 46         [24]  996 	lcall	_ak820_outline_0076
      004DDE                        997 00117$:
                                    998 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:73: td_step = extra ? 0 : 2;
      004DDE 90 06 80         [24]  999 	mov	dptr,#_td_finish_extra_10000_611
      004DE1 E0               [24] 1000 	movx	a,@dptr
      004DE2 60 04            [24] 1001 	jz	00143$
      004DE4 7F 00            [12] 1002 	mov	r7,#0x00
      004DE6 80 02            [24] 1003 	sjmp	00144$
      004DE8                       1004 00143$:
      004DE8 7F 02            [12] 1005 	mov	r7,#0x02
      004DEA                       1006 00144$:
      004DEA 90 06 78         [24] 1007 	mov	dptr,#_td_step
      004DED EF               [12] 1008 	mov	a,r7
      004DEE F0               [24] 1009 	movx	@dptr,a
                                   1010 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:74: td_record.keycode = td_entry.on_tap;
      004DEF 90 06 20         [24] 1011 	mov	dptr,#_td_entry
      004DF2 12 51 B1         [24] 1012 	lcall	_ak820_outline_0028
                                   1013 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:75: td_prepare();
      004DF5 91 C7            [12] 1014 	acall	_td_prepare
      004DF7                       1015 00132$:
                                   1016 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:78: for (; td_step < 4; ++td_step) {
      004DF7 90 06 78         [24] 1017 	mov	dptr,#_td_step
      004DFA E0               [24] 1018 	movx	a,@dptr
      004DFB FF               [12] 1019 	mov	r7,a
      004DFC BF 04 00         [24] 1020 	cjne	r7,#0x04,00292$
      004DFF                       1021 00292$:
      004DFF 50 4A            [24] 1022 	jnc	00127$
                                   1023 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:79: if (td_step == 2) td_record.keycode = td_work->output;
      004E01 BF 02 09         [24] 1024 	cjne	r7,#0x02,00119$
      004E04 90 06 1E         [24] 1025 	mov	dptr,#_td_work
      004E07 12 37 D4         [24] 1026 	lcall	_ak820_outline_0005
      004E0A 12 51 B1         [24] 1027 	lcall	_ak820_outline_0028
      004E0D                       1028 00119$:
                                   1029 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:80: if (td_step == 3 && (td_work->state & TD_DOWN)) break;
      004E0D 90 06 78         [24] 1030 	mov	dptr,#_td_step
      004E10 E0               [24] 1031 	movx	a,@dptr
      004E11 FF               [12] 1032 	mov	r7,a
      004E12 BF 03 0D         [24] 1033 	cjne	r7,#0x03,00121$
      004E15 90 06 1E         [24] 1034 	mov	dptr,#_td_work
      004E18 12 37 D4         [24] 1035 	lcall	_ak820_outline_0005
      004E1B A3               [24] 1036 	inc	dptr
      004E1C A3               [24] 1037 	inc	dptr
      004E1D A3               [24] 1038 	inc	dptr
      004E1E E0               [24] 1039 	movx	a,@dptr
      004E1F 20 E2 29         [24] 1040 	jb	acc.2,00127$
      004E22                       1041 00121$:
                                   1042 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:81: td_record.event.pressed = !(td_step & 1);
      004E22 90 06 78         [24] 1043 	mov	dptr,#_td_step
      004E25 E0               [24] 1044 	movx	a,@dptr
      004E26 54 01            [12] 1045 	anl	a,#0x01
      004E28 B4 01 00         [24] 1046 	cjne	a,#0x01,00299$
      004E2B                       1047 00299$:
      004E2B 92 0F            [24] 1048 	mov	_td_finish_sloc0_1_0,c
      004E2D 90 06 74         [24] 1049 	mov	dptr,#(_td_record + 0x0005)
      004E30 E4               [12] 1050 	clr	a
      004E31 33               [12] 1051 	rlc	a
      004E32 12 51 F5         [24] 1052 	lcall	_ak820_outline_0153
                                   1053 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:82: if (td_record.keycode) process_record(&td_record);
      004E35 60 06            [24] 1054 	jz	00124$
      004E37 90 06 6F         [24] 1055 	mov	dptr,#_td_record
      004E3A 12 7E 7D         [24] 1056 	lcall	_process_record
      004E3D                       1057 00124$:
                                   1058 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:83: if (!td_work->state) goto done;
      004E3D 12 51 86         [24] 1059 	lcall	_ak820_outline_0007
      004E40 60 14            [24] 1060 	jz	00130$
                                   1061 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:78: for (; td_step < 4; ++td_step) {
      004E42 90 06 78         [24] 1062 	mov	dptr,#_td_step
      004E45 E0               [24] 1063 	movx	a,@dptr
      004E46 24 01            [12] 1064 	add	a, #0x01
      004E48 F0               [24] 1065 	movx	@dptr,a
      004E49 A1 F7            [24] 1066 	ajmp	00132$
      004E4B                       1067 00127$:
                                   1068 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:85: if (!(td_work->state & TD_DOWN)) td_work->state = 0;
      004E4B 12 51 86         [24] 1069 	lcall	_ak820_outline_0007
      004E4E 20 E2 05         [24] 1070 	jb	acc.2,00130$
      004E51 12 46 2F         [24] 1071 	lcall	_ak820_outline_0127
      004E54 E4               [12] 1072 	clr	a
      004E55 F0               [24] 1073 	movx	@dptr,a
                                   1074 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:86: done:
      004E56                       1075 00130$:
                                   1076 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:87: ak820_td_invoking = false;
      004E56 90 06 79         [24] 1077 	mov	dptr,#_ak820_td_invoking
      004E59 E4               [12] 1078 	clr	a
      004E5A F0               [24] 1079 	movx	@dptr,a
                                   1080 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:88: }
      004E5B 22               [24] 1081 	ret
                                   1082 ;------------------------------------------------------------
                                   1083 ;Allocation info for local variables in function 'ak820_tap_dance_task'
                                   1084 ;------------------------------------------------------------
                                   1085 ;now           Allocated with name '_ak820_tap_dance_task_now_10000_628'
                                   1086 ;term          Allocated with name '_ak820_tap_dance_task_term_10000_629'
                                   1087 ;------------------------------------------------------------
                                   1088 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:89: void ak820_tap_dance_task(uint16_t now) {
                                   1089 ;	-----------------------------------------
                                   1090 ;	 function ak820_tap_dance_task
                                   1091 ;	-----------------------------------------
      004E5C                       1092 _ak820_tap_dance_task:
      004E5C 12 38 9B         [24] 1093 	lcall	_ak820_outline_0122
      004E5F 90 06 81         [24] 1094 	mov	dptr,#_ak820_tap_dance_task_now_10000_628
      004E62 12 38 98         [24] 1095 	lcall	_ak820_outline_0121
                                   1096 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:90: uint16_t term = td_entry.custom_tapping_term;
      004E65 90 06 28         [24] 1097 	mov	dptr,#(_td_entry + 0x0008)
      004E68 12 38 29         [24] 1098 	lcall	_ak820_outline_0055
      004E6B 90 06 83         [24] 1099 	mov	dptr,#_ak820_tap_dance_task_term_10000_629
      004E6E 12 51 C7         [24] 1100 	lcall	_ak820_outline_0064
                                   1101 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:91: if (!term) term = 200;
      004E71 EE               [12] 1102 	mov	a,r6
      004E72 4F               [12] 1103 	orl	a,r7
      004E73 70 08            [24] 1104 	jnz	00102$
      004E75 90 06 83         [24] 1105 	mov	dptr,#_ak820_tap_dance_task_term_10000_629
      004E78 74 C8            [12] 1106 	mov	a,#0xc8
      004E7A 12 38 A3         [24] 1107 	lcall	_ak820_outline_0129
      004E7D                       1108 00102$:
                                   1109 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:92: if (td_wait && (uint16_t)(now - td_time) >= term) td_finish(false);
      004E7D 90 06 1C         [24] 1110 	mov	dptr,#_td_wait
      004E80 12 51 BF         [24] 1111 	lcall	_ak820_outline_0030
      004E83 60 1E            [24] 1112 	jz	00106$
      004E85 90 06 2A         [24] 1113 	mov	dptr,#_td_time
      004E88 12 38 29         [24] 1114 	lcall	_ak820_outline_0055
      004E8B 90 06 81         [24] 1115 	mov	dptr,#_ak820_tap_dance_task_now_10000_628
      004E8E 12 38 0D         [24] 1116 	lcall	_ak820_outline_0034
      004E91 90 06 83         [24] 1117 	mov	dptr,#_ak820_tap_dance_task_term_10000_629
      004E94 12 38 40         [24] 1118 	lcall	_ak820_outline_0063
      004E97 C3               [12] 1119 	clr	c
      004E98 EE               [12] 1120 	mov	a,r6
      004E99 9C               [12] 1121 	subb	a,r4
      004E9A EF               [12] 1122 	mov	a,r7
      004E9B 9D               [12] 1123 	subb	a,r5
      004E9C 40 05            [24] 1124 	jc	00106$
      004E9E 75 82 00         [24] 1125 	mov	dpl, #0x00
                                   1126 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:93: }
      004EA1 A1 06            [12] 1127 	ajmp	_td_finish
      004EA3                       1128 00106$:
      004EA3 22               [24] 1129 	ret
                                   1130 ;------------------------------------------------------------
                                   1131 ;Allocation info for local variables in function 'ak820_tap_dance_before'
                                   1132 ;------------------------------------------------------------
                                   1133 ;event         Allocated with name '_ak820_tap_dance_before_event_10000_632'
                                   1134 ;id            Allocated with name '_ak820_tap_dance_before_id_10000_633'
                                   1135 ;slot          Allocated with name '_ak820_tap_dance_before_slot_10000_633'
                                   1136 ;------------------------------------------------------------
                                   1137 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:94: bool ak820_tap_dance_before(const keyevent_t AK820_STATE_MEM *event) {
                                   1138 ;	-----------------------------------------
                                   1139 ;	 function ak820_tap_dance_before
                                   1140 ;	-----------------------------------------
      004EA4                       1141 _ak820_tap_dance_before:
      004EA4 12 38 9B         [24] 1142 	lcall	_ak820_outline_0122
      004EA7 90 06 85         [24] 1143 	mov	dptr,#_ak820_tap_dance_before_event_10000_632
      004EAA 12 38 98         [24] 1144 	lcall	_ak820_outline_0121
                                   1145 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:97: if (IS_NOEVENT(*event)) return true;
      004EAD 90 06 85         [24] 1146 	mov	dptr,#_ak820_tap_dance_before_event_10000_632
      004EB0 12 38 29         [24] 1147 	lcall	_ak820_outline_0055
      004EB3 74 04            [12] 1148 	mov	a,#0x04
      004EB5 12 51 9B         [24] 1149 	lcall	_ak820_outline_0008
      004EB8 70 02            [24] 1150 	jnz	00102$
      004EBA 81 C3            [12] 1151 	ajmp	_ak820_tailshare_00013
      004EBC                       1152 00102$:
                                   1153 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:98: if (event->key.row >= MATRIX_ROWS || event->key.col >= MATRIX_COLS) {
      004EBC 12 38 22         [24] 1154 	lcall	_ak820_outline_0044
      004EBF FD               [12] 1155 	mov	r5,a
      004EC0 BD 10 00         [24] 1156 	cjne	r5,#0x10,00220$
      004EC3                       1157 00220$:
      004EC3 50 09            [24] 1158 	jnc	00105$
      004EC5 12 38 4C         [24] 1159 	lcall	_ak820_outline_0077
      004EC8 FC               [12] 1160 	mov	r4,a
      004EC9 BC 08 00         [24] 1161 	cjne	r4,#0x08,00222$
      004ECC                       1162 00222$:
      004ECC 40 1A            [24] 1163 	jc	00106$
      004ECE                       1164 00105$:
                                   1165 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:99: if (event->pressed) td_finish(true);
      004ECE 90 06 85         [24] 1166 	mov	dptr,#_ak820_tap_dance_before_event_10000_632
      004ED1 12 38 4F         [24] 1167 	lcall	_ak820_outline_0078
      004ED4 74 05            [12] 1168 	mov	a,#0x05
      004ED6 2A               [12] 1169 	add	a, r2
      004ED7 FA               [12] 1170 	mov	r2,a
      004ED8 E4               [12] 1171 	clr	a
      004ED9 3B               [12] 1172 	addc	a, r3
      004EDA FB               [12] 1173 	mov	r3,a
      004EDB 12 46 3F         [24] 1174 	lcall	_ak820_outline_0148
      004EDE E0               [24] 1175 	movx	a,@dptr
      004EDF 60 05            [24] 1176 	jz	00104$
      004EE1 75 82 01         [24] 1177 	mov	dpl, #0x01
      004EE4 B1 06            [12] 1178 	acall	_td_finish
      004EE6                       1179 00104$:
                                   1180 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:100: return true;
      004EE6 81 C3            [12] 1181 	ajmp	_ak820_tailshare_00013
      004EE8                       1182 00106$:
                                   1183 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:102: id = event->key.row * MATRIX_COLS + event->key.col;
      004EE8 ED               [12] 1184 	mov	a,r5
      004EE9 12 38 C7         [24] 1185 	lcall	_ak820_outline_0174
      004EEC 2C               [12] 1186 	add	a,r4
                                   1187 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:103: if (td_map_get(id) == TD_MAP_NONE) {
      004EED FD               [12] 1188 	mov	r5,a
      004EEE F5 82            [12] 1189 	mov	dpl,a
      004EF0 C0 07            [24] 1190 	push	ar7
      004EF2 C0 06            [24] 1191 	push	ar6
      004EF4 C0 05            [24] 1192 	push	ar5
      004EF6 91 0E            [12] 1193 	acall	_td_map_get
      004EF8 AC 82            [24] 1194 	mov	r4, dpl
      004EFA D0 05            [24] 1195 	pop	ar5
      004EFC D0 06            [24] 1196 	pop	ar6
      004EFE D0 07            [24] 1197 	pop	ar7
      004F00 BC 08 12         [24] 1198 	cjne	r4,#0x08,00111$
                                   1199 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:104: if (!event->pressed) td_map_set(id, 0);
      004F03 74 05            [12] 1200 	mov	a,#0x05
      004F05 12 51 A6         [24] 1201 	lcall	_ak820_outline_0013
      004F08 70 09            [24] 1202 	jnz	00109$
      004F0A 90 06 6D         [24] 1203 	mov	dptr,#_td_map_set_PARM_2
      004F0D E4               [12] 1204 	clr	a
      004F0E F0               [24] 1205 	movx	@dptr,a
      004F0F 8D 82            [24] 1206 	mov	dpl, r5
      004F11 91 34            [12] 1207 	acall	_td_map_set
      004F13                       1208 00109$:
                                   1209 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:105: return false;
      004F13 81 83            [12] 1210 	ajmp	_ak820_tailshare_00012
      004F15                       1211 00111$:
                                   1212 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:107: if (event->pressed && td_wait && (td_wait->source != id || (td_wait->state & 3) == 2)) td_finish(true);
      004F15 12 37 C7         [24] 1213 	lcall	_ak820_outline_0002
      004F18 60 21            [24] 1214 	jz	00113$
      004F1A 90 06 1C         [24] 1215 	mov	dptr,#_td_wait
      004F1D 12 38 29         [24] 1216 	lcall	_ak820_outline_0055
      004F20 4E               [12] 1217 	orl	a,r6
      004F21 60 18            [24] 1218 	jz	00113$
      004F23 12 38 91         [24] 1219 	lcall	_ak820_outline_0118
      004F26 E0               [24] 1220 	movx	a,@dptr
      004F27 B5 05 0C         [24] 1221 	cjne	a,ar5,00112$
      004F2A 12 38 91         [24] 1222 	lcall	_ak820_outline_0118
      004F2D A3               [24] 1223 	inc	dptr
      004F2E E0               [24] 1224 	movx	a,@dptr
      004F2F FF               [12] 1225 	mov	r7,a
      004F30 53 07 03         [24] 1226 	anl	ar7,#0x03
      004F33 BF 02 05         [24] 1227 	cjne	r7,#0x02,00113$
      004F36                       1228 00112$:
      004F36 75 82 01         [24] 1229 	mov	dpl, #0x01
      004F39 B1 06            [12] 1230 	acall	_td_finish
      004F3B                       1231 00113$:
                                   1232 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:108: id = event->key.row * MATRIX_COLS + event->key.col;
      004F3B 90 06 85         [24] 1233 	mov	dptr,#_ak820_tap_dance_before_event_10000_632
      004F3E 12 37 D4         [24] 1234 	lcall	_ak820_outline_0005
      004F41 A3               [24] 1235 	inc	dptr
      004F42 E0               [24] 1236 	movx	a,@dptr
      004F43 12 38 C7         [24] 1237 	lcall	_ak820_outline_0174
      004F46 FD               [12] 1238 	mov	r5,a
      004F47 12 38 4C         [24] 1239 	lcall	_ak820_outline_0077
      004F4A 2D               [12] 1240 	add	a, r5
                                   1241 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:109: slot = td_slots + td_map_get(id);
      004F4B FD               [12] 1242 	mov	r5,a
      004F4C F5 82            [12] 1243 	mov	dpl,a
      004F4E C0 07            [24] 1244 	push	ar7
      004F50 C0 06            [24] 1245 	push	ar6
      004F52 C0 05            [24] 1246 	push	ar5
      004F54 91 0E            [12] 1247 	acall	_td_map_get
      004F56 E5 82            [12] 1248 	mov	a, dpl
      004F58 D0 05            [24] 1249 	pop	ar5
      004F5A D0 06            [24] 1250 	pop	ar6
      004F5C D0 07            [24] 1251 	pop	ar7
      004F5E 75 F0 04         [24] 1252 	mov	b,#0x04
      004F61 A4               [48] 1253 	mul	ab
      004F62 24 FC            [12] 1254 	add	a, #_td_slots
      004F64 FB               [12] 1255 	mov	r3,a
      004F65 74 05            [12] 1256 	mov	a,#(_td_slots >> 8)
      004F67 35 F0            [12] 1257 	addc	a, b
      004F69 FC               [12] 1258 	mov	r4,a
                                   1259 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:110: if (slot->state && slot->source == id) {
      004F6A 74 03            [12] 1260 	mov	a,#0x03
      004F6C 2B               [12] 1261 	add	a, r3
      004F6D F9               [12] 1262 	mov	r1,a
      004F6E E4               [12] 1263 	clr	a
      004F6F 3C               [12] 1264 	addc	a, r4
      004F70 12 51 FF         [24] 1265 	lcall	_ak820_outline_0161
      004F73 F8               [12] 1266 	mov	r0,a
      004F74 60 55            [24] 1267 	jz	00124$
      004F76 C0 00            [24] 1268 	push	ar0
      004F78 12 51 DB         [24] 1269 	lcall	_ak820_outline_0098
      004F7B E0               [24] 1270 	movx	a,@dptr
      004F7C B5 05 02         [24] 1271 	cjne	a,ar5,00235$
      004F7F 80 04            [24] 1272 	sjmp	00236$
      004F81                       1273 00235$:
      004F81 D0 00            [24] 1274 	pop	ar0
      004F83 80 46            [24] 1275 	sjmp	00124$
      004F85                       1276 00236$:
      004F85 D0 00            [24] 1277 	pop	ar0
                                   1278 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:111: if (event->pressed) return !(slot->state & TD_DONE);
      004F87 12 37 C7         [24] 1279 	lcall	_ak820_outline_0002
      004F8A 60 0E            [24] 1280 	jz	00118$
      004F8C E8               [12] 1281 	mov	a,r0
      004F8D A2 E3            [12] 1282 	mov	c,acc.3
      004F8F E4               [12] 1283 	clr	a
      004F90 33               [12] 1284 	rlc	a
      004F91 B4 01 00         [24] 1285 	cjne	a,#0x01,00238$
      004F94                       1286 00238$:
      004F94 92 10            [24] 1287 	mov  _ak820_tap_dance_before_sloc0_1_0,c
      004F96 12 38 B5         [24] 1288 	lcall	_ak820_outline_0146
      004F99 22               [24] 1289 	ret
      004F9A                       1290 00118$:
                                   1291 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:112: slot->state &= ~TD_DOWN;
      004F9A 53 00 FB         [24] 1292 	anl	ar0,#0xfb
      004F9D 12 51 E8         [24] 1293 	lcall	_ak820_outline_0117
                                   1294 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:113: if (slot->state & TD_DONE) {
      004FA0 E8               [12] 1295 	mov	a,r0
      004FA1 30 E3 24         [24] 1296 	jnb	acc.3,00122$
                                   1297 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:114: td_work = slot;
      004FA4 90 06 1E         [24] 1298 	mov	dptr,#_td_work
      004FA7 12 38 85         [24] 1299 	lcall	_ak820_outline_0101
                                   1300 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:115: td_record.keycode = slot->output;
      004FAA 12 38 BF         [24] 1301 	lcall	_ak820_outline_0149
      004FAD 12 51 B1         [24] 1302 	lcall	_ak820_outline_0028
                                   1303 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:116: slot->state = 0;
      004FB0 89 82            [24] 1304 	mov	dpl,r1
      004FB2 8A 83            [24] 1305 	mov	dph,r2
      004FB4 E4               [12] 1306 	clr	a
      004FB5 F0               [24] 1307 	movx	@dptr,a
                                   1308 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:117: td_prepare();
      004FB6 12 4C C7         [24] 1309 	lcall	_td_prepare
                                   1310 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:118: td_record.event.pressed = false;
      004FB9 90 06 74         [24] 1311 	mov	dptr,#(_td_record + 0x0005)
      004FBC E4               [12] 1312 	clr	a
      004FBD 12 51 F5         [24] 1313 	lcall	_ak820_outline_0153
                                   1314 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:119: if (td_record.keycode) process_record(&td_record);
      004FC0 60 06            [24] 1315 	jz	00122$
      004FC2 90 06 6F         [24] 1316 	mov	dptr,#_td_record
      004FC5 12 7E 7D         [24] 1317 	lcall	_process_record
      004FC8                       1318 00122$:
                                   1319 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:121: return false;
      004FC8 02 4C 83         [24] 1320 	ljmp	_ak820_tailshare_00012
      004FCB                       1321 00124$:
                                   1322 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:123: return true;
      004FCB 02 4C C3         [24] 1323 	ljmp	_ak820_tailshare_00013
                                   1324 ;------------------------------------------------------------
                                   1325 ;Allocation info for local variables in function 'ak820_tap_dance_process'
                                   1326 ;------------------------------------------------------------
                                   1327 ;record        Allocated with name '_ak820_tap_dance_process_record_10000_648'
                                   1328 ;index         Allocated with name '_ak820_tap_dance_process_index_10000_649'
                                   1329 ;id            Allocated with name '_ak820_tap_dance_process_id_10000_649'
                                   1330 ;slot          Allocated with name '_ak820_tap_dance_process_slot_10000_649'
                                   1331 ;------------------------------------------------------------
                                   1332 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:125: bool ak820_tap_dance_process(keyrecord_t AK820_STATE_MEM *record) {
                                   1333 ;	-----------------------------------------
                                   1334 ;	 function ak820_tap_dance_process
                                   1335 ;	-----------------------------------------
      004FCE                       1336 _ak820_tap_dance_process:
      004FCE 12 38 9B         [24] 1337 	lcall	_ak820_outline_0122
      004FD1 90 06 87         [24] 1338 	mov	dptr,#_ak820_tap_dance_process_record_10000_648
      004FD4 12 38 98         [24] 1339 	lcall	_ak820_outline_0121
                                   1340 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:128: if (get_repeat_key_count() || ak820_macro_primitive || record->event.type != KEY_EVENT ||
      004FD7 12 A8 79         [24] 1341 	lcall	_get_repeat_key_count
      004FDA E5 82            [12] 1342 	mov	a, dpl
      004FDC 70 2E            [24] 1343 	jnz	00101$
      004FDE 90 0A 58         [24] 1344 	mov	dptr,#_ak820_macro_primitive
      004FE1 E0               [24] 1345 	movx	a,@dptr
      004FE2 70 28            [24] 1346 	jnz	00101$
      004FE4 90 06 87         [24] 1347 	mov	dptr,#_ak820_tap_dance_process_record_10000_648
      004FE7 12 37 D4         [24] 1348 	lcall	_ak820_outline_0005
      004FEA A3               [24] 1349 	inc	dptr
      004FEB A3               [24] 1350 	inc	dptr
      004FEC A3               [24] 1351 	inc	dptr
      004FED A3               [24] 1352 	inc	dptr
      004FEE E0               [24] 1353 	movx	a,@dptr
      004FEF FD               [12] 1354 	mov	r5,a
      004FF0 BD 01 19         [24] 1355 	cjne	r5,#0x01,00101$
                                   1356 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:129: record->event.key.row >= MATRIX_ROWS || record->event.key.col >= MATRIX_COLS ||
      004FF3 12 38 22         [24] 1357 	lcall	_ak820_outline_0044
      004FF6 FD               [12] 1358 	mov	r5,a
      004FF7 BD 10 00         [24] 1359 	cjne	r5,#0x10,00228$
      004FFA                       1360 00228$:
      004FFA 50 10            [24] 1361 	jnc	00101$
      004FFC 12 38 4C         [24] 1362 	lcall	_ak820_outline_0077
      004FFF FC               [12] 1363 	mov	r4,a
      005000 BC 08 00         [24] 1364 	cjne	r4,#0x08,00230$
      005003                       1365 00230$:
      005003 50 07            [24] 1366 	jnc	00101$
                                   1367 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:130: !record->event.pressed) return (record->keycode >> 8) != (QK_TAP_DANCE >> 8);
      005005 74 05            [12] 1368 	mov	a,#0x05
      005007 2E               [12] 1369 	add	a, r6
      005008 31 C9            [12] 1370 	acall	_ak820_outline_0075
      00500A 70 26            [24] 1371 	jnz	00102$
      00500C                       1372 00101$:
      00500C 90 06 87         [24] 1373 	mov	dptr,#_ak820_tap_dance_process_record_10000_648
      00500F 12 38 4F         [24] 1374 	lcall	_ak820_outline_0078
      005012 74 07            [12] 1375 	mov	a,#0x07
      005014 2A               [12] 1376 	add	a, r2
      005015 F5 82            [12] 1377 	mov	dpl,a
      005017 E4               [12] 1378 	clr	a
      005018 3B               [12] 1379 	addc	a, r3
      005019 F5 83            [12] 1380 	mov	dph,a
      00501B E0               [24] 1381 	movx	a,@dptr
      00501C A3               [24] 1382 	inc	dptr
      00501D E0               [24] 1383 	movx	a,@dptr
      00501E FA               [12] 1384 	mov	r2,a
      00501F 7B 00            [12] 1385 	mov	r3,#0x00
      005021 BA 57 06         [24] 1386 	cjne	r2,#0x57,00233$
      005024 BB 00 03         [24] 1387 	cjne	r3,#0x00,00233$
      005027 D3               [12] 1388 	setb	c
      005028 80 01            [24] 1389 	sjmp	00234$
      00502A                       1390 00233$:
      00502A C3               [12] 1391 	clr	c
      00502B                       1392 00234$:
      00502B B3               [12] 1393 	cpl	c
      00502C 92 11            [24] 1394 	mov	_ak820_tap_dance_process_sloc0_1_0,c
      00502E 12 38 B5         [24] 1395 	lcall	_ak820_outline_0146
      005031 22               [24] 1396 	ret
      005032                       1397 00102$:
                                   1398 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:131: id = record->event.key.row * MATRIX_COLS + record->event.key.col;
      005032 ED               [12] 1399 	mov	a,r5
      005033 12 38 C7         [24] 1400 	lcall	_ak820_outline_0174
      005036 2C               [12] 1401 	add	a,r4
      005037 FD               [12] 1402 	mov	r5,a
                                   1403 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:133: if (td_wait && !(td_wait->state & TD_DOWN) && td_wait->source == id &&
      005038 90 06 1C         [24] 1404 	mov	dptr,#_td_wait
      00503B 12 38 79         [24] 1405 	lcall	_ak820_outline_0097
      00503E 4B               [12] 1406 	orl	a,r3
      00503F 60 40            [24] 1407 	jz	00109$
      005041 31 DB            [12] 1408 	acall	_ak820_outline_0098
      005043 A3               [24] 1409 	inc	dptr
      005044 E0               [24] 1410 	movx	a,@dptr
      005045 20 E2 39         [24] 1411 	jb	acc.2,00109$
      005048 31 DB            [12] 1412 	acall	_ak820_outline_0098
      00504A E0               [24] 1413 	movx	a,@dptr
      00504B B5 05 33         [24] 1414 	cjne	a,ar5,00109$
                                   1415 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:134: record->keycode != (QK_TAP_DANCE | td_map_get(id))) td_finish(true);
      00504E 12 37 E8         [24] 1416 	lcall	_ak820_outline_0016
      005051 FE               [12] 1417 	mov	r6,a
      005052 A3               [24] 1418 	inc	dptr
      005053 E0               [24] 1419 	movx	a,@dptr
      005054 FF               [12] 1420 	mov	r7,a
      005055 8D 82            [24] 1421 	mov	dpl, r5
      005057 C0 07            [24] 1422 	push	ar7
      005059 C0 06            [24] 1423 	push	ar6
      00505B C0 05            [24] 1424 	push	ar5
      00505D 12 4C 0E         [24] 1425 	lcall	_td_map_get
      005060 AC 82            [24] 1426 	mov	r4, dpl
      005062 D0 05            [24] 1427 	pop	ar5
      005064 D0 06            [24] 1428 	pop	ar6
      005066 D0 07            [24] 1429 	pop	ar7
      005068 7B 00            [12] 1430 	mov	r3,#0x00
      00506A 43 03 57         [24] 1431 	orl	ar3,#0x57
      00506D EE               [12] 1432 	mov	a,r6
      00506E B5 04 06         [24] 1433 	cjne	a,ar4,00239$
      005071 EF               [12] 1434 	mov	a,r7
      005072 B5 03 02         [24] 1435 	cjne	a,ar3,00239$
      005075 80 0A            [24] 1436 	sjmp	00109$
      005077                       1437 00239$:
      005077 75 82 01         [24] 1438 	mov	dpl, #0x01
      00507A C0 05            [24] 1439 	push	ar5
      00507C 12 4D 06         [24] 1440 	lcall	_td_finish
      00507F D0 05            [24] 1441 	pop	ar5
      005081                       1442 00109$:
                                   1443 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:135: if ((record->keycode >> 8) != (QK_TAP_DANCE >> 8)) return true;
      005081 90 06 87         [24] 1444 	mov	dptr,#_ak820_tap_dance_process_record_10000_648
      005084 12 38 29         [24] 1445 	lcall	_ak820_outline_0055
      005087 12 37 E8         [24] 1446 	lcall	_ak820_outline_0016
      00508A FE               [12] 1447 	mov	r6,a
      00508B A3               [24] 1448 	inc	dptr
      00508C E0               [24] 1449 	movx	a,@dptr
      00508D FB               [12] 1450 	mov	r3,a
      00508E 7C 00            [12] 1451 	mov	r4,#0x00
      005090 BB 57 05         [24] 1452 	cjne	r3,#0x57,00240$
      005093 BC 00 02         [24] 1453 	cjne	r4,#0x00,00240$
      005096 80 03            [24] 1454 	sjmp	00114$
      005098                       1455 00240$:
      005098 02 4C C3         [24] 1456 	ljmp	_ak820_tailshare_00013
      00509B                       1457 00114$:
                                   1458 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:136: index = (uint8_t)record->keycode;
                                   1459 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:137: slot = td_slots + (index & 7);
      00509B 8E 04            [24] 1460 	mov	ar4,r6
      00509D 53 04 07         [24] 1461 	anl	ar4,#0x07
      0050A0 7F 00            [12] 1462 	mov	r7,#0x00
      0050A2 EC               [12] 1463 	mov	a,r4
      0050A3 2C               [12] 1464 	add	a,r4
      0050A4 FC               [12] 1465 	mov	r4,a
      0050A5 EF               [12] 1466 	mov	a,r7
      0050A6 33               [12] 1467 	rlc	a
      0050A7 FF               [12] 1468 	mov	r7,a
      0050A8 EC               [12] 1469 	mov	a,r4
      0050A9 2C               [12] 1470 	add	a,r4
      0050AA FC               [12] 1471 	mov	r4,a
      0050AB EF               [12] 1472 	mov	a,r7
      0050AC 33               [12] 1473 	rlc	a
      0050AD FF               [12] 1474 	mov	r7,a
      0050AE EC               [12] 1475 	mov	a,r4
      0050AF 24 FC            [12] 1476 	add	a, #_td_slots
      0050B1 FC               [12] 1477 	mov	r4,a
      0050B2 EF               [12] 1478 	mov	a,r7
      0050B3 34 05            [12] 1479 	addc	a, #(_td_slots >> 8)
      0050B5 FF               [12] 1480 	mov	r7,a
                                   1481 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:138: if (index >= VIAL_TAP_DANCE_ENTRIES || (slot->state && slot->source != id)) goto suppress;
      0050B6 BE 08 00         [24] 1482 	cjne	r6,#0x08,00241$
      0050B9                       1483 00241$:
      0050B9 40 02            [24] 1484 	jc	00242$
      0050BB 21 41            [12] 1485 	ajmp	00123$
      0050BD                       1486 00242$:
      0050BD 74 03            [12] 1487 	mov	a,#0x03
      0050BF 2C               [12] 1488 	add	a, r4
      0050C0 31 C9            [12] 1489 	acall	_ak820_outline_0075
      0050C2 F9               [12] 1490 	mov	r1,a
      0050C3 60 0C            [24] 1491 	jz	00116$
      0050C5 51 0B            [12] 1492 	acall	_ak820_outline_0191
      0050C7 A3               [24] 1493 	inc	dptr
      0050C8 A3               [24] 1494 	inc	dptr
      0050C9 E0               [24] 1495 	movx	a,@dptr
      0050CA B5 05 02         [24] 1496 	cjne	a,ar5,00244$
      0050CD 80 02            [24] 1497 	sjmp	00245$
      0050CF                       1498 00244$:
      0050CF 21 41            [12] 1499 	ajmp	00123$
      0050D1                       1500 00245$:
      0050D1                       1501 00116$:
                                   1502 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:139: if (!slot->state) {
      0050D1 E9               [12] 1503 	mov	a,r1
      0050D2 70 35            [24] 1504 	jnz	00122$
                                   1505 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:140: if (dynamic_keymap_get_tap_dance(index, &td_entry)) goto suppress;
      0050D4 90 0B AF         [24] 1506 	mov	dptr,#_dynamic_keymap_get_tap_dance_PARM_2
      0050D7 74 20            [12] 1507 	mov	a,#_td_entry
      0050D9 F0               [24] 1508 	movx	@dptr,a
      0050DA 74 06            [12] 1509 	mov	a,#(_td_entry >> 8)
      0050DC 12 4B E9         [24] 1510 	lcall	_ak820_outline_0095
      0050DF 8E 82            [24] 1511 	mov	dpl, r6
      0050E1 C0 07            [24] 1512 	push	ar7
      0050E3 C0 06            [24] 1513 	push	ar6
      0050E5 C0 05            [24] 1514 	push	ar5
      0050E7 C0 04            [24] 1515 	push	ar4
      0050E9 C0 03            [24] 1516 	push	ar3
      0050EB C0 02            [24] 1517 	push	ar2
      0050ED 12 90 06         [24] 1518 	lcall	_dynamic_keymap_get_tap_dance
      0050F0 12 38 7F         [24] 1519 	lcall	_ak820_outline_0100
      0050F3 D0 02            [24] 1520 	pop	ar2
      0050F5 D0 03            [24] 1521 	pop	ar3
      0050F7 D0 04            [24] 1522 	pop	ar4
      0050F9 D0 05            [24] 1523 	pop	ar5
      0050FB D0 06            [24] 1524 	pop	ar6
      0050FD D0 07            [24] 1525 	pop	ar7
      0050FF 45 F0            [12] 1526 	orl	a,b
      005101 70 3E            [24] 1527 	jnz	00123$
                                   1528 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:141: slot->source = id;
      005103 51 0B            [12] 1529 	acall	_ak820_outline_0191
      005105 A3               [24] 1530 	inc	dptr
      005106 A3               [24] 1531 	inc	dptr
      005107 ED               [12] 1532 	mov	a,r5
      005108 F0               [24] 1533 	movx	@dptr,a
      005109                       1534 00122$:
                                   1535 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:143: slot->state = (slot->state & 3) + 1 + TD_DOWN;
      005109 12 46 3F         [24] 1536 	lcall	_ak820_outline_0148
      00510C E0               [24] 1537 	movx	a,@dptr
      00510D F9               [12] 1538 	mov	r1,a
      00510E 74 03            [12] 1539 	mov	a,#0x03
      005110 59               [12] 1540 	anl	a,r1
      005111 24 05            [12] 1541 	add	a, #0x05
      005113 12 46 3F         [24] 1542 	lcall	_ak820_outline_0148
      005116 F0               [24] 1543 	movx	@dptr,a
                                   1544 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:144: td_time = record->event.time;
      005117 90 06 87         [24] 1545 	mov	dptr,#_ak820_tap_dance_process_record_10000_648
      00511A 12 38 4F         [24] 1546 	lcall	_ak820_outline_0078
      00511D 12 46 3F         [24] 1547 	lcall	_ak820_outline_0148
      005120 A3               [24] 1548 	inc	dptr
      005121 A3               [24] 1549 	inc	dptr
      005122 12 38 4F         [24] 1550 	lcall	_ak820_outline_0078
      005125 90 06 2A         [24] 1551 	mov	dptr,#_td_time
      005128 EA               [12] 1552 	mov	a,r2
      005129 F0               [24] 1553 	movx	@dptr,a
      00512A EB               [12] 1554 	mov	a,r3
      00512B A3               [24] 1555 	inc	dptr
      00512C F0               [24] 1556 	movx	@dptr,a
                                   1557 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:145: td_wait = slot;
      00512D 90 06 1C         [24] 1558 	mov	dptr,#_td_wait
      005130 EC               [12] 1559 	mov	a,r4
      005131 12 38 98         [24] 1560 	lcall	_ak820_outline_0121
                                   1561 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:146: td_map_set(id, index);
      005134 90 06 6D         [24] 1562 	mov	dptr,#_td_map_set_PARM_2
      005137 EE               [12] 1563 	mov	a,r6
      005138 F0               [24] 1564 	movx	@dptr,a
      005139 8D 82            [24] 1565 	mov	dpl, r5
      00513B 12 4C 34         [24] 1566 	lcall	_td_map_set
                                   1567 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:147: return false;
      00513E 02 4C 83         [24] 1568 	ljmp	_ak820_tailshare_00012
      005141                       1569 00123$:
                                   1570 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:149: td_map_set(id, TD_MAP_NONE);
      005141 90 06 6D         [24] 1571 	mov	dptr,#_td_map_set_PARM_2
      005144 74 08            [12] 1572 	mov	a,#0x08
      005146 F0               [24] 1573 	movx	@dptr,a
      005147 8D 82            [24] 1574 	mov	dpl, r5
      005149 12 4C 34         [24] 1575 	lcall	_td_map_set
                                   1576 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:150: return false;
      00514C 02 4C 83         [24] 1577 	ljmp	_ak820_tailshare_00012
                                   1578 ;------------------------------------------------------------
                                   1579 ;Allocation info for local variables in function 'ak820_tap_dance_cancel'
                                   1580 ;------------------------------------------------------------
                                   1581 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_659'
                                   1582 ;i             Allocated with name '_ak820_tap_dance_cancel_i_20000_660'
                                   1583 ;------------------------------------------------------------
                                   1584 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:152: void ak820_tap_dance_cancel(void) {
                                   1585 ;	-----------------------------------------
                                   1586 ;	 function ak820_tap_dance_cancel
                                   1587 ;	-----------------------------------------
      00514F                       1588 _ak820_tap_dance_cancel:
                                   1589 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:153: td_wait = 0;
      00514F 90 06 1C         [24] 1590 	mov	dptr,#_td_wait
      005152 51 06            [12] 1591 	acall	_ak820_outline_0162
                                   1592 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:154: for (uint8_t i = 0; i < VIAL_TAP_DANCE_ENTRIES; ++i) td_slots[i].state = 0;
      005154 FF               [12] 1593 	mov	r7,a
      005155                       1594 00104$:
      005155 BF 08 00         [24] 1595 	cjne	r7,#0x08,00141$
      005158                       1596 00141$:
      005158 50 18            [24] 1597 	jnc	00101$
      00515A EF               [12] 1598 	mov	a,r7
      00515B 75 F0 04         [24] 1599 	mov	b,#0x04
      00515E A4               [48] 1600 	mul	ab
      00515F 24 FC            [12] 1601 	add	a, #_td_slots
      005161 FD               [12] 1602 	mov	r5,a
      005162 74 05            [12] 1603 	mov	a,#(_td_slots >> 8)
      005164 35 F0            [12] 1604 	addc	a, b
      005166 FE               [12] 1605 	mov	r6,a
      005167 12 38 AA         [24] 1606 	lcall	_ak820_outline_0138
      00516A A3               [24] 1607 	inc	dptr
      00516B A3               [24] 1608 	inc	dptr
      00516C A3               [24] 1609 	inc	dptr
      00516D E4               [12] 1610 	clr	a
      00516E F0               [24] 1611 	movx	@dptr,a
      00516F 0F               [12] 1612 	inc	r7
      005170 80 E3            [24] 1613 	sjmp	00104$
      005172                       1614 00101$:
                                   1615 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:155: for (uint8_t i = 0; i < sizeof(td_map); ++i) td_map[i] = 0;
      005172 7F 00            [12] 1616 	mov	r7,#0x00
      005174                       1617 00107$:
      005174 BF 40 00         [24] 1618 	cjne	r7,#0x40,00143$
      005177                       1619 00143$:
      005177 50 0C            [24] 1620 	jnc	00109$
      005179 EF               [12] 1621 	mov	a,r7
      00517A 24 2C            [12] 1622 	add	a, #_td_map
      00517C F5 82            [12] 1623 	mov	dpl,a
      00517E E4               [12] 1624 	clr	a
      00517F 34 06            [12] 1625 	addc	a, #(_td_map >> 8)
      005181 31 EF            [12] 1626 	acall	_ak820_outline_0140
      005183 80 EF            [24] 1627 	sjmp	00107$
      005185                       1628 00109$:
                                   1629 ;	keyboards/ajazz/ak820/ak820_tap_dance.c:156: }
      005185 22               [24] 1630 	ret
                                   1631 	.area CSEG    (CODE)
                                   1632 	.area CONST   (CODE)
                                   1633 	.area XINIT   (CODE)
                                   1634 	.area CABS    (ABS,CODE)
                                   1635 
                                   1636 ; Experimental exact instruction outlining.
                                   1637 	.globl _ak820_outline_0002
                                   1638 	.globl _ak820_outline_0005
                                   1639 	.globl _ak820_outline_0007
                                   1640 	.globl _ak820_outline_0008
                                   1641 	.globl _ak820_outline_0013
                                   1642 	.globl _ak820_outline_0016
                                   1643 	.globl _ak820_outline_0023
                                   1644 	.globl _ak820_outline_0028
                                   1645 	.globl _ak820_outline_0030
                                   1646 	.globl _ak820_outline_0034
                                   1647 	.globl _ak820_outline_0044
                                   1648 	.globl _ak820_outline_0055
                                   1649 	.globl _ak820_outline_0063
                                   1650 	.globl _ak820_outline_0064
                                   1651 	.globl _ak820_outline_0065
                                   1652 	.globl _ak820_outline_0075
                                   1653 	.globl _ak820_outline_0076
                                   1654 	.globl _ak820_outline_0077
                                   1655 	.globl _ak820_outline_0078
                                   1656 	.globl _ak820_outline_0084
                                   1657 	.globl _ak820_outline_0095
                                   1658 	.globl _ak820_outline_0097
                                   1659 	.globl _ak820_outline_0098
                                   1660 	.globl _ak820_outline_0100
                                   1661 	.globl _ak820_outline_0101
                                   1662 	.globl _ak820_outline_0105
                                   1663 	.globl _ak820_outline_0117
                                   1664 	.globl _ak820_outline_0118
                                   1665 	.globl _ak820_outline_0121
                                   1666 	.globl _ak820_outline_0122
                                   1667 	.globl _ak820_outline_0127
                                   1668 	.globl _ak820_outline_0129
                                   1669 	.globl _ak820_outline_0138
                                   1670 	.globl _ak820_outline_0140
                                   1671 	.globl _ak820_outline_0146
                                   1672 	.globl _ak820_outline_0148
                                   1673 	.globl _ak820_outline_0149
                                   1674 	.globl _ak820_outline_0153
                                   1675 	.globl _ak820_outline_0161
                                   1676 	.globl _ak820_outline_0162
                                   1677 	.globl _ak820_outline_0174
                                   1678 	.globl _ak820_outline_0191
                                   1679 	.globl _ak820_outline_0196
                                   1680 
                                   1681 	.area CSEG (CODE)
                                   1682 ; function ak820_outline_0007
      005186                       1683 _ak820_outline_0007:
      005186 90 06 1E         [24] 1684 	mov	dptr,#_td_work
      005189 E0               [24] 1685 	movx	a,@dptr
      00518A FE               [12] 1686 	mov	r6,a
      00518B A3               [24] 1687 	inc	dptr
      00518C E0               [24] 1688 	movx	a,@dptr
      00518D FF               [12] 1689 	mov	r7,a
      00518E 74 03            [12] 1690 	mov	a,#0x03
      005190 2E               [12] 1691 	add	a,r6
      005191 FE               [12] 1692 	mov	r6,a
      005192 E4               [12] 1693 	clr	a
      005193 3F               [12] 1694 	addc	a,r7
      005194 FF               [12] 1695 	mov	r7,a
      005195 8E 82            [24] 1696 	mov	dpl,r6
      005197 8F 83            [24] 1697 	mov	dph,r7
      005199 E0               [24] 1698 	movx	a,@dptr
      00519A 22               [24] 1699 	ret
                                   1700 
                                   1701 	.area CSEG (CODE)
                                   1702 ; function ak820_outline_0008
      00519B                       1703 _ak820_outline_0008:
      00519B 2E               [12] 1704 	add	a,r6
      00519C FC               [12] 1705 	mov	r4,a
      00519D E4               [12] 1706 	clr	a
      00519E 3F               [12] 1707 	addc	a,r7
      00519F FD               [12] 1708 	mov	r5,a
      0051A0 8C 82            [24] 1709 	mov	dpl,r4
      0051A2 8D 83            [24] 1710 	mov	dph,r5
      0051A4 E0               [24] 1711 	movx	a,@dptr
      0051A5 22               [24] 1712 	ret
                                   1713 
                                   1714 	.area CSEG (CODE)
                                   1715 ; function ak820_outline_0013
      0051A6                       1716 _ak820_outline_0013:
      0051A6 2E               [12] 1717 	add	a,r6
      0051A7 FB               [12] 1718 	mov	r3,a
      0051A8 E4               [12] 1719 	clr	a
      0051A9 3F               [12] 1720 	addc	a,r7
      0051AA FC               [12] 1721 	mov	r4,a
      0051AB 8B 82            [24] 1722 	mov	dpl,r3
      0051AD 8C 83            [24] 1723 	mov	dph,r4
      0051AF E0               [24] 1724 	movx	a,@dptr
      0051B0 22               [24] 1725 	ret
                                   1726 
                                   1727 	.area CSEG (CODE)
                                   1728 ; function ak820_outline_0028
      0051B1                       1729 _ak820_outline_0028:
      0051B1 E0               [24] 1730 	movx	a,@dptr
      0051B2 FE               [12] 1731 	mov	r6,a
      0051B3 A3               [24] 1732 	inc	dptr
      0051B4 E0               [24] 1733 	movx	a,@dptr
      0051B5 FF               [12] 1734 	mov	r7,a
      0051B6 90 06 76         [24] 1735 	mov	dptr,#(_td_record+0x0007)
                                   1736 	.globl _ak820_tailshare_00014
                           0005AB  1737 _ak820_tailshare_00014 = .
      0051B9 EE               [12] 1738 	mov	a,r6
      0051BA F0               [24] 1739 	movx	@dptr,a
      0051BB EF               [12] 1740 	mov	a,r7
      0051BC A3               [24] 1741 	inc	dptr
      0051BD F0               [24] 1742 	movx	@dptr,a
      0051BE 22               [24] 1743 	ret
                                   1744 
                                   1745 	.area CSEG (CODE)
                                   1746 ; function ak820_outline_0030
      0051BF                       1747 _ak820_outline_0030:
      0051BF E0               [24] 1748 	movx	a,@dptr
      0051C0 F5 F0            [12] 1749 	mov	b,a
      0051C2 A3               [24] 1750 	inc	dptr
      0051C3 E0               [24] 1751 	movx	a,@dptr
      0051C4 45 F0            [12] 1752 	orl	a,b
      0051C6 22               [24] 1753 	ret
                                   1754 
                                   1755 	.area CSEG (CODE)
                                   1756 ; function ak820_outline_0064
      0051C7                       1757 _ak820_outline_0064:
      0051C7 21 B9            [12] 1758 	ajmp	_ak820_tailshare_00014
                                   1759 
                                   1760 	.area CSEG (CODE)
                                   1761 ; function ak820_outline_0075
      0051C9                       1762 _ak820_outline_0075:
      0051C9 FA               [12] 1763 	mov	r2,a
      0051CA E4               [12] 1764 	clr	a
      0051CB 3F               [12] 1765 	addc	a,r7
      0051CC FB               [12] 1766 	mov	r3,a
      0051CD 8A 82            [24] 1767 	mov	dpl,r2
      0051CF 8B 83            [24] 1768 	mov	dph,r3
      0051D1 E0               [24] 1769 	movx	a,@dptr
      0051D2 22               [24] 1770 	ret
                                   1771 
                                   1772 	.area CSEG (CODE)
                                   1773 ; function ak820_outline_0084
      0051D3                       1774 _ak820_outline_0084:
      0051D3 74 02            [12] 1775 	mov	a,#0x02
      0051D5 2E               [12] 1776 	add	a,r6
      0051D6 FE               [12] 1777 	mov	r6,a
      0051D7 E4               [12] 1778 	clr	a
      0051D8 3F               [12] 1779 	addc	a,r7
      0051D9 FF               [12] 1780 	mov	r7,a
      0051DA 22               [24] 1781 	ret
                                   1782 
                                   1783 	.area CSEG (CODE)
                                   1784 ; function ak820_outline_0098
      0051DB                       1785 _ak820_outline_0098:
      0051DB 8B 82            [24] 1786 	mov	dpl,r3
      0051DD 8C 83            [24] 1787 	mov	dph,r4
      0051DF A3               [24] 1788 	inc	dptr
      0051E0 A3               [24] 1789 	inc	dptr
      0051E1 22               [24] 1790 	ret
                                   1791 
                                   1792 	.area CSEG (CODE)
                                   1793 ; function ak820_outline_0105
      0051E2                       1794 _ak820_outline_0105:
      0051E2 8D 82            [24] 1795 	mov	dpl,r5
      0051E4 8E 83            [24] 1796 	mov	dph,r6
      0051E6 E0               [24] 1797 	movx	a,@dptr
      0051E7 22               [24] 1798 	ret
                                   1799 
                                   1800 	.area CSEG (CODE)
                                   1801 ; function ak820_outline_0117
      0051E8                       1802 _ak820_outline_0117:
      0051E8 89 82            [24] 1803 	mov	dpl,r1
      0051EA 8A 83            [24] 1804 	mov	dph,r2
      0051EC E8               [12] 1805 	mov	a,r0
      0051ED F0               [24] 1806 	movx	@dptr,a
      0051EE 22               [24] 1807 	ret
                                   1808 
                                   1809 	.area CSEG (CODE)
                                   1810 ; function ak820_outline_0140
      0051EF                       1811 _ak820_outline_0140:
      0051EF F5 83            [12] 1812 	mov	dph,a
      0051F1 E4               [12] 1813 	clr	a
      0051F2 F0               [24] 1814 	movx	@dptr,a
      0051F3 0F               [12] 1815 	inc	r7
      0051F4 22               [24] 1816 	ret
                                   1817 
                                   1818 	.area CSEG (CODE)
                                   1819 ; function ak820_outline_0153
      0051F5                       1820 _ak820_outline_0153:
      0051F5 F0               [24] 1821 	movx	@dptr,a
      0051F6 90 06 76         [24] 1822 	mov	dptr,#(_td_record+0x0007)
      0051F9 E0               [24] 1823 	movx	a,@dptr
      0051FA FE               [12] 1824 	mov	r6,a
      0051FB A3               [24] 1825 	inc	dptr
      0051FC E0               [24] 1826 	movx	a,@dptr
      0051FD 4E               [12] 1827 	orl	a,r6
      0051FE 22               [24] 1828 	ret
                                   1829 
                                   1830 	.area CSEG (CODE)
                                   1831 ; function ak820_outline_0161
      0051FF                       1832 _ak820_outline_0161:
      0051FF FA               [12] 1833 	mov	r2,a
      005200 89 82            [24] 1834 	mov	dpl,r1
      005202 8A 83            [24] 1835 	mov	dph,r2
      005204 E0               [24] 1836 	movx	a,@dptr
      005205 22               [24] 1837 	ret
                                   1838 
                                   1839 	.area CSEG (CODE)
                                   1840 ; function ak820_outline_0162
      005206                       1841 _ak820_outline_0162:
      005206 E4               [12] 1842 	clr	a
      005207 F0               [24] 1843 	movx	@dptr,a
      005208 A3               [24] 1844 	inc	dptr
      005209 F0               [24] 1845 	movx	@dptr,a
      00520A 22               [24] 1846 	ret
                                   1847 
                                   1848 	.area CSEG (CODE)
                                   1849 ; function ak820_outline_0191
      00520B                       1850 _ak820_outline_0191:
      00520B 8C 82            [24] 1851 	mov	dpl,r4
      00520D 8F 83            [24] 1852 	mov	dph,r7
      00520F 22               [24] 1853 	ret
                                   1854 
                                   1855 	.area CSEG (CODE)
                                   1856 ; function ak820_outline_0196
      005210                       1857 _ak820_outline_0196:
      005210 75 F0 02         [24] 1858 	mov	b,#0x02
      005213 A4               [48] 1859 	mul	ab
      005214 22               [24] 1860 	ret
